﻿# A diary may have one inspection date or an individually chosen date range.
# DateCount is reusable form structure; the actual two timestamps are patient data.
function Get-MedicalDiaryDateCount($definition){
 if(-not $definition -or -not $definition.PSObject.Properties['DateCount']){return 1}
 $count=$definition.DateCount
 if(($count -isnot [int] -and $count -isnot [long]) -or $count -notin @(1,2)){throw 'Для дневника можно выбрать одну дату или период из двух дат.'}
 return [int]$count
}
function ConvertTo-MedicalDiaryDate($value,[string]$label){
 $date=[datetime]::MinValue
 if($value -is [datetime]){$date=[datetime]$value}
 elseif(-not [datetime]::TryParseExact([string]$value,'yyyy-MM-ddTHH:mm:ss',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$date)){throw ('Укажите корректную дату '+$label+' дневника.')}
 if($date -lt [datetime]'1753-01-01' -or $date -gt [datetime]'9998-12-31'){throw ('Дата '+$label+' дневника находится вне допустимого диапазона календаря.')}
 return $date
}
function Get-MedicalDiaryRange($context){
 $start=ConvertTo-MedicalDiaryDate $context.DateTime 'начала'
 $end=$start
 if($context.PSObject.Properties['EndDateTime'] -and $null -ne $context.EndDateTime -and [string]$context.EndDateTime -ne ''){$end=ConvertTo-MedicalDiaryDate $context.EndDateTime 'окончания'}
 if($end -lt $start){throw 'Дата окончания осмотра не может быть раньше даты начала.'}
 return [pscustomobject]@{DateCount=(Get-MedicalDiaryDateCount $context);Start=$start;End=$end}
}
function Set-MedicalDiaryDateCount([string]$id,[int]$count){
 if($count -notin @(1,2)){throw 'Для дневника можно выбрать одну дату или период из двух дат.'}
 $binding=Get-MedicalClinicalBinding 'diary' $id
 $binding.Definition | Add-Member -NotePropertyName DateCount -NotePropertyValue $count -Force
 # Keep the second timestamp while switching to one date, so switching back
 # restores the selected end rather than silently discarding patient data.
 if(-not $binding.State.PSObject.Properties['EndDateTime']){$binding.State | Add-Member -NotePropertyName EndDateTime -NotePropertyValue ([string]$binding.State.DateTime)}
 if($count -eq 2){$binding.State | Add-Member -NotePropertyName DateIsAutomatic -NotePropertyValue $false -Force}
}
function Set-MedicalDiaryDates([string]$id,$start,$end){
 $from=ConvertTo-MedicalDiaryDate $start 'начала';$until=ConvertTo-MedicalDiaryDate $end 'окончания'
 if($until -lt $from){throw 'Дата окончания осмотра не может быть раньше даты начала.'}
 $binding=Get-MedicalClinicalBinding 'diary' $id
 $changed=([string]$binding.State.DateTime -cne $from.ToString('yyyy-MM-ddTHH:mm:ss') -or [string]$binding.State.EndDateTime -cne $until.ToString('yyyy-MM-ddTHH:mm:ss'))
 $binding.State.DateTime=$from.ToString('yyyy-MM-ddTHH:mm:ss')
 $binding.State | Add-Member -NotePropertyName EndDateTime -NotePropertyValue ($until.ToString('yyyy-MM-ddTHH:mm:ss')) -Force
 if($changed){$binding.State | Add-Member -NotePropertyName DateIsAutomatic -NotePropertyValue $false -Force}
}
function Update-MedicalDiaryPeriodControls($binding){
 $period=(Get-MedicalDiaryDateCount (Get-MedicalClinicalBinding 'diary' $binding.Id).Definition) -eq 2
 $binding.DiaryEndLabel.Visible=$period;$binding.DiaryEndControl.Visible=$period
 $binding.DiaryDateLabel.Text=if($period){'С'}else{'Дата и время записи'}
}
function Invoke-MedicalDiaryStartDateChanged($binding,[datetime]$value){
 if($binding.DiaryPeriodUpdating -or $script:medicalClinicalBuilding -or $binding.Stage -ne $script:stage){return}
 Set-MedicalClinicalDate $binding.Id $value
 if($binding.PSObject.Properties['DiaryEndControl'] -and $binding.DiaryEndControl){
  $state=(Get-MedicalClinicalBinding 'diary' $binding.Id).State
  $end=ConvertTo-MedicalDiaryDate $state.EndDateTime 'окончания'
  if($binding.DiaryEndControl.Value -ne $end){$binding.DiaryPeriodUpdating=$true;try{$binding.DiaryEndControl.Value=$end}finally{$binding.DiaryPeriodUpdating=$false}}
 }
}
function Invoke-MedicalDiaryEndDateChanged($binding,[datetime]$value){
 if($binding.DiaryPeriodUpdating -or $script:medicalClinicalBuilding -or $binding.Stage -ne $script:stage){return}
 $from=ConvertTo-MedicalDiaryDate (Get-MedicalClinicalBinding 'diary' $binding.Id).State.DateTime 'начала'
 if($value -lt $from){
  $binding.DiaryPeriodUpdating=$true
  try{$binding.DiaryEndControl.Value=ConvertTo-MedicalDiaryDate (Get-MedicalClinicalBinding 'diary' $binding.Id).State.EndDateTime 'окончания'}finally{$binding.DiaryPeriodUpdating=$false}
  [void][Windows.Forms.MessageBox]::Show('Дата окончания осмотра не может быть раньше даты начала.','Период дневника')
  return
 }
 Set-MedicalDiaryDates $binding.Id $from $value
}
function Invoke-MedicalDiaryDateModeChanged($binding){
 if($binding.DiaryPeriodUpdating -or $script:medicalClinicalBuilding -or $binding.Stage -ne $script:stage){return}
 Set-MedicalDiaryDateCount $binding.Id ($binding.DiaryModeControl.SelectedIndex+1)
 Update-MedicalDiaryPeriodControls $binding
}
function Add-MedicalDiaryPeriodControls($toolbar,$binding,$context,$dateLabel){
 $range=Get-MedicalDiaryRange $context
 $mode=New-Object SafeComboBox;$mode.DropDownStyle='DropDownList';$mode.Width=190;$mode.Margin=New-Object Windows.Forms.Padding(0,0,12,8)
 [void]$mode.Items.Add('Одна дата');[void]$mode.Items.Add('Период — с… по…');$mode.SelectedIndex=$range.DateCount-1;$mode.Tag=$binding
 $modeLabel=New-Object Windows.Forms.Label;$modeLabel.Text='Даты осмотра';$modeLabel.AutoSize=$true;$modeLabel.Margin=New-Object Windows.Forms.Padding(0,8,8,0)
 [void]$toolbar.Controls.Add($modeLabel);[void]$toolbar.Controls.Add($mode)
 $endLabel=New-Object Windows.Forms.Label;$endLabel.Text='По';$endLabel.AutoSize=$true;$endLabel.Margin=New-Object Windows.Forms.Padding(0,8,8,0);[void]$toolbar.Controls.Add($endLabel)
 $end=New-Object Windows.Forms.DateTimePicker;$end.Format='Custom';$end.CustomFormat='dd.MM.yyyy  HH:mm';$end.Width=205;$end.Value=$range.End;$end.Tag=$binding;$end.Margin=New-Object Windows.Forms.Padding(0,0,12,8);[void]$toolbar.Controls.Add($end)
 foreach($item in @(@('DiaryDateLabel',$dateLabel),@('DiaryModeControl',$mode),@('DiaryEndLabel',$endLabel),@('DiaryEndControl',$end),@('DiaryPeriodUpdating',$false))){$binding | Add-Member -NotePropertyName $item[0] -NotePropertyValue $item[1] -Force}
 Update-MedicalDiaryPeriodControls $binding
 $mode.Add_SelectedIndexChanged({Invoke-MedicalDiaryDateModeChanged $this.Tag})
 $end.Add_ValueChanged({Invoke-MedicalDiaryEndDateChanged $this.Tag $this.Value})
}
function Read-MedicalDiaryDateControl($control,[string]$label){
 $date=[datetime]$control.Value;$text=([string]$control.Text -replace '\s+',' ').Trim()
 if($text -and $text -cne $date.ToString('dd.MM.yyyy HH:mm')){
  $parsed=[datetime]::MinValue
  if(-not [datetime]::TryParseExact($text,[string[]]@('dd.MM.yyyy HH:mm','dd.MM.yyyy HH:mm:ss'),[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$parsed)){throw ('Проверьте дату '+$label+' дневника: ДД.ММ.ГГГГ ЧЧ:ММ.')}
  $date=$parsed
 }
 return (ConvertTo-MedicalDiaryDate $date $label)
}
function Capture-MedicalDiaryPeriodControls($binding){
 # Read both uncommitted typed values before DateTimePicker events can normalize
 # the other control. A reversed pair never mutates either saved timestamp.
 $start=Read-MedicalDiaryDateControl $binding.DateControl 'начала'
 $period=$binding.PSObject.Properties['DiaryModeControl'] -and $binding.DiaryModeControl -and $binding.DiaryModeControl.SelectedIndex -eq 1
 if($period){$end=Read-MedicalDiaryDateControl $binding.DiaryEndControl 'окончания';Set-MedicalDiaryDates $binding.Id $start $end}
 else{Set-MedicalClinicalDate $binding.Id $start;$end=ConvertTo-MedicalDiaryDate (Get-MedicalClinicalBinding 'diary' $binding.Id).State.EndDateTime 'окончания'}
 $binding.DiaryPeriodUpdating=$true
 try{$binding.DateControl.Value=$start;if($binding.DiaryEndControl){$binding.DiaryEndControl.Value=$end}}finally{$binding.DiaryPeriodUpdating=$false}
}
function Get-MedicalDiaryPeriodMarkerValues($context){
 $range=Get-MedicalDiaryRange $context
 $end=if($range.DateCount -eq 2){$range.End}else{$range.Start}
 $period=if($range.DateCount -eq 2){$range.Start.ToString('dd.MM.yyyy')+' — '+$end.ToString('dd.MM.yyyy')}else{$range.Start.ToString('dd.MM.yyyy')}
 return @{DIARY_START_DATE=$range.Start.ToString('dd.MM.yyyy');DIARY_END_DATE=$end.ToString('dd.MM.yyyy');DIARY_START_DATETIME=$range.Start.ToString('dd.MM.yyyy HH:mm');DIARY_END_DATETIME=$end.ToString('dd.MM.yyyy HH:mm');DIARY_PERIOD=$period}
}
function Set-MedicalDiaryPeriodXml($xml,$markers,$found){
 $n=New-Object Xml.XmlNamespaceManager($xml.NameTable);$n.AddNamespace('w',$script:ns)
 foreach($paragraph in $xml.SelectNodes('//w:p',$n)){
  $texts=@($paragraph.SelectNodes('.//w:t',$n)|Where-Object {[object]::ReferenceEquals($_.SelectSingleNode('ancestor::w:p[1]',$n),$paragraph)})
  $starts=@();$full='';foreach($text in $texts){$starts+=@($full.Length);$full+=$text.InnerText}
  $matches=[regex]::Matches($full,'\{\{(DIARY_(?:START_DATE|END_DATE|START_DATETIME|END_DATETIME|PERIOD))\}\}')
  for($i=$matches.Count-1;$i -ge 0;$i--){
   $match=$matches[$i];$key=$match.Groups[1].Value;$found[$key]=$true;$first=-1;$last=-1;$finish=$match.Index+$match.Length
   for($j=0;$j -lt $texts.Count;$j++){
    if($starts[$j] -le $match.Index -and ($starts[$j]+$texts[$j].InnerText.Length) -gt $match.Index){$first=$j}
    if($starts[$j] -lt $finish -and ($starts[$j]+$texts[$j].InnerText.Length) -ge $finish){$last=$j;break}
   }
   if($first -lt 0 -or $last -lt 0){throw 'Не удалось определить границы маркера периода дневника.'}
   $prefix=$texts[$first].InnerText.Substring(0,$match.Index-$starts[$first]);$suffix=$texts[$last].InnerText.Substring($finish-$starts[$last])
   if($first -eq $last){$texts[$first].InnerText=$prefix+[string]$markers[$key]+$suffix}
   else{$texts[$first].InnerText=$prefix+[string]$markers[$key];for($j=$first+1;$j -lt $last;$j++){$texts[$j].InnerText=''};$texts[$last].InnerText=$suffix}
  }
 }
 foreach($control in $xml.SelectNodes('//w:sdt',$n)){
  $key=''
  foreach($kind in @('tag','alias')){$node=$control.SelectSingleNode('./w:sdtPr/w:'+$kind,$n);if($node -and $markers.ContainsKey($node.GetAttribute('val',$script:ns))){$key=$node.GetAttribute('val',$script:ns);break}}
  if($key){$found[$key]=$true;Set-UniversalControlValue $control ([string]$markers[$key]) $n}
 }
}
function Get-MedicalDiaryPeriodMarkerAnnotation($archive){
 $result=@{};$xml=Get-XmlPart $archive 'customXml/mc-diary-period.xml'
 if($xml -and $xml.DocumentElement.LocalName -ceq 'markers' -and $xml.DocumentElement.NamespaceURI -ceq 'urn:medical-constructor:diary-period:v69'){
  foreach($key in $xml.DocumentElement.GetAttribute('names').Split(';')){if($key -in @('DIARY_START_DATE','DIARY_END_DATE','DIARY_START_DATETIME','DIARY_END_DATETIME','DIARY_PERIOD')){$result[$key]=$true}}
 }
 return $result
}
function Set-MedicalDiaryPeriodMarkerAnnotation($archive,$found){
 # This private annotation records only marker names, never patient dates. It
 # distinguishes a second formatting pass from markers erased by a filled parent
 # Word control, and is stripped before the final document merge.
 $name='customXml/mc-diary-period.xml';$entry=$archive.GetEntry($name);if($entry){$entry.Delete()}
 $xml=[xml]'<m:markers xmlns:m="urn:medical-constructor:diary-period:v69"/>';[void]$xml.DocumentElement.SetAttribute('names',([string[]]@($found.Keys|Sort-Object) -join ';'))
 Write-UniversalZipText $archive $name $xml.OuterXml
 $types=Get-XmlPart $archive '[Content_Types].xml';if(-not $types){throw 'В дневнике отсутствует список частей Word.'}
 $c='http://schemas.openxmlformats.org/package/2006/content-types'
 foreach($item in @($types.DocumentElement.ChildNodes)){if($item -is [Xml.XmlElement] -and $item.GetAttribute('PartName') -ieq '/customXml/mc-diary-period.xml'){[void]$types.DocumentElement.RemoveChild($item)}}
 $item=$types.CreateElement('Override',$c);[void]$item.SetAttribute('PartName','/customXml/mc-diary-period.xml');[void]$item.SetAttribute('ContentType','application/xml');[void]$types.DocumentElement.AppendChild($item)
 $entry=$archive.GetEntry('[Content_Types].xml');$entry.Delete();Write-UniversalZipText $archive '[Content_Types].xml' $types.OuterXml
 $r='http://schemas.openxmlformats.org/package/2006/relationships';$rels=Get-XmlPart $archive 'word/_rels/document.xml.rels';if(-not $rels){$rels=[xml]('<Relationships xmlns="'+$r+'"/>')}
 foreach($item in @($rels.DocumentElement.ChildNodes)){if($item -is [Xml.XmlElement] -and $item.GetAttribute('Target') -in @('../customXml/mc-diary-period.xml','/customXml/mc-diary-period.xml')){[void]$rels.DocumentElement.RemoveChild($item)}}
 $item=$rels.CreateElement('Relationship',$r);[void]$item.SetAttribute('Id','rIdMCDiaryPeriod'+[guid]::NewGuid().ToString('N'));[void]$item.SetAttribute('Type','http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXml');[void]$item.SetAttribute('Target','../customXml/mc-diary-period.xml');[void]$rels.DocumentElement.AppendChild($item)
 $entry=$archive.GetEntry('word/_rels/document.xml.rels');if($entry){$entry.Delete()};Write-UniversalZipText $archive 'word/_rels/document.xml.rels' $rels.OuterXml
}
function Set-MedicalDiaryPeriodDocument([string]$path,$context){
 $range=Get-MedicalDiaryRange $context;$markers=Get-MedicalDiaryPeriodMarkerValues $context
 $schema=$context.Schema
 $source=if($schema){Get-UniversalTemplatePath $schema}else{''}
 if($source -and [string]::Equals([IO.Path]::GetFullPath($source),[IO.Path]::GetFullPath($path),[StringComparison]::OrdinalIgnoreCase)){throw 'Период дневника можно добавлять только в копию документа, а не в исходный Word-шаблон.'}
 $temp=Join-Path ([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($path))) ('mc-diary-period-'+[guid]::NewGuid().ToString('N')+'.tmp');$archive=$null
 try{
  [IO.File]::Copy($path,$temp,$false);$archive=[IO.Compression.ZipFile]::Open($temp,[IO.Compression.ZipArchiveMode]::Update)
  $found=Get-MedicalDiaryPeriodMarkerAnnotation $archive
  $parts=@{}
  foreach($entry in @($archive.Entries)){
   if($entry.FullName -notmatch '^word/(document|header[0-9]*|footer[0-9]*)\.xml$'){continue}
   $xml=Get-XmlPart $archive $entry.FullName;Set-MedicalDiaryPeriodXml $xml $markers $found;$parts[$entry.FullName]=$xml
  }
  $xml=$parts['word/document.xml'];if(-not $xml){throw 'В дневнике отсутствует основной текст документа.'}
  $n=New-Object Xml.XmlNamespaceManager($xml.NameTable);$n.AddNamespace('w',$script:ns);$body=$xml.SelectSingleNode('/w:document/w:body',$n)
  if(-not $body){throw 'В дневнике отсутствует основная область текста.'}
  $bookmark=$xml.SelectSingleNode('//w:bookmarkStart[@w:name="MedicalDiaryPeriod"]',$n)
  $hasStart=$found.ContainsKey('DIARY_START_DATE') -or $found.ContainsKey('DIARY_START_DATETIME');$hasEnd=$found.ContainsKey('DIARY_END_DATE') -or $found.ContainsKey('DIARY_END_DATETIME')
  $needLine=$range.DateCount -eq 2 -and -not ($found.ContainsKey('DIARY_PERIOD') -or ($hasStart -and $hasEnd))
  if(-not $needLine -and $bookmark){$paragraph=$bookmark.SelectSingleNode('ancestor::w:p[1]',$n);if($paragraph){[void]$paragraph.ParentNode.RemoveChild($paragraph)}}
  if($needLine){
   $text='Период осмотра: '+$range.Start.ToString('dd.MM.yyyy HH:mm')+' — '+$range.End.ToString('dd.MM.yyyy HH:mm')
   if($bookmark){
    $paragraph=$bookmark.SelectSingleNode('ancestor::w:p[1]',$n);$texts=@($paragraph.SelectNodes('.//w:t',$n))
    if(-not $texts.Count){throw 'Некорректная строка периода осмотра.'}
    $texts[0].InnerText=$text;for($i=1;$i -lt $texts.Count;$i++){$texts[$i].InnerText=''}
   }else{
    $paragraph=$xml.CreateElement('w','p',$script:ns);$first=$body.SelectSingleNode('./w:p',$n)
    # Avoid inheriting heading/section breaks from a document title.
    if($first){$props=$first.SelectSingleNode('./w:pPr',$n);if($props){$copy=$props.CloneNode($true);foreach($node in @($copy.SelectNodes('./w:pStyle|./w:outlineLvl|./w:pageBreakBefore|./w:keepNext|./w:sectPr',$n))){[void]$copy.RemoveChild($node)};[void]$paragraph.AppendChild($copy)}}
    $max=0L;foreach($attribute in $xml.SelectNodes('//w:bookmarkStart/@w:id',$n)){$number=0L;if([long]::TryParse($attribute.Value,[ref]$number) -and $number -gt $max){$max=$number}};$id=($max+1).ToString()
    $begin=$xml.CreateElement('w','bookmarkStart',$script:ns);[void]$begin.SetAttribute('id',$script:ns,$id);[void]$begin.SetAttribute('name',$script:ns,'MedicalDiaryPeriod');[void]$paragraph.AppendChild($begin)
    $run=$xml.CreateElement('w','r',$script:ns);$node=$xml.CreateElement('w','t',$script:ns);$node.InnerText=$text;[void]$run.AppendChild($node);[void]$paragraph.AppendChild($run)
    $finish=$xml.CreateElement('w','bookmarkEnd',$script:ns);[void]$finish.SetAttribute('id',$script:ns,$id);[void]$paragraph.AppendChild($finish)
    if($first){[void]$body.InsertAfter($paragraph,$first)}else{$section=$body.SelectSingleNode('./w:sectPr',$n);if($section){[void]$body.InsertBefore($paragraph,$section)}else{[void]$body.AppendChild($paragraph)}}
   }
  }
  foreach($name in @($parts.Keys)){$entry=$archive.GetEntry($name);$entry.Delete();Write-UniversalZipText $archive $name $parts[$name].OuterXml}
  Set-MedicalDiaryPeriodMarkerAnnotation $archive $found
  $archive.Dispose();$archive=$null;[IO.File]::Replace($temp,$path,[NullString]::Value)
 }finally{if($archive){$archive.Dispose()};if([IO.File]::Exists($temp)){[IO.File]::Delete($temp)}}
}
