﻿# Reusable forms contain a schema and a Word template, never patient answers.
$script:medicalProgramRoot=$PSScriptRoot
$script:medicalTemplatesFolder=Join-Path $script:medicalProgramRoot 'Шаблоны'

function Initialize-MedicalTemplateFolder {
 [void][IO.Directory]::CreateDirectory($script:medicalTemplatesFolder)
 return $script:medicalTemplatesFolder
}

function Get-MedicalFormDisplayName([string]$name,[string]$fallback='Новая форма'){
 # Managed copies append a twelve-character content hash. Show the human stem,
 # including clinical names such as F10-Ж, rather than storage identifiers.
 $leaf=[IO.Path]::GetFileName(([string]$name).Trim().Replace('\','/'))
 if([IO.Path]::GetExtension($leaf) -in @('.docx','.dotx','.mcform','.json')){$leaf=[IO.Path]::GetFileNameWithoutExtension($leaf)}
 $guid='(?:[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}|[a-fA-F0-9]{32})'
 if($leaf -match ('^(?:mc(?:49|59)?-(?:template|snapshot)|mc-editor-(?:source|new|rebuild|result))-'+$guid+'$')){$leaf=''}
 else{
  # Temporary GUID prefixes predate the managed-copy naming scheme.
  $hadGuidPrefix=$leaf -match ('^(?:'+$guid+'[-_ ])+')
  $leaf=[regex]::Replace($leaf,('^(?:'+$guid+'[-_ ])+'),'')
  if($leaf -match ('^(?:'+$guid+')(?:[-_ ]'+$guid+')*$')){$leaf=''}
  else{
   # Only exact lowercase hashes written by the importer are storage suffixes.
   # Short hexadecimal words and uppercase clinical identifiers are retained.
   do{$previous=$leaf;$leaf=[regex]::Replace($leaf,'-(?:[a-f0-9]{12}|[a-f0-9]{64})(?:-[2-9][0-9]*|-[1-9][0-9]+)?$','')}while($leaf -cne $previous)
   if($leaf -match ('^(?:'+$guid+')$') -or ($hadGuidPrefix -and $leaf -cmatch '^(?:[a-f0-9]{12}|[a-f0-9]{64})$')){$leaf=''}
  }
 }
 $leaf=$leaf.Trim()
 if([string]::IsNullOrWhiteSpace($leaf)){
  $fallback=([string]$fallback).Trim()
  if([string]::IsNullOrWhiteSpace($fallback)){$fallback='Новая форма'}
  return $fallback
 }
 return $leaf
}

function Get-MedicalManagedTemplateName([string]$name){
 $name=Get-MedicalTemplateName $name
 $extension=[IO.Path]::GetExtension($name)
 $stem=Get-MedicalFormDisplayName $name 'Шаблон формы'
 return (Get-MedicalTemplateName ($stem+$extension))
}

function Get-MedicalTemplateName([string]$name){
 if([string]::IsNullOrWhiteSpace($name) -or $name -match '[<>:"/\\|?*\x00-\x1F]' -or $name -match '[. ]$' -or $name.Length -gt 240){
  throw 'Укажите допустимое имя шаблона Word без пути и специальных символов.'
 }
 $extension=[IO.Path]::GetExtension($name)
 if($extension -notin @('.docx','.dotx')){throw 'Шаблон Word должен иметь расширение .docx или .dotx.'}
 $stem=[IO.Path]::GetFileNameWithoutExtension($name)
 if([string]::IsNullOrWhiteSpace($stem) -or $stem -match '^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])($|\.)'){
  throw 'Это имя файла зарезервировано Windows. Укажите другое имя шаблона.'
 }
 return $name
}

function Get-MedicalTemplateInfo([string]$path){
 $name=[IO.Path]::GetFileName($path)
 return [pscustomobject]@{Name=$name;Path=[IO.Path]::GetFullPath($path);RelativePath=('Шаблоны/'+$name)}
}

function Get-MedicalTemplates {
 if(-not [IO.Directory]::Exists($script:medicalTemplatesFolder)){return}
 foreach($item in @(Get-ChildItem -LiteralPath $script:medicalTemplatesFolder -File | Where-Object {$_.Extension -in @('.docx','.dotx')} | Sort-Object Name)){
  Get-MedicalTemplateInfo $item.FullName
 }
}

function Get-MedicalBytesSha256([byte[]]$bytes){
 $algorithm=[Security.Cryptography.SHA256]::Create()
 try{return ([BitConverter]::ToString($algorithm.ComputeHash($bytes))).Replace('-','').ToLowerInvariant()}
 finally{$algorithm.Dispose()}
}

# Only reusable Word assets and their content fingerprints live in this cache.
# Every authored file is still freshly read and SHA256 checked by its caller;
# mtime and file size are never accepted as proof that content is unchanged.
function Get-MedicalTemplateMemo([string]$kind,[string]$key){
 if($null -eq $script:medicalTemplateMemo){$script:medicalTemplateMemo=[ordered]@{};$script:medicalTemplateMemoBytes=0L}
 $cacheKey=$kind+':'+$key
 if(-not $script:medicalTemplateMemo.Contains($cacheKey)){return $null}
 $entry=$script:medicalTemplateMemo[$cacheKey]
 $script:medicalTemplateMemo.Remove($cacheKey);$script:medicalTemplateMemo[$cacheKey]=$entry
 return $entry.Value
}
function Set-MedicalTemplateMemo([string]$kind,[string]$key,$value,[long]$cost=0){
 if($null -eq $script:medicalTemplateMemo){$script:medicalTemplateMemo=[ordered]@{};$script:medicalTemplateMemoBytes=0L}
 if($cost -lt 0 -or $cost -gt 33554432){return}
 $cacheKey=$kind+':'+$key
 if($script:medicalTemplateMemo.Contains($cacheKey)){$script:medicalTemplateMemoBytes-=$script:medicalTemplateMemo[$cacheKey].Cost;$script:medicalTemplateMemo.Remove($cacheKey)}
 while($script:medicalTemplateMemo.Count -ge 128 -or ($script:medicalTemplateMemoBytes+$cost) -gt 33554432){
  $oldest=@($script:medicalTemplateMemo.Keys)[0];$script:medicalTemplateMemoBytes-=$script:medicalTemplateMemo[$oldest].Cost;$script:medicalTemplateMemo.Remove($oldest)
 }
 $script:medicalTemplateMemo[$cacheKey]=[pscustomobject]@{Value=$value;Cost=$cost};$script:medicalTemplateMemoBytes+=$cost
}

function Test-MedicalTemplateBytes([byte[]]$bytes){
 if($null -eq $bytes -or $bytes.Length -eq 0){throw 'Файл шаблона Word пуст.'}
 $contentHash=Get-MedicalBytesSha256 $bytes
 if(Get-MedicalTemplateMemo 'validated' $contentHash){return}
 $memory=$null;$archive=$null;$entryStream=$null;$reader=$null
 try{
  $memory=[IO.MemoryStream]::new($bytes,$false)
  $archive=[IO.Compression.ZipArchive]::new($memory,[IO.Compression.ZipArchiveMode]::Read,$true)
  if(@($archive.Entries | Where-Object {$_.FullName -in @('customXml/mc49.xml','customXml/mc-case.xml')}).Count){
   throw 'Это заполненный документ Медицинского конструктора. Выберите незаполненный Word-шаблон: формы не должны содержать ответы пациента.'
  }
  $documents=@($archive.Entries | Where-Object {$_.FullName -ceq 'word/document.xml'})
  if($documents.Count -ne 1){throw 'В шаблоне Word должен быть один файл word/document.xml.'}
  $settings=New-Object Xml.XmlReaderSettings
  $settings.DtdProcessing=[Xml.DtdProcessing]::Prohibit;$settings.XmlResolver=$null
  $settings.MaxCharactersInDocument=33554432
  $wordNamespace='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
  $xmlEntries=@($documents[0])+@($archive.Entries | Where-Object {$_.FullName -match '^word/(header|footer)[^/]*\.xml$'})
  foreach($xmlEntry in $xmlEntries){
   $entryStream=$xmlEntry.Open();$reader=[Xml.XmlReader]::Create($entryStream,$settings)
   $document=New-Object Xml.XmlDocument;$document.XmlResolver=$null;$document.Load($reader)
   if($xmlEntry.FullName -ceq 'word/document.xml'){
    if($null -eq $document.DocumentElement -or $document.DocumentElement.LocalName -cne 'document' -or $document.DocumentElement.NamespaceURI -cne $wordNamespace){throw 'В файле нет корректного документа Word.'}
    $namespaces=[Xml.XmlNamespaceManager]::new($document.NameTable);$namespaces.AddNamespace('w',$wordNamespace)
    if($null -eq $document.SelectSingleNode('/w:document/w:body',$namespaces)){throw 'В документе Word отсутствует основное содержимое.'}
    $text=(($document.SelectNodes('//w:t',$namespaces) | ForEach-Object {$_.InnerText}) -join '')
    foreach($payload in [regex]::Matches($text,'MC_CASE_V24:([A-Za-z0-9+/=]+):END_MC_CASE')){
     $isCasePayload=$false
     try{[void][Convert]::FromBase64String($payload.Groups[1].Value);$isCasePayload=$true}catch{}
     if($isCasePayload){throw 'Это сохранённая карта госпитализации с ответами пациента. Выберите незаполненный Word-шаблон для формы.'}
    }
   }
   $reader.Dispose();$reader=$null;$entryStream.Dispose();$entryStream=$null
  }
  Set-MedicalTemplateMemo 'validated' $contentHash $true
 }catch{throw ('Некорректный шаблон Word: '+$_.Exception.Message)}
 finally{
  if($reader){$reader.Dispose()};if($entryStream){$entryStream.Dispose()}
  if($archive){$archive.Dispose()};if($memory){$memory.Dispose()}
 }
}

function Import-MedicalTemplateBytes([byte[]]$bytes,[string]$name,[bool]$preserveName=$false){
 $name=Get-MedicalTemplateName $name
 if(-not $preserveName){$name=Get-MedicalManagedTemplateName $name}
 Test-MedicalTemplateBytes $bytes
 $hash=Get-MedicalBytesSha256 $bytes
 [void](Initialize-MedicalTemplateFolder)
 $stem=[IO.Path]::GetFileNameWithoutExtension($name)
 $extension=[IO.Path]::GetExtension($name)
 $candidate=$name;$attempt=0;$temp=$null
 try{
  while($true){
   $destination=Join-Path $script:medicalTemplatesFolder $candidate
   if([IO.File]::Exists($destination)){
    $existingHash=Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($destination))
    if($existingHash -ceq $hash){return (Get-MedicalTemplateInfo $destination)}
   }elseif([IO.Directory]::Exists($destination)){
    # A directory with this name is also preserved.
   }else{
    if(-not $temp){
     $temp=Join-Path $script:medicalTemplatesFolder ('.mc-template-'+[guid]::NewGuid().ToString('N')+'.tmp')
     [IO.File]::WriteAllBytes($temp,$bytes)
    }
    try{[IO.File]::Move($temp,$destination);$temp=$null;return (Get-MedicalTemplateInfo $destination)}
    catch{
     if(-not [IO.File]::Exists($destination) -and -not [IO.Directory]::Exists($destination)){throw}
    }
   }
   $attempt++
   $suffix='-'+$hash.Substring(0,12);if($attempt -gt 1){$suffix+='-'+$attempt}
   $safeStem=$stem;if($safeStem.Length -gt 180){$safeStem=$safeStem.Substring(0,180)}
   $candidate=$safeStem+$suffix+$extension
  }
 }finally{if($temp -and [IO.File]::Exists($temp)){[IO.File]::Delete($temp)}}
}

function Import-MedicalTemplate([string]$path,[bool]$preserveName=$false){
 if(-not [IO.File]::Exists($path)){throw ('Файл шаблона не найден: '+$path)}
 $name=Get-MedicalTemplateName ([IO.Path]::GetFileName($path))
 return (Import-MedicalTemplateBytes ([IO.File]::ReadAllBytes($path)) $name $preserveName)
}

function New-MedicalTemplateFile([string]$name,$config){
 if([string]::IsNullOrWhiteSpace($name)){$name='Мой шаблон.docx'}
 if(-not [IO.Path]::GetExtension($name)){$name+='.docx'}
 $name=Get-MedicalTemplateName $name
 if([IO.Path]::GetExtension($name) -ine '.docx'){throw 'Новый шаблон создаётся в формате .docx. Для .dotx используйте загрузку готового шаблона Word.'}
 Assert-UniversalConfig $config
 $temp=Join-Path ([IO.Path]::GetTempPath()) ('mc59-template-'+[guid]::NewGuid().ToString('N')+'.docx')
 try{
  New-UniversalTemplate $temp $config
  return (Import-MedicalTemplateBytes ([IO.File]::ReadAllBytes($temp)) $name $true)
 }finally{if([IO.File]::Exists($temp)){[IO.File]::Delete($temp)}}
}

function Copy-MedicalFormSchema($config){
 # Keep only form structure. Unknown properties such as Values or AdmissionDateTime
 # must never turn a reusable form into a patient record.
 $source=Copy-UniversalObject $config
 Assert-UniversalConfig $source
 if($source.AutoTemplate -isnot [bool]){throw 'Режим шаблона Word должен быть логическим значением.'}
 $schema=[ordered]@{Version=[int]$source.Version;AutoTemplate=[bool]$source.AutoTemplate;Template=[string]$source.Template;Sections=@()}
 if($null -ne $source.PSObject.Properties['PreserveTemplateFormatting']){$schema['PreserveTemplateFormatting']=[bool]$source.PreserveTemplateFormatting}
 foreach($property in @('ProfileCode','ProfileSex','DocumentTitle','DateTimeLabel')){
  if($null -ne $source.PSObject.Properties[$property]){$schema[$property]=[string]$source.$property}
 }
 foreach($section in @($source.Sections)){
  $copy=[ordered]@{Id=[string]$section.Id;Title=[string]$section.Title;Fields=@()}
  foreach($field in @($section.Fields)){
   $fieldCopy=[ordered]@{}
   foreach($property in @('Id','Label','Marker','Type','System','WordId','Required','DetailFormPosition','DetailWordPosition','DetailMarker')){
    if($null -ne $field.PSObject.Properties[$property]){$fieldCopy[$property]=$field.$property}
   }
   $fieldCopy['Options']=@($field.Options | ForEach-Object {[string]$_})
   $copy.Fields+=@([pscustomobject]$fieldCopy)
  }
  $schema.Sections+=@([pscustomobject]$copy)
 }
 return (Copy-UniversalObject ([pscustomobject]$schema))
}

function Assert-MedicalFormPath([string]$path){
 if([string]::IsNullOrWhiteSpace($path)){throw 'Укажите файл формы.'}
 if([IO.Path]::GetExtension($path) -notin @('.mcform','.json')){throw 'Файл формы должен иметь расширение .mcform или .json.'}
}

# Stage templates use the exact same validation and integrity checks as initial.
function Get-MedicalFormTemplateAsset($config){
 $schema=Copy-MedicalFormSchema $config
 $templateName=[IO.Path]::GetFileName(([string]$schema.Template).Replace('\','/'))
 if([string]::IsNullOrWhiteSpace($templateName)){$templateName='Мой шаблон.docx'}
 $templateName=Get-MedicalManagedTemplateName $templateName
 $temp=$null;$cacheKey='';$cached=$null
 try{
  if($schema.AutoTemplate){
   $templateName=[IO.Path]::ChangeExtension($templateName,'.docx')
   # Copy-MedicalFormSchema emits the allowlisted properties in a fixed order.
   # Include the namespace used by the Word generator, as well as all structure.
   $keyText=([string]$script:ns)+'|'+(ConvertTo-Json -InputObject $schema -Depth 50 -Compress)
   $cacheKey=Get-MedicalBytesSha256 ([Text.Encoding]::UTF8.GetBytes($keyText))
   $cached=Get-MedicalTemplateMemo 'auto-asset' $cacheKey
   if($cached){return [pscustomobject]@{TemplateName=$templateName;TemplateSha256=$cached.Hash;TemplateBase64=$cached.Base64}}
   $temp=Join-Path ([IO.Path]::GetTempPath()) ('mc67-stage-template-'+[guid]::NewGuid().ToString('N')+'.docx')
   New-UniversalTemplate $temp $schema;$bytes=[IO.File]::ReadAllBytes($temp)
  }else{
   $source=[string]$config.Template
   if(-not [IO.Path]::IsPathRooted($source)){$source=Join-Path $script:medicalProgramRoot ($source.Replace('\',[IO.Path]::DirectorySeparatorChar))}
   if(-not [IO.File]::Exists($source)){throw ('Связанный шаблон Word не найден: '+$source)}
   $bytes=[IO.File]::ReadAllBytes($source)
  }
  $contentHash=Get-MedicalBytesSha256 $bytes
  # Validation/Base64 are memoized by the bytes' hash, never by their filename.
  $cached=Get-MedicalTemplateMemo 'asset' $contentHash
  if(-not $cached){
   Test-MedicalTemplateBytes $bytes
   $cached=[pscustomobject]@{Hash=$contentHash;Base64=[Convert]::ToBase64String($bytes)}
   Set-MedicalTemplateMemo 'asset' $contentHash $cached ($cached.Base64.Length*2L)
  }
  # Auto entries share the immutable strings in the content entry; charge its
  # retained size too, so eviction of either entry never defeats the memory cap.
  if($cacheKey){Set-MedicalTemplateMemo 'auto-asset' $cacheKey $cached ($cached.Base64.Length*2L)}
  return [pscustomobject]@{TemplateName=$templateName;TemplateSha256=$cached.Hash;TemplateBase64=$cached.Base64}
 }finally{if($temp -and [IO.File]::Exists($temp)){[IO.File]::Delete($temp)}}
}
function Test-MedicalFormTemplateAsset($source){
 $templateName=Get-MedicalTemplateName ([string]$source.TemplateName)
 if([string]$source.TemplateSha256 -cnotmatch '^[a-fA-F0-9]{64}$'){throw 'В файле отсутствует корректная контрольная сумма Word-шаблона этапа.'}
 if($source.TemplateBase64 -isnot [string] -or [string]::IsNullOrWhiteSpace($source.TemplateBase64)){throw 'В файле отсутствует Word-шаблон этапа.'}
 try{$bytes=[Convert]::FromBase64String($source.TemplateBase64)}catch{throw 'Некорректное кодирование Word-шаблона этапа.'}
 if((Get-MedicalBytesSha256 $bytes) -ine [string]$source.TemplateSha256){throw 'Контрольная сумма Word-шаблона этапа не совпадает. Файл повреждён.'}
 Test-MedicalTemplateBytes $bytes
 return [pscustomobject]@{TemplateName=$templateName;Bytes=$bytes}
}

function Write-MedicalForm([string]$path,$config,[string]$name='',$stageForms=$null){
 Assert-MedicalFormPath $path
 $schema=Copy-MedicalFormSchema $config
 $templateName=[IO.Path]::GetFileName(([string]$schema.Template).Replace('\','/'))
 if([string]::IsNullOrWhiteSpace($templateName)){$templateName='Мой шаблон.docx'}
 $templateName=Get-MedicalManagedTemplateName $templateName
 if($schema.AutoTemplate){$templateName=[IO.Path]::ChangeExtension($templateName,'.docx')}
 $sourceTemp=$null;$writeTemp=$null
 try{
  $asset=Get-MedicalFormTemplateAsset $schema
  $templateName=$asset.TemplateName
  $schema.Template='Шаблоны/'+$templateName
  if([string]::IsNullOrWhiteSpace($name)){$name=[IO.Path]::GetFileNameWithoutExtension($path)}
  $name=Get-MedicalFormDisplayName $name 'Новая форма'
  $envelope=[pscustomobject]@{Format='MedicalConstructor.Form';Version=1;Name=$name;Schema=$schema;TemplateName=$templateName;TemplateSha256=$asset.TemplateSha256;TemplateBase64=$asset.TemplateBase64}
  if($null -eq $stageForms -and $script:medicalClinicalForms -and (Get-Command Get-MedicalClinicalFormData -CommandType Function -ErrorAction SilentlyContinue)){$stageForms=Get-MedicalClinicalFormData}
  if($null -ne $stageForms){
   if(-not (Get-Command Get-MedicalClinicalPortableForms -CommandType Function -ErrorAction SilentlyContinue)){throw 'Не загружена поддержка структуры дневников и эпикриза.'}
   $portable=Get-MedicalClinicalPortableForms $false $stageForms
   $envelope | Add-Member -NotePropertyName StageForms -NotePropertyValue $portable -Force
  }
  $destination=[IO.Path]::GetFullPath($path);$parent=[IO.Path]::GetDirectoryName($destination)
  if(-not [IO.Directory]::Exists($parent)){throw ('Папка для сохранения формы не найдена: '+$parent)}
  $writeTemp=Join-Path $parent ('.mc-form-'+[guid]::NewGuid().ToString('N')+'.tmp')
  [IO.File]::WriteAllText($writeTemp,($envelope | ConvertTo-Json -Depth 50),[Text.UTF8Encoding]::new($true))
  if([IO.File]::Exists($destination)){[IO.File]::Replace($writeTemp,$destination,($destination+'.bak'))}
  else{[IO.File]::Move($writeTemp,$destination)}
  $writeTemp=$null
  return $envelope
 }finally{
  if($sourceTemp -and [IO.File]::Exists($sourceTemp)){[IO.File]::Delete($sourceTemp)}
  if($writeTemp -and [IO.File]::Exists($writeTemp)){[IO.File]::Delete($writeTemp)}
 }
}

function Read-MedicalForm([string]$path){
 Assert-MedicalFormPath $path
 if(-not [IO.File]::Exists($path)){throw ('Файл формы не найден: '+$path)}
 try{$envelope=[IO.File]::ReadAllText($path,[Text.Encoding]::UTF8) | ConvertFrom-Json}
 catch{throw ('Не удалось прочитать файл формы: '+$_.Exception.Message)}
 if($null -eq $envelope -or $envelope.Format -cne 'MedicalConstructor.Form' -or $envelope.Version -ne 1){throw 'Неизвестный формат или версия файла формы.'}
 if($envelope.Name -isnot [string] -or [string]::IsNullOrWhiteSpace($envelope.Name)){throw 'В файле формы отсутствует название.'}
 $schema=Copy-MedicalFormSchema $envelope.Schema
 $templateName=Get-MedicalTemplateName ([string]$envelope.TemplateName)
 if([string]$envelope.TemplateSha256 -cnotmatch '^[a-fA-F0-9]{64}$'){throw 'В файле формы отсутствует корректная контрольная сумма шаблона.'}
 if($envelope.TemplateBase64 -isnot [string] -or [string]::IsNullOrWhiteSpace($envelope.TemplateBase64)){throw 'В файле формы отсутствует связанный шаблон Word.'}
 try{$bytes=[Convert]::FromBase64String($envelope.TemplateBase64)}
 catch{throw 'Связанный шаблон в файле формы имеет некорректное кодирование Base64.'}
 if((Get-MedicalBytesSha256 $bytes) -ine [string]$envelope.TemplateSha256){throw 'Контрольная сумма связанного шаблона не совпадает. Файл формы повреждён.'}
 Test-MedicalTemplateBytes $bytes
 $stageForms=$null
 if($null -ne $envelope.PSObject.Properties['StageForms']){
  if(-not (Get-Command Test-MedicalClinicalPortableForms -CommandType Function -ErrorAction SilentlyContinue)){throw 'Для этой формы нужна версия конструктора с поддержкой структуры дневников и эпикриза.'}
  Test-MedicalClinicalPortableForms $envelope.StageForms $true
 }
 # All validation above completes before any files or directories are created.
 $template=Import-MedicalTemplateBytes $bytes $templateName
 $schema.Template=$template.RelativePath
 if($null -ne $envelope.PSObject.Properties['StageForms']){$stageForms=Resolve-MedicalClinicalPortableForms $envelope.StageForms}
 $result=[pscustomobject]@{Format='MedicalConstructor.Form';Version=1;Name=(Get-MedicalFormDisplayName $envelope.Name ([IO.Path]::GetFileNameWithoutExtension($path)));Schema=$schema;TemplateName=$template.Name;TemplateSha256=(Get-MedicalBytesSha256 $bytes);TemplateBase64=[Convert]::ToBase64String($bytes)}
 if($null -ne $stageForms){$result | Add-Member -NotePropertyName StageForms -NotePropertyValue $stageForms -Force}
 return $result
}

function New-MedicalSchemaFromTemplate([string]$templatePath){
 $template=Import-MedicalTemplate $templatePath
 # Read Word metadata only. In particular, never use a control's saved Value.
 $wordFields=@(Get-UniversalWordFields $template.Path)
 $metadata=@{};foreach($field in $wordFields){if(-not $metadata.ContainsKey([string]$field.Id)){$metadata[[string]$field.Id]=$field}}
 $reserved=@('ADMISSION_DATE','ADMISSION_TIME','ADMISSION_DATETIME','DIAGNOSIS_CODE','PATIENT_SEX','TREATMENT_START_DATE','TREATMENT_END_DATE','DIARY_START_DATE','DIARY_END_DATE','DIARY_START_DATETIME','DIARY_END_DATETIME','DIARY_PERIOD')
 $records=@{};$order=New-Object System.Collections.ArrayList;$pending=New-Object System.Collections.ArrayList
 $archive=[IO.Compression.ZipFile]::OpenRead($template.Path)
 try{
  $parts=@('word/document.xml')+@($archive.Entries | Where-Object {$_.FullName -match '^word/(header|footer)[^/]*\.xml$'} | Sort-Object FullName | ForEach-Object {$_.FullName})
  foreach($part in $parts){
   $xml=Get-XmlPart $archive $part;if($null -eq $xml){continue};$xml.XmlResolver=$null
   $namespaces=[Xml.XmlNamespaceManager]::new($xml.NameTable);$namespaces.AddNamespace('w',$script:ns)
   foreach($paragraph in $xml.SelectNodes('//w:p',$namespaces)){
    $text=(($paragraph.SelectNodes('.//w:t',$namespaces) | Where-Object {[object]::ReferenceEquals($_.SelectSingleNode('ancestor::w:p[1]',$namespaces),$paragraph)} | ForEach-Object {$_.InnerText}) -join '')
    foreach($match in [regex]::Matches($text,'\{\{([A-Z][A-Z0-9_]*)\}\}')){
     $marker=$match.Groups[1].Value
     if($marker -in $reserved -or $records.ContainsKey($marker)){continue}
     $records[$marker]=[pscustomobject]@{Marker=$marker;WordId='';Label='';Options=@()};[void]$order.Add($marker)
    }
   }
   foreach($control in $xml.SelectNodes('//w:sdt',$namespaces)){
    $idNode=$control.SelectSingleNode('./w:sdtPr/w:id',$namespaces)
    $id=if($idNode){$idNode.GetAttribute('val',$script:ns)}else{''}
    $tagNode=$control.SelectSingleNode('./w:sdtPr/w:tag',$namespaces)
    $aliasNode=$control.SelectSingleNode('./w:sdtPr/w:alias',$namespaces)
    $tag=if($tagNode){$tagNode.GetAttribute('val',$script:ns)}else{''}
    $alias=if($aliasNode){$aliasNode.GetAttribute('val',$script:ns)}else{''}
    $marker=if($tag -cmatch '^[A-Z][A-Z0-9_]*$'){$tag}elseif($alias -cmatch '^[A-Z][A-Z0-9_]*$'){$alias}else{''}
    if($marker -in $reserved){continue}
    $label=if(-not [string]::IsNullOrWhiteSpace($alias)){$alias}elseif(-not [string]::IsNullOrWhiteSpace($tag)){$tag}elseif($metadata.ContainsKey($id)){$metadata[$id].Label}else{''}
    $options=@(foreach($item in $control.SelectNodes('./w:sdtPr/*/w:listItem',$namespaces)){
     $option=$item.GetAttribute('displayText',$script:ns);if(-not $option){$option=$item.GetAttribute('value',$script:ns)}
     if($option -and $option -ne 'Выберите элемент.'){$option}
    })
    $record=[pscustomobject]@{Marker=$marker;WordId=$id;Label=[string]$label;Options=$options}
    if(-not $marker){if($id){[void]$pending.Add($record)};continue}
    if(-not $records.ContainsKey($marker)){$records[$marker]=$record;[void]$order.Add($marker)}
    elseif(-not $records[$marker].WordId){$records[$marker]=$record}
   }
  }
 }finally{$archive.Dispose()}
 $number=0
 foreach($record in $pending){
  do{$number++;$marker='FIELD_'+$number}while($records.ContainsKey($marker))
  $record.Marker=$marker;if([string]::IsNullOrWhiteSpace($record.Label)){$record.Label='Поле шаблона '+$number}
  $records[$marker]=$record;[void]$order.Add($marker)
 }
 $defaults=New-UniversalConfig;$known=@{};$sections=@{};$sectionOrder=New-Object System.Collections.ArrayList
 foreach($section in $defaults.Sections){foreach($field in $section.Fields){$known[[string]$field.Marker]=[pscustomobject]@{Field=$field;Section=$section}}}
 $extra=[pscustomobject]@{Id='template_fields';Title='Поля шаблона';Fields=@()};$usedIds=@{};$usedWordIds=@{}
 foreach($marker in $order){
  $record=$records[[string]$marker]
  if($known.ContainsKey([string]$marker)){
   $definition=$known[[string]$marker];$field=Copy-UniversalObject $definition.Field
   $sectionId=[string]$definition.Section.Id
   if(-not $sections.ContainsKey($sectionId)){
    $sections[$sectionId]=[pscustomobject]@{Id=$sectionId;Title=[string]$definition.Section.Title;Fields=@()};[void]$sectionOrder.Add($sectionId)
   }
   $section=$sections[$sectionId]
  }else{
   $label=[string]$record.Label;if([string]::IsNullOrWhiteSpace($label)){$label=[string]$marker}
   $field=New-UniversalField ([guid]::NewGuid().ToString('N')) $label ([string]$marker) 'multiline'
   $section=$extra
  }
  if($usedIds.ContainsKey([string]$field.Id)){$field.Id=[guid]::NewGuid().ToString('N')};$usedIds[[string]$field.Id]=$true
  $field.WordId='';$field.Options=@()
  if($record.WordId -and -not $usedWordIds.ContainsKey([string]$record.WordId)){
   $field.WordId=[string]$record.WordId;$usedWordIds[$field.WordId]=$true
   if(@($record.Options).Count){$field.Type='choice';$field.Options=@($record.Options)}
  }
  $section.Fields+=@($field)
 }
 $result=[pscustomobject]@{Version=49;AutoTemplate=$false;Template=$template.RelativePath;Sections=@()}
 foreach($id in $sectionOrder){$result.Sections+=@($sections[[string]$id])}
 if($extra.Fields.Count -gt 0 -or $result.Sections.Count -eq 0){$result.Sections+=@($extra)}
 Assert-UniversalConfig $result
 return $result
}
