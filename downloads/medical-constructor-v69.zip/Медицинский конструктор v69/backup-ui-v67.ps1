﻿function Show-MedicalSessionCloseChoice($owner,[bool]$formDirty,[bool]$caseDirty,[string]$backupPath){
 $dialog=New-Object Windows.Forms.Form;$dialog.Text='Сохранить работу перед закрытием';$dialog.Size=New-Object Drawing.Size(780,325)
 $dialog.StartPosition='CenterParent';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false
 $hint=New-Object Windows.Forms.Label;$hint.SetBounds(20,20,730,110)
 $items=@();if($formDirty){$items+='структура формы и Word-шаблоны'};if($caseDirty){$items+='ответы пациента, дневники и эпикриз'}
 $hint.Text='Не сохранены: '+($items -join '; ')+".`r`nРезервная копия уже записана и проверена. «Сохранить и закрыть» сохраняет изменения в обычные файлы формы и карты. «Закрыть с резервной копией» позволит восстановить работу при следующем запуске."
 $dialog.Controls.Add($hint)
 $location=New-Object Windows.Forms.Label;$location.SetBounds(20,138,730,52);$location.Text='Резервная копия: '+$backupPath;$dialog.Controls.Add($location)
 $result=[pscustomobject]@{Choice='Cancel'}
 $save=New-Object Windows.Forms.Button;$save.Text='Сохранить и закрыть';$save.SetBounds(20,211,225,42);$dialog.Controls.Add($save)
 $backup=New-Object Windows.Forms.Button;$backup.Text='Закрыть с резервной копией';$backup.SetBounds(260,211,265,42);$dialog.Controls.Add($backup)
 $cancel=New-Object Windows.Forms.Button;$cancel.Text='Продолжить работу';$cancel.SetBounds(540,211,210,42);$cancel.DialogResult='Cancel';$dialog.CancelButton=$cancel;$dialog.Controls.Add($cancel)
 $save.Add_Click({$result.Choice='Save';$dialog.DialogResult='OK';$dialog.Close()}.GetNewClosure())
 $backup.Add_Click({$result.Choice='Backup';$dialog.DialogResult='OK';$dialog.Close()}.GetNewClosure())
 Set-DarkTheme $dialog
 try{[void]$dialog.ShowDialog($owner);return $result.Choice}finally{$dialog.Dispose()}
}
function Confirm-MedicalSessionClose($owner,[string]$reason='UserClosing'){
 if(-not $script:medicalWorkspaceReady -and -not $script:medicalBackupEditorDraft -and -not $script:medicalBackupRetainedDraft){return $true}
 $shutdown=$reason -in @('WindowsShutDown','TaskManagerClosing')
 try{$checkpoint=Write-MedicalSessionBackup}
 catch{
  if($shutdown){return $true}
  [void][Windows.Forms.MessageBox]::Show($owner,'Не удалось записать резервную копию. Программа остаётся открытой: '+$_.Exception.Message,'Резервное сохранение','OK','Warning')
  return $false
 }
 if($shutdown){return $true}
 $payload=$checkpoint.Payload
 $formDirty=([string]$payload.FormSignature -cne [string]$script:medicalBackupFormSavedSignature)
 $caseDirty=$script:medicalWorkspaceReady -and ([string]$payload.CaseSignature -cne [string]$script:medicalBackupCaseSavedSignature)
 if($checkpoint.Payload.Data.EditorDraft){$formDirty=$true}
 if(-not $formDirty -and -not $caseDirty){
  try{[void](Write-MedicalSessionBackup $true);return $true}catch{[void][Windows.Forms.MessageBox]::Show($owner,$_.Exception.Message,'Резервное сохранение');return $false}
 }
 $choice=Show-MedicalSessionCloseChoice $owner $formDirty $caseDirty $checkpoint.Path
 if($choice -eq 'Cancel'){return $false}
 if($choice -eq 'Backup'){return $true}
 if($choice -ne 'Save'){return $false}
 if($checkpoint.Payload.Data.EditorDraft){
  [void][Windows.Forms.MessageBox]::Show($owner,'Сначала примените изменения в редакторе формы и Word или закройте программу с резервной копией.','Незавершённый редактор','OK','Information')
  return $false
 }
 try{
  # The ordinary save actions can return after a canceled picker. Only the
  # success hooks may update the saved signatures checked below.
  if($formDirty){
   $saveForm=Get-Command Invoke-MedicalSaveForm -CommandType Function -ErrorAction Stop
   & $saveForm | Out-Null
   $next=Write-MedicalSessionBackup
   if([string]$next.Payload.FormSignature -cne [string]$script:medicalBackupFormSavedSignature -or -not [IO.File]::Exists([string]$script:activeMedicalFormPath)){return $false}
  }
  if($caseDirty){
   $saveCase=Get-Command Save-Case -CommandType Function -ErrorAction Stop
   & $saveCase | Out-Null
   $next=Write-MedicalSessionBackup
   if([string]$next.Payload.CaseSignature -cne [string]$script:medicalBackupCaseSavedSignature -or -not [IO.File]::Exists([string]$script:caseFile)){return $false}
  }
  [void](Write-MedicalSessionBackup $true)
  return $true
 }catch{
  [void][Windows.Forms.MessageBox]::Show($owner,'Сохранение не завершено. Программа остаётся открытой: '+$_.Exception.Message,'Закрытие программы','OK','Warning')
  return $false
 }
}
function Show-MedicalBackupRecoveryChoice($owner,$backup){
 $dialog=New-Object Windows.Forms.Form;$dialog.Text='Восстановление сохранённой работы';$dialog.Size=New-Object Drawing.Size(780,345)
 $dialog.StartPosition='CenterParent';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false
 $hint=New-Object Windows.Forms.Label;$hint.SetBounds(20,20,730,125)
 $name=[string]$backup.Payload.Data.Form.Name
 $hint.Text='Найдена незавершённая работа: '+$name+".`r`nКопия содержит структуру формы, Word-шаблоны, ответы пациента, дневники и эпикриз. Восстановление вернёт их в рабочее окно. При начале новой работы эта копия останется в папке «Резервные копии»."
 if($backup.Payload.Data.EditorDraft){$hint.Text+="`r`nВ копии есть незавершённые изменения редактора формы и Word."}
 $dialog.Controls.Add($hint)
 $path=New-Object Windows.Forms.Label;$path.SetBounds(20,152,730,52);$path.Text=$backup.Path;$dialog.Controls.Add($path)
 $result=[pscustomobject]@{Choice='Later'}
 $restore=New-Object Windows.Forms.Button;$restore.Text='Восстановить работу';$restore.SetBounds(20,231,220,42);$dialog.Controls.Add($restore)
 $new=New-Object Windows.Forms.Button;$new.Text='Начать новую';$new.SetBounds(255,231,220,42);$dialog.Controls.Add($new)
 $later=New-Object Windows.Forms.Button;$later.Text='Решить позже';$later.SetBounds(490,231,260,42);$later.DialogResult='Cancel';$dialog.CancelButton=$later;$dialog.Controls.Add($later)
 $restore.Add_Click({$result.Choice='Restore';$dialog.DialogResult='OK';$dialog.Close()}.GetNewClosure())
 $new.Add_Click({$result.Choice='New';$dialog.DialogResult='OK';$dialog.Close()}.GetNewClosure())
 Set-DarkTheme $dialog
 try{[void]$dialog.ShowDialog($owner);return $result.Choice}finally{$dialog.Dispose()}
}
function Start-MedicalBackupRecovery($owner){
 try{
  [void](Initialize-MedicalSessionBackup)
  $pending=Get-MedicalPendingBackup
  if(-not $pending){return 'New'}
  $choice=Show-MedicalBackupRecoveryChoice $owner $pending
  if($choice -eq 'Later'){$script:medicalBackupPendingDeferred=$true;return 'Later'}
  if($choice -eq 'New'){Archive-MedicalPendingBackup;$script:medicalBackupPendingDeferred=$false;return 'New'}
  if($choice -eq 'Restore'){
   [void](Restore-MedicalSessionBackup $pending)
   $script:medicalBackupPendingDeferred=$false
   return 'Restored'
  }
  return 'Later'
 }catch{
  [void][Windows.Forms.MessageBox]::Show($owner,'Восстановление не завершено. Резервные файлы сохранены: '+$_.Exception.Message,'Резервная копия','OK','Warning')
  return 'Later'
 }
}
