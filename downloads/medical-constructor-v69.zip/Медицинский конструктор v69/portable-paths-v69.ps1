﻿# Save destinations are session preferences; documents and templates remain embedded.
# A moved program must never silently write back into a previous installation.
function Get-MedicalPortableProperty($value,[string]$name){
 if($null -eq $value){return $null}
 if($value -is [Collections.IDictionary]){return $value[$name]}
 return $value.$name
}
function Get-MedicalPortableFullPath([string]$path){
 if([string]::IsNullOrWhiteSpace($path)){return ''}
 try{return [IO.Path]::GetFullPath($path)}catch{return ''}
}
function Test-MedicalPortablePathInside([string]$path,[string]$root){
 $full=Get-MedicalPortableFullPath $path;$base=Get-MedicalPortableFullPath $root
 if(-not $full -or -not $base){return $false}
 $base=$base.TrimEnd([char[]]@([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar))
 return ($full.Equals($base,[StringComparison]::OrdinalIgnoreCase) -or $full.StartsWith(($base+[IO.Path]::DirectorySeparatorChar),[StringComparison]::OrdinalIgnoreCase))
}
function Get-MedicalPortableRelativePath([string]$path,[string]$root){
 if(-not (Test-MedicalPortablePathInside $path $root)){return ''}
 $full=Get-MedicalPortableFullPath $path
 $base=(Get-MedicalPortableFullPath $root).TrimEnd([char[]]@([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar))
 if($full.TrimEnd([char[]]@([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar)).Equals($base,[StringComparison]::OrdinalIgnoreCase)){return '.'}
 return $full.Substring($base.Length+1).Replace('\','/')
}
function Resolve-MedicalPortableRelativePath([string]$relative,[string]$root,[bool]$directory=$false){
 if([string]::IsNullOrWhiteSpace($relative)){return ''}
 # Explicitly reject Windows roots too when verification runs on another OS.
 if([IO.Path]::IsPathRooted($relative) -or $relative -match '^[A-Za-z]:' -or $relative -match '^[\\/]'){return ''}
 if(@($relative -split '[\\/]' | Where-Object {$_ -eq '..'}).Count){return ''}
 $local=$relative.Replace('\',[IO.Path]::DirectorySeparatorChar).Replace('/',[IO.Path]::DirectorySeparatorChar)
 $candidate=Get-MedicalPortableFullPath (Join-Path $root $local)
 if(-not (Test-MedicalPortablePathInside $candidate $root)){return ''}
 if($directory){if([IO.Directory]::Exists($candidate)){return $candidate}}
 elseif([IO.File]::Exists($candidate)){return $candidate}
 return ''
}
function Get-MedicalPortableSessionLocation {
 return [pscustomobject]@{
  Version=1;ProgramRoot=(Get-MedicalPortableFullPath $script:medicalProgramRoot)
  FormRelative=(Get-MedicalPortableRelativePath ([string]$script:activeMedicalFormPath) $script:medicalProgramRoot)
  CaseRelative=(Get-MedicalPortableRelativePath ([string]$script:caseFile) $script:medicalProgramRoot)
  FolderRelative=(Get-MedicalPortableRelativePath ([string]$script:caseFolder) $script:medicalProgramRoot)
 }
}
function Resolve-MedicalPortableSessionPath([string]$path,[string]$relative,$location,[bool]$directory=$false){
 $root=Get-MedicalPortableFullPath $script:medicalProgramRoot
 $previousRoot=Get-MedicalPortableFullPath ([string](Get-MedicalPortableProperty $location 'ProgramRoot'))
 $sameRoot=$previousRoot -and $root -and $previousRoot.TrimEnd('\','/').Equals($root.TrimEnd('\','/'),[StringComparison]::OrdinalIgnoreCase)
 # New checkpoints map exact local relative paths after a folder/drive move.
 if($location -and -not $sameRoot){return Resolve-MedicalPortableRelativePath $relative $root $directory}
 $full=Get-MedicalPortableFullPath $path
 # Older checkpoints carry no provenance. Keep only destinations already in this
 # installation; matching a basename alone could select another patient's file.
 if(-not $sameRoot -and -not (Test-MedicalPortablePathInside $full $root)){return ''}
 if($directory){if([IO.Directory]::Exists($full)){return $full}}
 elseif([IO.File]::Exists($full)){return $full}
 return ''
}
function Restore-MedicalPortableSessionLocation($data){
 $location=Get-MedicalPortableProperty $data 'Location'
 $form=Get-MedicalPortableProperty $data 'Form';$case=Get-MedicalPortableProperty $data 'Case'
 $script:activeMedicalFormPath=Resolve-MedicalPortableSessionPath ([string](Get-MedicalPortableProperty $form 'Path')) ([string](Get-MedicalPortableProperty $location 'FormRelative')) $location
 $script:caseFile=Resolve-MedicalPortableSessionPath ([string](Get-MedicalPortableProperty $case 'Path')) ([string](Get-MedicalPortableProperty $location 'CaseRelative')) $location
 $script:caseFolder=Resolve-MedicalPortableSessionPath ([string](Get-MedicalPortableProperty $case 'Folder')) ([string](Get-MedicalPortableProperty $location 'FolderRelative')) $location $true
 if($script:caseFile){$script:caseFolder=[IO.Path]::GetDirectoryName($script:caseFile)}
 else{$script:caseLastSavedPatientName=$null}
}
function Get-MedicalPortableSaveDirectory([string]$path,[string]$default=$script:medicalProgramRoot){
 $full=Get-MedicalPortableFullPath $path
 if($full){$parent=[IO.Path]::GetDirectoryName($full);if($parent -and [IO.Directory]::Exists($parent)){return $parent}}
 return (Get-MedicalPortableFullPath $default)
}
