﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v69'))
$ErrorActionPreference='Stop'
$script:checks=0
function Assert-Check([bool]$condition,[string]$message){
 if(-not $condition){throw $message}
 $script:checks++;Write-Output ('PASS '+$message)
}
function Assert-Rejected([scriptblock]$operation,[string]$message){
 $rejected=$false
 try{& $operation | Out-Null}catch{$rejected=$true}
 Assert-Check $rejected $message
}
function Import-TestFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null
 $ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors | Out-String)}
 foreach($node in $ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
  if($names.Count -eq 0 -or $node.Name -in $names){
   . ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))
  }
 }
}
function Set-TestProperty($object,[string]$name,$value){$object | Add-Member -NotePropertyName $name -NotePropertyValue $value -Force}
function Set-TestRuntimeRoot([string]$root){
 $script:medicalProgramRoot=$root
 $script:medicalTemplatesFolder=Join-Path $root 'Шаблоны'
}
function Get-TestHash([byte[]]$bytes){
 $hash=[Security.Cryptography.SHA256]::Create()
 try{return ([BitConverter]::ToString($hash.ComputeHash($bytes))).Replace('-','').ToLowerInvariant()}finally{$hash.Dispose()}
}
function Get-TestTree([string]$root){
 if(-not (Test-Path -LiteralPath $root)){return '<missing>'}
 return (@(Get-ChildItem -LiteralPath $root -Force -Recurse | Sort-Object FullName | ForEach-Object {
  $relative=$_.FullName.Substring($root.Length)
  if($_.PSIsContainer){'D '+$relative}else{'F '+$relative+' '+(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash}
 }) -join "`n")
}
function New-TestFormConfig([string]$template='',[bool]$automatic=$false){
 # v49 is still the schema version. The feature version must not break saved forms.
 $fields=@(
  [pscustomobject]@{Id='name';Label='Ф.И.О.';Marker='PATIENT_NAME';Type='text';System='name';WordId='';Options=@();Required=$true},
  [pscustomobject]@{Id='notes';Label='Примечания';Marker='NOTES';Type='multiline';System='';WordId='';Options=@();Required=$false}
 )
 $index=0
 foreach($position in @('after','before','newline','marker')){
  $index++
  $fields+=[pscustomobject]@{Id=('choice'+$index);Label=('Уточнение '+$index);Marker=('CHOICE_'+$index);Type='choice_detail';System='';WordId='';Options=@('Первый & <вариант>','Второй вариант');Required=$true;DetailFormPosition=@('above','below','right','above')[$index-1];DetailWordPosition=$position;DetailMarker=$(if($position -eq 'marker'){'DETAIL_TEXT'}else{''})}
 }
 return [pscustomobject]@{Version=49;AutoTemplate=$automatic;Template=$template;ProfileCode='A00';ProfileSex='F';Sections=@([pscustomobject]@{Id='exam';Title='Проверочный осмотр';Fields=$fields})}
}
function Set-TestZipPart([string]$path,[string]$name,[string]$content){
 $zip=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{
  $entry=$zip.GetEntry($name);if($entry){$entry.Delete()}
  Write-UniversalZipText $zip $name $content
 }finally{$zip.Dispose()}
}
function Get-TestZipPart([string]$path,[string]$name){
 $zip=[IO.Compression.ZipFile]::OpenRead($path)
 try{return (Get-XmlPart $zip $name)}finally{$zip.Dispose()}
}
function Write-TestEnvelope([string]$path,$envelope){[IO.File]::WriteAllText($path,($envelope | ConvertTo-Json -Depth 50),[Text.UTF8Encoding]::new($true))}
function Set-TestPopulatedCase($config){
 $script:universalConfig=Copy-UniversalObject $config
 foreach($name in @('universalValues','universalDetails','universalInputs','universalDetailInputs','universalMultiInputs','universalRepeatInputs')){
  Set-Variable -Scope Script -Name $name -Value @{old='Предыдущий пациент'}
 }
 $script:universalWordFields=@([pscustomobject]@{Id='old-word-field'})
 $script:stageTemplates=@{initial='old-initial.docx';diary='old-diary.docx';discharge='old-discharge.docx'}
 $script:stageData=@{initial=@('Старый осмотр');diary_1=@('Старый дневник')};$script:initialByLabel=@{old='Старое значение'}
 $script:currentPatient=77;$script:pendingDocument='old-output.docx';$script:source='old-source.docx';$script:fields=@('old-field');$script:controls=@([pscustomobject]@{Text='Старый ответ'})
 $script:caseFolder='old-case-folder';$script:caseFile='old-case.docx';$script:diaryIndex=8;$script:diaryRecords=@('old-diary');$script:stage='discharge'
 foreach($name in @('patientName','patientBirthYear','patientAddress','addressBase','addressStreet','addressHouse','addressApartment')){Set-Variable -Scope Script -Name $name -Value 'Предыдущий пациент'}
 foreach($name in @('patientNameControl','patientBirthControl','patientAddressControl','streetControl','houseControl','apartmentControl')){
  Set-Variable -Scope Script -Name $name -Value ([pscustomobject]@{Text='Предыдущий пациент'})
 }
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2020-01-01T01:00:00'}
 # Real hospital widgets require Windows; these checks exercise all non-widget state.
 $script:hospitalControls=@{}
}

$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-v59-forms-test-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
try{
 # Execute actual data functions, not a mocked GUI or a separate reimplementation.
 Import-TestFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
 Import-TestFunctions (Join-Path $Project 'universal.ps1')
 Import-TestFunctions (Join-Path $Project 'workspace-settings.ps1') @('Load-DocumentFont','Set-DocumentFontXml','Apply-DocumentFont')
 Import-TestFunctions (Join-Path $Project 'forms-v59.ps1')
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 $script:fontFile=Join-Path $Project 'document-font.json'
 $script:universalValues=@{name='НЕ СОХРАНЯТЬ ПАЦИЕНТА'}
 $script:universalDetails=@{choice1='НЕ СОХРАНЯТЬ УТОЧНЕНИЕ'}
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-13T12:30:00'}
 $sourceRoot=Join-Path $temp 'source'
 [void][IO.Directory]::CreateDirectory($sourceRoot)
 $source=Join-Path $sourceRoot 'Мой шаблон.docx'
 $config=New-TestFormConfig $source
 New-UniversalTemplate $source $config
 $customXml=Get-TestZipPart $source 'word/document.xml'
 Set-TestZipPart $source 'word/document.xml' ($customXml.OuterXml.Replace('Первичный осмотр','Индивидуальный осмотр — сохранить оформление'))
 $sourceBytes=[IO.File]::ReadAllBytes($source)
 $sourceHash=Get-TestHash $sourceBytes
 Assert-Check (@(Test-MedicalTemplateBytes $sourceBytes).Count -eq 0) 'Valid DOCX validation emits no pipeline data'

 $rootA=Join-Path $temp 'program-a';Set-TestRuntimeRoot $rootA
 Assert-Check (-not (Test-Path -LiteralPath $script:medicalTemplatesFolder)) 'Fixture begins without a template directory'
 $created=Initialize-MedicalTemplateFolder
 Assert-Check ((Test-Path -LiteralPath $created -PathType Container) -and $created -eq $script:medicalTemplatesFolder) 'Missing managed template folder is created and returned'
 Assert-Check (@(Get-MedicalTemplates).Count -eq 0) 'New managed template folder enumerates empty'
 Assert-Check ((Initialize-MedicalTemplateFolder) -eq $created) 'Folder initialization is repeatable'

 $managed=Import-MedicalTemplate $source
 Assert-Check ($managed.Name -eq 'Мой шаблон.docx' -and (Test-Path -LiteralPath $managed.Path -PathType Leaf)) 'Import preserves a usable Unicode filename'
 Assert-Check ((Get-TestHash ([IO.File]::ReadAllBytes($managed.Path))) -eq $sourceHash) 'Import preserves exact Word bytes and formatting'
 Assert-Check ($managed.RelativePath -eq ('Шаблоны/'+$managed.Name)) 'Import returns a portable relative template path'
 $tree=Get-TestTree $rootA
 $repeated=Import-MedicalTemplate $source
 Assert-Check ($repeated.Path -eq $managed.Path -and (Get-TestTree $rootA) -eq $tree) 'Identical import deduplicates without creating files'
 $alreadyManaged=Import-MedicalTemplate $managed.Path
 Assert-Check ($alreadyManaged.Path -eq $managed.Path -and (Get-TestTree $rootA) -eq $tree) 'Reimporting a managed template does not overwrite itself'

 $otherRoot=Join-Path $temp 'another-source';[void][IO.Directory]::CreateDirectory($otherRoot)
 $collisionSource=Join-Path $otherRoot 'Мой шаблон.docx'
 Copy-Item -LiteralPath $source -Destination $collisionSource
 Set-TestZipPart $collisionSource 'word/document.xml' ($customXml.OuterXml.Replace('Первичный осмотр','Другой текст и другое оформление'))
 $collision=Import-MedicalTemplate $collisionSource
 Assert-Check ($collision.Path -ne $managed.Path -and $collision.Name -ne $managed.Name) 'Different bytes with the same filename receive a distinct managed name'
 Assert-Check ((Get-TestHash ([IO.File]::ReadAllBytes($managed.Path))) -eq $sourceHash) 'Filename collision leaves the original template intact'
 Assert-Check ((Get-TestHash ([IO.File]::ReadAllBytes($collision.Path))) -eq (Get-TestHash ([IO.File]::ReadAllBytes($collisionSource)))) 'Collision import retains the second template exactly'
 $collisionTree=Get-TestTree $rootA
 Assert-Check ((Import-MedicalTemplate $collisionSource).Path -eq $collision.Path -and (Get-TestTree $rootA) -eq $collisionTree) 'Collision naming is stable on repeat imports'
 $dotxSource=Join-Path $sourceRoot 'Бланк.dotx';Copy-Item -LiteralPath $source -Destination $dotxSource
 $dotx=Import-MedicalTemplate $dotxSource
 [IO.File]::WriteAllText((Join-Path $script:medicalTemplatesFolder 'Прочитайте.txt'),'Ignored helper')
 [void][IO.Directory]::CreateDirectory((Join-Path $script:medicalTemplatesFolder 'Папка.docx'))
 $available=@(Get-MedicalTemplates)
 Assert-Check ($available.Count -eq 3 -and @($available | Where-Object {$_.Name -eq 'Прочитайте.txt' -or $_.Name -eq 'Папка.docx'}).Count -eq 0) 'Template catalog includes DOCX and DOTX files, excluding helpers and directories'
 Assert-Check (@($available | Where-Object {$_.Path -eq $dotx.Path}).Count -eq 1) 'DOTX appears in the template catalog'

 # Invalid imports must fail before any managed directory is changed.
 $bad=Join-Path $sourceRoot 'broken.docx';[IO.File]::WriteAllText($bad,'not a ZIP archive')
 $unsupported=Join-Path $sourceRoot 'template.txt';Copy-Item -LiteralPath $source -Destination $unsupported
 $invalidXml=Join-Path $sourceRoot 'invalid-xml.docx';Copy-Item -LiteralPath $source -Destination $invalidXml
 Set-TestZipPart $invalidXml 'word/document.xml' '<w:document'
 $wrongNamespace=Join-Path $sourceRoot 'wrong-namespace.docx';Copy-Item -LiteralPath $source -Destination $wrongNamespace
 Set-TestZipPart $wrongNamespace 'word/document.xml' '<document xmlns="urn:not-word"><body/></document>'
 $missingPart=Join-Path $sourceRoot 'missing-document.docx';Copy-Item -LiteralPath $source -Destination $missingPart
 $zip=[IO.Compression.ZipFile]::Open($missingPart,[IO.Compression.ZipArchiveMode]::Update)
 try{$zip.GetEntry('word/document.xml').Delete()}finally{$zip.Dispose()}
 $brokenHeader=Join-Path $sourceRoot 'invalid-header.docx';Copy-Item -LiteralPath $source -Destination $brokenHeader
 Set-TestZipPart $brokenHeader 'word/header1.xml' '<w:hdr'
 $dtdHeader=Join-Path $sourceRoot 'dtd-header.docx';Copy-Item -LiteralPath $source -Destination $dtdHeader
 Set-TestZipPart $dtdHeader 'word/header1.xml' ('<!DOCTYPE w:hdr [<!ENTITY harmless "n">]><w:hdr xmlns:w="'+$script:ns+'"><w:p><w:r><w:t>&harmless;</w:t></w:r></w:p></w:hdr>')
 foreach($invalid in @($bad,$unsupported,$invalidXml,$wrongNamespace,$missingPart,$brokenHeader,$dtdHeader,(Join-Path $temp 'not-present.docx'))){
  $before=Get-TestTree $rootA
  Assert-Rejected {Import-MedicalTemplate $invalid} ('Reject invalid import: '+[IO.Path]::GetFileName($invalid))
  Assert-Check ((Get-TestTree $rootA) -eq $before) ('Rejected import leaves managed files unchanged: '+[IO.Path]::GetFileName($invalid))
 }
 $emptyRoot=Join-Path $temp 'invalid-import-root';Set-TestRuntimeRoot $emptyRoot
 Assert-Rejected {Import-MedicalTemplate $bad} 'Invalid import cannot initialize a missing program directory'
 Assert-Check (-not (Test-Path -LiteralPath $emptyRoot)) 'Invalid import leaves missing directory absent'

 Set-TestRuntimeRoot $rootA
 $configBefore=$config | ConvertTo-Json -Depth 50
 $formPath=Join-Path $temp 'Переносимая форма.mcform'
 [void](Write-MedicalForm $formPath $config 'Мой осмотр')
 $saved=Get-Content -LiteralPath $formPath -Raw -Encoding UTF8 | ConvertFrom-Json
 Assert-Check ($saved.Format -ceq 'MedicalConstructor.Form' -and $saved.Version -eq 1 -and $saved.Name -ceq 'Мой осмотр') 'Saved form contains a versioned named envelope'
 Assert-Check ($saved.Schema.Version -eq 49) 'Saved form retains the compatible v49 schema version'
 Assert-Check (($config | ConvertTo-Json -Depth 50) -ceq $configBefore) 'Saving never mutates the supplied configuration'
 Assert-Check ((Get-TestHash ([Convert]::FromBase64String($saved.TemplateBase64))) -eq $sourceHash -and $saved.TemplateSha256.ToLowerInvariant() -eq $sourceHash) 'Saved form embeds the exact associated Word template and checksum'
 Assert-Check ($saved.TemplateName -ceq 'Мой шаблон.docx') 'Saved form retains the template filename'
 Assert-Check ($saved.Schema.ProfileCode -eq 'A00' -and $saved.Schema.ProfileSex -eq 'F') 'Saved form retains profile defaults'
 Assert-Check ($saved.Schema.Sections[0].Fields[0].System -eq 'name' -and $saved.Schema.Sections[0].Fields[1].Required -eq $false) 'Saved structure retains patient role and optional fields'
 foreach($id in 1..4){
  $original=$config.Sections[0].Fields[$id+1];$restored=$saved.Schema.Sections[0].Fields[$id+1]
  Assert-Check ($restored.DetailFormPosition -ceq $original.DetailFormPosition -and $restored.DetailWordPosition -ceq $original.DetailWordPosition -and $restored.DetailMarker -ceq $original.DetailMarker -and ($restored.Options -join '|') -ceq ($original.Options -join '|')) ('Saved structure retains clarification layout and Unicode choices: '+$id)
 }
 $rawForm=Get-Content -LiteralPath $formPath -Raw -Encoding UTF8
 Assert-Check (-not ($rawForm -match 'НЕ СОХРАНЯТЬ|2026-10-13|"(Values|Details|AdmissionDateTime|State)"\s*:')) 'Saved form omits patient answers, clarification text and admission time'
 # Deliberately contaminated input checks schema-only serialization, not just top-level omissions.
 $contaminated=Copy-UniversalObject $config
 foreach($pair in @(@('Values',@{name='PRIVATE ANSWER'}),@('Details',@{choice1='PRIVATE DETAIL'}),@('AdmissionDateTime','PRIVATE TIME'),@('State','PRIVATE STATE'))){Set-TestProperty $contaminated $pair[0] $pair[1]}
 Set-TestProperty $contaminated.Sections[0].Fields[0] 'Value' 'PRIVATE FIELD'
 $contaminatedBefore=$contaminated | ConvertTo-Json -Depth 50
 $cleanForm=Join-Path $temp 'clean.mcform';[void](Write-MedicalForm $cleanForm $contaminated)
 Assert-Check (-not ([IO.File]::ReadAllText($cleanForm) -match 'PRIVATE|"(Values|Details|AdmissionDateTime|State|Value)"\s*:')) 'Schema allowlist excludes accidental runtime and per-field answer properties'
 Assert-Check (($contaminated | ConvertTo-Json -Depth 50) -ceq $contaminatedBefore) 'Filtering runtime properties preserves the input object'

 # A filled program document is a patient record, even when its visible layout looks like a template.
 $recordConfig=Copy-UniversalObject $config;$recordConfig.AutoTemplate=$true
 $recordValues=@{};$recordDetails=@{}
 foreach($field in Get-UniversalFields $recordConfig){
  $recordValues[$field.Id]=$(if($field.Type -eq 'choice_detail'){$field.Options[0]}else{'Проверочный ответ пациента'})
  if($field.Type -eq 'choice_detail'){$recordDetails[$field.Id]='Проверочное уточнение пациента'}
 }
 $filledDocument=Join-Path $temp 'Заполненный осмотр.docx'
 Save-UniversalDocument $filledDocument $recordConfig $recordValues ([datetime]'2026-10-13T12:30:00') $recordDetails
 $recordState=Read-UniversalDocumentState $filledDocument
 Assert-Check ($recordState.Values.name -eq 'Проверочный ответ пациента') 'Filled-record fixture uses actual application export and hidden patient state'
 $caseDocument=Join-Path $temp 'Карта пациента.docx';New-UniversalTemplate $caseDocument $config
 $casePayload=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes('{"Version":24,"PatientName":"Проверочный пациент","Diaries":[]}'))
 $caseXml='<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="'+$script:ns+'"><w:body><w:p><w:r><w:t>Карта пациента</w:t></w:r></w:p><w:p><w:r><w:rPr><w:vanish/></w:rPr><w:t>MC_CASE_</w:t></w:r><w:r><w:rPr><w:vanish/></w:rPr><w:t>V24:'+$casePayload+':END_MC_CASE</w:t></w:r></w:p><w:sectPr/></w:body></w:document>'
 Set-TestZipPart $caseDocument 'word/document.xml' $caseXml
 foreach($recordDocument in @($filledDocument,$caseDocument)){
  $fixtureName=[IO.Path]::GetFileName($recordDocument)
  $before=Get-TestTree $rootA;$existingFormHash=(Get-FileHash -LiteralPath $formPath -Algorithm SHA256).Hash
  Assert-Rejected {Import-MedicalTemplate $recordDocument} ('Filled patient record cannot be imported as reusable Word template: '+$fixtureName)
  Assert-Check ((Get-TestTree $rootA) -eq $before) ('Rejected patient record import leaves managed templates unchanged: '+$fixtureName)
  $patientConfig=Copy-UniversalObject $config;$patientConfig.Template=$recordDocument
  Assert-Rejected {Write-MedicalForm $formPath $patientConfig} ('Reusable form cannot embed a filled patient document: '+$fixtureName)
  Assert-Check ((Get-FileHash -LiteralPath $formPath -Algorithm SHA256).Hash -eq $existingFormHash -and (Get-TestTree $rootA) -eq $before) ('Rejected patient-record form save preserves the existing form and templates: '+$fixtureName)
  $embeddedRecord=Copy-UniversalObject $saved;$recordBytes=[IO.File]::ReadAllBytes($recordDocument)
  $embeddedRecord.TemplateName=$fixtureName;$embeddedRecord.TemplateBase64=[Convert]::ToBase64String($recordBytes);$embeddedRecord.TemplateSha256=Get-TestHash $recordBytes
  $unsafeForm=Join-Path $temp ($fixtureName+'.mcform');Write-TestEnvelope $unsafeForm $embeddedRecord
  Assert-Rejected {Read-MedicalForm $unsafeForm} ('Opening a form rejects embedded patient state even with a correct checksum: '+$fixtureName)
  Assert-Check ((Get-TestTree $rootA) -eq $before) ('Rejected embedded patient state leaves managed templates unchanged: '+$fixtureName)
  $missingRecordRoot=Join-Path $temp ('missing-record-'+[guid]::NewGuid().ToString('N'));Set-TestRuntimeRoot $missingRecordRoot
  Assert-Rejected {Import-MedicalTemplate $recordDocument} ('Patient record is rejected before missing template-folder initialization: '+$fixtureName)
  Assert-Check (-not (Test-Path -LiteralPath $missingRecordRoot)) ('Rejected patient document cannot create a program directory: '+$fixtureName)
  Set-TestRuntimeRoot $rootA
 }
 $staticDocument=Join-Path $temp 'Статический текст.docx';New-UniversalTemplate $staticDocument $config
 $staticXml=Get-TestZipPart $staticDocument 'word/document.xml'
 Set-TestZipPart $staticDocument 'word/document.xml' ($staticXml.OuterXml.Replace('Первичный осмотр','Пациент обследован врачом. Обычный постоянный текст шаблона.'))
 $staticTemplate=Import-MedicalTemplate $staticDocument
 Assert-Check ((Get-FileHash -LiteralPath $staticTemplate.Path -Algorithm SHA256).Hash -eq (Get-FileHash -LiteralPath $staticDocument -Algorithm SHA256).Hash) 'Ordinary static Word text remains accepted and unchanged'

 # Older fields have no clarification-layout properties; loading must retain defaults.
 $legacy=Copy-UniversalObject $config
 foreach($field in @($legacy.Sections[0].Fields | Where-Object {$_.Type -eq 'choice_detail'})){
  foreach($property in @('DetailFormPosition','DetailWordPosition','DetailMarker')){$field.PSObject.Properties.Remove($property)}
 }
 $legacyForm=Join-Path $temp 'legacy-v49.mcform';[void](Write-MedicalForm $legacyForm $legacy)
 $openedLegacy=Read-MedicalForm $legacyForm
 Assert-Check ($openedLegacy.Schema.Version -eq 49 -and (Get-UniversalDetailFormPosition $openedLegacy.Schema.Sections[0].Fields[2]) -eq 'below' -and (Get-UniversalDetailWordPosition $openedLegacy.Schema.Sections[0].Fields[2]) -eq 'after') 'Legacy v49 fields without layout properties preserve existing defaults'
 Assert-Check ($null -eq $openedLegacy.Schema.Sections[0].Fields[2].PSObject.Properties['DetailWordPosition']) 'Saving a legacy schema preserves absent optional properties'

 # Creating a form from Word must discover actual bindings, excluding current answers.
 $scanSource=Join-Path $otherRoot 'По полям Word.docx';New-UniversalTemplate $scanSource $config
 $scanDocument='<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="'+$script:ns+'"><w:body>'+
  '<w:p><w:r><w:t>{{PATIENT_</w:t></w:r><w:r><w:t>NAME}} {{COMPLAINTS}} {{EXTRA_</w:t></w:r><w:r><w:t>NOTE}} {{ADMISSION_DATETIME}} {{FIELD_1}}</w:t></w:r></w:p>'+
  '<w:p><w:r><w:t>{{COMPLAINTS}} {{EXTRA_NOTE}}</w:t></w:r></w:p>'+
  '<w:p><w:sdt><w:sdtPr><w:id w:val="111"/><w:alias w:val="Назначения"/><w:tag w:val="MEDICATION"/><w:dropDownList><w:listItem w:displayText="Выберите элемент." w:value=""/><w:listItem w:displayText="Первая доза" w:value="1"/><w:listItem w:displayText="Вторая доза" w:value="2"/></w:dropDownList></w:sdtPr><w:sdtContent><w:r><w:t>PRIVATE WORD ANSWER</w:t></w:r></w:sdtContent></w:sdt></w:p>'+
  '<w:p><w:sdt><w:sdtPr><w:id w:val="222"/><w:alias w:val="Дата рождения"/><w:tag w:val="PATIENT_BIRTH"/></w:sdtPr><w:sdtContent><w:r><w:t>PRIVATE BIRTH</w:t></w:r></w:sdtContent></w:sdt></w:p>'+
  '<w:p><w:sdt><w:sdtPr><w:id w:val="333"/><w:alias w:val="Поле без маркера"/></w:sdtPr><w:sdtContent><w:r><w:t>PRIVATE UNTAGGED ANSWER</w:t></w:r></w:sdtContent></w:sdt></w:p>'+
  '<w:p><w:sdt><w:sdtPr><w:tag w:val="ADMISSION_DATE"/><w:id w:val="444"/></w:sdtPr><w:sdtContent><w:r><w:t>PRIVATE DATE</w:t></w:r></w:sdtContent></w:sdt></w:p>'+
  '<w:p><w:sdt><w:sdtPr><w:alias w:val="Непривязанный элемент"/></w:sdtPr><w:sdtContent><w:r><w:t>PRIVATE NO ID</w:t></w:r></w:sdtContent></w:sdt></w:p>'+
  '<w:sectPr/></w:body></w:document>'
 Set-TestZipPart $scanSource 'word/document.xml' $scanDocument
 Set-TestZipPart $scanSource 'word/header1.xml' ('<w:hdr xmlns:w="'+$script:ns+'"><w:p><w:r><w:t>{{HEADER_</w:t></w:r><w:r><w:t>NOTE}} {{COMPLAINTS}}</w:t></w:r></w:p></w:hdr>')
 Set-TestZipPart $scanSource 'word/footer1.xml' ('<w:ftr xmlns:w="'+$script:ns+'"><w:p><w:r><w:t>{{FOOTER_NOTE}}</w:t></w:r></w:p></w:ftr>')
 $scanHash=(Get-FileHash -LiteralPath $scanSource -Algorithm SHA256).Hash
 $scanned=New-MedicalSchemaFromTemplate $scanSource
 $scannedFields=@(Get-UniversalFields $scanned)
 Assert-UniversalConfig $scanned
 Assert-Check ($scanned.Version -eq 49 -and -not $scanned.AutoTemplate -and $scanned.Template.StartsWith('Шаблоны/')) 'New form from Word produces a valid managed manual-template schema'
 Assert-Check ($scannedFields.Count -eq 9) 'Word field discovery creates exactly one field for every usable binding'
 Assert-Check (@($scannedFields | Where-Object {$_.Marker -eq 'EXTRA_NOTE'}).Count -eq 1 -and @($scannedFields | Where-Object {$_.Marker -eq 'COMPLAINTS'}).Count -eq 1) 'Split-run markers and repeated literal markers deduplicate correctly'
 $nameField=@($scannedFields | Where-Object {$_.Marker -eq 'PATIENT_NAME'})[0]
 Assert-Check ($nameField.System -eq 'name' -and $nameField.Id -eq 'patient_name' -and $nameField.Type -eq 'text') 'Known patient marker inherits role and original field identity'
 $birthField=@($scannedFields | Where-Object {$_.Marker -eq 'PATIENT_BIRTH'})[0]
 Assert-Check ($birthField.System -eq 'birth' -and $birthField.WordId -eq '222') 'Tagged Word control retains patient role and Word binding'
 $choiceField=@($scannedFields | Where-Object {$_.Marker -eq 'MEDICATION'})[0]
 Assert-Check ($choiceField.Type -eq 'choice' -and $choiceField.WordId -eq '111' -and $choiceField.Label -eq 'Назначения' -and ($choiceField.Options -join '|') -ceq 'Первая доза|Вторая доза') 'Dropdown discovery keeps alias, Word ID and choices while excluding placeholder'
 Assert-Check (@($scannedFields | Where-Object {$_.Marker -eq 'HEADER_NOTE'}).Count -eq 1 -and @($scannedFields | Where-Object {$_.Marker -eq 'FOOTER_NOTE'}).Count -eq 1) 'Word field discovery includes split header and footer markers'
 Assert-Check (@($scannedFields | Where-Object {$_.Marker -in @('ADMISSION_DATE','ADMISSION_DATETIME')}).Count -eq 0) 'Reserved Word markers do not become editable clinical fields'
 $untagged=@($scannedFields | Where-Object {$_.WordId -eq '333'})[0]
 Assert-Check ($untagged.Marker -eq 'FIELD_2' -and $untagged.Label -eq 'Поле без маркера') 'Untagged Word control receives a collision-free generated marker'
 Assert-Check (-not (($scanned | ConvertTo-Json -Depth 50) -match 'PRIVATE|"(Values|Details|Value)"\s*:')) 'Discovered form schema never imports a Word control patient answer'
 Assert-Check (@($scannedFields | Where-Object {$_.Label -eq 'Непривязанный элемент'}).Count -eq 0) 'Unaddressable Word control without marker or ID is excluded'
 Assert-Check ((Get-FileHash -LiteralPath $scanSource -Algorithm SHA256).Hash -eq $scanHash) 'Discovering a form leaves the original Word file byte-identical'

 # Removing the original directory proves restoration uses embedded bytes, not its old path.
 Remove-Item -LiteralPath $sourceRoot -Recurse -Force
 $rootB=Join-Path $temp 'program-b';Set-TestRuntimeRoot $rootB
 $restoredForm=Read-MedicalForm $formPath
 $restoredPath=Join-Path $rootB $restoredForm.Schema.Template
 Assert-Check ($restoredForm.Name -ceq 'Мой осмотр' -and $restoredForm.Schema.Template -eq ('Шаблоны/'+$restoredForm.TemplateName)) 'Opening on another installation restores a portable template association'
 Assert-Check ((Test-Path -LiteralPath $restoredPath) -and (Get-TestHash ([IO.File]::ReadAllBytes($restoredPath))) -eq $sourceHash) 'Portable form restores original manual Word formatting byte for byte'
 Assert-Check (-not $restoredForm.Schema.AutoTemplate) 'Restored embedded template is selected rather than regenerated automatically'
 $portableTree=Get-TestTree $rootB
 Assert-Check ((Read-MedicalForm $formPath).Schema.Template -eq $restoredForm.Schema.Template -and (Get-TestTree $rootB) -eq $portableTree) 'Opening the same portable form twice deduplicates its template'
 Assert-Check ([IO.File]::ReadAllText($formPath) -ceq $rawForm) 'Opening does not modify the portable form file'

 # Invalid form envelopes are rejected before template extraction creates any files.
 $invalidCases=@()
 $variant=Copy-UniversalObject $saved;$variant.Format='AnotherProduct.Form';$invalidCases+=@([pscustomobject]@{Name='format';Value=$variant})
 $variant=Copy-UniversalObject $saved;$variant.Version=999;$invalidCases+=@([pscustomobject]@{Name='version';Value=$variant})
 $variant=Copy-UniversalObject $saved;$variant.Schema.Sections[0].Fields[0].Marker='invalid';$invalidCases+=@([pscustomobject]@{Name='schema';Value=$variant})
 $variant=Copy-UniversalObject $saved;$variant.TemplateBase64='not base64';$invalidCases+=@([pscustomobject]@{Name='base64';Value=$variant})
 $variant=Copy-UniversalObject $saved;$variant.TemplateSha256=('0'*64);$invalidCases+=@([pscustomobject]@{Name='checksum';Value=$variant})
 $variant=Copy-UniversalObject $saved;$badBytes=[Text.Encoding]::UTF8.GetBytes('not Word');$variant.TemplateBase64=[Convert]::ToBase64String($badBytes);$variant.TemplateSha256=Get-TestHash $badBytes;$invalidCases+=@([pscustomobject]@{Name='matching-hash-invalid-word';Value=$variant})
 foreach($case in $invalidCases){
  $file=Join-Path $temp ($case.Name+'.mcform');Write-TestEnvelope $file $case.Value
  $before=Get-TestTree $rootB
  Assert-Rejected {Read-MedicalForm $file} ('Reject malformed portable form: '+$case.Name)
  Assert-Check ((Get-TestTree $rootB) -eq $before) ('Invalid portable form cannot alter managed files: '+$case.Name)
  $missingRoot=Join-Path $temp ('missing-'+$case.Name);Set-TestRuntimeRoot $missingRoot
  Assert-Rejected {Read-MedicalForm $file} ('Reject invalid form before folder initialization: '+$case.Name)
  Assert-Check (-not (Test-Path -LiteralPath $missingRoot)) ('Invalid form leaves missing program folder absent: '+$case.Name)
  Set-TestRuntimeRoot $rootB
 }
 $malformed=Join-Path $temp 'malformed.mcform';[IO.File]::WriteAllText($malformed,'{ not JSON')
 $before=Get-TestTree $rootB
 Assert-Rejected {Read-MedicalForm $malformed} 'Malformed JSON fails before importing a Word template'
 Assert-Check ((Get-TestTree $rootB) -eq $before) 'Malformed JSON leaves template folder unchanged'

 # Auto mode must embed current structure, including newly created independent detail markers.
 $auto=New-TestFormConfig (Join-Path $temp 'never-existed.docx') $true
 $auto.Sections[0].Fields+=(New-UniversalField 'extra' 'Новая строка' 'EXTRA' 'text')
 $autoBefore=$auto | ConvertTo-Json -Depth 50
 $generated=New-MedicalTemplateFile 'Созданный шаблон' $auto
 Assert-Check ((Test-Path -LiteralPath $generated.Path) -and $generated.RelativePath -eq ('Шаблоны/'+$generated.Name)) 'Create-template action produces a managed valid Word file'
 [void](Test-MedicalTemplateBytes ([IO.File]::ReadAllBytes($generated.Path)))
 Assert-Check (($auto | ConvertTo-Json -Depth 50) -ceq $autoBefore) 'Template generation never mutates the structure'
 $before=Get-TestTree $rootB
 Assert-Rejected {New-MedicalTemplateFile 'Несоответствие.dotx' $auto} 'DOCX generator refuses a DOTX output extension'
 Assert-Check ((Get-TestTree $rootB) -eq $before) 'Refused DOTX generation leaves the managed template folder unchanged'
 $autoForm=Join-Path $temp 'automatic.mcform';[void](Write-MedicalForm $autoForm $auto 'Автоматическая форма')
 $openedAuto=Read-MedicalForm $autoForm;$autoPath=Join-Path $rootB $openedAuto.Schema.Template
 $xml=Get-TestZipPart $autoPath 'word/document.xml'
 foreach($field in Get-UniversalFields $auto){Assert-Check ($xml.OuterXml.Contains('{{'+$field.Marker+'}}')) ('Generated embedded template reflects current field: '+$field.Id)}
 Assert-Check ($xml.OuterXml.Contains('{{DETAIL_TEXT}}') -and $xml.OuterXml.Contains('{{ADMISSION_DATETIME}}')) 'Generated embedded template retains independent detail and date markers'
 Assert-Check (($auto | ConvertTo-Json -Depth 50) -ceq $autoBefore) 'Saving and opening automatic form preserve its input configuration'

 # The universal generator produces DOCX content, even if an older schema pointed at DOTX.
 $autoDotx=Copy-UniversalObject $auto;$autoDotx.Template='Изначальный шаблон.dotx'
 $autoDotxForm=Join-Path $temp 'automatic-dotx.mcform';[void](Write-MedicalForm $autoDotxForm $autoDotx)
 $dotxSnapshot=Get-Content -LiteralPath $autoDotxForm -Raw -Encoding UTF8 | ConvertFrom-Json
 Assert-Check ($dotxSnapshot.TemplateName -eq 'Изначальный шаблон.docx' -and $dotxSnapshot.Schema.Template.EndsWith('.docx')) 'Automatic snapshot uses DOCX filename matching generated Word content'
 Assert-Check ($autoDotx.Template -eq 'Изначальный шаблон.dotx') 'Automatic DOTX-to-DOCX snapshot leaves the input schema path unchanged'

 # Existing form files must survive invalid saves, with no stray temporary files.
 $preserved=(Get-FileHash -LiteralPath $formPath -Algorithm SHA256).Hash
 $invalidSchema=Copy-UniversalObject $auto;$invalidSchema.Sections[0].Fields[0].Marker='bad-marker'
 Assert-Rejected {Write-MedicalForm $formPath $invalidSchema} 'Invalid schema cannot overwrite an existing form'
 Assert-Check ((Get-FileHash -LiteralPath $formPath -Algorithm SHA256).Hash -eq $preserved) 'Invalid-schema save leaves existing form bytes intact'
 $missingTemplate=New-TestFormConfig (Join-Path $temp 'missing-template.docx') $false
 Assert-Rejected {Write-MedicalForm $formPath $missingTemplate} 'Missing manual template cannot overwrite an existing form'
 Assert-Check ((Get-FileHash -LiteralPath $formPath -Algorithm SHA256).Hash -eq $preserved) 'Missing-template save leaves existing form bytes intact'
 $blockedBackup=$formPath+'.bak';[void][IO.Directory]::CreateDirectory($blockedBackup)
 Assert-Rejected {Write-MedicalForm $formPath $auto 'Не записать'} 'Filesystem failure during replacement is reported'
 Assert-Check ((Get-FileHash -LiteralPath $formPath -Algorithm SHA256).Hash -eq $preserved) 'Failed filesystem replacement preserves the existing form'
 Remove-Item -LiteralPath $blockedBackup -Recurse -Force
 [void](Write-MedicalForm $formPath $auto 'Обновлённая форма')
 Assert-Check ([IO.File]::ReadAllText($blockedBackup) -ceq $rawForm) 'Successful replacement keeps the complete previous form in a backup'
 Assert-Check ((Read-MedicalForm $formPath).Name -ceq 'Обновлённая форма') 'Successfully replaced form remains loadable'
 Assert-Check (@(Get-ChildItem -LiteralPath $temp -Force -Recurse -File | Where-Object {$_.Name -like '*.tmp'}).Count -eq 0) 'Form operations clean up all temporary files'

 # Exercise pure form helpers and patient reset without constructing a WinForms window.
 Import-TestFunctions (Join-Path $Project 'forms-ui-v59.ps1') @('Get-MedicalFormSignature','Test-MedicalWorkspaceHasData','Get-MedicalGeneratedSchema')
 Import-TestFunctions (Join-Path $Project 'constructor.ps1') @('Reset-NewPatientCase')
 $boundInput=Copy-UniversalObject $scanned;$boundInput.Template=$scanSource
 $boundChoice=@(Get-UniversalFields $boundInput | Where-Object {$_.Marker -eq 'MEDICATION'})[0]
 $boundChoice.Options=@()
 $boundBefore=$boundInput | ConvertTo-Json -Depth 50
 $generatedSchema=Get-MedicalGeneratedSchema $boundInput
 $generatedChoice=@(Get-UniversalFields $generatedSchema | Where-Object {$_.Marker -eq 'MEDICATION'})[0]
 Assert-Check (($generatedChoice.Options -join '|') -ceq 'Первая доза|Вторая доза') 'Generated schema materializes choices from its bound Word dropdown'
 Assert-Check (@(Get-UniversalFields $generatedSchema | Where-Object {$_.WordId}).Count -eq 0) 'Generated schema clears Word IDs that would not exist in generated DOCX'
 Assert-Check (($boundInput | ConvertTo-Json -Depth 50) -ceq $boundBefore) 'Generating schema keeps the original bindings and structure unchanged'
 $unresolved=Copy-UniversalObject $boundInput
 (@(Get-UniversalFields $unresolved | Where-Object {$_.Marker -eq 'MEDICATION'})[0]).WordId='missing-id'
 Assert-Rejected {Get-MedicalGeneratedSchema $unresolved} 'Generated schema rejects a dropdown with no materializable choices'

 $resetCandidate=New-TestFormConfig $restoredPath
 $resetBefore=$resetCandidate | ConvertTo-Json -Depth 50
 $resetExpected=(Copy-MedicalFormSchema $resetCandidate) | ConvertTo-Json -Depth 50
 Set-TestPopulatedCase $scanned
 function script:Load-UniversalConfig {throw 'Reset must preserve the selected form rather than load a different saved form.'}
 Reset-NewPatientCase $resetCandidate
 Assert-Check (($script:universalConfig | ConvertTo-Json -Depth 50) -ceq $resetExpected) 'Explicit form reset activates the selected schema and all clarification settings'
 Assert-Check (-not [object]::ReferenceEquals($script:universalConfig,$resetCandidate) -and -not [object]::ReferenceEquals($script:universalConfig.Sections[0].Fields[0],$resetCandidate.Sections[0].Fields[0])) 'Reset deep-copies the selected schema and its nested fields'
 $script:universalConfig.Sections[0].Fields[0].Label='Новая локальная подпись'
 Assert-Check (($resetCandidate | ConvertTo-Json -Depth 50) -ceq $resetBefore) 'Editing active form after reset cannot mutate the supplied schema'
 foreach($name in @('universalValues','universalDetails','universalInputs','universalDetailInputs','universalMultiInputs','universalRepeatInputs')){
  Assert-Check ((Get-Variable -Scope Script -Name $name -ValueOnly).Count -eq 0) ('New patient clears the stale map: '+$name)
 }
 Assert-Check ($script:universalWordFields.Count -eq 0 -and $script:fields.Count -eq 0 -and $script:controls.Count -eq 0) 'New patient clears stale Word field and control bindings'
 Assert-Check ($script:stageData.Count -eq 0 -and $script:initialByLabel.Count -eq 0 -and $script:stage -eq 'initial') 'New patient clears stage answers and starts at the initial examination'
 Assert-Check ($script:stageTemplates.initial -eq $restoredPath -and $script:stageTemplates.diary -eq '' -and $script:stageTemplates.discharge -eq '') 'New patient associates only the chosen initial template and clears other stage templates'
 Assert-Check ($script:currentPatient -eq -1 -and $null -eq $script:pendingDocument -and $script:caseFolder -eq '' -and $script:caseFile -eq '' -and $script:source -eq '') 'New patient clears database, case and pending-document bindings'
 Assert-Check ($script:diaryIndex -eq 1 -and $script:diaryRecords.Count -eq 0) 'New patient resets the diary index and stored diary records'
 $demographicsClean=$true
 foreach($name in @('patientName','patientBirthYear','patientAddress','addressBase','addressStreet','addressHouse','addressApartment')){
  if((Get-Variable -Scope Script -Name $name -ValueOnly) -ne ''){$demographicsClean=$false}
 }
 Assert-Check $demographicsClean 'New patient clears every demographic and address variable'
 $textClean=$true
 foreach($name in @('patientNameControl','patientBirthControl','patientAddressControl','streetControl','houseControl','apartmentControl')){
  if((Get-Variable -Scope Script -Name $name -ValueOnly).Text -ne ''){$textClean=$false}
 }
 Assert-Check $textClean 'New patient clears demographic input text without WinForms emulation'
 Assert-Check ($script:admissionControl.Value -gt [datetime]'2020-01-01T01:00:00' -and $script:admissionControl.Value -le (Get-Date)) 'New patient assigns a fresh admission time'

 Set-TestPopulatedCase $resetCandidate
 $activeBefore=(Copy-MedicalFormSchema $script:universalConfig) | ConvertTo-Json -Depth 50
 Reset-NewPatientCase
 Assert-Check (($script:universalConfig | ConvertTo-Json -Depth 50) -ceq $activeBefore) 'New examination preserves the active reusable form without reloading disk settings'
 Assert-Check ($script:universalValues.Count -eq 0 -and $script:universalDetails.Count -eq 0 -and $script:stageData.Count -eq 0) 'New examination with active form clears previous patient answers'
 $script:fallbackConfig=$resetCandidate;$script:loadCount=0;$script:universalConfig=$null
 function script:Load-UniversalConfig {$script:loadCount++;return (Copy-UniversalObject $script:fallbackConfig)}
 Reset-NewPatientCase
 Assert-Check ($script:loadCount -eq 1 -and ($script:universalConfig | ConvertTo-Json -Depth 50) -ceq $resetBefore) 'Reset loads saved configuration only when no active form exists'

 $script:medicalFormBaseline=Get-MedicalFormSignature $script:universalConfig
 Assert-Check (-not (Test-MedicalWorkspaceHasData)) 'Clean patient and unchanged form do not require a reset confirmation'
 $script:universalValues=@{name=" `r`n "};$script:universalDetails=@{choice1=" `t "}
 Assert-Check (-not (Test-MedicalWorkspaceHasData)) 'Whitespace-only answers do not count as unsaved patient data'
 $script:universalValues.name='Новый пациент'
 Assert-Check (Test-MedicalWorkspaceHasData) 'Patient answer is detected before a potentially destructive form reset'
 $script:universalValues=@{};$script:universalDetails.choice1='25 мг'
 Assert-Check (Test-MedicalWorkspaceHasData) 'Clarification text alone is detected before form reset'
 $script:universalDetails=@{};$script:stageData=@{diary_1=@('  ','Заполненный дневник')}
 Assert-Check (Test-MedicalWorkspaceHasData) 'Diary or other stage answers are detected before form reset'
 $script:stageData=@{};$script:universalConfig.Sections[0].Fields[0].Label='Изменённая форма'
 Assert-Check (Test-MedicalWorkspaceHasData) 'Unsaved structure changes are detected even without patient answers'
 $script:universalConfig=Copy-UniversalObject $resetCandidate
 Set-TestProperty $script:universalConfig 'Values' @{ignored='Runtime property'}
 Assert-Check (-not (Test-MedicalWorkspaceHasData)) 'Runtime-only schema properties do not mark reusable structure as modified'

 # Switching the initial Word template must activate the dialog's generated schema,
 # including options materialized from Word, rather than reuse stale active bindings.
 # Keep the production module's PSScriptRoot bound to this fixture program.
 # The second template selection uses a managed relative path after the first.
 Copy-Item -LiteralPath (Join-Path $Project 'universal.ps1') -Destination (Join-Path $rootB 'universal.ps1')
 . (Join-Path $rootB 'universal.ps1')
 Import-TestFunctions (Join-Path $Project 'forms-ui-v59.ps1') @('Invoke-MedicalChooseTemplate','Set-MedicalRecoveredInitialTemplate')
 $script:universalConfig=Copy-UniversalObject $boundInput
 $script:choiceFixture=[pscustomobject]@{Schema=(Copy-UniversalObject $generatedSchema);Template=$generated;Name='Созданный шаблон'}
 $choiceBefore=$script:choiceFixture | ConvertTo-Json -Depth 50
 $script:universalValues=@{patient_name='Пациент продолжает текущий осмотр'}
 $script:universalDetails=@{current_detail='Текущее уточнение'}
 $script:stageData=@{diary_1=@('Существующий дневник')}
 $answersBefore=$script:universalValues | ConvertTo-Json -Depth 50
 $detailsBefore=$script:universalDetails | ConvertTo-Json -Depth 50
 $stagesBefore=$script:stageData | ConvertTo-Json -Depth 50
 $script:stage='initial';$script:medicalWorkspaceReady=$true
 $script:captureCount=0;$script:saveConfigCount=0;$script:openInitialCount=0;$script:lastSavedConfig=$null;$script:choiceNewForm=$null
 function script:Capture-Stage {$script:captureCount++}
 function script:Show-MedicalTemplateChoice($owner,$config,[bool]$newForm){$script:choiceNewForm=$newForm;return $script:choiceFixture}
 function script:Save-UniversalConfig($config){$script:saveConfigCount++;$script:lastSavedConfig=Copy-MedicalFormSchema $config}
 function script:Open-UniversalInitial {$script:openInitialCount++}
 Invoke-MedicalChooseTemplate
 $activeChoice=@(Get-UniversalFields $script:universalConfig | Where-Object {$_.Marker -eq 'MEDICATION'})[0]
 Assert-Check (($activeChoice.Options -join '|') -ceq 'Первая доза|Вторая доза' -and $activeChoice.WordId -eq '') 'Template switch activates materialized dropdown choices and clears obsolete Word bindings'
 Assert-Check ($script:universalConfig.Template -eq $generated.RelativePath -and -not $script:universalConfig.AutoTemplate) 'Template switch selects the managed generated Word template'
 $persistedChoice=@(Get-UniversalFields $script:lastSavedConfig | Where-Object {$_.Marker -eq 'MEDICATION'})[0]
 Assert-Check (($persistedChoice.Options -join '|') -ceq 'Первая доза|Вторая доза' -and $persistedChoice.WordId -eq '' -and $script:lastSavedConfig.Template -eq $generated.RelativePath) 'Template switch persists the selected generated schema rather than stale active settings'
 Assert-Check (($script:universalValues | ConvertTo-Json -Depth 50) -ceq $answersBefore -and ($script:universalDetails | ConvertTo-Json -Depth 50) -ceq $detailsBefore -and ($script:stageData | ConvertTo-Json -Depth 50) -ceq $stagesBefore) 'Changing initial template retains patient answers, clarification text and other stages'
 Assert-Check (($script:choiceFixture | ConvertTo-Json -Depth 50) -ceq $choiceBefore -and -not [object]::ReferenceEquals($script:universalConfig,$script:choiceFixture.Schema)) 'Template switch deep-copies the selected schema without mutating the dialog result'
 Assert-Check ($script:captureCount -eq 1 -and $script:saveConfigCount -eq 1 -and $script:openInitialCount -eq 1 -and $script:choiceNewForm -eq $false) 'Initial template switch captures once, saves once and refreshes once'
 $activeBeforeCancel=$script:universalConfig | ConvertTo-Json -Depth 50
 $script:choiceFixture=$null
 Invoke-MedicalChooseTemplate
 Assert-Check (($script:universalConfig | ConvertTo-Json -Depth 50) -ceq $activeBeforeCancel -and $script:saveConfigCount -eq 1 -and $script:openInitialCount -eq 1) 'Cancelled template selection preserves active schema and skips persistence or refresh'
 Write-Output ('COMPLETED: '+$script:checks+' checks passed. These checks cover file workflows; Windows UI and Word printing remain untested.')
}finally{Remove-Item -LiteralPath $temp -Recurse -Force}
