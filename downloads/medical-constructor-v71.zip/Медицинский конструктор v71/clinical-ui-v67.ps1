﻿# Independent input bindings keep every diary and the editable discharge separate
# from the canonical initial examination and from one another.
$script:medicalClinicalBindings=@{}
$script:medicalClinicalFlow=$null
$script:medicalActiveDiaryId=''
$script:medicalClinicalBuilding=$false
$script:medicalTreatmentPeriodControls=$null

# Critical actions also create a checkpoint between periodic timer saves.
function Request-MedicalClinicalCheckpoint {
 if((-not $script:medicalWorkspaceReady -and -not $script:medicalBackupEditorDraft -and -not $script:medicalBackupRetainedDraft) -or -not (Get-Command Write-MedicalSessionBackup -CommandType Function -ErrorAction SilentlyContinue)){return}
 try{[void](Write-MedicalSessionBackup)}catch{
  if($script:uiMedicalFormStatus){$script:uiMedicalFormStatus.Text='Резервная копия не записана: '+$_.Exception.Message}
 }
}
function Get-MedicalActiveClinicalContext {
 if($script:stage -eq 'discharge'){return (Get-MedicalClinicalContext 'discharge' '')}
 if($script:stage -ne 'diary'){return $null}
 if(-not $script:medicalClinicalForms){[void](Initialize-MedicalClinicalWorkspace)}
 $entries=@($script:medicalClinicalForms.Diaries)
 if(-not $entries.Count){return $null}
 $selected=$null
 foreach($entry in $entries){if([string]$entry.Id -eq $script:medicalActiveDiaryId){$selected=$entry;break}}
 if(-not $selected){$selected=$entries[0];$script:medicalActiveDiaryId=[string]$selected.Id}
 return (Get-MedicalClinicalContext 'diary' ([string]$selected.Id))
}
function Get-MedicalActiveSchemaForEditor {
 if($script:stage -eq 'initial'){return $script:universalConfig}
 $context=Get-MedicalActiveClinicalContext
 if($context){return $context.Schema}
 return $null
}
function Get-MedicalClinicalInputValue($binding,[string]$fieldId){
 if($binding.RepeatInputs.ContainsKey($fieldId)){return (@($binding.RepeatInputs[$fieldId].Rows | ForEach-Object {[string]$_.Editor.Text}) -join "`r`n")}
 if($binding.MultiInputs.ContainsKey($fieldId)){return (@($binding.MultiInputs[$fieldId] | Where-Object {$_.Checked} | ForEach-Object {[string]$_.Text}) -join "`r`n")}
 if($binding.Inputs.ContainsKey($fieldId)){return [string]$binding.Inputs[$fieldId].Text}
 return ''
}
function Save-MedicalClinicalInput($tag,[bool]$clearDetail=$false){
 if($script:medicalClinicalBuilding -or -not $tag -or -not $tag.Binding -or $tag.Binding.Stage -ne $script:stage){return}
 $binding=$tag.Binding;$fieldId=[string]$tag.FieldId
 $detail=$null
 if($binding.DetailInputs.ContainsKey($fieldId)){
  if($clearDetail){$binding.DetailInputs[$fieldId].Text=''}
  $detail=[string]$binding.DetailInputs[$fieldId].Text
 }
 Set-MedicalClinicalValue $binding.Stage $binding.Id $fieldId (Get-MedicalClinicalInputValue $binding $fieldId) $detail
 Update-MedicalClinicalCompletion $binding $fieldId
}
function Capture-MedicalClinicalStage {
 if($script:stage -eq 'initial' -or -not $script:medicalClinicalBindings){return}
 foreach($binding in @($script:medicalClinicalBindings.Values)){
  if($binding.Stage -ne $script:stage){continue}
  foreach($fieldId in @($binding.Inputs.Keys)){
   if($binding.Inputs[$fieldId] -and $binding.Inputs[$fieldId].IsDisposed){continue}
   $detail=$null;if($binding.DetailInputs.ContainsKey($fieldId)){$detail=[string]$binding.DetailInputs[$fieldId].Text}
   Set-MedicalClinicalValue $binding.Stage $binding.Id ([string]$fieldId) (Get-MedicalClinicalInputValue $binding ([string]$fieldId)) $detail
  }
  if($binding.Stage -eq 'diary' -and $binding.DateControl -and -not $binding.DateControl.IsDisposed){
   if(Get-Command Capture-MedicalDiaryPeriodControls -ErrorAction SilentlyContinue){Capture-MedicalDiaryPeriodControls $binding}
   else{Set-MedicalClinicalDate $binding.Id (Sync-MedicalClinicalDateControl $binding.DateControl $false 'дневника')}
  }
 }
 Capture-MedicalTreatmentPeriodControls
}
function Update-MedicalClinicalCompletion($changedBinding=$null,[string]$changedFieldId=''){
 if(-not $script:medicalClinicalBindings -or $script:medicalClinicalBuilding){return}
 $total=0;$missingTotal=0
 foreach($binding in @($script:medicalClinicalBindings.Values)){
  $partial=$changedBinding -and [object]::ReferenceEquals($binding,$changedBinding) -and $changedFieldId -and $binding.PSObject.Properties['CompletionFields']
  if($changedBinding -and -not [object]::ReferenceEquals($binding,$changedBinding) -and $binding.PSObject.Properties['CompletionFields']){$total+=$binding.RequiredCount;$missingTotal+=$binding.MissingCount;continue}
  if($partial){
   # Answers have already been committed. Repainting one dot must not resync all
   # diaries, flatten schemas or read the Word template again on each key.
   $data=Get-MedicalClinicalBinding $binding.Stage $binding.Id
   $field=Get-MedicalClinicalField $data.Definition.Schema $changedFieldId
   $fields=@($field);$values=$data.State.Values
   $previous=$binding.CompletionFields[$changedFieldId]
   if($previous){$binding.RequiredCount-=[int]$previous.Required;$binding.MissingCount-=[int]$previous.Missing}
  }else{
   $context=Get-MedicalClinicalContext $binding.Stage $binding.Id
   $fields=@(Get-UniversalFields $context.Schema);$values=$context.Values
   $binding | Add-Member -NotePropertyName CompletionFields -NotePropertyValue @{} -Force
   $binding | Add-Member -NotePropertyName RequiredCount -NotePropertyValue 0 -Force
   $binding | Add-Member -NotePropertyName MissingCount -NotePropertyValue 0 -Force
  }
  foreach($field in $fields){
   if(-not $field){continue}
   $id=[string]$field.Id;$filled=-not [string]::IsNullOrWhiteSpace([string]$values[$id]);$isRequired=Test-UniversalFieldRequired $field
   $isMissing=$isRequired -and -not $filled
   $binding.RequiredCount+=[int]$isRequired;$binding.MissingCount+=[int]$isMissing
   $binding.CompletionFields[$id]=[pscustomobject]@{Required=$isRequired;Missing=$isMissing}
   if($binding.Indicators.ContainsKey($id)){
    $dot=$binding.Indicators[$id]
    if($dot -and -not $dot.IsDisposed){$dot.ForeColor=if($filled){$script:uiSuccess}elseif($isRequired){$script:uiDanger}else{$script:darkMuted};$dot.AccessibleName=([string]$field.Label+': '+$(if($filled){'заполнено'}elseif($isRequired){'не заполнено'}else{'необязательное поле'}))}
   }
  }
  if($binding.CompletionLabel -and -not $binding.CompletionLabel.IsDisposed){$binding.CompletionLabel.Text=('Обязательные поля: '+($binding.RequiredCount-$binding.MissingCount)+' / '+$binding.RequiredCount+' • Пропущено: '+$binding.MissingCount)}
  $total+=$binding.RequiredCount;$missingTotal+=$binding.MissingCount
 }
 if($script:progressLabel){$script:progressLabel.Text=('Обязательные поля: '+($total-$missingTotal)+' / '+$total+' • Пропущено: '+$missingTotal)}
}
function Test-MedicalClinicalCompletion($context){
 $missing=@(Get-UniversalMissingFields $context.Schema $context.Values)
 if($missing.Count){
  $key=if($script:stage -eq 'diary'){[string]$context.Id}else{'discharge'}
  if($script:medicalClinicalBindings.ContainsKey($key)){
   $binding=$script:medicalClinicalBindings[$key];$first=$binding.Inputs[[string]$missing[0].Id]
   if($first -and $panel){$panel.ScrollControlIntoView($first);[void]$first.Focus()}
  }
  throw ("Не заполнены обязательные поля:`r`n"+(@($missing | ForEach-Object {$_.Section+' — '+$_.Label}) -join "`r`n")+"`r`nНезавершённую работу можно сохранить в карте.")
 }
 foreach($field in Get-UniversalFields $context.Schema){
  if($field.System -eq 'birth' -and -not [string]::IsNullOrWhiteSpace([string]$context.Values[[string]$field.Id])){
   $date=[datetime]::MinValue
   if(-not [datetime]::TryParseExact([string]$context.Values[[string]$field.Id],'dd.MM.yyyy',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$date)){throw 'Дата рождения должна быть в формате ДД.ММ.ГГГГ.'}
  }
 }
}
function Add-MedicalClinicalRepeatRow($binding,[string]$fieldId,[string]$value=''){
 $entry=$binding.RepeatInputs[$fieldId]
 $row=New-Object Windows.Forms.TableLayoutPanel;$row.ColumnCount=2;$row.AutoSize=$true;$row.AutoSizeMode='GrowAndShrink';$row.Dock='Top';$row.Margin=New-Object Windows.Forms.Padding(0,0,0,8)
 [void]$row.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
 [void]$row.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute,100)))
 $editor=New-Object Windows.Forms.TextBox;$editor.Text=$value;$editor.Multiline=$true;$editor.AcceptsReturn=$true;$editor.ScrollBars='Vertical';$editor.Height=58;$editor.Dock='Top'
 $editor.Tag=[pscustomobject]@{Binding=$binding;FieldId=$fieldId};$editor.Add_TextChanged({Save-MedicalClinicalInput $this.Tag})
 $item=[pscustomobject]@{Panel=$row;Editor=$editor;Binding=$binding;FieldId=$fieldId}
 $remove=New-Object Windows.Forms.Button;$remove.Text='Удалить';$remove.Dock='Top';$remove.Height=32;$remove.Tag=$item
 $remove.Add_Click({
  $item=$this.Tag;$entry=$item.Binding.RepeatInputs[$item.FieldId]
  $entry.Host.Controls.Remove($item.Panel);[void]$entry.Rows.Remove($item);$item.Panel.Dispose()
  Save-MedicalClinicalInput ([pscustomobject]@{Binding=$item.Binding;FieldId=$item.FieldId})
 })
 $row.Controls.Add((New-MedicalInputFrame $editor),0,0);$row.Controls.Add($remove,1,0)
 [void]$entry.Rows.Add($item);$entry.Host.Controls.Add($row);$entry.Host.Controls.SetChildIndex($row,($entry.Host.Controls.Count-2))
 if(-not $script:medicalClinicalBuilding){Set-DarkTheme $row;Save-MedicalClinicalInput $editor.Tag}
}
function New-MedicalClinicalRepeatControl($binding,$field){
 $hostPanel=New-Object Windows.Forms.TableLayoutPanel;$hostPanel.ColumnCount=1;$hostPanel.AutoSize=$true;$hostPanel.AutoSizeMode='GrowAndShrink';$hostPanel.Dock='Top'
 [void]$hostPanel.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
 $add=New-Object Windows.Forms.Button;$add.Text='+ Строка';$add.Width=155;$add.Height=32;$add.Margin=New-Object Windows.Forms.Padding(0,4,0,8)
 $id=[string]$field.Id;$add.Tag=[pscustomobject]@{Binding=$binding;FieldId=$id};$add.Add_Click({Add-MedicalClinicalRepeatRow $this.Tag.Binding $this.Tag.FieldId})
 $hostPanel.Controls.Add($add);$binding.RepeatInputs[$id]=[pscustomobject]@{Host=$hostPanel;Rows=(New-Object System.Collections.ArrayList)}
 $value=[string]$binding.Context.Values[$id]
 if($value.Length){foreach($line in [regex]::Split($value,'\r\n|\r|\n')){Add-MedicalClinicalRepeatRow $binding $id $line}}else{Add-MedicalClinicalRepeatRow $binding $id}
 return $hostPanel
}
function Add-MedicalClinicalField($block,$binding,$field){
 $id=[string]$field.Id
 if($field.Type -eq 'heading'){
  $heading=New-Object Windows.Forms.Label;$heading.Text=[string]$field.Label;$heading.AutoSize=$true;$heading.Dock='Top';$heading.Font=New-Object Drawing.Font('Segoe UI',11,[Drawing.FontStyle]::Bold);$heading.Margin=New-Object Windows.Forms.Padding(0,12,0,8);$block.Controls.Add($heading);return
 }
 $label=New-Object Windows.Forms.Label;$label.Text=[string]$field.Label;$label.AutoSize=$true;$label.Margin=New-Object Windows.Forms.Padding(0,5,0,6);$block.Controls.Add($label)
 if($field.Type -in @('choice','choice_detail')){
  $input=New-Object SafeComboBox;$input.DropDownStyle='DropDownList';$input.DropDownWidth=900;$input.Height=32
  $options=@($field.Options)
  if($field.WordId){$bound=@($binding.WordFields | Where-Object {$_.Id -eq $field.WordId});if($bound.Count -and $bound[0].Options.Count){$options=@($bound[0].Options)}}
  foreach($option in $options){[void]$input.Items.Add([string]$option)}
  $value=[string]$binding.Context.Values[$id]
  if($value -and -not $input.Items.Contains($value)){[void]$input.Items.Add($value)}
  if($value){$input.SelectedItem=$value}
 }elseif($field.Type -eq 'repeat'){$input=New-MedicalClinicalRepeatControl $binding $field}
 elseif($field.Type -eq 'multi'){
  $input=New-Object Windows.Forms.TableLayoutPanel;$input.ColumnCount=1;$input.AutoSize=$true;$input.AutoSizeMode='GrowAndShrink'
  [void]$input.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
  $checks=New-Object System.Collections.ArrayList
  foreach($option in Get-UniversalMultiRows @($field.Options) ([string]$binding.Context.Values[$id])){
   $check=New-Object Windows.Forms.CheckBox;$check.Text=$option.Text;$check.Checked=$option.Checked;$check.AutoSize=$true;$check.Dock='Top';$check.MaximumSize=New-Object Drawing.Size(([Math]::Max(300,$panel.ClientSize.Width-180)),0);$check.Margin=New-Object Windows.Forms.Padding(0,4,0,6)
   $check.Tag=[pscustomobject]@{Binding=$binding;FieldId=$id};$check.Add_CheckedChanged({Save-MedicalClinicalInput $this.Tag})
   [void]$checks.Add($check);$input.Controls.Add($check)
  }
  $binding.MultiInputs[$id]=$checks
 }else{
  $input=New-Object Windows.Forms.TextBox
  if($field.Type -eq 'multiline'){$input.Multiline=$true;$input.AcceptsReturn=$true;$input.ScrollBars='Vertical';$input.Height=105}else{$input.Height=30}
  $input.Text=[string]$binding.Context.Values[$id]
 }
 $input.Dock='Top';$input.Margin=New-Object Windows.Forms.Padding(0,0,0,10);$input.Tag=[pscustomobject]@{Binding=$binding;FieldId=$id}
 $binding.Inputs[$id]=$input
 if($field.Type -notin @('multi','repeat')){$input.Add_TextChanged({Save-MedicalClinicalInput $this.Tag})}
 $row=New-Object Windows.Forms.TableLayoutPanel;$row.ColumnCount=2;$row.RowCount=1;$row.AutoSize=$true;$row.Dock='Top';$row.Margin=New-Object Windows.Forms.Padding(0)
 [void]$row.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
 [void]$row.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute,32)))
 $dot=New-Object Windows.Forms.Label;$dot.Text='●';$dot.Dock='Fill';$dot.TextAlign='TopCenter';$dot.Font=New-Object Drawing.Font('Segoe UI',14);$binding.Indicators[$id]=$dot
 $visual=$input;if($input -is [Windows.Forms.TextBox]){$visual=New-MedicalInputFrame $input}
 $row.Controls.Add($visual,0,0);$row.Controls.Add($dot,1,0)
 if($field.Type -ne 'choice_detail'){$block.Controls.Add($row);return}
 $detailLabel=New-Object Windows.Forms.Label;$detailLabel.Text='Уточнение (необязательно)';$detailLabel.AutoSize=$true;$detailLabel.Margin=New-Object Windows.Forms.Padding(0,0,0,6)
 $detail=New-Object Windows.Forms.TextBox;$detail.Multiline=$true;$detail.AcceptsReturn=$true;$detail.ScrollBars='Vertical';$detail.Height=60;$detail.Dock='Top';$detail.Margin=New-Object Windows.Forms.Padding(0,0,0,14)
 $detail.Text=[string]$binding.Context.Details[$id];$detail.Tag=$input.Tag;$detail.AccessibleName=('Уточнение к полю «'+$field.Label+'»');$binding.DetailInputs[$id]=$detail
 $detail.Add_TextChanged({Save-MedicalClinicalInput $this.Tag})
 $detailHost=New-Object Windows.Forms.TableLayoutPanel;$detailHost.ColumnCount=1;$detailHost.AutoSize=$true;$detailHost.AutoSizeMode='GrowAndShrink';$detailHost.Dock='Top';$detailHost.Margin=New-Object Windows.Forms.Padding(0,0,0,8)
 [void]$detailHost.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)));$detailHost.Controls.Add($detailLabel);$detailHost.Controls.Add((New-MedicalInputFrame $detail))
 switch(Get-UniversalDetailFormPosition $field){
  'above' {$block.Controls.Add($detailHost);$block.Controls.Add($row)}
  'right' {
   $paired=New-Object Windows.Forms.TableLayoutPanel;$paired.ColumnCount=2;$paired.RowCount=1;$paired.AutoSize=$true;$paired.AutoSizeMode='GrowAndShrink';$paired.Dock='Top';$paired.Margin=New-Object Windows.Forms.Padding(0,0,0,8)
   [void]$paired.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,50)));[void]$paired.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,50)))
   $detailHost.Margin=New-Object Windows.Forms.Padding(14,0,0,0);$paired.Controls.Add($row,0,0);$paired.Controls.Add($detailHost,1,0);$block.Controls.Add($paired)
  }
  default {$block.Controls.Add($row);$block.Controls.Add($detailHost)}
 }
 $input.Add_SelectedIndexChanged({Save-MedicalClinicalInput $this.Tag $true})
}
function New-MedicalClinicalRecordPanel($context,[string]$stage){
 $binding=[pscustomobject]@{Stage=$stage;Id=[string]$context.Id;Context=$context;Inputs=@{};DetailInputs=@{};MultiInputs=@{};RepeatInputs=@{};Indicators=@{};DateControl=$null;CompletionLabel=$null;Heading=$null;WordFields=@()}
 $key=if($stage -eq 'diary'){[string]$context.Id}else{'discharge'};$script:medicalClinicalBindings[$key]=$binding
 $templatePath=Get-UniversalTemplatePath $context.Schema
 if(-not $context.Schema.AutoTemplate -and [IO.File]::Exists($templatePath)){
  if($null -ne $script:medicalClinicalWordFieldCache){
   if(-not $script:medicalClinicalWordFieldCache.ContainsKey($templatePath)){$script:medicalClinicalWordFieldCache[$templatePath]=@(Get-UniversalWordFields $templatePath)}
   $binding.WordFields=$script:medicalClinicalWordFieldCache[$templatePath]
  }else{$binding.WordFields=@(Get-UniversalWordFields $templatePath)}
 }
 $card=New-Object MedicalOutlineTable;$card.ColumnCount=1;$card.AutoSize=$true;$card.AutoSizeMode='GrowAndShrink';$card.Dock='Top';$card.Padding=New-Object Windows.Forms.Padding(16);$card.Margin=New-Object Windows.Forms.Padding(0,0,0,16)
 [void]$card.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
 $heading=New-Object Windows.Forms.Label;$heading.Text=[string]$context.Title;$heading.AutoSize=$true;$heading.Font=New-Object Drawing.Font('Segoe UI',14,[Drawing.FontStyle]::Bold);$heading.Margin=New-Object Windows.Forms.Padding(0,0,0,10);$card.Controls.Add($heading);$binding.Heading=$heading
 $toolbar=New-Object Windows.Forms.FlowLayoutPanel;$toolbar.AutoSize=$true;$toolbar.WrapContents=$true;$toolbar.Dock='Top';$toolbar.Margin=New-Object Windows.Forms.Padding(0,0,0,12)
 if($stage -eq 'diary'){
  $dateLabel=New-Object Windows.Forms.Label;$dateLabel.Text='Дата и время записи';$dateLabel.AutoSize=$true;$dateLabel.Margin=New-Object Windows.Forms.Padding(0,8,12,0);$toolbar.Controls.Add($dateLabel)
  $date=New-Object Windows.Forms.DateTimePicker;$date.Format='Custom';$date.CustomFormat='dd.MM.yyyy  HH:mm';$date.Width=205;$date.Value=$context.DateTime;$date.Tag=$binding;$date.Margin=New-Object Windows.Forms.Padding(0,0,12,8);$toolbar.Controls.Add($date);$binding.DateControl=$date
  $date.Add_ValueChanged({if(-not $script:medicalClinicalBuilding -and $this.Tag.Stage -eq $script:stage){
   if(Get-Command Invoke-MedicalDiaryStartDateChanged -ErrorAction SilentlyContinue){Invoke-MedicalDiaryStartDateChanged $this.Tag $this.Value}
   else{Set-MedicalClinicalDate $this.Tag.Id $this.Value}
  }})
  if(Get-Command Add-MedicalDiaryPeriodControls -ErrorAction SilentlyContinue){Add-MedicalDiaryPeriodControls $toolbar $binding $context $dateLabel}
 }
 $edit=New-Object Windows.Forms.Button;$edit.Text=if($stage -eq 'diary'){'Форма этого дневника'}else{'Форма эпикриза'};$edit.Width=195;$edit.Height=34;$edit.Margin=New-Object Windows.Forms.Padding(0,0,10,8);$edit.Tag=$binding
 $edit.Add_Click({Invoke-MedicalSelectClinicalContext $this.Tag.Stage $this.Tag.Id;Invoke-MedicalFormTemplateEditor});$toolbar.Controls.Add($edit)
 $card.Controls.Add($toolbar)
 if(-not $context.Schema.AutoTemplate -and -not [IO.File]::Exists($templatePath)){
  $hint=New-Object Windows.Forms.Label;$hint.AutoSize=$true;$hint.Text='Word-шаблон не найден. Ответы доступны; выберите шаблон через «Форма этого дневника» / «Форма эпикриза» или «Шаблоны».';$hint.MaximumSize=New-Object Drawing.Size(([Math]::Max(500,$panel.ClientSize.Width-140)),0);$hint.Margin=New-Object Windows.Forms.Padding(0,0,0,12);$card.Controls.Add($hint)
 }
 $completion=New-Object Windows.Forms.Label;$completion.AutoSize=$true;$completion.Margin=New-Object Windows.Forms.Padding(0,0,0,16);$card.Controls.Add($completion);$binding.CompletionLabel=$completion
 foreach($section in $context.Schema.Sections){
  $block=New-Object Windows.Forms.TableLayoutPanel;$block.ColumnCount=1;$block.AutoSize=$true;$block.AutoSizeMode='GrowAndShrink';$block.Dock='Top';$block.Margin=New-Object Windows.Forms.Padding(0,0,0,14)
  [void]$block.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
  $label=New-Object Windows.Forms.Label;$label.Text=[string]$section.Title;$label.AutoSize=$true;$label.Font=New-Object Drawing.Font('Segoe UI',12,[Drawing.FontStyle]::Bold);$label.Margin=New-Object Windows.Forms.Padding(0,8,0,10);$block.Controls.Add($label)
  foreach($field in $section.Fields){Add-MedicalClinicalField $block $binding $field}
  $card.Controls.Add($block)
 }
 return $card
}
function Invoke-MedicalSelectClinicalContext([string]$stage,[string]$id){
 if($stage -ne $script:stage){return}
 if($stage -eq 'diary'){$script:medicalActiveDiaryId=$id}
 foreach($binding in @($script:medicalClinicalBindings.Values)){
  if($binding.Heading){$binding.Heading.Text=([string]$binding.Context.Title+$(if($binding.Stage -eq 'diary' -and $binding.Id -eq $script:medicalActiveDiaryId){' • выбран для редактирования формы'}else{''}))}
 }
}
function Invoke-MedicalAddDiary {
 if(-not $script:medicalWorkspaceReady){return}
 Capture-Stage
 $context=Add-MedicalClinicalDiary
 $script:stage='diary';$script:medicalActiveDiaryId=[string]$context.Id
 Open-MedicalClinicalStage
 if($script:medicalClinicalBindings.ContainsKey($script:medicalActiveDiaryId)){$panel.ScrollControlIntoView($script:medicalClinicalBindings[$script:medicalActiveDiaryId].Heading)}
 Request-MedicalClinicalCheckpoint
}
function Open-MedicalClinicalStage {
 Remove-MedicalEndAction
 if($newDiary -and $newDiary.Parent){$newDiary.Parent.Controls.Remove($newDiary)}
 $script:medicalClinicalBuilding=$true;$script:medicalClinicalWordFieldCache=@{};$panel.SuspendLayout()
 try{
  $panel.AutoScrollPosition=New-Object Drawing.Point(0,0);$panel.AutoScrollMinSize=New-Object Drawing.Size(0,0)
  $script:universalFlow=$null;$script:universalInputs=@{};$script:universalDetailInputs=@{};$script:universalIndicators=@{};$script:universalMultiInputs=@{};$script:universalRepeatInputs=@{}
  $script:controls=@();$script:fields=@();$script:medicalClinicalBindings=@{};$script:medicalClinicalFlow=$null;$script:medicalTreatmentPeriodControls=$null
  Clear-MedicalWorkspacePanels
  $flow=New-Object Windows.Forms.TableLayoutPanel;$flow.Location=New-Object Drawing.Point(20,15);$flow.ColumnCount=1;$flow.RowCount=0;$flow.AutoSize=$true;$flow.AutoSizeMode='GrowAndShrink';$flow.Anchor='Top,Left';$flow.Padding=New-Object Windows.Forms.Padding(10);$flow.Margin=New-Object Windows.Forms.Padding(0)
  [void]$flow.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
  $title=New-Object Windows.Forms.Label;$title.Text=if($script:stage -eq 'diary'){'Дневники наблюдения'}else{'Выписной эпикриз'};$title.AutoSize=$true;$title.Font=New-Object Drawing.Font('Segoe UI',18,[Drawing.FontStyle]::Bold);$title.Margin=New-Object Windows.Forms.Padding(0,0,0,12);$flow.Controls.Add($title)
  $hint=New-Object Windows.Forms.Label;$hint.AutoSize=$true;$hint.MaximumSize=New-Object Drawing.Size(([Math]::Max(500,$panel.ClientSize.Width-100)),0);$hint.Margin=New-Object Windows.Forms.Padding(0,0,0,18)
  if($script:stage -eq 'diary'){
   $hint.Text='Все дневники показаны ниже. Предпросмотр и «Сохранить карту» создают единый Word-файл: первичный осмотр, все дневники, затем выписной эпикриз. «Сохранить форму» сохраняет их структуру и шаблоны; «Сохранить карту» — введённые ответы. Поля и Word-шаблон каждого дневника редактируются его кнопкой.'
   $flow.Controls.Add($hint);$flow.Controls.Add((New-MedicalTreatmentPeriodPanel $true))
   $contexts=@(Get-MedicalClinicalDiaryContexts)
   if(-not $contexts.Count){$empty=New-Object Windows.Forms.Label;$empty.Text='Дневников пока нет. Нажмите «Добавить дневник».';$empty.AutoSize=$true;$empty.Margin=New-Object Windows.Forms.Padding(0,0,0,14);$flow.Controls.Add($empty)}
   foreach($context in $contexts){$flow.Controls.Add((New-MedicalClinicalRecordPanel $context 'diary'))}
   if($newDiary){$newDiary.Text='+ Добавить дневник';$newDiary.Width=260;$newDiary.Height=42;$newDiary.Dock='None';$newDiary.Anchor='Top,Left';$newDiary.TextAlign='MiddleLeft';$newDiary.Visible=$true;$newDiary.Margin=New-Object Windows.Forms.Padding(0,4,0,10);$flow.Controls.Add($newDiary)}
  }else{
   $hint.Text='Ф.И.О., дата рождения, адрес, жалобы, анамнез и первоначальный осмотр подтягиваются из первичного осмотра. Любое поле можно изменить: ручные исправления эпикриза сохранятся при последующих изменениях первичного осмотра.'
   $flow.Controls.Add($hint);$flow.Controls.Add((New-MedicalTreatmentPeriodPanel $false));$context=Get-MedicalClinicalContext 'discharge' '';$flow.Controls.Add((New-MedicalClinicalRecordPanel $context 'discharge'))
   if($newDiary){$newDiary.Visible=$false}
  }
  $panel.Controls.Add($flow);$script:medicalClinicalFlow=$flow
  Set-DarkTheme $flow;$flow.BackColor=$script:darkBg
  Resize-MedicalClinicalForm
  $panel.AutoScrollPosition=New-Object Drawing.Point(0,0)
 }finally{$script:medicalClinicalWordFieldCache=$null;$panel.ResumeLayout($true);$script:medicalClinicalBuilding=$false}
 $form.Text=('Медицинский конструктор v71 — '+$(if($script:stage -eq 'diary'){'Дневники наблюдения'}else{'Выписной эпикриз'}))
 [void](Get-MedicalActiveClinicalContext)
 Invoke-MedicalSelectClinicalContext $script:stage $script:medicalActiveDiaryId
 $save.Enabled=($script:stage -eq 'discharge' -or @(Get-MedicalClinicalDiaryContexts).Count -gt 0)
 Update-MedicalClinicalCompletion;Update-MedicalNavigation;Add-MedicalEndAction
}
function Resize-MedicalClinicalForm {
 if($script:medicalClinicalResizing -or $script:stage -eq 'initial' -or -not $script:medicalClinicalFlow -or $script:medicalClinicalFlow.IsDisposed){return}
 $width=[Math]::Max(600,($panel.ClientSize.Width-58))
 if($script:medicalClinicalFlow.Width -eq $width -and $script:medicalClinicalFlow.MinimumSize.Width -eq $width){return}
 $script:medicalClinicalResizing=$true;$script:medicalClinicalFlow.SuspendLayout()
 try{
  $script:medicalClinicalFlow.MaximumSize=New-Object Drawing.Size(0,0);$script:medicalClinicalFlow.MinimumSize=New-Object Drawing.Size($width,0);$script:medicalClinicalFlow.MaximumSize=New-Object Drawing.Size($width,0);$script:medicalClinicalFlow.Width=$width
  foreach($binding in @($script:medicalClinicalBindings.Values)){foreach($checks in $binding.MultiInputs.Values){foreach($check in $checks){$check.MaximumSize=New-Object Drawing.Size(([Math]::Max(300,$width-124)),0)}}}
 }finally{$script:medicalClinicalFlow.ResumeLayout($true);$script:medicalClinicalResizing=$false}
}
function Ensure-MedicalClinicalTemplate([string]$purpose='сохранение'){
 $context=Get-MedicalActiveClinicalContext
 if(-not $context){throw 'Добавьте дневник перед сохранением документа.'}
 if($context.Schema.AutoTemplate){return $true}
 $path=Get-UniversalTemplatePath $context.Schema
 if([IO.File]::Exists($path)){return $true}
 $relocated=Resolve-MedicalTemplateReference ([string]$context.Schema.Template) ([string]$script:caseFile)
 if($relocated){$candidate=Copy-MedicalFormSchema $context.Schema;$candidate.Template=$relocated;[void](Set-MedicalClinicalSchema $script:stage $context.Id $candidate);return $true}
 Capture-MedicalClinicalStage
 $choice=Show-MedicalTemplateRecoveryChoice $form $context.Schema $purpose
 if(-not $choice){return $false}
 [void](Set-MedicalClinicalSchema $script:stage $context.Id $choice.Schema)
 Open-MedicalClinicalStage
 return $true
}
function Export-MedicalClinicalDocument([string]$path,[bool]$allowIncomplete=$false){
 if($script:stage -eq 'diary'){Capture-MedicalClinicalStage;Export-MedicalDiariesDocument $path $allowIncomplete;return}
 Capture-MedicalClinicalStage
 $context=Get-MedicalActiveClinicalContext
 if(-not $context){throw 'Добавьте дневник перед сохранением документа.'}
 if(-not $allowIncomplete){Test-MedicalClinicalCompletion $context}
 $date=if($script:stage -eq 'diary'){$context.DateTime}else{$script:admissionControl.Value}
 Save-UniversalDocument $path $context.Schema $context.Values $date $context.Details $allowIncomplete 'discharge'
 Set-MedicalDischargePeriodDocument $path $context.Schema
}


function Save-MedicalTreatmentPeriodControls($controls,[bool]$showError=$false){
 if($script:medicalClinicalBuilding -or -not $controls -or $controls.Stage -ne $script:stage -or $controls.Start.IsDisposed -or $controls.End.IsDisposed){return $true}
 try{
  $from=Sync-MedicalClinicalDateControl $controls.Start $true 'начала лечения';$until=Sync-MedicalClinicalDateControl $controls.End $true 'окончания лечения'
  if($until -lt $from){throw 'Дата окончания лечения не может быть раньше даты начала.'}
  $current=Get-MedicalTreatmentPeriod
  if($from.ToString('yyyy-MM-dd') -cne [string]$current.StartDate -or $until.ToString('yyyy-MM-dd') -cne [string]$current.EndDate){[void](Set-MedicalTreatmentPeriod $from $until)}
  $controls.Status.ForeColor=$script:darkMuted
  $controls.Status.Text=if($controls.Stage -eq 'diary'){'Первый дневник — на следующий день после поступления, последний — в дату окончания. Уже существующие даты пропускаются.'}else{'В эпикризе период лечения выводится без времени. Эти даты можно изменить независимо от первичного осмотра.'}
  return $true
 }catch{
  $controls.Status.ForeColor=$script:uiDanger;$controls.Status.Text=$_.Exception.Message
  if($showError){throw}
  return $false
 }
}
function Capture-MedicalTreatmentPeriodControls {
 $controls=$script:medicalTreatmentPeriodControls
 if($controls -and $controls.Stage -eq $script:stage -and -not $controls.Start.IsDisposed -and -not $controls.End.IsDisposed){[void](Save-MedicalTreatmentPeriodControls $controls $true)}
}
function Invoke-MedicalDiaryPeriod {
 if(-not $script:medicalWorkspaceReady -or $script:stage -ne 'diary'){return}
 $controls=$script:medicalTreatmentPeriodControls;if(-not $controls){return}
 try{
  Capture-Stage
  $result=Add-MedicalClinicalDiaryPeriod $controls.Start.Value $controls.End.Value
  if($result.DiaryIds.Count){$script:medicalActiveDiaryId=[string]$result.DiaryIds[0]}
  Open-MedicalClinicalStage
  $message='Назначены даты существующим пустым дневникам: '+$result.ReusedCount+'. Добавлено дневников: '+$result.AddedCount+'. Уже существующих дат пропущено: '+$result.SkippedCount+'.'
  if($result.RemainingBlankCount -gt 0){$message+=' Пустых заготовок вне периода: '+$result.RemainingBlankCount+'; в Word не включаются до заполнения или назначения даты.'}
  $script:medicalTreatmentPeriodControls.Status.Text=$message
  Request-MedicalClinicalCheckpoint
 }catch{[Windows.Forms.MessageBox]::Show($_.Exception.Message,'Период дневников')|Out-Null}
}
function New-MedicalTreatmentPeriodPanel([bool]$withDiaryGeneration=$false){
 $period=Get-MedicalTreatmentPeriod
 $block=New-Object MedicalOutlineTable;$block.ColumnCount=1;$block.AutoSize=$true;$block.AutoSizeMode='GrowAndShrink';$block.Dock='Top';$block.Padding=New-Object Windows.Forms.Padding(14);$block.Margin=New-Object Windows.Forms.Padding(0,0,0,18)
 [void]$block.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
 $heading=New-Object Windows.Forms.Label;$heading.Text='Период лечения';$heading.AutoSize=$true;$heading.Font=New-Object Drawing.Font('Segoe UI',12,[Drawing.FontStyle]::Bold);$heading.Margin=New-Object Windows.Forms.Padding(0,0,0,10);$block.Controls.Add($heading)
 $row=New-Object Windows.Forms.FlowLayoutPanel;$row.AutoSize=$true;$row.WrapContents=$true;$row.Dock='Top';$row.Margin=New-Object Windows.Forms.Padding(0,0,0,8)
 $fromLabel=New-Object Windows.Forms.Label;$fromLabel.Text='С';$fromLabel.AutoSize=$true;$fromLabel.Margin=New-Object Windows.Forms.Padding(0,8,10,0);$row.Controls.Add($fromLabel)
 $start=New-Object Windows.Forms.DateTimePicker;$start.Format='Custom';$start.CustomFormat='dd.MM.yyyy';$start.Width=155;$start.Value=ConvertTo-MedicalTreatmentDate $period.StartDate 'начала лечения';$start.Margin=New-Object Windows.Forms.Padding(0,0,20,8);$row.Controls.Add($start)
 $toLabel=New-Object Windows.Forms.Label;$toLabel.Text='По';$toLabel.AutoSize=$true;$toLabel.Margin=New-Object Windows.Forms.Padding(0,8,10,0);$row.Controls.Add($toLabel)
 $end=New-Object Windows.Forms.DateTimePicker;$end.Format='Custom';$end.CustomFormat='dd.MM.yyyy';$end.Width=155;$end.Value=ConvertTo-MedicalTreatmentDate $period.EndDate 'окончания лечения';$end.Margin=New-Object Windows.Forms.Padding(0,0,14,8);$row.Controls.Add($end)
 $status=New-Object Windows.Forms.Label;$status.AutoSize=$true;$status.MaximumSize=New-Object Drawing.Size(([Math]::Max(500,$panel.ClientSize.Width-150)),0);$status.Margin=New-Object Windows.Forms.Padding(0,0,0,8)
 $status.Text=if($withDiaryGeneration){'Первый дневник — на следующий день после поступления, последний — в дату окончания. Уже существующие даты пропускаются.'}else{'В эпикризе период лечения выводится без времени. Эти даты можно изменить независимо от первичного осмотра.'}
 $controls=[pscustomobject]@{Stage=[string]$script:stage;Start=$start;End=$end;GenerateButton=$null;Status=$status}
 $start.Tag=$controls;$end.Tag=$controls
 $start.Add_ValueChanged({[void](Save-MedicalTreatmentPeriodControls $this.Tag)});$end.Add_ValueChanged({[void](Save-MedicalTreatmentPeriodControls $this.Tag)})
 $block.Controls.Add($row);$block.Controls.Add($status)
 if($withDiaryGeneration){
  $button=New-Object Windows.Forms.Button;$button.Text='Добавить дневники за период';$button.Width=285;$button.Height=38;$button.TextAlign='MiddleLeft';$button.Margin=New-Object Windows.Forms.Padding(0,4,0,4);$button.Add_Click({Invoke-MedicalDiaryPeriod});$block.Controls.Add($button);$controls.GenerateButton=$button
 }
 $script:medicalTreatmentPeriodControls=$controls
 return $block
}


function Sync-MedicalClinicalDateControl($control,[bool]$dateOnly,[string]$label){
 if(-not $control){throw ('Не задана дата '+$label+'.')}
 $date=[datetime]$control.Value
 $format=if($dateOnly){'dd.MM.yyyy'}else{'dd.MM.yyyy HH:mm'}
 $text=if($control.PSObject.Properties['Text']){([string]$control.Text -replace '\s+',' ').Trim()}else{''}
 if($text -and $text -cne $date.ToString($format)){
  [string[]]$formats=if($dateOnly){@('dd.MM.yyyy')}else{@('dd.MM.yyyy HH:mm','dd.MM.yyyy HH:mm:ss')}
  $parsed=[datetime]::MinValue
  if(-not [datetime]::TryParseExact($text,$formats,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$parsed)){throw ('Проверьте дату '+$label+': '+$(if($dateOnly){'ДД.ММ.ГГГГ.'}else{'ДД.ММ.ГГГГ ЧЧ:ММ.'}))}
  $control.Value=$parsed;$date=[datetime]$control.Value
 }
 if($dateOnly){return (ConvertTo-MedicalTreatmentDate $date $label)}
 if($date -lt [datetime]'1753-01-01' -or $date -gt [datetime]'9998-12-31'){throw ('Дата '+$label+' находится вне допустимого диапазона календаря.')}
 return $date
}
