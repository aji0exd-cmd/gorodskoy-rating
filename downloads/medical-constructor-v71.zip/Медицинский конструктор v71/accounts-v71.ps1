﻿# Local application accounts. Documents and exported Word files are not encrypted by this module.
# Password hashes use PBKDF2-SHA256, random 32-byte salt and 600,000 iterations.
if(-not ('MedicalAccountsV71.Security' -as [type])){
 Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
namespace MedicalAccountsV71 {
 public static class Security {
  private sealed class Ticket { internal string Root; internal string Id; internal string Revision; }
  private static readonly Dictionary<string,Ticket> Tickets = new Dictionary<string,Ticket>(StringComparer.Ordinal);
  public static byte[] Random(int count) { byte[] value=new byte[count]; using(RandomNumberGenerator rng=RandomNumberGenerator.Create()){rng.GetBytes(value);} return value; }
  public static byte[] Derive(string password,byte[] salt,int iterations) {
   byte[] bytes=new UTF8Encoding(false,true).GetBytes(password);
   try {
    Type algorithm=typeof(Rfc2898DeriveBytes).Assembly.GetType("System.Security.Cryptography.HashAlgorithmName");
    if(algorithm==null) algorithm=Type.GetType("System.Security.Cryptography.HashAlgorithmName, System.Security.Cryptography.Primitives");
    if(algorithm!=null){
     ConstructorInfo ctor=typeof(Rfc2898DeriveBytes).GetConstructor(new Type[]{typeof(byte[]),typeof(byte[]),typeof(int),algorithm});
     PropertyInfo sha=algorithm.GetProperty("SHA256",BindingFlags.Public|BindingFlags.Static);
     if(ctor!=null && sha!=null){using(Rfc2898DeriveBytes kdf=(Rfc2898DeriveBytes)ctor.Invoke(new object[]{bytes,salt,iterations,sha.GetValue(null,null)})){return kdf.GetBytes(32);}}
    }
    // Windows .NET Framework versions without the SHA256 constructor.
    using(HMACSHA256 hmac=new HMACSHA256(bytes)){
     byte[] block=new byte[salt.Length+4];Buffer.BlockCopy(salt,0,block,0,salt.Length);block[block.Length-1]=1;
     byte[] u=hmac.ComputeHash(block);byte[] result=(byte[])u.Clone();
     for(int i=1;i<iterations;i++){byte[] next=hmac.ComputeHash(u);Array.Clear(u,0,u.Length);u=next;for(int j=0;j<result.Length;j++){result[j]^=u[j];}}
     Array.Clear(u,0,u.Length);Array.Clear(block,0,block.Length);return result;
    }
   } finally {Array.Clear(bytes,0,bytes.Length);}
  }
  public static bool Equal(byte[] a,byte[] b){if(a==null||b==null)return false;int difference=a.Length^b.Length;int length=Math.Max(a.Length,b.Length);for(int i=0;i<length;i++){difference|=(i<a.Length?a[i]:0)^(i<b.Length?b[i]:0);}return difference==0;}
  public static string Issue(string root,string id,string revision){string token=Convert.ToBase64String(Random(48));lock(Tickets){Tickets[token]=new Ticket{Root=root,Id=id,Revision=revision};}return token;}
  public static bool Check(string token,string root,string id,string revision){if(String.IsNullOrEmpty(token))return false;lock(Tickets){Ticket value;return Tickets.TryGetValue(token,out value)&&String.Equals(value.Root,root,StringComparison.Ordinal)&&String.Equals(value.Id,id,StringComparison.Ordinal)&&String.Equals(value.Revision,revision,StringComparison.Ordinal);}}
  public static void Revoke(string token){if(token==null)return;lock(Tickets){Tickets.Remove(token);}}
 }
}
'@
}
function Initialize-MedicalAccounts([Parameter(Mandatory=$true)][string]$Root){
 $full=[IO.Path]::GetFullPath($Root)
 if(-not [IO.Directory]::Exists($full)){throw 'Папка программы не найдена.'}
 $folder=[IO.Path]::Combine($full,'Учетные записи');[void][IO.Directory]::CreateDirectory($folder)
 return [pscustomobject]@{Root=$full;AccountsDirectory=$folder;DatabasePath=[IO.Path]::Combine($folder,'accounts.json');BackupPath=[IO.Path]::Combine($folder,'accounts.last-good.json');LockPath=[IO.Path]::Combine($folder,'accounts.lock')}
}
function Assert-MedicalAccountsContext($Context){
 if($null -eq $Context -or $Context.Root -isnot [string] -or $Context.DatabasePath -isnot [string]){throw 'Неверная папка учетных записей.'}
 $root=[IO.Path]::GetFullPath($Context.Root);$folder=[IO.Path]::Combine($root,'Учетные записи')
 if($Context.Root -cne $root -or $Context.AccountsDirectory -cne $folder -or $Context.DatabasePath -cne [IO.Path]::Combine($folder,'accounts.json') -or $Context.BackupPath -cne [IO.Path]::Combine($folder,'accounts.last-good.json') -or $Context.LockPath -cne [IO.Path]::Combine($folder,'accounts.lock')){throw 'Неверная папка учетных записей.'}
}
function Enter-MedicalAccountsLock($Context){
 Assert-MedicalAccountsContext $Context
 $watch=[Diagnostics.Stopwatch]::StartNew()
 while($true){
  try{return [IO.File]::Open($Context.LockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}
  catch [IO.IOException]{if($watch.ElapsedMilliseconds -ge 5000){throw 'Учетные записи заняты другим экземпляром программы. Повторите попытку.'};[Threading.Thread]::Sleep(40)}
 }
}
function Assert-MedicalAccountsProperties($Value,[string[]]$Names){
 if($null -eq $Value -or $Value -isnot [pscustomobject]){throw 'Неверный формат базы учетных записей.'}
 $actual=@($Value.PSObject.Properties.Name)
 if($actual.Count -ne $Names.Count){throw 'Неверный формат базы учетных записей.'}
 foreach($name in $Names){if(-not ($actual -ccontains $name)){throw 'Неверный формат базы учетных записей.'}}
}
function Test-MedicalAccountUtc($Value,[bool]$Nullable=$false){
 if($Nullable -and $null -eq $Value){return $true}
 if($Value -isnot [string] -or $Value -notmatch '^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{7}Z$'){return $false}
 $parsed=[datetime]::MinValue
 return [datetime]::TryParseExact($Value,'yyyy-MM-dd HH:mm:ss.fffffffZ',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::AssumeUniversal,[ref]$parsed)
}
function Get-MedicalAccountsUtc {return [datetime]::UtcNow.ToString('yyyy-MM-dd HH:mm:ss.fffffffZ',[Globalization.CultureInfo]::InvariantCulture)}
function Get-MedicalNormalizedUsername([string]$Username){
 if($null -eq $Username){throw 'Введите имя учетной записи.'}
 $value=$Username.Trim().Normalize([Text.NormalizationForm]::FormKC)
 if($value.Length -lt 3 -or $value.Length -gt 64 -or $value -notmatch '^[\p{L}\p{Nd}._-]+$'){throw 'Имя учетной записи: 3–64 буквы, цифры, точки, дефисы или знаки подчеркивания.'}
 return $value.ToUpperInvariant()
}
function Assert-MedicalAccountPassword([string]$Password){
 if($null -eq $Password -or $Password.Length -lt 10 -or $Password.Length -gt 1024 -or [string]::IsNullOrWhiteSpace($Password)){throw 'Пароль должен содержать от 10 до 1024 символов и не состоять только из пробелов.'}
}
function New-MedicalAccountPassword([string]$Password){
 Assert-MedicalAccountPassword $Password
 $salt=[MedicalAccountsV71.Security]::Random(32);$hash=[MedicalAccountsV71.Security]::Derive($Password,$salt,600000)
 try{return [pscustomobject]@{Algorithm='PBKDF2-SHA256';Iterations=600000;Salt=[Convert]::ToBase64String($salt);Hash=[Convert]::ToBase64String($hash)}}finally{[Array]::Clear($hash,0,$hash.Length)}
}
function Test-MedicalAccountPassword([string]$Password,$Verifier){
 if($null -eq $Password -or $Password.Length -gt 1024){$Password=''}
 $actual=[MedicalAccountsV71.Security]::Derive($Password,[Convert]::FromBase64String($Verifier.Salt),[int]$Verifier.Iterations)
 $expected=[Convert]::FromBase64String($Verifier.Hash)
 try{return [MedicalAccountsV71.Security]::Equal($actual,$expected)}finally{[Array]::Clear($actual,0,$actual.Length);[Array]::Clear($expected,0,$expected.Length)}
}
function Assert-MedicalAccountsDatabase($Database){
 Assert-MedicalAccountsProperties $Database @('Version','Revision','CreatedUtc','UpdatedUtc','LoginFailures','LoginLockedUntilUtc','Accounts')
 if($Database.Version -isnot [long] -and $Database.Version -isnot [int]){throw 'Неверный формат базы учетных записей.'}
 if($Database.Version -ne 1 -or $Database.Revision -isnot [string] -or $Database.Revision -cnotmatch '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'){throw 'Неподдерживаемая версия базы учетных записей.'}
 if(-not (Test-MedicalAccountUtc $Database.CreatedUtc) -or -not (Test-MedicalAccountUtc $Database.UpdatedUtc) -or -not (Test-MedicalAccountUtc $Database.LoginLockedUntilUtc $true)){throw 'Неверный формат времени в базе учетных записей.'}
 if(($Database.LoginFailures -isnot [int] -and $Database.LoginFailures -isnot [long]) -or $Database.LoginFailures -lt 0 -or $Database.LoginFailures -gt 1000){throw 'Неверный формат защиты входа.'}
 if($Database.Accounts -isnot [Array] -or $Database.Accounts.Count -lt 1 -or $Database.Accounts.Count -gt 200){throw 'Неверный список учетных записей.'}
 $ids=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal);$names=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal);$admins=0
 foreach($account in $Database.Accounts){
  Assert-MedicalAccountsProperties $account @('Id','Username','NormalizedUsername','DisplayName','Role','Enabled','PasswordRevision','Password','CreatedUtc')
  if($account.Id -isnot [string] -or $account.Id -cnotmatch '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' -or -not $ids.Add($account.Id)){throw 'Неверный идентификатор учетной записи.'}
  if($account.Username -isnot [string] -or $account.NormalizedUsername -isnot [string] -or (Get-MedicalNormalizedUsername $account.Username) -cne $account.NormalizedUsername -or -not $names.Add($account.NormalizedUsername)){throw 'Повторяющееся или неверное имя учетной записи.'}
  if($account.DisplayName -isnot [string] -or [string]::IsNullOrWhiteSpace($account.DisplayName) -or $account.DisplayName.Length -gt 128){throw 'Неверное отображаемое имя учетной записи.'}
  if(@('Administrator','User') -cnotcontains $account.Role -or $account.Enabled -isnot [bool] -or $account.PasswordRevision -isnot [string] -or $account.PasswordRevision -cnotmatch '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' -or -not (Test-MedicalAccountUtc $account.CreatedUtc)){throw 'Неверные права учетной записи.'}
  Assert-MedicalAccountsProperties $account.Password @('Algorithm','Iterations','Salt','Hash')
  if($account.Password.Algorithm -cne 'PBKDF2-SHA256' -or ($account.Password.Iterations -isnot [int] -and $account.Password.Iterations -isnot [long]) -or $account.Password.Iterations -lt 300000 -or $account.Password.Iterations -gt 2000000 -or $account.Password.Salt -isnot [string] -or $account.Password.Hash -isnot [string]){throw 'Неверный формат защиты пароля.'}
  try{$salt=[Convert]::FromBase64String($account.Password.Salt);$hash=[Convert]::FromBase64String($account.Password.Hash)}catch{throw 'Неверный формат защиты пароля.'}
  if($salt.Length -ne 32 -or $hash.Length -ne 32 -or [Convert]::ToBase64String($salt) -cne $account.Password.Salt -or [Convert]::ToBase64String($hash) -cne $account.Password.Hash){throw 'Неверный формат защиты пароля.'}
  if($account.Enabled -and $account.Role -ceq 'Administrator'){$admins++}
 }
 if($admins -lt 1){throw 'В базе должен оставаться хотя бы один активный администратор.'}
}
function Read-MedicalAccountsDatabase($Context,[bool]$AllowEmpty=$false){
 if(-not [IO.File]::Exists($Context.DatabasePath)){
  if([IO.File]::Exists($Context.BackupPath)){throw 'Основная база учетных записей отсутствует. Для безопасности вход закрыт; сохранена последняя исправная резервная копия.'}
  if($AllowEmpty){return $null};throw 'Сначала создайте учетную запись администратора.'
 }
 try{
  # Bound allocation on the opened file itself, avoiding a metadata/read race.
  $stream=[IO.File]::Open($Context.DatabasePath,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
  try{
   if($stream.Length -lt 2 -or $stream.Length -gt 1048576){throw 'Недопустимый размер базы.'}
   $bytes=New-Object byte[] ([int]$stream.Length);$offset=0
   while($offset -lt $bytes.Length){$read=$stream.Read($bytes,$offset,$bytes.Length-$offset);if($read -le 0){throw 'База прочитана не полностью.'};$offset+=$read}
   if($stream.ReadByte() -ne -1){throw 'Размер базы изменился при чтении.'}
  }finally{$stream.Dispose()}
  $text=(New-Object Text.UTF8Encoding($false,$true)).GetString($bytes).TrimStart([char]0xfeff)
  $db=ConvertFrom-Json -InputObject $text -ErrorAction Stop
  Assert-MedicalAccountsDatabase $db
  return $db
 }catch{throw 'База учетных записей повреждена или имеет неподдерживаемый формат. Вход закрыт. Не удаляйте базу; используйте последнюю исправную резервную копию.'}
}
function Write-MedicalAccountsDatabase($Context,$Database){
 Assert-MedicalAccountsDatabase $Database
 $Database.UpdatedUtc=Get-MedicalAccountsUtc;$Database.Revision=[guid]::NewGuid().ToString('D')
 $text=ConvertTo-Json -InputObject $Database -Depth 12
 $bytes=(New-Object Text.UTF8Encoding($false,$true)).GetBytes($text)
 if($bytes.Length -gt 1048576){throw 'База учетных записей слишком велика.'}
 $temporary=[IO.Path]::Combine($Context.AccountsDirectory,('accounts-'+[guid]::NewGuid().ToString('N')+'.tmp'))
 try{
  $stream=[IO.File]::Open($temporary,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
  try{$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)}finally{$stream.Dispose()}
  $verifiedBytes=[IO.File]::ReadAllBytes($temporary)
  if(-not [MedicalAccountsV71.Security]::Equal($bytes,$verifiedBytes)){throw 'Не удалось проверить сохраненные учетные записи.'}
  $verified=ConvertFrom-Json -InputObject ((New-Object Text.UTF8Encoding($false,$true)).GetString($verifiedBytes)) -ErrorAction Stop
  Assert-MedicalAccountsDatabase $verified
  if($verified.Revision -cne $Database.Revision){throw 'Не удалось проверить сохраненные учетные записи.'}
  if([IO.File]::Exists($Context.DatabasePath)){
   # Validate the current file before it becomes the last-good backup.
   $null=Read-MedicalAccountsDatabase $Context
   [IO.File]::Replace($temporary,$Context.DatabasePath,$Context.BackupPath,$true)
  }else{
   # A missing primary after first setup must never be mistaken for a fresh installation.
   [IO.File]::Copy($temporary,$Context.BackupPath,$false)
   if(-not [MedicalAccountsV71.Security]::Equal($bytes,[IO.File]::ReadAllBytes($Context.BackupPath))){throw 'Не удалось проверить резервную копию учетных записей.'}
   [IO.File]::Move($temporary,$Context.DatabasePath)
  }
 }finally{if([IO.File]::Exists($temporary)){[IO.File]::Delete($temporary)}}
}
function Get-MedicalAccountsState($Context){
 $lock=Enter-MedicalAccountsLock $Context
 try{$db=Read-MedicalAccountsDatabase $Context $true;return [pscustomobject]@{IsInitialized=($null -ne $db);Count=$(if($null -eq $db){0}else{$db.Accounts.Count})}}finally{$lock.Dispose()}
}
function New-MedicalAccountRecord([string]$Username,[string]$DisplayName,[string]$Password,[string]$Role){
 $normal=Get-MedicalNormalizedUsername $Username
 if([string]::IsNullOrWhiteSpace($DisplayName) -or $DisplayName.Trim().Length -gt 128){throw 'Укажите имя сотрудника длиной до 128 символов.'}
 if(@('Administrator','User') -cnotcontains $Role){throw 'Неверная роль учетной записи.'}
 return [pscustomobject]@{Id=[guid]::NewGuid().ToString('D');Username=$Username.Trim().Normalize([Text.NormalizationForm]::FormKC);NormalizedUsername=$normal;DisplayName=$DisplayName.Trim();Role=$Role;Enabled=$true;PasswordRevision=[guid]::NewGuid().ToString('D');Password=(New-MedicalAccountPassword $Password);CreatedUtc=(Get-MedicalAccountsUtc)}
}
function New-MedicalAccountSession($Context,$Account){
 $token=[MedicalAccountsV71.Security]::Issue($Context.DatabasePath,$Account.Id,$Account.PasswordRevision)
 return [pscustomobject]@{UserId=$Account.Id;Username=$Account.Username;DisplayName=$Account.DisplayName;Role=$Account.Role;DataRoot=[IO.Path]::Combine($Context.Root,'Данные',$Account.Id);Context=$Context;AuthenticatedAt=(Get-MedicalAccountsUtc);Token=$token}
}
function New-MedicalFirstAdministrator($Context,[string]$Username,[string]$DisplayName,[string]$Password){
 $lock=Enter-MedicalAccountsLock $Context
 try{
  if($null -ne (Read-MedicalAccountsDatabase $Context $true)){throw 'Администратор уже создан. Выполните вход.'}
  $account=New-MedicalAccountRecord $Username $DisplayName $Password 'Administrator';$now=Get-MedicalAccountsUtc
  $db=[pscustomobject]@{Version=1;Revision=[guid]::NewGuid().ToString('D');CreatedUtc=$now;UpdatedUtc=$now;LoginFailures=0;LoginLockedUntilUtc=$null;Accounts=@($account)}
  Write-MedicalAccountsDatabase $Context $db
  return New-MedicalAccountSession $Context $account
 }finally{$lock.Dispose()}
}
function Invoke-MedicalAccountLogin($Context,[string]$Username,[string]$Password){
 $failure='Не удалось войти. Проверьте имя и пароль или повторите попытку позже.'
 $lock=Enter-MedicalAccountsLock $Context
 try{
  $db=Read-MedicalAccountsDatabase $Context
  if($null -ne $db.LoginLockedUntilUtc -and [datetime]::Parse($db.LoginLockedUntilUtc,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::AssumeUniversal).ToUniversalTime() -gt [datetime]::UtcNow){throw $failure}
  $normal='';try{$normal=Get-MedicalNormalizedUsername $Username}catch{}
  $account=$null;foreach($candidate in $db.Accounts){if($candidate.NormalizedUsername -ceq $normal){$account=$candidate;break}}
  # Unknown and disabled names do the same expensive derivation as valid names.
  $verifier=if($null -ne $account){$account.Password}else{$db.Accounts[0].Password}
  $matches=Test-MedicalAccountPassword $Password $verifier
  if($null -eq $account -or -not $account.Enabled -or -not $matches){
   $db.LoginFailures=[Math]::Min(1000,[int]$db.LoginFailures+1)
   if($db.LoginFailures -ge 5){$seconds=[Math]::Min(300,30*[Math]::Pow(2,[Math]::Min(4,$db.LoginFailures-5)));$db.LoginLockedUntilUtc=[datetime]::UtcNow.AddSeconds($seconds).ToString('yyyy-MM-dd HH:mm:ss.fffffffZ',[Globalization.CultureInfo]::InvariantCulture)}
   Write-MedicalAccountsDatabase $Context $db
   throw $failure
  }
  if($db.LoginFailures -ne 0 -or $null -ne $db.LoginLockedUntilUtc){$db.LoginFailures=0;$db.LoginLockedUntilUtc=$null;Write-MedicalAccountsDatabase $Context $db}
  return New-MedicalAccountSession $Context $account
 }finally{$lock.Dispose()}
}
function Get-MedicalAccountForSession($Database,$Session,[bool]$Administrator=$false){
 if($null -eq $Session -or $null -eq $Session.Context -or $Session.Token -isnot [string] -or $Session.UserId -isnot [string]){throw 'Выполните вход в программу.'}
 $account=$null;foreach($candidate in $Database.Accounts){if($candidate.Id -ceq $Session.UserId){$account=$candidate;break}}
 if($null -eq $account -or -not $account.Enabled -or -not [MedicalAccountsV71.Security]::Check($Session.Token,$Session.Context.DatabasePath,$account.Id,$account.PasswordRevision)){throw 'Сеанс завершен или учетная запись отключена. Выполните вход снова.'}
 $Session.Username=$account.Username;$Session.DisplayName=$account.DisplayName;$Session.Role=$account.Role;$Session.DataRoot=[IO.Path]::Combine($Session.Context.Root,'Данные',$account.Id)
 if($Administrator -and $account.Role -cne 'Administrator'){throw 'Действие доступно только администратору.'}
 return $account
}
function Assert-MedicalAdministrator($Session){
 if($null -eq $Session -or $null -eq $Session.Context){throw 'Выполните вход в программу.'}
 $lock=Enter-MedicalAccountsLock $Session.Context
 try{$db=Read-MedicalAccountsDatabase $Session.Context;$null=Get-MedicalAccountForSession $db $Session $true;return $true}finally{$lock.Dispose()}
}
function Test-MedicalSession($Session){
 if($null -eq $Session -or $null -eq $Session.Context){return $false}
 try{$lock=Enter-MedicalAccountsLock $Session.Context;try{$db=Read-MedicalAccountsDatabase $Session.Context;$null=Get-MedicalAccountForSession $db $Session;return $true}finally{$lock.Dispose()}}catch{return $false}
}
function Close-MedicalSession($Session){if($null -ne $Session){[MedicalAccountsV71.Security]::Revoke([string]$Session.Token)}}
function ConvertTo-MedicalPublicAccount($Account){return [pscustomobject]@{Id=$Account.Id;Username=$Account.Username;DisplayName=$Account.DisplayName;Role=$Account.Role;Enabled=$Account.Enabled}}
function Get-MedicalAccounts($Session){
 $lock=Enter-MedicalAccountsLock $Session.Context
 try{$db=Read-MedicalAccountsDatabase $Session.Context;$null=Get-MedicalAccountForSession $db $Session $true;return @($db.Accounts|ForEach-Object{ConvertTo-MedicalPublicAccount $_})}finally{$lock.Dispose()}
}
function New-MedicalUserAccount($Session,[string]$Username,[string]$DisplayName,[string]$Password,[string]$Role='User'){
 $lock=Enter-MedicalAccountsLock $Session.Context
 try{
  $db=Read-MedicalAccountsDatabase $Session.Context;$null=Get-MedicalAccountForSession $db $Session $true
  if($db.Accounts.Count -ge 200){throw 'Достигнут предел: 200 учетных записей.'}
  $normal=Get-MedicalNormalizedUsername $Username;foreach($existing in $db.Accounts){if($existing.NormalizedUsername -ceq $normal){throw 'Такое имя учетной записи уже используется.'}}
  $record=New-MedicalAccountRecord $Username $DisplayName $Password $Role;$db.Accounts=@($db.Accounts)+@($record);Write-MedicalAccountsDatabase $Session.Context $db
  return ConvertTo-MedicalPublicAccount $record
 }finally{$lock.Dispose()}
}
function Find-MedicalAccountById($Database,[string]$UserId){foreach($account in $Database.Accounts){if($account.Id -ceq $UserId){return $account}};throw 'Учетная запись не найдена.'}
function Set-MedicalAccountEnabled($Session,[string]$UserId,[bool]$Enabled){
 $lock=Enter-MedicalAccountsLock $Session.Context
 try{$db=Read-MedicalAccountsDatabase $Session.Context;$null=Get-MedicalAccountForSession $db $Session $true;$account=Find-MedicalAccountById $db $UserId;$account.Enabled=$Enabled;if(-not $Enabled){$account.PasswordRevision=[guid]::NewGuid().ToString('D')};Assert-MedicalAccountsDatabase $db;Write-MedicalAccountsDatabase $Session.Context $db;return ConvertTo-MedicalPublicAccount $account}finally{$lock.Dispose()}
}
function Set-MedicalAccountRole($Session,[string]$UserId,[string]$Role){
 if(@('Administrator','User') -cnotcontains $Role){throw 'Неверная роль учетной записи.'}
 $lock=Enter-MedicalAccountsLock $Session.Context
 try{$db=Read-MedicalAccountsDatabase $Session.Context;$null=Get-MedicalAccountForSession $db $Session $true;$account=Find-MedicalAccountById $db $UserId;$account.Role=$Role;Assert-MedicalAccountsDatabase $db;Write-MedicalAccountsDatabase $Session.Context $db;return ConvertTo-MedicalPublicAccount $account}finally{$lock.Dispose()}
}
function Reset-MedicalAccountPassword($Session,[string]$UserId,[string]$NewPassword){
 $lock=Enter-MedicalAccountsLock $Session.Context
 try{$db=Read-MedicalAccountsDatabase $Session.Context;$null=Get-MedicalAccountForSession $db $Session $true;$account=Find-MedicalAccountById $db $UserId;$account.Password=New-MedicalAccountPassword $NewPassword;$account.PasswordRevision=[guid]::NewGuid().ToString('D');Write-MedicalAccountsDatabase $Session.Context $db}finally{$lock.Dispose()}
}
function Set-MedicalOwnPassword($Session,[string]$CurrentPassword,[string]$NewPassword){
 $lock=Enter-MedicalAccountsLock $Session.Context
 try{
  $db=Read-MedicalAccountsDatabase $Session.Context;$account=Get-MedicalAccountForSession $db $Session
  if(-not (Test-MedicalAccountPassword $CurrentPassword $account.Password)){throw 'Текущий пароль неверен.'}
  $account.Password=New-MedicalAccountPassword $NewPassword;$account.PasswordRevision=[guid]::NewGuid().ToString('D');Write-MedicalAccountsDatabase $Session.Context $db
  [MedicalAccountsV71.Security]::Revoke($Session.Token);$Session.Token=[MedicalAccountsV71.Security]::Issue($Session.Context.DatabasePath,$account.Id,$account.PasswordRevision)
  return $Session
 }finally{$lock.Dispose()}
}

function Assert-MedicalAccountSession($Session){
 if($null -eq $Session -or $null -eq $Session.Context){throw 'Выполните вход в программу.'}
 $lock=Enter-MedicalAccountsLock $Session.Context
 try{$db=Read-MedicalAccountsDatabase $Session.Context;$null=Get-MedicalAccountForSession $db $Session;return $Session}finally{$lock.Dispose()}
}
