﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v71'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-NativeOcr([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
function Assert-NativeOcrThrows([scriptblock]$action,[string]$pattern,[string]$message){$errorText='';try{& $action}catch{$errorText=[string]$_.Exception.Message};Assert-NativeOcr ($errorText -match $pattern) ($message+' ['+$errorText+']')}
# API-shaped test adapter. Runs real PowerShell bridge/OCR control flow, not native Windows OCR.
# Signatures match Microsoft's generated windows-rs WinRT metadata:
# https://github.com/microsoft/windows-rs/blob/master/crates/libs/windows/src/Windows/Storage/mod.rs
# https://github.com/microsoft/windows-rs/blob/master/crates/libs/windows/src/Windows/Data/Pdf/mod.rs
# StorageFile.OpenAsync -> IAsyncOperation<IRandomAccessStream>; OpenReadAsync -> WithContentType.
# PdfDocument has no IClosable; PdfPage, bitmap and streams implement disposal.
if('System.WindowsRuntimeSystemExtensions' -as [type]){throw 'Run this isolated adapter suite in a fresh PowerShell process before loading native WinRT.'}
$source=@'
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace Windows.Foundation {
 public interface IAsyncAction {void Cancel();}
 public interface IAsyncOperation<T> {void Cancel();}
 public struct Size {public double Width; public double Height;}
}
namespace NativeOcrFixture {
 public class Operation<T>:Windows.Foundation.IAsyncOperation<T> { public Task<T> Task;public bool Cancelled; public Operation(T result){Task=System.Threading.Tasks.Task.FromResult<T>(result);} public Operation(Task<T> task){Task=task;} public void Cancel(){Cancelled=true;} }
 public class Action:Windows.Foundation.IAsyncAction { public Task Task;public bool Cancelled; public Action(){Task=new System.Threading.Tasks.Task(delegate{});Task.RunSynchronously();} public Action(Task task){Task=task;}public void Cancel(){Cancelled=true;} }
 public static class State {public static bool FailRender;public static bool FailRecognition;public static bool FailOpen;public static uint Pages=2;public static uint Frames=2;public static int OpenReadCalls;public static int OpenCalls;public static int Recognized;public static int SeekCount; public static List<Windows.Graphics.Imaging.SoftwareBitmap> Bitmaps=new List<Windows.Graphics.Imaging.SoftwareBitmap>();public static List<Windows.Data.Pdf.PdfPage> PdfPages=new List<Windows.Data.Pdf.PdfPage>();public static List<Windows.Storage.Streams.MemoryStream> Streams=new List<Windows.Storage.Streams.MemoryStream>();public static void Reset(){FailRender=false;FailRecognition=false;FailOpen=false;Pages=2;Frames=2;OpenReadCalls=0;OpenCalls=0;Recognized=0;SeekCount=0;Bitmaps.Clear();PdfPages.Clear();Streams.Clear();}}
}
namespace System {public static class WindowsRuntimeSystemExtensions {
 public static Threading.Tasks.Task<T> AsTask<T>(global::Windows.Foundation.IAsyncOperation<T> operation){return ((NativeOcrFixture.Operation<T>)operation).Task;}
 public static Threading.Tasks.Task AsTask(global::Windows.Foundation.IAsyncAction operation){return ((NativeOcrFixture.Action)operation).Task;}
}}
namespace Windows.Storage.Streams {
 public interface IRandomAccessStream:IDisposable {void Seek(ulong position);}
 public interface IRandomAccessStreamWithContentType:IRandomAccessStream {}
 public class MemoryStream:IRandomAccessStreamWithContentType {public bool Disposed;public MemoryStream(){NativeOcrFixture.State.Streams.Add(this);}public void Dispose(){Disposed=true;}public void Seek(ulong p){NativeOcrFixture.State.SeekCount++;}}
 public class InMemoryRandomAccessStream:MemoryStream{}
}
namespace Windows.Storage {
 public enum FileAccessMode {Read=0,ReadWrite=1}
 public class StorageFile {
  public string Path;public static Windows.Foundation.IAsyncOperation<StorageFile> GetFileFromPathAsync(string path){return new NativeOcrFixture.Operation<StorageFile>(new StorageFile{Path=path});}
  public Windows.Foundation.IAsyncOperation<Streams.IRandomAccessStream> OpenAsync(FileAccessMode mode){NativeOcrFixture.State.OpenCalls++;if(NativeOcrFixture.State.FailOpen)throw new InvalidOperationException("open fault");return new NativeOcrFixture.Operation<Streams.IRandomAccessStream>(new Streams.MemoryStream());}
  public Windows.Foundation.IAsyncOperation<Streams.IRandomAccessStreamWithContentType> OpenReadAsync(){NativeOcrFixture.State.OpenReadCalls++;if(NativeOcrFixture.State.FailOpen)throw new InvalidOperationException("open fault");return new NativeOcrFixture.Operation<Streams.IRandomAccessStreamWithContentType>(new Streams.MemoryStream());}
 }
}
namespace Windows.Graphics.Imaging {
 public enum BitmapPixelFormat {Bgra8=0} public enum BitmapAlphaMode {Premultiplied=0} public enum ExifOrientationMode {RespectExifOrientation=0}public enum ColorManagementMode {DoNotColorManage=0}
 public class BitmapTransform {public uint ScaledWidth;public uint ScaledHeight;}
 public class SoftwareBitmap:IDisposable {public bool Disposed;public BitmapTransform Transform;public SoftwareBitmap(){NativeOcrFixture.State.Bitmaps.Add(this);}public void Dispose(){Disposed=true;}}
 public class BitmapFrame {public uint PixelWidth{get{return 4000;}}public uint PixelHeight{get{return 3000;}}public Windows.Foundation.IAsyncOperation<SoftwareBitmap> GetSoftwareBitmapAsync(BitmapPixelFormat p,BitmapAlphaMode a,BitmapTransform t,ExifOrientationMode e,ColorManagementMode c){return new NativeOcrFixture.Operation<SoftwareBitmap>(new SoftwareBitmap{Transform=t});}}
 public class BitmapDecoder {
  public uint FrameCount{get{return NativeOcrFixture.State.Frames;}}
  public static Windows.Foundation.IAsyncOperation<BitmapDecoder> CreateAsync(Windows.Storage.Streams.IRandomAccessStream stream){return new NativeOcrFixture.Operation<BitmapDecoder>(new BitmapDecoder());}
  public Windows.Foundation.IAsyncOperation<SoftwareBitmap> GetSoftwareBitmapAsync(BitmapPixelFormat p,BitmapAlphaMode a){return new NativeOcrFixture.Operation<SoftwareBitmap>(new SoftwareBitmap());}
  public Windows.Foundation.IAsyncOperation<BitmapFrame> GetFrameAsync(uint index){return new NativeOcrFixture.Operation<BitmapFrame>(new BitmapFrame());}
 }
}
namespace Windows.Media.Ocr {
 public class OcrLine {public string Text;}
 public class OcrResult {public List<OcrLine> Lines;}
 public class OcrEngine {public Windows.Foundation.IAsyncOperation<OcrResult> RecognizeAsync(Windows.Graphics.Imaging.SoftwareBitmap bitmap){if(NativeOcrFixture.State.FailRecognition)throw new InvalidOperationException("recognition fault");int n=++NativeOcrFixture.State.Recognized;return new NativeOcrFixture.Operation<OcrResult>(new OcrResult{Lines=new List<OcrLine>{new OcrLine{Text="Page "+n},new OcrLine{Text="Second line"}}});}}
}
namespace Windows.Data.Pdf {
 // Official API: PdfDocument has no IClosable/IDisposable; pages do implement IClosable.
 public class PdfDocument {public uint PageCount{get{return NativeOcrFixture.State.Pages;}}public static Windows.Foundation.IAsyncOperation<PdfDocument> LoadFromFileAsync(Windows.Storage.StorageFile file){return new NativeOcrFixture.Operation<PdfDocument>(new PdfDocument());} public PdfPage GetPage(uint index){return new PdfPage(index);}}
 public class PdfPageRenderOptions {public uint DestinationWidth;public uint DestinationHeight;}
 public class PdfPage:IDisposable {public uint Index;public bool Disposed;public PdfPageRenderOptions Options;public PdfPage(uint index){Index=index;NativeOcrFixture.State.PdfPages.Add(this);}public Windows.Foundation.Size Size{get{return new Windows.Foundation.Size{Width=800,Height=1100};}}public Windows.Foundation.IAsyncAction RenderToStreamAsync(Windows.Storage.Streams.IRandomAccessStream stream,PdfPageRenderOptions options){Options=options;if(NativeOcrFixture.State.FailRender)throw new InvalidOperationException("render fault");return new NativeOcrFixture.Action();} public void Dispose(){Disposed=true;}}
}

'@
Add-Type -TypeDefinition $source -CompilerOptions '/langversion:5'
. (Join-Path $Project 'offline-import-v71.ps1')
$originalInitialize=${function:Initialize-MedicalLocalOcr}
function Initialize-MedicalLocalOcr {return [pscustomobject]@{Engine=(New-Object Windows.Media.Ocr.OcrEngine);Warning='Adapter warning';MaxDimension=2400}}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-native-ocr-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 $operation=[NativeOcrFixture.Operation[string]]::new('async value');$value=Wait-MedicalLocalWinRt $operation ([string])
 Assert-NativeOcr ($value -ceq 'async value') 'Actual reflection bridge selects generic IAsyncOperation<T> overload'
 $action=[NativeOcrFixture.Action]::new();$output=@(Wait-MedicalLocalWinRt $action $null)
 Assert-NativeOcr ($output.Count -eq 0) 'Actual reflection bridge selects non-generic IAsyncAction without output'
 $genericVoidAction=[NativeOcrFixture.Action]::new([Threading.Tasks.Task]::FromResult([pscustomobject]@{Value='void placeholder'}));$genericVoidOutput=@(Wait-MedicalLocalWinRt $genericVoidAction $null)
 Assert-NativeOcr ($genericVoidOutput.Count -eq 0) 'Runtime generic task behind IAsyncAction does not leak its void placeholder into OCR output'
 $pending=New-Object 'Threading.Tasks.TaskCompletionSource[string]';$pendingOperation=[NativeOcrFixture.Operation[string]]::new($pending.Task)
 Assert-NativeOcrThrows {Wait-MedicalLocalWinRt $pendingOperation ([string]) 0} 'время ожидания' 'Pending native operation has a bounded wait'
 Assert-NativeOcr ($pendingOperation.Cancelled) 'Timeout calls cancellation on pending native operation'
 $pendingAction=New-Object 'Threading.Tasks.TaskCompletionSource[int]';$pendingActionOperation=[NativeOcrFixture.Action]::new($pendingAction.Task)
 Assert-NativeOcrThrows {Wait-MedicalLocalWinRt $pendingActionOperation $null 0} 'время ожидания' 'Pending render action also has a bounded wait'
 Assert-NativeOcr ($pendingActionOperation.Cancelled) 'Timeout cancels native action'
 $fault=New-Object 'Threading.Tasks.TaskCompletionSource[string]';$fault.SetException((New-Object InvalidOperationException 'native async fault'));$faultOperation=[NativeOcrFixture.Operation[string]]::new($fault.Task)
 Assert-NativeOcrThrows {Wait-MedicalLocalWinRt $faultOperation ([string])} 'native async fault' 'Async failure reaches caller instead of becoming empty OCR success'
 [NativeOcrFixture.State]::Reset()
 $pdf=Invoke-MedicalLocalNativeOcr (Join-Path $temp 'scan.pdf') $temp
 Assert-NativeOcr ($pdf.Text -ceq "Page 1`r`nSecond line`r`n`r`nPage 2`r`nSecond line") 'Actual PDF OCR loop preserves line and page order'
 Assert-NativeOcr ($pdf.Warnings.Count -eq 2 -and $pdf.Warnings[0] -ceq 'Adapter warning') 'PDF loop preserves engine and accuracy warnings'
 Assert-NativeOcr ([NativeOcrFixture.State]::PdfPages.Count -eq 2 -and [NativeOcrFixture.State]::Recognized -eq 2) 'PDF requests exactly one OCR result per page'
 Assert-NativeOcr (@([NativeOcrFixture.State]::PdfPages|Where-Object {-not $_.Disposed}).Count -eq 0) 'Every successful PDF page is disposed'
 Assert-NativeOcr (@([NativeOcrFixture.State]::Streams|Where-Object {-not $_.Disposed}).Count -eq 0) 'Every successful PDF render stream is disposed'
 Assert-NativeOcr (@([NativeOcrFixture.State]::Bitmaps|Where-Object {-not $_.Disposed}).Count -eq 0) 'Every successful PDF bitmap is disposed'
 Assert-NativeOcr ([NativeOcrFixture.State]::SeekCount -eq 2) 'Every PDF render stream rewinds before decoding'
 Assert-NativeOcr (@([NativeOcrFixture.State]::PdfPages|Where-Object {$_.Options.DestinationWidth -le 0 -or $_.Options.DestinationHeight -le 0 -or $_.Options.DestinationWidth -gt 2400 -or $_.Options.DestinationHeight -gt 2400}).Count -eq 0) 'PDF render receives positive OCR-bounded dimensions via two-argument API'
 Assert-NativeOcr (-not ([Windows.Data.Pdf.PdfDocument].GetInterfaces().Name -contains 'IDisposable')) 'Fixture enforces official non-disposable PdfDocument contract'
 $progress=[IO.File]::ReadAllText((Join-Path $temp 'progress.json'))|ConvertFrom-Json
 Assert-NativeOcr ($progress.Current -eq 2 -and $progress.Total -eq 2) 'Actual PDF loop reports final page progress'
 [NativeOcrFixture.State]::Reset();[NativeOcrFixture.State]::FailRender=$true
 Assert-NativeOcrThrows {Invoke-MedicalLocalNativeOcr (Join-Path $temp 'render.pdf') $temp} 'render fault' 'PDF render failure reaches caller'
 Assert-NativeOcr ([NativeOcrFixture.State]::PdfPages[0].Disposed -and [NativeOcrFixture.State]::Streams[0].Disposed) 'Failed render disposes both page and memory stream'
 [NativeOcrFixture.State]::Reset();[NativeOcrFixture.State]::FailRecognition=$true
 Assert-NativeOcrThrows {Invoke-MedicalLocalNativeOcr (Join-Path $temp 'recognition.pdf') $temp} 'recognition fault' 'PDF OCR failure reaches caller'
 Assert-NativeOcr ([NativeOcrFixture.State]::PdfPages[0].Disposed -and [NativeOcrFixture.State]::Streams[0].Disposed -and [NativeOcrFixture.State]::Bitmaps[0].Disposed) 'Failed PDF OCR disposes bitmap, page and stream'
 [NativeOcrFixture.State]::Reset();[NativeOcrFixture.State]::Pages=31
 Assert-NativeOcrThrows {Invoke-MedicalLocalNativeOcr (Join-Path $temp 'huge.pdf') $temp} '30 страниц' 'PDF page limit is checked before rendering'
 Assert-NativeOcr ([NativeOcrFixture.State]::PdfPages.Count -eq 0) 'Oversized PDF does not allocate render pages'
 [NativeOcrFixture.State]::Reset()
 $image=Invoke-MedicalLocalNativeOcr (Join-Path $temp 'scan.tiff') $temp
 Assert-NativeOcr ($image.Text -ceq "Page 1`r`nSecond line`r`n`r`nPage 2`r`nSecond line") 'Actual TIFF OCR loop preserves frames and line breaks'
 Assert-NativeOcr (([NativeOcrFixture.State]::OpenReadCalls+[NativeOcrFixture.State]::OpenCalls) -eq 1) 'Image stream opens once using correctly typed async result'
 Assert-NativeOcr ([NativeOcrFixture.State]::Bitmaps.Count -eq 2 -and [NativeOcrFixture.State]::Recognized -eq 2) 'TIFF processes each decoded frame once'
 Assert-NativeOcr (@([NativeOcrFixture.State]::Bitmaps|Where-Object {$_.Transform.ScaledWidth -ne 2400 -or $_.Transform.ScaledHeight -ne 1800}).Count -eq 0) 'Image transform respects OCR dimension while keeping aspect ratio'
 Assert-NativeOcr (@([NativeOcrFixture.State]::Bitmaps|Where-Object {-not $_.Disposed}).Count -eq 0 -and [NativeOcrFixture.State]::Streams[0].Disposed) 'Successful image OCR disposes bitmaps and source stream'
 [NativeOcrFixture.State]::Reset();[NativeOcrFixture.State]::FailRecognition=$true
 Assert-NativeOcrThrows {Invoke-MedicalLocalNativeOcr (Join-Path $temp 'recognition.png') $temp} 'recognition fault' 'Image OCR failure reaches caller'
 Assert-NativeOcr ([NativeOcrFixture.State]::Streams[0].Disposed -and [NativeOcrFixture.State]::Bitmaps[0].Disposed) 'Failed image OCR disposes source stream and bitmap'
 [NativeOcrFixture.State]::Reset();[NativeOcrFixture.State]::Frames=31
 Assert-NativeOcrThrows {Invoke-MedicalLocalNativeOcr (Join-Path $temp 'huge.tiff') $temp} '30 страниц' 'TIFF frame limit is checked before OCR'
 Assert-NativeOcr ([NativeOcrFixture.State]::Recognized -eq 0 -and [NativeOcrFixture.State]::Streams[0].Disposed) 'Oversized TIFF releases stream without decoding frames'
 [NativeOcrFixture.State]::Reset();[NativeOcrFixture.State]::FailOpen=$true
 Assert-NativeOcrThrows {Invoke-MedicalLocalNativeOcr (Join-Path $temp 'unreadable.png') $temp} 'open fault' 'Image open failure reaches caller without an invalid cleanup call'
 Write-Output ('Completed '+$script:checks+' API-adapter checks. Actual Windows WinRT/Word/OCR is not executed by this suite.')
}finally{${function:Initialize-MedicalLocalOcr}=$originalInitialize;if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
