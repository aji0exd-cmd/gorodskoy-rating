﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v71'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Page([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
function Import-PageFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors|Out-String)}
 foreach($node in $ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
  if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}
 }
}
function Get-PageScale([string]$html){
 $match=[regex]::Match($html,'<div class="sheet" style="[^"]*zoom:([0-9.]+);')
 if(-not $match.Success){throw 'Fitted sheet has no numeric scale'}
 return [double]::Parse($match.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture)
}
Import-PageFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
foreach($file in @('universal.ps1','template-editor-v59.ps1','template-format-v62.ps1','template-layout-preview-v62.ps1')){Import-PageFunctions (Join-Path $Project $file)}
$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-editor-page-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 $path=Join-Path $temp 'page.docx';New-UniversalTemplate $path (New-UniversalConfig)
 $model=Read-MedicalTemplateModel $path;$selected=$model.Paragraphs[0]
 $source=[Convert]::ToBase64String([IO.File]::ReadAllBytes($path));$before=$model.Parts['word/document.xml'].Xml.OuterXml
 $layout=Get-MedicalPageLayout $model $selected.Id
 $default=ConvertTo-MedicalTemplateHtml $model $selected.Id
 Assert-Page (-not $default.Contains('zoom:')) 'Standalone preview retains physical scale when no viewport is supplied'
 $height=ConvertTo-MedicalHtmlNumber $layout.PageHeightCm 29.7 1 100
 Assert-Page ($default.Contains('min-height:'+$height+'cm;')) 'Sheet uses actual Word page height instead of a short text rectangle'
 $previous=0.0
 foreach($width in @(360,480,600,840,1280,1920)){
  $html=ConvertTo-MedicalTemplateHtml $model $selected.Id $width;$scale=Get-PageScale $html
  $pixelWidth=$layout.PageWidthCm*96/2.54
  Assert-Page ($scale -gt 0 -and $scale -le 1) ('Sheet remains readable without enlargement at viewport '+$width)
  Assert-Page ($pixelWidth*$scale -le $width-31) ('Whole Word sheet fits within viewport '+$width)
  Assert-Page ($scale -ge $previous) ('Growing viewport never shrinks the Word sheet: '+$width)
  Assert-Page (([regex]::Matches($html,'data-mc-paragraph="')).Count -eq $model.Paragraphs.Count) ('All paragraphs remain selectable at viewport '+$width)
  Assert-Page ($html.Contains('id="selected-paragraph"') -and $html.Contains('word-paragraph selected')) ('Selected paragraph remains highlighted at viewport '+$width)
  $previous=$scale
 }
 foreach($width in @(0,-100,[double]::NaN,[double]::PositiveInfinity)){
  $html=ConvertTo-MedicalTemplateHtml $model '' $width
  Assert-Page (-not $html.Contains('zoom:') -and -not $html.Contains('NaN') -and -not $html.Contains('Infinity')) ('Invalid or absent viewport cannot generate invalid CSS: '+$width)
 }
 $tiny=ConvertTo-MedicalTemplateHtml $model '' 1
 Assert-Page ((Get-PageScale $tiny) -eq 0.1) 'Transient tiny viewport has a positive lower scale bound'
 $attributes=[regex]::Matches($default,'data-mc-paragraph="([^"]*)"')
 $ids=@($attributes|ForEach-Object {[Net.WebUtility]::HtmlDecode($_.Groups[1].Value)})
 Assert-Page (@($ids|Select-Object -Unique).Count -eq $model.Paragraphs.Count) 'Each selectable paragraph maps to a unique model record'
 foreach($paragraph in $model.Paragraphs){Assert-Page ($paragraph.Id -cin $ids) ('Native selection identifier maps back to '+$paragraph.Id)}
 Assert-Page ($before -ceq $model.Parts['word/document.xml'].Xml.OuterXml) 'Resize and selection rendering do not rewrite Word XML'
 Assert-Page (@($model.Parts.Values|Where-Object {$_.Modified}).Count -eq 0) 'Preview resize does not mark the template as edited'
 Assert-Page ($source -ceq [Convert]::ToBase64String([IO.File]::ReadAllBytes($path))) 'Preview resize leaves the source DOCX byte for byte unchanged'
 $originalId=$selected.Id;$selected.Id='native" data-attack="x<&'
 try{
  $escaped=ConvertTo-MedicalTemplateHtml $model $selected.Id 600
  Assert-Page ($escaped.Contains('data-mc-paragraph="native&quot; data-attack=&quot;x&lt;&amp;"')) 'Model identifier is HTML encoded before use in a selectable attribute'
  Assert-Page (-not $escaped.Contains('data-mc-paragraph="native" data-attack=')) 'A model identifier cannot create an additional HTML attribute'
 }finally{$selected.Id=$originalId}
 Set-MedicalPageLayout $model @{PageWidthCm=29.7;PageHeightCm=21} $selected.Id
 $landscape=Get-MedicalPageLayout $model $selected.Id;$wideHtml=ConvertTo-MedicalTemplateHtml $model $selected.Id 600
 $scale=Get-PageScale $wideHtml
 Assert-Page ($landscape.PageWidthCm*$scale*96/2.54 -le 569) 'Landscape sheet fits the same narrow Word pane'
 Assert-Page ($wideHtml.Contains('min-height:'+(ConvertTo-MedicalHtmlNumber $landscape.PageHeightCm 21 1 100)+'cm;') -and $wideHtml.Contains('width:'+(ConvertTo-MedicalHtmlNumber $landscape.PageWidthCm 29.7 1 100)+'cm;')) 'Landscape width and height come from Word page settings'
 Assert-Page ($scale -lt (Get-PageScale (ConvertTo-MedicalTemplateHtml (Read-MedicalTemplateModel $path) '' 600))) 'Landscape is scaled more than portrait at the same viewport'
 Assert-Page ($wideHtml.Contains('default-src &#39;none&#39;') -and -not ($wideHtml -match '<script|\bonclick=|javascript:|<iframe|<link\b')) 'Selectable sheet uses inert HTML and retains its restrictive content policy'
 Write-Output ('Completed '+$script:checks+' editor-page checks.')
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
