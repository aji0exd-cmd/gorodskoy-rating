﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v71'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Offline([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
function Assert-OfflineThrows([scriptblock]$action,[string]$pattern,[string]$message){$errorText='';try{& $action}catch{$errorText=[string]$_.Exception.Message};Assert-Offline ($errorText -match $pattern) ($message+' ['+$errorText+']')}
function Import-OfflineFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors);if($errors.Count){throw ($errors|Out-String)}
 foreach($node in $ast.FindAll({param($item) $item -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){if($names.Count -eq 0 -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}}
}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-offline-tests-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 . (Join-Path $Project 'offline-import-v71.ps1')
 Import-OfflineFunctions (Join-Path $Project 'template-editor-v59.ps1')
 Add-Type -AssemblyName System.IO.Compression.FileSystem
 $limits=Get-MedicalLocalImportLimits
 Assert-Offline ($limits.MaxFileBytes -eq 50MB -and $limits.MaxTextBytes -eq 2MB -and $limits.MaxPages -eq 30) 'File, text and page limits are bounded'
 Assert-Offline ($limits.AsyncTimeoutSeconds -le 45 -and $limits.WorkerTimeoutSeconds -le 720 -and $limits.WordTimeoutSeconds -le 90) 'Native worker and async operations have bounded timeouts'
 $filter=Get-MedicalLocalDocumentFilter
 foreach($extension in @('docx','dotx','doc','dot','rtf','txt','pdf','png','jpg','jpeg','bmp','tif','tiff')){Assert-Offline ($filter.Contains('*.'+$extension)) ('Picker supports '+$extension)}
 $original='Ф.И.О.: Иванов Иван Иванович'+"`r`n`r`n"+'Жалобы: слабость & <кружение> '+"`t"+'«цитата»'+"`r`n"+'Давление: 120/80'+"`r`n"
 $encodings=@{
  'utf8'=(New-Object Text.UTF8Encoding $false,$true)
  'utf8bom'=(New-Object Text.UTF8Encoding $true,$true)
  'utf16le'=(New-Object Text.UnicodeEncoding $false,$true,$true)
  'utf16be'=(New-Object Text.UnicodeEncoding $true,$true,$true)
  'utf32le'=(New-Object Text.UTF32Encoding $false,$true,$true)
  'utf32be'=(New-Object Text.UTF32Encoding $true,$true,$true)
  'cp1251'=[Text.Encoding]::GetEncoding(1251)
 }
 foreach($key in $encodings.Keys){
  $path=Join-Path $temp ($key+'.txt');[IO.File]::WriteAllText($path,$original,$encodings[$key]);$before=[Convert]::ToBase64String([IO.File]::ReadAllBytes($path))
  Assert-Offline ((Read-MedicalLocalText $path) -ceq $original) ('Correctly decodes '+$key)
  $import=Import-MedicalLocalDocument $path
  try{
   Assert-Offline ($import.Temporary -and $import.SourceKind -ceq 'text' -and $import.Warnings.Count -ge 1) ('Text import returns managed working file and review warning: '+$key)
   $model=Read-MedicalTemplateModel $import.Path
   Assert-Offline ($model.TemplateExtension -ceq '.docx') ('Imported '+$key+' is real readable Word OOXML')
   $texts=@($model.Paragraphs|ForEach-Object {$_.Text})
   Assert-Offline ($texts.Count -eq 5 -and $texts[1] -ceq '' -and $texts[4] -ceq '') ('Blank and trailing paragraphs survive '+$key)
   Assert-Offline (($texts -join "`r`n") -ceq $original) ('Full Unicode, XML punctuation and tabs survive '+$key)
   Assert-Offline ($before -ceq [Convert]::ToBase64String([IO.File]::ReadAllBytes($path))) ('Source file unchanged '+$key)
   $workingDirectory=$import.WorkingDirectory
  }finally{Remove-MedicalLocalImport $import}
  Assert-Offline (-not [IO.Directory]::Exists($workingDirectory)) ('Managed converted files are removed '+$key)
 }
 $source=Join-Path $temp 'source.docx';Write-MedicalLocalTextTemplate $source 'Жалобы: {{COMPLAINTS}}';$sourceBytes=[Convert]::ToBase64String([IO.File]::ReadAllBytes($source))
 $direct=Import-MedicalLocalDocument $source;Remove-MedicalLocalImport $direct
 Assert-Offline (-not $direct.Temporary -and $direct.Path -ceq $source -and $direct.WorkingDirectory -ceq '') 'DOCX uses original path without a disposable working directory'
 Assert-Offline ($sourceBytes -ceq [Convert]::ToBase64String([IO.File]::ReadAllBytes($source))) 'Direct DOCX cleanup never deletes or modifies the original'
 $dotx=Join-Path $temp 'source.dotx';[IO.File]::Copy($source,$dotx);$directDotx=Import-MedicalLocalDocument $dotx
 Assert-Offline (-not $directDotx.Temporary -and $directDotx.Path -ceq $dotx) 'DOTX is left intact for the model validator'
 Assert-OfflineThrows {Remove-MedicalLocalImport ([pscustomobject]@{Temporary=$true;WorkingDirectory=$temp})} 'Недопустимая' 'Cleanup rejects arbitrary user directories'
 Assert-Offline ([IO.Directory]::Exists($temp)) 'Rejected cleanup preserves user directory'
 Assert-OfflineThrows {Assert-MedicalLocalImportPath ''} 'Выберите' 'Empty path rejected'
 Assert-OfflineThrows {Assert-MedicalLocalImportPath (Join-Path $temp 'missing.txt')} 'не найден' 'Missing path rejected'
 $empty=Join-Path $temp 'empty.txt';[IO.File]::WriteAllBytes($empty,[byte[]]@())
 Assert-OfflineThrows {Assert-MedicalLocalImportPath $empty} 'пуст' 'Empty file rejected'
 $exe=Join-Path $temp 'bad.exe';[IO.File]::WriteAllText($exe,'not an image')
 Assert-OfflineThrows {Assert-MedicalLocalImportPath $exe} 'Поддерживаются' 'Unexpected formats rejected before native processing'
 $binary=Join-Path $temp 'binary.txt';[IO.File]::WriteAllBytes($binary,[byte[]]@(65,0,66))
 Assert-OfflineThrows {Read-MedicalLocalText $binary} 'двоичные' 'Binary masquerading as text is rejected'
 $bigText=Join-Path $temp 'big.txt';$stream=[IO.File]::Create($bigText);$stream.SetLength(2MB+1);$stream.Dispose()
 Assert-OfflineThrows {Assert-MedicalLocalImportPath $bigText} '2 МБ' 'Oversized text rejected before allocation'
 $bigPdf=Join-Path $temp 'big.pdf';$stream=[IO.File]::Create($bigPdf);$stream.SetLength(50MB+1);$stream.Dispose()
 Assert-OfflineThrows {Assert-MedicalLocalImportPath $bigPdf} '50 МБ' 'Oversized PDF rejected before native decode'
 Assert-OfflineThrows {Write-MedicalLocalTextTemplate (Join-Path $temp 'empty.docx') "`r`n "} 'не найден читаемый' 'Blank OCR text cannot create an empty template'
 Assert-OfflineThrows {Write-MedicalLocalTextTemplate (Join-Path $temp 'large.docx') ('x'*1500001)} 'слишком много' 'Oversized extracted text rejected'
 $size=Get-MedicalLocalOcrSize 4000 3000
 Assert-Offline ($size.Width -eq 2400 -and $size.Height -eq 1800) 'Large scan fits OCR limit with preserved ratio'
 $size=Get-MedicalLocalOcrSize 3000 4000 1600
 Assert-Offline ($size.Width -eq 1200 -and $size.Height -eq 1600) 'Engine-specific dimension limit wins for portrait scan'
 $size=Get-MedicalLocalOcrSize 600 800
 Assert-Offline ($size.Width -eq 600 -and $size.Height -eq 800) 'Small images are not unnecessarily enlarged'
 $size=Get-MedicalLocalOcrSize 1 60000000
 Assert-Offline ($size.Width -eq 1 -and $size.Height -eq 2400) 'Extreme aspect ratio keeps both dimensions positive'
 Assert-OfflineThrows {Get-MedicalLocalOcrSize 12000 6000} '60 мегапикселей' 'Decompression image pixel bomb is rejected'
 Assert-OfflineThrows {Get-MedicalLocalOcrSize 0 20} 'некорректный' 'Invalid decoded dimensions are rejected'
 Assert-OfflineThrows {Get-MedicalLocalOcrSize 20 20 0} 'некорректный' 'Invalid native engine dimension is rejected'
 $languages=@([pscustomobject]@{LanguageTag='en-US'},[pscustomobject]@{LanguageTag='ru-RU'})
 $selected=Select-MedicalLocalOcrEngine $languages {param($l) [pscustomobject]@{Language=$l.LanguageTag}} {throw 'profile must not be selected'}
 Assert-Offline ($selected.Engine.Language -ceq 'ru-RU' -and -not $selected.Warning) 'Russian local OCR engine is preferred over profile defaults'
 $selected=Select-MedicalLocalOcrEngine @([pscustomobject]@{LanguageTag='en-US'}) {throw 'language factory must not be used'} {[pscustomobject]@{Language='en-US'}}
 Assert-Offline ($selected.Engine.Language -ceq 'en-US' -and $selected.Warning -match 'Русский') 'Fallback language produces an explicit accuracy warning'
 $selected=Select-MedicalLocalOcrEngine $languages {param($l) $null} {[pscustomobject]@{Language='en-US'}}
 Assert-Offline ($selected.Engine.Language -ceq 'en-US' -and $selected.Warning) 'Unavailable Russian engine falls back with warning'
 Assert-OfflineThrows {Select-MedicalLocalOcrEngine @() {throw 'not called'} {throw 'not called'}} 'не установлен ни один' 'Missing installed OCR language has actionable error'
 Assert-OfflineThrows {Select-MedicalLocalOcrEngine $languages {param($l) $null} {$null}} 'Не удалось включить' 'Unusable native engines fail clearly'
 # Actual worker control flow with an OCR backend adapter. Native WinRT itself requires Windows.
 $originalOcr=${function:Invoke-MedicalLocalNativeOcr};$originalWord=${function:Convert-MedicalLocalWordDocument}
 try{
  function Invoke-MedicalLocalNativeOcr([string]$Path,[string]$Directory){Write-MedicalLocalImportProgress $Directory 'page 1 of 2' 1 2;return [pscustomobject]@{Text="Жалобы: головокружение`r`nАнамнез: со вчерашнего дня";Warnings=@('Check OCR')}}
  $pdf=Join-Path $temp 'scan.pdf';[IO.File]::WriteAllText($pdf,'fake native backend source');$directory=New-MedicalLocalImportDirectory
  $request=Join-Path $directory 'request.json';[IO.File]::WriteAllText($request,([pscustomobject]@{Path=$pdf;Directory=$directory}|ConvertTo-Json))
  try{
   Invoke-MedicalLocalImportWorker $request;$result=[IO.File]::ReadAllText((Join-Path $directory 'result.json'))|ConvertFrom-Json
   Assert-Offline ($result.Success -and $result.SourceKind -ceq 'pdf-ocr' -and $result.Warnings[0] -ceq 'Check OCR') 'Worker returns OCR result and warnings from backend adapter'
   $model=Read-MedicalTemplateModel $result.Path
   Assert-Offline (@($model.Paragraphs).Count -eq 2 -and $model.Paragraphs[0].Text -match 'головокружение') 'Worker writes real editable OOXML from OCR lines'
   $progress=[IO.File]::ReadAllText((Join-Path $directory 'progress.json'))|ConvertFrom-Json
   Assert-Offline ($progress.Current -eq 1 -and $progress.Total -eq 2) 'Worker progress reports native-page counts'
   function Invoke-MedicalLocalNativeOcr([string]$Path,[string]$Directory){throw 'OCR language missing'}
   Invoke-MedicalLocalImportWorker $request;$failure=[IO.File]::ReadAllText((Join-Path $directory 'result.json'))|ConvertFrom-Json
   Assert-Offline (-not $failure.Success -and $failure.Error -ceq 'OCR language missing' -and -not $failure.Path) 'Worker transports native failure without a success file result'
   function Invoke-MedicalLocalNativeOcr([string]$Path,[string]$Directory){throw (New-Object OperationCanceledException 'cancelled by adapter')}
   Invoke-MedicalLocalImportWorker $request;$failure=[IO.File]::ReadAllText((Join-Path $directory 'result.json'))|ConvertFrom-Json
   Assert-Offline (-not $failure.Success -and $failure.Error -ceq 'cancelled by adapter') 'Worker cancellation cannot be interpreted as success'
  }finally{Remove-MedicalLocalImport ([pscustomobject]@{Temporary=$true;WorkingDirectory=$directory})}
  Assert-Offline (-not [IO.Directory]::Exists($directory) -and [IO.File]::ReadAllText($pdf) -ceq 'fake native backend source') 'Failed and cancelled worker cleanup preserves source file'
  function Convert-MedicalLocalWordDocument([string]$Path,[string]$Destination,[string]$Directory){Write-MedicalLocalTextTemplate $Destination 'Converted old-format Word'}
  $doc=Join-Path $temp 'legacy.doc';[IO.File]::WriteAllText($doc,'native old doc adapter');$directory=New-MedicalLocalImportDirectory;$request=Join-Path $directory 'request.json';[IO.File]::WriteAllText($request,([pscustomobject]@{Path=$doc;Directory=$directory}|ConvertTo-Json))
  try{Invoke-MedicalLocalImportWorker $request;$result=[IO.File]::ReadAllText((Join-Path $directory 'result.json'))|ConvertFrom-Json;Assert-Offline ($result.Success -and $result.SourceKind -ceq 'word' -and $result.Warnings.Count -gt 0) 'Worker dispatches legacy Word to isolated conversion adapter';Assert-Offline ((Read-MedicalTemplateModel $result.Path).Paragraphs[0].Text -ceq 'Converted old-format Word') 'Legacy conversion result is readable by existing editor'}finally{Remove-MedicalLocalImport ([pscustomobject]@{Temporary=$true;WorkingDirectory=$directory})}
 }finally{${function:Invoke-MedicalLocalNativeOcr}=$originalOcr;${function:Convert-MedicalLocalWordDocument}=$originalWord}
 if([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT){
  $base=Join-Path ([IO.Path]::GetTempPath()) 'MedicalConstructor-LocalImport';$before=@([IO.Directory]::GetDirectories($base))
  Assert-OfflineThrows {Import-MedicalLocalDocument $pdf} 'Windows' 'Non-Windows import explains native OCR requirement'
  $after=@([IO.Directory]::GetDirectories($base));Assert-Offline (($before -join '|') -ceq ($after -join '|')) 'Native platform failure removes newly created working directory'
 }

 # Exercise actual Word conversion ownership and finally blocks through native boundary adapters.
 $wordFunctions=@{};foreach($name in @('New-MedicalLocalWordApplication','Get-MedicalLocalWordProcessId','Get-MedicalLocalWordProcess','Release-MedicalLocalComReference')){$wordFunctions[$name]=(Get-Item ('function:'+$name)).ScriptBlock}
 function New-OfflineWordFixture {
  $script:offlineWordTrace=@{Open=0;Save=0;Close=0;Quit=0;Released=0;FailOpen=$false;ReadOnly=$false;Recent=$true;Format=0}
  $script:offlineWordPid=901;$script:offlineExistingWord=@();$script:offlineCurrentWord=[pscustomobject]@{Id=901;ProcessName='WINWORD';StartTime=[datetime]'2026-01-01T12:00:00Z'}
  $script:offlineDocument=[pscustomobject]@{UpdateStylesOnOpen=$true}
  $script:offlineDocument|Add-Member ScriptMethod SaveAs2 {param($path,$format) $script:offlineWordTrace.Save++;$script:offlineWordTrace.Format=$format;Write-MedicalLocalTextTemplate $path 'Read-only Word conversion'}
  $script:offlineDocument|Add-Member ScriptMethod Close {param($mode) $script:offlineWordTrace.Close++}
  $documents=[pscustomobject]@{}
  $documents|Add-Member ScriptMethod Open {param($path,$confirm,$readonly,$recent) $script:offlineWordTrace.Open++;$script:offlineWordTrace.ReadOnly=$readonly;$script:offlineWordTrace.Recent=$recent;if($script:offlineWordTrace.FailOpen){throw 'native Word open failed'};return $script:offlineDocument}
  $script:offlineWord=[pscustomobject]@{Visible=$true;DisplayAlerts=99;AutomationSecurity=99;Options=[pscustomobject]@{UpdateLinksAtOpen=$true};Documents=$documents}
  $script:offlineWord|Add-Member ScriptMethod Quit {param($mode) $script:offlineWordTrace.Quit++}
 }
 try{
  function New-MedicalLocalWordApplication {return $script:offlineWord}
  function Get-MedicalLocalWordProcessId($Word){return $script:offlineWordPid}
  function Get-MedicalLocalWordProcess([uint32]$Id=0){if($Id -eq 0){return $script:offlineExistingWord};return $script:offlineCurrentWord}
  function Release-MedicalLocalComReference($Reference){$script:offlineWordTrace.Released++}
  New-OfflineWordFixture
  $directory=New-MedicalLocalImportDirectory
  try{
   $output=Join-Path $directory 'converted.docx';Convert-MedicalLocalWordDocument $source $output $directory
   Assert-Offline ($script:offlineWordTrace.Open -eq 1 -and $script:offlineWordTrace.Save -eq 1 -and $script:offlineWordTrace.Close -eq 1 -and $script:offlineWordTrace.Quit -eq 1) 'Owned new Word instance opens, saves, closes and quits exactly once'
   Assert-Offline ($script:offlineWordTrace.ReadOnly -and -not $script:offlineWordTrace.Recent -and $script:offlineWordTrace.Format -eq 12) 'Legacy Word conversion uses readonly document and private macro-free DOCX format'
   Assert-Offline ($script:offlineWord.AutomationSecurity -eq 3 -and -not $script:offlineWord.Options.UpdateLinksAtOpen) 'Owned Word disables macros and external link updates before opening'
   Assert-Offline ($script:offlineWordTrace.Released -eq 2 -and [IO.File]::Exists((Join-Path $directory 'word-process.json'))) 'Owned Word and document references are released and PID ownership recorded'
   Assert-Offline ((Read-MedicalTemplateModel $output).Paragraphs[0].Text -ceq 'Read-only Word conversion') 'Actual owned conversion flow returns an editor-readable Word document'
  }finally{Remove-MedicalLocalImport ([pscustomobject]@{Temporary=$true;WorkingDirectory=$directory})}
  New-OfflineWordFixture;$script:offlineExistingWord=@($script:offlineCurrentWord);$directory=New-MedicalLocalImportDirectory
  try{
   Assert-OfflineThrows {Convert-MedicalLocalWordDocument $source (Join-Path $directory 'converted.docx') $directory} 'отдельный процесс' 'COM activation reusing an existing Word PID is refused'
   Assert-Offline ($script:offlineWordTrace.Open -eq 0 -and $script:offlineWordTrace.Quit -eq 0 -and $script:offlineWordTrace.Released -eq 1) 'Refused pre-existing Word never opens a document or quits the user process'
   Assert-Offline ($script:offlineWord.Visible -and $script:offlineWord.AutomationSecurity -eq 99 -and $script:offlineWord.Options.UpdateLinksAtOpen) 'Refused pre-existing Word application settings stay untouched'
   Assert-Offline (-not [IO.File]::Exists((Join-Path $directory 'word-process.json'))) 'Pre-existing PID is never recorded as an owned kill target'
  }finally{Remove-MedicalLocalImport ([pscustomobject]@{Temporary=$true;WorkingDirectory=$directory})}
  New-OfflineWordFixture;$script:offlineWordPid=0;$directory=New-MedicalLocalImportDirectory
  try{Assert-OfflineThrows {Convert-MedicalLocalWordDocument $source (Join-Path $directory 'converted.docx') $directory} 'отдельный процесс' 'Unknown Word PID is refused';Assert-Offline ($script:offlineWordTrace.Quit -eq 0 -and $script:offlineWordTrace.Open -eq 0) 'Unconfirmed Word ownership never triggers Quit or document open'}finally{Remove-MedicalLocalImport ([pscustomobject]@{Temporary=$true;WorkingDirectory=$directory})}
  New-OfflineWordFixture;$script:offlineWordTrace.FailOpen=$true;$directory=New-MedicalLocalImportDirectory
  try{Assert-OfflineThrows {Convert-MedicalLocalWordDocument $source (Join-Path $directory 'converted.docx') $directory} 'native Word open failed' 'Native document open error reaches caller';Assert-Offline ($script:offlineWordTrace.Quit -eq 1 -and $script:offlineWordTrace.Released -eq 1 -and $script:offlineWordTrace.Save -eq 0) 'Owned Word still quits when opening the source fails'}finally{Remove-MedicalLocalImport ([pscustomobject]@{Temporary=$true;WorkingDirectory=$directory})}
 }finally{foreach($name in $wordFunctions.Keys){Set-Item ('function:'+$name) $wordFunctions[$name]}}
 # Real registration closure survives its function scope and converts programmatic FormClosing into cancellation.
 $dialogFixture=[pscustomobject]@{IsDisposed=$false;Enabled=$false;Opacity=0}
 $dialogFixture|Add-Member ScriptMethod Add_FormClosing {param($handler) $script:offlineClosingHandler=$handler}
 $cancelState=@{Value=$false};Register-MedicalLocalImportCancellation $dialogFixture $cancelState
 & $script:offlineClosingHandler
 Assert-Offline ($cancelState.Value) 'Closing the progress form requests cancellation through its actual registered event'
 $ownerFixture=[pscustomobject]@{IsDisposed=$false;Enabled=$false;Opacity=0}
 Assert-Offline (-not (Test-MedicalLocalImportUiClosed $ownerFixture $dialogFixture)) 'A hidden disabled owner during account lock does not cancel local OCR'
 $ownerFixture.IsDisposed=$true
 Assert-Offline (Test-MedicalLocalImportUiClosed $ownerFixture $dialogFixture) 'Disposed owner requests worker cancellation before progress controls are accessed'
 $ownerFixture.IsDisposed=$false;$dialogFixture.IsDisposed=$true
 Assert-Offline (Test-MedicalLocalImportUiClosed $ownerFixture $dialogFixture) 'Disposed progress dialog requests worker cancellation'

 $module=[IO.File]::ReadAllText((Join-Path $Project 'offline-import-v71.ps1'))
 Assert-Offline (-not (($module -replace 'http://schemas.openxmlformats.org/[a-zA-Z0-9/.-]+','') -match 'https?://|Invoke-WebRequest|WebClient|HttpClient|curl|wget')) 'Importer contains no cloud endpoint, network client or dependency download'
 Assert-Offline ($module.Contains('AutomationSecurity=3') -and $module.Contains('UpdateLinksAtOpen=$false') -and $module.Contains('.Open($Path,$false,$true,$false)')) 'Legacy Word path disables macros, link updates and writes to the original'
 Assert-Offline ($module.Contains('OperationCanceledException') -and $module.Contains('$process.Kill()') -and $module.Contains('Stop-MedicalLocalImportWord')) 'Cancellation and timeout clean up worker and its owned Word instance'
 Assert-Offline ($module.Contains('$wordProcessId -notin $before') -and $module.Contains('StartTime.ToUniversalTime().ToString(''o'') -ceq')) 'Word cleanup checks both ownership and process start time'
 Assert-Offline ($module.Contains('UseShellExecute=$false') -and $module.Contains('-EncodedCommand') -and $module.Contains('request.json')) 'Worker uses encoded launch code and JSON paths instead of shell interpolation'
 Assert-Offline ($module.Contains('$processStarted=$false') -and $module.Contains('if($processStarted -and -not $process.HasExited)')) 'Process-launch failure does not access an unstarted process during UI cleanup'
 Write-Output ('Completed '+$script:checks+' offline-import checks. Native Windows OCR and Word rendering still need Windows verification.')
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
