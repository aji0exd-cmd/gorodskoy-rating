﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v71'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Recovery([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
function Assert-RecoveryThrows([scriptblock]$action,[string]$message){$failed=$false;try{& $action}catch{$failed=$true};Assert-Recovery $failed $message}
Add-Type -AssemblyName System.IO.Compression.FileSystem
. (Join-Path $Project 'universal.ps1')
. (Join-Path $Project 'forms-v59.ps1')
. (Join-Path $Project 'template-editor-v59.ps1')
. (Join-Path $Project 'template-recovery-v66.ps1')
. (Join-Path $Project 'card-document-v65.ps1')
$tokens=$null;$errors=$null
$constructor=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'constructor.ps1'),[ref]$tokens,[ref]$errors)
if($errors.Count){throw ($errors | Out-String)}
foreach($name in @('Get-XmlPart','Read-CaseDocument')){
 $definition=$constructor.Find({param($node)$node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $name},$false)
 . ([scriptblock]::Create($definition.Extent.Text))
}
function Set-RecoveryTextPart($zip,[string]$name,[string]$text){$entry=$zip.GetEntry($name);if($entry){$entry.Delete()};$entry=$zip.CreateEntry($name);$stream=$entry.Open();try{$bytes=[Text.Encoding]::UTF8.GetBytes($text);$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}}
function New-RecoveryTemplate([string]$path,$schema,[string]$layout='first'){
 New-UniversalTemplate $path $schema
 $zip=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{
  $doc=Get-XmlPart $zip 'word/document.xml';$n=[Xml.XmlNamespaceManager]::new($doc.NameTable);$n.AddNamespace('w',$script:ns)
  $first=$doc.SelectSingleNode('//w:p[1]',$n);$pr=$doc.CreateElement('w','pPr',$script:ns);$align=$doc.CreateElement('w','jc',$script:ns);$align.SetAttribute('val',$script:ns,'right');[void]$pr.AppendChild($align);[void]$first.PrependChild($pr)
  Set-RecoveryTextPart $zip 'word/document.xml' $doc.OuterXml
  Set-RecoveryTextPart $zip 'word/styles.xml' ('<w:styles xmlns:w="'+$script:ns+'"><w:style w:type="paragraph" w:styleId="Custom-'+$layout+'"><w:name w:val="Original '+$layout+'"/><w:rPr><w:rFonts w:ascii="Cambria"/><w:color w:val="236A6A"/></w:rPr></w:style></w:styles>')
  Set-RecoveryTextPart $zip 'word/header1.xml' ('<w:hdr xmlns:w="'+$script:ns+'"><w:p><w:r><w:t>Original header '+$layout+'</w:t></w:r></w:p></w:hdr>')
  $entry=$zip.CreateEntry('word/media/logo.png');$stream=$entry.Open();try{$bytes=[Convert]::FromBase64String('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aD1sAAAAASUVORK5CYII=');$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
 }finally{$zip.Dispose()}
 Test-MedicalTemplateBytes ([IO.File]::ReadAllBytes($path))
}
function New-RecoveryRecord($schema,$snapshots=$null){
 return [pscustomobject]@{version=49;universal=[pscustomobject]@{Version=49;Schema=(Copy-UniversalObject $schema);Values=[pscustomobject]@{patient_name='Тестовый Пациент';complaints='Ответы должны остаться';history='Текст истории'};Details=[pscustomobject]@{history='Уточнение'};AdmissionDateTime='2026-10-13T22:00:00'};patientName='Тестовый Пациент';templates=[pscustomobject]@{initial=$schema.Template;diary='Missing-diary.dotx';discharge='Missing-discharge.docx'};stages=[pscustomobject]@{diary_1=@('Дневник сохраняется');discharge=@('Выписка сохраняется')};diaryCount=1;TemplateSnapshots=$snapshots}
}
$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-recovery-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 $oldRoot=Join-Path $temp 'old-program';$newRoot=Join-Path $temp 'new-program';$cardRoot=Join-Path $temp 'cards'
 foreach($folder in @($oldRoot,$newRoot,$cardRoot)){[void][IO.Directory]::CreateDirectory($folder)}
 $oldTemplates=Join-Path $oldRoot 'Шаблоны';[void][IO.Directory]::CreateDirectory($oldTemplates)
 $original=Join-Path $oldTemplates '01-b92192ba816b-9dff67722061-0ea467e5a8f9-3c129c65f0fc.docx'
 $schema=New-UniversalConfig;$schema.AutoTemplate=$false;$schema.Template=$original
 New-RecoveryTemplate $original $schema
 $originalBytes=[IO.File]::ReadAllBytes($original);$originalHash=Get-MedicalBytesSha256 $originalBytes
 $script:medicalProgramRoot=$newRoot;$script:medicalTemplatesFolder=Join-Path $newRoot 'Шаблоны'
 Assert-Recovery ((Resolve-MedicalTemplateReference $original) -ceq $original) 'Existing exact absolute saved source wins without layout guessing'
 Assert-Recovery ((Resolve-MedicalTemplateReference 'Шаблоны\absent.docx') -ceq '') 'Missing Windows-style relative source resolves as unavailable'
 $legacy=New-RecoveryRecord $schema;$legacy.universal.Schema.Template='Шаблоны/'+[IO.Path]::GetFileName($original)
 $resolved=Restore-MedicalCardTemplateReferences $legacy (Join-Path $cardRoot 'legacy-card.docx')
 Assert-Recovery ($resolved.universal.Schema.Template -ceq $original -and $resolved.templates.initial -ceq $original) 'Legacy card missing relative path uses its recorded exact absolute original source'
 Assert-Recovery ($legacy.universal.Schema.Template -cne $resolved.universal.Schema.Template) 'Resolving legacy source returns an independent record without mutating the caller'
 Assert-Recovery ($resolved.universal.Values.complaints -ceq 'Ответы должны остаться' -and $resolved.universal.Details.history -ceq 'Уточнение' -and $resolved.stages.diary_1[0] -ceq 'Дневник сохраняется') 'Resolving legacy source preserves all current answers, details and stages'
 Assert-Recovery (-not [IO.Directory]::Exists($script:medicalTemplatesFolder)) 'Read-only legacy source resolution creates no template folder'
 $leaf=[IO.Path]::GetFileName($original);[IO.File]::WriteAllBytes((Join-Path $newRoot $leaf),$originalBytes)
 $missing='C:\old-machine\program\Шаблоны\'+$leaf
 Assert-Recovery ((Resolve-MedicalTemplateReference $missing (Join-Path $cardRoot 'card.docx')) -ceq (Join-Path $newRoot $leaf)) 'Moved source is located by its exact stored filename in the new program'
 [IO.File]::WriteAllBytes((Join-Path $cardRoot $leaf),$originalBytes)
 Assert-Recovery ((Resolve-MedicalTemplateReference $missing (Join-Path $cardRoot 'card.docx')) -ceq (Join-Path $newRoot $leaf)) 'Multiple exact-name copies with identical bytes resolve to the same source content'
 $other=Join-Path $cardRoot 'other.docx';New-RecoveryTemplate $other $schema 'different';[IO.File]::Copy($other,(Join-Path $cardRoot $leaf),$true)
 Assert-Recovery ((Resolve-MedicalTemplateReference $missing (Join-Path $cardRoot 'card.docx')) -ceq '') 'Different exact-name candidates refuse automatic layout selection'
 $snapshot=[pscustomobject]@{Name=$leaf;Sha256=$originalHash;BytesBase64=[Convert]::ToBase64String($originalBytes)}
 Assert-Recovery ((Resolve-MedicalTemplateReference $missing (Join-Path $cardRoot 'card.docx') $snapshot) -ceq (Join-Path $newRoot $leaf)) 'Verified embedded hash disambiguates differing relocated copies'
 [IO.File]::Delete((Join-Path $newRoot $leaf));[IO.File]::Delete((Join-Path $cardRoot $leaf))
 [IO.File]::WriteAllBytes((Join-Path $newRoot 'Похожее название-a1b2c3d4e5f6.docx'),$originalBytes)
 Assert-Recovery ((Resolve-MedicalTemplateReference 'Похожее название-deadbeef1234.docx') -ceq '') 'Human stem similarity does not choose another template version'
 $legacy.templates.initial=$missing;$legacy.universal.Schema.Template='Шаблоны/'+$leaf
 $stillMissing=Restore-MedicalCardTemplateReferences $legacy (Join-Path $cardRoot 'old.docx')
 Assert-Recovery ($stillMissing.templates.initial -ceq $missing -and $stillMissing.universal.Schema.Template -ceq ('Шаблоны/'+$leaf)) 'Unavailable legacy template remains explicit rather than rebuilding a generic document'
 $script:universalConfig=$schema;$script:stageTemplates=@{initial=$original;diary='Missing-diary.dotx';discharge='Missing-discharge.docx'};$script:stage='initial';$script:source=$original;$script:caseFile=Join-Path $cardRoot 'original-card.docx'
 $snapshots=Get-MedicalCardTemplateSnapshots
 Assert-Recovery ($snapshots.Count -eq 1 -and $snapshots.Contains('initial')) 'Saving current card embeds the available original while missing other stages do not block saving'
 Assert-Recovery ($snapshots.initial.Sha256 -ceq $originalHash -and $snapshots.initial.BytesBase64 -ceq [Convert]::ToBase64String($originalBytes)) 'Embedded initial source is byte-exact, including original styles, header and media'
 Assert-Recovery ($snapshots.initial.Name -ceq $leaf) 'Snapshot retains exact source filename independently of managed display names'
 $dischargeSource=Join-Path $oldTemplates 'Выписной шаблон.docx';[IO.File]::WriteAllBytes($dischargeSource,$originalBytes)
 $script:stageTemplates.diary=$other;$script:stageTemplates.discharge=$dischargeSource
 $allSnapshots=Get-MedicalCardTemplateSnapshots
 Assert-Recovery ($allSnapshots.Count -eq 3 -and $allSnapshots.diary.Sha256 -ceq (Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($other))) -and $allSnapshots.discharge.Sha256 -ceq $originalHash) 'All available stage sources retain their own verified exact template bytes'
 $allRecord=New-RecoveryRecord $schema $allSnapshots;$allRecord.templates.diary=$other;$allRecord.templates.discharge=$dischargeSource
 $script:stageTemplates.diary='Missing-diary.dotx';$script:stageTemplates.discharge='Missing-discharge.docx'
 $portable=New-RecoveryRecord $schema $snapshots
 $portablePath=Join-Path $cardRoot 'portable-card.docx';[IO.File]::Copy($original,$portablePath)
 Set-MedicalCardDocumentState $portablePath $portable
 $read=Read-CaseDocument $portablePath
 Assert-Recovery ($read.TemplateSnapshots.initial.Sha256 -ceq $originalHash) 'Actual saved-card package reads its verified embedded template snapshot'
 Assert-Recovery ($read.universal.Values.patient_name -ceq 'Тестовый Пациент' -and $read.stages.discharge[0] -ceq 'Выписка сохраняется') 'Actual portable card roundtrip preserves patient and other stages'
 [IO.Directory]::Delete($oldRoot,$true)
 $restored=Restore-MedicalCardTemplateReferences $read $portablePath
 $restoredPath=[string]$restored.universal.Schema.Template
 Assert-Recovery ([IO.File]::Exists($restoredPath) -and $restoredPath.StartsWith($script:medicalTemplatesFolder)) 'Moved new-version card recreates its exact original source in the new program template folder'
 Assert-Recovery ((Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($restoredPath))) -ceq $originalHash) 'Restored source preserves exact original Word bytes rather than an inferred layout'
 Assert-Recovery ($restored.templates.initial -ceq $restoredPath -and $restored.universal.Schema.AutoTemplate -eq $false) 'Portable card updates both source references without switching custom templates to generated mode'
 Assert-Recovery ($restored.universal.Values.complaints -ceq $read.universal.Values.complaints -and $restored.universal.Details.history -ceq $read.universal.Details.history) 'Snapshot restore leaves filled patient answers and clarification contents unchanged'
 Assert-Recovery ($read.universal.Schema.Template -cne $restoredPath) 'Snapshot import leaves the input card record unchanged'
 $again=Restore-MedicalCardTemplateReferences $read $portablePath
 Assert-Recovery ($again.universal.Schema.Template -ceq $restoredPath -and @(Get-MedicalTemplates).Count -eq 1) 'Repeated card reopening reuses matching original bytes without accumulating new templates'
 [IO.File]::Delete($other)
 $allRestored=Restore-MedicalCardTemplateReferences $allRecord $portablePath
 Assert-Recovery ([IO.File]::Exists([string]$allRestored.templates.diary) -and [IO.File]::Exists([string]$allRestored.templates.discharge)) 'A moved card restores all assigned diary and discharge template sources independently'
 Assert-Recovery ((Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes([string]$allRestored.templates.diary))) -ceq $allSnapshots.diary.Sha256 -and (Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes([string]$allRestored.templates.discharge))) -ceq $allSnapshots.discharge.Sha256) 'Recovered diary and discharge retain the exact authored layout of their own stage'
 Assert-Recovery ($allRestored.stages.diary_1[0] -ceq 'Дневник сохраняется' -and $allRestored.stages.discharge[0] -ceq 'Выписка сохраняется') 'Restoring every stage leaves all saved stage answers unchanged'
 $corruptSource=$restoredPath;[IO.File]::WriteAllBytes($corruptSource,[byte[]]@(1,2,3))
 $corruptRecord=Copy-UniversalObject $restored
 $recoveredDamaged=Restore-MedicalCardTemplateReferences $corruptRecord $portablePath;$restoredPath=[string]$recoveredDamaged.universal.Schema.Template
 Assert-Recovery ($restoredPath -cne $corruptSource -and (Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($restoredPath))) -ceq $originalHash) 'Damaged exact local source recovers from verified embedded bytes to a separate source'
 Assert-Recovery ([Convert]::ToBase64String([IO.File]::ReadAllBytes($corruptSource)) -ceq 'AQID') 'Recovery preserves the damaged local original without overwriting it'
 Assert-RecoveryThrows {Test-MedicalTemplateBytes ([IO.File]::ReadAllBytes($portablePath))} 'A saved hospitalization card is rejected as an unfilled source template'
 $clinical=Join-Path $cardRoot 'clinical-output.docx';[IO.File]::Copy($restoredPath,$clinical)
 $zip=[IO.Compression.ZipFile]::Open($clinical,[IO.Compression.ZipArchiveMode]::Update);try{Set-RecoveryTextPart $zip 'customXml/mc49.xml' '<state>patient answers</state>'}finally{$zip.Dispose()}
 Assert-RecoveryThrows {Read-MedicalRecoveryTemplateBytes $clinical} 'A clinical export carrying patient state is rejected as a source template'
 $bad=Copy-UniversalObject $read;$bad.TemplateSnapshots.initial.Sha256=('0'*64)
 $untouched=Join-Path $temp 'validation-only';$script:medicalProgramRoot=$untouched;$script:medicalTemplatesFolder=Join-Path $untouched 'Шаблоны'
 Assert-RecoveryThrows {Restore-MedicalCardTemplateReferences $bad $portablePath} 'Tampered source hash rejects the card before recovery'
 Assert-Recovery (-not [IO.Directory]::Exists($untouched)) 'Invalid snapshot creates no program folder or partial recovered template'
 $bad=Copy-UniversalObject $read;$bad.TemplateSnapshots | Add-Member -NotePropertyName diary -NotePropertyValue ([pscustomobject]@{Name='diary.docx';Sha256=('f'*64);BytesBase64=$snapshot.BytesBase64})
 Assert-RecoveryThrows {Restore-MedicalCardTemplateReferences $bad $portablePath} 'All stage snapshots validate before any initial-source import occurs'
 Assert-Recovery (-not [IO.Directory]::Exists($untouched)) 'A damaged second snapshot does not partially import the valid first one'
 $invalidSchema=Copy-UniversalObject $read;$invalidSchema.universal.Schema.Sections[0].Id=''
 Assert-RecoveryThrows {Restore-MedicalCardTemplateReferences $invalidSchema $portablePath} 'Invalid saved form schema is rejected before restoring any embedded sources'
 Assert-Recovery (-not [IO.Directory]::Exists($untouched)) 'Invalid saved schema creates no partially restored template folder'
 $incompatible=Copy-UniversalObject $read;$incompatible.universal.Schema.Sections[1].Fields[0].Marker='NOT_IN_SAVED_SOURCE'
 Assert-RecoveryThrows {Restore-MedicalCardTemplateReferences $incompatible $portablePath} 'Initial embedded source must cover the saved form marker bindings'
 Assert-Recovery (-not [IO.Directory]::Exists($untouched)) 'Incompatible embedded source creates no recovered template files'
 Assert-RecoveryThrows {Get-MedicalValidatedCardTemplateSnapshots ([pscustomobject]@{initial=[pscustomobject]@{Name='../outside.docx';Sha256=$originalHash;BytesBase64=$snapshot.BytesBase64}})} 'Snapshot path traversal is rejected before imports'
 Assert-RecoveryThrows {Get-MedicalValidatedCardTemplateSnapshots ([pscustomobject]@{initial=[pscustomobject]@{Name='source.docx';Sha256=$originalHash;BytesBase64='not base64!'}})} 'Snapshot malformed Base64 is rejected'
 Assert-RecoveryThrows {Get-MedicalValidatedCardTemplateSnapshots ([pscustomobject]@{unexpected=$snapshot})} 'Snapshot unknown stage names are rejected'
 $tooLarge=Join-Path $temp 'oversized-source.docx';$file=[IO.File]::Create($tooLarge);try{$file.SetLength(67108865)}finally{$file.Dispose()}
 Assert-RecoveryThrows {Read-MedicalRecoveryTemplateBytes $tooLarge} 'Oversized source is rejected before reading its bytes into memory'
 $filledBytes=[IO.File]::ReadAllBytes($portablePath);$filledSnapshot=[pscustomobject]@{Name='not-a-template.docx';Sha256=(Get-MedicalBytesSha256 $filledBytes);BytesBase64=[Convert]::ToBase64String($filledBytes)}
 Assert-RecoveryThrows {Get-MedicalValidatedCardTemplateSnapshots ([pscustomobject]@{initial=$filledSnapshot})} 'Matching snapshot hash does not permit embedding a filled patient card'
 $script:medicalProgramRoot=$newRoot;$script:medicalTemplatesFolder=Join-Path $newRoot 'Шаблоны';$script:universalConfig=New-UniversalConfig;$script:universalConfig.AutoTemplate=$true;$script:universalConfig.Template='nonexistent-generated.docx';$script:source=$clinical;$script:stage='initial'
 $generated=Get-MedicalCardTemplateSnapshots;$generatedBytes=[Convert]::FromBase64String($generated.initial.BytesBase64)
 Assert-Recovery ($generated.Count -eq 1 -and $generated.initial.Name -ceq 'Шаблон первичного осмотра.docx') 'Auto-template forms snapshot their actual freshly generated unfilled source despite an unrelated current file'
 Test-MedicalTemplateBytes $generatedBytes
 $generatedPath=Join-Path $temp 'generated-verify.docx';[IO.File]::WriteAllBytes($generatedPath,$generatedBytes);Assert-MedicalEditorTemplateCoverage $script:universalConfig (Read-MedicalTemplateModel $generatedPath)
 Assert-Recovery $true 'Auto-template snapshot contains all actual schema and admission markers'
 $before=(Copy-MedicalFormSchema $schema | ConvertTo-Json -Depth 40 -Compress)
 $import=Import-MedicalRecoveryTemplate $schema $restoredPath
 Assert-Recovery ($import.Schema.Sections[0].Fields[0].Id -ceq $schema.Sections[0].Fields[0].Id -and $import.Schema.Sections[1].Fields[0].Marker -ceq $schema.Sections[1].Fields[0].Marker) 'Explicit original Word recovery preserves existing field IDs and markers'
 Assert-Recovery ($import.Schema.AutoTemplate -eq $false -and $import.Schema.PreserveTemplateFormatting -eq $true) 'Explicit original Word recovery uses the chosen authored layout'
 Assert-Recovery ((Copy-MedicalFormSchema $schema | ConvertTo-Json -Depth 40 -Compress) -ceq $before) 'Explicit recovery does not mutate the input schema'
 $formPath=Join-Path $temp 'matching-form.mcform';[void](Write-MedicalForm $formPath $import.Schema 'Chosen source form')
 $recoverForm=Import-MedicalRecoveryTemplate $schema $formPath
 Assert-Recovery ($recoverForm.Schema.Sections[0].Fields[0].Id -ceq $schema.Sections[0].Fields[0].Id -and (Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($recoverForm.Template.Path))) -ceq $originalHash) 'Explicit .mcform recovery imports only its matching exact Word source'
 $wrongSchema=New-UniversalConfig;$wrongSchema.Sections[1].Fields[0].Marker='MISSING_ORIGINAL_MARKER';$folderCount=@(Get-MedicalTemplates).Count
 Assert-RecoveryThrows {Import-MedicalRecoveryTemplate $wrongSchema $formPath} 'A selected form with incompatible original field markers is rejected'
 Assert-Recovery (@(Get-MedicalTemplates).Count -eq $folderCount) 'Coverage failure imports no unrelated template'
 Assert-RecoveryThrows {Import-MedicalRecoveryTemplate $schema $portablePath} 'Explicit recovery rejects filled cards even when chosen in a Word dialog'
 $savedFolder=$script:medicalTemplatesFolder;$script:medicalTemplatesFolder=Join-Path $newRoot ('OneDrive-'+('x'*110))
 $longName='01-'+(([guid]::NewGuid().ToString('N')+'-')*5)+'a1b2c3d4e5f6.docx'
 $shortName=Get-MedicalRecoveryImportName $longName
 Assert-Recovery ((Join-Path $script:medicalTemplatesFolder $shortName).Length -lt 240 -and $shortName -ceq 'Восстановленный шаблон.docx') 'Old chained GUID filenames normalize to a short recovered destination in long Windows program paths'
 $longClinical=('Подробное название шаблона осмотра ' * 5)+'.docx';$shortClinical=Get-MedicalRecoveryImportName $longClinical
 Assert-Recovery ((Join-Path $script:medicalTemplatesFolder $shortClinical).Length -lt 240 -and $shortClinical.StartsWith('Подробное название')) 'Long human template names retain a readable prefix within Windows legacy path limits'
 $script:medicalTemplatesFolder=Join-Path $newRoot ('x'*220)
 Assert-RecoveryThrows {Get-MedicalRecoveryImportName 'source.docx'} 'Too-long program folders are rejected before Windows atomic import temporary files exceed the legacy path limit'
 $script:medicalTemplatesFolder=$savedFolder
 # Corruption is rejected while reading the actual card package, before any UI
 # can clear or replace the patient's currently filled form.
 $corruptPath=Join-Path $cardRoot 'corrupt-card.docx';[IO.File]::Copy($restoredPath,$corruptPath)
 Set-MedicalCardDocumentState $corruptPath $bad
 Assert-RecoveryThrows {Read-CaseDocument $corruptPath} 'Actual card reader rejects a tampered embedded snapshot before returning patient state'
 Assert-Recovery (@(Get-ChildItem -LiteralPath $temp -Recurse -Filter '*.tmp').Count -eq 0) 'Recovery and portable card operations clean up all temporary source files'
 Write-Output ('PASS '+$script:checks+' template-recovery checks')
}finally{if([IO.Directory]::Exists($temp)){Remove-Item -LiteralPath $temp -Recurse -Force}}
