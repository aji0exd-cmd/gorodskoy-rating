﻿param(
 [string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v71'),
 [string]$BaselineProject=(Join-Path (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) 'medical-constructor-v68/Медицинский конструктор v68'),
 [switch]$Benchmark
)
$ErrorActionPreference='Stop';$script:checks=0
function Assert-InitialPerf([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
function Import-InitialPerfFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors|Out-String)}
 foreach($node in $ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
  if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}
 }
}
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @'
using System;
public sealed class InitialPerfWidget {
 public bool IsDisposed; public string Tag; public int TextWrites,ColorWrites,NameWrites;
 private string text="",name=""; private object color;
 public string Text {get{return text;} set{text=value;TextWrites++;}}
 public string AccessibleName {get{return name;} set{name=value;NameWrites++;}}
 public object ForeColor {get{return color;} set{color=value;ColorWrites++;}}
 public event EventHandler TextChanged;
 public void Fire(){if(TextChanged!=null)TextChanged(this,EventArgs.Empty);}
 public void Reset(){TextWrites=ColorWrites=NameWrites=0;}
}
'@
. (Join-Path $Project 'universal.ps1')
if([IO.File]::Exists((Join-Path $BaselineProject 'universal-ui.ps1'))){
 Import-InitialPerfFunctions (Join-Path $BaselineProject 'universal-ui.ps1') @('Update-UniversalCompletion')
 $baseline=Get-Command Update-UniversalCompletion -CommandType Function
}
. (Join-Path $Project 'universal-ui.ps1')
$optimized=Get-Command Update-UniversalCompletion -CommandType Function
function Initialize-InitialPerfFixture([int]$count){
 $fields=@();$script:universalValues=@{};$script:universalInputs=@{};$script:universalIndicators=@{}
 for($i=0;$i -lt $count;$i++){
  $id='f'+$i;$field=New-UniversalField $id ('Поле '+$i) ('FIELD_'+$i) 'text';$fields+=@($field)
  $script:universalValues[$id]='';$widget=New-Object InitialPerfWidget;$widget.Tag=$id;$script:universalInputs[$id]=$widget;$script:universalIndicators[$id]=New-Object InitialPerfWidget
 }
 $script:universalConfig=[pscustomobject]@{Version=49;AutoTemplate=$true;Template='unused.docx';Sections=@([pscustomobject]@{Id='s';Title='Раздел';Fields=$fields})}
 $script:universalCompletionLabel=New-Object InitialPerfWidget;$script:progressLabel=New-Object InitialPerfWidget
 $script:uiSuccess='green';$script:uiDanger='red';$script:darkMuted='gray';$script:stage='initial';$script:universalBuilding=$false
 Update-UniversalCompletion
}
Initialize-InitialPerfFixture 100
Assert-InitialPerf ($script:universalCompletionMissing -eq 100 -and $script:universalCompletionRequired -eq 100) 'Full initial render initializes accurate required counts'
foreach($widget in $script:universalIndicators.Values){$widget.Reset()}
$script:universalValues.f1='текст';Update-UniversalCompletion 'f1'
Assert-InitialPerf ($script:universalCompletionMissing -eq 99) 'One input immediately updates completion count'
Assert-InitialPerf ($script:universalIndicators.f1.ForeColor -eq 'green') 'Changed input indicator updates immediately'
Assert-InitialPerf (@($script:universalIndicators.Values|Where-Object {$_.ColorWrites -gt 0}).Count -eq 1) 'Typing does not repaint all other field indicators'
foreach($widget in $script:universalIndicators.Values){$widget.Reset()}
$script:universalValues.f1='продолжение';Update-UniversalCompletion 'f1'
Assert-InitialPerf ($script:universalCompletionMissing -eq 99) 'Editing an already-filled input keeps exact counts'
Assert-InitialPerf (@($script:universalIndicators.Values|Where-Object {$_.ColorWrites -gt 0 -or $_.NameWrites -gt 0}).Count -eq 0) 'Unchanged visual state causes no repeated indicator writes'
$script:universalValues.f1=' ';Update-UniversalCompletion 'f1'
Assert-InitialPerf ($script:universalCompletionMissing -eq 100) 'Whitespace counts as missing after partial update'
$script:universalConfig.Sections[0].Fields[1].Required=$false;Update-UniversalCompletion 'f1'
Assert-InitialPerf ($script:universalCompletionRequired -eq 99 -and $script:universalCompletionMissing -eq 99) 'Required setting of edited field is read from current schema'
$script:universalConfig=Copy-UniversalObject $script:universalConfig
$script:universalConfig.Sections[0].Fields[2].Required=$false;Update-UniversalCompletion 'f2'
Assert-InitialPerf ($script:universalCompletionRequired -eq 98) 'Schema replacement invalidates cached completion index'
$script:universalConfig.Sections[0].Fields=@($script:universalConfig.Sections[0].Fields[0..4]);Update-UniversalCompletion
Assert-InitialPerf ($script:universalCompletionIndex.Count -eq 5 -and $script:universalCompletionRequired -eq 3) 'Full form rebuild removes deleted fields from cache'
# Exercise the actual production TextChanged callback rather than a rewritten equivalent.
$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'universal-ui.ps1'),[ref]$tokens,[ref]$errors)
$open=$ast.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Show-UniversalInitial'},$false)
$handler=$open.Find({param($n)$n -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $n.Expression -is [Management.Automation.Language.VariableExpressionAst] -and $n.Expression.VariablePath.UserPath -eq 'ctrl' -and $n.Member.Value -eq 'Add_TextChanged'},$true)
$ctrl=$script:universalInputs.f0;$ctrl.Text='Новый ответ'
$nativeCallback=& ([scriptblock]::Create($handler.Arguments[0].Extent.Text))
$variables=New-Object 'Collections.Generic.List[Management.Automation.PSVariable]'
$variables.Add((New-Object Management.Automation.PSVariable('this',$ctrl)))
[void]$nativeCallback.InvokeWithContext($null,$variables,@($ctrl,[EventArgs]::Empty))
Assert-InitialPerf ($script:universalValues.f0 -ceq 'Новый ответ') 'Real TextChanged writes patient answer immediately'
Assert-InitialPerf ($script:universalCompletionMissing -eq 2) 'Real callback updates cached completion immediately'
Assert-InitialPerf ($script:progressLabel.Text.Contains('1 / 3')) 'Bottom progress indicator follows input without idle scan'
# Idle handler must not read templates or build full signatures.
$tokens=$null;$errors=$null;$main=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'constructor.ps1'),[ref]$tokens,[ref]$errors)
$tick=$main.Find({param($n)$n -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $n.Expression -is [Management.Automation.Language.MemberExpressionAst] -and $n.Expression.Expression -is [Management.Automation.Language.VariableExpressionAst] -and $n.Expression.Expression.VariablePath.UserPath -eq 'script:progressTimer' -and $n.Member.Value -eq 'Add_Tick'},$true)
if(-not $tick){$tick=$main.Find({param($n)$n -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $n.Extent.Text.StartsWith('$script:progressTimer.Add_Tick(')},$true)}
$source=$tick.Arguments[0].Extent.Text
Assert-InitialPerf (-not $source.Contains('Get-MedicalFormSignature') -and -not $source.Contains('Update-MedicalClinicalCompletion')) 'Idle tick does not rehash forms or recalculate every diary'
# The real tick is invoked with deliberately failing expensive helpers.
function Get-MedicalFormSignature {throw 'Idle attempted full form signature'}
function Update-MedicalClinicalCompletion {throw 'Idle attempted all diary completion'}
function Get-MedicalPatientSummary {return 'Пациент'}
function Get-MedicalFormDisplayName($value){return $value}
function Update-MedicalNavigation {}
$script:medicalClinicalForms=[pscustomobject]@{Diaries=@()};$script:stage='diary';$script:medicalWorkspaceReady=$true;$script:activeMedicalFormName='Тест'
$script:uiPatientLabel=New-Object InitialPerfWidget;$script:uiMedicalFormStatus=New-Object InitialPerfWidget
$script:medicalBackupLastCheckpoint=[pscustomobject]@{Payload=[pscustomobject]@{FormSignature='new'}};$script:medicalBackupFormSavedSignature='old';$script:medicalBackupLastError=''
$callback=& ([scriptblock]::Create($source));& $callback
Assert-InitialPerf ($script:uiMedicalFormStatus.Text.Contains('есть изменения')) 'Idle status uses verified checkpoint dirty state'
$script:uiMedicalFormStatus.Reset();$script:uiPatientLabel.Reset();& $callback
Assert-InitialPerf ($script:uiMedicalFormStatus.TextWrites -eq 0 -and $script:uiPatientLabel.TextWrites -eq 0) 'Identical idle status avoids repeated label invalidation'
$script:medicalBackupFormSavedSignature='new';& $callback
Assert-InitialPerf (-not $script:uiMedicalFormStatus.Text.Contains('есть изменения')) 'Saving form clears dirty status without disk reads'
$script:medicalBackupLastError='Нет доступа';& $callback
Assert-InitialPerf ($script:uiMedicalFormStatus.Text.Contains('Нет доступа')) 'Backup failure remains visible until a successful checkpoint'
. (Join-Path $Project 'forms-v59.ps1')
Import-InitialPerfFunctions (Join-Path $Project 'constructor.ps1') @('Reset-NewPatientCase')
$script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-01T00:00:00';Text=''};$script:hospitalControls=@{}
Reset-NewPatientCase $script:universalConfig
Assert-InitialPerf ($null -eq $script:medicalBackupLastCheckpoint) 'A new patient clears the prior verified status snapshot'
Assert-InitialPerf ($script:universalValues.Count -eq 0 -and $script:caseFile -eq '') 'Reset does not retain previous patient answers or card path'
if($Benchmark -and $baseline){
 Initialize-InitialPerfFixture 100
 $before=@();$after=@();$iterations=100
 foreach($entry in @(@('v68',$baseline),@('v69',$optimized))){
  $times=@()
  & $entry[1] | Out-Null
  for($run=0;$run -lt 5;$run++){
   $watch=[Diagnostics.Stopwatch]::StartNew()
   for($i=0;$i -lt $iterations;$i++){$script:universalValues.f0='текст '+$i;if($entry[0] -eq 'v68'){& $entry[1]}else{& $entry[1] 'f0'}}
   $watch.Stop();$times+=@($watch.Elapsed.TotalMilliseconds/$iterations)
  }
  $sorted=@($times|Sort-Object);Write-Output ('BENCH '+$entry[0]+' median_ms_per_input='+$sorted[2].ToString('F4',[Globalization.CultureInfo]::InvariantCulture)+' fields=100 samples=5 events_per_sample=100 native_widgets=mock')
 }
}
Write-Output ('CHECKS '+$script:checks)
