﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v71'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Check([bool]$test,[string]$label){if(-not $test){throw $label};$script:checks++;Write-Output ('PASS '+$label)}
function Assert-Reject([scriptblock]$operation,[string]$label){$threw=$false;try{& $operation | Out-Null}catch{$threw=$true};Assert-Check $threw $label}
function Import-TestFunctions([string]$path,[string[]]$names=@()){
 $t=$null;$e=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$t,[ref]$e)
 if($e.Count){throw ($e|Out-String)}
 foreach($node in $ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
  if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}
 }
}
function Get-TestDocText([string]$path){$z=[IO.Compression.ZipFile]::OpenRead($path);try{$x=Get-XmlPart $z 'word/document.xml';$n=[Xml.XmlNamespaceManager]::new($x.NameTable);$n.AddNamespace('w',$script:ns);return (($x.SelectNodes('//w:t',$n)|ForEach-Object {$_.InnerText}) -join "`n")}finally{$z.Dispose()}}
function Get-TestTree([string]$path){if(-not (Test-Path -LiteralPath $path)){return ''};return ((Get-ChildItem -LiteralPath $path -File -Recurse | Sort-Object FullName | ForEach-Object {$_.FullName+':'+(Get-FileHash -LiteralPath $_.FullName).Hash}) -join ';')}
function Apply-DocumentFont($path){}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-v67-clinical-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
try{
 Import-TestFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
 Import-TestFunctions (Join-Path $Project 'universal.ps1')
 Import-TestFunctions (Join-Path $Project 'forms-v59.ps1')
 Import-TestFunctions (Join-Path $Project 'clinical-stages-v67.ps1')
 $script:medicalProgramRoot=$temp;$script:medicalTemplatesFolder=Join-Path $temp 'Шаблоны'
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-14T10:20:30'}
 $script:universalConfig=New-UniversalConfig
 $script:universalValues=@{patient_name='ТЕСТ ФИО';patient_birth='01.01.2000';patient_address='ТЕСТ АДРЕС';complaints='ПЕРВИЧНЫЕ ЖАЛОБЫ';history='ПЕРВИЧНЫЙ АНАМНЕЗ';examination='ПЕРВИЧНЫЙ ОСМОТР';diagnosis='ПЕРВИЧНЫЙ ДИАГНОЗ'}
 $script:universalDetails=@{}
 $script:medicalClinicalForms=$null;$script:medicalClinicalState=$null
 [void](Initialize-MedicalClinicalWorkspace)
 Assert-Check (@($script:medicalClinicalForms.Diaries).Count -eq 0) 'New workspace starts with zero diary entries'
 $discharge=Get-MedicalClinicalContext 'discharge'
 foreach($id in @('patient_name','patient_birth','patient_address','complaints','history','examination','diagnosis')){Assert-Check ($discharge.Values[$id] -ceq $script:universalValues[$id]) ('Discharge initially links '+$id)}
 foreach($marker in @('FINAL_DIAGNOSIS','EXAMINATION_RESULTS','TREATMENT_RESULTS','RECOMMENDATIONS')){Assert-Check (@(Get-UniversalFields $discharge.Schema | Where-Object {$_.Marker -eq $marker}).Count -eq 1) ('Discharge has editable '+$marker)}
 Assert-Check ($discharge.Values.final_diagnosis -eq 'ПЕРВИЧНЫЙ ДИАГНОЗ') 'Final diagnosis starts from preliminary diagnosis'
 Set-MedicalClinicalValue 'discharge' '' 'complaints' 'ЖАЛОБЫ ЭПИКРИЗА'
 Set-MedicalClinicalValue 'discharge' '' 'patient_name' ''
 $script:universalValues.complaints='ИЗМЕНЕННЫЕ ЖАЛОБЫ';$script:universalValues.patient_name='ОБНОВЛЕННОЕ ФИО';$script:universalValues.history='ОБНОВЛЕННЫЙ АНАМНЕЗ'
 $discharge=Get-MedicalClinicalContext 'discharge'
 Assert-Check ($discharge.Values.complaints -eq 'ЖАЛОБЫ ЭПИКРИЗА') 'Manual discharge edits survive initial updates'
 Assert-Check ($discharge.Values.patient_name -ceq '') 'Explicit clearing survives initial updates'
 Assert-Check ($discharge.Values.history -eq 'ОБНОВЛЕННЫЙ АНАМНЕЗ') 'Unedited source-linked fields follow initial updates'
 Assert-Check ($script:universalValues.complaints -eq 'ИЗМЕНЕННЫЕ ЖАЛОБЫ') 'Editing discharge never changes initial values'
 Reset-MedicalClinicalLink 'discharge' '' 'patient_name'
 Assert-Check ((Get-MedicalClinicalContext 'discharge').Values.patient_name -eq 'ОБНОВЛЕННОЕ ФИО') 'Explicit relink restores current initial value'
 Set-MedicalClinicalValue 'discharge' '' 'examination_results' 'РЕЗУЛЬТАТЫ ОБСЛЕДОВАНИЯ'
 Set-MedicalClinicalValue 'discharge' '' 'treatment_results' 'РЕЗУЛЬТАТЫ ЛЕЧЕНИЯ'
 Set-MedicalClinicalValue 'discharge' '' 'recommendations' 'РЕКОМЕНДАЦИИ'
 $first=Add-MedicalClinicalDiary;$second=Add-MedicalClinicalDiary
 Assert-Check ($first.Id -cne $second.Id) 'Diary entries have distinct stable IDs'
 Set-MedicalClinicalValue 'diary' $first.Id 'diary_complaints' 'ПЕРВЫЙ ДНЕВНИК'
 Set-MedicalClinicalValue 'diary' $second.Id 'diary_complaints' 'ВТОРОЙ ДНЕВНИК'
 Set-MedicalClinicalDate $first.Id ([datetime]'2026-10-14T12:00:00')
 Set-MedicalClinicalDate $second.Id ([datetime]'2026-10-15T13:30:00')
 $diaries=@(Get-MedicalClinicalDiaryContexts)
 Assert-Check ($diaries.Count -eq 2) 'All diaries remain in display order'
 Assert-Check ($diaries[0].Values.diary_complaints -eq 'ПЕРВЫЙ ДНЕВНИК') 'First diary keeps own answers'
 Assert-Check ($diaries[1].Values.diary_complaints -eq 'ВТОРОЙ ДНЕВНИК') 'Second diary keeps own answers'
 Assert-Check ($diaries[0].DateTime -eq [datetime]'2026-10-14T12:00:00') 'Diary timestamp belongs to patient state'
 Assert-Check ($diaries[0].Values.patient_name -eq 'ОБНОВЛЕННОЕ ФИО') 'Diary demographics link current initial values'
 $script:universalValues.patient_address='НОВЫЙ АДРЕС ПОСЛЕ ДНЕВНИКА'
 $checkpointState=Get-MedicalClinicalState
 foreach($entry in $checkpointState.Diaries){Assert-Check ($entry.Values.patient_address -eq 'НОВЫЙ АДРЕС ПОСЛЕ ДНЕВНИКА') 'Checkpoint syncs every linked diary without revisiting its tab'}
 $canonical=Get-UniversalState | ConvertTo-Json -Depth 50 -Compress
 $schema=Copy-MedicalFormSchema $first.Schema
 $schema.Sections[1].Title='ИЗМЕНЕННЫЙ РАЗДЕЛ'
 $schema.Sections[1].Fields[0].Label='ИЗМЕНЕННОЕ ПОЛЕ'
 $custom=New-UniversalField 'extra' 'Добавленное поле' 'DIARY_EXTRA' 'choice_detail'
 $custom.Options=@('Тест');$custom | Add-Member DetailWordPosition 'marker';$custom | Add-Member DetailMarker 'DIARY_EXTRA_DETAIL'
 $schema.Sections[1].Fields+=@($custom)
 [void](Set-MedicalClinicalSchema 'diary' $first.Id $schema 'МОЙ ДНЕВНИК')
 Set-MedicalClinicalValue 'diary' $first.Id 'extra' 'Тест' 'УТОЧНЕНИЕ ДНЕВНИКА'
 $first=Get-MedicalClinicalContext 'diary' $first.Id
 Assert-Check ($first.Title -eq 'МОЙ ДНЕВНИК') 'Diary title is independently editable'
 Assert-Check ($first.Values.diary_complaints -eq 'ПЕРВЫЙ ДНЕВНИК') 'Schema edits preserve answers by stable ID'
 Assert-Check ($first.Details.extra -eq 'УТОЧНЕНИЕ ДНЕВНИКА') 'Diary detail values use independent state maps'
 Assert-Check ((Get-UniversalState | ConvertTo-Json -Depth 50 -Compress) -ceq $canonical) 'Clinical edits leave entire canonical initial state intact'
 Assert-Reject {Set-MedicalClinicalValue 'diary' $first.Id 'unknown' 'x'} 'Unknown clinical field is rejected'
 Assert-Reject {Get-MedicalClinicalContext 'diary' 'unknown'} 'Unknown diary ID is rejected'
 $forms=Get-MedicalClinicalFormData;$state=Get-MedicalClinicalState
 $structureJson=$forms|ConvertTo-Json -Depth 60
 foreach($secret in @('ПЕРВЫЙ ДНЕВНИК','ВТОРОЙ ДНЕВНИК','УТОЧНЕНИЕ ДНЕВНИКА','РЕЗУЛЬТАТЫ ЛЕЧЕНИЯ','ОБНОВЛЕННОЕ ФИО','2026-10-14T12:00:00')){Assert-Check (-not $structureJson.Contains($secret)) ('Reusable structure excludes '+$secret)}
 $stateJson=$state|ConvertTo-Json -Depth 60
 Assert-Check ($stateJson.Contains('ПЕРВЫЙ ДНЕВНИК') -and $stateJson.Contains('УТОЧНЕНИЕ ДНЕВНИКА')) 'Patient state includes all diary answers and details'
 [void](Initialize-MedicalClinicalWorkspace $forms)
 Assert-Check ([string]::IsNullOrEmpty((Get-MedicalClinicalContext 'diary' $first.Id).Values.diary_complaints)) 'Opening reusable diary structure clears answers'
 Restore-MedicalClinicalState ($stateJson|ConvertFrom-Json)
 Assert-Check ((Get-MedicalClinicalContext 'diary' $first.Id).Values.diary_complaints -eq 'ПЕРВЫЙ ДНЕВНИК') 'Patient state restores diary answer by stable ID'
 Assert-Check ((Get-MedicalClinicalContext 'diary' $first.Id).Details.extra -eq 'УТОЧНЕНИЕ ДНЕВНИКА') 'Patient state restores diary clarification'
 Assert-Check ((Get-MedicalClinicalContext 'diary' $second.Id).DateTime -eq [datetime]'2026-10-15T13:30:00') 'Patient state restores individual diary date'
 Assert-Check ((Get-MedicalClinicalContext 'discharge').Values.complaints -eq 'ЖАЛОБЫ ЭПИКРИЗА') 'Patient state restores discharge overrides'
 Assert-Check ((Get-MedicalClinicalContext 'discharge').Values.recommendations -eq 'РЕКОМЕНДАЦИИ') 'Patient state restores clinical final fields'
 $diaryDoc=Join-Path $temp 'diary.docx';$first=Get-MedicalClinicalContext 'diary' $first.Id
 Save-UniversalDocument $diaryDoc $first.Schema $first.Values $first.DateTime $first.Details $true
 $docText=Get-TestDocText $diaryDoc
 foreach($text in @('Дневник наблюдения','Дата и время записи: 14.10.2026 12:00','ПЕРВЫЙ ДНЕВНИК','УТОЧНЕНИЕ ДНЕВНИКА','ОБНОВЛЕННОЕ ФИО')){Assert-Check ($docText.Contains($text)) ('Diary DOCX includes '+$text)}
 Assert-Check (-not $docText.Contains('Первичный осмотр')) 'Generated diary Word title is stage-aware'
 $dischargeDoc=Join-Path $temp 'discharge.docx';$discharge=Get-MedicalClinicalContext 'discharge'
 Save-UniversalDocument $dischargeDoc $discharge.Schema $discharge.Values $discharge.DateTime $discharge.Details $true
 $docText=Get-TestDocText $dischargeDoc
 foreach($text in @('Выписной эпикриз','ЖАЛОБЫ ЭПИКРИЗА','РЕЗУЛЬТАТЫ ОБСЛЕДОВАНИЯ','РЕЗУЛЬТАТЫ ЛЕЧЕНИЯ','РЕКОМЕНДАЦИИ')){Assert-Check ($docText.Contains($text)) ('Discharge DOCX includes '+$text)}
 $formPath=Join-Path $temp 'All stages.mcform'
 $envelope=Write-MedicalForm $formPath $script:universalConfig 'ФОРМА С ДНЕВНИКАМИ'
 Assert-Check (@($envelope.StageForms.Diaries).Count -eq 2) 'MCFORM stores every individual diary schema'
 Assert-Check ($envelope.StageForms.Discharge.Schema.DocumentTitle -eq 'Выписной эпикриз') 'MCFORM stores discharge schema'
 $json=[IO.File]::ReadAllText($formPath)
 foreach($secret in @('ПЕРВЫЙ ДНЕВНИК','ВТОРОЙ ДНЕВНИК','УТОЧНЕНИЕ ДНЕВНИКА','РЕКОМЕНДАЦИИ','ОБНОВЛЕННОЕ ФИО')){Assert-Check (-not $json.Contains('"'+$secret+'"')) ('MCFORM excludes patient answer '+$secret)}
 foreach($definition in @($envelope.StageForms.Diaries)+@($envelope.StageForms.Discharge)){
  Assert-Check ($definition.TemplateSha256 -cmatch '^[a-f0-9]{64}$') 'Each stage template has its own SHA-256'
  Assert-Check ([Convert]::FromBase64String($definition.TemplateBase64).Length -gt 100) 'Each stage Word template is embedded'
 }
 $newRoot=Join-Path $temp 'other program';[void][IO.Directory]::CreateDirectory($newRoot)
 $script:medicalProgramRoot=$newRoot;$script:medicalTemplatesFolder=Join-Path $newRoot 'Шаблоны'
 $opened=Read-MedicalForm $formPath
 Assert-Check (@($opened.StageForms.Diaries).Count -eq 2) 'MCFORM opens all diary layouts in another program directory'
 foreach($definition in @($opened.StageForms.Diaries)+@($opened.StageForms.Discharge)){Assert-Check ([IO.File]::Exists((Join-Path $newRoot $definition.Schema.Template))) 'MCFORM restores embedded Word template for every stage'}
 $bad=$json|ConvertFrom-Json;$bad.StageForms.Diaries[1].TemplateSha256=('0'*64)
 $badPath=Join-Path $temp 'broken.mcform';[IO.File]::WriteAllText($badPath,($bad|ConvertTo-Json -Depth 60))
 $before=Get-TestTree $newRoot
 Assert-Reject {Read-MedicalForm $badPath} 'Corrupted stage hash rejects entire form'
 Assert-Check ((Get-TestTree $newRoot) -ceq $before) 'All stage hashes validate before importing initial template'
 $bad=$json|ConvertFrom-Json;$bad.StageForms.Diaries[0].PSObject.Properties.Remove('TemplateBase64')
 $badPath=Join-Path $temp 'stage-asset-missing.mcform';[IO.File]::WriteAllText($badPath,($bad|ConvertTo-Json -Depth 60))
 $before=Get-TestTree $newRoot
 Assert-Reject {Read-MedicalForm $badPath} 'Reusable form rejects a stage without its portable Word asset'
 Assert-Check ((Get-TestTree $newRoot) -ceq $before) 'Missing stage asset rejects form before any template imports'
 $bad=$forms|ConvertTo-Json -Depth 60|ConvertFrom-Json;$bad.Diaries[1].Id=$bad.Diaries[0].Id
 Assert-Reject {Initialize-MedicalClinicalWorkspace $bad} 'Duplicate diary schema IDs reject form'
 $beforeState=Get-MedicalClinicalState|ConvertTo-Json -Depth 60 -Compress
 $bad=$state|ConvertTo-Json -Depth 60|ConvertFrom-Json;$bad.Diaries[1].Id=$bad.Diaries[0].Id
 Assert-Reject {Restore-MedicalClinicalState $bad} 'Duplicate patient diary IDs reject restore'
 Assert-Check ((Get-MedicalClinicalState|ConvertTo-Json -Depth 60 -Compress) -ceq $beforeState) 'Rejected restore leaves existing patient state intact'
 $originalInitial=Copy-UniversalObject $script:universalConfig
 $name=@(Get-UniversalFields $script:universalConfig | Where-Object {$_.System -eq 'name'})[0]
 $name.Type='choice_detail';$name.Options=@('ИВАН');$script:universalValues.patient_name='ИВАН';$script:universalDetails.patient_name='ПЕТРОВ'
 [void](Initialize-MedicalClinicalWorkspace)
 $third=Add-MedicalClinicalDiary
 Assert-Check ($third.Values.patient_name -eq 'ИВАН: ПЕТРОВ') 'Diary text demographics retain initial choice clarification'
 Set-MedicalClinicalValue 'diary' $third.Id 'patient_name' 'ИВАН: ПЕТРОВ'
 Assert-Check (-not $third.Overrides.ContainsKey('patient_name')) 'Capturing converted linked demographics does not create false override'
 $script:universalDetails.patient_name='СИДОРОВ'
 Assert-Check ((Get-MedicalClinicalContext 'diary' $third.Id).Values.patient_name -eq 'ИВАН: СИДОРОВ') 'Converted linked demographic stays live after capture'
 $name.Id='diary_complaints';$name.Marker='DIARY_COMPLAINTS';$script:universalValues=@{diary_complaints='ИВАН'};$script:universalDetails=@{diary_complaints='ПЕТРОВ'}
 $collision=New-MedicalDiarySchema
 Assert-Check (@(Get-UniversalFields $collision | Where-Object {$_.Id -eq 'diary_complaints'}).Count -eq 1) 'Generated diary IDs avoid imported demographic collisions'
 Assert-Check (@(Get-UniversalFields $collision | Where-Object {$_.Marker -eq 'DIARY_COMPLAINTS'}).Count -eq 1) 'Generated diary markers avoid imported demographic collisions'
 $script:universalConfig=$originalInitial;$script:universalValues=@{};$script:universalDetails=@{}
 [void](Initialize-MedicalClinicalWorkspace $forms)
 $definition=@($script:medicalClinicalForms.Diaries)[0];$definition.Schema.AutoTemplate=$false;$definition.Schema.Template='missing-original.docx'
 $backup=Get-MedicalClinicalPortableForms $true
 Assert-Check ($backup.Diaries[0].TemplateMissing -eq $true) 'Recovery structure snapshot survives missing Word template'
 Assert-Reject {Get-MedicalClinicalPortableForms $false} 'Normal reusable form save requires missing template restoration'
 Remove-MedicalClinicalDiary $first.Id
 Assert-Check (@(Get-MedicalClinicalDiaryContexts).Count -eq 1) 'Removing diary removes structure and matching patient entry'
 Assert-Check ((Get-MedicalClinicalContext 'diary' $second.Id).Id -eq $second.Id) 'Removing earlier diary preserves later stable ID'
 $canonical=Get-UniversalState|ConvertTo-Json -Depth 50 -Compress
 $script:fields=@([pscustomobject]@{Sentinel='canonical fields'});$script:source='canonical-source';$script:stageData=@{sentinel=@('stay')}
 $rawRecord=[pscustomobject]@{diaryCount=2;admissionDate='2026-10-14';templates=[pscustomobject]@{diary='absent-diary.docx';discharge='absent-discharge.docx'};stages=[pscustomobject]@{diary_1=@('СЫРОЙ ПЕРВЫЙ','',"ТРЕТИЙ`nМНОГОСТРОЧНЫЙ");diary_2=@('СЫРОЙ ВТОРОЙ');discharge=@('СТАРЫЙ ЭПИКРИЗ','') }}
 $beforeRecord=$rawRecord|ConvertTo-Json -Depth 50 -Compress
 [void](Initialize-MedicalClinicalWorkspace)
 [void](Import-MedicalLegacyClinicalStages $rawRecord)
 $contexts=@(Get-MedicalClinicalDiaryContexts)
 Assert-Check ($contexts.Count -eq 2) 'Missing legacy Word retains every diary'
 Assert-Check ($contexts[0].Id -eq 'legacy_diary_1' -and $contexts[1].Id -eq 'legacy_diary_2') 'Migrated diary IDs follow numeric original order'
 $legacyFields=@(Get-UniversalFields $contexts[0].Schema)
 Assert-Check ($legacyFields.Count -eq 3) 'Missing source creates one editable field for every original array position'
 Assert-Check ($contexts[0].Values[$legacyFields[0].Id] -eq 'СЫРОЙ ПЕРВЫЙ') 'First raw legacy value survives'
 Assert-Check ($contexts[0].Values[$legacyFields[1].Id] -ceq '') 'Empty raw legacy value retains its position'
 Assert-Check ($contexts[0].Values[$legacyFields[2].Id] -eq "ТРЕТИЙ`nМНОГОСТРОЧНЫЙ") 'Multiline raw legacy value survives'
 Assert-Check (@($legacyFields | Where-Object {$_.Type -ne 'multiline' -or $_.Required}).Count -eq 0) 'Raw legacy fields remain freely editable'
 $legacyDischarge=Get-MedicalClinicalContext 'discharge'
 Assert-Check ($legacyDischarge.Values.legacy_discharge_1 -eq 'СТАРЫЙ ЭПИКРИЗ') 'Missing discharge source keeps original answer'
 Assert-Check ($legacyDischarge.Values.patient_name -eq [string]$script:universalValues.patient_name) 'Migrated discharge also links current initial demographics'
 Assert-Check (($rawRecord|ConvertTo-Json -Depth 50 -Compress) -ceq $beforeRecord) 'Migration never alters original record stages'
 Assert-Check ($script:stageData.sentinel[0] -eq 'stay' -and $script:source -eq 'canonical-source' -and $script:fields[0].Sentinel -eq 'canonical fields') 'Migration never mutates old arrays or canonical SDT state'
 Assert-Check ((Get-UniversalState|ConvertTo-Json -Depth 50 -Compress) -ceq $canonical) 'Migration never changes canonical initial form or answers'
 $beforeLive=(Get-MedicalClinicalState|ConvertTo-Json -Depth 60 -Compress)
 $bad=Get-MedicalClinicalState;$bad.Diaries[0].DateTime='14/10/2026'
 Assert-Reject {Test-MedicalClinicalState $bad (Get-MedicalClinicalFormData)} 'Pure state check rejects non-ISO legacy date'
 Assert-Check ((Get-MedicalClinicalState|ConvertTo-Json -Depth 60 -Compress) -ceq $beforeLive) 'Pure state check leaves live patient state unchanged'
 $bad=Get-MedicalClinicalState;$bad.Diaries[0].Id='unknown-id'
 Assert-Reject {Test-MedicalClinicalState $bad (Get-MedicalClinicalFormData)} 'Pure state check rejects answers without matching schema'
 $templatePath=Join-Path $newRoot 'original-legacy.docx'
 New-UniversalTemplate $templatePath (New-UniversalConfig)
 $fixtureXml='<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>Legacy layout heading</w:t></w:r></w:p><w:p><w:sdt><w:sdtPr><w:alias w:val="Z first alias"/><w:id w:val="9"/></w:sdtPr><w:sdtContent><w:r><w:t>SOURCE SECRET ONE</w:t></w:r></w:sdtContent></w:sdt></w:p><w:p><w:sdt><w:sdtPr><w:alias w:val="A second alias"/><w:id w:val="9"/><w:dropDownList><w:listItem w:displayText="Option B" w:value="B"/></w:dropDownList></w:sdtPr><w:sdtContent><w:r><w:t>SOURCE SECRET TWO</w:t></w:r></w:sdtContent></w:sdt></w:p><w:p><w:sdt><w:sdtPr><w:tag w:val="third tag"/></w:sdtPr><w:sdtContent><w:r><w:t>SOURCE SECRET THREE</w:t></w:r></w:sdtContent></w:sdt></w:p><w:sectPr><w:pgSz w:w="11906" w:h="16838"/></w:sectPr></w:body></w:document>'
 $zip=[IO.Compression.ZipFile]::Open($templatePath,[IO.Compression.ZipArchiveMode]::Update)
 try{$entry=$zip.GetEntry('word/document.xml');$entry.Delete();$entry=$zip.CreateEntry('word/document.xml');$writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false));try{$writer.Write($fixtureXml)}finally{$writer.Dispose()}}finally{$zip.Dispose()}
 $originalHash=(Get-FileHash -LiteralPath $templatePath).Hash
 $legacyRecord=[pscustomobject]@{diaryCount=1;admissionDate='2026-10-14';templates=[pscustomobject]@{diary=$templatePath;discharge=$templatePath};stages=[pscustomobject]@{diary_1=@('ORDER FIRST','ORDER SECOND','ORDER THIRD','ORDER EXTRA');discharge=@('DISCHARGE FIRST','DISCHARGE SECOND','DISCHARGE THIRD','DISCHARGE EXTRA')}}
 [void](Initialize-MedicalClinicalWorkspace)
 [void](Import-MedicalLegacyClinicalStages $legacyRecord)
 $context=@(Get-MedicalClinicalDiaryContexts)[0];$fields=@(Get-UniversalFields $context.Schema)
 Assert-Check ($fields.Count -eq 4) 'SDT migration keeps extra saved positions beyond source controls'
 Assert-Check (($fields.Label -join '|') -eq 'Z first alias|A second alias|third tag|Поле прежней карты 4') 'SDT aliases preserve exact original XML order'
 for($i=0;$i -lt 4;$i++){Assert-Check ($context.Values[$fields[$i].Id] -ceq $legacyRecord.stages.diary_1[$i]) ('Original SDT value index '+$i+' maps exactly')}
 Assert-Check (@($fields | Where-Object {$_.WordId} | Select-Object -ExpandProperty WordId -Unique).Count -eq 3) 'Duplicate and missing source SDT IDs become unique portable bindings'
 Assert-Check ($fields[1].Type -eq 'choice' -and $fields[1].Options[0] -eq 'Option B') 'SDT dropdown options remain structure metadata'
 Assert-Check (-not $context.Schema.AutoTemplate) 'Known legacy Word source keeps its authored layout'
 Assert-Check ((Get-FileHash -LiteralPath $templatePath).Hash -ceq $originalHash) 'Legacy source Word bytes are never changed'
 $managed=Get-UniversalTemplatePath $context.Schema;$managedText=Get-TestDocText $managed
 Assert-Check ($managedText.Contains('Legacy layout heading')) 'Portable legacy Word preserves original static layout'
 foreach($secret in @('SOURCE SECRET ONE','SOURCE SECRET TWO','SOURCE SECRET THREE','ORDER FIRST','ORDER SECOND','ORDER THIRD','ORDER EXTRA')){Assert-Check (-not $managedText.Contains($secret)) ('Portable legacy source excludes answer '+$secret)}
 $output=Join-Path $temp 'migrated-diary.docx'
 Save-UniversalDocument $output $context.Schema $context.Values $context.DateTime $context.Details $true
 $outputText=Get-TestDocText $output
 foreach($answer in $legacyRecord.stages.diary_1){Assert-Check ($outputText.Contains($answer)) ('Migrated formatted diary exports '+$answer)}
 $output=Join-Path $temp 'migrated-discharge.docx';$context=Get-MedicalClinicalContext 'discharge'
 Save-UniversalDocument $output $context.Schema $context.Values $context.DateTime $context.Details $true
 $outputText=Get-TestDocText $output
 foreach($answer in $legacyRecord.stages.discharge){Assert-Check ($outputText.Contains($answer)) ('Migrated formatted discharge exports '+$answer)}
 Assert-Check ($outputText.Contains([string]$script:universalValues.patient_name)) 'Migrated discharge exports linked initial demographics beside recovered answers'
 $portable=Get-MedicalClinicalPortableForms
 $portableJson=$portable|ConvertTo-Json -Depth 60
 foreach($secret in @('ORDER FIRST','ORDER SECOND','DISCHARGE FIRST','DISCHARGE EXTRA')){Assert-Check (-not $portableJson.Contains($secret)) ('Portable legacy structures exclude '+$secret)}
 $portableState=Get-MedicalClinicalState
 [void](Initialize-MedicalClinicalWorkspace $portable)
 Restore-MedicalClinicalState $portableState
 Assert-Check ((Get-MedicalClinicalContext 'diary' 'legacy_diary_1').Values.legacy_diary1_4 -eq 'ORDER EXTRA') 'Portable legacy state restores extra answer by stable ID'
 $pureBefore=Get-MedicalClinicalFormData|ConvertTo-Json -Depth 60 -Compress
 $explicit=New-MedicalClinicalFormData (New-UniversalConfig)
 Assert-Check ($explicit.Discharge.Schema.DocumentTitle -eq 'Выписной эпикриз') 'Explicit initial-schema factory creates valid discharge independently'
 Assert-Check ((Get-MedicalClinicalFormData|ConvertTo-Json -Depth 60 -Compress) -ceq $pureBefore) 'Explicit schema factory leaves current stage forms unchanged'
 $script:universalConfig=New-UniversalConfig;$script:universalValues=@{patient_name='ТЕКУЩЕЕ ФИО';history='SOURCE HISTORY';diagnosis='SOURCE DIAGNOSIS'};$script:universalDetails=@{}
 [void](Initialize-MedicalClinicalWorkspace)
 Set-MedicalClinicalValue 'discharge' '' 'history' 'MANUAL HISTORY'
 Set-MedicalClinicalValue 'discharge' '' 'final_diagnosis' 'MANUAL FINAL DIAGNOSIS'
 Set-MedicalClinicalValue 'discharge' '' 'treatment_results' 'MANUAL TREATMENT RESULT'
 $extra=New-UniversalField 'new_initial_field' 'Новый раздел из осмотра' 'NEW_INITIAL_FIELD';$extra.Required=$false
 $script:universalConfig.Sections+=@([pscustomobject]@{Id='new_initial_section';Title='Новый раздел первичного осмотра';Fields=@($extra)})
 $script:universalValues.new_initial_field='NEW LINKED INITIAL ANSWER'
 $script:universalConfig.Sections[2].Title='Обновленное название анамнеза';$script:universalConfig.Sections[2].Fields[0].Label='Обновленное поле анамнеза'
 $context=Get-MedicalClinicalContext 'discharge'
 Assert-Check (@(Get-UniversalFields $context.Schema | Where-Object {$_.Id -eq 'new_initial_field'}).Count -eq 1) 'Default discharge adopts fields added later to primary form'
 Assert-Check ($context.Values.new_initial_field -eq 'NEW LINKED INITIAL ANSWER') 'New default discharge field links current primary answer'
 Assert-Check ($context.Schema.Sections[2].Title -eq 'Обновленное название анамнеза') 'Default discharge follows renamed primary sections'
 Assert-Check ($context.Values.history -eq 'MANUAL HISTORY' -and $context.Values.treatment_results -eq 'MANUAL TREATMENT RESULT') 'Default schema follow preserves manual edits and final results'
 $collisionField=New-UniversalField 'final_diagnosis' 'Специальное поле первичного осмотра' 'FINAL_DIAGNOSIS';$collisionField.Required=$false
 $script:universalConfig.Sections[-1].Fields+=@($collisionField);$script:universalValues.final_diagnosis='PRIMARY COLLISION ANSWER'
 $context=Get-MedicalClinicalContext 'discharge';$generatedId=[string]$script:medicalClinicalForms.Discharge.GeneratedFieldIds.final_diagnosis
 Assert-Check ($generatedId -ne 'final_diagnosis') 'Default schema follow separates new primary ID from generated final diagnosis'
 Assert-Check ($context.Values[$generatedId] -eq 'MANUAL FINAL DIAGNOSIS') 'Generated result ID collision retains original manual final diagnosis'
 Assert-Check ($context.Values.final_diagnosis -eq 'PRIMARY COLLISION ANSWER') 'Generated result ID collision links independent primary answer'
 $custom=Copy-MedicalFormSchema $context.Schema;$custom.DocumentTitle='Мой оформленный эпикриз';$custom.Sections[0].Title='Мой раздел эпикриза'
 [void](Set-MedicalClinicalSchema 'discharge' '' $custom)
 $extra=New-UniversalField 'later_field' 'Later primary field' 'LATER_PRIMARY';$extra.Required=$false;$script:universalConfig.Sections[-1].Fields+=@($extra)
 $context=Get-MedicalClinicalContext 'discharge'
 Assert-Check ($context.Schema.DocumentTitle -eq 'Мой оформленный эпикриз' -and $context.Schema.Sections[0].Title -eq 'Мой раздел эпикриза') 'Editing discharge schema retains its authored title and sections'
 Assert-Check (@(Get-UniversalFields $context.Schema | Where-Object {$_.Id -eq 'later_field'}).Count -eq 0) 'Customized discharge schema is preserved when primary structure changes'
 Assert-Check ($context.Values[$generatedId] -eq 'MANUAL FINAL DIAGNOSIS') 'Customized discharge retains remapped final diagnosis answer'
 $portable=Get-MedicalClinicalPortableForms;$state=Get-MedicalClinicalState
 [void](Initialize-MedicalClinicalWorkspace $portable);Restore-MedicalClinicalState $state
 Assert-Check ((Get-MedicalClinicalContext 'discharge').Schema.DocumentTitle -eq 'Мой оформленный эпикриз') 'Portable customized discharge does not resume default schema-follow'
 $diary=Add-MedicalClinicalDiary;$forms=Get-MedicalClinicalFormData
 foreach($date in @('1600-01-01T00:00:00','9999-01-01T00:00:00')){$invalid=Get-MedicalClinicalState;$invalid.Diaries[0].DateTime=$date;Assert-Reject {Test-MedicalClinicalState $invalid $forms} ('Pure state check rejects native calendar date '+$date)}
 $invalid=Get-MedicalClinicalFormData;$invalid.Diaries[0].Id=42
 Assert-Reject {Copy-MedicalClinicalFormData $invalid} 'Diary structure IDs must be strings'
 $invalid=Get-MedicalClinicalState;$invalid.Diaries[0].Id=42
 Assert-Reject {Test-MedicalClinicalState $invalid $forms} 'Diary answer IDs must be strings'
 $context=Get-MedicalClinicalContext 'discharge';$path=Join-Path $temp 'standalone-discharge.docx'
 Save-UniversalDocument $path $context.Schema $context.Values $context.DateTime $context.Details $true 'discharge'
 Assert-Check ((Read-UniversalDocumentState $path).Stage -eq 'discharge') 'Standalone discharge Word state identifies its own clinical stage'
 $existing=(Get-FileHash -LiteralPath $path).Hash
 Assert-Reject {Save-UniversalDocument $path $context.Schema $context.Values $context.DateTime $context.Details $true 'bad-stage'} 'Unknown standalone document stage is rejected'
 Assert-Check ((Get-FileHash -LiteralPath $path).Hash -ceq $existing) 'Rejected standalone stage leaves previous output intact'
 $path=Join-Path $temp 'standalone-primary.docx';Save-UniversalDocument $path $script:universalConfig $script:universalValues $script:admissionControl.Value $script:universalDetails $true
 Assert-Check ($null -eq (Read-UniversalDocumentState $path).PSObject.Properties['Stage']) 'Primary Word state remains backward compatible without extra stage metadata'
 Write-Output ('CHECKS '+$script:checks)
}finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force -Recurse}}
