﻿# Templates belong to forms. Cards carry verified, unfilled source copies so
# moving a saved card never requires rebuilding its authored Word layout.
function Get-MedicalRecoveryProperty($value,[string]$name){
 if($null -eq $value){return $null}
 if($value -is [Collections.IDictionary]){return $value[$name]}
 return $value.$name
}

function Get-MedicalRecoveryLeaf([string]$reference){
 return [IO.Path]::GetFileName($reference.Replace('\','/'))
}

function Get-MedicalRecoveryAbsolutePath([string]$reference){
 if([string]::IsNullOrWhiteSpace($reference)){return ''}
 $reference=$reference.Replace('\',[IO.Path]::DirectorySeparatorChar)
 if(-not [IO.Path]::IsPathRooted($reference)){$reference=Join-Path $script:medicalProgramRoot $reference}
 return [IO.Path]::GetFullPath($reference)
}

function Read-MedicalRecoveryTemplateBytes([string]$path){
 $info=New-Object IO.FileInfo($path)
 if(-not $info.Exists){throw ('Файл шаблона Word не найден: '+$path)}
 if($info.Length -gt 67108864){throw 'Шаблон Word превышает допустимый размер 64 МБ.'}
 $bytes=[IO.File]::ReadAllBytes($path)
 if($bytes.Length -gt 67108864){throw 'Шаблон Word превышает допустимый размер 64 МБ.'}
 Test-MedicalTemplateBytes $bytes
 return ,$bytes
}

function Get-MedicalRecoveryImportName([string]$name){
 $normalized=Get-MedicalManagedTemplateName $name
 $extension=[IO.Path]::GetExtension($normalized)
 $stem=[IO.Path]::GetFileNameWithoutExtension($normalized)
 # Old editors could concatenate storage GUIDs into a 200-character filename.
 # The original name remains in the card, while the new local copy stays usable
 # with Windows PowerShell 5.1 in a long Desktop/OneDrive program folder.
 if($stem.Length -gt 80 -and $stem -match '^[0-9a-fA-F-]+$'){$stem='Восстановленный шаблон'}
 $folderLength=[IO.Path]::GetFullPath($script:medicalTemplatesFolder).Length
 if($folderLength+49 -ge 260){throw 'Путь к папке программы слишком длинный для сохранения шаблона. Переместите программу в папку с более коротким путём.'}
 $budget=240-($folderLength+1+$extension.Length+13)
 if($budget -lt 1){throw 'Путь к папке программы слишком длинный для сохранения шаблона. Переместите программу в папку с более коротким путём.'}
 $budget=[Math]::Min(80,$budget)
 if($stem.Length -gt $budget){$stem=$stem.Substring(0,$budget).TrimEnd([char[]]@(' ','.','-'))}
 if([string]::IsNullOrWhiteSpace($stem)){$stem='Шаблон';if($stem.Length -gt $budget){$stem=$stem.Substring(0,$budget)}}
 return (Get-MedicalTemplateName ($stem+$extension))
}

function Resolve-MedicalTemplateReference([string]$reference,[string]$casePath='',$snapshot=$null){
 if([string]::IsNullOrWhiteSpace($reference)){return ''}
 $leaf=Get-MedicalRecoveryLeaf $reference
 if([IO.Path]::GetExtension($leaf) -notin @('.docx','.dotx')){return ''}
 $expectedHash=''
 if($null -ne $snapshot){$expectedHash=[string](Get-MedicalRecoveryProperty $snapshot 'Sha256');if($expectedHash -cnotmatch '^[a-fA-F0-9]{64}$'){throw 'Неверная контрольная сумма сохранённого Word-шаблона.'}}
 $exact=Get-MedicalRecoveryAbsolutePath $reference
 if([IO.File]::Exists($exact)){
  try{
   $bytes=Read-MedicalRecoveryTemplateBytes $exact
   if(-not $expectedHash -or (Get-MedicalBytesSha256 $bytes) -ieq $expectedHash){return $exact}
  }catch{
   # A damaged local copy is preserved. A verified embedded source can still
   # recover the card, or the user can explicitly choose the correct original.
  }
 }
 # Only the exact stored filename is considered. A similar human title does
 # not establish which of the user's differently formatted documents to use.
 $folders=@($script:medicalTemplatesFolder,$script:medicalProgramRoot)
 if(-not [string]::IsNullOrWhiteSpace($casePath)){
  $cardFolder=[IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($casePath))
  $folders+=@((Join-Path $cardFolder 'Шаблоны'),$cardFolder)
 }
 $seen=@{};$candidates=New-Object Collections.ArrayList
 foreach($folder in $folders){
  if([string]::IsNullOrWhiteSpace([string]$folder)){continue}
  $candidate=[IO.Path]::GetFullPath((Join-Path $folder $leaf))
  if($seen.ContainsKey($candidate)) {continue};$seen[$candidate]=$true
  if(-not [IO.File]::Exists($candidate)){continue}
  try{$bytes=Read-MedicalRecoveryTemplateBytes $candidate;$hash=Get-MedicalBytesSha256 $bytes}catch{continue}
  if($expectedHash -and $hash -ine $expectedHash){continue}
  [void]$candidates.Add([pscustomobject]@{Path=$candidate;Hash=$hash})
 }
 if($candidates.Count -eq 0){return ''}
 $hashes=@($candidates | ForEach-Object {$_.Hash} | Select-Object -Unique)
 if($hashes.Count -ne 1){return ''}
 return [string]$candidates[0].Path
}

function Get-MedicalValidatedCardTemplateSnapshots($snapshots){
 $validated=@{};$total=0L
 if($null -eq $snapshots){return $validated}
 $names=if($snapshots -is [Collections.IDictionary]){@($snapshots.Keys)}else{@($snapshots.PSObject.Properties | ForEach-Object {$_.Name})}
 foreach($stage in $names){
  if([string]$stage -notin @('initial','diary','discharge')){throw 'В карте указан неизвестный этап Word-шаблона.'}
  $snapshot=Get-MedicalRecoveryProperty $snapshots ([string]$stage)
  $name=Get-MedicalTemplateName ([string](Get-MedicalRecoveryProperty $snapshot 'Name'))
  $hash=[string](Get-MedicalRecoveryProperty $snapshot 'Sha256')
  $payload=Get-MedicalRecoveryProperty $snapshot 'BytesBase64'
  if($hash -cnotmatch '^[a-fA-F0-9]{64}$' -or $payload -isnot [string] -or [string]::IsNullOrWhiteSpace($payload)){throw 'В карте повреждена сохранённая копия Word-шаблона.'}
  if($payload.Length -gt 89478488){throw 'Сохранённый Word-шаблон превышает допустимый размер 64 МБ.'}
  try{$bytes=[Convert]::FromBase64String($payload)}catch{throw 'В карте повреждено кодирование сохранённого Word-шаблона.'}
  $total+=$bytes.Length
  if($bytes.Length -gt 67108864 -or $total -gt 67108864){throw 'Сохранённые Word-шаблоны карты превышают допустимый общий размер 64 МБ.'}
  if((Get-MedicalBytesSha256 $bytes) -ine $hash){throw 'Контрольная сумма сохранённого Word-шаблона не совпадает. Карта повреждена.'}
  Test-MedicalTemplateBytes $bytes
  $validated[[string]$stage]=[pscustomobject]@{Name=$name;Bytes=$bytes;Sha256=$hash.ToLowerInvariant()}
 }
 return $validated
}

function Get-MedicalCardTemplateSnapshots {
 $result=[ordered]@{};$total=0L;$generated=$null
 try{
  foreach($stage in @('initial','diary','discharge')){
   $path=''
   if($stage -eq 'initial' -and $script:universalConfig){
    if($script:universalConfig.AutoTemplate){
     $generated=Join-Path ([IO.Path]::GetTempPath()) ('mc-card-source-'+[guid]::NewGuid().ToString('N')+'.docx')
     New-UniversalTemplate $generated $script:universalConfig;$path=$generated
    }else{
     $path=Resolve-MedicalTemplateReference ([string]$script:universalConfig.Template) ([string]$script:caseFile)
     if(-not $path){$path=Resolve-MedicalTemplateReference ([string](Get-MedicalRecoveryProperty $script:stageTemplates 'initial')) ([string]$script:caseFile)}
    }
   }else{
    $reference=[string](Get-MedicalRecoveryProperty $script:stageTemplates $stage)
    if($script:stage -eq $stage -and [IO.File]::Exists([string]$script:source)){$reference=[string]$script:source}
    $path=Resolve-MedicalTemplateReference $reference ([string]$script:caseFile)
   }
   if(-not $path){continue}
   $bytes=Read-MedicalRecoveryTemplateBytes $path;$total+=$bytes.Length
   if($total -gt 67108864){throw 'Исходные Word-шаблоны карты превышают допустимый общий размер 64 МБ.'}
   $name=Get-MedicalRecoveryLeaf $path
   if($stage -eq 'initial' -and $script:universalConfig.AutoTemplate){$name='Шаблон первичного осмотра.docx'}
   $name=Get-MedicalTemplateName $name
   $result[$stage]=[pscustomobject]@{Name=$name;Sha256=(Get-MedicalBytesSha256 $bytes);BytesBase64=[Convert]::ToBase64String($bytes)}
  }
  return $result
 }finally{if($generated -and [IO.File]::Exists($generated)){[IO.File]::Delete($generated)}}
}

function Restore-MedicalCardTemplateReferences($record,[string]$cardPath){
 # Validate every embedded copy before creating folders or touching templates.
 if($record.universal){Assert-UniversalConfig $record.universal.Schema}
 $validated=Get-MedicalValidatedCardTemplateSnapshots (Get-MedicalRecoveryProperty $record 'TemplateSnapshots')
 if($record.universal -and $validated.ContainsKey('initial')){
  $checkPath=Join-Path ([IO.Path]::GetTempPath()) ('mc-card-check-'+[guid]::NewGuid().ToString('N')+[IO.Path]::GetExtension($validated.initial.Name))
  try{
   [IO.File]::WriteAllBytes($checkPath,$validated.initial.Bytes)
   Assert-MedicalEditorTemplateCoverage $record.universal.Schema (Read-MedicalTemplateModel $checkPath)
  }finally{if([IO.File]::Exists($checkPath)){[IO.File]::Delete($checkPath)}}
 }
 $copy=Copy-UniversalObject $record
 $plans=New-Object Collections.ArrayList
 foreach($stage in @('initial','diary','discharge')){
  $schema=if($copy.universal){$copy.universal.Schema}else{$null}
  $reference=[string](Get-MedicalRecoveryProperty $copy.templates $stage)
  $snapshot=if($validated.ContainsKey($stage)){$validated[$stage]}else{$null}
  $path=''
  if($stage -eq 'initial' -and $schema){$path=Resolve-MedicalTemplateReference ([string]$schema.Template) $cardPath $snapshot}
  if(-not $path){$path=Resolve-MedicalTemplateReference $reference $cardPath $snapshot}
  $importName=if(-not $path -and $snapshot){Get-MedicalRecoveryImportName $snapshot.Name}else{''}
  [void]$plans.Add([pscustomobject]@{Stage=$stage;Path=$path;Snapshot=$snapshot;ImportName=$importName})
 }
 # Path budgets and every source association are checked before the first
 # import; an existing source needs no writable template folder at all.
 foreach($plan in $plans){
  $stage=[string]$plan.Stage;$path=[string]$plan.Path;$snapshot=$plan.Snapshot
  if(-not $path -and $snapshot){$path=(Import-MedicalTemplateBytes $snapshot.Bytes $plan.ImportName $true).Path}
  if(-not $path){continue}
  if($copy.templates -is [Collections.IDictionary]){$copy.templates[$stage]=$path}
  else{$copy.templates | Add-Member -NotePropertyName $stage -NotePropertyValue $path -Force}
  if($stage -eq 'initial' -and $schema){
   $schema.Template=$path
   # Auto-generated forms retain their generation mode; only custom templates
   # use this exact imported source during export and editing.
  }
 }
 return $copy
}

function Import-MedicalRecoveryTemplate($schema,[string]$path){
 $draft=Copy-MedicalFormSchema $schema
 $temporary=$null
 try{
  if([IO.Path]::GetExtension($path) -in @('.mcform','.json')){
   # Read the chosen form as an envelope only: its structure must never replace
   # the already-filled patient's field IDs or move any answers to other fields.
   $info=New-Object IO.FileInfo($path)
   if(-not $info.Exists){throw 'Выбранный файл формы не найден.'}
   if($info.Length -gt 100663296){throw 'Файл формы превышает допустимый размер.'}
   try{$envelope=[IO.File]::ReadAllText($path,[Text.Encoding]::UTF8) | ConvertFrom-Json}catch{throw 'Не удалось прочитать выбранный файл формы.'}
   if($envelope.Format -cne 'MedicalConstructor.Form' -or $envelope.Version -ne 1){throw 'Неизвестный формат файла формы.'}
   $data=[pscustomobject]@{initial=[pscustomobject]@{Name=$envelope.TemplateName;Sha256=$envelope.TemplateSha256;BytesBase64=$envelope.TemplateBase64}}
   $validated=Get-MedicalValidatedCardTemplateSnapshots $data;$bytes=$validated.initial.Bytes;$name=$validated.initial.Name
   $temporary=Join-Path ([IO.Path]::GetTempPath()) ('mc-recover-source-'+[guid]::NewGuid().ToString('N')+[IO.Path]::GetExtension($name))
   [IO.File]::WriteAllBytes($temporary,$bytes);$modelPath=$temporary
  }else{
   $name=Get-MedicalTemplateName (Get-MedicalRecoveryLeaf $path)
   $bytes=Read-MedicalRecoveryTemplateBytes $path
   $temporary=Join-Path ([IO.Path]::GetTempPath()) ('mc-recover-source-'+[guid]::NewGuid().ToString('N')+[IO.Path]::GetExtension($name))
   [IO.File]::WriteAllBytes($temporary,$bytes);$modelPath=$temporary
  }
  $model=Read-MedicalTemplateModel $modelPath
  Assert-MedicalEditorTemplateCoverage $draft $model
  $template=Import-MedicalTemplateBytes $bytes (Get-MedicalRecoveryImportName $name) $true
  $draft.Template=$template.RelativePath;$draft.AutoTemplate=$false
  $draft | Add-Member -NotePropertyName PreserveTemplateFormatting -NotePropertyValue $true -Force
  return [pscustomobject]@{Schema=$draft;Template=$template}
 }finally{if($temporary -and [IO.File]::Exists($temporary)){[IO.File]::Delete($temporary)}}
}
