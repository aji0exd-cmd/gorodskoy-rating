﻿# v51: same export pipeline for Save, Preview and Print.
function Export-CurrentStageDocument([string]$path,[bool]$allowIncomplete=$false){
 if(-not (Ensure-MedicalCurrentTemplate 'сохранение или предпросмотр документа')){throw (New-Object OperationCanceledException('Выбор Word-шаблона отменён. Ответы пациента сохранены в открытой форме.'))}
 if($script:stage -eq 'initial'){
  Capture-Universal
  if(-not $allowIncomplete){Test-UniversalCompletion;Test-UniversalPatientValues}
  Save-UniversalDocument $path $script:universalConfig $script:universalValues $script:admissionControl.Value $script:universalDetails $allowIncomplete
  return
 }
 if(-not $script:source -or -not (Test-Path -LiteralPath $script:source)){throw 'Для текущего этапа сначала выберите Word-шаблон.'}
 if([IO.Path]::GetFullPath($path) -eq [IO.Path]::GetFullPath($script:source)){throw 'Нельзя перезаписывать исходный шаблон.'}
 $script:patientName=$script:patientNameControl.Text.Trim();$script:patientAddress=((Get-FullRegistration).Trim() -replace '\\,', ',')
 $script:patientBirthYear=$script:patientBirthControl.Text.Trim()
 if($script:patientBirthYear -and -not $allowIncomplete){
  $birth=[datetime]::MinValue
  if(-not [datetime]::TryParseExact($script:patientBirthYear,'dd.MM.yyyy',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$birth)){throw 'Дата рождения должна быть в формате ДД.ММ.ГГГГ.'}
 }
 $values=@($script:controls | ForEach-Object {if($_){$_.Text}else{''}})
 for($i=0;$i -lt $script:fields.Count;$i++){
  if($script:fields[$i].IsAddress){$values[$i]=$script:patientAddress}
  elseif($script:fields[$i].HospitalKey){$values[$i]=[string]$script:hospitalControls[$script:fields[$i].HospitalKey].Text}
 }
 Save-Document $path $values;Apply-DocumentFont $path;Capture-Stage
}
function Get-WordActionArguments([string]$worker,[string]$path,[string]$action,[bool]$temporary){
 if($action -notin @('Preview','Print')){throw 'Неизвестное действие с документом.'}
 foreach($value in @($worker,$path)){if($value.IndexOfAny([char[]]@('"',"`r","`n")) -ge 0){throw 'Недопустимые символы в пути файла.'}}
 $args='-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "'+$worker+'" -DocumentPath "'+$path+'" -Action '+$action
 if($temporary){$args+=' -Temporary'}
 return $args
}
function Start-WordDocumentAction([string]$path,[ValidateSet('Preview','Print')][string]$action,[bool]$temporary=$false){
 if(-not (Test-Path -LiteralPath $path -PathType Leaf)){throw 'Выберите существующий документ Word.'}
 if([IO.Path]::GetExtension($path).ToLowerInvariant() -notin @('.docx','.dotx')){throw 'Поддерживаются файлы DOCX и DOTX.'}
 $worker=Join-Path $PSScriptRoot 'word-actions.ps1'
 if(-not (Test-Path -LiteralPath $worker)){throw 'Не найден word-actions.ps1. Распакуйте все файлы обновления в папку программы.'}
 $start=New-Object Diagnostics.ProcessStartInfo
 $start.FileName=Join-Path $PSHOME 'powershell.exe'
 $start.Arguments=Get-WordActionArguments $worker ([IO.Path]::GetFullPath($path)) $action $temporary
 $start.UseShellExecute=$false;$start.CreateNoWindow=$true;$start.WorkingDirectory=$PSScriptRoot
 $process=[Diagnostics.Process]::Start($start)
 if($process){$process.Dispose()}
}
function Show-CurrentDocumentAction([ValidateSet('Preview','Print')][string]$action){
 $folder=Join-Path $env:LOCALAPPDATA 'MedicalConstructor\Preview'
 [void][IO.Directory]::CreateDirectory($folder)
 $path=Join-Path $folder ('mc-preview-'+[guid]::NewGuid().ToString('N')+'.docx')
 try{
  Export-CurrentStageDocument $path
  Start-WordDocumentAction $path $action $true
 }catch{
  if(Test-Path -LiteralPath $path){Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue}
  throw
 }
}
