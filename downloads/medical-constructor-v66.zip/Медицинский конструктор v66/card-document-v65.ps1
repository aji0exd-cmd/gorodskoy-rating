﻿# Full hospitalization state lives in an XML package part, outside the Word page.
function Assert-MedicalCardOutputPath([string]$path){
 $target=[IO.Path]::GetFullPath($path)
 $sources=@([string]$script:source)
 if($script:universalConfig){$sources+=Get-UniversalTemplatePath $script:universalConfig}
 if($script:stageTemplates -is [Collections.IDictionary]){$sources+=@($script:stageTemplates.Values)}
 elseif($script:stageTemplates){$sources+=@($script:stageTemplates.PSObject.Properties | ForEach-Object {$_.Value})}
 foreach($sourcePath in $sources){
  if([string]::IsNullOrWhiteSpace([string]$sourcePath)){continue}
  $sourcePath=[string]$sourcePath
  if(-not [IO.Path]::IsPathRooted($sourcePath)){$sourcePath=Join-Path $PSScriptRoot $sourcePath}
  if([string]::Equals($target,[IO.Path]::GetFullPath($sourcePath),[StringComparison]::OrdinalIgnoreCase)){throw 'Нельзя сохранять карту поверх исходного Word-шаблона. Выберите другое имя файла.'}
 }
}
function Read-MedicalCardDocumentState($zip){
 $parts=@($zip.Entries | Where-Object {$_.FullName -ieq 'customXml/mc-case.xml'})
 if($parts.Count -eq 0){return $null}
 try{
  if($parts.Count -ne 1){throw 'Повтор части состояния карты.'}
  $settings=New-Object Xml.XmlReaderSettings;$settings.DtdProcessing=[Xml.DtdProcessing]::Prohibit;$settings.XmlResolver=$null;$settings.MaxCharactersInDocument=201326592
  $stream=$parts[0].Open();$reader=$null
  try{
   $reader=[Xml.XmlReader]::Create($stream,$settings);$xml=New-Object Xml.XmlDocument;$xml.XmlResolver=$null;$xml.Load($reader)
  }finally{if($reader){$reader.Dispose()};$stream.Dispose()}
  $root=$xml.DocumentElement
  if(-not $root -or $root.LocalName -cne 'case' -or $root.NamespaceURI -cne 'urn:medical-constructor:case:v65'){throw 'Неизвестный формат состояния карты.'}
  if(@($root.ChildNodes | Where-Object {$_ -is [Xml.XmlElement]}).Count){throw 'Неверная структура состояния карты.'}
  $bytes=[Convert]::FromBase64String($root.InnerText)
  $utf8=New-Object Text.UTF8Encoding($false,$true)
  $record=($utf8.GetString($bytes) | ConvertFrom-Json)
  if(-not $record -or $record -is [Array] -or [int]$record.version -ne 49 -or -not $record.universal -or -not $record.universal.Schema -or $null -eq $record.stages -or $null -eq $record.templates){throw 'В состоянии карты отсутствуют обязательные данные.'}
  if($null -ne $record.TemplateSnapshots){[void](Get-MedicalValidatedCardTemplateSnapshots $record.TemplateSnapshots)}
  return $record
 }catch{throw ('Повреждено состояние карты госпитализации: '+$_.Exception.Message)}
}
function Complete-MedicalCardDocumentSave([string]$temporary,[string]$path){
 # Replacement commits the complete package in one operation, including when
 # the chosen card already exists. A locked destination keeps its old bytes.
 if([IO.File]::Exists($path)){[IO.File]::Replace($temporary,$path,[NullString]::Value)}
 else{[IO.File]::Move($temporary,$path)}
}
function Set-MedicalCardDocumentState([string]$path,$record){
 $payload=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($record | ConvertTo-Json -Depth 40 -Compress)))
 $state='<?xml version="1.0" encoding="UTF-8"?><mc:case xmlns:mc="urn:medical-constructor:case:v65">'+$payload+'</mc:case>'
 $zip=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{
  if(-not $zip.GetEntry('word/document.xml')){throw 'Не найден документ Word.'}
  $types=Get-XmlPart $zip '[Content_Types].xml'
  if(-not $types){throw 'Не найден список частей документа Word.'}
  $relNs='http://schemas.openxmlformats.org/package/2006/relationships'
  $rels=Get-XmlPart $zip 'word/_rels/document.xml.rels'
  if(-not $rels){$rels=[xml]('<?xml version="1.0"?><Relationships xmlns="'+$relNs+'"/>')}
  foreach($item in @($rels.DocumentElement.ChildNodes)){
   if($item -is [Xml.XmlElement] -and $item.GetAttribute('Target') -in @('../customXml/mc-case.xml','/customXml/mc-case.xml')){[void]$rels.DocumentElement.RemoveChild($item)}
  }
  $rel=$rels.CreateElement('Relationship',$relNs);$rel.SetAttribute('Id',('rIdMCCase'+[guid]::NewGuid().ToString('N')))
  $rel.SetAttribute('Type','http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXml');$rel.SetAttribute('Target','../customXml/mc-case.xml');[void]$rels.DocumentElement.AppendChild($rel)
  $ctNs='http://schemas.openxmlformats.org/package/2006/content-types'
  foreach($item in @($types.DocumentElement.ChildNodes)){
   if($item -is [Xml.XmlElement] -and $item.GetAttribute('PartName') -ieq '/customXml/mc-case.xml'){[void]$types.DocumentElement.RemoveChild($item)}
  }
  $override=$types.CreateElement('Override',$ctNs);$override.SetAttribute('PartName','/customXml/mc-case.xml');$override.SetAttribute('ContentType','application/xml');[void]$types.DocumentElement.AppendChild($override)
  foreach($entry in @($zip.Entries)){
   if($entry.FullName -ieq 'customXml/mc-case.xml' -or $entry.FullName -in @('[Content_Types].xml','word/_rels/document.xml.rels')){$entry.Delete()}
  }
  Write-UniversalZipText $zip '[Content_Types].xml' $types.OuterXml
  Write-UniversalZipText $zip 'word/_rels/document.xml.rels' $rels.OuterXml
  Write-UniversalZipText $zip 'customXml/mc-case.xml' $state
 }finally{$zip.Dispose()}
}
