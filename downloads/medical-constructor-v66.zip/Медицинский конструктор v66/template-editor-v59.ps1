﻿# v63: one window for a reusable form schema and its Word template.
# The editor never reads patient answers and never overwrites its source template.

function Get-MedicalEditorNamespace($document){
 $manager=[Xml.XmlNamespaceManager]::new($document.NameTable)
 $manager.AddNamespace('w','http://schemas.openxmlformats.org/wordprocessingml/2006/main')
 return ,$manager
}

function Read-MedicalEditorXml([byte[]]$bytes){
 $settings=New-Object Xml.XmlReaderSettings
 $settings.DtdProcessing=[Xml.DtdProcessing]::Prohibit;$settings.XmlResolver=$null
 $settings.MaxCharactersInDocument=33554432
 $stream=[IO.MemoryStream]::new($bytes,$false);$reader=$null
 try{
  $reader=[Xml.XmlReader]::Create($stream,$settings)
  $document=New-Object Xml.XmlDocument;$document.PreserveWhitespace=$true;$document.XmlResolver=$null
  $document.Load($reader);return ,$document
 }finally{if($reader){$reader.Dispose()};$stream.Dispose()}
}

function Get-MedicalEditorParagraphText($node,$namespaces){
 $text=New-Object Text.StringBuilder
 foreach($item in $node.SelectNodes('.//w:t|.//w:br|.//w:cr|.//w:tab',$namespaces)){
  if(-not [object]::ReferenceEquals($item.SelectSingleNode('ancestor::w:p[1]',$namespaces),$node)){continue}
  switch($item.LocalName){'t'{[void]$text.Append($item.InnerText)} 'tab'{[void]$text.Append("`t")} default{[void]$text.Append("`r`n")}}
 }
 return $text.ToString()
}

function Get-MedicalEditorParagraphRestriction($node,$namespaces){
 if($node.SelectSingleNode('.//w:br[@w:type="page" or @w:type="column" or @w:clear]',$namespaces)){
  return 'Абзац содержит разрыв страницы или колонки. Он сохраняется без изменений; добавьте маркер в отдельный обычный абзац.'
 }
 if($node.SelectSingleNode('ancestor::w:sdt|ancestor::w:del|ancestor::w:ins',$namespaces)){
  return 'Абзац находится внутри элемента Word или исправления. Его текст сохраняется без изменений; для маркера добавьте отдельный обычный абзац.'
 }
 foreach($child in $node.ChildNodes){
  if($child -isnot [Xml.XmlElement]){continue}
  if($child.NamespaceURI -ne 'http://schemas.openxmlformats.org/wordprocessingml/2006/main' -or $child.LocalName -notin @('pPr','r')){
   return 'Абзац содержит элемент Word, ссылку, закладку или объект. Для сохранения структуры он доступен только для чтения; вставьте маркер в новый обычный абзац.'
  }
  if($child.LocalName -eq 'r'){
   foreach($runChild in $child.ChildNodes){
    if($runChild -is [Xml.XmlElement] -and ($runChild.NamespaceURI -ne $node.NamespaceURI -or $runChild.LocalName -notin @('rPr','t','br','cr','tab'))){
     return 'Абзац содержит изображение, поле Word или встроенный объект. Он сохраняется без изменений; маркер можно вставить в отдельный абзац.'
    }
   }
  }
 }
 return ''
}

function Update-MedicalEditorParagraphs($model){
 $paragraphs=New-Object Collections.ArrayList
 foreach($partName in $model.PartOrder){
  $part=$model.Parts[$partName];$xml=$part.Xml;$namespaces=Get-MedicalEditorNamespace $xml;$index=0
  foreach($node in $xml.SelectNodes('//w:p',$namespaces)){
   $index++;$reason=Get-MedicalEditorParagraphRestriction $node $namespaces
   $location=if($node.SelectSingleNode('ancestor::w:tc',$namespaces)){'Таблица, абзац '+$index}else{'Абзац '+$index}
   if($node.SelectSingleNode('ancestor::*[local-name()="txbxContent"]',$namespaces)){$location='Текстовое поле, абзац '+$index}
   [void]$paragraphs.Add([pscustomobject]@{Id=($partName+'#'+$index);Part=$partName;Index=$index;Node=$node;Text=(Get-MedicalEditorParagraphText $node $namespaces);Editable=([string]::IsNullOrEmpty($reason));Reason=$reason;Location=$location})
  }
 }
 $model.Paragraphs=$paragraphs
}

function Read-MedicalTemplateModel([string]$path){
 $archive=$null
 $model=[pscustomobject]@{SourcePath=[IO.Path]::GetFullPath($path);TemplateExtension='';Entries=(New-Object Collections.ArrayList);Parts=@{};PartOrder=@();Paragraphs=(New-Object Collections.ArrayList)}
 try{
  $archive=[IO.Compression.ZipFile]::OpenRead($path);$names=@{};$total=0L
  foreach($entry in $archive.Entries){
   if($entry.FullName -in @('customXml/mc49.xml','customXml/mc-case.xml')){throw 'Вы выбрали сохранённую карту пациента. Для формы используйте чистый Word-шаблон без ответов пациента.'}
   if($names.ContainsKey($entry.FullName)){throw ('Повторяющаяся часть Word: '+$entry.FullName)};$names[$entry.FullName]=$true
   $total+=$entry.Length;if($entry.Length -gt 33554432 -or $total -gt 268435456){throw 'Шаблон слишком велик для встроенного редактора.'}
   $stream=$entry.Open();$memory=New-Object IO.MemoryStream
   try{$stream.CopyTo($memory);$bytes=$memory.ToArray()}finally{$stream.Dispose();$memory.Dispose()}
   [void]$model.Entries.Add([pscustomobject]@{Name=$entry.FullName;Bytes=$bytes;LastWriteTime=$entry.LastWriteTime;ExternalAttributes=$entry.ExternalAttributes})
   if($entry.FullName -ceq 'word/document.xml' -or $entry.FullName -cmatch '^word/(header|footer)[^/]*\.xml$'){
    $xml=Read-MedicalEditorXml $bytes
    $expected=if($entry.FullName -ceq 'word/document.xml'){'document'}elseif($entry.FullName -cmatch '/header'){'hdr'}else{'ftr'}
    if($xml.DocumentElement.LocalName -cne $expected -or $xml.DocumentElement.NamespaceURI -cne 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'){throw ('Некорректная часть Word: '+$entry.FullName)}
    $model.Parts[$entry.FullName]=[pscustomobject]@{Xml=$xml;Modified=$false}
   }
  }
  if(-not $model.Parts.ContainsKey('word/document.xml')){throw 'В файле отсутствует word/document.xml.'}
  $contentTypes=@($model.Entries | Where-Object {$_.Name -ceq '[Content_Types].xml'})
  if($contentTypes.Count -ne 1){throw 'В файле отсутствует описание частей Word.'}
  $typeXml=Read-MedicalEditorXml $contentTypes[0].Bytes
  $mainType=@($typeXml.DocumentElement.ChildNodes | Where-Object {$_ -is [Xml.XmlElement] -and $_.GetAttribute('PartName') -ceq '/word/document.xml'})
  if($mainType.Count -ne 1){throw 'В файле отсутствует тип основного документа Word.'}
  switch($mainType[0].GetAttribute('ContentType')){
   'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml'{$model.TemplateExtension='.docx'}
   'application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml'{$model.TemplateExtension='.dotx'}
   default{throw 'Поддерживаются обычные Word-файлы DOCX и DOTX без макросов.'}
  }
  $body=$model.Parts['word/document.xml'].Xml.SelectSingleNode('/w:document/w:body',(Get-MedicalEditorNamespace $model.Parts['word/document.xml'].Xml))
  if(-not $body){throw 'В шаблоне отсутствует основной текст Word.'}
  $model.PartOrder=@('word/document.xml')+@($model.Parts.Keys | Where-Object {$_ -cne 'word/document.xml'} | Sort-Object)
  foreach($partName in $model.PartOrder){
   $part=$model.Parts[$partName];$text=(($part.Xml.SelectNodes('//w:t',(Get-MedicalEditorNamespace $part.Xml)) | ForEach-Object {$_.InnerText}) -join '')
   if($text.Contains('MC_CASE_V24:')){throw 'Вы выбрали карту госпитализации с данными пациента. Для формы нужен чистый Word-шаблон.'}
  }
  Update-MedicalEditorParagraphs $model
  return $model
 }finally{if($archive){$archive.Dispose()}}
}

function Set-MedicalTemplateParagraph($model,[string]$id,[string]$text){
 $paragraph=@($model.Paragraphs | Where-Object {$_.Id -ceq $id})
 if($paragraph.Count -ne 1){throw 'Абзац шаблона не найден.'};$paragraph=$paragraph[0]
 # RichTextBox normalizes CRLF to LF. Merely selecting an existing multiline
 # paragraph must not rewrite it or collapse its original run formatting.
 if(($paragraph.Text -replace '\r\n|\r',"`n") -ceq ($text -replace '\r\n|\r',"`n")){return}
 if(-not $paragraph.Editable){throw $paragraph.Reason}
 $node=$paragraph.Node;$xml=$node.OwnerDocument;$namespaces=Get-MedicalEditorNamespace $xml
 $firstRun=$node.SelectSingleNode('./w:r',$namespaces);$runStyle=$null
 if($firstRun){$style=$firstRun.SelectSingleNode('./w:rPr',$namespaces);if($style){$runStyle=$style.CloneNode($true)}}
 foreach($run in @($node.SelectNodes('./w:r',$namespaces))){[void]$node.RemoveChild($run)}
 $run=$xml.CreateElement('w','r',$node.NamespaceURI);if($runStyle){[void]$run.AppendChild($runStyle)}
 $segments=[regex]::Split($text,'(\r\n|\r|\n|\t)')
 foreach($segment in $segments){
  if($segment -match '^\r\n$|^\r$|^\n$'){$child=$xml.CreateElement('w','br',$node.NamespaceURI)}
  elseif($segment -eq "`t"){$child=$xml.CreateElement('w','tab',$node.NamespaceURI)}
  else{$child=$xml.CreateElement('w','t',$node.NamespaceURI);$child.InnerText=$segment;$space=$xml.CreateAttribute('xml','space','http://www.w3.org/XML/1998/namespace');$space.Value='preserve';[void]$child.Attributes.Append($space)}
  [void]$run.AppendChild($child)
 }
 [void]$node.AppendChild($run);$paragraph.Text=$text;$model.Parts[$paragraph.Part].Modified=$true
}

function Add-MedicalTemplateParagraph($model,[string]$partName,[string]$afterId='',[string]$text=''){
 if(-not $model.Parts.ContainsKey($partName)){throw 'Часть Word не найдена.'}
 $part=$model.Parts[$partName];$xml=$part.Xml;$namespaces=Get-MedicalEditorNamespace $xml
 $node=$xml.CreateElement('w','p',$xml.DocumentElement.NamespaceURI)
 if($afterId){
  $selected=@($model.Paragraphs | Where-Object {$_.Id -ceq $afterId -and $_.Part -ceq $partName})
  if($selected.Count -ne 1){throw 'Выберите абзац для вставки.'}
  $anchor=$selected[0].Node
  if($anchor.ParentNode.NamespaceURI -ne $node.NamespaceURI -or $anchor.ParentNode.LocalName -notin @('body','tc','hdr','ftr')){throw 'Новый абзац можно добавить рядом с обычным абзацем, в таблице или колонтитуле. Выберите другое место.'}
  $style=$anchor.SelectSingleNode('./w:pPr',$namespaces)
  if($style){$copy=$style.CloneNode($true);foreach($sectionBreak in @($copy.SelectNodes('./w:sectPr',$namespaces))){[void]$copy.RemoveChild($sectionBreak)};[void]$node.AppendChild($copy)}
  [void]$anchor.ParentNode.InsertAfter($node,$anchor)
 }else{
  $container=if($partName -ceq 'word/document.xml'){$xml.SelectSingleNode('/w:document/w:body',$namespaces)}else{$xml.DocumentElement}
  $section=$container.SelectSingleNode('./w:sectPr',$namespaces)
  if($section){[void]$container.InsertBefore($node,$section)}else{[void]$container.AppendChild($node)}
 }
 $part.Modified=$true;Update-MedicalEditorParagraphs $model
 $record=@($model.Paragraphs | Where-Object {[object]::ReferenceEquals($_.Node,$node)})[0]
 if($text){Set-MedicalTemplateParagraph $model $record.Id $text}
 return $record
}

function Write-MedicalTemplateModel([string]$path,$model){
 $destination=[IO.Path]::GetFullPath($path)
 if($destination -eq [IO.Path]::GetFullPath($model.SourcePath)){throw 'Редактор не перезаписывает исходный шаблон. Сохраните отдельную копию.'}
 $parent=[IO.Path]::GetDirectoryName($destination)
 if(-not [IO.Directory]::Exists($parent)){throw 'Папка назначения не найдена.'}
 $temp=Join-Path $parent ('.mc-editor-'+[guid]::NewGuid().ToString('N')+'.tmp');$backup=$temp+'.bak';$archive=$null
 try{
  $archive=[IO.Compression.ZipFile]::Open($temp,[IO.Compression.ZipArchiveMode]::Create)
  foreach($entry in $model.Entries){
   $bytes=$entry.Bytes
   if($model.Parts.ContainsKey($entry.Name) -and $model.Parts[$entry.Name].Modified){
    $bytes=[Text.UTF8Encoding]::new($false).GetBytes($model.Parts[$entry.Name].Xml.OuterXml)
    [void](Read-MedicalEditorXml $bytes)
   }
   $output=$archive.CreateEntry($entry.Name,[IO.Compression.CompressionLevel]::Optimal)
   $output.LastWriteTime=$entry.LastWriteTime;$output.ExternalAttributes=$entry.ExternalAttributes
   $stream=$output.Open();try{$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
  }
  $archive.Dispose();$archive=$null
  [void](Read-MedicalTemplateModel $temp)
  if([IO.File]::Exists($destination)){[IO.File]::Replace($temp,$destination,$backup)}else{[IO.File]::Move($temp,$destination)}
  $temp=$null
 }finally{if($archive){$archive.Dispose()};if($temp -and [IO.File]::Exists($temp)){[IO.File]::Delete($temp)};if([IO.File]::Exists($backup)){[IO.File]::Delete($backup)}}
}

function Assert-MedicalEditorTemplateCoverage($config,$model){
 Assert-UniversalConfig $config
 $values=@{};$details=@{};$hits=@{}
 foreach($field in Get-UniversalFields $config){$values[[string]$field.Id]='Проверка '+[string]$field.Id;$details[[string]$field.Id]='Проверка уточнения'}
 foreach($partName in $model.PartOrder){
  # Run the real marker engine on a private XML copy. It validates unknown markers,
  # split runs, Word IDs and nested clarification bindings without changing the model.
  $copy=Read-MedicalEditorXml ([Text.Encoding]::UTF8.GetBytes($model.Parts[$partName].Xml.OuterXml))
  Set-UniversalXml $copy $config $values ([datetime]'2000-01-01T12:00:00') $hits $details
 }
 $missing=@(foreach($field in Get-UniversalFields $config){
  if(-not $hits.ContainsKey([string]$field.Marker)){$field.Label+' — {{'+$field.Marker+'}}'}
  if($field.Type -eq 'choice_detail' -and (Get-UniversalDetailWordPosition $field) -eq 'marker' -and -not $hits.ContainsKey([string]$field.DetailMarker)){$field.Label+' — {{'+$field.DetailMarker+'}} (уточнение)'}
 })
 if($missing.Count){throw ("Добавьте в шаблон маркеры полей или свяжите поля с элементами Word:`r`n"+($missing -join "`r`n"))}
 if(-not ($hits.ContainsKey('ADMISSION_DATETIME') -or ($hits.ContainsKey('ADMISSION_DATE') -and $hits.ContainsKey('ADMISSION_TIME')))){throw 'Добавьте {{ADMISSION_DATETIME}} либо оба маркера {{ADMISSION_DATE}} и {{ADMISSION_TIME}}.'}
}

function Save-MedicalEditorResult($config,$model,[string]$name){
 $schema=Copy-MedicalFormSchema $config
 Assert-MedicalEditorTemplateCoverage $schema $model
 if(-not [IO.Path]::GetExtension($name)){$name+=$model.TemplateExtension};$name=Get-MedicalTemplateName $name
 if([IO.Path]::GetExtension($name) -ine $model.TemplateExtension){throw ('Этот шаблон имеет формат '+$model.TemplateExtension+'. Используйте это расширение, чтобы Word открывал файл корректно.')}
 $folder=Join-Path ([IO.Path]::GetTempPath()) ('mc-editor-result-'+[guid]::NewGuid().ToString('N'))
 [void][IO.Directory]::CreateDirectory($folder);$path=Join-Path $folder $name
 try{
  Write-MedicalTemplateModel $path $model
  $verified=Read-MedicalTemplateModel $path;Assert-MedicalEditorTemplateCoverage $schema $verified
  $template=Import-MedicalTemplate $path $true
  $schema.Template=$template.RelativePath;$schema.AutoTemplate=$false
  $schema | Add-Member -NotePropertyName PreserveTemplateFormatting -NotePropertyValue $true -Force
  return [pscustomobject]@{Schema=$schema;Template=$template}
 }finally{if([IO.Directory]::Exists($folder)){[IO.Directory]::Delete($folder,$true)}}
}

function New-MedicalEditorLabel([string]$text){
 $label=New-Object Windows.Forms.Label;$label.Text=$text;$label.Dock='Fill';$label.TextAlign='MiddleLeft';return $label
}

function New-MedicalEditorButton([string]$text){
 $button=New-Object Windows.Forms.Button;$button.Text=$text;$button.AutoSize=$true;$button.Height=32;$button.Margin=New-Object Windows.Forms.Padding(4);return $button
}

function Show-MedicalFormTemplateEditor($owner,$config){
 $schema=Copy-MedicalFormSchema $config
 $initialTemp=$null
 try{
  if($schema.AutoTemplate){
   $initialTemp=Join-Path ([IO.Path]::GetTempPath()) ('mc-editor-source-'+[guid]::NewGuid().ToString('N')+'.docx')
   New-UniversalTemplate $initialTemp $schema;$source=$initialTemp
  }else{
   $source=[string]$schema.Template
   if(-not [IO.Path]::IsPathRooted($source)){$source=Join-Path $script:medicalProgramRoot ($source.Replace('\',[IO.Path]::DirectorySeparatorChar))}
  }
  $model=Read-MedicalTemplateModel $source
  $state=@{Schema=$schema;Model=$model;Selected=$null;SelectedNode=$null;PropertiesSelection=$null;PropertiesNode=$null;PropertiesFieldNode=$null;SectionFieldIds=@{};SectionFieldOptions=@();Paragraph=$null;VisibleParagraphs=@();Loading=$false;Result=$null;Dirty=$false;WordPreview=$null}
  $dialog=New-Object Windows.Forms.Form;$dialog.Text='Форма и шаблон Word — единый редактор';$dialog.Size=New-Object Drawing.Size(1380,900);$dialog.MinimumSize=New-Object Drawing.Size(1100,740);$dialog.StartPosition='CenterParent';$dialog.Font=New-Object Drawing.Font('Segoe UI',10)
  $layout=New-Object Windows.Forms.TableLayoutPanel;$layout.Dock='Fill';$layout.ColumnCount=1;$layout.RowCount=2
  [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)));[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',62)))
  $split=New-Object Windows.Forms.SplitContainer;$split.Dock='Fill';$split.Orientation='Vertical';$split.Size=New-Object Drawing.Size(1360,790);$split.Panel1MinSize=380;$split.Panel2MinSize=500;$split.SplitterDistance=460
  $layout.Controls.Add($split,0,0);$dialog.Controls.Add($layout)
  $left=New-Object Windows.Forms.TableLayoutPanel;$left.Dock='Fill';$left.ColumnCount=1;$left.RowCount=3
  [void]$left.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',84)));[void]$left.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',43)));[void]$left.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',57)))
  $leftButtons=New-Object Windows.Forms.FlowLayoutPanel;$leftButtons.Dock='Fill'
  $addSection=New-MedicalEditorButton '+ Раздел';$editSection=New-MedicalEditorButton 'Изменить раздел';$addField=New-MedicalEditorButton '+ Поле';$delete=New-MedicalEditorButton 'Удалить';$up=New-MedicalEditorButton 'Выше';$down=New-MedicalEditorButton 'Ниже'
  foreach($button in @($addSection,$editSection,$addField,$delete,$up,$down)){$leftButtons.Controls.Add($button)}
  $tree=New-Object Windows.Forms.TreeView;$tree.Dock='Fill';$tree.HideSelection=$false;$tree.FullRowSelect=$true
  $tabs=New-Object Windows.Forms.TabControl;$tabs.Dock='Fill'
  $fieldTab=New-Object Windows.Forms.TabPage;$fieldTab.Text='Поле / раздел';$fieldTab.AutoScroll=$true
  $detailTab=New-Object Windows.Forms.TabPage;$detailTab.Text='Уточнение';$detailTab.AutoScroll=$true
  $tabs.TabPages.Add($fieldTab);$tabs.TabPages.Add($detailTab)
  $left.Controls.Add($leftButtons,0,0);$left.Controls.Add($tree,0,1);$left.Controls.Add($tabs,0,2);$split.Panel1.Controls.Add($left)
  $properties=New-Object Windows.Forms.TableLayoutPanel;$properties.Dock='Top';$properties.AutoSize=$true;$properties.ColumnCount=2;$properties.Padding=New-Object Windows.Forms.Padding(6)
  [void]$properties.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Absolute',125)));[void]$properties.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',100)))
  $fieldName=New-Object Windows.Forms.TextBox;$fieldName.ReadOnly=$false;$fieldMarker=New-Object Windows.Forms.TextBox
  $sectionFieldPicker=New-Object Windows.Forms.ComboBox;$sectionFieldPicker.DropDownStyle='DropDownList'
  $sectionFieldName=New-Object Windows.Forms.TextBox;$sectionFieldName.ReadOnly=$false
  $propertyNameLabel=New-MedicalEditorLabel 'Название'
  $sectionFieldPickerLabel=New-MedicalEditorLabel 'Поле раздела'
  $sectionFieldNameLabel=New-MedicalEditorLabel 'Название поля'
  $sectionInfo=New-MedicalEditorLabel 'Раздел объединяет поля. Ниже редактируются маркер, тип и уточнение выбранного поля.' 
  $fieldType=New-Object Windows.Forms.ComboBox;$fieldType.DropDownStyle='DropDownList'
  $typeIds=@('text','multiline','choice','choice_detail','heading','multi','repeat')
  $fieldType.Items.AddRange([object[]]@('Строка','Многострочный текст','Список','Список с уточнением','Подзаголовок','Галочки','Повторяемые строки'))
  $fieldOptions=New-Object Windows.Forms.TextBox;$fieldOptions.Multiline=$true;$fieldOptions.ScrollBars='Vertical';$fieldOptions.Height=100
  $fieldRequired=New-Object Windows.Forms.CheckBox;$fieldRequired.Text='Обязательное поле'
  $fieldRole=New-Object Windows.Forms.ComboBox;$fieldRole.DropDownStyle='DropDownList';$fieldRole.Items.AddRange([object[]]@('Обычное поле','Ф.И.О.','Дата рождения','Адрес'));$roleIds=@('','name','birth','address')
  $fieldWordId=New-Object Windows.Forms.TextBox
  $rows=@(@($propertyNameLabel,$fieldName,36),@($sectionFieldPickerLabel,$sectionFieldPicker,36),@($sectionFieldNameLabel,$sectionFieldName,36),@((New-MedicalEditorLabel 'Маркер Word'),$fieldMarker,36),@((New-MedicalEditorLabel 'Тип'),$fieldType,36),@((New-MedicalEditorLabel 'Варианты'),$fieldOptions,110),@((New-MedicalEditorLabel 'Проверка'),$fieldRequired,36),@((New-MedicalEditorLabel 'Роль пациента'),$fieldRole,36),@((New-MedicalEditorLabel 'ID элемента Word'),$fieldWordId,36))
  $row=0;foreach($item in $rows){[void]$properties.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',[int]$item[2])));$item[0].Dock='Fill';$item[1].Dock='Fill';$properties.Controls.Add($item[0],0,$row);$properties.Controls.Add($item[1],1,$row);$row++}
  [void]$properties.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',62)));$sectionInfo.Dock='Fill';$properties.Controls.Add($sectionInfo,0,$row);$properties.SetColumnSpan($sectionInfo,2);$fieldTab.Controls.Add($properties)
  $detailProperties=New-Object Windows.Forms.TableLayoutPanel;$detailProperties.Dock='Top';$detailProperties.AutoSize=$true;$detailProperties.ColumnCount=1;$detailProperties.Padding=New-Object Windows.Forms.Padding(8)
  $detailForm=New-Object Windows.Forms.ComboBox;$detailForm.DropDownStyle='DropDownList';$detailForm.Items.AddRange([object[]]@('Под списком','Над списком','Справа от списка'))
  $detailWord=New-Object Windows.Forms.ComboBox;$detailWord.DropDownStyle='DropDownList';$detailWord.Items.AddRange([object[]]@('После варианта','Перед вариантом','С новой строки','Отдельный маркер'))
  $detailMarker=New-Object Windows.Forms.TextBox
  $detailStatus=New-MedicalEditorLabel 'Выберите поле слева, чтобы настроить уточнение.'
  $detailEnable=New-MedicalEditorButton 'Включить уточнение'
  $detailControls=@(
   @($detailStatus,84),@($detailEnable,40),
   @((New-MedicalEditorLabel 'Расположение уточнения в форме'),28),@($detailForm,38),
   @((New-MedicalEditorLabel 'Расположение уточнения в Word'),28),@($detailWord,38),
   @((New-MedicalEditorLabel 'Отдельный маркер (без {{ }})'),28),@($detailMarker,38),
   @((New-MedicalEditorLabel 'Для отдельного маркера выберите это расположение в Word и вставьте маркер справа.'),64)
  )
  $row=0;foreach($item in $detailControls){[void]$detailProperties.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',[int]$item[1])));$item[0].Dock='Fill';$detailProperties.Controls.Add($item[0],0,$row);$row++};$detailTab.Controls.Add($detailProperties)
  $right=New-Object Windows.Forms.TableLayoutPanel;$right.Dock='Fill';$right.ColumnCount=1;$right.RowCount=6
  foreach($height in @(48,70,38)){[void]$right.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',$height)))}
  [void]$right.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',24)));[void]$right.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',76)));[void]$right.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',116)))
  $templateTools=New-Object Windows.Forms.FlowLayoutPanel;$templateTools.Dock='Fill'
  $loadTemplate=New-MedicalEditorButton 'Загрузить Word';$buildTemplate=New-MedicalEditorButton 'Создать по полям'
  $templateName=New-Object Windows.Forms.TextBox;$templateName.Width=230;$templateName.Margin=New-Object Windows.Forms.Padding(5,8,5,0)
  $templateName.Text=if($schema.AutoTemplate){'Мой шаблон.docx'}else{(Get-MedicalFormDisplayName $source 'Шаблон формы')+$model.TemplateExtension}
  foreach($control in @($loadTemplate,$buildTemplate,$templateName)){$templateTools.Controls.Add($control)}
  $hint=New-MedicalEditorLabel 'Выберите поле слева и абзац справа. Вставляйте маркеры в текст. Таблицы, изображения, стили абзацев и колонтитулы сохраняются. Изменённый обычный абзац использует стиль своего первого текстового фрагмента; это редактор текста, а не макета страниц Word.'
  $partCombo=New-Object Windows.Forms.ComboBox;$partCombo.DropDownStyle='DropDownList';$partCombo.Dock='Fill'
  $paragraphList=New-Object Windows.Forms.ListBox;$paragraphList.Dock='Fill';$paragraphList.HorizontalScrollbar=$true
  $textEditorHost=New-Object Windows.Forms.GroupBox;$textEditorHost.Text='Оформление и макет Word';$textEditorHost.Dock='Fill';$textEditorHost.Padding=New-Object Windows.Forms.Padding(8,22,8,8)
  $textEditorLayout=New-Object Windows.Forms.TableLayoutPanel;$textEditorLayout.Dock='Fill';$textEditorLayout.ColumnCount=1;$textEditorLayout.RowCount=2
  [void]$textEditorLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',30)));[void]$textEditorLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)))
  $paragraphTitle=New-MedicalEditorLabel 'Выберите абзац в списке выше.'
  $documentTabs=New-Object Windows.Forms.TabControl;$documentTabs.Dock='Fill'
  $formatTab=New-Object Windows.Forms.TabPage;$formatTab.Text='Абзац и линейка'
  $layoutTab=New-Object Windows.Forms.TabPage;$layoutTab.Text='Макет (приблизительный)'
  $wordTab=New-Object Windows.Forms.TabPage;$wordTab.Text='Страницы Word'
  $paragraphFormatEditor=New-MedicalParagraphFormatEditor $state $dialog
  $paragraphText=$paragraphFormatEditor.Editor
  $paragraphFormatEditor.Root.Dock='Fill';$formatTab.Controls.Add($paragraphFormatEditor.Root)
  $layoutBrowser=New-Object Windows.Forms.WebBrowser;$layoutBrowser.Dock='Fill';$layoutBrowser.ScriptErrorsSuppressed=$true;$layoutBrowser.AllowWebBrowserDrop=$false;$layoutBrowser.IsWebBrowserContextMenuEnabled=$false;$layoutBrowser.WebBrowserShortcutsEnabled=$false
  $layoutTab.Controls.Add($layoutBrowser)
  $wordLayout=New-Object Windows.Forms.TableLayoutPanel;$wordLayout.Dock='Fill';$wordLayout.ColumnCount=1;$wordLayout.RowCount=3
  [void]$wordLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',42)));[void]$wordLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',54)));[void]$wordLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)))
  $wordTools=New-Object Windows.Forms.FlowLayoutPanel;$wordTools.Dock='Fill';$wordTools.WrapContents=$false;$wordTools.AutoScroll=$true
  $wordPreviewButton=New-MedicalEditorButton 'Показать / обновить страницы Word'
  $wordZoomCombo=New-Object Windows.Forms.ComboBox;$wordZoomCombo.DropDownStyle='DropDownList';$wordZoomCombo.Width=150;$wordZoomCombo.Items.AddRange([object[]]@('Страница целиком','По ширине','100%'));$wordZoomCombo.SelectedIndex=0
  $wordTools.Controls.Add($wordPreviewButton);$wordTools.Controls.Add($wordZoomCombo)
  $wordStatus=New-MedicalEditorLabel 'Для точных страниц нажмите кнопку выше. Нужен установленный настольный Microsoft Word.'
  $wordPages=New-Object Windows.Forms.FlowLayoutPanel;$wordPages.Dock='Fill';$wordPages.FlowDirection='TopDown';$wordPages.WrapContents=$false;$wordPages.AutoScroll=$true
  $wordLayout.Controls.Add($wordTools,0,0);$wordLayout.Controls.Add($wordStatus,0,1);$wordLayout.Controls.Add($wordPages,0,2);$wordTab.Controls.Add($wordLayout)
  foreach($page in @($formatTab,$layoutTab,$wordTab)){$documentTabs.TabPages.Add($page)}
  $textEditorLayout.Controls.Add($paragraphTitle,0,0);$textEditorLayout.Controls.Add($documentTabs,0,1);$textEditorHost.Controls.Add($textEditorLayout)
  $textContext=New-Object Windows.Forms.ContextMenuStrip
  $cutMenu=$textContext.Items.Add('Вырезать');$copyMenu=$textContext.Items.Add('Копировать');$pasteMenu=$textContext.Items.Add('Вставить текст');$selectMenu=$textContext.Items.Add('Выделить всё')
  $paragraphText.ContextMenuStrip=$textContext
  $markerTools=New-Object Windows.Forms.FlowLayoutPanel;$markerTools.Dock='Fill';$markerTools.AutoScroll=$true
  $insertField=New-MedicalEditorButton 'Вставить маркер поля';$insertDetail=New-MedicalEditorButton 'Маркер уточнения';$insertDate=New-MedicalEditorButton 'Дата и время';$addParagraph=New-MedicalEditorButton '+ Абзац';$deleteParagraph=New-MedicalEditorButton 'Удалить абзац';$pasteText=New-MedicalEditorButton 'Вставить текст'
  foreach($button in @($insertField,$insertDetail,$insertDate,$addParagraph,$deleteParagraph,$pasteText)){$markerTools.Controls.Add($button)}
  $right.Controls.Add($templateTools,0,0);$right.Controls.Add($hint,0,1);$right.Controls.Add($partCombo,0,2);$right.Controls.Add($paragraphList,0,3);$right.Controls.Add($textEditorHost,0,4);$right.Controls.Add($markerTools,0,5);$split.Panel2.Controls.Add($right)
  $footer=New-Object Windows.Forms.FlowLayoutPanel;$footer.Dock='Fill';$footer.FlowDirection='RightToLeft'
  $cancel=New-MedicalEditorButton 'Отмена';$cancel.DialogResult='Cancel';$save=New-MedicalEditorButton 'Применить форму и Word';$save.Width=245
  $footer.Controls.Add($cancel);$footer.Controls.Add($save);$layout.Controls.Add($footer,0,1);$dialog.CancelButton=$cancel

  # GetNewClosure creates a dynamic module which cannot resolve the private
  # functions dot-sourced by constructor.ps1. Capture command objects in the
  # original script scope before creating callbacks; invoking those objects
  # preserves the helper functions' scope, nested calls and script variables.
  $editorCommands=@{}
  foreach($commandName in @(
   'Set-MedicalTemplateParagraph','Test-UniversalFieldRequired',
   'Get-UniversalDetailFormPosition','Get-UniversalDetailWordPosition',
   'New-UniversalField','Add-MedicalTemplateParagraph','Remove-MedicalTemplateParagraph','Read-MedicalTemplateModel',
   'Assert-UniversalConfig','New-UniversalTemplate','Save-MedicalEditorResult',
   'ConvertTo-MedicalTemplateHtml','New-MedicalWordPreview','Remove-MedicalWordPreview','New-MedicalEditorLabel',
   'Show-MedicalSectionRenameDialog','Get-MedicalFormDisplayName'
  )){
   $editorCommands[$commandName]=Get-Command -Name $commandName -CommandType Function -ErrorAction Stop
  }

  $commitProperties={param([bool]$requireName=$false)
   if($state.Loading -or -not $state.PropertiesSelection){return}
   # The controls stay bound to the loaded section and its selected child field.
   # Tree selection itself still identifies a section for move and delete.
   $selection=$state.PropertiesSelection;$name=$fieldName.Text.Trim()
   if([string]::IsNullOrWhiteSpace($name) -and $requireName){
    $tabs.SelectedTab=$fieldTab;[void]$fieldName.Focus()
    if($selection.Kind -eq 'section'){throw 'Введите название выбранного раздела в поле «Название раздела».'}
    throw 'Введите название выбранного поля в поле «Название поля».'
   }
   $field=$selection.Field
   if($selection.Kind -eq 'section'){
    # A temporary empty input during replacement must not erase the title.
    $previousTitle=[string]$selection.Section.Title;$childName=$sectionFieldName.Text.Trim()
    if($name){
     if($field -and $field.Label -ceq $previousTitle -and $childName -ceq $previousTitle){
      $childName=$name;$previousLoading=[bool]$state.Loading;$state.Loading=$true
      try{$sectionFieldName.Text=$name}finally{$state.Loading=$previousLoading}
     }
     $selection.Section.Title=$name;if($state.PropertiesNode){$state.PropertiesNode.Text=$name}
    }
    if(-not $field){return}
    if([string]::IsNullOrWhiteSpace($childName) -and $requireName){$tabs.SelectedTab=$fieldTab;[void]$sectionFieldName.Focus();throw 'Введите название выбранного поля раздела в поле «Название поля».'}
    if($childName){$field.Label=$childName}
   }elseif($name){$field.Label=$name}
   $marker=$fieldMarker.Text.Trim().ToUpperInvariant()
   if($requireName -or $marker -cmatch '^[A-Z][A-Z0-9_]*$'){$field.Marker=$marker}
   if($fieldType.SelectedIndex -ge 0){$field.Type=$typeIds[$fieldType.SelectedIndex]}
   $field.Options=@($fieldOptions.Lines | Where-Object {-not [string]::IsNullOrWhiteSpace($_)})
   $field.System=$roleIds[[Math]::Max(0,$fieldRole.SelectedIndex)];$field.WordId=$fieldWordId.Text.Trim()
   $field | Add-Member -NotePropertyName Required -NotePropertyValue ([bool]$fieldRequired.Checked) -Force
   if($field.Type -in @('heading','multi','repeat')){$field.System='';$field.WordId=''}
   if($field.Type -eq 'heading'){$field.Required=$false;$field.Options=@()}
   if($field.Type -eq 'choice_detail'){
    $field | Add-Member -NotePropertyName DetailFormPosition -NotePropertyValue @('below','above','right')[[Math]::Max(0,$detailForm.SelectedIndex)] -Force
    $field | Add-Member -NotePropertyName DetailWordPosition -NotePropertyValue @('after','before','newline','marker')[[Math]::Max(0,$detailWord.SelectedIndex)] -Force
    $field | Add-Member -NotePropertyName DetailMarker -NotePropertyValue $detailMarker.Text.Trim().ToUpperInvariant() -Force
   }
   $fieldNode=if($selection.Kind -eq 'section'){$state.PropertiesFieldNode}else{$state.PropertiesNode}
   if($fieldNode){$fieldNode.Text=$field.Label+'  {{'+$field.Marker+'}}'}
   if($selection.Kind -eq 'section'){
    $index=$sectionFieldPicker.SelectedIndex
    if($index -ge 0 -and $index -lt $state.SectionFieldOptions.Count -and $state.SectionFieldOptions[$index].Id -ceq $field.Id){
     $previousLoading=[bool]$state.Loading;$state.Loading=$true
     try{$sectionFieldPicker.Items[$index]=$field.Label;$sectionFieldPicker.SelectedIndex=$index}finally{$state.Loading=$previousLoading}
    }
   }
  }.GetNewClosure()
  $commitParagraph={if($state.Paragraph -and -not $state.Loading){& $editorCommands['Set-MedicalTemplateParagraph'] $state.Model $state.Paragraph.Id $paragraphText.Text}}.GetNewClosure()
  $showError={param($exception)[void][Windows.Forms.MessageBox]::Show($dialog,$exception.Exception.Message,'Форма и шаблон','OK','Warning')}.GetNewClosure()
  $updateAvailability={
   $isField=$state.PropertiesSelection -and $state.PropertiesSelection.Field
   $isSection=$state.Selected -and $state.Selected.Kind -eq 'section'
   $withDetail=$isField -and $fieldType.SelectedIndex -eq 3
   $editSection.Enabled=[bool]$isSection
   $detailTab.Enabled=$true
   $detailEnable.Enabled=[bool]$isField -and $fieldType.SelectedIndex -in @(0,1,2)
   $detailEnable.Text=if($withDetail){'Уточнение включено'}else{'Включить уточнение'}
   if(-not $isField){$detailStatus.Text=if($isSection){'В этом разделе пока нет полей. Нажмите «+ Поле», затем настройте его уточнение.'}else{'Выберите поле или раздел с полями в дереве слева, чтобы настроить уточнение.'}}
   elseif($withDetail){$detailStatus.Text='Уточнение включено для выбранного поля. Настройте его расположение ниже. Варианты списка задаются на вкладке «Поле / раздел».'}
   elseif($fieldType.SelectedIndex -in @(0,1,2)){$detailStatus.Text='Уточнение используется с типом «Список с уточнением». Нажмите «Включить уточнение», затем задайте варианты на вкладке «Поле / раздел».'}
   else{$detailStatus.Text='Для уточнения выберите тип «Список с уточнением» на вкладке «Поле / раздел».'}
   $fieldOptions.Enabled=[bool]$isField -and $fieldType.SelectedIndex -in @(2,3,5,6)
   $detailForm.Enabled=[bool]$withDetail;$detailWord.Enabled=[bool]$withDetail
   $detailMarker.Enabled=[bool]$withDetail -and $detailWord.SelectedIndex -eq 3
   $editable=$state.Paragraph -and $state.Paragraph.Editable
   foreach($button in @($insertDate,$deleteParagraph,$pasteText)){$button.Enabled=[bool]$editable}
   $insertField.Enabled=[bool]$editable -and [bool]$isField
   $insertDetail.Enabled=[bool]$editable -and $withDetail -and $detailWord.SelectedIndex -eq 3
  }.GetNewClosure()
  $loadProperties={
   $previousLoading=[bool]$state.Loading;$state.Loading=$true
   $state.PropertiesSelection=$null;$state.PropertiesNode=$null;$state.PropertiesFieldNode=$null;$state.SectionFieldOptions=@()
   try{
    $selection=$state.Selected;$isSection=$selection -and $selection.Kind -eq 'section'
    $propertyNameLabel.Text=if($isSection){'Название раздела'}else{'Название поля'}
    foreach($control in @($sectionFieldPickerLabel,$sectionFieldPicker,$sectionFieldNameLabel,$sectionFieldName,$sectionInfo)){$control.Visible=[bool]$isSection}
    $properties.RowStyles[1].Height=if($isSection){36}else{0};$properties.RowStyles[2].Height=if($isSection){36}else{0};$properties.RowStyles[9].Height=if($isSection){62}else{0}
    $sectionFieldPicker.Items.Clear();$sectionFieldPicker.SelectedIndex=-1;$sectionFieldName.Text=''
    $field=$null
    if($selection){
     if($isSection){
      $fieldName.Text=[string]$selection.Section.Title;$state.SectionFieldOptions=@($selection.Section.Fields)
      $selectedFieldId=[string]$state.SectionFieldIds[[string]$selection.Section.Id];$selectedIndex=0
      for($i=0;$i -lt $state.SectionFieldOptions.Count;$i++){
       $candidate=$state.SectionFieldOptions[$i];[void]$sectionFieldPicker.Items.Add([string]$candidate.Label)
       if($candidate.Id -ceq $selectedFieldId){$selectedIndex=$i}
      }
      if($state.SectionFieldOptions.Count){
       $sectionFieldPicker.SelectedIndex=$selectedIndex;$field=$state.SectionFieldOptions[$selectedIndex];$sectionFieldName.Text=[string]$field.Label
       $state.SectionFieldIds[[string]$selection.Section.Id]=[string]$field.Id
       foreach($node in $state.SelectedNode.Nodes){if($node.Tag.Field -and $node.Tag.Field.Id -ceq $field.Id){$state.PropertiesFieldNode=$node;break}}
      }
      $sectionInfo.Text=if($field){'Раздел объединяет поля. «Поле раздела» выбирает, чьи маркер, тип и уточнение редактируются ниже.'}else{'В этом разделе пока нет полей. Нажмите «+ Поле», чтобы добавить текст, список или уточнение.'}
     }else{$field=$selection.Field;$fieldName.Text=[string]$field.Label;$state.PropertiesFieldNode=$state.SelectedNode}
     $state.PropertiesSelection=[pscustomobject]@{Kind=$selection.Kind;Section=$selection.Section;Field=$field};$state.PropertiesNode=$state.SelectedNode
    }else{$fieldName.Text=''}
    $fieldName.Enabled=[bool]$selection;$fieldName.ReadOnly=$false;$sectionFieldName.Enabled=[bool]$field;$sectionFieldName.ReadOnly=$false;$sectionFieldPicker.Enabled=[bool]$field
    foreach($control in @($fieldMarker,$fieldType,$fieldOptions,$fieldRequired,$fieldRole,$fieldWordId)){$control.Enabled=[bool]$field}
    $fieldMarker.ReadOnly=$false;$fieldWordId.ReadOnly=$false
    if(-not $field){
     $fieldMarker.Text='';$fieldType.SelectedIndex=-1;$fieldOptions.Text='';$fieldRequired.Checked=$false;$fieldRole.SelectedIndex=-1;$fieldWordId.Text=''
     $detailForm.SelectedIndex=0;$detailWord.SelectedIndex=0;$detailMarker.Text='';return
    }
    $fieldMarker.Text=$field.Marker;$fieldType.SelectedIndex=$typeIds.IndexOf([string]$field.Type)
    $fieldOptions.Text=@($field.Options) -join "`r`n";$fieldRequired.Checked=(& $editorCommands['Test-UniversalFieldRequired'] $field);$fieldRole.SelectedIndex=$roleIds.IndexOf([string]$field.System);$fieldWordId.Text=[string]$field.WordId
    $detailForm.SelectedIndex=@('below','above','right').IndexOf((& $editorCommands['Get-UniversalDetailFormPosition'] $field));$detailWord.SelectedIndex=@('after','before','newline','marker').IndexOf((& $editorCommands['Get-UniversalDetailWordPosition'] $field));$detailMarker.Text=[string]$field.DetailMarker
    if(-not $detailMarker.Text){$detailMarker.Text=$field.Marker+'_DETAIL'}
   }finally{$state.Loading=$previousLoading;& $updateAvailability}
  }.GetNewClosure()
  $refreshTree={param([string]$selectedId='')
   $previousLoading=[bool]$state.Loading;$state.Loading=$true;$tree.BeginUpdate()
   try{
    $tree.Nodes.Clear();$chosen=$null
    foreach($section in $state.Schema.Sections){
     $sectionNode=New-Object Windows.Forms.TreeNode([string]$section.Title);$sectionNode.Tag=[pscustomobject]@{Kind='section';Section=$section;Field=$null}
     [void]$tree.Nodes.Add($sectionNode);if($section.Id -eq $selectedId){$chosen=$sectionNode}
     foreach($field in $section.Fields){$node=New-Object Windows.Forms.TreeNode(($field.Label+'  {{'+$field.Marker+'}}'));$node.Tag=[pscustomobject]@{Kind='field';Section=$section;Field=$field};[void]$sectionNode.Nodes.Add($node);if($field.Id -eq $selectedId){$chosen=$node}}
     $sectionNode.Expand()
    }
    if(-not $chosen -and $tree.Nodes.Count){$chosen=$tree.Nodes[0]};$tree.SelectedNode=$chosen;$state.SelectedNode=$chosen;$state.Selected=if($chosen){$chosen.Tag}else{$null}
   }finally{$tree.EndUpdate();$state.Loading=$previousLoading}
   & $loadProperties
  }.GetNewClosure()
  $loadParagraph={
   $previousLoading=[bool]$state.Loading;$state.Loading=$true
   try{
    # Keep Word records in PowerShell; native ListBox items contain display strings.
    $index=$paragraphList.SelectedIndex
    $state.Paragraph=if($index -ge 0 -and $index -lt $state.VisibleParagraphs.Count){$state.VisibleParagraphs[$index]}else{$null}
    if($state.Paragraph){
     $paragraphText.Text=[string]$state.Paragraph.Text;$paragraphText.ReadOnly=-not $state.Paragraph.Editable
     $paragraphTitle.Text=$state.Paragraph.Location+$(if($state.Paragraph.Editable){' — вводите текст или нажмите «Вставить текст»'}else{' — только для чтения'})
     if(-not $state.Paragraph.Editable){$hint.Text=$state.Paragraph.Reason}
     else{$hint.Text='Редактируйте текст и оформление выбранного абзаца ниже. Линейка задаёт отступы. Для вида документа откройте «Макет», для точных страниц — «Страницы Word».'}
    }else{
     $paragraphText.Text='';$paragraphText.ReadOnly=$true;$paragraphTitle.Text='Выберите абзац в списке выше.'
    }
    & $paragraphFormatEditor.Load
   }finally{$state.Loading=$previousLoading;& $updateAvailability}
  }.GetNewClosure()
  $refreshParagraphs={param([string]$selectedId='')
   $previousLoading=[bool]$state.Loading;$state.Loading=$true;$paragraphList.BeginUpdate()
   try{
    $paragraphList.Items.Clear();$paragraphList.SelectedIndex=-1;$state.VisibleParagraphs=@();$partIndex=$partCombo.SelectedIndex
    if($partIndex -ge 0){
     $partName=$state.Model.PartOrder[$partIndex]
     foreach($paragraph in $state.Model.Paragraphs | Where-Object {$_.Part -ceq $partName}){
      $preview=($paragraph.Text -replace '[\r\n\t]+',' ');if($preview.Length -gt 145){$preview=$preview.Substring(0,145)+'…'}
      $display=$paragraph.Location+' | '+$preview;if(-not $paragraph.Editable){$display='[только чтение] '+$display}
      $state.VisibleParagraphs+=@($paragraph);[void]$paragraphList.Items.Add($display)
      if($paragraph.Id -ceq $selectedId){$paragraphList.SelectedIndex=$paragraphList.Items.Count-1}
     }
    }
    if($paragraphList.SelectedIndex -lt 0 -and $paragraphList.Items.Count){$paragraphList.SelectedIndex=0}
   }finally{$paragraphList.EndUpdate();$state.Loading=$previousLoading}
   & $loadParagraph
  }.GetNewClosure()
  $refreshParts={
   $previousLoading=[bool]$state.Loading;$state.Loading=$true;$partCombo.Items.Clear()
   foreach($part in $state.Model.PartOrder){$label=if($part -ceq 'word/document.xml'){'Основной документ'}elseif($part -match '/header'){'Верхний колонтитул'}else{'Нижний колонтитул'};[void]$partCombo.Items.Add(($label+' — '+$part))}
   $partCombo.SelectedIndex=0;$state.Paragraph=$null;$state.Loading=$previousLoading;& $refreshParagraphs
  }.GetNewClosure()
  $tree.Add_AfterSelect({if($state.Loading){return};try{& $commitProperties;$state.SelectedNode=$tree.SelectedNode;$state.Selected=if($state.SelectedNode){$state.SelectedNode.Tag}else{$null};& $loadProperties}catch{& $showError $_}}.GetNewClosure())
  $fieldName.Add_TextChanged({if($state.Loading){return};try{& $commitProperties}catch{& $showError $_}}.GetNewClosure())
  $sectionFieldName.Add_TextChanged({if($state.Loading){return};try{& $commitProperties}catch{& $showError $_}}.GetNewClosure())
  $sectionFieldPicker.Add_SelectedIndexChanged({
   if($state.Loading){return}
   try{
    $index=$sectionFieldPicker.SelectedIndex
    if(-not $state.Selected -or $state.Selected.Kind -ne 'section' -or $index -lt 0 -or $index -ge $state.SectionFieldOptions.Count){return}
    $sectionId=[string]$state.Selected.Section.Id;$nextFieldId=[string]$state.SectionFieldOptions[$index].Id
    & $commitProperties
    $state.SectionFieldIds[$sectionId]=$nextFieldId;& $loadProperties
   }catch{& $showError $_}
  }.GetNewClosure())
  $fieldMarker.Add_TextChanged({if($state.Loading){return};try{& $commitProperties}catch{& $showError $_}}.GetNewClosure())
  $paragraphText.Add_TextChanged({
   if($state.Loading -or -not $state.Paragraph -or -not $state.Paragraph.Editable -or $paragraphText.ReadOnly){return}
   try{
    & $commitParagraph
    $index=$paragraphList.SelectedIndex
    if($index -ge 0 -and $index -lt $state.VisibleParagraphs.Count -and $state.VisibleParagraphs[$index].Id -ceq $state.Paragraph.Id){
     $preview=($state.Paragraph.Text -replace '[\r\n\t]+',' ');if($preview.Length -gt 145){$preview=$preview.Substring(0,145)+'…'}
     $display=$state.Paragraph.Location+' | '+$preview
     $previousLoading=[bool]$state.Loading;$state.Loading=$true
     try{$paragraphList.Items[$index]=$display;$paragraphList.SelectedIndex=$index}finally{$state.Loading=$previousLoading}
    }
   }catch{& $showError $_}
  }.GetNewClosure())
  $partCombo.Add_SelectedIndexChanged({if($state.Loading){return};try{& $commitParagraph;& $refreshParagraphs}catch{& $showError $_}}.GetNewClosure())
  $paragraphList.Add_SelectedIndexChanged({if($state.Loading){return};try{& $commitParagraph;& $loadParagraph}catch{& $showError $_}}.GetNewClosure())
  $fieldType.Add_SelectedIndexChanged({if($state.Loading){return};& $updateAvailability}.GetNewClosure())
  $detailWord.Add_SelectedIndexChanged({if($state.Loading){return};& $updateAvailability}.GetNewClosure())
  $detailEnable.Add_Click({try{if(-not $state.PropertiesSelection -or -not $state.PropertiesSelection.Field -or $fieldType.SelectedIndex -notin @(0,1,2)){return};& $commitProperties;$fieldType.SelectedIndex=3;& $commitProperties;& $updateAvailability}catch{& $showError $_}}.GetNewClosure())
  $addSection.Add_Click({
   try{
    & $commitProperties;$sectionId=[guid]::NewGuid().ToString('N');$fieldId=[guid]::NewGuid().ToString('N')
    $field=& $editorCommands['New-UniversalField'] $fieldId 'Новый раздел' ('FIELD_'+$fieldId.Substring(0,8).ToUpperInvariant()) 'multiline'
    $section=[pscustomobject]@{Id=$sectionId;Title='Новый раздел';Fields=@($field)};$state.Schema.Sections+=@($section);& $refreshTree $section.Id
   }catch{& $showError $_}
  }.GetNewClosure())
  $renameSection={param($node=$null)
   if(-not $node){$node=$tree.SelectedNode}
   if(-not $node -or -not $node.Tag -or $node.Tag.Kind -ne 'section'){return}
   $sectionId=[string]$node.Tag.Section.Id
   & $commitProperties;& $commitParagraph;$previousTitle=[string]$node.Tag.Section.Title
   $result=& $editorCommands['Show-MedicalSectionRenameDialog'] $dialog $state.Schema $sectionId $state.Model $state.Paragraph
   if($result){
    # A section created with one matching main field remains a single named item.
    # Distinct child labels and sections with several fields stay independent.
    if(@($result.Section.Fields).Count -eq 1 -and $result.Section.Fields[0].Label -ceq $previousTitle){$result.Section.Fields[0].Label=[string]$result.Section.Title}
    & $refreshTree $result.Section.Id;if($result.WordChanged){& $refreshParagraphs $result.ParagraphId}
   }
  }.GetNewClosure()
  $editSection.Add_Click({try{& $renameSection}catch{& $showError $_}}.GetNewClosure())
  $tree.Add_NodeMouseDoubleClick({param($sender,$eventArgs)try{if($eventArgs.Node -and $eventArgs.Node.Tag.Kind -eq 'section'){& $renameSection $eventArgs.Node}}catch{& $showError $_}}.GetNewClosure())
  $tree.Add_KeyDown({param($sender,$eventArgs)if($eventArgs.KeyCode -eq 'F2' -and $tree.SelectedNode -and $tree.SelectedNode.Tag.Kind -eq 'section'){try{& $renameSection;$eventArgs.Handled=$true;$eventArgs.SuppressKeyPress=$true}catch{& $showError $_}}}.GetNewClosure())
  $addField.Add_Click({try{& $commitProperties;if(-not $state.Selected){throw 'Добавьте или выберите раздел.'};$section=$state.Selected.Section;$id=[guid]::NewGuid().ToString('N');$field=& $editorCommands['New-UniversalField'] $id 'Новое поле' ('FIELD_'+$id.Substring(0,8).ToUpperInvariant()) 'multiline';$section.Fields+=@($field);& $refreshTree $field.Id}catch{& $showError $_}}.GetNewClosure())
  $delete.Add_Click({try{& $commitProperties;if(-not $state.Selected){return};if([Windows.Forms.MessageBox]::Show($dialog,'Удалить выбранное поле или раздел? Маркеры в Word удалите или замените справа.','Удаление','YesNo','Question') -ne 'Yes'){return};$selection=$state.Selected;if($selection.Kind -eq 'section'){$state.Schema.Sections=@($state.Schema.Sections | Where-Object {$_.Id -cne $selection.Section.Id})}else{$selection.Section.Fields=@($selection.Section.Fields | Where-Object {$_.Id -cne $selection.Field.Id})};& $refreshTree}catch{& $showError $_}}.GetNewClosure())
  $moveItem={param([int]$offset)
   & $commitProperties;if(-not $state.Selected){return};$selection=$state.Selected
   $items=if($selection.Kind -eq 'section'){@($state.Schema.Sections)}else{@($selection.Section.Fields)}
   $selectedId=if($selection.Kind -eq 'section'){$selection.Section.Id}else{$selection.Field.Id};$index=-1
   for($i=0;$i -lt $items.Count;$i++){if($items[$i].Id -ceq $selectedId){$index=$i;break}}
   $target=$index+$offset;if($index -lt 0 -or $target -lt 0 -or $target -ge $items.Count){return}
   $old=$items[$index];$items[$index]=$items[$target];$items[$target]=$old
   if($selection.Kind -eq 'section'){$state.Schema.Sections=$items}else{$selection.Section.Fields=$items};& $refreshTree $selectedId
  }.GetNewClosure()
  $up.Add_Click({try{& $moveItem -1}catch{& $showError $_}}.GetNewClosure());$down.Add_Click({try{& $moveItem 1}catch{& $showError $_}}.GetNewClosure())
  $insertField.Add_Click({try{& $commitProperties;if(-not $state.PropertiesSelection -or -not $state.PropertiesSelection.Field){throw 'Выберите поле слева или в списке «Поле раздела».'};$paragraphText.SelectedText='{{'+$state.PropertiesSelection.Field.Marker+'}}';[void]$paragraphText.Focus()}catch{& $showError $_}}.GetNewClosure())
  $insertDetail.Add_Click({try{& $commitProperties;if(-not $state.PropertiesSelection -or -not $state.PropertiesSelection.Field -or $state.PropertiesSelection.Field.Type -ne 'choice_detail' -or (& $editorCommands['Get-UniversalDetailWordPosition'] $state.PropertiesSelection.Field) -ne 'marker'){throw 'Выберите поле «Список с уточнением» и расположение Word «Отдельный маркер».'};$paragraphText.SelectedText='{{'+$state.PropertiesSelection.Field.DetailMarker+'}}';[void]$paragraphText.Focus()}catch{& $showError $_}}.GetNewClosure())
  $insertDate.Add_Click({$paragraphText.SelectedText='{{ADMISSION_DATETIME}}';[void]$paragraphText.Focus()}.GetNewClosure())
  $addParagraph.Add_Click({try{& $commitParagraph;$partName=$state.Model.PartOrder[$partCombo.SelectedIndex];$afterId=if($state.Paragraph){$state.Paragraph.Id}else{''};$record=& $editorCommands['Add-MedicalTemplateParagraph'] $state.Model $partName $afterId '';& $refreshParagraphs $record.Id;[void]$paragraphText.Focus()}catch{& $showError $_}}.GetNewClosure())
  $deleteParagraph.Add_Click({
   try{
    if(-not $state.Paragraph -or -not $state.Paragraph.Editable){return}
    & $commitParagraph
    if([Windows.Forms.MessageBox]::Show($dialog,'Удалить выбранный абзац? Если он содержит нужный маркер, вставьте маркер в другое место перед применением.','Удалить абзац','YesNo','Question') -ne 'Yes'){return}
    $record=& $editorCommands['Remove-MedicalTemplateParagraph'] $state.Model $state.Paragraph.Id
    $state.Paragraph=$null
    & $refreshParagraphs $record.Id
   }catch{& $showError $_}
  }.GetNewClosure())
  $pasteParagraphText={
   try{
    if(-not $state.Paragraph -or -not $state.Paragraph.Editable -or $paragraphText.ReadOnly){return}
    if(-not [Windows.Forms.Clipboard]::ContainsText([Windows.Forms.TextDataFormat]::UnicodeText)){throw 'В буфере обмена нет текста.'}
    $paragraphText.SelectedText=[Windows.Forms.Clipboard]::GetText([Windows.Forms.TextDataFormat]::UnicodeText)
    [void]$paragraphText.Focus()
   }catch{& $showError $_}
  }.GetNewClosure()
  $pasteText.Add_Click($pasteParagraphText);$pasteMenu.Add_Click($pasteParagraphText)
  $cutMenu.Add_Click({if(-not $paragraphText.ReadOnly){$paragraphText.Cut()}}.GetNewClosure())
  $copyMenu.Add_Click({$paragraphText.Copy()}.GetNewClosure())
  $selectMenu.Add_Click({$paragraphText.SelectAll();[void]$paragraphText.Focus()}.GetNewClosure())
  $loadTemplate.Add_Click({
   $picker=New-Object Windows.Forms.OpenFileDialog;$picker.Title='Шаблон Word для этой формы';$picker.Filter='Word (*.docx;*.dotx)|*.docx;*.dotx'
   try{if($picker.ShowDialog($dialog) -eq 'OK'){& $commitProperties;& $commitParagraph;$candidate=& $editorCommands['Read-MedicalTemplateModel'] $picker.FileName;if([Windows.Forms.MessageBox]::Show($dialog,'Заменить рабочий шаблон? Его текущие изменения не будут сохранены. Поля формы сохранятся.','Загрузка Word','YesNo','Question') -eq 'Yes'){$state.Model=$candidate;$templateName.Text=(& $editorCommands['Get-MedicalFormDisplayName'] $picker.FileName 'Шаблон формы')+$candidate.TemplateExtension;& $refreshParts}}}catch{& $showError $_}finally{$picker.Dispose()}
  }.GetNewClosure())
  $buildTemplate.Add_Click({
   $path=Join-Path ([IO.Path]::GetTempPath()) ('mc-editor-rebuild-'+[guid]::NewGuid().ToString('N')+'.docx')
   try{& $commitProperties $true;& $commitParagraph;& $editorCommands['Assert-UniversalConfig'] $state.Schema;if([Windows.Forms.MessageBox]::Show($dialog,'Создать новый Word по текущим полям? Рабочий текст шаблона будет заменён; исходный файл останется сохранён.','Новый шаблон','YesNo','Question') -eq 'Yes'){& $editorCommands['New-UniversalTemplate'] $path $state.Schema;$state.Model=& $editorCommands['Read-MedicalTemplateModel'] $path;$templateName.Text='Мой шаблон.docx';& $refreshParts}}catch{& $showError $_}finally{if([IO.File]::Exists($path)){[IO.File]::Delete($path)}}
  }.GetNewClosure())
  $save.Add_Click({try{& $commitProperties $true;& $commitParagraph;$state.Result=& $editorCommands['Save-MedicalEditorResult'] $state.Schema $state.Model $templateName.Text.Trim();$dialog.DialogResult='OK';$dialog.Close()}catch{& $showError $_}}.GetNewClosure())
  $clearWordPreview={
   foreach($control in @($wordPages.Controls)){
    if($control -is [Windows.Forms.PictureBox] -and $control.Image){$control.Image.Dispose();$control.Image=$null}
    $wordPages.Controls.Remove($control);$control.Dispose()
   }
   if($state.WordPreview){& $editorCommands['Remove-MedicalWordPreview'] $state.WordPreview;$state.WordPreview=$null}
  }.GetNewClosure()
  $resizeWordPages={
   $width=[Math]::Max(160,($wordPages.ClientSize.Width-30));$height=[Math]::Max(100,($wordPages.ClientSize.Height-60))
   $graphics=$wordPages.CreateGraphics();try{$displayDpi=[double]$graphics.DpiX}finally{$graphics.Dispose()}
   foreach($control in $wordPages.Controls){
    if($control -is [Windows.Forms.PictureBox] -and $control.Tag){
     $pageWidth=if($wordZoomCombo.SelectedIndex -eq 0){[Math]::Min($width,($height*$control.Tag.WidthPoints/$control.Tag.HeightPoints))}elseif($wordZoomCombo.SelectedIndex -eq 2){$control.Tag.WidthPoints*$displayDpi/72.0}else{$width}
     $control.Width=[int][Math]::Max(60,[Math]::Round($pageWidth));$control.Height=[int][Math]::Round($control.Width*$control.Tag.HeightPoints/$control.Tag.WidthPoints)
    }
   }
  }.GetNewClosure()
  $documentTabs.Add_SelectedIndexChanged({
   if($state.Loading){return}
   try{
    & $commitParagraph
    if($documentTabs.SelectedTab -eq $layoutTab){$layoutBrowser.DocumentText=& $editorCommands['ConvertTo-MedicalTemplateHtml'] $state.Model $(if($state.Paragraph){$state.Paragraph.Id}else{''})}
    elseif($documentTabs.SelectedTab -eq $formatTab){& $paragraphFormatEditor.Load}
   }catch{& $showError $_}
  }.GetNewClosure())
  $wordPreviewButton.Add_Click({
   try{
    & $commitParagraph;$wordPreviewButton.Enabled=$false;$dialog.UseWaitCursor=$true
    $wordStatus.Text='Word формирует страницы…';$wordStatus.Refresh()
    & $clearWordPreview
    $state.WordPreview=& $editorCommands['New-MedicalWordPreview'] $state.Model
    $wordStatus.Text=$state.WordPreview.Message
    if($state.WordPreview.Available){
     foreach($page in $state.WordPreview.Pages){
      $caption=& $editorCommands['New-MedicalEditorLabel'] ('Страница '+$page.Number);$caption.Width=[Math]::Max(160,($wordPages.ClientSize.Width-30));$caption.Height=26;$caption.Dock='None';$wordPages.Controls.Add($caption)
      $picture=New-Object Windows.Forms.PictureBox;$picture.SizeMode='Zoom';$picture.BackColor=[Drawing.Color]::White;$picture.BorderStyle='FixedSingle';$picture.Tag=$page
      $picture.Image=[Drawing.Image]::FromFile($page.Path);$wordPages.Controls.Add($picture)
     }
     & $resizeWordPages
    }
   }catch{$wordStatus.Text='Не удалось получить страницы Word.';& $showError $_}
   finally{$dialog.UseWaitCursor=$false;$wordPreviewButton.Enabled=$true}
  }.GetNewClosure())
  $wordPages.Add_SizeChanged({& $resizeWordPages}.GetNewClosure())
  $wordZoomCombo.Add_SelectedIndexChanged({& $resizeWordPages}.GetNewClosure())
  & $refreshTree;& $refreshParts
  if(Get-Command Set-DarkTheme -ErrorAction SilentlyContinue){Set-DarkTheme $dialog}
  & $paragraphFormatEditor.RestorePaperColors
  & $paragraphFormatEditor.Load
  try{if($dialog.ShowDialog($owner) -eq 'OK'){return $state.Result};return $null}finally{& $clearWordPreview;$textContext.Dispose();$dialog.Dispose()}
 }finally{if($initialTemp -and [IO.File]::Exists($initialTemp)){[IO.File]::Delete($initialTemp)}}
}
