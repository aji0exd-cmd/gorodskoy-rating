﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v66'))
$ErrorActionPreference='Stop';$script:checks=0;$script:recoveryPassLog=New-Object 'System.Collections.Generic.List[string]';$script:recoveryFailures=New-Object 'System.Collections.Generic.List[string]'
function Assert-Recovery([bool]$condition,[string]$message){if(-not $condition){$script:recoveryFailures.Add($message);throw $message};$script:checks++;$script:recoveryPassLog.Add('PASS '+$message)}
function Assert-RecoveryRejected([scriptblock]$operation,[string]$message){$failed=$false;try{& $operation | Out-Null}catch{$failed=$true};Assert-Recovery $failed $message}
function Import-RecoveryFunctions([string]$path,[string[]]$names){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors | Out-String)}
 foreach($name in $names){
  $definition=$ast.Find({param($node)$node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $name},$false)
  if(-not $definition){throw ('Missing production function '+$name)}
  . ([scriptblock]::Create(($definition.Extent.Text -replace '^function\s+','function script:')))
 }
}
# Native widget drawing and modal input are adapted. All recovery helpers, event
# handler bodies, schemas, template import, document rendering and card state are
# the shipped production functions. No global aliases hide callback scope bugs.
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @'
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
public class MedicalRecoveryControl {
 public MedicalRecoveryControls Controls {get;private set;}
 public ArrayList Items {get;private set;}
 public ArrayList ColumnStyles {get;private set;}
 public MedicalRecoveryControl Parent {get;set;}
 private string text="";
 public string Text {get{return text;}set{text=value??"";if(TextChanged!=null)TextChanged(this,EventArgs.Empty);}}
 private int selectedIndex=-1;
 public int SelectedIndex {get{return selectedIndex;}set{selectedIndex=value;if(value>=0&&value<Items.Count)Text=Convert.ToString(Items[value]);if(SelectedIndexChanged!=null)SelectedIndexChanged(this,EventArgs.Empty);}}
 public object SelectedItem {get{return selectedIndex>=0&&selectedIndex<Items.Count?Items[selectedIndex]:null;}set{SelectedIndex=Items.IndexOf(value);}}
 public bool Enabled {get;set;}
 public bool Visible {get;set;}
 public bool AutoSize {get;set;}
 public bool IsDisposed {get;private set;}
 public bool Multiline {get;set;}
 public bool AcceptsReturn {get;set;}
 public bool WrapContents {get;set;}
 public bool Checked {get;set;}
 public string Anchor {get;set;}
 public string Dock {get;set;}
 public string FlowDirection {get;set;}
 public string AutoSizeMode {get;set;}
 public string ScrollBars {get;set;}
 public string DropDownStyle {get;set;}
 public int DropDownWidth {get;set;}
 public int ColumnCount {get;set;}
 public int RowCount {get;set;}
 public string CustomFormat {get;set;}
 public string AccessibleName {get;set;}
 public string TextAlign {get;set;}
 public object Tag {get;set;}
 public object Font {get;set;}
 public object BackColor {get;set;}
 public object ForeColor {get;set;}
 public object DialogResult {get;set;}
 public Size Size {get;set;}
 public Size ClientSize {get;set;}
 public Size AutoScrollMinSize {get;set;}
 public Size MinimumSize {get;set;}
 public Size MaximumSize {get;set;}
 public Point Location {get;set;}
 public Point AutoScrollPosition {get;set;}
 public Windows.Forms.Padding Padding {get;set;}
 public Windows.Forms.Padding Margin {get;set;}
 public int Width {get;set;}
 public int Height {get;set;}
 public int Bottom {get{return Location.Y+Height;}}
 public DateTime Value {get;set;}
 public MedicalRecoveryControl(){Controls=new MedicalRecoveryControls(this);Items=new ArrayList();ColumnStyles=new ArrayList();Enabled=true;ClientSize=new Size(1100,600);MinimumSize=Size.Empty;MaximumSize=Size.Empty;}
 public void SetBounds(int x,int y,int w,int h){Location=new Point(x,y);Width=w;Height=h;}
 public void SuspendLayout(){}
 public void ResumeLayout(bool perform){}
 public void PerformLayout(){}
 public void Refresh(){}
 public void ScrollControlIntoView(MedicalRecoveryControl child){}
 public bool Focus(){return true;}
 public void Dispose(){IsDisposed=true;}
 public event EventHandler Click;
 public event EventHandler TextChanged;
 public event EventHandler SelectedIndexChanged;
 public event EventHandler CheckedChanged;
 public void RaiseClick(){if(Click!=null)Click(this,EventArgs.Empty);}
 public void RaiseCheckedChanged(){if(CheckedChanged!=null)CheckedChanged(this,EventArgs.Empty);}
}
public sealed class MedicalRecoveryControls:IEnumerable {
 private List<MedicalRecoveryControl> items=new List<MedicalRecoveryControl>();private MedicalRecoveryControl owner;
 public MedicalRecoveryControls(MedicalRecoveryControl control){owner=control;}
 public int Count {get{return items.Count;}}
 public MedicalRecoveryControl this[int i]{get{return items[i];}}
 public void Add(MedicalRecoveryControl child){if(child.Parent!=null)child.Parent.Controls.Remove(child);items.Add(child);child.Parent=owner;}
 public void Add(MedicalRecoveryControl child,int column,int row){Add(child);}
 public void Remove(MedicalRecoveryControl child){if(items.Remove(child))child.Parent=null;}
 public bool Contains(MedicalRecoveryControl child){return items.Contains(child);}
 public void Clear(){foreach(MedicalRecoveryControl child in items)child.Parent=null;items.Clear();}
 public IEnumerator GetEnumerator(){return items.GetEnumerator();}
}
namespace Windows.Forms {
 public enum SizeType{Absolute,Percent,AutoSize}
 public class Padding {public int Left,Top,Right,Bottom;public Padding(int all){Left=Top=Right=Bottom=all;}public Padding(int left,int top,int right,int bottom){Left=left;Top=top;Right=right;Bottom=bottom;}}
 public class ColumnStyle {public ColumnStyle(SizeType sizeType,float width){}}
 public class TableLayoutPanel:MedicalRecoveryControl{}
 public class FlowLayoutPanel:MedicalRecoveryControl{}
 public class TextBox:MedicalRecoveryControl{}
 public class Label:MedicalRecoveryControl{}
 public class Button:MedicalRecoveryControl{}
 public class ComboBox:MedicalRecoveryControl{}
 public class CheckBox:MedicalRecoveryControl{}
 public class Form:MedicalRecoveryControl {
  public static Action<Form> Plan;public static int Calls=0;
  public string StartPosition {get;set;}public string FormBorderStyle {get;set;}
  public bool MaximizeBox {get;set;}public bool MinimizeBox {get;set;}public bool ShowInTaskbar {get;set;}
  public object CancelButton {get;set;}public object AcceptButton {get;set;}public bool Closed {get;private set;}
  public object ShowDialog(object owner){Calls++;if(Plan!=null)Plan(this);return DialogResult??"Cancel";}
  public void Close(){Closed=true;}
 }
 public class OpenFileDialog {
  public static Queue<string> Paths=new Queue<string>();public static Queue<string> Results=new Queue<string>();public static int Calls=0;public static string CapturedFilter="";
  public string Filter {get;set;}public string Title {get;set;}public string InitialDirectory {get;set;}public string FileName {get;set;}
  public bool CheckFileExists {get;set;}public bool Multiselect {get;set;}
  public object ShowDialog(object owner){Calls++;CapturedFilter=Filter;FileName=Paths.Count>0?Paths.Dequeue():"";return Results.Count>0?Results.Dequeue():"Cancel";}
  public void Dispose(){}
 }
 public class SaveFileDialog {
  public static string PickedPath="";public static string Result="OK";public static int Calls=0;public static string CapturedName="";
  public string Filter {get;set;}public string Title {get;set;}public string InitialDirectory {get;set;}public string FileName {get;set;}
  public string DefaultExt {get;set;}public bool AddExtension {get;set;}public bool OverwritePrompt {get;set;}
  public object ShowDialog(object owner){Calls++;CapturedName=FileName;FileName=PickedPath.Length>0?PickedPath:System.IO.Path.Combine(InitialDirectory,FileName);return Result;}
  public void Dispose(){}
 }
 public static class MessageBox {
  public static string Result="OK";public static List<string> Messages=new List<string>();
  public static string Show(params object[] args){Messages.Add(args.Length>1?Convert.ToString(args[1]):"");return Result;}
 }
}
namespace System.Windows.Forms {
 public enum DialogResult{None,OK,Cancel}
 public class Label:global::Windows.Forms.Label{}
 public class ComboBox:global::Windows.Forms.ComboBox{}
 public class TableLayoutPanel:global::Windows.Forms.TableLayoutPanel{}
 public sealed class SaveFileDialog {
  public static string PickedPath="";public static DialogResult Result=DialogResult.OK;public static int Calls=0;public static string CapturedName="";
  public string Filter {get;set;}public string Title {get;set;}public string InitialDirectory {get;set;}public string FileName {get;set;}
  public string DefaultExt {get;set;}public bool AddExtension {get;set;}public bool OverwritePrompt {get;set;}
  public DialogResult ShowDialog(){Calls++;CapturedName=FileName;FileName=PickedPath.Length>0?PickedPath:System.IO.Path.Combine(InitialDirectory,FileName);return Result;}
 }
 public sealed class FolderBrowserDialog {public string Description {get;set;}public string SelectedPath {get;set;}public DialogResult ShowDialog(){return DialogResult.Cancel;}}
 public static class MessageBox {public static string Show(params object[] args){return global::Windows.Forms.MessageBox.Show(args);}}
}
public class MedicalOutlineTable:Windows.Forms.TableLayoutPanel{}
public class SafeComboBox:Windows.Forms.ComboBox{}
'@
# GDI font drawing is adapted only; paragraph/Word formatting is untouched.
function New-Object {
 [CmdletBinding()]param([Parameter(Position=0,Mandatory=$true)][string]$TypeName,[Parameter(Position=1)][object[]]$ArgumentList)
 if($TypeName -eq 'Drawing.Font'){return [pscustomobject]@{Name=$ArgumentList[0];Size=$ArgumentList[1]}}
 if($PSBoundParameters.ContainsKey('ArgumentList')){return ,(Microsoft.PowerShell.Utility\New-Object -TypeName $TypeName -ArgumentList $ArgumentList)}
 return ,(Microsoft.PowerShell.Utility\New-Object -TypeName $TypeName)
}
function Set-DarkTheme($control){}
function New-MedicalInputFrame($control){return $control}
function Get-RecoveryButton($dialog,[string]$text){$buttons=@($dialog.Controls | Where-Object {$_ -is [Windows.Forms.Button] -and $_.Text -ceq $text});if($buttons.Count -ne 1){throw ('Missing/ambiguous recovery button '+$text)};return $buttons[0]}
function Get-RecoveryStateSignature {
 $schema=Copy-MedicalFormSchema $script:universalConfig;$schema.Template='';$schema.AutoTemplate=$false;$schema.PSObject.Properties.Remove('PreserveTemplateFormatting')
 return ([ordered]@{Schema=$schema;Values=$script:universalValues;Details=$script:universalDetails;Stages=$script:stageData;Stage=$script:stage;Diary=$script:diaryIndex;Case=$script:caseFile;Folder=$script:caseFolder;SavedName=$script:caseLastSavedPatientName;Patient=[string]$script:patientNameControl.Text;Admission=$script:admissionControl.Value.ToString('o');DiaryTemplate=$script:stageTemplates.diary;DischargeTemplate=$script:stageTemplates.discharge}|ConvertTo-Json -Depth 50 -Compress)
}
function Set-RecoveryFixture([string]$missingPath){
 $script:universalConfig=Copy-MedicalFormSchema $script:fixtureSchema;$script:universalConfig.Template=$missingPath;$script:universalConfig.AutoTemplate=$false
 $script:universalValues=@{'identity-custom'='Текущий Пациент';'birth-custom'='02.03.1984';notes="Первая строка`r`nВторая строка";'choice-custom'='Сохранённый вариант, которого больше нет в Word'}
 $script:universalDetails=@{'choice-custom'='Уточнение сохранить'};$script:universalInputs=@{};$script:universalDetailInputs=@{};$script:universalMultiInputs=@{};$script:universalRepeatInputs=@{}
 foreach($field in Get-UniversalFields $script:universalConfig){$control=New-Object MedicalRecoveryControl;$control.Text=[string]$script:universalValues[[string]$field.Id];$script:universalInputs[[string]$field.Id]=$control}
 $detail=New-Object MedicalRecoveryControl;$detail.Text=$script:universalDetails['choice-custom'];$script:universalDetailInputs['choice-custom']=$detail
 $script:stage='initial';$script:stageData=@{initial=@('Старый кэш осмотра');diary_1=@('Первый дневник');diary_2=@('Второй дневник');discharge=@('Полная выписка')};$script:diaryIndex=2
 $script:stageTemplates=@{initial=$missingPath;diary='Не менять дневник.dotx';discharge='Не менять выписку.docx'};$script:source=$missingPath;$script:fields=@();$script:controls=@();$script:hospitalControls=@{}
 $script:caseFolder=$script:temp;$script:caseFile=Join-Path $script:temp 'Оригинальная карта.docx';$script:caseLastSavedPatientName='Текущий Пациент'
 $script:admissionControl.Value=[datetime]'2026-10-13T20:15:00';$script:medicalWorkspaceReady=$true;$script:activeMedicalFormName='Форма из карты';$script:activeMedicalFormPath='';$script:medicalFormBaseline=Get-MedicalFormSignature $script:universalConfig
 Set-UniversalDemographics;Capture-Stage
 [Windows.Forms.Form]::Calls=0;[Windows.Forms.MessageBox]::Messages.Clear();[Windows.Forms.MessageBox]::Result='OK';[Windows.Forms.OpenFileDialog]::Calls=0;[Windows.Forms.OpenFileDialog]::Paths.Clear();[Windows.Forms.OpenFileDialog]::Results.Clear();[System.Windows.Forms.SaveFileDialog]::Calls=0;[System.Windows.Forms.SaveFileDialog]::PickedPath='';[Windows.Forms.SaveFileDialog]::Calls=0;[Windows.Forms.SaveFileDialog]::PickedPath=''
}
$script:temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-v66-recovery-events-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($script:temp)
try{
 $root=Join-Path $script:temp 'program';[void][IO.Directory]::CreateDirectory($root)
 foreach($name in @('universal.ps1','universal-ui.ps1','forms-v59.ps1','forms-ui-v59.ps1','document-actions.ps1','card-document-v65.ps1','template-recovery-v66.ps1','template-editor-v59.ps1','workspace-settings.ps1')){Copy-Item -LiteralPath (Join-Path $Project $name) -Destination (Join-Path $root $name)}
 . (Join-Path $root 'universal.ps1');. (Join-Path $root 'forms-v59.ps1');. (Join-Path $root 'universal-ui.ps1');. (Join-Path $root 'document-actions.ps1');. (Join-Path $root 'card-document-v65.ps1');. (Join-Path $root 'template-recovery-v66.ps1');. (Join-Path $root 'template-editor-v59.ps1');. (Join-Path $root 'workspace-settings.ps1');. (Join-Path $root 'forms-ui-v59.ps1')
 Import-RecoveryFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart','Get-InitialExamBindings','Sync-InitialExamValues','Get-StageKey','Capture-Stage','Get-FullRegistration','Get-HospitalizationValues','Set-SdtValue','Set-PatientDetails','Save-Document','Save-Case','Read-CaseDocument')
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main';$script:fontFile=Join-Path $Project 'document-font.json'
 $form=New-Object MedicalRecoveryControl;$panel=New-Object MedicalRecoveryControl;$save=New-Object MedicalRecoveryControl;$caseSave=New-Object Windows.Forms.Button
 $stageInitial=New-Object MedicalRecoveryControl;$stageDiary=New-Object MedicalRecoveryControl;$stageDischarge=New-Object MedicalRecoveryControl
 foreach($name in @('patientNameControl','patientBirthControl','patientAddressControl','streetControl','houseControl','apartmentControl','admissionControl')){Set-Variable -Scope Script -Name $name -Value (New-Object MedicalRecoveryControl)}
 $script:darkBg='Background';$script:darkPanel='Panel';$script:darkMuted='Muted';$script:uiSuccess='Success';$script:uiDanger='Danger'
 $sourceFile=Join-Path $script:temp 'Оформленный первичный осмотр.docx';$script:fixtureSchema=New-UniversalConfig
 $choice=New-UniversalField 'choice-custom' 'Жалобы и уточнение' 'CHOICE' 'choice_detail';$choice.Options=@('Первый вариант','Второй вариант');$choice|Add-Member -NotePropertyName DetailWordPosition -NotePropertyValue 'marker';$choice|Add-Member -NotePropertyName DetailMarker -NotePropertyValue 'CHOICE_DETAIL';$choice|Add-Member -NotePropertyName DetailFormPosition -NotePropertyValue 'right'
 $script:fixtureSchema.Sections=@([pscustomobject]@{Id='section-fixed-id';Title='Не менять название и структуру';Fields=@((New-UniversalField 'identity-custom' 'Моя роль ФИО' 'PATIENT_NAME' 'text' 'name'),(New-UniversalField 'birth-custom' 'Дата рождения' 'PATIENT_BIRTH' 'text' 'birth'),(New-UniversalField 'notes' 'Многострочный ответ' 'NOTES' 'multiline'),$choice)})
 $script:fixtureSchema.AutoTemplate=$false;$script:fixtureSchema.Template=$sourceFile;New-UniversalTemplate $sourceFile $script:fixtureSchema
 $mcform=Join-Path $script:temp 'Другая структура, нужный Word.mcform';$otherSchema=Copy-MedicalFormSchema $script:fixtureSchema;$otherSchema.Sections[0].Id='foreign-section';$otherSchema.Sections[0].Title='Не загружать это название';foreach($f in Get-UniversalFields $otherSchema){$f.Id='foreign-'+$f.Id;$f.Label='Постороннее '+$f.Label};[void](Write-MedicalForm $mcform $otherSchema 'Не загружать эту форму')
 function Open-Stage {if($script:stage -ne 'initial'){throw 'Fixture covers initial view only'};Open-UniversalInitial}

 $missing=Join-Path $script:temp 'No longer installed/01-old-storage-id.docx'
 Set-RecoveryFixture $missing;$before=Get-RecoveryStateSignature
 Open-UniversalInitial
 Assert-Recovery ((Get-RecoveryStateSignature) -ceq $before) 'Missing template renders the initial examination without changing schema, answers or case bindings'
 Assert-Recovery ($script:universalInputs.Count -eq 4 -and $script:universalInputs['identity-custom'].Text -ceq 'Текущий Пациент') 'Missing-template view restores every custom field and the configured patient-name role'
 Assert-Recovery ($script:universalInputs['choice-custom'].Text -ceq $script:universalValues['choice-custom'] -and $script:universalInputs['choice-custom'].Items.Contains($script:universalValues['choice-custom'])) 'Missing-template dropdown retains a saved answer absent from configured options'
 Assert-Recovery ($script:universalDetailInputs['choice-custom'].Text -ceq 'Уточнение сохранить' -and -not $script:universalBuilding) 'Missing-template view restores its clarification and releases the building guard'
 Assert-Recovery ($script:universalWordFields.Count -eq 0 -and $save.Enabled) 'Unavailable Word source does not block editing or pretend source lists were loaded'
 $script:universalConfig.Sections[0].Fields[3].Options=@();$script:universalConfig.Sections[0].Fields[3].WordId='unavailable-word-list';Open-UniversalInitial
 Assert-Recovery ($script:universalInputs['choice-custom'].Items.Count -eq 1 -and $script:universalInputs['choice-custom'].Text -ceq $script:universalValues['choice-custom']) 'A Word-bound choice with unavailable options still exposes its actual saved answer'
 Set-RecoveryFixture $missing;$before=Get-RecoveryStateSignature;$schemaBefore=$script:universalConfig | ConvertTo-Json -Depth 50 -Compress
 [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{param($dialog);$dialog.DialogResult='Cancel'}
 $ready=Ensure-MedicalCurrentTemplate 'проверку отмены'
 Assert-Recovery (-not $ready -and [Windows.Forms.Form]::Calls -eq 1) 'Missing source opens the actual recovery chooser and respects Cancel'
 Assert-Recovery ((Get-RecoveryStateSignature) -ceq $before -and ($script:universalConfig | ConvertTo-Json -Depth 50 -Compress) -ceq $schemaBefore) 'Cancel preserves original template reference, field IDs, answers, clarifications and all stages'
 Assert-Recovery (-not (Test-Path -LiteralPath $script:universalConfigPath) -and @(Get-MedicalTemplates).Count -eq 0) 'Cancel writes neither cached configuration nor a substitute Word template'
 [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{
  param($dialog)
  [Windows.Forms.OpenFileDialog]::Paths.Enqueue($sourceFile);[Windows.Forms.OpenFileDialog]::Results.Enqueue('Cancel')
  (Get-RecoveryButton $dialog 'Выбрать Word / форму…').RaiseClick()
  Assert-Recovery (-not $dialog.Closed -and $null -eq $dialog.DialogResult) 'Canceling the file picker leaves the recovery chooser open'
  $dialog.DialogResult='Cancel'
 }
 $ready=Ensure-MedicalCurrentTemplate 'проверку отмены файла'
 Assert-Recovery (-not $ready -and (Get-RecoveryStateSignature) -ceq $before -and @(Get-MedicalTemplates).Count -eq 0) 'Canceling browse also retains complete patient state and imports no file'
 # A bad marker set is rejected inside the real callback and can be retried.
 $wrongSchema=Copy-MedicalFormSchema $script:fixtureSchema;$wrongSchema.Sections[0].Fields=@($wrongSchema.Sections[0].Fields | Where-Object {$_.Id -ne 'choice-custom'})
 $wrongPath=Join-Path $script:temp 'Несовместимый шаблон.docx';New-UniversalTemplate $wrongPath $wrongSchema
 $sourceHash=Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($sourceFile));$mcformHash=Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($mcform))
 [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{
  param($dialog)
  [Windows.Forms.OpenFileDialog]::Paths.Enqueue($wrongPath);[Windows.Forms.OpenFileDialog]::Results.Enqueue('OK')
  (Get-RecoveryButton $dialog 'Выбрать Word / форму…').RaiseClick()
  Assert-Recovery (-not $dialog.Closed -and $null -eq $dialog.DialogResult -and [Windows.Forms.MessageBox]::Messages.Count -eq 1) 'Incompatible Word markers are reported and leave the recovery dialog available for retry'
  Assert-Recovery ((Get-RecoveryStateSignature) -ceq $before -and @(Get-MedicalTemplates).Count -eq 0) 'Rejected template imports nothing and leaves original patient data intact'
  [Windows.Forms.OpenFileDialog]::Paths.Enqueue($sourceFile);[Windows.Forms.OpenFileDialog]::Results.Enqueue('OK')
  (Get-RecoveryButton $dialog 'Выбрать Word / форму…').RaiseClick()
 }
 $ready=Ensure-MedicalCurrentTemplate 'продолжение сохранения'
 Assert-Recovery ($ready -and [IO.File]::Exists((Get-UniversalTemplatePath)) -and $script:source -ceq (Get-UniversalTemplatePath)) 'Retrying with a compatible DOCX imports and binds a usable managed source'
 Assert-Recovery ((Get-RecoveryStateSignature) -ceq $before) 'DOCX recovery preserves all field IDs, values, details, diary/discharge data and card/FIO bindings'
 Assert-Recovery ((Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes((Get-UniversalTemplatePath)))) -ceq $sourceHash -and (Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($sourceFile))) -ceq $sourceHash) 'Recovered Word source keeps its exact bytes and never rewrites the chosen original'
 Assert-Recovery ([Windows.Forms.OpenFileDialog]::CapturedFilter.Contains('*.mcform') -and $script:universalConfig.PreserveTemplateFormatting) 'The recovery picker accepts reusable forms and preserves authored Word formatting'
 # Recovery from a mcform explicitly ignores its foreign section/field IDs.
 Set-RecoveryFixture $missing;$before=Get-RecoveryStateSignature
 [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{
  param($dialog)
  [Windows.Forms.OpenFileDialog]::Paths.Enqueue($mcform);[Windows.Forms.OpenFileDialog]::Results.Enqueue('OK')
  (Get-RecoveryButton $dialog 'Выбрать Word / форму…').RaiseClick()
 }
 $ready=Ensure-MedicalCurrentTemplate 'сохранение из формы'
 Assert-Recovery ($ready -and (Get-RecoveryStateSignature) -ceq $before) 'mcform recovery uses only its Word bytes while retaining the current schema and every patient answer'
 Assert-Recovery ($script:universalConfig.Sections[0].Id -ceq 'section-fixed-id' -and $script:universalConfig.Sections[0].Title -ceq 'Не менять название и структуру' -and $script:universalInputs.ContainsKey('identity-custom') -and -not $script:universalInputs.ContainsKey('foreign-identity-custom')) 'Foreign mcform section titles, field IDs and labels never replace the open patient form'
 Assert-Recovery ((Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes((Get-UniversalTemplatePath)))) -ceq $sourceHash -and (Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($mcform))) -ceq $mcformHash) 'mcform recovery imports the exact embedded source and leaves the selected form bytes unchanged'
 # Existing-folder selection exercises the other captured delegate as well.
 Set-RecoveryFixture $missing;$before=Get-RecoveryStateSignature
 [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{param($dialog);(Get-RecoveryButton $dialog 'Выбрать из папки').RaiseClick()}
 $ready=Ensure-MedicalCurrentTemplate 'выбор из папки'
 Assert-Recovery ($ready -and (Get-RecoveryStateSignature) -ceq $before -and [Windows.Forms.OpenFileDialog]::Calls -eq 0) 'The real managed-template selection callback rebinds without resetting patient fields or invoking browse'
 # Explicit generation is allowed only through its visible chooser action.
 Set-RecoveryFixture $missing;$before=Get-RecoveryStateSignature
 [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{param($dialog);(Get-RecoveryButton $dialog 'Создать по структуре').RaiseClick()}
 $ready=Ensure-MedicalCurrentTemplate 'новое простое оформление'
 Assert-Recovery ($ready -and (Get-RecoveryStateSignature) -ceq $before -and [IO.File]::Exists((Get-UniversalTemplatePath))) 'Explicit Create by Structure generates a new template while retaining the filled form and stage data'
 Assert-Recovery ([IO.Path]::GetFileName((Get-UniversalTemplatePath)).StartsWith('Восстановленный шаблон по структуре')) 'Recovery generation is clearly named separately from the missing authored original'
 # Save Form is guarded before either its destination dialog or writer.
 Set-RecoveryFixture $missing;$before=Get-RecoveryStateSignature
 [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{param($dialog);$dialog.DialogResult='Cancel'}
 Invoke-MedicalSaveForm
 Assert-Recovery ([Windows.Forms.SaveFileDialog]::Calls -eq 0 -and (Get-RecoveryStateSignature) -ceq $before) 'Canceling source recovery prevents Save Form from opening a destination dialog or writing a partial form'
 [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{param($dialog);[Windows.Forms.OpenFileDialog]::Paths.Enqueue($mcform);[Windows.Forms.OpenFileDialog]::Results.Enqueue('OK');(Get-RecoveryButton $dialog 'Выбрать Word / форму…').RaiseClick()}
 [Windows.Forms.SaveFileDialog]::PickedPath=Join-Path $script:temp 'Форма после восстановления.mcform';Invoke-MedicalSaveForm
 $savedForm=Read-MedicalForm ([Windows.Forms.SaveFileDialog]::PickedPath)
 Assert-Recovery ($savedForm.Schema.Sections[0].Id -ceq 'section-fixed-id' -and $savedForm.Schema.Sections[0].Fields[0].Id -ceq 'identity-custom') 'Save Form after recovery writes the current schema and template as a real reusable mcform'
 Assert-Recovery ((Get-RecoveryStateSignature) -ceq $before -and -not ([IO.File]::ReadAllText([Windows.Forms.SaveFileDialog]::PickedPath).Contains('Текущий Пациент'))) 'Saving the recovered form retains patient state in memory and excludes patient answers from mcform'
 # The main Templates and Editor commands both remain usable with a stale path.
 Set-RecoveryFixture $missing;$before=Get-RecoveryStateSignature
 [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{param($dialog);[Windows.Forms.OpenFileDialog]::Paths.Enqueue($sourceFile);[Windows.Forms.OpenFileDialog]::Results.Enqueue('OK');(Get-RecoveryButton $dialog 'Выбрать Word / форму…').RaiseClick()}
 Invoke-MedicalChooseTemplate
 Assert-Recovery ([Windows.Forms.Form]::Calls -eq 1 -and [IO.File]::Exists((Get-UniversalTemplatePath)) -and (Get-RecoveryStateSignature) -ceq $before) 'The main Templates command repairs its missing source instead of attempting to read the stale file'
 $script:editorCalls=0;$actualEditor=${function:Show-MedicalFormTemplateEditor}
 function Show-MedicalFormTemplateEditor($owner,$config){$script:editorCalls++;Assert-Recovery ([IO.File]::Exists((Get-UniversalTemplatePath $config))) 'The unified editor is opened only after a real compatible source was restored';return $null}
 try{
  Set-RecoveryFixture $missing;$before=Get-RecoveryStateSignature
  [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{param($dialog);$dialog.DialogResult='Cancel'}
  Invoke-MedicalFormTemplateEditor
  Assert-Recovery ($script:editorCalls -eq 0 -and (Get-RecoveryStateSignature) -ceq $before) 'Canceling editor recovery does not enter the editor or reset the patient'
  [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{param($dialog);[Windows.Forms.OpenFileDialog]::Paths.Enqueue($sourceFile);[Windows.Forms.OpenFileDialog]::Results.Enqueue('OK');(Get-RecoveryButton $dialog 'Выбрать Word / форму…').RaiseClick()}
  Invoke-MedicalFormTemplateEditor
  Assert-Recovery ($script:editorCalls -eq 1 -and (Get-RecoveryStateSignature) -ceq $before) 'The editor command recovers the template and canceling that editor retains all patient state'
 }finally{Set-Item Function:Show-MedicalFormTemplateEditor $actualEditor}
 # Render and save an actual card, then model an old card with a stale reference.
 Set-RecoveryFixture $sourceFile;$script:caseFile='';$script:caseLastSavedPatientName=$null
 [System.Windows.Forms.SaveFileDialog]::PickedPath=Join-Path $script:temp 'Сохранённая карта.docx';Save-Case
 $card=$script:caseFile;$cardHash=Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($card));$savedRecord=Read-CaseDocument $card
 Assert-Recovery ($savedRecord.patientName -ceq 'Текущий Пациент' -and $savedRecord.universal.Values.'identity-custom' -ceq 'Текущий Пациент' -and $savedRecord.universal.Details.'choice-custom' -ceq 'Уточнение сохранить') 'A recovered template reaches actual Save Card with complete current patient state'
 Assert-Recovery ($savedRecord.TemplateSnapshots.initial.BytesBase64 -ceq [Convert]::ToBase64String([IO.File]::ReadAllBytes($sourceFile))) 'Actual Save Card stores an exact unfilled source copy for future portable reopening'
 $script:universalConfig.Template=$missing;$script:source=$missing;$script:stageTemplates.initial=$missing;$before=Get-RecoveryStateSignature
 [Windows.Forms.Form]::Calls=0;[System.Windows.Forms.SaveFileDialog]::Calls=0;[Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{param($dialog);$dialog.DialogResult='Cancel'}
 Save-Case
 Assert-Recovery ([Windows.Forms.Form]::Calls -eq 1 -and [System.Windows.Forms.SaveFileDialog]::Calls -eq 0 -and (Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($card))) -ceq $cardHash) 'Canceling Save Card recovery returns before destination selection or overwriting the previous card'
 Assert-Recovery ((Get-RecoveryStateSignature) -ceq $before -and @(Get-ChildItem -LiteralPath $script:temp -Filter 'case_*.tmp').Count -eq 0) 'Canceled Save Card retains all patient/stage/path state and leaves no temporary card'
 $cancelPreview=Join-Path $script:temp 'Не создавать предпросмотр.docx';$cancelThrown=$false
 try{Export-CurrentStageDocument $cancelPreview}catch [OperationCanceledException]{$cancelThrown=$true}
 Assert-Recovery ($cancelThrown -and -not [IO.File]::Exists($cancelPreview) -and (Get-RecoveryStateSignature) -ceq $before) 'Preview cancellation raises its typed cancellation before any document output and retains the patient'
 [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{param($dialog);[Windows.Forms.OpenFileDialog]::Paths.Enqueue($mcform);[Windows.Forms.OpenFileDialog]::Results.Enqueue('OK');(Get-RecoveryButton $dialog 'Выбрать Word / форму…').RaiseClick()}
 Save-Case;$recoveredRecord=Read-CaseDocument $card
 Assert-Recovery ($script:caseFile -ceq $card -and $recoveredRecord.universal.Values.notes -ceq "Первая строка`r`nВторая строка" -and $recoveredRecord.stages.diary_2[0] -ceq 'Второй дневник' -and $recoveredRecord.stages.discharge[0] -ceq 'Полная выписка') 'Save Card after interactive mcform recovery renders and saves without losing multiline or later-stage data'
 Assert-Recovery ($recoveredRecord.universal.Schema.Sections[0].Fields[0].Id -ceq 'identity-custom' -and $recoveredRecord.universal.Schema.PreserveTemplateFormatting) 'The saved card retains original IDs and authored formatting after a source rebind'
 # Legacy cards have no stored source copy. They must restore answers first.
 $legacyRecord=Copy-UniversalObject $savedRecord;$legacyRecord.PSObject.Properties.Remove('TemplateSnapshots');$legacyRecord.universal.Schema.Template=$missing;$legacyRecord.templates.initial=$missing
 $legacyPath=Join-Path $script:temp 'Карта v65 с потерянным шаблоном.docx';Copy-Item -LiteralPath $card -Destination $legacyPath;Set-MedicalCardDocumentState $legacyPath $legacyRecord
 [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{
  param($dialog)
  Assert-Recovery ($script:caseFile -ceq $legacyPath -and $script:universalInputs['identity-custom'].Text -ceq 'Текущий Пациент' -and $script:universalDetailInputs['choice-custom'].Text -ceq 'Уточнение сохранить') 'Legacy card displays its restored answers and clarification before asking for a missing source'
  $dialog.DialogResult='Cancel'
 }
 Open-CasePath $legacyPath
 Assert-Recovery ($script:medicalWorkspaceReady -and $script:caseFile -ceq $legacyPath -and $script:caseLastSavedPatientName -ceq 'Текущий Пациент' -and $script:stageData.diary_2[0] -ceq 'Второй дневник') 'Canceling legacy-card recovery leaves the card open and editable with current FIO and every later stage'
 Assert-Recovery ($script:universalInputs['choice-custom'].Text -ceq 'Сохранённый вариант, которого больше нет в Word' -and $script:universalValues.notes -ceq "Первая строка`r`nВторая строка") 'Opening a legacy card with a stale source preserves unavailable dropdown and exact multiline answers'

 # Relocation considers the exact stored filename and preserves the live form.
 $relocatedFile=Join-Path $script:temp 'Автоматически перемещённый оригинал.docx';Copy-Item -LiteralPath $sourceFile -Destination $relocatedFile
 $relocatedReference=Join-Path $script:temp ('Old installation/'+[IO.Path]::GetFileName($relocatedFile))
 Set-RecoveryFixture $relocatedReference;$before=Get-RecoveryStateSignature
 [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{param($dialog);Assert-Recovery $false 'An exact relocated source must not show the recovery chooser'}
 $ready=Ensure-MedicalCurrentTemplate 'автоматический поиск'
 Assert-Recovery ($ready -and [Windows.Forms.Form]::Calls -eq 0 -and (Get-UniversalTemplatePath) -ceq $relocatedFile) 'An exact existing source relocated beside the card resolves automatically without asking the user'
 Assert-Recovery ((Get-RecoveryStateSignature) -ceq $before) 'Automatic exact-filename relocation preserves patient answers, schema and every later stage'
 # New cards carry unfilled source copies, so they reopen after all originals
 # and managed sources were removed. No generic substitute or chooser is used.
 $portable=Join-Path $script:temp 'Перенесённая карта с исходным шаблоном.docx';Copy-Item -LiteralPath $card -Destination $portable;Set-MedicalCardDocumentState $portable $savedRecord
 [IO.File]::Delete($sourceFile);foreach($item in @(Get-MedicalTemplates)){[IO.File]::Delete($item.Path)}
 [Windows.Forms.Form]::Calls=0;Open-CasePath $portable
 Assert-Recovery ([Windows.Forms.Form]::Calls -eq 0 -and [IO.File]::Exists((Get-UniversalTemplatePath))) 'Opening a new portable card restores its embedded source before rendering and needs no missing-template dialog'
 Assert-Recovery ((Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes((Get-UniversalTemplatePath)))) -ceq $sourceHash) 'Portable card reopening materializes the exact authored unfilled source instead of a generated replacement'
 Assert-Recovery ($script:caseFile -ceq $portable -and $script:caseLastSavedPatientName -ceq 'Текущий Пациент' -and $script:universalInputs['identity-custom'].Text -ceq 'Текущий Пациент') 'Portable reopening retains the current patient role, visible FIO and opened card destination'
 Assert-Recovery ($script:universalDetailInputs['choice-custom'].Text -ceq 'Уточнение сохранить' -and $script:stageData.diary_1[0] -ceq 'Первый дневник' -and $script:stageData.diary_2[0] -ceq 'Второй дневник' -and $script:stageData.discharge[0] -ceq 'Полная выписка') 'Portable reopening restores clarification, every diary and discharge data alongside the source'
 $portableBefore=Get-RecoveryStateSignature;$broken=Copy-UniversalObject $savedRecord;$broken.TemplateSnapshots.initial.Sha256=('0'*64)
 $brokenPath=Join-Path $script:temp 'Повреждённая копия карты.docx';Copy-Item -LiteralPath $portable -Destination $brokenPath
 # Write corrupt metadata at the ZIP layer: the production writer correctly
 # validates snapshots and would refuse manufacturing this damaged document.
 $z=[IO.Compression.ZipFile]::Open($brokenPath,[IO.Compression.ZipArchiveMode]::Update)
 try{
  $entry=$z.GetEntry('customXml/mc-case.xml');$entry.Delete()
  $payload=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($broken|ConvertTo-Json -Depth 50 -Compress)))
  Write-UniversalZipText $z 'customXml/mc-case.xml' ('<mc:case xmlns:mc="urn:medical-constructor:case:v65">'+$payload+'</mc:case>')
 }finally{$z.Dispose()}
 Assert-RecoveryRejected {Open-CasePath $brokenPath} 'Opening a card with a corrupt embedded source is rejected before binding another patient form'
 Assert-Recovery ((Get-RecoveryStateSignature) -ceq $portableBefore -and $script:caseFile -ceq $portable) 'A damaged card source leaves the currently open complete patient and card path unchanged'

 # The following stage tests run the actual router, Word control reader and
 # positional stage restore. Only Show-Fields draws fake native text widgets.
 Import-RecoveryFunctions (Join-Path $Project 'constructor.ps1') @('Read-Template','Restore-Stage','Open-Stage')
 $newDiary=New-Object MedicalRecoveryControl
 function Update-MedicalNavigation {}
 function Show-Fields {
  $panel.Controls.Clear();$script:controls=@()
  foreach($field in $script:fields){$control=New-Object MedicalRecoveryControl;$control.Text=[string]$field.Value;$script:controls+=,$control;$panel.Controls.Add($control)}
 }
 $diarySource=Join-Path $script:temp 'Исходный дневник с двумя полями.docx';New-UniversalTemplate $diarySource $script:fixtureSchema
 $diaryXml='<w:document xmlns:w="'+$script:ns+'"><w:body><w:p><w:r><w:t>Дневник наблюдения</w:t></w:r></w:p><w:p><w:sdt><w:sdtPr><w:id w:val="711"/><w:alias w:val="Жалобы дневника"/><w:tag w:val="diary-complaints"/><w:text/></w:sdtPr><w:sdtContent><w:r><w:t>Пустые жалобы оригинала</w:t></w:r></w:sdtContent></w:sdt></w:p><w:p><w:sdt><w:sdtPr><w:id w:val="712"/><w:alias w:val="Состояние дневника"/><w:tag w:val="diary-condition"/><w:text/></w:sdtPr><w:sdtContent><w:r><w:t>Пустое состояние оригинала</w:t></w:r></w:sdtContent></w:sdt></w:p><w:sectPr/></w:body></w:document>'
 $z=[IO.Compression.ZipFile]::Open($diarySource,[IO.Compression.ZipArchiveMode]::Update);try{$z.GetEntry('word/document.xml').Delete();Write-UniversalZipText $z 'word/document.xml' $diaryXml}finally{$z.Dispose()}
 $diaryHash=Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($diarySource));$savedDiary=@('Сохранённые жалобы пациента','Сохранённое состояние пациента')
 Set-RecoveryFixture $missing;$script:stage='diary';$script:diaryIndex=1;$script:stageData.diary_1=$savedDiary
 $script:stageTemplates.diary=Join-Path $script:temp 'Never present/Нет исходного дневника.docx';$script:source='';Open-Stage;$before=Get-RecoveryStateSignature
 Assert-Recovery ($script:fields.Count -eq 0 -and $script:controls.Count -eq 0 -and (@($script:stageData.diary_1) -join '|') -ceq ($savedDiary -join '|')) 'Missing diary placeholder has no live controls while retaining its saved positional answers'
 [Windows.Forms.OpenFileDialog]::Paths.Enqueue($diarySource);[Windows.Forms.OpenFileDialog]::Results.Enqueue('Cancel');$cancelDiary=Join-Path $script:temp 'Не создавать отменённый дневник.docx'
 $cancelThrown=$false;try{Export-CurrentStageDocument $cancelDiary}catch [OperationCanceledException]{$cancelThrown=$true}
 Assert-Recovery ($cancelThrown -and -not [IO.File]::Exists($cancelDiary) -and (Get-RecoveryStateSignature) -ceq $before) 'Canceling missing diary source selection preserves saved stage answers and creates no document'
 [Windows.Forms.OpenFileDialog]::Paths.Enqueue($diarySource);[Windows.Forms.OpenFileDialog]::Results.Enqueue('OK');[Windows.Forms.MessageBox]::Result='No'
 $cancelThrown=$false;try{Export-CurrentStageDocument $cancelDiary}catch [OperationCanceledException]{$cancelThrown=$true}
 Assert-Recovery ($cancelThrown -and -not [IO.File]::Exists($cancelDiary) -and (Get-RecoveryStateSignature) -ceq $before -and $script:fields.Count -eq 0) 'Declining legacy diary field-order confirmation preserves the stored template binding and all saved answers'
 [Windows.Forms.MessageBox]::Result='OK';$script:stageTemplates.diary=Join-Path $script:temp ('Old installation/'+[IO.Path]::GetFileName($diarySource));$script:source='';Open-Stage
 $diaryBefore=(@($script:stageData.diary_1) -join '|');$pickerBefore=[Windows.Forms.OpenFileDialog]::Calls;$relocatedDiaryOutput=Join-Path $script:temp 'Дневник после перемещения.docx'
 Export-CurrentStageDocument $relocatedDiaryOutput
 Assert-Recovery ($script:fields.Count -eq 2 -and $script:controls.Count -eq 2 -and $script:controls[0].Text -ceq $savedDiary[0] -and $script:controls[1].Text -ceq $savedDiary[1] -and [Windows.Forms.OpenFileDialog]::Calls -eq $pickerBefore) 'Automatic diary relocation reloads the real Word fields and restores both saved answers before export'
 $z=[IO.Compression.ZipFile]::OpenRead($relocatedDiaryOutput);try{$x=Get-XmlPart $z 'word/document.xml';$n=[Xml.XmlNamespaceManager]::new($x.NameTable);$n.AddNamespace('w',$script:ns);$body=(($x.SelectNodes('//w:t',$n)|ForEach-Object {$_.InnerText}) -join '|')}finally{$z.Dispose()}
 Assert-Recovery ($body.Contains($savedDiary[0]) -and $body.Contains($savedDiary[1]) -and -not $body.Contains('Пустые жалобы оригинала') -and -not $body.Contains('Пустое состояние оригинала')) 'Actual relocated diary DOCX contains the saved patient answers instead of source placeholders'
 Assert-Recovery ((@($script:stageData.diary_1) -join '|') -ceq $diaryBefore -and $script:universalValues.'identity-custom' -ceq 'Текущий Пациент' -and $script:universalDetails.'choice-custom' -ceq 'Уточнение сохранить') 'Relocated diary export retains its saved array and the initial form patient and clarification'
 # A file restored at its original path must also reload an empty stage view,
 # even when source already holds that identical path from the placeholder.
 $restoredPath=Join-Path $script:temp 'Restored later/Вновь появившийся дневник.docx';[void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($restoredPath))
 $script:stageTemplates.diary=$restoredPath;$script:source=$restoredPath;$script:fields=@();$script:controls=@();Open-Stage;Copy-Item -LiteralPath $diarySource -Destination $restoredPath
 $restoredDiaryOutput=Join-Path $script:temp 'Дневник после возврата оригинала.docx';Export-CurrentStageDocument $restoredDiaryOutput
 Assert-Recovery ($script:source -ceq $restoredPath -and $script:fields.Count -eq 2 -and $script:controls[0].Text -ceq $savedDiary[0] -and $script:controls[1].Text -ceq $savedDiary[1]) 'A source appearing at its stored path reloads empty stage controls even when the source path itself is unchanged'
 $z=[IO.Compression.ZipFile]::OpenRead($restoredDiaryOutput);try{$x=Get-XmlPart $z 'word/document.xml';$n=[Xml.XmlNamespaceManager]::new($x.NameTable);$n.AddNamespace('w',$script:ns);$body=(($x.SelectNodes('//w:t',$n)|ForEach-Object {$_.InnerText}) -join '|')}finally{$z.Dispose()}
 Assert-Recovery ($body.Contains($savedDiary[0]) -and $body.Contains($savedDiary[1]) -and (@($script:stageData.diary_1) -join '|') -ceq $diaryBefore) 'Actual DOCX export after restoring the original path displays both saved diary answers and retains stage state'
 Assert-Recovery ((Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($diarySource))) -ceq $diaryHash -and (Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($restoredPath))) -ceq $diaryHash) 'Both automatic diary recovery paths leave their original Word source files unchanged'
 # No helper in this test was promoted to global scope to make closures pass.
 foreach($name in @('Import-MedicalRecoveryTemplate','Get-MedicalGeneratedSchema','New-MedicalTemplateFile','Get-MedicalFormDisplayName')){Assert-Recovery (-not (Get-Item ('Function:global:'+$name) -ErrorAction SilentlyContinue)) ('Real captured recovery callbacks work while helper '+$name+' remains script-local')}

 if($script:recoveryFailures.Count){throw ($script:recoveryFailures -join "`r`n")}
 foreach($line in $script:recoveryPassLog){Write-Output $line}
 Write-Output ('PASS '+$script:checks+' recovery-callback checks')
}finally{Remove-Item -LiteralPath $script:temp -Recurse -Force}
