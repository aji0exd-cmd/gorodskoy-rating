using System;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.Versioning;
using System.Text;
using System.Threading;
using System.Windows.Forms;

[assembly: AssemblyTitle("Медицинский конструктор")]
[assembly: AssemblyDescription("Локальное настольное приложение для медицинских форм и документов")]
[assembly: AssemblyProduct("Медицинский конструктор")]
[assembly: AssemblyVersion("72.0.1.0")]
[assembly: AssemblyFileVersion("72.0.1.0")]
[assembly: AssemblyInformationalVersion("72.0.1")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyCopyright("")]
[assembly: TargetFramework(".NETFramework,Version=v4.7.2", FrameworkDisplayName=".NET Framework 4.7.2")]

namespace MedicalConstructor.Native {
 internal static class Program {
  private const string EngineName="System.Management.Automation, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35";
  [STAThread]
  private static int Main() {
   string root=AppDomain.CurrentDomain.BaseDirectory;
   string phase="initialization";
   object runspace=null;
   IDisposable pipeline=null;
   try {
    Application.EnableVisualStyles();
    Application.SetCompatibleTextRenderingDefault(false);
    root=Path.GetFullPath(root);
    Directory.SetCurrentDirectory(root);
    string entry=Path.Combine(root,"launcher.ps1");
    phase="application-files";
    if(!File.Exists(entry) || !File.Exists(Path.Combine(root,"constructor.ps1")))
     throw new FileNotFoundException("Application files are incomplete.");
    // Same process-only policy as the supplied VBS launcher. Machine/User policy still takes precedence.
    Environment.SetEnvironmentVariable("PSExecutionPolicyPreference","Bypass",EnvironmentVariableTarget.Process);
    phase="windows-powershell";
    Assembly engine=Assembly.Load(EngineName);
    Type factory=RequiredType(engine,"System.Management.Automation.Runspaces.RunspaceFactory");
    Type shellType=RequiredType(engine,"System.Management.Automation.PowerShell");
    runspace=RequiredMethod(factory,"CreateRunspace",BindingFlags.Public|BindingFlags.Static,Type.EmptyTypes).Invoke(null,null);
    if(runspace==null) throw new InvalidOperationException("Runspace is unavailable.");
    RequiredProperty(runspace.GetType(),"ApartmentState").SetValue(runspace,ApartmentState.STA,null);
    PropertyInfo threadOptions=RequiredProperty(runspace.GetType(),"ThreadOptions");
    threadOptions.SetValue(runspace,Enum.Parse(threadOptions.PropertyType,"UseCurrentThread"),null);
    phase="open-runspace";
    RequiredMethod(runspace.GetType(),"Open",BindingFlags.Public|BindingFlags.Instance,Type.EmptyTypes).Invoke(runspace,null);
    object shell=RequiredMethod(shellType,"Create",BindingFlags.Public|BindingFlags.Static,Type.EmptyTypes).Invoke(null,null);
    pipeline=shell as IDisposable;
    if(pipeline==null) throw new InvalidOperationException("PowerShell pipeline is unavailable.");
    RequiredProperty(shellType,"Runspace").SetValue(shell,runspace,null);
    // A literal absolute command path: no command text interpolation, shell execution or child process.
    RequiredMethod(shellType,"AddCommand",BindingFlags.Public|BindingFlags.Instance,new Type[]{typeof(string)}).Invoke(shell,new object[]{entry});
    phase="application";
    RequiredMethod(shellType,"Invoke",BindingFlags.Public|BindingFlags.Instance,Type.EmptyTypes).Invoke(shell,null);
    // A handled PowerShell error sets HadErrors even after the user recovers.
    // The launcher's explicit result preserves its useful diagnostic and avoids
    // a second error dialog. Only uncaught error-stream records fail below.
    object session=RequiredProperty(runspace.GetType(),"SessionStateProxy").GetValue(runspace,null);
    object startupFailure=RequiredMethod(session.GetType(),"GetVariable",BindingFlags.Public|BindingFlags.Instance,new Type[]{typeof(string)}).Invoke(session,new object[]{"MedicalConstructorStartupFailureV72"});
    if(startupFailure is bool && (bool)startupFailure) return 1;
    object streams=RequiredProperty(shellType,"Streams").GetValue(shell,null);
    object errors=RequiredProperty(streams.GetType(),"Error").GetValue(streams,null);
    if((int)RequiredProperty(errors.GetType(),"Count").GetValue(errors,null)>0)
     throw new InvalidOperationException("Application pipeline reported an uncaught error.");
    return 0;
   } catch(Exception error) {
    string incident=Guid.NewGuid().ToString("N",CultureInfo.InvariantCulture);
    WriteSafeFailure(root,incident,phase,error.GetType().FullName);
    try {
     MessageBox.Show("Не удалось запустить медицинский конструктор.\r\nПроверьте наличие файлов программы, Windows PowerShell 5.1 и .NET Framework 4.7.2 или новее.\r\n\r\nКод ошибки: "+incident+"\r\nСведения без содержимого документов сохранены в startup_error.txt.","Медицинский конструктор",MessageBoxButtons.OK,MessageBoxIcon.Error);
    } catch { }
    return 1;
   } finally {
    try { if(pipeline!=null) pipeline.Dispose(); } catch { }
    try { IDisposable disposable=runspace as IDisposable; if(disposable!=null) disposable.Dispose(); } catch { }
   }
  }
  private static Type RequiredType(Assembly assembly,string name) {
   Type result=assembly.GetType(name,false);
   if(result==null) throw new TypeLoadException("Required Windows PowerShell type is unavailable.");
   return result;
  }
  private static PropertyInfo RequiredProperty(Type type,string name) {
   PropertyInfo result=type.GetProperty(name,BindingFlags.Public|BindingFlags.Instance);
   if(result==null) throw new MissingMemberException("Required Windows PowerShell property is unavailable.");
   return result;
  }
  private static MethodInfo RequiredMethod(Type type,string name,BindingFlags flags,Type[] parameterTypes) {
   foreach(MethodInfo method in type.GetMethods(flags)) {
    if(method.Name!=name || method.IsGenericMethodDefinition || method.ContainsGenericParameters) continue;
    ParameterInfo[] parameters=method.GetParameters();
    if(parameters.Length!=parameterTypes.Length) continue;
    bool matches=true;
    for(int i=0;i<parameters.Length;i++) if(parameters[i].ParameterType!=parameterTypes[i]) {matches=false;break;}
    if(matches) return method;
   }
   throw new MissingMethodException("Required Windows PowerShell method is unavailable.");
  }
  private static void WriteSafeFailure(string root,string incident,string phase,string type) {
   try {
    string message="Native application startup failed.\r\nIncident: "+incident+"\r\nPhase: "+phase+"\r\nType: "+type+"\r\nNo passwords, paths, document content or exception messages are included.\r\n";
    File.WriteAllText(Path.Combine(root,"startup_error.txt"),message,new UTF8Encoding(true));
   } catch { }
  }
 }
}
