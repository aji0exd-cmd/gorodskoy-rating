﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v72'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Startup([bool]$Value,[string]$Message){if(-not $Value){throw $Message};$script:checks++;Write-Output ('PASS '+$Message)}
. (Join-Path $Project 'startup-diagnostics-v72.ps1')
$temporary=Join-Path ([IO.Path]::GetTempPath()) ('medical-startup-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temporary)
$root=Join-Path $temporary 'Секретное имя пациента';[void][IO.Directory]::CreateDirectory($root)
$outside=Join-Path $temporary 'outside';[void][IO.Directory]::CreateDirectory($outside)
$oldDirectory=[Environment]::CurrentDirectory
if(-not ('MedicalStartupMessageProbe' -as [type])){
 Add-Type -TypeDefinition @'
public static class MedicalStartupMessageProbe {public static string Message;public static string Title;public static int Count;public static void Reset(){Message=Title=null;Count=0;}}
namespace System.Windows.Forms {
 public static class MessageBox {public static void Show(string message,string title,string buttons,string icon){MedicalStartupMessageProbe.Message=message;MedicalStartupMessageProbe.Title=title;MedicalStartupMessageProbe.Count++;}}
 public static class Application {public static void SetUnhandledExceptionMode(string value){}}
}
'@
}
function Invoke-RealStartup([string]$Directory){
 $runspace=[runspacefactory]::CreateRunspace();$runspace.ThreadOptions='UseCurrentThread';$runspace.Open()
 $powershell=[powershell]::Create();$powershell.Runspace=$runspace
 try{
  # Only the unavailable Windows assembly load/dialog is adapted. Production
  # launcher/helper, real cmdlet binding, errors, scripts and pipeline remain real.
  [void]$powershell.AddScript('function Add-Type { param([string]$AssemblyName) if($AssemblyName -ne "System.Windows.Forms"){throw "Unexpected platform assembly"} }')
  $null=$powershell.Invoke();$powershell.Commands.Clear();$powershell.Streams.Error.Clear()
  [MedicalStartupMessageProbe]::Reset()
  [void]$powershell.AddCommand((Join-Path $Directory 'launcher.ps1'))
  $output=@($powershell.Invoke())
  return [pscustomobject]@{Failed=$runspace.SessionStateProxy.GetVariable('MedicalConstructorStartupFailureV72');HadErrors=$powershell.HadErrors;UncaughtErrors=$powershell.Streams.Error.Count;Output=$output;Messages=[MedicalStartupMessageProbe]::Count}
 }finally{$powershell.Dispose();$runspace.Dispose()}
}
try{
 foreach($name in @('launcher.ps1','startup-diagnostics-v72.ps1','core-guard-v71.ps1')){[IO.File]::Copy((Join-Path $Project $name),(Join-Path $root $name))}
 # Reproduce the exact failure class from v72 without mocking Add-Type binding.
 # Get-Date has the same real NamedParameterNotFound binding behavior in PS5.1/7.
 [IO.File]::WriteAllText((Join-Path $root 'local-ai-v72.ps1'),"`n`nGet-Date -CompilerOptions '/langversion:5'",[Text.UTF8Encoding]::new($true))
 [IO.File]::WriteAllText((Join-Path $root 'constructor.ps1'),". (Join-Path `$PSScriptRoot 'local-ai-v72.ps1')",[Text.UTF8Encoding]::new($true))
 $run=Invoke-RealStartup $root
 Assert-Startup ($run.Failed -eq $true -and $run.Messages -eq 1) 'Real production launcher catches a parameter-binding startup failure and reports it once'
 Assert-Startup ($run.HadErrors -and $run.UncaughtErrors -eq 0) 'Real PowerShell reproduces HadErrors true with no uncaught stream errors after catch'
 $logPath=Join-Path $root 'startup_error.txt';$raw=[IO.File]::ReadAllText($logPath);$log=$raw|ConvertFrom-Json
 Assert-Startup ($log.Component -ceq 'local-ai-v72.ps1' -and $log.Line -eq 3) 'Diagnostic identifies actual failing module and line through nested script/pipeline boundaries'
 Assert-Startup ($log.ErrorId -ceq 'NamedParameterNotFound') 'Diagnostic identifies the real cmdlet parameter-binding error without raw messages'
 Assert-Startup ($log.ExceptionType -ceq 'System.Management.Automation.ParameterBindingException') 'Diagnostic preserves a safe useful exception type'
 Assert-Startup ($log.Category -ceq 'InvalidArgument' -and $log.Version -ceq '72.0.1') 'Diagnostic records a known error category and fixed startup-fix version'
 Assert-Startup ($log.Incident -cmatch '^[a-f0-9]{32}$') 'Diagnostic carries a valid incident identifier'
 Assert-Startup (@($log.PSObject.Properties).Count -eq 8) 'Diagnostic emits only the eight fixed allowed fields'
 Assert-Startup ($raw -notmatch 'Секретное|CompilerOptions|langversion|Get-Date|PSScriptRoot|startup-diagnostics') 'Diagnostic excludes folder names, source lines, parameter values and command text'
 Assert-Startup ([IO.File]::ReadAllBytes($logPath)[0] -eq 0xef -and $raw.Length -lt 4096) 'Diagnostic is bounded UTF-8 with BOM for Windows text editors'
 Assert-Startup ([MedicalStartupMessageProbe]::Title -ceq 'Медицинский конструктор — ошибка запуска' -and [MedicalStartupMessageProbe]::Message.Contains($log.Incident)) 'Startup dialog is Russian and shows the matching incident code'
 Assert-Startup ([MedicalStartupMessageProbe]::Message -notmatch 'Секретное|CompilerOptions|langversion|Get-Date') 'Startup dialog excludes sensitive exception and source data'
 Assert-Startup (@([IO.Directory]::GetFiles($root,'.startup-*.tmp')).Count -eq 0) 'Atomic diagnostic write removes all temporary files'
 [IO.File]::WriteAllText((Join-Path $root 'constructor.ps1'),"throw 'SECRET_PATIENT_TARGET_NAME_123456'",[Text.UTF8Encoding]::new($true))
 $run=Invoke-RealStartup $root;$raw=[IO.File]::ReadAllText($logPath);$log=$raw|ConvertFrom-Json
 Assert-Startup ($run.Failed -eq $true -and $log.Component -ceq 'constructor.ps1' -and $log.Line -eq 1) 'Thrown startup error retains a trusted source component and line'
 Assert-Startup ($log.ErrorId -cin @('Other','RuntimeException') -and $raw -notmatch 'SECRET_PATIENT|TARGET_NAME|throw|Секретное') 'Custom FullyQualifiedErrorId and exception text cannot leak patient data'
 # A script named after a patient must never become a diagnostic component.
 $unknown=Join-Path $root 'SECRET_PATIENT.ps1';[IO.File]::WriteAllText($unknown,"throw 'SECRET_PATIENT'",[Text.UTF8Encoding]::new($true))
 try{& $unknown}catch{$unknownError=$_}
 $safe=Get-MedicalStartupDiagnostic $unknownError $root 'SECRET_PATIENT'
 Assert-Startup ($safe.Component -ceq 'unknown' -and $safe.Line -eq 0) 'Only exact shipped component names are accepted'
 Assert-Startup ($safe.Incident -cmatch '^[a-f0-9]{32}$') 'Untrusted incident identifier is replaced with a fresh safe value'
 $external=Join-Path $outside 'constructor.ps1';[IO.File]::WriteAllText($external,"throw 'SECRET_PATIENT'",[Text.UTF8Encoding]::new($true))
 try{& $external}catch{$externalError=$_}
 $safe=Get-MedicalStartupDiagnostic $externalError $root
 Assert-Startup ($safe.Component -ceq 'unknown' -and $safe.Line -eq 0) 'Same basename outside the program root is not trusted'
 $spoof=[Management.Automation.ErrorRecord]::new([InvalidOperationException]::new('SECRET_PATIENT'),'NamedParameterNotFound,SECRET_PATIENT',[Management.Automation.ErrorCategory]::InvalidArgument,'SECRET_PATIENT')
 $safe=Get-MedicalStartupDiagnostic $spoof $root
 Assert-Startup ($safe.ErrorId -ceq 'NamedParameterNotFound' -and ($safe|ConvertTo-Json) -notmatch 'SECRET_PATIENT') 'Only exact known ErrorId prefix survives; custom suffix, target and message are discarded'
 $unknownId=[Management.Automation.ErrorRecord]::new([InvalidOperationException]::new('SECRET_PATIENT'),'SECRET_PATIENT',[Management.Automation.ErrorCategory]::InvalidArgument,'SECRET_PATIENT')
 $safe=Get-MedicalStartupDiagnostic $unknownId $root
 Assert-Startup ($safe.ErrorId -ceq 'Other' -and ($safe|ConvertTo-Json) -notmatch 'SECRET_PATIENT') 'Unknown alphanumeric ErrorId is excluded instead of accepted by a permissive regex'
 $safe=Get-MedicalStartupDiagnostic $null $root
 Assert-Startup ($safe.ErrorId -ceq 'Other' -and $safe.ExceptionType -ceq 'System.Exception' -and $safe.Component -ceq 'unknown') 'Missing error record still produces a useful fixed safe diagnostic'
 # A handled error during normal application operation must not become a startup failure.
 [IO.File]::WriteAllText((Join-Path $root 'constructor.ps1'),"try { Get-Item -LiteralPath (Join-Path `$PSScriptRoot 'missing-file') -ErrorAction Stop } catch { }; 'normal-close'",[Text.UTF8Encoding]::new($true))
 $run=Invoke-RealStartup $root
 Assert-Startup (-not $run.Failed -and $run.UncaughtErrors -eq 0 -and $run.Messages -eq 0) 'Real hosted pipeline handles a normal application error without a startup error dialog'
 Assert-Startup (-not [IO.File]::Exists($logPath)) 'Successful fresh start removes obsolete startup diagnostics'
 # A broken helper should not prevent the launcher from reporting a controlled failure.
 [IO.File]::Delete((Join-Path $root 'startup-diagnostics-v72.ps1'))
 $run=Invoke-RealStartup $root;$raw=[IO.File]::ReadAllText($logPath)
 Assert-Startup ($run.Failed -and $run.Messages -eq 1 -and $raw -match 'Incident code: [a-f0-9]{32}') 'Missing diagnostics helper falls back to an incident-only log and controlled dialog'
 Assert-Startup ($raw -notmatch 'Секретное|SECRET_PATIENT|missing-file') 'Fallback diagnostic also excludes paths and document data'
 Write-Output ('TOTAL '+$script:checks+' checks passed; production launcher and actual PowerShell ErrorRecord/pipeline verified with only Windows assembly/dialog adapters.')
}finally{
 [Environment]::CurrentDirectory=$oldDirectory
 if([IO.Directory]::Exists($temporary)){[IO.Directory]::Delete($temporary,$true)}
}
