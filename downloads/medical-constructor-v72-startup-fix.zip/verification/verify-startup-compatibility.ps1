﻿param(
 [string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v72'),
 [string]$ReferenceAssemblies=$env:MEDICAL_NET472_REFERENCE_ROOT,
 [string]$RoslynDirectory=$PSHOME
)
$ErrorActionPreference='Stop';$script:startupCompatibilityChecks=0
function Assert-StartupCompatibility([bool]$Value,[string]$Message){if(-not $Value){throw ('FAILED: '+$Message)};$script:startupCompatibilityChecks++;Write-Output ('PASS '+$Message)}
# The verification host uses PowerShell 7/Roslyn. The application itself targets
# Windows PowerShell 5.1. A strict parameter binder below models its Add-Type
# FromSource parameter surface; this does not claim a native Windows execution.
$module=Join-Path $Project 'local-ai-v72.ps1'
$source=[IO.File]::ReadAllText($module)
Assert-StartupCompatibility (-not ('MedicalLocalAiTransportV72' -as [type])) 'Fresh process starts before the application transport has been compiled'
$script:compatibilityNativeAddType=Get-Command Add-Type -CommandType Cmdlet
$script:compatibilityCompileCalls=0
$work=Join-Path ([IO.Path]::GetTempPath()) ('medical-startup-compatibility-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($work)
$server=$null
try{
 # These are the documented Windows PowerShell 5.1 FromSource parameters plus
 # common parameters supplied by CmdletBinding. CompilerOptions is deliberately
 # absent. Compilation uses the real host cmdlet after parameter binding passes.
 function Add-Type {
  [CmdletBinding()]
  param(
   [Parameter(Mandatory=$true,Position=0)][string]$TypeDefinition,
   [object]$CodeDomProvider,[object]$CompilerParameters,[string]$Language,
   [string[]]$ReferencedAssemblies,[string]$OutputAssembly,[string]$OutputType,
   [switch]$PassThru,[switch]$IgnoreWarnings
  )
  $script:compatibilityCompileCalls++
  if($PSBoundParameters.ContainsKey('CodeDomProvider') -or $PSBoundParameters.ContainsKey('CompilerParameters')){throw 'This regression fixture does not adapt custom CodeDOM compilers.'}
  & $script:compatibilityNativeAddType @PSBoundParameters
 }
 # Reintroduce exactly the released defect and prove the binder rejects it
 # before the transport is compiled. This is an executable red/green regression,
 # not just an assertion that a source string has disappeared.
 if($source -match 'Add-Type\s+-CompilerOptions'){$old=$source}else{$old=[regex]::Replace($source,'Add-Type\s+-TypeDefinition',"Add-Type -CompilerOptions '/langversion:5' -TypeDefinition",1)}
 Assert-StartupCompatibility ($old -match "Add-Type\s+-CompilerOptions\s+'/langversion:5'") 'Regression fixture recreates the former Add-Type invocation from actual production source' 
 $badPath=Join-Path $work 'legacy-compiler-options.ps1';[IO.File]::WriteAllText($badPath,$old,[Text.UTF8Encoding]::new($true))
 $bindingError=$null
 try{. $badPath}catch{$bindingError=$_}
 Assert-StartupCompatibility ($null -ne $bindingError -and $bindingError.Exception -is [Management.Automation.ParameterBindingException] -and $bindingError.Exception.ParameterName -ceq 'CompilerOptions') 'Legacy Add-Type invocation fails the Windows PowerShell 5.1 shaped parameter binder'
 Assert-StartupCompatibility ($script:compatibilityCompileCalls -eq 0 -and -not ('MedicalLocalAiTransportV72' -as [type])) 'Unsupported parameter stops startup before compiler or transport side effects'
 . $module
 Assert-StartupCompatibility ($script:compatibilityCompileCalls -eq 1 -and $null -ne ('MedicalLocalAiTransportV72' -as [type])) 'Actual corrected AI module binds the legacy parameter surface and really compiles its transport'
 Assert-StartupCompatibility ($null -ne (Get-Command Initialize-MedicalLocalAi -CommandType Function -ErrorAction Stop)) 'Actual import exposes local AI initialization after successful compilation'
 . $module
 Assert-StartupCompatibility ($script:compatibilityCompileCalls -eq 1) 'Repeated import uses the existing transport instead of recompiling its type'
 foreach($entry in @(@('top-menu-v72.ps1','New-MedicalMainMenu'),@('open-document-v72.ps1','Open-MedicalDocumentPath'),@('model-acquisition-v72.ps1','Install-MedicalAiModel'),@('local-ai-ui-v72.ps1','Show-MedicalAiSettings'))){
  . (Join-Path $Project $entry[0])
  Assert-StartupCompatibility ($null -ne (Get-Command $entry[1] -CommandType Function -ErrorAction Stop)) ('Actual pre-login module imports successfully: '+$entry[0])
 }
 Assert-StartupCompatibility ($script:compatibilityCompileCalls -eq 1) 'New pre-login module imports perform no additional compilation or model startup'
 Remove-Item Function:\Add-Type
 & $script:compatibilityNativeAddType -TypeDefinition @'
using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
public sealed class StartupCompatibilityHttpServer:IDisposable {
 private readonly HttpListener listener;
 private readonly Thread worker;
 public string Endpoint,Method,Path,Payload;
 public long DeclaredLength=-1;
 public StartupCompatibilityHttpServer(){
  var socket=new System.Net.Sockets.TcpListener(IPAddress.Loopback,0);socket.Start();int port=((IPEndPoint)socket.LocalEndpoint).Port;socket.Stop();
  Endpoint="http://127.0.0.1:"+port;listener=new HttpListener();listener.Prefixes.Add(Endpoint+"/");listener.Start();worker=new Thread(Run);worker.IsBackground=true;worker.Start();
 }
 private void Run(){try{var context=listener.GetContext();Method=context.Request.HttpMethod;Path=context.Request.Url.AbsolutePath;DeclaredLength=context.Request.ContentLength64;using(var reader=new StreamReader(context.Request.InputStream))Payload=reader.ReadToEnd();byte[] bytes=Encoding.UTF8.GetBytes("{\"status\":\"ok\"}");context.Response.StatusCode=200;context.Response.ContentType="application/json";context.Response.ContentLength64=bytes.Length;context.Response.OutputStream.Write(bytes,0,bytes.Length);context.Response.Close();}catch{}}
 public void Dispose(){try{listener.Stop();listener.Close();}catch{}worker.Join(2000);}
}
'@
 $server=New-Object StartupCompatibilityHttpServer
 $reply=[MedicalLocalAiTransportV72]::Execute($server.Endpoint+'/health','GET',$null,'',3000,4096,[Threading.CancellationToken]::None)|ConvertFrom-Json
 Assert-StartupCompatibility ($reply.status -ceq 'ok') 'Transport compiled by the legacy-shaped import completes a real local HTTP health request'
 Assert-StartupCompatibility ($server.Method -ceq 'GET' -and $server.Path -ceq '/health') 'Compiled production transport sends the expected GET route'
 Assert-StartupCompatibility ($server.Payload -ceq '' -and $server.DeclaredLength -le 0) 'Health GET has no body after PowerShell null-string argument conversion'
 $server.Dispose();$server=$null
 if([string]::IsNullOrWhiteSpace($ReferenceAssemblies)){
  if([IO.File]::Exists('/tmp/net472-ref/build/.NETFramework/v4.7.2/mscorlib.dll')){$ReferenceAssemblies='/tmp/net472-ref/build/.NETFramework/v4.7.2'}
  elseif(${env:ProgramFiles(x86)}){$ReferenceAssemblies=Join-Path ${env:ProgramFiles(x86)} 'Reference Assemblies/Microsoft/Framework/.NETFramework/v4.7.2'}
 }
 $refs=@('mscorlib.dll','System.dll','System.Core.dll','System.Windows.Forms.dll','System.Drawing.dll','System.Net.Http.dll'|ForEach-Object{Join-Path $ReferenceAssemblies $_})
 foreach($path in $refs){Assert-StartupCompatibility ([IO.File]::Exists($path)) ('Official desktop reference is present: '+[IO.Path]::GetFileName($path))}
 & $script:compatibilityNativeAddType -Path (Join-Path $RoslynDirectory 'Microsoft.CodeAnalysis.dll')
 & $script:compatibilityNativeAddType -Path (Join-Path $RoslynDirectory 'Microsoft.CodeAnalysis.CSharp.dll')
 & $script:compatibilityNativeAddType -CompilerOptions '/nowarn:1701' -ReferencedAssemblies @((Join-Path $RoslynDirectory 'Microsoft.CodeAnalysis.dll'),(Join-Path $RoslynDirectory 'Microsoft.CodeAnalysis.CSharp.dll'),[Collections.Immutable.ImmutableArray].Assembly.Location,(Join-Path $PSHOME 'ref/System.Runtime.dll'),(Join-Path $PSHOME 'ref/System.Collections.dll'),(Join-Path $PSHOME 'ref/System.Linq.dll')) -TypeDefinition @'
using System;
using System.IO;
using System.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
public static class StartupDesktopCompiler {
 public static string[] Check(string code,string[] refs,string name){
  var syntax=CSharpSyntaxTree.ParseText(code,new CSharpParseOptions(LanguageVersion.CSharp5),name);
  var compilation=CSharpCompilation.Create(name,new SyntaxTree[]{syntax},refs.Select(x=>(MetadataReference)MetadataReference.CreateFromFile(x)),new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));
  return compilation.GetDiagnostics().Where(x=>x.Severity==DiagnosticSeverity.Error).Select(x=>x.ToString()).ToArray();
 }
}
'@
 $blocksChecked=0
 foreach($file in @('local-ai-v72.ps1','top-menu-v72.ps1','ui-v57.ps1','constructor.ps1','accounts-v71.ps1','account-workspace-v71.ps1','template-format-ui-v62.ps1')){
  $text=[IO.File]::ReadAllText((Join-Path $Project $file));$blocks=[regex]::Matches($text,"(?s)-TypeDefinition @'\r?\n(.*?)\r?\n'@")
  Assert-StartupCompatibility ($blocks.Count -eq 1) ('Actual production C# block is located: '+$file)
  foreach($block in $blocks){
   $errors=[StartupDesktopCompiler]::Check($block.Groups[1].Value,$refs,$file.Replace('.','_'))
   if($errors.Count){throw ($errors -join "`n")}
   $blocksChecked++;Assert-StartupCompatibility ($errors.Count -eq 0) ('Actual C# compiles as C# 5 against .NET Framework 4.7.2: '+$file)
  }
 }
 Assert-StartupCompatibility ($blocksChecked -eq 7) 'All seven startup and editor native helper blocks pass the desktop compiler check'
 Write-Output ('TOTAL '+$script:startupCompatibilityChecks+' checks passed. Windows PowerShell 5.1 shaped parameter binding, real transport compilation/local HTTP and C# 5/.NET Framework 4.7.2 references verified; native Windows execution was not run.')
}finally{
 if(Test-Path Function:\Add-Type){Remove-Item Function:\Add-Type}
 if($server){$server.Dispose()}
 if([IO.Directory]::Exists($work)){[IO.Directory]::Delete($work,$true)}
}
