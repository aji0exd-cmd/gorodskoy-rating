﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v63'))
$ErrorActionPreference='Stop'
$formatUiTally=@{Checks=0}
function Assert-FormatUi([bool]$condition,[string]$message){if(-not $condition){throw $message};$formatUiTally.Checks++;Write-Output ('PASS '+$message)}
$module=Join-Path $Project 'template-format-ui-v62.ps1'
$source=[IO.File]::ReadAllText($module)
$errors=$null;$tokens=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($module,[ref]$tokens,[ref]$errors)
Assert-FormatUi ($errors.Count -eq 0) 'PowerShell formatting controls parse without errors'
Assert-FormatUi ([IO.File]::ReadAllBytes($module)[0] -eq 239) 'UTF-8 BOM retained for Windows PowerShell 5.1'
$cpp=[regex]::Match($source,"(?s)-TypeDefinition @'\r?\n(.*?)\r?\n'@").Groups[1].Value
Assert-FormatUi (-not [string]::IsNullOrWhiteSpace($cpp)) 'Native rich text editor and ruler source available'
$work=Join-Path ([IO.Path]::GetTempPath()) ('medical-format-ui-tests-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($work)
try{
 if($env:OS -eq 'Windows_NT'){
  Add-Type -TypeDefinition $cpp -ReferencedAssemblies 'System.Windows.Forms','System.Drawing' -ErrorAction Stop
  Assert-FormatUi ($null -ne ('MedicalWordParagraphEditor' -as [type])) 'Windows paragraph editor compiles'
 }else{
  $runtimeRef=Join-Path $PSHOME 'ref';$desktopRef='/tmp/windowsdesktop-ref/ref/net8.0'
  if(-not (Test-Path $desktopRef)){throw 'Install official WindowsDesktop.App.Ref before running C# compilation on Linux.'}
  $references=@(Get-ChildItem (Join-Path $runtimeRef '*.dll')|ForEach-Object FullName)+@(Get-ChildItem (Join-Path $desktopRef '*.dll')|ForEach-Object FullName)
  $assembly=Join-Path $work 'native-format-ui.dll'
  Add-Type -TypeDefinition $cpp -ReferencedAssemblies $references -OutputAssembly $assembly -ErrorAction Stop
  Assert-FormatUi ((Get-Item $assembly).Length -gt 0) 'Windows paragraph editor and ruler compile against official reference assemblies'
  $math=[regex]::Match($cpp,'(?s)public static class MedicalWordLayoutMath \{(.*?)\r?\n\}\r?\npublic class').Value -replace '\r?\npublic class$',''
  Add-Type -TypeDefinition ('using System;'+$math) -ErrorAction Stop
 }
 foreach($case in @(@(0,96,0),@(2.54,96,96),@(2.54,144,144),@(17,96,643),@(-1,96,-38))){Assert-FormatUi ([MedicalWordLayoutMath]::CmToPixels($case[0],$case[1]) -eq $case[2]) ('Ruler geometry: '+$case[0]+' cm at '+$case[1]+' DPI')}
 foreach($case in @(@(2.54,1440),@(1.27,720),@(-1.27,-720),@(0,0))){Assert-FormatUi ([MedicalWordLayoutMath]::CmToTwips($case[0]) -eq $case[1]) ('Paragraph indent conversion: '+$case[0]+' cm')}
 foreach($case in @(@(12,240),@(6,120),@(12.5,250))){Assert-FormatUi ([MedicalWordLayoutMath]::PointsToTwips($case[0]) -eq $case[1]) ('Paragraph spacing conversion: '+$case[0]+' pt')}
 foreach($case in @(@('left',1),@('center',3),@('right',2),@('both',4))){Assert-FormatUi ([MedicalWordLayoutMath]::AlignmentCode($case[0]) -eq $case[1]) ('Native rich edit alignment: '+$case[0])}
 Assert-FormatUi ([MedicalWordLayoutMath]::Clamp(-1,0,17) -eq 0) 'Ruler drag clamps before text area'
 Assert-FormatUi ([MedicalWordLayoutMath]::Clamp(18,0,17) -eq 17) 'Ruler drag clamps after text area'
 Assert-FormatUi ([MedicalWordLayoutMath]::Clamp(3.5,0,17) -eq 3.5) 'Ruler drag preserves interior position'
 $structure=[regex]::Match($cpp,'(?s)\[StructLayout\(LayoutKind.Sequential\)\]\s+private struct ParagraphFormat \{.*?\n \}').Value.Replace('private struct','public struct')
 if(-not $structure){throw 'PARAFORMAT2 structure missing'}
 Add-Type -TypeDefinition ('using System;using System.Runtime.InteropServices;public static class MedicalNativeFormatProbe {'+$structure+' public static int Size(){return Marshal.SizeOf(typeof(ParagraphFormat));}}')
 Assert-FormatUi ([MedicalNativeFormatProbe]::Size() -eq 188) 'PARAFORMAT2 layout matches Windows native 188-byte structure'
 Assert-FormatUi ($cpp.Contains('format.dwMask=0x000001CF')) 'Paragraph native mask covers indents, alignment, and spacing'
 Assert-FormatUi ($cpp.Contains('format.dxStartIndent=MedicalWordLayoutMath.CmToTwips(left+first)')) 'Native first-line position includes paragraph left indent'
 Assert-FormatUi ($cpp.Contains('format.dxOffset=-MedicalWordLayoutMath.CmToTwips(first)')) 'Native hanging indent matches Word first-line offset'
 Assert-FormatUi ($cpp.Contains('format.bLineSpacingRule=4') -and $cpp.Contains('format.bLineSpacingRule=3')) 'Imported exact and minimum line spacing retained in visual renderer'
 Assert-FormatUi ($cpp.Contains('Clipboard.GetText(TextDataFormat.UnicodeText)')) 'Keyboard paste inserts plain text to avoid unsaved clipboard font formatting'
 Assert-FormatUi ($source.Contains('ContentWidthCm') -and $source.Contains('VerticalScrollBarWidth')) 'Ruler width reserves native vertical scrollbar outside text area'
 Assert-FormatUi ($source.Contains('$viewport.AutoScroll=$false')) 'Formatting viewport uses available space without an extra scrolling canvas'
 $resizeMatch=[regex]::Match($source,'(?s)\$resize=(\{.*?\}\.GetNewClosure\(\))')
 Assert-FormatUi $resizeMatch.Success 'Real viewport resize callback available for responsive-width regression'
 if($env:OS -ne 'Windows_NT'){Add-Type -TypeDefinition 'namespace System.Windows.Forms {public static class SystemInformation {public static int VerticalScrollBarWidth=17;}}'}
 Assert-FormatUi ($cpp.Contains('RichTextBoxScrollBars.ForcedVertical') -and $cpp.Contains('rectangle.Right=Math.Max(7,ClientSize.Width-6)')) 'Native client width excludes reserved scrollbar exactly once'
 Assert-FormatUi ($source.Contains('$pageOriginal[$key]')) 'Page dialog updates only parameters changed by user'
 $fontValidated=[regex]::Match($source,'(?s)\$font.Add_Validated\((\{.*?\}\.GetNewClosure\(\))\)')
 Assert-FormatUi $fontValidated.Success 'Font validation callback available for unchanged-style regression'
 $fontWriteCount=@{Value=0};$font=[pscustomobject]@{Text='Times New Roman'};$local=@{Format=[pscustomobject]@{FontName='Times New Roman'}}
 $apply={$fontWriteCount.Value++}.GetNewClosure()
 $validateFont=. ([scriptblock]::Create($fontValidated.Groups[1].Value))
 & $validateFont
 Assert-FormatUi ($fontWriteCount.Value -eq 0) 'Focusing and leaving font selector preserves mixed fonts when no choice changes'
 $font.Text='Arial';& $validateFont
 Assert-FormatUi ($fontWriteCount.Value -eq 1) 'Changed font selector sends explicit font update'
 $applyMatch=[regex]::Match($source,'(?s)\$apply=(\{param\(\$delta\).*?\}\s*\.GetNewClosure\(\))')
 Assert-FormatUi $applyMatch.Success 'Real UI formatting callback can be extracted for private-scope regression'
 $factory=Join-Path $work 'private-constructor-scope.ps1'
 @'
param($Project,$ApplyExpression,$ResizeExpression)
$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
. (Join-Path $Project 'universal.ps1')
. (Join-Path $Project 'forms-v59.ps1')
. (Join-Path $Project 'template-editor-v59.ps1')
. (Join-Path $Project 'template-editor-operations-v61.ps1')
. (Join-Path $Project 'template-format-v62.ps1')
$model=Read-MedicalTemplateModel (Join-Path $Project 'Шаблон первичного осмотра.docx')
$paragraph=@($model.Paragraphs | Where-Object {$_.Editable})[0]
$commands=@{'Set-MedicalParagraphFormat'=(Get-Command Set-MedicalParagraphFormat -CommandType Function);'Get-MedicalParagraphFormat'=(Get-Command Get-MedicalParagraphFormat -CommandType Function)}
$local=@{Loading=$false};$state=@{Loading=$false;Model=$model;Paragraph=$paragraph};$render=@{Calls=0}
$load={$render.Calls++}.GetNewClosure()
$owner=$null
function New-PrivateFormatCallback($ApplyExpression,$state,$commands,$local,$load){return (. ([scriptblock]::Create($ApplyExpression)))}
$apply=New-PrivateFormatCallback $ApplyExpression $state $commands $local $load
$context=[pscustomobject]@{Apply=$apply;Local=$local;State=$state;Render=$render;Commands=$commands;Before=(Get-MedicalParagraphFormat $model $paragraph.Id);Text=$paragraph.Text}
 & $context.Apply @{Alignment='both'}
 $after=& $context.Commands['Get-MedicalParagraphFormat'] $context.State.Model $context.State.Paragraph.Id
 Assert-FormatUi ($after.Alignment -eq 'both') 'Actual UI callback resolves script-private helpers after component factory returns while constructor scope remains active'
 Assert-FormatUi ($context.Render.Calls -eq 1) 'Formatting callback refreshes paragraph display after successful update'
 Assert-FormatUi ($after.FontName -eq $context.Before.FontName -and $after.FontSize -eq $context.Before.FontSize) 'Alignment callback preserves existing font and size'
 Assert-FormatUi ($context.State.Paragraph.Text -ceq $context.Text) 'Formatting callback preserves paragraph text and marker positions'
 $context.Local.Loading=$true;& $context.Apply @{Alignment='center'};$context.Local.Loading=$false
 $after=& $context.Commands['Get-MedicalParagraphFormat'] $context.State.Model $context.State.Paragraph.Id
 Assert-FormatUi ($after.Alignment -eq 'both' -and $context.Render.Calls -eq 1) 'Formatting load events do not write back displayed values'
 $context.State.Loading=$true;& $context.Apply @{Alignment='left'};$context.State.Loading=$false
 $after=& $context.Commands['Get-MedicalParagraphFormat'] $context.State.Model $context.State.Paragraph.Id
 Assert-FormatUi ($after.Alignment -eq 'both' -and $context.Render.Calls -eq 1) 'Paragraph-switch events do not format stale selection'
 $context.State.Paragraph.Editable=$false;& $context.Apply @{Alignment='right'}
 $after=& $context.Commands['Get-MedicalParagraphFormat'] $context.State.Model $context.State.Paragraph.Id
 Assert-FormatUi ($after.Alignment -eq 'both') 'Read-only paragraph rejects formatting callback without mutation'
 $context.State.Paragraph.Editable=$true
 & $context.Apply @{FirstLineCm=-.25;LeftIndentCm=.75;RightIndentCm=.5}
 $after=& $context.Commands['Get-MedicalParagraphFormat'] $context.State.Model $context.State.Paragraph.Id
 Assert-FormatUi ([Math]::Abs($after.FirstLineCm+.25) -lt .003) 'Actual ruler callback saves hanging first line'
 Assert-FormatUi ([Math]::Abs($after.LeftIndentCm-.75) -lt .003 -and [Math]::Abs($after.RightIndentCm-.5) -lt .003) 'Actual ruler callback saves left and right indents together'
 & $context.Apply @{FontSize=14;Bold=$true}
 $after=& $context.Commands['Get-MedicalParagraphFormat'] $context.State.Model $context.State.Paragraph.Id
 Assert-FormatUi ($after.FontSize -eq 14 -and $after.Bold) 'Actual UI callback saves font size and bold formatting'
 Assert-FormatUi ($context.State.Paragraph.Text -ceq $context.Text) 'Formatting changes leave original text untouched'
 $local=@{Format=(& $context.Commands['Get-MedicalParagraphFormat'] $model $paragraph.Id);FormatNote='Шрифт и размер применяются ко всему абзацу.'}
 $graphics=[pscustomobject]@{DpiX=96;Disposed=$false}
 $graphics | Add-Member ScriptMethod Dispose {$this.Disposed=$true}
 $editor=[pscustomobject]@{NativeZoom=[single]1;Graphics=$graphics;Text=$paragraph.Text;SelectionStart=9;SelectionLength=4;FontSize=$local.Format.FontSize}
 $editor | Add-Member ScriptProperty ZoomFactor {return $this.NativeZoom} {param($value)
  if($value -le (1.0/64.0) -or $value -ge 64){throw 'Unsupported RichTextBox zoom'}
  $multiplier=[single]([single]$value*1000);$numerator=[Math]::Ceiling($multiplier);if($numerator -ge 64000){$numerator=[Math]::Floor($multiplier)}
  $this.NativeZoom=[single]($numerator/1000.0)
 }
 $editor | Add-Member ScriptMethod CreateGraphics {return $this.Graphics}
 $paper=[pscustomobject]@{Width=1;Height=1}
 $viewport=[pscustomobject]@{ClientSize=[pscustomobject]@{Width=1200;Height=300}}
 $ruler=[pscustomobject]@{RulerDpi=[single]96;ContentWidthCm=17;Invalidations=0}
 $ruler | Add-Member ScriptMethod Invalidate {$this.Invalidations++}
 $summary=[pscustomobject]@{Text=''};$tip=[pscustomobject]@{Text=''}
 $tip | Add-Member ScriptMethod SetToolTip {param($control,$text)$this.Text=$text}
 $resize=. ([scriptblock]::Create($ResizeExpression))
 $beforeXml=($model.PartOrder | ForEach-Object {$model.Parts[$_].Xml.OuterXml}) -join "`n"
 $beforeFormat=$local.Format | ConvertTo-Json -Depth 10 -Compress
 $viewportCases=@(@(1200,300,96),@(1800,580,96),@(420,350,96),@(100,140,96),@(900,270,144),@(1600,220,192),@(640,620,120))
 foreach($case in $viewportCases){
  $viewport.ClientSize.Width=$case[0];$viewport.ClientSize.Height=$case[1];$graphics.DpiX=$case[2];$graphics.Disposed=$false
  & $resize
  Assert-FormatUi ($paper.Width -eq $case[0]-16 -and $paper.Height -eq $case[1]) ('Actual pane fills available width and height: '+$case[0]+' x '+$case[1]+' at '+$case[2]+' DPI')
  $nativeTextPixels=$paper.Width-12-[Windows.Forms.SystemInformation]::VerticalScrollBarWidth
  $rulerTextPixels=$ruler.ContentWidthCm*$ruler.RulerDpi/2.54
  $nativeZoomTolerance=$local.Format.ContentWidthCm*$case[2]/2.54/1000+.01
  Assert-FormatUi ([Math]::Abs($nativeTextPixels-$rulerTextPixels) -lt $nativeZoomTolerance) ('Scaled centimetre ruler fits native text rectangle within RichEdit zoom rounding: '+$case[0]+' px at '+$case[2]+' DPI')
  Assert-FormatUi ([Math]::Abs($ruler.RulerDpi-$case[2]*$editor.ZoomFactor) -lt .0001) ('Ruler centimetres use actual RichEdit zoom: '+$case[0]+' px')
  $expectedZoom=$nativeTextPixels*2.54/($local.Format.ContentWidthCm*$case[2])
  Assert-FormatUi ([Math]::Abs($editor.ZoomFactor-$expectedZoom) -lt .00101) ('Display zoom fits Word width without changing document size: '+$case[0]+' px')
  Assert-FormatUi ($graphics.Disposed) ('Responsive pane releases graphics object: '+$case[0]+' px')
 }
 Assert-FormatUi ($editor.Text -ceq $paragraph.Text -and $editor.SelectionStart -eq 9 -and $editor.SelectionLength -eq 4) 'Resizing preserves text, caret, and selected range'
 Assert-FormatUi ($editor.FontSize -eq $local.Format.FontSize) 'Fitting the pane changes display zoom instead of stored font size'
 Assert-FormatUi (($local.Format | ConvertTo-Json -Depth 10 -Compress) -ceq $beforeFormat) 'Responsive display leaves paragraph and page measurements unchanged'
 Assert-FormatUi ((($model.PartOrder | ForEach-Object {$model.Parts[$_].Xml.OuterXml}) -join "`n") -ceq $beforeXml) 'Wide and narrow viewport changes leave all Word XML unchanged'
 Assert-FormatUi ($summary.Text.StartsWith('Масштаб ') -and $summary.Text.Contains('область word:') -and $tip.Text -ceq $summary.Text) 'Fit percentage and actual Word width visible with complete tooltip'
 $local.Format=$beforeFormat | ConvertFrom-Json;$local.Format.ContentWidthCm=5;$local.Format.IsTable=$true
 $viewport.ClientSize.Width=1100;$viewport.ClientSize.Height=230;$graphics.DpiX=144;& $resize
 Assert-FormatUi ($paper.Width -eq 1084 -and $paper.Height -eq 230 -and $ruler.ContentWidthCm -eq 5) 'Narrow Word table cell expands to the same full viewport'
 Assert-FormatUi ($summary.Text.Contains('ячейка word: 5 см') -and $editor.ZoomFactor -gt 3) 'Table cell displays its actual Word width and enlarged fit scale'
 Assert-FormatUi ((($model.PartOrder | ForEach-Object {$model.Parts[$_].Xml.OuterXml}) -join "`n") -ceq $beforeXml) 'Fitting narrow table width leaves original Word XML intact'
 $local.Format=$null;$viewport.ClientSize.Width=900;$viewport.ClientSize.Height=200;& $resize
 Assert-FormatUi ($paper.Width -eq 884 -and $paper.Height -eq 200 -and $ruler.ContentWidthCm -eq 17) 'Empty paragraph selection still fills viewport with a default ruler width'
 $viewport.ClientSize.Width=1;$viewport.ClientSize.Height=0;& $resize
 Assert-FormatUi ($paper.Width -eq 1 -and $paper.Height -eq 1 -and $editor.ZoomFactor -ge (1.0/64.0)) 'Transient collapsed viewport produces valid control size and supported zoom'
 Assert-FormatUi ([Math]::Abs([MedicalWordLayoutMath]::FitZoom(100000,17,.1,96)-63.999) -lt .00001) 'Extreme enlargement clamps to RichEdit supported maximum'
 Assert-FormatUi ([Math]::Abs([MedicalWordLayoutMath]::FitZoom(1,17,55,192)-.016) -lt .00001) 'Extreme reduction clamps to RichEdit supported minimum'
'@ | Set-Content -LiteralPath $factory -Encoding UTF8
 & $factory $Project $applyMatch.Groups[1].Value $resizeMatch.Groups[1].Value
 'ALL '+$formatUiTally.Checks+' UI FORMAT CHECKS PASSED'
}finally{if(Test-Path $work){Remove-Item -LiteralPath $work -Recurse -Force}}
