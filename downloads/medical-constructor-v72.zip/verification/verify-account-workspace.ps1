﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v72'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Check([bool]$test,[string]$label){if(-not $test){throw $label};$script:checks++;Write-Output ('PASS '+$label)}
function Assert-Rejected([scriptblock]$action,[string]$label){$rejected=$false;try{$null=& $action}catch{$rejected=$true};Assert-Check $rejected $label}
function Get-TestSha([string]$path){return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}
function New-TestLink([string]$link,[string]$target){$kind=if($env:OS -eq 'Windows_NT'){'Junction'}else{'SymbolicLink'};$null=New-Item -ItemType $kind -Path $link -Target $target}
function New-TestDanglingFileLink([string]$link,[string]$target){[IO.File]::WriteAllText($target,'temporary redirect target');$null=New-Item -ItemType SymbolicLink -Path $link -Target $target;[IO.File]::Delete($target)}
Add-Type -TypeDefinition @'
using System;using System.Collections;
namespace Windows.Forms {
 public sealed class ControlCollection:CollectionBase {public void Add(object value){List.Add(value);}}
 public class Control {public string Text{get;set;}public bool Enabled{get;set;}public int Width{get;set;}public int Height{get;set;}public bool AutoEllipsis{get;set;}public bool UseMnemonic{get;set;}public ControlCollection Controls=new ControlCollection();public Control(){Enabled=true;}}
 public sealed class Form:Control {
  public double Opacity{get;set;}public bool IsDisposed{get;set;}public int Closes,Hides;public event EventHandler Closing;
  public Form(){Opacity=1;}
  public void Close(){Closes++;if(Closing!=null)Closing(this,EventArgs.Empty);IsDisposed=true;}
  public void Hide(){Hides++;throw new Exception("Modal editors must not be hidden");}
 }
 public sealed class Label:Control{}
 public sealed class Button:Control {public event EventHandler Click;public void RaiseClick(){if(Click!=null)Click(this,EventArgs.Empty);}}
 public sealed class Timer:IDisposable {public int Interval{get;set;}public bool Enabled{get;set;}public int Starts,Stops;public bool Disposed;public event EventHandler Tick;public void Start(){Starts++;Enabled=true;}public void Stop(){Stops++;Enabled=false;}public void RaiseTick(){if(Tick!=null)Tick(this,EventArgs.Empty);}public void Dispose(){Disposed=true;}}
 public static class Application {
  public static ArrayList OpenForms=new ArrayList();public static ArrayList Filters=new ArrayList();
  public static void AddMessageFilter(object value){Filters.Add(value);}public static void RemoveMessageFilter(object value){Filters.Remove(value);}
 }
 public static class MessageBox {public static Queue Replies=new Queue();public static int Calls;public static object Show(params object[] args){Calls++;return Replies.Count>0?Replies.Dequeue():"OK";}}
}
public sealed class MedicalAccountActivityV71 {public double IdleSeconds{get;set;}public int Resets;public void Reset(){IdleSeconds=0;Resets++;}}
'@
. (Join-Path $Project 'accounts-v71.ps1')
. (Join-Path $Project 'account-workspace-v71.ps1')
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-v71-workspace-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
$leases=New-Object Collections.ArrayList
try{
 $root=Join-Path $temp 'Переносимая программа';[void][IO.Directory]::CreateDirectory($root)
 $starters=@('template.dotx','Универсальный первичный осмотр.docx','Шаблон первичного осмотра.docx','diagnosis-templates.json','document-font.json')
 $starterHashes=@{}
 foreach($name in $starters){[IO.File]::Copy((Join-Path $Project $name),(Join-Path $root $name));$starterHashes[$name]=Get-TestSha (Join-Path $root $name)}
 foreach($name in @('form-settings.json','patients.json','appearance.json')){[IO.File]::WriteAllText((Join-Path $root $name),'LEGACY PRIVATE DATA')}
 foreach($name in @('Карты','Шаблоны','Резервные копии')){[void][IO.Directory]::CreateDirectory((Join-Path $root $name));[IO.File]::WriteAllText((Join-Path (Join-Path $root $name) 'legacy-patient.txt'),'LEGACY PRIVATE DATA')}
 $context=Initialize-MedicalAccounts $root;$script:medicalAccountsContext=$context
 $admin=New-MedicalFirstAdministrator $context 'admin' 'Главный врач' 'AdminPass_123'
 $doctor=New-MedicalUserAccount $admin 'doctor' 'Врач' 'DoctorPass_123'
 $doctorSession=Invoke-MedicalAccountLogin $context 'doctor' 'DoctorPass_123'
 $script:medicalAuthSession=$null;$script:medicalAccountWorkspace=$null
 Assert-Rejected {Assert-MedicalActiveAccount} 'Missing authentication rejects active-account operations'
 Assert-Rejected {Assert-MedicalAccountPath (Join-Path $temp 'patient.docx')} 'Missing authentication rejects ordinary document access'
 Assert-Rejected {Assert-MedicalAccountPath (Join-Path $temp 'backup.mcbak') $true} 'Missing authentication rejects background backup access'
 $workspaceA=Initialize-MedicalAccountWorkspace $admin $root;[void]$leases.Add($workspaceA)
 Assert-Check ($workspaceA.DataRoot -ceq (Join-Path (Join-Path $root 'Данные') $admin.UserId)) 'Administrator workspace uses stable account GUID beneath this installation'
 Assert-Check ($script:medicalProgramRoot -ceq $workspaceA.DataRoot -and $script:medicalTemplatesFolder -ceq (Join-Path $workspaceA.DataRoot 'Шаблоны')) 'Template and program resource roots switch to current account'
 Assert-Check ($script:universalConfigPath -ceq (Join-Path $workspaceA.DataRoot 'form-settings.json') -and $script:dbFile -ceq (Join-Path $workspaceA.DataRoot 'patients.json')) 'Form configuration and patient database are account-specific'
 Assert-Check ($script:profileFile -ceq (Join-Path $workspaceA.DataRoot 'diagnosis-templates.json') -and $script:fontFile -ceq (Join-Path $workspaceA.DataRoot 'document-font.json') -and $script:uiSettingsPath -ceq (Join-Path $workspaceA.DataRoot 'appearance.json')) 'Profiles, typography and appearance are account-specific'
 Assert-Check ((Get-MedicalAccountCardsDirectory) -ceq $workspaceA.CardsRoot) 'Save-card default points to account private card folder'
 Assert-Check ($script:medicalBackupPath -ceq '' -and -not $script:medicalAccountLocked) 'Workspace resets checkpoint destination and unlocked state'
 foreach($name in @('Карты','Шаблоны','Резервные копии')){Assert-Check ([IO.Directory]::Exists((Join-Path $workspaceA.DataRoot $name))) ('Account private folder exists: '+$name)}
 foreach($name in $starters){Assert-Check ((Get-TestSha (Join-Path $workspaceA.DataRoot $name)) -ceq $starterHashes[$name]) ('Shipped reusable resource is copied byte-for-byte: '+$name)}
 foreach($name in @('form-settings.json','patients.json','appearance.json','Карты/legacy-patient.txt','Шаблоны/legacy-patient.txt','Резервные копии/legacy-patient.txt')){Assert-Check (-not [IO.File]::Exists((Join-Path $workspaceA.DataRoot $name))) ('Legacy private state is never migrated: '+$name)}
 Assert-Rejected {Initialize-MedicalAccountWorkspace $admin $root} 'Second program instance cannot lease the same account workspace'
 Assert-Rejected {[IO.File]::Open((Join-Path $workspaceA.DataRoot '.session.lock'),[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None).Dispose()} 'Production workspace lease is a real exclusive file handle'
 Assert-Check ($null -ne $workspaceA.Lease) 'Rejected duplicate lease leaves first workspace active'
 $otherPath=Join-Path (Join-Path (Join-Path $root 'Данные') $doctor.Id) 'Карты/other.docx'
 Assert-Rejected {Assert-MedicalAccountPath $otherPath} 'Administrator cannot read another employee private document through the app'
 Assert-Rejected {Assert-MedicalAccountPath $otherPath $true} 'Administrator cannot redirect checkpoint into another employee workspace'
 foreach($name in @('accounts.json','accounts.json.bak','database.lock')){Assert-Rejected {Assert-MedicalAccountPath (Join-Path (Join-Path $root 'Учетные записи') $name)} ('Account database tree cannot be chosen as a document: '+$name)}
 $null=Assert-MedicalAccountPath (Join-Path $workspaceA.CardsRoot 'own.docx')
 Assert-Check $true 'Current account may access its own ordinary document destination'
 $null=Assert-MedicalAccountPath (Join-Path $temp 'explicit-export.docx')
 Assert-Check $true 'User may explicitly export ordinary Word files outside managed workspaces'
 Assert-Rejected {Assert-MedicalAccountPath (Join-Path $temp 'external.mcbak') $true} 'Automatic backup cannot leave the authenticated account workspace'
 $outside=Join-Path $temp 'redirect-target';[void][IO.Directory]::CreateDirectory($outside)
 $link=Join-Path $workspaceA.DataRoot 'Карты/redirect';New-TestLink $link $outside
 Assert-Rejected {Assert-MedicalAccountPath (Join-Path $link 'patient.docx')} 'Managed-tree directory redirect is rejected for ordinary documents'
 Assert-Rejected {Assert-MedicalAccountPath (Join-Path $link 'checkpoint.mcbak') $true} 'Managed-tree directory redirect is rejected for checkpoints'
 [IO.Directory]::Delete($link)
 $dangling=Join-Path $workspaceA.CardsRoot 'dangling.docx';$danglingTarget=Join-Path $outside 'missing-runtime-target.docx';New-TestDanglingFileLink $dangling $danglingTarget
 Assert-Rejected {Assert-MedicalAccountPath $dangling} 'Dangling managed document symlink is rejected despite false File.Exists'
 Assert-Rejected {Assert-MedicalAccountPath $dangling $true} 'Dangling managed backup symlink is rejected before creating its target'
 Assert-Check (-not [IO.File]::Exists($danglingTarget)) 'Rejected dangling document and backup leave outside target absent'
 [IO.File]::Delete($dangling)
 $null=Assert-MedicalAccountPath (Join-Path $workspaceA.CardsRoot 'new-missing/nested/patient.docx')
 Assert-Check $true 'Normal new managed destination with missing parents remains allowed'
 $forged=$admin.PSObject.Copy();$forged.Token=[Convert]::ToBase64String([byte[]](1..48))
 Assert-Rejected {Initialize-MedicalAccountWorkspace $forged $root} 'Unissued authentication ticket cannot create or lease a workspace'
 Assert-Rejected {Initialize-MedicalAccountWorkspace $admin $temp} 'Valid session cannot redirect workspace to another installation'
 $workspaceB=Initialize-MedicalAccountWorkspace $doctorSession $root;[void]$leases.Add($workspaceB)
 Assert-Check ($workspaceB.DataRoot -cne $workspaceA.DataRoot -and $workspaceB.CardsRoot -cne $workspaceA.CardsRoot) 'Separate employees receive independent working directories'
 Assert-Rejected {Assert-MedicalAccountPath (Join-Path $workspaceA.CardsRoot 'private.docx')} 'Ordinary employee cannot access administrator private workspace'
 [IO.File]::WriteAllText((Join-Path $workspaceA.CardsRoot 'private.docx'),'ADMIN ONLY')
 [IO.File]::WriteAllText((Join-Path $workspaceB.CardsRoot 'private.docx'),'DOCTOR ONLY')
 [IO.File]::WriteAllText((Join-Path $workspaceA.DataRoot 'diagnosis-templates.json'),'PERSONALIZED ADMIN FORM')
 Assert-Check ((Get-TestSha (Join-Path $workspaceB.DataRoot 'diagnosis-templates.json')) -ceq $starterHashes['diagnosis-templates.json']) 'One employee template edits do not affect another employee'
 foreach($name in $starters){Assert-Check ((Get-TestSha (Join-Path $root $name)) -ceq $starterHashes[$name]) ('Profile changes leave shipped starter unchanged: '+$name)}
 Close-MedicalAccountWorkspace
 Assert-Check ($null -eq $workspaceB.Lease -and $null -eq $script:medicalAuthSession -and -not (Test-MedicalSession $doctorSession)) 'Workspace cleanup releases lease and revokes active authentication ticket'
 $probe=[IO.File]::Open((Join-Path $workspaceB.DataRoot '.session.lock'),[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);$probe.Dispose()
 Assert-Check $true 'Released workspace can be leased by a later program instance'
 # An existing child redirect is rejected before lease acquisition or seeding.
 [IO.Directory]::Delete((Join-Path $workspaceB.DataRoot 'Шаблоны'));New-TestLink (Join-Path $workspaceB.DataRoot 'Шаблоны') $outside
 $doctorSession=Invoke-MedicalAccountLogin $context 'doctor' 'DoctorPass_123'
 Assert-Rejected {Initialize-MedicalAccountWorkspace $doctorSession $root} 'Existing private template junction is rejected at workspace initialization'
 Assert-Check (@(Get-ChildItem -LiteralPath $outside -Force).Count -eq 0) 'Rejected template junction does not seed or alter redirect target'
 [IO.Directory]::Delete((Join-Path $workspaceB.DataRoot 'Шаблоны'));[void][IO.Directory]::CreateDirectory((Join-Path $workspaceB.DataRoot 'Шаблоны'))
 $seed=Join-Path $workspaceB.DataRoot 'template.dotx';$seedSaved=$seed+'.safe';[IO.File]::Move($seed,$seedSaved)
 $danglingSeedTarget=Join-Path $outside 'missing-seed.dotx';New-TestDanglingFileLink $seed $danglingSeedTarget
 Assert-Rejected {Initialize-MedicalAccountWorkspace $doctorSession $root} 'Dangling shipped-seed symlink is rejected before profile seeding'
 Assert-Check (-not [IO.File]::Exists($danglingSeedTarget)) 'Rejected dangling seed cannot create an outside template'
 [IO.File]::Delete($seed);[IO.File]::Move($seedSaved,$seed)
 $config=Join-Path $workspaceB.DataRoot 'form-settings.json';$danglingConfigTarget=Join-Path $outside 'missing-config.json';New-TestDanglingFileLink $config $danglingConfigTarget
 Assert-Rejected {Initialize-MedicalAccountWorkspace $doctorSession $root} 'Dangling private configuration symlink is rejected at workspace initialization'
 Assert-Check (-not [IO.File]::Exists($danglingConfigTarget)) 'Rejected dangling configuration leaves outside target absent'
 [IO.File]::Delete($config)
 $probe=[IO.File]::Open((Join-Path $workspaceB.DataRoot '.session.lock'),[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);$probe.Dispose()
 Assert-Check $true 'Dangling seed and configuration rejection leak no workspace lease'
 $workspaceA.Lease.Dispose();$workspaceA.Lease=$null;Close-MedicalSession $admin;Close-MedicalSession $doctorSession
 # Moving all program files preserves GUID workspaces, credentials and prior card bytes.
 $moved=Join-Path $temp 'Программа после переноса';[IO.Directory]::Move($root,$moved);$root=$moved
 $context=Initialize-MedicalAccounts $root;$script:medicalAccountsContext=$context
 $admin=Invoke-MedicalAccountLogin $context 'admin' 'AdminPass_123';$workspaceA=Initialize-MedicalAccountWorkspace $admin $root;[void]$leases.Add($workspaceA)
 Assert-Check ($workspaceA.DataRoot.StartsWith($moved,[StringComparison]::Ordinal) -and $script:medicalProgramRoot -ceq $workspaceA.DataRoot) 'Moved installation rebases active profile paths without old-machine binding'
 Assert-Check ([IO.File]::ReadAllText((Join-Path $workspaceA.CardsRoot 'private.docx')) -ceq 'ADMIN ONLY') 'Moved account keeps exact previously saved card data'
 Assert-Check ([IO.File]::ReadAllText((Join-Path $workspaceA.DataRoot 'diagnosis-templates.json')) -ceq 'PERSONALIZED ADMIN FORM') 'Existing personalized reusable resources are never overwritten by starter seeding'
 Close-MedicalAccountWorkspace
 # A redirect at the entire users root must fail before creating the account GUID outside.
 $users=Join-Path $root 'Данные';$originalUsers=$users+'-original';[IO.Directory]::Move($users,$originalUsers);New-TestLink $users $outside
 $admin=Invoke-MedicalAccountLogin $context 'admin' 'AdminPass_123'
 Assert-Rejected {Initialize-MedicalAccountWorkspace $admin $root} 'Redirected users root is rejected before profile creation'
 Assert-Check (-not [IO.Directory]::Exists((Join-Path $outside $admin.UserId))) 'Rejected users-root junction creates no GUID folder outside installation'
 [IO.Directory]::Delete($users);[IO.Directory]::Move($originalUsers,$users)
 [IO.Directory]::Move($users,$originalUsers);New-TestLink $users $outside;[IO.Directory]::Delete($outside)
 Assert-Rejected {Initialize-MedicalAccountWorkspace $admin $root} 'Dangling users-root redirect is rejected before any profile directory is created'
 Assert-Check (-not [IO.Directory]::Exists($outside) -and -not [IO.Directory]::Exists((Join-Path $outside $admin.UserId))) 'Rejected dangling users root does not recreate outside target or GUID folder'
 if($env:OS -eq 'Windows_NT'){[IO.Directory]::Delete($users)}else{[IO.File]::Delete($users)};[IO.Directory]::Move($originalUsers,$users)
 $workspaceA=Initialize-MedicalAccountWorkspace $admin $root;[void]$leases.Add($workspaceA)
 # Real UI policy exercises the actual lock controller using native-like windows.
 function Reset-TestWindows {
  [Windows.Forms.Application]::OpenForms.Clear();$script:ownerWindow=New-Object Windows.Forms.Form;$script:ownerWindow.Opacity=0.88
  $script:editorWindow=New-Object Windows.Forms.Form;$script:editorWindow.Opacity=0.63;$script:editorWindow.Enabled=$false
  [void][Windows.Forms.Application]::OpenForms.Add($script:ownerWindow);[void][Windows.Forms.Application]::OpenForms.Add($script:editorWindow)
  $script:templateTimer=New-Object Windows.Forms.Timer;$script:templateTimer.Start()
  $script:medicalAccountActivity=New-Object MedicalAccountActivityV71
  $script:medicalAccountLocked=$false;$script:medicalAuthClosingLocked=$false;$script:medicalWorkspaceReady=$true
  $script:medicalBackupEditorDraft=$null;$script:medicalBackupRetainedDraft=$null;$script:lockQueue=New-Object Collections.Queue
  $script:lockCalls=0;$script:backupCalls=0;$script:backupFail=$false;$script:loginThrow=$false
 }
 function Show-MedicalLockScreen($owner,$session){
  $script:lockCalls++
  Assert-Check ($script:medicalAccountLocked -and $script:ownerWindow.Opacity -eq 0 -and -not $script:ownerWindow.Enabled -and $script:editorWindow.Opacity -eq 0 -and -not $script:editorWindow.Enabled) 'Lock screen runs while all pre-existing work windows remain opaque-hidden and disabled' | Out-Host
  if($script:loginThrow){throw 'TEST lock dialog failure'}
  if($script:lockQueue.Count -eq 0){throw 'TEST lock queue exhausted'}
  return $script:lockQueue.Dequeue()
 }
 function Write-MedicalSessionBackup {$script:backupCalls++;if($script:backupFail){throw 'TEST checkpoint folder unavailable'};return [pscustomobject]@{Confirmed=$true}}
 Reset-TestWindows
 $previous=$script:medicalAuthSession;$renewed=Invoke-MedicalAccountLogin $context 'admin' 'AdminPass_123';$script:lockQueue.Enqueue($renewed)
 Invoke-MedicalAccountLock $script:ownerWindow
 Assert-Check (-not $script:medicalAccountLocked -and -not $script:medicalAuthClosingLocked) 'Same-account unlock returns to active work without exit'
 Assert-Check ($script:ownerWindow.Opacity -eq 0.88 -and $script:ownerWindow.Enabled -and $script:editorWindow.Opacity -eq 0.63 -and -not $script:editorWindow.Enabled) 'Unlock restores original opacity and enabled state for every modal and parent window'
 Assert-Check ($script:ownerWindow.Hides -eq 0 -and $script:editorWindow.Hides -eq 0 -and $script:editorWindow.Closes -eq 0) 'Lock preserves existing modal editor loops without Hide or Close'
 Assert-Check (-not (Test-MedicalSession $previous) -and (Test-MedicalSession $renewed) -and $script:medicalAuthSession.Token -ceq $renewed.Token) 'Unlock replaces and revokes the old session ticket'
 Assert-Check ($script:templateTimer.Enabled -and $script:templateTimer.Stops -eq 1 -and $script:templateTimer.Starts -eq 2 -and $script:medicalAccountActivity.Resets -eq 1) 'Successful unlock resumes template watching and resets inactivity clock'
 Reset-TestWindows
 $wrongUser=Invoke-MedicalAccountLogin $context 'doctor' 'DoctorPass_123';$renewed=Invoke-MedicalAccountLogin $context 'admin' 'AdminPass_123'
 $script:lockQueue.Enqueue($wrongUser);$script:lockQueue.Enqueue($renewed)
 Invoke-MedicalAccountLock $script:ownerWindow
 Assert-Check ($script:lockCalls -eq 2 -and $script:medicalAuthSession.UserId -ceq $workspaceA.UserId) 'Different employee ticket cannot unlock another employee open work'
 Assert-Check (-not (Test-MedicalSession $wrongUser)) 'Rejected cross-account unlock ticket is revoked'
 Reset-TestWindows;$script:lockQueue.Enqueue($null)
 $script:medicalBackupEditorDraft=[pscustomobject]@{State=[pscustomobject]@{AccountClose=$false}}
 $script:closedDraftFlag=$false;$script:editorWindow.Add_Closing({$script:closedDraftFlag=$script:medicalBackupEditorDraft.State.AccountClose})
 Invoke-MedicalAccountLock $script:ownerWindow
 Assert-Check ($script:backupCalls -eq 1 -and $script:medicalAuthClosingLocked) 'Canceling locked login closes through private backup-preserving exit'
 Assert-Check ($script:closedDraftFlag -and $script:medicalBackupEditorDraft.State.AccountClose) 'Locked exit marks an open editor draft before closing modal windows'
 Assert-Check ($script:ownerWindow.Closes -eq 1 -and $script:editorWindow.Closes -eq 1 -and $script:ownerWindow.Opacity -eq 0 -and -not $script:ownerWindow.Enabled) 'Locked exit closes all pre-existing windows without exposing patient data'
 Assert-Check (-not $script:templateTimer.Enabled -and (Test-MedicalAccountLockedClose)) 'Locked exit does not restart background template watcher'
 Reset-TestWindows;$script:backupFail=$true;$script:lockQueue.Enqueue($null);$script:lockQueue.Enqueue($null)
 [Windows.Forms.MessageBox]::Replies.Enqueue('No');[Windows.Forms.MessageBox]::Replies.Enqueue('Yes')
 Invoke-MedicalAccountLock $script:ownerWindow
 Assert-Check ($script:lockCalls -eq 2 -and $script:backupCalls -eq 2) 'Failed backup with No returns to locked login and retries without recursion'
 Assert-Check ($script:ownerWindow.Closes -eq 1 -and $script:medicalAuthClosingLocked) 'Explicit Yes permits locked close after repeated backup failure'
 Reset-TestWindows;$script:loginThrow=$true
 Invoke-MedicalAccountLock $script:ownerWindow
 Assert-Check ($script:medicalAuthClosingLocked -and $script:backupCalls -eq 1 -and $script:ownerWindow.Closes -eq 1) 'Unavailable lock dialog fails closed with best-effort checkpoint'
 Reset-TestWindows;$script:medicalAccountActivity.IdleSeconds=599
 Invoke-MedicalAccountActivityTick $script:ownerWindow
 Assert-Check ($script:lockCalls -eq 0 -and -not $script:medicalAccountLocked) 'Valid session below ten-minute idle threshold stays active'
 $renewed=Invoke-MedicalAccountLogin $context 'admin' 'AdminPass_123';$script:lockQueue.Enqueue($renewed);$script:medicalAccountActivity.IdleSeconds=600
 Invoke-MedicalAccountActivityTick $script:ownerWindow
 Assert-Check ($script:lockCalls -eq 1 -and $script:medicalAccountActivity.Resets -eq 1) 'Exactly ten minutes of inactivity triggers lock and successful unlock resets idle time'
 Reset-TestWindows;$revoked=$script:medicalAuthSession;Close-MedicalSession $revoked;$renewed=Invoke-MedicalAccountLogin $context 'admin' 'AdminPass_123';$script:lockQueue.Enqueue($renewed)
 Invoke-MedicalAccountActivityTick $script:ownerWindow
 Assert-Check ($script:lockCalls -eq 1 -and $script:medicalAuthSession.Token -ceq $renewed.Token) 'Revoked ticket triggers lock before idle threshold and requires fresh authentication'
 Reset-TestWindows;$script:ownerWindow.IsDisposed=$true
 Invoke-MedicalAccountActivityTick $script:ownerWindow
 Assert-Check ($script:lockCalls -eq 0) 'Disposed main window cannot open another lock dialog'
 Reset-TestWindows;$script:medicalAccountLocked=$true
 Invoke-MedicalAccountActivityTick $script:ownerWindow
 Assert-Check ($script:lockCalls -eq 0) 'Timer cannot re-enter an already active lock screen'
 $script:medicalAccountLocked=$false
 Start-MedicalAccountActivity $script:ownerWindow;$timer=$script:medicalAccountTimer;$activity=$script:medicalAccountActivity
 Assert-Check ($timer.Enabled -and $timer.Interval -eq 15000 -and [Windows.Forms.Application]::Filters.Contains($activity)) 'Actual inactivity timer and native activity filter are registered'
 $capturedOwner=$script:ownerWindow;$script:medicalAccountActivity.IdleSeconds=600;$renewed=Invoke-MedicalAccountLogin $context 'admin' 'AdminPass_123';$script:lockQueue.Enqueue($renewed)
 & {$localOwner='changed caller variable';$timer.RaiseTick()}
 Assert-Check ($script:lockCalls -eq 1 -and $capturedOwner.Closes -eq 0 -and -not $script:medicalAccountLocked) 'Actual timer closure resolves captured FunctionInfo and current script account state'
 Stop-MedicalAccountActivity
 Assert-Check ($timer.Disposed -and -not $timer.Enabled -and $null -eq $script:medicalAccountTimer -and -not [Windows.Forms.Application]::Filters.Contains($activity)) 'Inactivity cleanup disposes timer and removes native message filter'
 $script:medicalAccountLocked=$true
 Assert-Rejected {Assert-MedicalActiveAccount} 'Locked account blocks direct document actions'
 Assert-Check ((Assert-MedicalActiveAccount $true).UserId -ceq $workspaceA.UserId) 'Explicit background policy can validate a locked current account'
 $script:medicalAccountLocked=$false
 Close-MedicalSession $script:medicalAuthSession
 Assert-Rejected {Assert-MedicalAccountPath (Join-Path $workspaceA.CardsRoot 'patient.docx')} 'Revoked session cannot open documents even if workspace object remains'
 $null=Assert-MedicalAccountPath (Join-Path $workspaceA.DataRoot 'Резервные копии/last.mcbak') $true
 Assert-Check $true 'Revoked account may checkpoint only its already selected private profile for recovery'
 Assert-Rejected {Assert-MedicalAccountPath (Join-Path $temp 'elsewhere.mcbak') $true} 'Revoked account checkpoint still cannot escape its private profile'
 # Missing authentication cannot hide windows or create a pre-login checkpoint.
 Reset-TestWindows;$script:medicalAuthSession=$null
 Invoke-MedicalAccountLock $script:ownerWindow
 Assert-Check ($script:lockCalls -eq 0 -and $script:backupCalls -eq 0 -and $script:ownerWindow.Opacity -eq 0.88 -and -not $script:medicalAccountLocked) 'Pre-login lock action does not touch windows or patient backups'
 # The C# activity filter itself is compiled from the production here-string.
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'account-workspace-v71.ps1'),[ref]$tokens,[ref]$errors)
 $activitySource=@($ast.FindAll({param($node) $node -is [Management.Automation.Language.StringConstantExpressionAst] -and $node.Value.Contains('public sealed class MedicalAccountActivityV71')},$true))[0].Value
 $activitySource=$activitySource.Replace('MedicalAccountActivityV71','ActualMedicalAccountActivityV71')
 $activitySource+="`nnamespace System.Windows.Forms {public struct Message {public int Msg;} public interface IMessageFilter {bool PreFilterMessage(ref Message message);}}"
 Add-Type -TypeDefinition $activitySource
 $actualActivity=New-Object ActualMedicalAccountActivityV71;$message=New-Object System.Windows.Forms.Message
 foreach($code in @(0x100,0x109,0x200,0x20E)){
  Start-Sleep -Milliseconds 20;$beforeIdle=$actualActivity.IdleSeconds;$message.Msg=$code;$consumed=$actualActivity.PreFilterMessage([ref]$message)
  Assert-Check (-not $consumed -and $actualActivity.IdleSeconds -lt $beforeIdle) ('Actual activity filter observes input without consuming native message: '+$code)
 }
 foreach($code in @(0x0F,0x10A,0x20F)){
  Start-Sleep -Milliseconds 20;$beforeIdle=$actualActivity.IdleSeconds;$message.Msg=$code;$consumed=$actualActivity.PreFilterMessage([ref]$message)
  Assert-Check (-not $consumed -and $actualActivity.IdleSeconds -ge $beforeIdle) ('Actual activity filter ignores non-input native message: '+$code)
 }
 # Sidebar buttons invoke captured commands after their creation scope ends.
 $script:medicalAuthSession=Invoke-MedicalAccountLogin $context 'admin' 'AdminPass_123';$script:medicalAccountLocked=$false
 $script:passwordCalls=0;$script:managerCalls=0;$script:sidebarLockOwner=$null
 function Add-MedicalSidebarHeading($sidebar,$text){}
 function Move-MedicalSidebarButton($sidebar,$button){$sidebar.Controls.Add($button)}
 function Show-MedicalPasswordChange($owner,$session){$script:passwordCalls++;$script:passwordOwner=$owner;$script:passwordUser=$session.UserId}
 function Show-MedicalAccountManager($owner,$session){$null=Assert-MedicalAdministrator $session;$script:managerCalls++;$script:managerOwner=$owner}
 function Invoke-MedicalAccountLock($owner){$script:sidebarLockOwner=$owner}
 $sidebar=New-Object Windows.Forms.Control;$sidebarOwner=New-Object Windows.Forms.Form
 & {param($privateOwner,$privateSidebar) Add-MedicalAccountControls $privateOwner $privateSidebar} $sidebarOwner $sidebar
 $buttons=@($sidebar.Controls|Where-Object {$_ -is [Windows.Forms.Button]})
 Assert-Check ($buttons.Count -eq 3) 'Administrator sidebar contains password, employee manager and lock buttons'
 $label=@($sidebar.Controls|Where-Object {$_ -is [Windows.Forms.Label]})[0]
 Assert-Check ($label.Text -ceq $script:medicalAuthSession.DisplayName -and -not $label.UseMnemonic) 'Sidebar displays current authenticated employee name without mnemonic interpretation'
 @($buttons|Where-Object {$_.Text -ceq 'Изменить пароль'})[0].RaiseClick()
 Assert-Check ($script:passwordCalls -eq 1 -and [object]::ReferenceEquals($script:passwordOwner,$sidebarOwner) -and $script:passwordUser -ceq $workspaceA.UserId) 'Password button callback retains owner and reads original script session'
 @($buttons|Where-Object {$_.Text -ceq 'Управление сотрудниками'})[0].RaiseClick()
 Assert-Check ($script:managerCalls -eq 1 -and [object]::ReferenceEquals($script:managerOwner,$sidebarOwner)) 'Employee manager callback retains privileged command and owner outside creation scope'
 @($buttons|Where-Object {$_.Text -ceq 'Заблокировать'})[0].RaiseClick()
 Assert-Check ([object]::ReferenceEquals($script:sidebarLockOwner,$sidebarOwner)) 'Lock button invokes captured command for its own window'
 Close-MedicalSession $script:medicalAuthSession;$beforeMessages=[Windows.Forms.MessageBox]::Calls
 @($buttons|Where-Object {$_.Text -ceq 'Изменить пароль'})[0].RaiseClick()
 Assert-Check ($script:passwordCalls -eq 1 -and [Windows.Forms.MessageBox]::Calls -eq ($beforeMessages+1)) 'Revoked session blocks password dialog through already-created button callback'
 $script:medicalAuthSession=Invoke-MedicalAccountLogin $context 'doctor' 'DoctorPass_123'
 $userSidebar=New-Object Windows.Forms.Control;Add-MedicalAccountControls $sidebarOwner $userSidebar
 $userButtons=@($userSidebar.Controls|Where-Object {$_ -is [Windows.Forms.Button]})
 Assert-Check ($userButtons.Count -eq 2 -and @($userButtons|Where-Object {$_.Text -ceq 'Управление сотрудниками'}).Count -eq 0) 'Ordinary employee sidebar exposes no account-management button'
 Write-Output ('TOTAL '+$script:checks+' checks passed')
}finally{
 try{Stop-MedicalAccountActivity}catch{}
 foreach($workspace in $leases){if($workspace.Lease){try{$workspace.Lease.Dispose()}catch{}}}
 try{Close-MedicalAccountWorkspace}catch{}
 if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}
}
