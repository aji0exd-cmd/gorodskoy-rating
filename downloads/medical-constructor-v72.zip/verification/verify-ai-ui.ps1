﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v72'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-AiUi([bool]$Condition,[string]$Message){if(-not $Condition){throw $Message};$script:checks++;Write-Output ('PASS '+$Message)}
function Assert-AiUiThrows([scriptblock]$Action,[string]$Message){$thrown=$false;try{& $Action}catch{$thrown=$true};Assert-AiUi $thrown $Message}
function Import-AiUiFunctions([string]$Path,[string[]]$Names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($Path,[ref]$tokens,[ref]$errors);if($errors.Count){throw ($errors|Out-String)}
 foreach($node in $ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){if(-not $Names.Count -or $node.Name -in $Names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}}
}
Add-Type -TypeDefinition @'
using System;
namespace Windows.Forms {
 public class TextBoxBase {
  public bool IsDisposed; public bool ReadOnly;public bool Enabled=true;public string Text="";public int SelectionStart;public int SelectionLength;
  public void Select(int start,int length){SelectionStart=start;SelectionLength=length;}
  public string SelectedText{get{return Text.Substring(SelectionStart,SelectionLength);}set{Text=Text.Substring(0,SelectionStart)+value+Text.Substring(SelectionStart+SelectionLength);SelectionLength=value.Length;}}
 }
 public static class Clipboard {public static int Calls;public static string Last;public static void SetText(string value){Calls++;Last=value;}}
}
'@
Import-AiUiFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
foreach($file in @('universal.ps1','forms-v59.ps1','template-editor-v59.ps1','template-recognition-v71.ps1','local-ai-ui-v72.ps1')){Import-AiUiFunctions (Join-Path $Project $file)}
$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-ai-ui-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
function New-AiUiFixture([string]$Body){
 $path=Join-Path $temp ([guid]::NewGuid().ToString('N')+'.docx');New-UniversalTemplate $path (New-UniversalConfig);$model=Read-MedicalTemplateModel $path
 $model.Parts['word/document.xml'].Xml=Read-MedicalEditorXml ([Text.Encoding]::UTF8.GetBytes(('<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'+$Body+'<w:sectPr/></w:body></w:document>')))
 $model.Parts['word/document.xml'].Modified=$false;Update-MedicalEditorParagraphs $model;return $model
}
function New-AiUiSuggestion($Paragraph,[string]$Marker,[int]$Start,[int]$Length){return [pscustomobject]@{ParagraphId=$Paragraph.Id;Marker=$Marker;Start=$Start;Length=$Length;OriginalText=$Paragraph.Text;Reason='Test model suggestion';Selected=$true}}
function Wait-AiUiJob($Job,[int]$Seconds=10){$clock=[Diagnostics.Stopwatch]::StartNew();do{$result=Complete-MedicalAiUiJob $Job;if($null -ne $result){return $result};[Threading.Thread]::Sleep(20)}while($clock.Elapsed.TotalSeconds -lt $Seconds);throw 'Background worker did not complete in time.'}
try{
 $control=New-Object Windows.Forms.TextBoxBase;$control.Text='До: жалобы {{COMPLAINTS}}; после';$control.SelectionStart=4;$control.SelectionLength=20
 $owner=[pscustomobject]@{ActiveControl=[pscustomobject]@{ActiveControl=$control}}
 Assert-AiUi ([object]::ReferenceEquals((Get-MedicalAiEditableTarget $owner),$control)) 'Focused editable target is found through nested containers'
 Assert-AiUi ([object]::ReferenceEquals((Get-MedicalAiEditableTarget $owner $control),$control)) 'Editor may supply its exact paragraph input control'
 $control.ReadOnly=$true;Assert-AiUi ($null -eq (Get-MedicalAiEditableTarget $owner)) 'Read-only target is never offered for AI replacement';$control.ReadOnly=$false
 $control.Enabled=$false;Assert-AiUi ($null -eq (Get-MedicalAiEditableTarget $owner)) 'Disabled target is never offered for AI replacement';$control.Enabled=$true
 $control.IsDisposed=$true;Assert-AiUi ($null -eq (New-MedicalAiTextSnapshot $control)) 'Disposed target has no editable snapshot';$control.IsDisposed=$false
 $control.Text='Префикс: жалобы {{COMPLAINTS}}; суффикс';$control.SelectionStart=9;$control.SelectionLength=21
 $snapshot=New-MedicalAiTextSnapshot $control
 Assert-AiUi ($snapshot.Input -ceq 'жалобы {{COMPLAINTS}}' -and $snapshot.Start -eq 9) 'Snapshot uses exactly the chosen character range'
 $control.SelectionStart=0;$control.SelectionLength=0;$snapshot=New-MedicalAiTextSnapshot $control
 Assert-AiUi ($snapshot.Input -ceq $control.Text -and $snapshot.Length -eq $control.Text.Length) 'No selection offers the entire focused field'
 $original=$control.Text;$control.Text+=' changed';Assert-AiUiThrows {Apply-MedicalAiTextResult $snapshot 'Замена'} 'Changed target text cannot receive stale model output';$control.Text=$original
 $control.ReadOnly=$true;Assert-AiUiThrows {Apply-MedicalAiTextResult $snapshot 'Замена'} 'Target becoming read-only blocks reviewed output';$control.ReadOnly=$false
 $control.IsDisposed=$true;Assert-AiUiThrows {Apply-MedicalAiTextResult $snapshot 'Замена'} 'Closed input control blocks reviewed output';$control.IsDisposed=$false
 Assert-AiUiThrows {Apply-MedicalAiTextResult $snapshot ''} 'Empty model response cannot erase patient input'
 Assert-AiUiThrows {Apply-MedicalAiTextResult $snapshot 'Текст без маркера'} 'Removing existing Word marker is rejected before mutation'
 Assert-AiUi ($control.Text -ceq $original) 'Rejected output leaves original input intact'
 [void](Apply-MedicalAiTextResult $snapshot 'Исправлено {{COMPLAINTS}}')
 Assert-AiUi ($control.Text -ceq 'Исправлено {{COMPLAINTS}}') 'Reviewed output applies explicitly while retaining the marker'
 $control.Text='начало abc конец';$control.Select(7,3);$snapshot=New-MedicalAiTextSnapshot $control;$control.Select(0,0);[void](Apply-MedicalAiTextResult $snapshot 'ABC')
 Assert-AiUi ($control.Text -ceq 'начало ABC конец') 'Applying uses the original range even after focus or caret movement'
 Assert-AiUiThrows {Apply-MedicalAiTextResult $null 'test'} 'Paste-only assistant never invents a target field'
 $schema=New-UniversalConfig;$schema.AutoTemplate=$false;$schema.Template='model.docx'
 $model=New-AiUiFixture '<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>Ф.И.О.: </w:t></w:r><w:r><w:rPr><w:i/></w:rPr><w:t>Иванов</w:t></w:r><w:r><w:rPr><w:color w:val="004488"/></w:rPr><w:t>; адрес: Москва.</w:t></w:r></w:p>'
 $p=$model.Paragraphs[0];$beforeXml=$model.Parts['word/document.xml'].Xml.OuterXml;$beforeSchema=$schema|ConvertTo-Json -Depth 40
 $proposals=@((New-AiUiSuggestion $p 'PATIENT_NAME' 8 6),(New-AiUiSuggestion $p 'PATIENT_ADDRESS' 23 6))
 $plan=New-MedicalAiReviewPlan $model $schema $proposals
 Assert-AiUi ($plan.Rows.Count -eq 2 -and @($plan.Rows|Where-Object {$_.Selected}).Count -eq 0) 'Even backend-selected AI suggestions start unchecked in the review plan'
 Assert-AiUi ($model.Parts['word/document.xml'].Xml.OuterXml -ceq $beforeXml) 'Building review proposals never changes Word XML'
 $ids=@($plan.Rows|ForEach-Object {$_.Id});$result=Apply-MedicalAiReviewPlan $model $schema $plan $ids
 Assert-AiUi ($result.Model.Paragraphs[0].Text -ceq 'Ф.И.О.: {{PATIENT_NAME}}; адрес: {{PATIENT_ADDRESS}}.') 'Multiple reviewed ranges in one paragraph apply from right to left'
 Assert-AiUi ($result.AppliedCount -eq 2) 'Applied count records only accepted review rows'
 Assert-AiUi ($model.Parts['word/document.xml'].Xml.OuterXml -ceq $beforeXml -and ($schema|ConvertTo-Json -Depth 40) -ceq $beforeSchema) 'AI application preserves source model and schema atomically'
 $formatNs=Get-MedicalEditorNamespace $result.Model.Paragraphs[0].Node.OwnerDocument
 Assert-AiUi ($result.Model.Paragraphs[0].Node.SelectSingleNode('./w:pPr/w:jc',$formatNs).GetAttribute('val',$formatNs.LookupNamespace('w')) -ceq 'center') 'Range replacement preserves paragraph alignment'
 Assert-AiUi ($null -ne $result.Model.Paragraphs[0].Node.SelectSingleNode('./w:r[2]/w:rPr/w:i',$formatNs)) 'Range replacement preserves the answer run style'
 $path=Join-Path $temp 'reviewed.docx';Write-MedicalTemplateModel $path $result.Model;$reread=Read-MedicalTemplateModel $path
 Assert-AiUi ($reread.Paragraphs[0].Text -ceq $result.Model.Paragraphs[0].Text) 'Reviewed markers survive an actual DOCX round trip'
 Assert-AiUiThrows {Apply-MedicalAiReviewPlan $model $schema $plan @()} 'No checked rows cannot claim a successful application'
 Assert-AiUiThrows {Apply-MedicalAiReviewPlan $model $schema $plan @('unknown')} 'Unknown checkbox row IDs are refused'
 Assert-AiUiThrows {Apply-MedicalAiReviewPlan $model $schema $plan @($ids[0],$ids[0])} 'Repeated review IDs are refused'
 $changed=Copy-MedicalRecognitionModel $model;Set-MedicalTemplateParagraph $changed $changed.Paragraphs[0].Id 'new'
 Assert-AiUiThrows {Apply-MedicalAiReviewPlan $changed $schema $plan $ids} 'Changed document fingerprint blocks stale review'
 $bad=New-AiUiSuggestion $p 'UNKNOWN_MARKER' 8 6;Assert-AiUiThrows {New-MedicalAiReviewPlan $model $schema @($bad)} 'Marker absent from actual schema is refused'
 $bad=New-AiUiSuggestion $p 'PATIENT_NAME' -1 6;Assert-AiUiThrows {New-MedicalAiReviewPlan $model $schema @($bad)} 'Negative AI character offset is refused'
 $bad=New-AiUiSuggestion $p 'PATIENT_NAME' 8 600;Assert-AiUiThrows {New-MedicalAiReviewPlan $model $schema @($bad)} 'Oversized AI range is refused'
 $bad=New-AiUiSuggestion $p 'PATIENT_NAME' 8 6;$bad.OriginalText='different';Assert-AiUiThrows {New-MedicalAiReviewPlan $model $schema @($bad)} 'Mismatched per-row source text is refused'
 $overlap=@((New-AiUiSuggestion $p 'PATIENT_NAME' 8 6),(New-AiUiSuggestion $p 'PATIENT_ADDRESS' 10 3));Assert-AiUiThrows {New-MedicalAiReviewPlan $model $schema $overlap} 'Overlapping AI suggestions cannot reach review application'
 $marked=New-AiUiFixture (New-UniversalParagraph 'Ф.И.О.: {{PATIENT_NAME}}');$bad=New-AiUiSuggestion $marked.Paragraphs[0] 'PATIENT_NAME' 8 16;Assert-AiUiThrows {New-MedicalAiReviewPlan $marked $schema @($bad)} 'AI cannot overwrite an already inserted marker'
 $complex=New-AiUiFixture '<w:p><w:hyperlink><w:r><w:t>Ф.И.О.: Иванов</w:t></w:r></w:hyperlink></w:p>';$bad=New-AiUiSuggestion $complex.Paragraphs[0] 'PATIENT_NAME' 8 6;Assert-AiUiThrows {New-MedicalAiReviewPlan $complex $schema @($bad)} 'Complex protected Word paragraph is refused'
 $empty=[pscustomobject]@{Version=49;AutoTemplate=$false;Template='import.docx';Sections=@([pscustomobject]@{Id='import';Title='Импорт';Fields=@()})}
 $derivedPlan=New-MedicalAiReviewPlan $model $empty @($proposals[0]);Assert-AiUi ($derivedPlan.NewSchema -and $derivedPlan.Rows.Count -eq 2 -and $derivedPlan.Rows[1].Action -ceq 'add-date' -and -not $derivedPlan.Rows[1].Selected) 'Empty imported structure offers a separate unchecked admission date'
 Assert-AiUiThrows {Apply-MedicalAiReviewPlan $model $empty $derivedPlan @($derivedPlan.Rows[0].Id)} 'New reusable form cannot silently omit its required date marker'
 $derived=Apply-MedicalAiReviewPlan $model $empty $derivedPlan @($derivedPlan.Rows|ForEach-Object {$_.Id})
 Assert-AiUi (@(Get-UniversalFields $derived.Schema).Count -eq 1 -and @(Get-UniversalFields $derived.Schema)[0].System -ceq 'name') 'Derived form stores only selected field structure and patient role'
 Assert-AiUi ($derived.Model.Paragraphs[1].Text -ceq 'Дата и время поступления: {{ADMISSION_DATETIME}}') 'Explicitly checked date insertion is written after the document heading'
 # A real isolated runspace executes the production adapter with a deterministic fake inference backend.
 $workerRoot=Join-Path $temp 'worker';$profile=Join-Path $workerRoot 'profile';[void][IO.Directory]::CreateDirectory($profile)
 [IO.File]::Copy((Join-Path $Project 'local-ai-ui-v72.ps1'),(Join-Path $workerRoot 'local-ai-ui-v72.ps1'))
 $stub=@'
function Initialize-MedicalLocalAi($AppRoot,$ProfileRoot){$script:profile=$ProfileRoot}
function Stop-MedicalLocalAiRuntime{[IO.File]::WriteAllText((Join-Path $script:profile 'stopped.txt'),'stopped')}
function Invoke-MedicalLocalAi {
 param($Task,[Alias('Input')][string]$InputText,$Paragraphs,$Schema,$Instruction,$CancellationToken,$TimeoutSeconds)
 if($InputText -ceq 'WAIT'){for($i=0;$i -lt 500;$i++){$CancellationToken.ThrowIfCancellationRequested();[Threading.Thread]::Sleep(10)}}
 if($InputText -ceq 'FAIL'){throw 'deterministic failure'}
 if($Task -eq 'Text'){return [pscustomobject]@{Success=$true;Text=('edited:'+ $InputText+':'+$Instruction);Suggestions=@();Warnings=@();Error='';Provider='fake';Model='fixture'}}
 $proposals=@(foreach($p in $Paragraphs){$index=([string]$p.Text).IndexOf('__',[StringComparison]::Ordinal);if($index -ge 0){[pscustomobject]@{ParagraphId=$p.Id;Marker='PATIENT_NAME';Start=$index;Length=2;OriginalText=$p.Text;Reason='test'}}})
 return [pscustomobject]@{Success=$true;Text='';Suggestions=$proposals;Warnings=@('review');Error='';Provider='fake';Model='fixture'}
}
'@
 [IO.File]::WriteAllText((Join-Path $workerRoot 'local-ai-v72.ps1'),$stub,[Text.Encoding]::UTF8)
 $job=New-MedicalAiUiJob -AppRoot $workerRoot -ProfileRoot $profile -Task Text -InputText 'source' -Instruction 'correct';$answer=Wait-AiUiJob $job
 Assert-AiUi ($answer.Success -and $answer.Text -ceq 'edited:source:correct') 'Actual isolated worker forwards source and custom instruction to inference'
 Assert-AiUi ($job.Disposed -and [IO.File]::ReadAllText((Join-Path $profile 'stopped.txt')) -ceq 'stopped') 'Success disposes the runspace and stops only its owned runtime'
 Assert-AiUiThrows {Complete-MedicalAiUiJob $job} 'Disposed background job cannot be consumed twice'
 [IO.File]::Delete((Join-Path $profile 'stopped.txt'));$job=New-MedicalAiUiJob -AppRoot $workerRoot -ProfileRoot $profile -Task Text -InputText 'WAIT';Request-MedicalAiUiCancellation $job;$cancelAt=$job.CancelAt;Request-MedicalAiUiCancellation $job;$answer=Wait-AiUiJob $job
 Assert-AiUi (-not $answer.Success -and $answer.Cancelled) 'Cancelling a real running worker never yields an applicable answer'
 Assert-AiUi ($job.CancelAt -eq $cancelAt -and $job.Disposed) 'Repeated cancel is idempotent and releases worker resources'
 Assert-AiUi ([IO.File]::Exists((Join-Path $profile 'stopped.txt'))) 'Cancellation unwinds inference finally and stops the owned runtime'
 $job=New-MedicalAiUiJob -AppRoot $workerRoot -ProfileRoot $profile -Task Text -InputText 'FAIL';$answer=Wait-AiUiJob $job
 Assert-AiUi (-not $answer.Success -and $answer.Error -ceq 'Не удалось выполнить запрос локального ИИ.') 'Unhandled inference exception becomes a safe UI error without source text'
 Assert-AiUi ($job.Disposed) 'Inference failure also releases the runspace'
 $long=('а'*650)+'__'+('б'*650)+'__'+('в'*100)
 $job=New-MedicalAiUiJob -AppRoot $workerRoot -ProfileRoot $profile -Task Markers -InputText 'markers' -Paragraphs @([pscustomobject]@{Id='p1';Text=$long}) -Schema @([pscustomobject]@{Marker='PATIENT_NAME';Label='Ф.И.О.'});$answer=Wait-AiUiJob $job
 Assert-AiUi ($answer.Success -and @($answer.Suggestions).Count -eq 2) 'Large paragraph is analyzed by actual worker in bounded model-context chunks'
 Assert-AiUi ($answer.Suggestions[0].Start -eq 650 -and $answer.Suggestions[1].Start -eq 1302) 'Chunk suggestions are mapped back to exact original character offsets'
 Assert-AiUi (@($answer.Suggestions|Where-Object {$_.OriginalText -cne $long -or $_.Selected}).Count -eq 0) 'Aggregated chunk suggestions retain complete source and remain unchecked'
 Assert-AiUi (@(Get-ChildItem -LiteralPath $profile -File).Count -eq 1) 'Worker adapter creates no request or result files containing document text'


 [IO.File]::Delete((Join-Path $profile 'stopped.txt'));$deadlineClock=[Diagnostics.Stopwatch]::StartNew();$job=New-MedicalAiUiJob -AppRoot $workerRoot -ProfileRoot $profile -Task Text -InputText 'WAIT' -TimeoutSeconds 1;$answer=Wait-AiUiJob $job
 Assert-AiUi (-not $answer.Success -and $job.Disposed -and $deadlineClock.Elapsed.TotalSeconds -lt 4) 'Whole worker deadline cancels a task independently of per-request timeouts'
 Assert-AiUi ([IO.File]::Exists((Join-Path $profile 'stopped.txt'))) 'Deadline cancellation executes owned runtime cleanup'
 Assert-AiUi ($answer.Error.StartsWith('Истекло время') -and -not $answer.Cancelled) 'Automatic deadline reports an actionable timeout rather than a silent user cancellation'
 [IO.File]::Delete((Join-Path $profile 'stopped.txt'));$job=New-MedicalAiUiJob -AppRoot $workerRoot -ProfileRoot $profile -Task Text -InputText 'WAIT';[Threading.Thread]::Sleep(80);Stop-MedicalAiUiJob $job
 Assert-AiUi ($job.Disposed -and [IO.File]::Exists((Join-Path $profile 'stopped.txt'))) 'Abnormal dialog cleanup actively drains and disposes its running worker'
 Stop-MedicalAiUiJob $job;Assert-AiUi $job.Disposed 'Abnormal cleanup can be called repeatedly after worker disposal'
 # A neighboring heading and empty answer are submitted together so a model can map that answer.
 $stub=[IO.File]::ReadAllText((Join-Path $workerRoot 'local-ai-v72.ps1'))
 $addition=@'
 if(@($Paragraphs).Count -eq 2 -and $Paragraphs[0].Text -ceq 'Ф.И.О.' -and $Paragraphs[1].Text -ceq ''){return [pscustomobject]@{Success=$true;Text='';Suggestions=@([pscustomobject]@{ParagraphId=$Paragraphs[1].Id;Marker='PATIENT_NAME';Start=0;Length=0;OriginalText='';Reason='adjacent heading'});Warnings=@();Error='';Provider='fake';Model='fixture'}}
 $proposals=@(foreach($p in $Paragraphs)
'@
 $stub=$stub.Replace('$proposals=@(foreach($p in $Paragraphs)',$addition)
 [IO.File]::WriteAllText((Join-Path $workerRoot 'local-ai-v72.ps1'),$stub,[Text.Encoding]::UTF8)
 $job=New-MedicalAiUiJob -AppRoot $workerRoot -ProfileRoot $profile -Task Markers -InputText 'markers' -Paragraphs @([pscustomobject]@{Id='heading';Text='Ф.И.О.'},[pscustomobject]@{Id='answer';Text=''}) -Schema @([pscustomobject]@{Marker='PATIENT_NAME';Label='Ф.И.О.'});$answer=Wait-AiUiJob $job
 Assert-AiUi ($answer.Success -and $answer.Suggestions[0].ParagraphId -ceq 'answer' -and $answer.Suggestions[0].Length -eq 0) 'Heading and adjacent blank paragraph retain their context and original IDs in a bounded batch'
 function Get-AiUiEvent([string]$FunctionName,[string]$Control,[string]$Event){
  $tokens=$null;$errors=$null;$sourceAst=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'local-ai-ui-v72.ps1'),[ref]$tokens,[ref]$errors)
  $functionAst=$sourceAst.Find({param($node)$node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ceq $FunctionName},$false)
  $method=$functionAst.Find({param($node)$node -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $node.Member.Value -ceq $Event -and $node.Expression.Extent.Text -ceq ('$'+$Control)},$true)
  if(-not $method){throw 'Production UI event handler not found.'}
  $block=$method.Find({param($node)$node -is [Management.Automation.Language.ScriptBlockExpressionAst]},$true)
  return $block.ScriptBlock.GetScriptBlock()
 }
 $control=New-Object Windows.Forms.TextBoxBase;$control.Text='Факты {{COMPLAINTS}}';$snapshot=New-MedicalAiTextSnapshot $control
 $before=New-Object Windows.Forms.TextBoxBase;$before.Text=$snapshot.Input;$after=New-Object Windows.Forms.TextBoxBase
 $run=[pscustomobject]@{Enabled=$true};$apply=[pscustomobject]@{Enabled=$false};$copy=[pscustomobject]@{Enabled=$false};$status=[pscustomobject]@{Text=''};$instruction=[pscustomobject]@{Text='Correct language'};$dialog=[pscustomobject]@{Name='fake owner'}
 $state=@{Busy=$false;ResultInput='';HasResult=$false}
 $script:aiProgressCalls=0
 $commands=@{'Show-MedicalAiProgress'={param($Owner,$Task,$InputText,$Instruction)$script:aiProgressCalls++;return [pscustomobject]@{Success=$true;Text='Исправлено {{COMPLAINTS}}';Warnings=@('Проверьте')}};'Apply-MedicalAiTextResult'=(Get-Command Apply-MedicalAiTextResult -CommandType Function)}
 $runClick=(Get-AiUiEvent 'Invoke-MedicalLocalAssistant' 'run' 'Add_Click').GetNewClosure()
 $applyClick=(Get-AiUiEvent 'Invoke-MedicalLocalAssistant' 'apply' 'Add_Click').GetNewClosure()
 $inputChanged=(Get-AiUiEvent 'Invoke-MedicalLocalAssistant' 'before' 'Add_TextChanged').GetNewClosure()
 $copyClick=(Get-AiUiEvent 'Invoke-MedicalLocalAssistant' 'copy' 'Add_Click').GetNewClosure()
 & $runClick
 Assert-AiUi ($state.HasResult -and $apply.Enabled -and $copy.Enabled -and $after.Text -ceq 'Исправлено {{COMPLAINTS}}') 'Actual inference button callback makes reviewed output available for the unchanged target'
 Assert-AiUi ($control.Text -ceq 'Факты {{COMPLAINTS}}') 'Inference button callback does not auto-apply the result'
 & $applyClick
 Assert-AiUi ($control.Text -ceq 'Исправлено {{COMPLAINTS}}' -and -not $apply.Enabled) 'Actual apply callback uses the guarded explicit text replacement'
 $control.Text='patient edited';$apply.Enabled=$true;& $applyClick
 Assert-AiUi ($control.Text -ceq 'patient edited' -and $status.Text.Contains('изменился')) 'Actual apply callback catches stale source without losing patient changes'
 & $inputChanged
 Assert-AiUi (-not $state.HasResult -and -not $apply.Enabled -and -not $copy.Enabled) 'Actual source-text change callback invalidates previous inference output'
 [Windows.Forms.Clipboard]::Calls=0;$state.HasResult=$false;& $copyClick
 Assert-AiUi ([Windows.Forms.Clipboard]::Calls -eq 0) 'Copy callback refuses an invalidated inference result'
 $state.HasResult=$true;& $copyClick
 Assert-AiUi ([Windows.Forms.Clipboard]::Calls -eq 1 -and [Windows.Forms.Clipboard]::Last -ceq $after.Text) 'Actual copy command exports only after explicit click on a valid result'
 $state.Busy=$true;$after.Text='unchanged';& $runClick
 Assert-AiUi ($after.Text -ceq 'unchanged') 'Actual inference button ignores reentrant requests'
 $state.Busy=$false;$before.Text='';$run.Enabled=$true;& $runClick
 Assert-AiUi ($status.Text -ceq 'Введите текст в левое поле.' -and $run.Enabled) 'Actual inference button refuses empty input without disabling the dialog'

 $job=New-MedicalAiUiJob -AppRoot $workerRoot -ProfileRoot $profile -Task Text -InputText 'WAIT';$state=@{AllowClose=$false};$cancel=[pscustomobject]@{Enabled=$true};$label=[pscustomobject]@{Text=''}
 $commands=@{'Request-MedicalAiUiCancellation'=(Get-Command Request-MedicalAiUiCancellation -CommandType Function)}
 $uiTokens=$null;$uiErrors=$null;$uiAst=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'local-ai-ui-v72.ps1'),[ref]$uiTokens,[ref]$uiErrors)
 $progressAst=$uiAst.Find({param($node)$node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ceq 'Show-MedicalAiProgress'},$false)
 $cancelAssignment=$progressAst.Find({param($node)$node -is [Management.Automation.Language.AssignmentStatementAst] -and $node.Left.Extent.Text -ceq '$cancelAction'},$true)
 $cancelBlock=$cancelAssignment.Find({param($node)$node -is [Management.Automation.Language.ScriptBlockExpressionAst]},$true)
 $cancelAction=$cancelBlock.ScriptBlock.GetScriptBlock().GetNewClosure();$formClosing=(Get-AiUiEvent 'Show-MedicalAiProgress' 'dialog' 'Add_FormClosing').GetNewClosure();$eventArgs=[pscustomobject]@{Cancel=$false}
 & $formClosing $null $eventArgs
 Assert-AiUi ($eventArgs.Cancel -and $job.Cancellation.IsCancellationRequested -and -not $cancel.Enabled) 'Actual close event first cancels active inference and defers disposal until cleanup'
 Stop-MedicalAiUiJob $job
 Assert-AiUi $job.Disposed 'Close-cancel path drains the real worker before disposing the progress window'
 $state.AllowClose=$true;$eventArgs.Cancel=$false;& $formClosing $null $eventArgs
 Assert-AiUi (-not $eventArgs.Cancel) 'Completed cleanup allows the progress window to close normally'

 $state=@{Result=$null};$status=[pscustomobject]@{Text=''};$dialog=[pscustomobject]@{DialogResult='';Closed=$false};$dialog|Add-Member ScriptMethod Close {$this.Closed=$true}
 $grid=[pscustomobject]@{Rows=@(foreach($proposal in $plan.Rows){[pscustomobject]@{Tag=$proposal;Cells=@{Apply=[pscustomobject]@{Value=$false}}}})};$grid|Add-Member ScriptMethod EndEdit {return $true}
 $commands=@{'Apply-MedicalAiReviewPlan'=(Get-Command Apply-MedicalAiReviewPlan -CommandType Function)}
 $reviewApply=(Get-AiUiEvent 'Invoke-MedicalAiTemplateRecognition' 'apply' 'Add_Click').GetNewClosure();& $reviewApply
 Assert-AiUi ($null -eq $state.Result -and -not $dialog.Closed -and $status.Text.Contains('Отметьте')) 'Actual marker-review apply event refuses an empty checkbox selection'
 $grid.Rows[0].Cells.Apply.Value=$true;& $reviewApply
 Assert-AiUi ($state.Result.AppliedCount -eq 1 -and $dialog.Closed -and $dialog.DialogResult -ceq 'OK') 'Actual marker-review apply event applies exactly the checked row and closes review'
 Assert-AiUi ($model.Parts['word/document.xml'].Xml.OuterXml -ceq $beforeXml) 'Actual marker-review event returns a private copy without mutating its working source'
 # Inspect actual event scriptblocks, not a duplicated implementation.
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'local-ai-ui-v72.ps1'),[ref]$tokens,[ref]$errors)
 $handlers=@($ast.FindAll({param($n)$n -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $n.Member.Value -like 'Add_*'},$true))
 Assert-AiUi ($handlers.Count -ge 14) 'Parser discovers production UI handlers for progress, settings and explicit review'
 $text=[IO.File]::ReadAllText((Join-Path $Project 'local-ai-ui-v72.ps1'))
 Assert-AiUi ($text -match 'finally\{Stop-MedicalLocalAiRuntime\}') 'Worker owns cleanup in a finally block around both inference tasks'
 Assert-AiUi (-not ($text -match 'Invoke-WebRequest|Invoke-RestMethod|WebClient|WriteAllText|Export-Clixml')) 'UI module never writes document requests or starts an implicit download'
 Assert-AiUi ($text.Contains('$download.Add_Click') -and $text.Contains("& $"+"commands['Install-MedicalAiModel']")) 'Model acquisition is reachable only through its explicit settings button'
 Assert-AiUi ($text.Contains('$copy.Add_Click') -and ([regex]::Matches($text,'Clipboard\]::SetText').Count -eq 1)) 'Clipboard export has exactly one explicit user command'
 Write-Output ('Completed '+$script:checks+' AI UI checks.')
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
