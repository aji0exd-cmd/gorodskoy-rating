﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v72'))
$ErrorActionPreference='Stop';$script:checks=0;$script:renderCalls=0;$script:wordLaunches=0
function Assert-Cache([bool]$test,[string]$message){if(-not $test){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
function Assert-CacheRejected([scriptblock]$operation,[string]$message){$caught=$false;try{& $operation | Out-Null}catch{$caught=$true};Assert-Cache $caught $message}
function Import-CacheFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors);if($errors.Count){throw ($errors|Out-String)}
 foreach($node in $ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}}
}
function Invoke-CacheExport([string]$path,[bool]$allowIncomplete=$true,[string]$failure=''){
 New-HospitalizationComMock
 if($failure -eq 'save'){$script:mock.FailSave=$true}
 $beforeRender=$script:renderCalls;$beforeWord=$script:wordLaunches;$watch=[Diagnostics.Stopwatch]::StartNew()
 Export-MedicalHospitalizationDocument $path $allowIncomplete
 $watch.Stop();return [pscustomobject]@{Milliseconds=$watch.Elapsed.TotalMilliseconds;Renders=($script:renderCalls-$beforeRender);WordLaunches=($script:wordLaunches-$beforeWord)}
}
function Assert-CacheMiss([string]$message){$run=Invoke-CacheExport $script:output;Assert-Cache ($run.Renders -eq @(Get-MedicalHospitalizationContexts).Count -and $run.WordLaunches -eq 1) $message}
function Assert-CacheHit([string]$message){$run=Invoke-CacheExport $script:output;Assert-Cache ($run.Renders -eq 0 -and $run.WordLaunches -eq 0) $message}
function Set-CacheHeader([string]$path,[string]$sentinel){
 $archive=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{
  $old=$archive.GetEntry('word/header1.xml');if($old){$old.Delete()}
  $entry=$archive.CreateEntry('word/header1.xml',[IO.Compression.CompressionLevel]::NoCompression);$entry.LastWriteTime=[datetimeoffset]'2020-01-01T00:00:00Z'
  $bytes=[Text.Encoding]::UTF8.GetBytes('<w:hdr xmlns:w="'+$script:ns+'"><w:p><w:r><w:t>'+ $sentinel+'</w:t></w:r></w:p></w:hdr>');$stream=$entry.Open();try{$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
 }finally{$archive.Dispose()}
}
function Add-CacheField([string]$path,[string]$code){
 $archive=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{
  $xml=Get-MedicalDiaryXml $archive 'word/document.xml';$n=New-Object Xml.XmlNamespaceManager($xml.NameTable);$n.AddNamespace('w',$script:ns);$body=$xml.SelectSingleNode('/w:document/w:body',$n);$section=$body.SelectSingleNode('w:sectPr',$n)
  $paragraph=$xml.CreateElement('w','p',$script:ns);$field=$xml.CreateElement('w','fldSimple',$script:ns);[void]$field.SetAttribute('instr',$script:ns,$code);$run=$xml.CreateElement('w','r',$script:ns);$text=$xml.CreateElement('w','t',$script:ns);$text.InnerText='FIELD RESULT';[void]$run.AppendChild($text);[void]$field.AppendChild($run);[void]$paragraph.AppendChild($field);[void]$body.InsertBefore($paragraph,$section);Set-MedicalDiaryXml $archive 'word/document.xml' $xml
 }finally{$archive.Dispose()}
}
function Add-CacheExternalRelationship([string]$path,[string]$type,[string]$target){
 $archive=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{
  $xml=Get-MedicalDiaryXml $archive 'word/_rels/document.xml.rels';$namespace='http://schemas.openxmlformats.org/package/2006/relationships';if(-not $xml){$xml=[xml]('<Relationships xmlns="'+$namespace+'"/>')}
  $relation=$xml.CreateElement('Relationship',$namespace);[void]$relation.SetAttribute('Id',('testExternal'+[guid]::NewGuid().ToString('N')));[void]$relation.SetAttribute('Type',('http://schemas.openxmlformats.org/officeDocument/2006/relationships/'+$type));[void]$relation.SetAttribute('TargetMode','External');[void]$relation.SetAttribute('Target',$target);[void]$xml.DocumentElement.AppendChild($relation);Set-MedicalDiaryXml $archive 'word/_rels/document.xml.rels' $xml
 }finally{$archive.Dispose()}
}
function Set-CacheDropdownOption([string]$path,[string]$option){
 $archive=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{
  $xml=Get-MedicalDiaryXml $archive 'word/document.xml';$n=New-Object Xml.XmlNamespaceManager($xml.NameTable);$n.AddNamespace('w',$script:ns)
  $item=$xml.SelectSingleNode('//w:sdt[w:sdtPr/w:id[@w:val="314159"]]/w:sdtPr/w:dropDownList/w:listItem',$n)
  if(-not $item){
   $fragment=[xml]('<w:p xmlns:w="'+$script:ns+'"><w:sdt><w:sdtPr><w:id w:val="314159"/><w:tag w:val="CACHE_CHOICE"/><w:dropDownList><w:listItem w:displayText="OPTION_A" w:value="OPTION_A"/></w:dropDownList></w:sdtPr><w:sdtContent><w:r><w:t>SELECT</w:t></w:r></w:sdtContent></w:sdt></w:p>')
   $body=$xml.SelectSingleNode('/w:document/w:body',$n);[void]$body.InsertBefore($xml.ImportNode($fragment.DocumentElement,$true),$body.SelectSingleNode('w:sectPr',$n));$item=$xml.SelectSingleNode('//w:sdt[w:sdtPr/w:id[@w:val="314159"]]/w:sdtPr/w:dropDownList/w:listItem',$n)
  }
  [void]$item.SetAttribute('displayText',$script:ns,$option);[void]$item.SetAttribute('value',$script:ns,$option)
  $archive.GetEntry('word/document.xml').Delete();$entry=$archive.CreateEntry('word/document.xml',[IO.Compression.CompressionLevel]::NoCompression);$entry.LastWriteTime=[datetimeoffset]'2020-01-01T00:00:00Z';$bytes=[Text.Encoding]::UTF8.GetBytes($xml.OuterXml);$stream=$entry.Open();try{$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
 }finally{$archive.Dispose()}
}
function Get-CachePackageParts([string]$path){$archive=[IO.Compression.ZipFile]::OpenRead($path);try{return @($archive.Entries.FullName)}finally{$archive.Dispose()}}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-word-cache-tests-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 Add-Type -AssemblyName System.IO.Compression;Add-Type -AssemblyName System.IO.Compression.FileSystem
 Import-CacheFunctions (Join-Path $PSScriptRoot 'verify-diary-document.ps1') @('Read-DiaryPart','Get-DiaryText','New-TestRange','New-TestHeaderCollection','New-TestSection','New-DiaryComMock')
 Import-CacheFunctions (Join-Path $PSScriptRoot 'verify-hospitalization-document.ps1') @('New-HospitalizationComMock','New-HospitalizationAuthoredTemplate')
 Import-CacheFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
 foreach($module in @('universal.ps1','forms-v59.ps1','clinical-stages-v67.ps1','diary-document-v67.ps1','hospitalization-document-v68.ps1')){Import-CacheFunctions (Join-Path $Project $module)}
 if([IO.File]::Exists((Join-Path $Project 'diary-period-v69.ps1'))){Import-CacheFunctions (Join-Path $Project 'diary-period-v69.ps1')}
 $script:realSaveUniversalDocument=(Get-Command Save-UniversalDocument).ScriptBlock
 function Save-UniversalDocument($output,$config,$values,[datetime]$admission,$details=$script:universalDetails,[bool]$allowIncomplete=$false,[string]$documentStage=''){$script:renderCalls++;& $script:realSaveUniversalDocument $output $config $values $admission $details $allowIncomplete $documentStage}
 function New-MedicalDiaryWordApplication {$script:wordLaunches++;return $script:mock.Application}
 function Load-DocumentFont {return $script:testFont}
 function Apply-DocumentFont($path){throw 'Authored fixtures must preserve their template fonts'}
 $script:testFont=[pscustomobject]@{Enabled=$false;Name='Times New Roman';Size=12}
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main';$script:medicalProgramRoot=$temp;$script:medicalTemplatesFolder=Join-Path $temp 'Шаблоны'
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-01T09:45:00'}
 $script:universalConfig=New-UniversalConfig;$script:universalValues=@{};$script:universalDetails=@{}
 foreach($field in Get-UniversalFields $script:universalConfig){$script:universalValues[[string]$field.Id]='ТЕСТ '+[string]$field.Id}
 $script:universalValues.patient_name='ТЕСТОВЫЙ ПАЦИЕНТ';$script:universalValues.patient_birth='01.01.2000';$script:universalValues.complaints='ЖАЛОБЫ'
 $script:universalConfig=New-HospitalizationAuthoredTemplate $script:universalConfig 'initial' 'Arial' 22 1000 'ИСХОДНЫЙ ТЕКСТ';$initialSource=Get-UniversalTemplatePath $script:universalConfig
 Set-CacheHeader $initialSource 'HEADER_A'
 [void](Initialize-MedicalClinicalWorkspace);$first=Add-MedicalClinicalDiary;Set-MedicalClinicalDate $first.Id ([datetime]'2026-10-02T10:00:00')
 Set-MedicalClinicalValue 'diary' $first.Id 'diary_complaints' 'ДНЕВНИК ПАЦИЕНТА'
 [void](Set-MedicalTreatmentPeriod '2026-10-01' '2026-10-10')
 $script:output=Join-Path $temp 'Preview.docx';$cold=Invoke-CacheExport $script:output
 Assert-Cache ($cold.Renders -eq 3 -and $cold.WordLaunches -eq 1) 'Cold export uses all three real stage renderers and one mocked native Word merge'
 $original=Get-MedicalHospitalizationFileHash $script:output;$private=Get-MedicalHospitalizationFileHash $script:medicalHospitalizationRenderCache.Path
 Assert-Cache ($original -ceq $private -and $script:medicalHospitalizationRenderCache.Path -cne $script:output) 'Completed private render has exact exported bytes and a distinct path'
 Assert-CacheHit 'Repeated preview reuses a completed render without stage rendering or starting Word'
 Assert-Cache ((Get-MedicalHospitalizationFileHash $script:output) -ceq $original) 'Cache hit atomically copies the exact previously completed DOCX'
 $cacheFolder=[string]$script:medicalHospitalizationRenderCache.Folder
 Assert-Cache (@(Get-ChildItem -LiteralPath $cacheFolder -File).Count -eq 1) 'The session cache retains exactly one completed file'
 $archive=[IO.Compression.ZipFile]::Open($script:output,[IO.Compression.ZipArchiveMode]::Update)
 try{Set-MedicalDiaryXml $archive 'customXml/mc-case.xml' ([xml]'<case>PRIVATE CARD METADATA</case>');$xml=Get-MedicalDiaryXml $archive 'word/document.xml';$node=$xml.GetElementsByTagName('t',$script:ns)[0];$node.InnerText='EXTERNAL WORD EDIT';Set-MedicalDiaryXml $archive 'word/document.xml' $xml}finally{$archive.Dispose()}
 Assert-CacheHit 'Adding card metadata or editing the caller export cannot contaminate the private render'
 Assert-Cache ((Get-MedicalHospitalizationFileHash $script:output) -ceq $original -and 'customXml/mc-case.xml' -notin @(Get-CachePackageParts $script:output)) 'A later preview contains original rendered bytes without the saved-card envelope'
 $reordered=@{};[string[]]$keys=@($script:universalValues.Keys);[Array]::Sort($keys,[StringComparer]::Ordinal);[Array]::Reverse($keys);foreach($key in $keys){$reordered[$key]=$script:universalValues[$key]};$script:universalValues=$reordered
 Assert-CacheHit 'Dictionary insertion order does not change the canonical render fingerprint'
 $oldCulture=[Threading.Thread]::CurrentThread.CurrentCulture
 try{[Threading.Thread]::CurrentThread.CurrentCulture=[Globalization.CultureInfo]'ru-RU';Assert-CacheHit 'Fingerprint remains stable across current culture changes'}finally{[Threading.Thread]::CurrentThread.CurrentCulture=$oldCulture}
 $script:universalValues.complaints='НОВЫЕ ЖАЛОБЫ';Assert-CacheMiss 'Changing initial examination answers invalidates the completed render'
 Assert-Cache ((Get-DiaryText $script:output).Contains('НОВЫЕ ЖАЛОБЫ')) 'A changed answer reaches the real DOCX rather than stale cached text'
 $script:universalDetails.complaints='ИЗМЕНЕННОЕ УТОЧНЕНИЕ';Assert-CacheMiss 'Changing clarification data invalidates the completed render'
 $script:universalConfig.Sections[0].Title='НОВОЕ НАЗВАНИЕ';Assert-CacheMiss 'Changing the form structure invalidates the completed render'
 $script:admissionControl.Value=[datetime]'2026-10-01T12:34:00';Assert-CacheMiss 'Corrected initial examination time invalidates the completed render'
 Assert-Cache ((Get-DiaryText $script:output).Contains('01.10.2026 12:34')) 'Corrected admission time reaches the repeated real DOCX export'
 Set-MedicalClinicalDate $first.Id ([datetime]'2026-10-03T11:45:00');Assert-CacheMiss 'Changing a diary timestamp invalidates the completed render'
 Set-MedicalClinicalValue 'diary' $first.Id 'diary_complaints' 'ДРУГОЙ ДНЕВНИК';Assert-CacheMiss 'Changing a diary answer invalidates the completed render'
 Set-MedicalDiaryDateCount $first.Id 2;Set-MedicalDiaryDates $first.Id ([datetime]'2026-10-03T11:45:00') ([datetime]'2026-10-04T16:15:00');Assert-CacheMiss 'Selecting two diary dates invalidates the completed render'
 $rangeContext=@(Get-MedicalHospitalizationContexts)[1];$rangeMetadata=(Read-UniversalDocumentState $script:output).Stages[1]
 Assert-Cache ($rangeContext.DateCount -eq 2 -and $rangeContext.EndDateTime -eq [datetime]'2026-10-04T16:15:00' -and $rangeMetadata.DateCount -eq 2 -and $rangeMetadata.EndDateTime -eq '2026-10-04T16:15:00') 'Complete rendered collection metadata preserves the selected diary date mode and end timestamp'
 Assert-Cache ((Get-DiaryText $script:output).Contains('03.10.2026 11:45') -and (Get-DiaryText $script:output).Contains('04.10.2026 16:15')) 'Both selected diary dates reach the rendered full hospitalization'
 Set-MedicalDiaryDates $first.Id ([datetime]'2026-10-03T11:45:00') ([datetime]'2026-10-05T17:25:00');Assert-CacheMiss 'Editing only the second diary timestamp invalidates the completed render'
 Set-MedicalDiaryDateCount $first.Id 1;Assert-CacheMiss 'Switching a diary back to one date invalidates the completed render'
 Set-MedicalClinicalValue 'discharge' '' 'complaints' 'РУЧНАЯ ПРАВКА ЭПИКРИЗА';Assert-CacheMiss 'Manual discharge edits invalidate the completed render'
 [void](Set-MedicalTreatmentPeriod '2026-10-01' '2026-10-11');Assert-CacheMiss 'Changing the treatment period invalidates the completed render'
 Assert-Cache ((Get-DiaryText $script:output).Contains('01.10.2026 — 11.10.2026')) 'The date-only discharge period updates in the real DOCX'
 $script:testFont=[pscustomobject]@{Enabled=$false;Name='Calibri';Size=11};Assert-CacheMiss 'Common document font settings participate in render invalidation'
 $size=([IO.FileInfo]$initialSource).Length;$mtime=[IO.File]::GetLastWriteTimeUtc($initialSource);Set-CacheHeader $initialSource 'HEADER_B';[IO.File]::SetLastWriteTimeUtc($initialSource,$mtime)
 Assert-Cache (([IO.FileInfo]$initialSource).Length -eq $size -and [IO.File]::GetLastWriteTimeUtc($initialSource) -eq $mtime) 'The authored-template mutation fixture preserves file size and modification time'
 Assert-CacheMiss 'Full source hashing detects same-size same-time external header edits'
 $header=[xml][Text.Encoding]::UTF8.GetString($script:renderedSnapshots[0].Parts['word/header1.xml']);Assert-Cache (([string]$header.DocumentElement.InnerText).Contains('HEADER_B')) 'Changed authored header bytes reach the renderer after invalidation'
 $lastHash=Get-MedicalHospitalizationFileHash $script:output;$lastKey=[string]$script:medicalHospitalizationRenderCache.Key
 $sourceBytes=[IO.File]::ReadAllBytes($initialSource);[IO.File]::Delete($initialSource)
 try{Assert-CacheRejected {Invoke-CacheExport $script:output} 'Deleting an authored source is rejected before a cache hit can hide the missing template';Assert-Cache ((Get-MedicalHospitalizationFileHash $script:output) -ceq $lastHash -and $script:mock.Opened.Count -eq 0) 'Missing source preserves the previous output and starts no Word instance'}finally{[IO.File]::WriteAllBytes($initialSource,$sourceBytes)}
 Assert-CacheHit 'Restoring identical source bytes permits the previous completed render to be reused'
 $plainSource=[IO.File]::ReadAllBytes($initialSource)
 Add-CacheField $initialSource 'PAGE';Add-CacheField $initialSource 'NUMPAGES';Add-CacheField $initialSource 'HYPERLINK "https://example.invalid"';Add-CacheExternalRelationship $initialSource 'hyperlink' 'https://example.invalid'
 Assert-CacheMiss 'Ordinary page fields and clickable hyperlinks can produce a completed cached render'
 Assert-CacheHit 'Static page fields and ordinary external hyperlinks retain repeated-render caching'
 Add-CacheField $initialSource 'DATE \@ "dd.MM.yyyy"';Assert-CacheMiss 'A volatile Word date field bypasses completed-render reuse'
 Assert-CacheMiss 'Unchanged templates containing volatile Word fields rerender rather than freezing native field results'
 [IO.File]::WriteAllBytes($initialSource,$plainSource);Assert-CacheMiss 'Returning to a static authored template restores ordinary render caching';Assert-CacheHit 'Static authored templates remain reusable after volatile-field exports'
 $external=Join-Path $temp 'external-resource.bin';[IO.File]::WriteAllText($external,'RESOURCE A');Add-CacheExternalRelationship $initialSource 'image' $external
 Assert-CacheMiss 'An externally linked rendered resource bypasses completed-render caching'
 $linkedSourceHash=Get-MedicalHospitalizationFileHash $initialSource;[IO.File]::WriteAllText($external,'RESOURCE B')
 Assert-CacheMiss 'Changing an external resource requires rendering even when the DOCX package itself is unchanged'
 Assert-Cache ((Get-MedicalHospitalizationFileHash $initialSource) -ceq $linkedSourceHash) 'The external-resource fixture changes no source DOCX bytes and performs no network fetch'
 [IO.File]::WriteAllBytes($initialSource,$plainSource);Assert-CacheHit 'Returning to the prior static template can reuse the last matching successful completed render'

 $script:universalValues.complaints='';[void](Invoke-CacheExport $script:output $true);$incompleteHash=Get-MedicalHospitalizationFileHash $script:output
 Assert-CacheRejected {Invoke-CacheExport $script:output $false} 'A permissive preview never bypasses strict required-field validation on a cache hit'
 Assert-Cache ((Get-MedicalHospitalizationFileHash $script:output) -ceq $incompleteHash -and $script:mock.Opened.Count -eq 0) 'Strict required-field rejection is atomic and does not start Word'
 $script:universalValues.complaints='НОВЫЕ ЖАЛОБЫ';$script:universalValues.patient_birth='31.02.2000';[void](Invoke-CacheExport $script:output $true)
 Assert-CacheRejected {Invoke-CacheExport $script:output $false} 'A permissive cached birth date still fails strict date validation'
 $script:universalValues.patient_birth='01.01.2000';[void](Invoke-CacheExport $script:output $true)
 $stableKey=[string]$script:medicalHospitalizationRenderCache.Key;$stableHash=Get-MedicalHospitalizationFileHash $script:output
 $script:universalValues.complaints='ЭКСПОРТ С ОШИБКОЙ'
 Assert-CacheRejected {Invoke-CacheExport $script:output $true 'save'} 'A failed native merge cannot publish an incomplete completed-render cache'
 Assert-Cache ($script:medicalHospitalizationRenderCache.Key -ceq $stableKey -and (Get-MedicalHospitalizationFileHash $script:output) -ceq $stableHash) 'Failed rerender retains both the last good private render and saved card'
 $script:universalValues.complaints='НОВЫЕ ЖАЛОБЫ';Assert-CacheHit 'Reverting after a failed render reuses the last successful matching render'
 $archive=[IO.Compression.ZipFile]::Open($script:medicalHospitalizationRenderCache.Path,[IO.Compression.ZipArchiveMode]::Update);try{Set-MedicalDiaryXml $archive 'customXml/tampered.xml' ([xml]'<tampered/>')}finally{$archive.Dispose()}
 Assert-CacheMiss 'Tampered private cache bytes are rejected and rebuilt through the real stage pipeline'
 Assert-Cache ('customXml/tampered.xml' -notin @(Get-CachePackageParts $script:output)) 'Corrupt cache content never reaches the exported DOCX'
 $stableKey=[string]$script:medicalHospitalizationRenderCache.Key;$blocked=Join-Path $temp 'Blocked.docx';[void][IO.Directory]::CreateDirectory($blocked);$keep=Join-Path $blocked 'keep.txt';[IO.File]::WriteAllText($keep,'KEEP')
 Assert-CacheRejected {Invoke-CacheExport $blocked} 'An invalid destination is rejected atomically even when the render is cached'
 Assert-Cache ($script:medicalHospitalizationRenderCache.Key -ceq $stableKey -and [IO.File]::ReadAllText($keep) -ceq 'KEEP' -and $script:mock.Opened.Count -eq 0) 'Destination failure retains the private render and directory contents without native Word work'
 Assert-CacheRejected {Invoke-CacheExport $initialSource} 'A cached render still cannot overwrite any authored Word template'
 Assert-CacheRejected {Invoke-CacheExport (Join-Path $temp 'Wrong.dotx')} 'A cached render still requires a DOCX destination'
 # Blank reusable diary blueprints can be outside the selected patient period.
 [void](Initialize-MedicalClinicalWorkspace);for($index=0;$index -lt 3;$index++){[void](Add-MedicalClinicalDiary)};$form=Get-MedicalClinicalFormData;[void](Initialize-MedicalClinicalWorkspace $form);[void](Add-MedicalClinicalDiaryPeriod '2026-10-01' '2026-10-02')
 $unusedId=[string]$script:medicalClinicalForms.Diaries[2].Id;$unusedSchema=New-HospitalizationAuthoredTemplate $script:medicalClinicalForms.Diaries[2].Schema 'unused' 'Tahoma' 22 1100 'НЕИСПОЛЬЗУЕМЫЙ ШАБЛОН';[void](Set-MedicalClinicalSchema 'diary' $unusedId $unusedSchema);$unusedSource=Get-UniversalTemplatePath $unusedSchema
 [void](Invoke-CacheExport $script:output);Assert-Cache (@(Get-MedicalHospitalizationContexts).Count -eq 3) 'Unused form blueprints remain omitted from the patient document'
 Assert-CacheHit 'The patient render is reusable while unused blueprints remain unchanged'
 Assert-CacheRejected {Invoke-CacheExport $unusedSource} 'A cache hit protects the Word source of an omitted diary blueprint'
 Set-CacheHeader $unusedSource 'UNUSED_A';Assert-CacheMiss 'An externally edited omitted blueprint invalidates the full form fingerprint'
 $unusedBytes=[IO.File]::ReadAllBytes($unusedSource);[IO.File]::Delete($unusedSource);Assert-CacheMiss 'Deletion of an omitted blueprint cannot accidentally reuse a stale full-form fingerprint';[IO.File]::WriteAllBytes($unusedSource,$unusedBytes)
 Assert-CacheMiss 'Restoring an omitted authored source refreshes the full form fingerprint'
 $secondId=[string]$script:medicalClinicalForms.Diaries[1].Id;Set-MedicalClinicalValue 'diary' $secondId 'diary_complaints' 'ДОПОЛНИТЕЛЬНАЯ ЗАПИСЬ';Assert-CacheMiss 'Authoring a previously omitted diary invalidates the ordered rendered-context collection'
 $definitions=@($script:medicalClinicalForms.Diaries);$patients=@($script:medicalClinicalState.Diaries);$script:medicalClinicalForms.Diaries=@($definitions[1],$definitions[0],$definitions[2]);$script:medicalClinicalState.Diaries=@($patients[1],$patients[0],$patients[2]);Assert-CacheMiss 'Reordering diaries invalidates the render and preserves explicit collection order'
 # Deterministic canonical shape tests include null and empty arrays.
 $a=[ordered]@{z=@($null,@(),@{b=2;a=1});a='А'};$b=[ordered]@{a='А';z=@($null,@(),[ordered]@{a=1;b=2})}
 $aJson=ConvertTo-Json -InputObject (ConvertTo-MedicalHospitalizationCanonicalValue $a) -Depth 100 -Compress;$bJson=ConvertTo-Json -InputObject (ConvertTo-MedicalHospitalizationCanonicalValue $b) -Depth 100 -Compress
 Assert-Cache ($aJson -ceq $bJson -and $aJson.Contains('[null,[],{"a":1,"b":2}]')) 'Canonical keys preserve array order, nulls and empty arrays while sorting object members'
 # Measure the same real OOXML fixture with native Word calls mocked. This is
 # instrumentation, not a claimed desktop Word or UI acceleration factor.
 $coldTimes=@();$hitTimes=@();$coldRenders=0;$coldWords=0;$hitRenders=0;$hitWords=0
 for($index=0;$index -lt 3;$index++){
  Clear-MedicalHospitalizationRenderCache;$run=Invoke-CacheExport $script:output;$coldTimes+=@($run.Milliseconds);$coldRenders+=$run.Renders;$coldWords+=$run.WordLaunches
  for($repeat=0;$repeat -lt 3;$repeat++){$run=Invoke-CacheExport $script:output;$hitTimes+=@($run.Milliseconds);$hitRenders+=$run.Renders;$hitWords+=$run.WordLaunches}
 }
 $coldTimes=@($coldTimes|Sort-Object);$hitTimes=@($hitTimes|Sort-Object)
 $benchmark=[pscustomobject]@{Environment='Linux PowerShell 7; real OOXML rendering and file copies; native Word COM mocked';ColdRuns=$coldTimes.Count;WarmRuns=$hitTimes.Count;ColdMedianMilliseconds=[Math]::Round($coldTimes[1],2);WarmMedianMilliseconds=[Math]::Round($hitTimes[4],2);ColdStageRenders=$coldRenders;WarmStageRenders=$hitRenders;ColdMockWordLaunches=$coldWords;WarmMockWordLaunches=$hitWords;NativeWindowsWordMeasured=$false}
 [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'word-cache-benchmark.json'),($benchmark|ConvertTo-Json), (New-Object Text.UTF8Encoding($true)))
 Assert-Cache ($coldRenders -eq (3*@(Get-MedicalHospitalizationContexts).Count) -and $hitRenders -eq 0 -and $coldWords -eq 3 -and $hitWords -eq 0) 'Measured warm runs avoid all repeated OOXML render and mocked native Word composition calls'
 # A fast UI schema signature may deliberately trust unchanged file metadata.
 # The explicit export boundary must force source bytes before cloning discharge.
 $schema=New-UniversalConfig;$choice=New-UniversalField 'cache_choice' 'Внешний список' 'CACHE_CHOICE' 'choice';$choice.WordId='314159';$choice.Required=$false;$schema.Sections[0].Fields+=@($choice)
 $script:universalConfig=New-HospitalizationAuthoredTemplate $schema 'sdt-source' 'Arial' 22 1000 'SDT SOURCE';$sdtSource=Get-UniversalTemplatePath $script:universalConfig;Set-CacheDropdownOption $sdtSource 'OPTION_A'
 [void](Initialize-MedicalClinicalWorkspace);[void](Invoke-CacheExport $script:output)
 $beforeOption=(Get-MedicalClinicalField $script:medicalClinicalForms.Discharge.Schema 'cache_choice').Options
 Assert-Cache (@($beforeOption).Count -eq 1 -and $beforeOption[0] -ceq 'OPTION_A') 'Automatic discharge initially captures authored Word dropdown options'
 $stamp=[IO.File]::GetLastWriteTimeUtc($sdtSource);$length=([IO.FileInfo]$sdtSource).Length;Set-CacheDropdownOption $sdtSource 'OPTION_B';[IO.File]::SetLastWriteTimeUtc($sdtSource,$stamp)
 Assert-Cache (([IO.FileInfo]$sdtSource).Length -eq $length -and [IO.File]::GetLastWriteTimeUtc($sdtSource) -eq $stamp) 'External SDT option edit preserves source file length and modification time'
 $freshContexts=@(Get-MedicalHospitalizationContexts);$freshChoice=Get-MedicalClinicalField $freshContexts[-1].Schema 'cache_choice'
 Assert-Cache ($freshChoice.Options[0] -ceq 'OPTION_B') 'Export context construction forces a byte check before cloning automatic discharge dropdown options'
 Assert-CacheMiss 'Same-size same-time source dropdown edits invalidate the completed hospitalization render'
 $metadata=Read-UniversalDocumentState $script:output;$savedChoice=Get-MedicalClinicalField $metadata.Stages[-1].Schema 'cache_choice'
 Assert-Cache ($savedChoice.Options[0] -ceq 'OPTION_B') 'Saved complete-card metadata contains refreshed discharge dropdown options'
 $folder=[string]$script:medicalHospitalizationRenderCache.Folder;Clear-MedicalHospitalizationRenderCache
 Assert-Cache ($null -eq $script:medicalHospitalizationRenderCache -and -not [IO.Directory]::Exists($folder)) 'Explicit normal-close cleanup removes the private completed render and session directory'
 Write-Output ('Completed '+$script:checks+' word-cache checks. Real authored/generated DOCX inputs, rendering, hashing, invalidation and atomic files verified; native Word COM is mocked. No desktop Word timing or Windows UI timing is claimed.')
 Write-Output ($benchmark|ConvertTo-Json -Compress)
}finally{Clear-MedicalHospitalizationRenderCache;if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
