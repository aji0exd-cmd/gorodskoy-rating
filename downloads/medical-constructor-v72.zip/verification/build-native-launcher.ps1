﻿param(
 [string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v72'),
 [string]$ReferenceAssemblies=$env:MEDICAL_NET472_REFERENCE_ROOT,
 [string]$RoslynDirectory=$PSHOME,
 [string]$OutputPath=''
)
$ErrorActionPreference='Stop'
# Build only: PowerShell 7 + Roslyn and official .NET Framework 4.7.2 reference assemblies.
# The emitted program runs Windows PowerShell 5.1 in process and has no PowerShell 7 dependency.
if([string]::IsNullOrWhiteSpace($ReferenceAssemblies)){
 if(-not [string]::IsNullOrWhiteSpace(${env:ProgramFiles(x86)})){
  $frameworkCandidate=Join-Path ${env:ProgramFiles(x86)} 'Reference Assemblies/Microsoft/Framework/.NETFramework/v4.7.2'
  if([IO.Directory]::Exists($frameworkCandidate)){$ReferenceAssemblies=$frameworkCandidate}
 }
}
if([string]::IsNullOrWhiteSpace($ReferenceAssemblies) -or -not [IO.File]::Exists((Join-Path $ReferenceAssemblies 'mscorlib.dll'))){throw 'Supply -ReferenceAssemblies with the official .NET Framework 4.7.2 reference-assembly directory.'}
if([string]::IsNullOrWhiteSpace($OutputPath)){$OutputPath=Join-Path $Project 'Медицинский конструктор.exe'}
$sourcePath=Join-Path $Project 'Source/NativeLauncher.cs';$manifestPath=Join-Path $Project 'Source/app.manifest'
foreach($path in @($sourcePath,$manifestPath,(Join-Path $RoslynDirectory 'Microsoft.CodeAnalysis.dll'),(Join-Path $RoslynDirectory 'Microsoft.CodeAnalysis.CSharp.dll'))){if(-not [IO.File]::Exists($path)){throw 'Native build input is missing.'}}
Add-Type -Path (Join-Path $RoslynDirectory 'Microsoft.CodeAnalysis.dll')
Add-Type -Path (Join-Path $RoslynDirectory 'Microsoft.CodeAnalysis.CSharp.dll')
if(-not ('MedicalNativeBuildV72.Compiler' -as [type])){
 $references=@((Join-Path $RoslynDirectory 'Microsoft.CodeAnalysis.dll'),(Join-Path $RoslynDirectory 'Microsoft.CodeAnalysis.CSharp.dll'),[Collections.Immutable.ImmutableArray].Assembly.Location,(Join-Path $PSHOME 'ref/System.Runtime.dll'),(Join-Path $PSHOME 'ref/System.Collections.dll'),(Join-Path $PSHOME 'ref/System.Linq.dll'))
 Add-Type -ReferencedAssemblies $references -CompilerOptions '/nowarn:1701' -TypeDefinition @'
using System;
using System.IO;
using System.Linq;
using System.Text;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.Text;
namespace MedicalNativeBuildV72 {
 public static class Compiler {
  public static void Build(string source,string manifest,string output,string[] referenceFiles) {
   CSharpParseOptions parse=new CSharpParseOptions(LanguageVersion.CSharp5);
   SyntaxTree tree=CSharpSyntaxTree.ParseText(SourceText.From(File.ReadAllText(source),Encoding.UTF8),parse,"Source/NativeLauncher.cs");
   MetadataReference[] references=referenceFiles.Select(p=>(MetadataReference)MetadataReference.CreateFromFile(p)).ToArray();
   CSharpCompilationOptions options=new CSharpCompilationOptions(OutputKind.WindowsApplication).WithOptimizationLevel(OptimizationLevel.Release).WithPlatform(Platform.AnyCpu).WithDeterministic(true).WithOverflowChecks(true);
   CSharpCompilation compilation=CSharpCompilation.Create("MedicalConstructor",new SyntaxTree[]{tree},references,options);
   using(FileStream manifestStream=File.OpenRead(manifest))
   using(Stream resources=compilation.CreateDefaultWin32Resources(true,false,manifestStream,null))
   using(FileStream pe=File.Create(output)) {
    var result=compilation.Emit(pe,win32Resources:resources);
    if(!result.Success) throw new InvalidOperationException(String.Join(Environment.NewLine,result.Diagnostics.Where(d=>d.Severity==DiagnosticSeverity.Error).Select(d=>d.ToString())));
   }
  }
 }
}
'@
}
$referenceFiles=@('mscorlib.dll','System.dll','System.Core.dll','System.Windows.Forms.dll','System.Drawing.dll'|ForEach-Object{Join-Path $ReferenceAssemblies $_})
foreach($path in $referenceFiles){if(-not [IO.File]::Exists($path)){throw 'Required .NET Framework reference assembly is missing.'}}
$temporary=$OutputPath+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
try{
 [MedicalNativeBuildV72.Compiler]::Build($sourcePath,$manifestPath,$temporary,$referenceFiles)
 if([IO.File]::Exists($OutputPath)){[IO.File]::Replace($temporary,$OutputPath,[Management.Automation.Language.NullString]::Value)}else{[IO.File]::Move($temporary,$OutputPath)}
}finally{if([IO.File]::Exists($temporary)){[IO.File]::Delete($temporary)}}
$info=[IO.FileInfo]$OutputPath
[pscustomobject]@{Path=$info.FullName;Bytes=$info.Length;SHA256=(Get-FileHash -LiteralPath $OutputPath -Algorithm SHA256).Hash.ToLowerInvariant();Framework='.NET Framework 4.7.2';Language='C# 5';Kind='Windows GUI / AnyCPU';Runtime='Windows PowerShell 5.1, in process'}
