﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v72'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Check([bool]$test,[string]$label){if(-not $test){throw $label};$script:checks++;Write-Output ('PASS '+$label)}
function Import-TestFunctions([string]$path,[string[]]$names=@()){
 $t=$null;$e=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$t,[ref]$e)
 if($e.Count){throw ($e|Out-String)}
 foreach($node in $ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
  if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}
 }
}
Add-Type -TypeDefinition @'
using System;
using System.Collections;
using System.Threading;
namespace Windows.Forms {
 public sealed class ControlCollection:CollectionBase {public void Add(object value){List.Add(value);}}
 public class Control {
  public string Text{get;set;} public bool Enabled{get;set;} public object DialogResult{get;set;}
  public ControlCollection Controls=new ControlCollection(); public int Left,Top,Width,Height;
  public Control(){Enabled=true;}
  public void SetBounds(int x,int y,int w,int h){Left=x;Top=y;Width=w;Height=h;}
 }
 public sealed class Form:Control,IDisposable {
  public static string Choice="";public static Form Last;public bool Disposed,Closed;
  public object Size{get;set;} public object StartPosition{get;set;} public object FormBorderStyle{get;set;}
  public bool MaximizeBox{get;set;} public bool MinimizeBox{get;set;} public Button CancelButton{get;set;}
  public object ShowDialog(object owner){Last=this;foreach(object item in Controls){Button b=item as Button;if(b!=null && b.Text==Choice && b.Enabled){b.RaiseClick();break;}}return DialogResult;}
  public void Close(){Closed=true;} public void Dispose(){Disposed=true;}
 }
 public sealed class Label:Control{}
 public sealed class Button:Control{public event EventHandler Click;public void RaiseClick(){if(Click!=null)Click(this,EventArgs.Empty);}}
 public static class MessageBox {
  public static int Calls;public static bool Throw;public static string Last;
  public static object Show(params object[] args){Calls++;Last=args.Length>1?Convert.ToString(args[1]):"";if(Throw)throw new Exception("TEST notification failure");return null;}
 }
 public static class Application {
  private static ThreadExceptionEventHandler handlers;
  public static int ModeCalls;public static string Mode;
  public static event ThreadExceptionEventHandler ThreadException {add{handlers+=value;}remove{handlers-=value;}}
  public static int HandlerCount{get{return handlers==null?0:handlers.GetInvocationList().Length;}}
  public static void SetUnhandledExceptionMode(string mode){ModeCalls++;Mode=mode;}
  public static void Raise(Exception exception){if(handlers!=null)handlers(null,new ThreadExceptionEventArgs(exception));}
 }
}
'@
function Set-DarkTheme($control){}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-v71-core-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
try{
 . (Join-Path $Project 'core-guard-v71.ps1')
 . (Join-Path $Project 'backup-ui-v67.ps1')
 Import-TestFunctions (Join-Path $Project 'backup-v67.ps1') @('Archive-MedicalPendingBackup')
 Assert-Check (Initialize-MedicalCoreGuard $temp) 'Guard initializes a portable diagnostic folder'
 Assert-Check ($script:medicalCoreGuard.Path -ceq (Join-Path $temp 'Журнал работы/core-events.jsonl')) 'Diagnostics stay beside the portable program'
 Assert-Check ($script:medicalCoreGuard.ModeReady -and [Windows.Forms.Application]::Mode -ceq 'CatchException') 'Native UI exception mode is set before windows'
 $script:stage='initial';$secret='PATIENT Ivanov PASSWORD 123 C:\Users\Name\medical.docx'
 $exception=[IO.IOException]::new($secret)
 $result=Write-MedicalCoreIncident $exception 'save'
 Assert-Check $result.LogWritten 'Real metadata incident is atomically written'
 Assert-Check ($result.Incident.Type -ceq 'System.IO.IOException' -and $result.Incident.HResult -eq $exception.HResult) 'Diagnostic retains useful exception type and HRESULT'
 $text=[IO.File]::ReadAllText($script:medicalCoreGuard.Path)
 Assert-Check (-not $text.Contains($secret) -and -not $text.Contains('Ivanov') -and -not $text.Contains('medical.docx')) 'Exception message, patient text and paths are excluded'
 $json=$text.Trim()|ConvertFrom-Json
 Assert-Check (@($json.PSObject.Properties).Count -eq 7) 'Diagnostic has only seven approved metadata fields'
 Assert-Check ($json.Id -cmatch '^[a-f0-9]{32}$' -and $json.Area -ceq 'save' -and $json.Version -eq 71) 'Incident code and source metadata are valid'
 $result=Write-MedicalCoreIncident $exception $secret
 Assert-Check ($result.Incident.Area -ceq 'ui') 'Untrusted diagnostic area is reduced to an allowed token'
 for($i=0;$i -lt 140;$i++){[void](Write-MedicalCoreIncident $exception)}
 $lines=[IO.File]::ReadAllLines($script:medicalCoreGuard.Path)
 Assert-Check ($lines.Count -eq 128) 'Diagnostic history is bounded to the latest 128 entries'
 Assert-Check (([IO.FileInfo]$script:medicalCoreGuard.Path).Length -le 65536) 'Diagnostic history is bounded to 64 KiB'
 Assert-Check (@(Get-ChildItem -LiteralPath (Split-Path -Parent $script:medicalCoreGuard.Path) -Filter '.mc-core-*.tmp').Count -eq 0) 'Successful incidents leave no temporary partial files'
 $injected=[ordered]@{Id=[guid]::NewGuid().ToString('N');Utc=[datetimeoffset]::UtcNow.ToString('o');Version=71;Area='ui';Stage='diary';Type='System.Exception';HResult=0;Patient=$secret}
 [IO.File]::WriteAllText($script:medicalCoreGuard.Path,('BROKEN'+"`n"+($injected|ConvertTo-Json -Compress)))
 [void](Write-MedicalCoreIncident $exception)
 $text=[IO.File]::ReadAllText($script:medicalCoreGuard.Path)
 Assert-Check (-not $text.Contains('BROKEN') -and -not $text.Contains('Ivanov')) 'Corrupt lines and unapproved old diagnostic fields are not copied'
 Assert-Check ([IO.File]::ReadAllLines($script:medicalCoreGuard.Path).Count -eq 2) 'Valid old metadata survives a damaged neighboring line'
 [IO.File]::WriteAllText($script:medicalCoreGuard.Path,('x'*70000))
 [void](Write-MedicalCoreIncident $exception)
 Assert-Check ([IO.File]::ReadAllLines($script:medicalCoreGuard.Path).Count -eq 1) 'Oversized corrupt log is replaced without unbounded input'
 $validLogPath=$script:medicalCoreGuard.Path;$script:medicalCoreGuard.Path=Join-Path $temp 'occupied';[void][IO.Directory]::CreateDirectory($script:medicalCoreGuard.Path)
 $result=Write-MedicalCoreIncident $exception
 Assert-Check (-not $result.LogWritten -and -not $script:medicalCoreGuard.LogBusy) 'Unavailable diagnostic target never escapes the exception boundary'
 Assert-Check ([IO.Directory]::Exists($script:medicalCoreGuard.Path)) 'Failed logging does not overwrite an existing directory'
 Assert-Check (@(Get-ChildItem -LiteralPath $temp -Filter '.mc-core-*.tmp').Count -eq 0) 'Failed diagnostic write removes temporary files'
 $script:medicalCoreGuard.Path=$validLogPath
 $script:medicalAccountsContext=$null;$script:medicalAuthSession=$null;$script:medicalWorkspaceReady=$true;$script:medicalBackupEditorDraft=$null;$script:medicalBackupRetainedDraft=$null;$script:medicalBackupBusy=$false;$script:backupCalls=0;$script:backupThrows=$false;$script:backupReenter=$false;$script:reentered='unset'
 function script:Write-MedicalSessionBackup([bool]$closed=$false){
  $script:backupCalls++
  if($script:backupReenter){$script:reentered=Invoke-MedicalUiExceptionRecovery ([Exception]::new('nested'))}
  if($script:backupThrows){throw 'TEST backup failure with patient text'}
  return [pscustomobject]@{Path='checkpoint';Closed=$closed}
 }
 $owner=[pscustomobject]@{Window='original'}
 Assert-Check (Register-MedicalUiExceptionGuard $owner) 'Real native event handler registers'
 [void](Register-MedicalUiExceptionGuard $owner)
 Assert-Check ([Windows.Forms.Application]::HandlerCount -eq 1) 'Repeated registration cannot duplicate exception handling'
 $beforeMessages=[Windows.Forms.MessageBox]::Calls
 [Windows.Forms.Application]::Raise($exception)
 Assert-Check ($script:backupCalls -eq 1) 'Escaped native UI exception attempts one real backup callback'
 Assert-Check ([Windows.Forms.MessageBox]::Calls -eq ($beforeMessages+1)) 'Escaped native UI exception shows one recovery notice'
 Assert-Check ($script:medicalCoreGuard.LastIncident.BackupSaved) 'Recovery notice tracks actual confirmed checkpoint result'
 Assert-Check (-not [Windows.Forms.MessageBox]::Last.Contains('Ivanov') -and [Windows.Forms.MessageBox]::Last.Contains($script:medicalCoreGuard.LastIncident.Incident.Id)) 'Recovery notice contains incident code without exception data'
 Assert-Check (-not $script:medicalCoreGuard.Busy) 'Recovery guard resets after a native callback'
 $script:medicalWorkspaceReady=$false;$beforeBackups=$script:backupCalls
 [Windows.Forms.Application]::Raise($exception)
 Assert-Check ($script:backupCalls -eq $beforeBackups) 'No workspace or editor draft means no emergency checkpoint'
 $script:medicalWorkspaceReady=$true;$script:medicalAccountsContext=[pscustomobject]@{Loaded=$true}
 [Windows.Forms.Application]::Raise($exception)
 Assert-Check ($script:backupCalls -eq $beforeBackups) 'Account context without authenticated session cannot touch patient backups'
 $script:medicalAuthSession=[pscustomobject]@{Authenticated=$true}
 [Windows.Forms.Application]::Raise($exception)
 Assert-Check ($script:backupCalls -eq ($beforeBackups+1)) 'Authenticated workspace permits emergency checkpoint'
 $script:medicalWorkspaceReady=$false;$script:medicalBackupRetainedDraft=[pscustomobject]@{Raw='draft'};$beforeBackups=$script:backupCalls
 [Windows.Forms.Application]::Raise($exception)
 Assert-Check ($script:backupCalls -eq ($beforeBackups+1)) 'Authenticated unfinished new-form draft remains recoverable before workspace opens'
 $script:medicalBackupRetainedDraft=$null;$script:medicalWorkspaceReady=$true;$script:medicalAccountsContext=$null;$script:medicalAuthSession=$null
 $script:backupReenter=$true;$beforeMessages=[Windows.Forms.MessageBox]::Calls
 [Windows.Forms.Application]::Raise($exception)
 Assert-Check ($null -eq $script:reentered) 'Nested recovery is rejected before recursive backup or dialog'
 Assert-Check ([Windows.Forms.MessageBox]::Calls -eq ($beforeMessages+1)) 'Nested failure cannot open repeated recovery dialogs'
 $script:backupReenter=$false;$script:backupThrows=$true
 [Windows.Forms.Application]::Raise($exception)
 Assert-Check (-not $script:medicalCoreGuard.LastIncident.BackupSaved -and -not $script:medicalCoreGuard.Busy) 'Failed emergency checkpoint does not trap the exception handler'
 Assert-Check ([Windows.Forms.MessageBox]::Last.Contains('не подтверждено') -and -not [Windows.Forms.MessageBox]::Last.Contains('patient text')) 'Failed backup is reported truthfully without copying its sensitive message'
 $script:medicalBackupBusy=$true;$beforeBackups=$script:backupCalls
 [Windows.Forms.Application]::Raise($exception)
 Assert-Check ($script:backupCalls -eq $beforeBackups) 'Existing in-progress backup is never reentered'
 $script:medicalBackupBusy=$false;$script:backupThrows=$false;[Windows.Forms.MessageBox]::Throw=$true
 [Windows.Forms.Application]::Raise($exception)
 Assert-Check (-not $script:medicalCoreGuard.Busy) 'Notification failure also releases the exception guard'
 [Windows.Forms.MessageBox]::Throw=$false
 Unregister-MedicalUiExceptionGuard
 Assert-Check ([Windows.Forms.Application]::HandlerCount -eq 0 -and $null -eq $script:medicalCoreGuard.Handler) 'Native event handler is detached during cleanup'
 $beforeBackups=$script:backupCalls;[Windows.Forms.Application]::Raise($exception)
 Assert-Check ($script:backupCalls -eq $beforeBackups) 'Disposed application retains no active recovery callback'
 [void](Register-MedicalUiExceptionGuard $owner);[void](Initialize-MedicalCoreGuard $temp)
 Assert-Check ([Windows.Forms.Application]::HandlerCount -eq 0) 'Reinitializing guard detaches the previous native subscription'
 # Exercise the actual four-button dialog and its captured click closures.
 foreach($pair in @(@('Сохранить и закрыть','Save'),@('Закрыть с резервной копией','Backup'),@('Закрыть без сохранения','Discard'),@('Продолжить работу','Cancel'))){
  [Windows.Forms.Form]::Choice=$pair[0];$choice=Show-MedicalSessionCloseChoice $null $true $true 'backup'
  Assert-Check ($choice -ceq $pair[1]) ('Actual close dialog returns '+$pair[1])
  Assert-Check ([Windows.Forms.Form]::Last.Disposed) ('Actual '+$pair[1]+' close dialog is disposed')
 }
 [Windows.Forms.Form]::Choice='Сохранить и закрыть'
 $choice=Show-MedicalSessionCloseChoice $null $true $true '' $false
 Assert-Check ($choice -ceq 'Cancel') 'Failed checkpoint disables ordinary-save shortcut in close dialog'
 Assert-Check ([Windows.Forms.Form]::Last.CancelButton.Text -ceq 'Продолжить работу') 'Escape defaults to continuing work, never discarding'
 $buttons=@([Windows.Forms.Form]::Last.Controls|Where-Object {$_ -is [Windows.Forms.Button]})
 Assert-Check ($buttons.Count -eq 4) 'All four explicit close choices are available'
 Assert-Check (@($buttons|Where-Object {$_.Top+$_.Height -gt 335}).Count -eq 0) 'Every close choice fits within the native dialog client area'
 [Windows.Forms.Form]::Choice='Закрыть без сохранения';$choice=Show-MedicalSessionCloseChoice $null $true $true '' $false
 Assert-Check ($choice -ceq 'Discard') 'Actual dialog permits explicit discard after checkpoint failure'
 # Production close controller with real files and the real archive routine.
 function script:Show-MedicalSessionCloseChoice($owner,$formDirty,$caseDirty,$path,[bool]$backupAvailable=$true){$script:closeCalls++;$script:closeAvailable=$backupAvailable;return $script:closeChoice}
 function script:Invoke-MedicalSaveForm {$script:formSaves++}
 function script:Save-Case {$script:caseSaves++}
 $script:medicalWorkspaceReady=$true;$script:medicalBackupEditorDraft=$null;$script:medicalBackupRetainedDraft=$null;$script:medicalSessionCloseBusy=$false
 $script:medicalBackupFormSavedSignature='old-form';$script:medicalBackupCaseSavedSignature='old-case';$script:formSaves=0;$script:caseSaves=0
 $script:closeCalls=0;$script:closeChoice='Discard';$script:checkpointThrows=$false;$script:checkpointCalls=0;$script:checkpointReenter=$false
 $script:medicalBackupPath=Join-Path $temp 'working-session.mcbak'
 $savedForm=Join-Path $temp 'saved.mcform';$savedCard=Join-Path $temp 'saved.docx'
 [IO.File]::WriteAllText($savedForm,'UNCHANGED FORM');[IO.File]::WriteAllText($savedCard,'UNCHANGED CARD')
 function script:Write-MedicalSessionBackup([bool]$closed=$false){
  $script:checkpointCalls++
  if($script:checkpointReenter){$script:closeReentered=Confirm-MedicalSessionClose $null}
  if($script:checkpointThrows){throw 'TEST folder unavailable'}
  [IO.File]::WriteAllText($script:medicalBackupPath,('CURRENT CHECKPOINT '+$closed))
  return [pscustomobject]@{Path=$script:medicalBackupPath;Closed=$closed;Payload=[pscustomobject]@{FormSignature='new-form';CaseSignature='new-case';Data=[pscustomobject]@{EditorDraft=$script:medicalBackupEditorDraft}}}
 }
 [IO.File]::WriteAllText(($script:medicalBackupPath+'.bak'),'PRIOR CHECKPOINT')
 Assert-Check (Confirm-MedicalSessionClose $null) 'Explicit discard closes the actual production controller'
 Assert-Check ($script:formSaves -eq 0 -and $script:caseSaves -eq 0) 'Discard never invokes normal form or card saving'
 Assert-Check ([IO.File]::ReadAllText($savedForm) -ceq 'UNCHANGED FORM' -and [IO.File]::ReadAllText($savedCard) -ceq 'UNCHANGED CARD') 'Previously saved form and card bytes stay unchanged'
 Assert-Check (-not [IO.File]::Exists($script:medicalBackupPath) -and -not [IO.File]::Exists(($script:medicalBackupPath+'.bak'))) 'Discard removes current recovery pointers by archiving them'
 $archives=@(Get-ChildItem -LiteralPath $temp -Filter 'session-*.mcbak')
 Assert-Check ($archives.Count -eq 2) 'Discard retains both current and previous checkpoints as manual archives'
 Assert-Check (@($archives|Where-Object {[IO.File]::ReadAllText($_.FullName) -ceq 'PRIOR CHECKPOINT'}).Count -eq 1) 'Prior checkpoint archive retains exact bytes'
 Assert-Check (@($archives|Where-Object {[IO.File]::ReadAllText($_.FullName) -ceq 'CURRENT CHECKPOINT False'}).Count -eq 1) 'Last automatic checkpoint remains recoverable manually'
 Assert-Check (-not $script:medicalSessionCloseBusy) 'Discard releases the close decision guard'
 $script:checkpointThrows=$true;$script:closeChoice='Cancel';$beforeClose=$script:closeCalls
 Assert-Check (-not (Confirm-MedicalSessionClose $null)) 'Checkpoint failure still lets user continue working'
 Assert-Check ($script:closeCalls -eq ($beforeClose+1) -and -not $script:closeAvailable) 'Checkpoint failure is passed explicitly to the decision dialog'
 Assert-Check (-not $script:medicalSessionCloseBusy) 'Failed checkpoint and canceled close release the close guard'
 $script:closeChoice='Discard';[IO.File]::WriteAllText($script:medicalBackupPath,'OLD VALID BACKUP')
 Assert-Check (Confirm-MedicalSessionClose $null) 'Unavailable backup folder cannot trap an explicit discard choice'
 Assert-Check ($script:formSaves -eq 0 -and $script:caseSaves -eq 0) 'Discard after backup failure still never writes ordinary files'
 $archives=@(Get-ChildItem -LiteralPath $temp -Filter 'session-*.mcbak')
 Assert-Check (@($archives|Where-Object {[IO.File]::ReadAllText($_.FullName) -ceq 'OLD VALID BACKUP'}).Count -eq 1) 'Backup failure discard preserves the previously durable checkpoint'
 $beforeClose=$script:closeCalls
 Assert-Check (Confirm-MedicalSessionClose $null 'WindowsShutDown') 'System shutdown remains noninteractive when backup fails'
 Assert-Check ($script:closeCalls -eq $beforeClose -and -not $script:medicalSessionCloseBusy) 'Shutdown failure shows no choice and resets close state'
 $script:checkpointThrows=$false;$script:checkpointReenter=$true;$script:closeChoice='Cancel';$beforeClose=$script:closeCalls
 Assert-Check (-not (Confirm-MedicalSessionClose $null)) 'Cancel after reentrant close keeps the application open'
 Assert-Check (-not $script:closeReentered -and $script:closeCalls -eq ($beforeClose+1)) 'Nested close cannot create a duplicate checkpoint or dialog'
 $script:checkpointReenter=$false;$script:medicalBackupEditorDraft=[pscustomobject]@{Raw='unfinished'};$script:closeChoice='Discard'
 Assert-Check (Confirm-MedicalSessionClose $null) 'Explicit discard can close even with an unapplied editor draft'
 $script:medicalBackupEditorDraft=$null;$script:medicalWorkspaceReady=$false;$beforeWrites=$script:checkpointCalls
 Assert-Check (Confirm-MedicalSessionClose $null) 'Empty workspace closes without a save prompt'
 Assert-Check ($script:checkpointCalls -eq $beforeWrites -and -not $script:medicalSessionCloseBusy) 'Empty workspace creates no checkpoint and releases close state'
 Write-Output ('TOTAL '+$script:checks+' checks passed')
}finally{
 try{Unregister-MedicalUiExceptionGuard}catch{}
 if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}
}
