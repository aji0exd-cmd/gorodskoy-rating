﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v72'))
$ErrorActionPreference='Stop'
$t=$null;$e=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'template-editor-v59.ps1'),[ref]$t,[ref]$e)
if($e.Count){throw ($e | Out-String)}
$editor=$ast.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Show-MedicalFormTemplateEditor'},$false)
$spec=@{}
foreach($name in @('recognizeCurrentTemplate','clearWordPreview')){
 $nodes=@($editor.FindAll({param($n)$n -is [Management.Automation.Language.AssignmentStatementAst] -and $n.Left -is [Management.Automation.Language.VariableExpressionAst] -and $n.Left.VariablePath.UserPath -eq $name},$true))
 if($nodes.Count -ne 1){throw ('Expected production assignment '+$name)};$spec[$name]=$nodes[0].Extent.Text
}
$nodes=@($editor.FindAll({param($n)$n -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $n.Expression -is [Management.Automation.Language.VariableExpressionAst] -and $n.Expression.VariablePath.UserPath -eq 'loadTemplate' -and $n.Member.Value -eq 'Add_Click'},$true))
if($nodes.Count -ne 1){throw 'Expected actual Load document handler'};$spec.LoadHandler=$nodes[0].Arguments[0].Extent.Text
$closeNode=$editor.Find({param($n)$n -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $n.Expression -is [Management.Automation.Language.VariableExpressionAst] -and $n.Expression.VariablePath.UserPath -eq 'dialog' -and $n.Member.Value -eq 'Add_FormClosing'},$true)
if(-not $closeNode){throw 'Expected editor close handler'};$spec.CloseHandler=$closeNode.Arguments[0].Extent.Text
$root=Join-Path ([IO.Path]::GetTempPath()) ('mc-import-editor-test-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($root);$child=Join-Path $root 'private-script-scope.ps1'
$childSource=@'
param([string]$Project,[string]$Root,$Spec)
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Import([bool]$condition,[string]$label){if(-not $condition){throw $label};$script:checks++;Write-Output ('PASS '+$label)}
function Import-Functions([string]$path,[string[]]$names=@()){
 $t=$null;$e=$null;$a=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$t,[ref]$e);if($e.Count){throw ($e|Out-String)}
 foreach($node in $a.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}}
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @"
using System;
using System.Collections;
using System.Collections.Generic;
public sealed class ImportEditorWidget {
 public string Text="";public ArrayList Controls=new ArrayList();public event EventHandler Click;
 public void RaiseClick(){if(Click!=null)Click(this,EventArgs.Empty);}public void Dispose(){}
}
namespace Windows.Forms {
 public sealed class PictureBox {public object Image;}
 public sealed class OpenFileDialog:IDisposable {
  public static string Choice="OK",Destination="";public static int Calls,Disposed;
  public string Title,Filter,FileName;public bool CheckFileExists,Multiselect;
  public string ShowDialog(object owner){Calls++;FileName=Destination;return Choice;}public void Dispose(){Disposed++;}
 }
 public static class MessageBox {
  public static Queue<string> Responses=new Queue<string>();public static ArrayList Messages=new ArrayList();
  public static string Show(params object[] args){Messages.Add(args);return Responses.Count>0?Responses.Dequeue():"No";}
 }
}
"@
Import-Functions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
foreach($file in @('universal.ps1','forms-v59.ps1','template-editor-v59.ps1','template-recovery-v66.ps1')){Import-Functions (Join-Path $Project $file)}
Import-Functions (Join-Path $Project 'forms-ui-v59.ps1') @('Import-MedicalLocalTemplateChoice')
$script:medicalProgramRoot=$Root;$script:medicalTemplatesFolder=Join-Path $Root 'Шаблоны';$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
$script:universalValues=@{patient_name='PATIENT ANSWER MUST NOT ENTER SCHEMA'};$script:universalDetails=@{}
$original=Join-Path $Root 'Мой исходный осмотр.docx';$script:testSchema=New-UniversalConfig;New-UniversalTemplate $original $script:testSchema
$script:sourceOriginal=$original;$originalHash=Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($original))
$script:conversionMode='ok';$script:recognitionMode='cancel';$script:cleanupMode='ok';$script:conversionCalls=0;$script:recognitionCalls=0;$script:cleanupCalls=0;$script:createdImports=New-Object Collections.ArrayList
function Get-MedicalLocalDocumentFilter {return 'Документы|*.docx;*.doc;*.pdf;*.txt;*.png'}
function Import-MedicalLocalDocument([string]$Path,$Owner){
 $script:conversionCalls++
 if($script:conversionMode -eq 'error'){throw 'Conversion failed intentionally'}
 if($script:conversionMode -eq 'cancel'){return $null}
 $folder=Join-Path $Root ('private-import-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($folder)
 $copy=Join-Path $folder 'converted.docx';[IO.File]::Copy($Path,$copy)
 $result=[pscustomobject]@{Path=$copy;Temporary=$true;SourceKind='fake-converted';Warnings=@();WorkingDirectory=$folder}
 [void]$script:createdImports.Add($result);return $result
}
function Remove-MedicalLocalImport($Import){$script:cleanupCalls++;if($Import.Temporary -and [IO.Directory]::Exists($Import.WorkingDirectory)){[IO.Directory]::Delete($Import.WorkingDirectory,$true)};if($script:cleanupMode -eq 'error'){throw 'Private conversion cleanup failed intentionally'}}
function Invoke-MedicalTemplateRecognition($Owner,$Model,$Schema){
 $script:recognitionCalls++
 if($script:recognitionMode -eq 'cancel'){return $null}
 if($script:recognitionMode -eq 'error'){throw 'Recognition review failed intentionally'}
 $copySchema=Copy-MedicalFormSchema $Schema
 if($script:recognitionMode -eq 'invalid-schema'){$copySchema.Sections[0].Title=''}
 elseif($copySchema.Sections[0].Fields.Count){$copySchema.Sections[0].Fields[0].Label='Распознанное название'}
 $copyModel=Read-MedicalTemplateModel $script:sourceOriginal
 Set-MedicalTemplateParagraph $copyModel $copyModel.Paragraphs[0].Id 'Распознанный заголовок'
 if($script:recognitionMode -eq 'invalid-model'){$copyModel=$null}
 return [pscustomobject]@{Schema=$copySchema;Model=$copyModel;AppliedCount=3}
}
$script:realWriteModel=(Get-Command Write-MedicalTemplateModel -CommandType Function).ScriptBlock;$script:failReviewWrite=$false
function Write-MedicalTemplateModel([string]$Path,$Model){if($script:failReviewWrite){throw 'Private review write failed intentionally'};& $script:realWriteModel $Path $Model}
function New-TestSession {
 $state=@{Model=(Read-MedicalTemplateModel $script:sourceOriginal);Schema=(Copy-MedicalFormSchema $script:testSchema);Paragraph=$null;Selected='old';SelectedNode='old';PropertiesSelection='old';PropertiesNode='old';PropertiesFieldNode='old';SectionFieldIds=@{old='field'};WordPreview=$null}
 $wordPages=New-Object ImportEditorWidget;$saveStatus=New-Object ImportEditorWidget;$templateName=New-Object ImportEditorWidget;$loadTemplate=New-Object ImportEditorWidget;$dialog=New-Object ImportEditorWidget
 $tracker=@{Properties=0;Paragraph=0;Tree=0;Parts=0;Errors=@()}
 $commitProperties={param([bool]$required=$false)$tracker.Properties++}.GetNewClosure();$commitParagraph={$tracker.Paragraph++}.GetNewClosure()
 $refreshTree={$tracker.Tree++}.GetNewClosure();$refreshParts={$tracker.Parts++}.GetNewClosure();$showError={param($errorRecord)$tracker.Errors+=@($errorRecord)}.GetNewClosure()
 $editorCommands=@{}
 foreach($name in @('Import-MedicalLocalDocument','Remove-MedicalLocalImport','Invoke-MedicalTemplateRecognition','Get-MedicalLocalDocumentFilter','Read-MedicalTemplateModel','Get-MedicalFormDisplayName','Assert-UniversalConfig')){$editorCommands[$name]=Get-Command $name -CommandType Function}
 # Evaluate exact production closures in private script scope; they must invoke
 # captured commands despite their dynamic GetNewClosure module scope.
 Invoke-Expression $Spec.clearWordPreview;Invoke-Expression $Spec.recognizeCurrentTemplate
 $handler=Invoke-Expression $Spec.LoadHandler;$loadTemplate.Add_Click($handler)
 return [pscustomobject]@{State=$state;Tracker=$tracker;Recognize=$recognizeCurrentTemplate;Load=$loadTemplate;Name=$templateName;Status=$saveStatus;OriginalModel=$state.Model;OriginalSchema=$state.Schema}
}
function Reset-Responses([string[]]$responses=@()){
 [Windows.Forms.MessageBox]::Responses.Clear();foreach($response in $responses){[Windows.Forms.MessageBox]::Responses.Enqueue($response)}
 [Windows.Forms.OpenFileDialog]::Choice='OK';[Windows.Forms.OpenFileDialog]::Destination=$script:sourceOriginal
 $script:conversionMode='ok';$script:recognitionMode='cancel';$script:cleanupMode='ok';$script:failReviewWrite=$false
}
function Assert-OriginalPreserved([string]$label){Assert-Import ((Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($script:sourceOriginal))) -ceq $originalHash) $label}
function Assert-NoImports([string]$label){Assert-Import (@($script:createdImports | Where-Object {[IO.Directory]::Exists($_.WorkingDirectory)}).Count -eq 0) $label}
foreach($mode in @('cancel','error','invalid-schema','invalid-model')){
 Reset-Responses;$script:recognitionMode=$mode;$session=New-TestSession;& $session.Recognize
 Assert-Import ([object]::ReferenceEquals($session.State.Model,$session.OriginalModel) -and [object]::ReferenceEquals($session.State.Schema,$session.OriginalSchema)) ('Recognition '+$mode+' keeps both old references')
 Assert-Import ($session.Tracker.Tree -eq 0 -and $session.Tracker.Parts -eq 0) ('Recognition '+$mode+' does not refresh a partial result')
 Assert-Import ($session.Tracker.Properties -eq 1 -and $session.Tracker.Paragraph -eq 1) ('Recognition '+$mode+' commits current controls before review')
 Assert-Import (@($session.Tracker.Errors).Count -eq $(if($mode -eq 'cancel'){0}else{1})) ('Recognition '+$mode+' reports only actual errors')
 Assert-OriginalPreserved ('Recognition '+$mode+' leaves original bytes unchanged')
}
Reset-Responses;$script:recognitionMode='ok';$session=New-TestSession;& $session.Recognize
Assert-Import (-not [object]::ReferenceEquals($session.State.Model,$session.OriginalModel) -and -not [object]::ReferenceEquals($session.State.Schema,$session.OriginalSchema)) 'Accepted recognition publishes both private clones'
Assert-Import ($session.State.Schema.Sections[0].Fields[0].Label -ceq 'Распознанное название' -and $session.State.Model.Paragraphs[0].Text -ceq 'Распознанный заголовок') 'Accepted schema and Word changes are visible together'
Assert-Import ($session.OriginalSchema.Sections[0].Fields[0].Label -cne 'Распознанное название' -and $session.OriginalModel.Paragraphs[0].Text -cne 'Распознанный заголовок') 'Recognition does not mutate replaced model and schema'
Assert-Import ($session.Tracker.Tree -eq 1 -and $session.Tracker.Parts -eq 1 -and $session.Tracker.Errors.Count -eq 0) 'Accepted result refreshes both document and fields once'
Assert-Import (-not $session.State.Selected -and -not $session.State.PropertiesSelection -and $session.State.SectionFieldIds.Count -eq 0) 'Accepted result clears stale object bindings'
Assert-Import ($session.Status.Text.Contains('3') -and $session.Status.Text.Contains('сохраните')) 'Status asks to check and save recognized form'
Assert-OriginalPreserved 'Accepted recognition preserves original bytes'
Reset-Responses;$session=New-TestSession;[Windows.Forms.OpenFileDialog]::Choice='Cancel';$calls=$script:conversionCalls;$disposed=[Windows.Forms.OpenFileDialog]::Disposed;$session.Load.RaiseClick()
Assert-Import ($script:conversionCalls -eq $calls -and [object]::ReferenceEquals($session.State.Model,$session.OriginalModel)) 'Cancel document picker avoids conversion and replacement'
Assert-Import ([Windows.Forms.OpenFileDialog]::Disposed -eq $disposed+1) 'Cancelled file picker is disposed'
foreach($mode in @('cancel','error')){
 Reset-Responses;$script:conversionMode=$mode;$session=New-TestSession;$disposed=[Windows.Forms.OpenFileDialog]::Disposed;$session.Load.RaiseClick()
 Assert-Import ([object]::ReferenceEquals($session.State.Model,$session.OriginalModel) -and [object]::ReferenceEquals($session.State.Schema,$session.OriginalSchema)) ('Conversion '+$mode+' keeps existing work')
 Assert-Import ([Windows.Forms.OpenFileDialog]::Disposed -eq $disposed+1) ('Conversion '+$mode+' disposes picker')
 Assert-Import ($session.Tracker.Errors.Count -eq $(if($mode -eq 'cancel'){0}else{1})) ('Conversion '+$mode+' error handling is bounded')
 Assert-NoImports ('Conversion '+$mode+' leaks no private import')
}
Reset-Responses @('No');$session=New-TestSession;$cleanup=$script:cleanupCalls;$session.Load.RaiseClick()
Assert-Import ([object]::ReferenceEquals($session.State.Model,$session.OriginalModel) -and [object]::ReferenceEquals($session.State.Schema,$session.OriginalSchema)) 'Declined document replacement keeps both old references'
Assert-Import ($script:cleanupCalls -eq $cleanup+1 -and $session.Tracker.Parts -eq 0) 'Declined replacement cleans conversion without publishing'
Assert-NoImports 'Declined replacement removes private files'
Reset-Responses @('No');$script:cleanupMode='error';$session=New-TestSession;$disposed=[Windows.Forms.OpenFileDialog]::Disposed;$session.Load.RaiseClick()
Assert-Import ($session.Tracker.Errors.Count -eq 1 -and [object]::ReferenceEquals($session.State.Model,$session.OriginalModel)) 'Cleanup failure is contained inside native event and preserves declined working model'
Assert-Import ([Windows.Forms.OpenFileDialog]::Disposed -eq $disposed+1) 'Cleanup failure still disposes document picker'
Reset-Responses @('Yes','No');$session=New-TestSession;$recognitions=$script:recognitionCalls;$session.Load.RaiseClick()
Assert-Import (-not [object]::ReferenceEquals($session.State.Model,$session.OriginalModel) -and [object]::ReferenceEquals($session.State.Schema,$session.OriginalSchema)) 'Accepted replacement updates Word and preserves existing schema'
Assert-Import ($session.Name.Text -ceq 'Мой исходный осмотр.docx') 'Imported editor template keeps human source filename'
Assert-Import ($script:recognitionCalls -eq $recognitions -and $session.Tracker.Parts -eq 1) 'Declined recognition remains available for manual editing'
Assert-Import ($session.State.Model.Paragraphs.Count -gt 0 -and -not [IO.File]::Exists($session.State.Model.SourcePath)) 'Converted in-memory Word remains editable after private cleanup'
Assert-NoImports 'Accepted replacement removes private files'
Reset-Responses @('Yes','Yes');$session=New-TestSession;$session.Load.RaiseClick()
Assert-Import (-not [object]::ReferenceEquals($session.State.Model,$session.OriginalModel) -and [object]::ReferenceEquals($session.State.Schema,$session.OriginalSchema)) 'Cancelling recognition after load keeps loaded document for manual markers'
Assert-NoImports 'Cancelling optional review still cleans private conversion'
Reset-Responses @('Yes','Yes');$script:recognitionMode='ok';$session=New-TestSession;$session.Load.RaiseClick()
Assert-Import ($session.State.Model.Paragraphs[0].Text -ceq 'Распознанный заголовок' -and $session.State.Schema.Sections[0].Fields[0].Label -ceq 'Распознанное название') 'Load plus accepted review publishes matched model and schema'
Assert-Import ($session.Tracker.Errors.Count -eq 0 -and $session.Tracker.Parts -eq 2 -and $session.Tracker.Tree -eq 1) 'Load and recognition refresh at their individual successful boundaries'
Assert-NoImports 'Load with accepted review cleans private conversion'
Assert-OriginalPreserved 'All editor conversion paths preserve original source bytes'
# Exercise the real reusable-form import helper, with actual OOXML read/write and
# actual managed template importer. Only the system conversion/review UI is fake.
Reset-Responses;$choice=Import-MedicalLocalTemplateChoice $null $script:testSchema $original $true
Assert-Import ($choice -and [IO.File]::Exists($choice.Template.Path) -and $choice.Template.Name -ceq 'Мой исходный осмотр.docx') 'New-form import stores a human-named managed template'
Assert-Import ($choice.Schema.Template -ceq $choice.Template.RelativePath -and -not $choice.Schema.AutoTemplate) 'Imported form binds its durable template after private cleanup'
Assert-Import ($choice.Schema.PreserveTemplateFormatting -and $choice.Name -ceq 'Мой исходный осмотр') 'New-form import retains formatting and readable display name'
Assert-NoImports 'New-form cancelled review cleans private conversion'
Assert-Import ((Read-MedicalTemplateModel $choice.Template.Path).Paragraphs.Count -gt 0) 'Durable template remains readable after conversion cleanup'
Reset-Responses;$script:recognitionMode='ok';$choice=Import-MedicalLocalTemplateChoice $null $script:testSchema $original $true
Assert-Import ($choice.Schema.Sections[0].Fields[0].Label -ceq 'Распознанное название' -and (Read-MedicalTemplateModel $choice.Template.Path).Paragraphs[0].Text -ceq 'Распознанный заголовок') 'New-form helper persists accepted recognition into actual OOXML'
Assert-Import (-not (($choice.Schema | ConvertTo-Json -Depth 40).Contains('PATIENT ANSWER MUST NOT ENTER SCHEMA'))) 'New reusable schema does not copy current patient answers'
Assert-NoImports 'New-form recognized conversion is cleaned'
Assert-Import (@([IO.Directory]::GetDirectories([IO.Path]::GetTempPath(),'mc-recognized-*') | Where-Object {[IO.File]::Exists((Join-Path $_ 'Мой исходный осмотр.docx'))}).Count -eq 0) 'New-form recognized write staging is removed'
Reset-Responses;$script:failReviewWrite=$true;$script:recognitionMode='ok';$failed=$false
try{[void](Import-MedicalLocalTemplateChoice $null $script:testSchema $original $true)}catch{$failed=$true}
Assert-Import $failed 'Private recognized-template write failure propagates without successful result'
Assert-NoImports 'Failed recognized-template write still cleans conversion'
Reset-Responses;$script:conversionMode='cancel';$choice=Import-MedicalLocalTemplateChoice $null $script:testSchema $original $true
Assert-Import ($null -eq $choice) 'Cancelled conversion returns no new form result'
Reset-Responses;$script:recognitionMode='error';$recognitions=$script:recognitionCalls
$choice=Import-MedicalLocalTemplateChoice $null $script:testSchema $original $false
Assert-Import ($choice -and $script:recognitionCalls -eq $recognitions) 'Filled-form recovery skips recognition to preserve answer bindings'
$expectedIds=@(Get-UniversalFields $script:testSchema | ForEach-Object {$_.Id});$actualIds=@(Get-UniversalFields $choice.Schema | ForEach-Object {$_.Id})
Assert-Import (($expectedIds -join '|') -ceq ($actualIds -join '|')) 'Filled-form recovery retains all original stable field IDs'
Assert-NoImports 'Filled-form recovery cleans converted private source'
Assert-OriginalPreserved 'All form import paths preserve source bytes'
$state=@{AccountClose=$true;AllowClose=$false;Result='stale applied result';SavedResult='saved snapshot';ClosingReason='UserClosing'}
$closing=[pscustomobject]@{CloseReason='UserClosing';Cancel=$false};$getEditorSignature={throw 'Locked exit must not inspect or display the form'};$editorCommands=@{}
$closeHandler=Invoke-Expression $Spec.CloseHandler;& $closeHandler $null $closing
Assert-Import ($state.AllowClose -and -not $state.Result -and $state.ClosingReason -ceq 'WindowsShutDown' -and -not $closing.Cancel) 'Exit while account is locked closes editor through private recovery path'
Assert-Import ($state.SavedResult -ceq 'saved snapshot') 'Locked exit preserves prior saved snapshot without applying stale result'
Write-Output ('TOTAL '+$script:checks+' checks passed')
'@
[IO.File]::WriteAllText($child,$childSource,[Text.UTF8Encoding]::new($true))
try{& $child -Project $Project -Root $root -Spec $spec;if(-not $?){throw 'Child script failed'}}finally{if([IO.Directory]::Exists($root)){[IO.Directory]::Delete($root,$true)}}
