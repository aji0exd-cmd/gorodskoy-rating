﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v72'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-AccountUi([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @'
using System;
public sealed class AccountUiWidget {
 public string Text {get;set;} public string DialogResult {get;set;} public bool Enabled {get;set;}
 public bool Closed {get;private set;} public bool Focused {get;private set;}
 public AccountUiWidget(){Text="";DialogResult="";Enabled=true;}
 public void Close(){Closed=true;} public bool Focus(){Focused=true;return true;} public void Clear(){Text="";}
}
public sealed class AccountUiGridRow {
 public object Tag {get;set;} public bool Selected {get;set;} public System.Collections.Generic.List<object> Cells=new System.Collections.Generic.List<object>();
}
public sealed class AccountUiRows : System.Collections.Generic.List<AccountUiGridRow> {
 public int Add(object[] values){var row=new AccountUiGridRow();foreach(var value in values)row.Cells.Add(value);base.Add(row);if(Count==1)row.Selected=true;return Count-1;}
}
public sealed class AccountUiGrid {
 public AccountUiRows Rows=new AccountUiRows();public object CurrentCell {get;set;}
 public System.Collections.Generic.List<AccountUiGridRow> SelectedRows {get {var result=new System.Collections.Generic.List<AccountUiGridRow>();foreach(var row in Rows)if(row.Selected)result.Add(row);return result;}}
 public void ClearSelection(){foreach(var row in Rows)row.Selected=false;}
}
namespace Windows.Forms {
 public static class MessageBox {public static int Calls=0;public static string Show(params object[] args){Calls++;return "OK";}}
}
'@
. (Join-Path $Project 'accounts-v71.ps1')
. (Join-Path $Project 'accounts-ui-v71.ps1')
$tokens=$null;$errors=$null
$sourcePath=Join-Path $Project 'accounts-ui-v71.ps1'
$ast=[Management.Automation.Language.Parser]::ParseFile($sourcePath,[ref]$tokens,[ref]$errors)
Assert-AccountUi ($errors.Count -eq 0) 'Account UI parses successfully'
$entry=$ast.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Show-MedicalAccountEntryDialog'},$false)
$nodes=@($entry.FindAll({param($n)$n -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $n.Expression -is [Management.Automation.Language.VariableExpressionAst] -and $n.Expression.VariablePath.UserPath -eq 'submit' -and $n.Member.Value -eq 'Add_Click'},$true))
Assert-AccountUi ($nodes.Count -eq 1) 'Exact production account submit event is found'
$submitSource=$nodes[0].Arguments[0].Extent.Text
$shownNodes=@($entry.FindAll({param($n)$n -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $n.Expression -is [Management.Automation.Language.VariableExpressionAst] -and $n.Expression.VariablePath.UserPath -eq 'dialog' -and $n.Member.Value -eq 'Add_Shown'},$true))
$shownSource=$shownNodes[0].Arguments[0].Extent.Text
function New-AccountUiFixture {
 param([string]$Mode,$Context,$Session,[string]$Username='',[string]$DisplayName='',[string]$Password='',[string]$Confirmation='',[string]$CurrentPassword='',[string]$TargetUserId='',[string]$TargetDisplayName='',[int]$RoleIndex=0,$LoginOverride=$null)
 $commands=@{}
 foreach($name in @('New-MedicalFirstAdministrator','Invoke-MedicalAccountLogin','New-MedicalUserAccount','Set-MedicalOwnPassword','Reset-MedicalAccountPassword','Save-MedicalLoginPreference')){$commands[$name]=Get-Command $name -CommandType Function -ErrorAction Stop}
 if($LoginOverride){$commands['Invoke-MedicalAccountLogin']=$LoginOverride}
 $askUsername=$Mode -in @('FirstAdministrator','Create','Lock')
 $loginPicker=[pscustomobject]@{SelectedItem=[pscustomobject]@{Username=$Username}}
 $askDisplay=$Mode -in @('FirstAdministrator','Create');$askCurrent=$Mode -eq 'OwnPassword'
 $askConfirm=$Mode -in @('FirstAdministrator','Create','OwnPassword','ResetPassword')
 $boxes=@{}
 foreach($name in @('Username','DisplayName','Password','ConfirmPassword','CurrentPassword')){$boxes[$name]=New-Object AccountUiWidget}
 $boxes.Username.Text=$Username;$boxes.DisplayName.Text=$DisplayName;$boxes.Password.Text=$Password
 $boxes.ConfirmPassword.Text=$Confirmation;$boxes.CurrentPassword.Text=$CurrentPassword
 $passwordBoxes=New-Object 'Collections.Generic.List[object]';[void]$passwordBoxes.Add($boxes.Password)
 if($askConfirm){[void]$passwordBoxes.Add($boxes.ConfirmPassword)}
 if($askCurrent){[void]$passwordBoxes.Add($boxes.CurrentPassword)}
 $dialog=New-Object AccountUiWidget;$submit=New-Object AccountUiWidget;$errorLabel=New-Object AccountUiWidget
 $roleBox=[pscustomobject]@{SelectedIndex=$RoleIndex};$state=@{Result=$null;Busy=$false}
 . ([scriptblock]::Create('$callback='+$submitSource));. ([scriptblock]::Create('$shown='+$shownSource))
 return [pscustomobject]@{Callback=$callback;Shown=$shown;State=$state;Dialog=$dialog;Submit=$submit;Error=$errorLabel;Boxes=$boxes;Commands=$commands}
}
$managerAst=$ast.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Show-MedicalAccountManager'},$false)
$managerSources=@{}
foreach($name in @('select','refresh')){
 $assignment=@($managerAst.FindAll({param($n)$n -is [Management.Automation.Language.AssignmentStatementAst] -and $n.Left -is [Management.Automation.Language.VariableExpressionAst] -and $n.Left.VariablePath.UserPath -eq $name},$true))[0]
 $managerSources[$name]=$assignment.Right.Extent.Text
}
foreach($action in @('Create','Enabled','Role','Reset','Own')){
 $node=@($managerAst.FindAll({param($n)$n -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $n.Expression.Extent.Text -eq ('$buttons.'+$action) -and $n.Member.Value -eq 'Add_Click'},$true))[0]
 $managerSources[$action]=$node.Arguments[0].Extent.Text
}
$script:accountUiChosenRole=$null;$script:accountUiEntryCalls=0;$script:accountUiPasswordCalls=0
function Show-AccountUiCancelledEntry {param($Owner,$Session,$Mode,$TargetUserId,$TargetDisplayName)$script:accountUiEntryCalls++;return $null}
function Show-AccountUiCancelledPassword {param($Owner,$Session)$script:accountUiPasswordCalls++;return $null}
function Show-AccountUiChosenRole {param($Owner,$Account)return $script:accountUiChosenRole}
function New-AccountUiManagerFixture($Session){
 $commands=@{}
 foreach($name in @('Assert-MedicalAdministrator','Get-MedicalAccounts','Set-MedicalAccountEnabled','Set-MedicalAccountRole','Test-MedicalSession')){$commands[$name]=Get-Command $name -CommandType Function -ErrorAction Stop}
 $commands['Show-MedicalAccountEntryDialog']=Get-Command Show-AccountUiCancelledEntry -CommandType Function
 $commands['Show-MedicalPasswordChange']=Get-Command Show-AccountUiCancelledPassword -CommandType Function
 $commands['Show-MedicalAccountRoleDialog']=Get-Command Show-AccountUiChosenRole -CommandType Function
 $dialog=New-Object AccountUiWidget;$grid=New-Object AccountUiGrid;$buttons=@{}
 foreach($action in @('Create','Enabled','Role','Reset','Own')){$buttons[$action]=New-Object AccountUiWidget}
 $state=@{Session=$Session;Selected=$null;Busy=$false;Ready=$false}
 . ([scriptblock]::Create('$select='+$managerSources.select));. ([scriptblock]::Create('$refresh='+$managerSources.refresh))
 $callbacks=@{}
 foreach($action in @('Create','Enabled','Role','Reset','Own')){. ([scriptblock]::Create('$callback='+$managerSources[$action]));$callbacks[$action]=$callback}
 return [pscustomobject]@{Select=$select;Refresh=$refresh;Callbacks=$callbacks;State=$state;Grid=$grid;Buttons=$buttons;Dialog=$dialog}
}
function Select-AccountUiManagerUser($Fixture,[string]$Username){
 $Fixture.Grid.ClearSelection()
 foreach($row in $Fixture.Grid.Rows){if($row.Tag.Username -eq $Username){$row.Selected=$true}}
 & $Fixture.Select
}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-account-ui-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
try{
 $context=Initialize-MedicalAccounts -Root $temp
 $fixture=New-AccountUiFixture -Mode FirstAdministrator -Context $context -Username 'admin' -DisplayName 'Администратор' -Password 'Administrator test 71' -Confirmation 'Different password 71'
 & $fixture.Callback
 Assert-AccountUi (-not $fixture.Dialog.Closed -and $null -eq $fixture.State.Result -and $fixture.Error.Text -match 'не совпадают') 'Confirmation mismatch keeps first administrator dialog open'
 Assert-AccountUi (-not (Get-MedicalAccountsState $context).IsInitialized) 'Confirmation mismatch does not initialize or write account database'
 Assert-AccountUi ($fixture.Boxes.Password.Text -eq '' -and $fixture.Boxes.ConfirmPassword.Text -eq '' -and $fixture.Boxes.Password.Focused) 'Rejected setup clears both password boxes and focuses password input'
 Assert-AccountUi ($fixture.Submit.Enabled -and -not $fixture.State.Busy) 'Failed submit releases busy state and enables submit'
 $fixture=New-AccountUiFixture -Mode FirstAdministrator -Context $context -Username 'admin' -DisplayName 'Администратор' -Password 'abc' -Confirmation 'abc'
 & $fixture.Callback
 Assert-AccountUi (-not $fixture.Dialog.Closed -and $fixture.Error.Text -match '4 символов' -and -not (Get-MedicalAccountsState $context).IsInitialized) 'Short setup password is rejected before database write'
 $fixture=New-AccountUiFixture -Mode FirstAdministrator -Context $context -Username 'admin' -DisplayName 'Администратор' -Password 'Administrator test 71' -Confirmation 'Administrator test 71'
 & $fixture.Shown
 Assert-AccountUi ($fixture.Boxes.Username.Focused) 'First administrator dialog focuses username'
 & $fixture.Callback
 $admin=$fixture.State.Result
 Assert-AccountUi ($fixture.Dialog.Closed -and $fixture.Dialog.DialogResult -eq 'OK' -and $admin.Role -eq 'Administrator') 'Exact production setup callback creates administrator and returns authenticated session'
 Assert-AccountUi ($fixture.Commands['New-MedicalFirstAdministrator'] -is [Management.Automation.FunctionInfo]) 'Private authentication helper is captured as FunctionInfo'
 Assert-AccountUi ((Get-MedicalAccountsState $context).IsInitialized) 'Successful setup initializes the account database'
 $fixture=New-AccountUiFixture -Mode Create -Session $admin -Username 'doctor' -DisplayName 'Врач' -Password 'Doctor password 71' -Confirmation 'Doctor password 71'
 & $fixture.Callback
 $doctorAccount=@(Get-MedicalAccounts $admin | Where-Object Username -eq 'doctor')[0]
 Assert-AccountUi ($fixture.Dialog.Closed -and $null -ne $fixture.State.Result -and $doctorAccount.Role -eq 'User') 'Create callback creates ordinary user by default'
 $fixture=New-AccountUiFixture -Mode Create -Session $admin -Username 'admin2' -DisplayName 'Второй администратор' -Password 'Second admin pass 71' -Confirmation 'Second admin pass 71' -RoleIndex 1
 & $fixture.Callback
 Assert-AccountUi ($fixture.Dialog.Closed -and @(Get-MedicalAccounts $admin | Where-Object {$_.Username -eq 'admin2' -and $_.Role -eq 'Administrator'}).Count -eq 1) 'Explicit administrator role is passed through create callback'
 $fixture=New-AccountUiFixture -Mode Login -Context $context -Username 'doctor' -Password 'wrong password 71'
 & $fixture.Callback
 Assert-AccountUi (-not $fixture.Dialog.Closed -and $null -eq $fixture.State.Result -and $fixture.Error.Text -eq 'Не удалось войти. Проверьте имя и пароль или повторите попытку позже.') 'Rejected login shows generic core error and stays open'
 Assert-AccountUi ($fixture.Boxes.Password.Text -eq '' -and $fixture.Boxes.Username.Text -eq 'doctor' -and $fixture.Boxes.Password.Focused) 'Rejected login clears password while retaining username'
 $fixture=New-AccountUiFixture -Mode Login -Context $context -Username 'doctor' -Password 'Doctor password 71'
 & $fixture.Callback;$doctor=$fixture.State.Result
 Assert-AccountUi ($fixture.Dialog.Closed -and $doctor.Role -eq 'User' -and $doctor.UserId -ceq $doctorAccount.Id) 'Login callback returns the authenticated employee session'
 $fixture=New-AccountUiFixture -Mode Create -Session $doctor -Username 'forbidden' -DisplayName 'Forbidden' -Password 'Forbidden pass 71' -Confirmation 'Forbidden pass 71'
 & $fixture.Callback
 Assert-AccountUi (-not $fixture.Dialog.Closed -and $null -eq $fixture.State.Result -and @(Get-MedicalAccounts $admin | Where-Object Username -eq 'forbidden').Count -eq 0) 'Core authorization rejects account creation invoked through a user UI callback'
 $fixture=New-AccountUiFixture -Mode OwnPassword -Session $doctor -Password 'Updated doctor pass 71' -Confirmation 'Updated doctor pass 71' -CurrentPassword 'wrong current 71'
 & $fixture.Shown
 Assert-AccountUi ($fixture.Boxes.CurrentPassword.Focused) 'Password change focuses current password'
 & $fixture.Callback
 Assert-AccountUi (-not $fixture.Dialog.Closed -and $fixture.Boxes.Password.Text -eq '' -and $fixture.Boxes.ConfirmPassword.Text -eq '' -and $fixture.Boxes.CurrentPassword.Text -eq '' -and $fixture.Boxes.CurrentPassword.Focused) 'Rejected current password clears all password inputs and keeps dialog open'
 $fixture=New-AccountUiFixture -Mode OwnPassword -Session $doctor -Password 'Updated doctor pass 71' -Confirmation 'Updated doctor pass 71' -CurrentPassword 'Doctor password 71'
 & $fixture.Callback;$doctor=$fixture.State.Result
 Assert-AccountUi ($fixture.Dialog.Closed -and (Test-MedicalSession $doctor)) 'Own password change returns a renewed valid session'
 $fixture=New-AccountUiFixture -Mode Lock -Session $doctor -Password 'Updated doctor pass 71'
 & $fixture.Shown
 Assert-AccountUi ($fixture.Boxes.Password.Focused -and -not $fixture.Boxes.Username.Focused) 'Locked dialog focuses password rather than fixed username'
 & $fixture.Callback
 Assert-AccountUi ($fixture.Dialog.Closed -and $fixture.State.Result.UserId -ceq $doctor.UserId) 'Lock callback authenticates the same employee and returns fresh session'
 function Get-AccountUiWrongCandidate {param($Context,$Username,$Password)return [pscustomobject]@{UserId='other-account';Role='User'}}
 $fixture=New-AccountUiFixture -Mode Lock -Session $doctor -Password 'any password 71' -LoginOverride (Get-Command Get-AccountUiWrongCandidate -CommandType Function)
 & $fixture.Callback
 Assert-AccountUi (-not $fixture.Dialog.Closed -and $null -eq $fixture.State.Result -and $fixture.Boxes.Password.Text -eq '') 'Lock callback refuses a candidate for a different account'
 $fixture=New-AccountUiFixture -Mode Login -Context $context -Username 'doctor' -Password 'Updated doctor pass 71'
 $fixture.State.Busy=$true;& $fixture.Callback
 Assert-AccountUi (-not $fixture.Dialog.Closed -and $null -eq $fixture.State.Result -and $fixture.State.Busy) 'Busy login callback ignores duplicate submit'
 $fixture=New-AccountUiFixture -Mode ResetPassword -Session $admin -TargetUserId $doctorAccount.Id -TargetDisplayName 'Врач' -Password 'Reset doctor pass 71' -Confirmation 'Reset doctor pass 71'
 & $fixture.Callback
 Assert-AccountUi ($fixture.Dialog.Closed -and $fixture.State.Result -eq $true -and -not (Test-MedicalSession $doctor)) 'Administrative reset callback invalidates employee sessions'
 $resetSession=Invoke-MedicalAccountLogin $context 'doctor' 'Reset doctor pass 71'
 Assert-AccountUi ($resetSession.UserId -ceq $doctorAccount.Id) 'Employee can log in with the password set by administrator UI callback'
 $fixture=New-AccountUiManagerFixture $admin
 & $fixture.Refresh
 Assert-AccountUi ($fixture.Grid.Rows.Count -eq 3 -and $null -ne $fixture.State.Selected -and $fixture.Buttons.Enabled.Enabled) 'Manager refresh populates safe account rows and selects current row'
 Assert-AccountUi ($fixture.Grid.Rows[0].Tag.PSObject.Properties.Name -notcontains 'Password') 'Manager keeps only safe public account records in row tags'
 $fixture.Grid.ClearSelection();& $fixture.Select
 Assert-AccountUi ($null -eq $fixture.State.Selected -and -not $fixture.Buttons.Enabled.Enabled -and -not $fixture.Buttons.Role.Enabled -and -not $fixture.Buttons.Reset.Enabled) 'Empty grid selection disables account-specific actions'
 Select-AccountUiManagerUser $fixture 'doctor'
 Assert-AccountUi ($fixture.State.Selected.Username -eq 'doctor' -and $fixture.Buttons.Enabled.Text -eq 'Отключить') 'Selected enabled employee exposes disable action'
 & $fixture.Callbacks.Enabled
 Assert-AccountUi (-not $fixture.State.Selected.Enabled -and $fixture.Buttons.Enabled.Text -eq 'Включить' -and $fixture.State.Selected.Username -eq 'doctor' -and -not (Test-MedicalSession $resetSession)) 'Disable callback revokes employee session and keeps selection after refresh'
 & $fixture.Callbacks.Enabled
 Assert-AccountUi ($fixture.State.Selected.Enabled -and $fixture.Buttons.Enabled.Text -eq 'Отключить') 'Enable callback restores account access and button label'
 $script:accountUiChosenRole='Administrator';& $fixture.Callbacks.Role
 Assert-AccountUi ($fixture.State.Selected.Role -eq 'Administrator') 'Role callback applies the chosen administrator role and refreshes safe record'
 $script:accountUiChosenRole='User';& $fixture.Callbacks.Role
 Assert-AccountUi ($fixture.State.Selected.Role -eq 'User') 'Role callback restores ordinary user role'
 $beforeCount=$fixture.Grid.Rows.Count;$beforeEntry=$script:accountUiEntryCalls
 & $fixture.Callbacks.Create
 Assert-AccountUi ($script:accountUiEntryCalls -eq ($beforeEntry+1) -and $fixture.Grid.Rows.Count -eq $beforeCount -and -not $fixture.State.Busy) 'Cancelled create account dialog preserves manager rows and releases busy state'
 $beforeEntry=$script:accountUiEntryCalls;& $fixture.Callbacks.Reset
 Assert-AccountUi ($script:accountUiEntryCalls -eq ($beforeEntry+1) -and $fixture.State.Selected.Username -eq 'doctor') 'Other employee reset invokes reset dialog and retains selection when cancelled'
 Select-AccountUiManagerUser $fixture 'admin';$beforeOwn=$script:accountUiPasswordCalls;& $fixture.Callbacks.Reset
 Assert-AccountUi ($script:accountUiPasswordCalls -eq ($beforeOwn+1) -and (Test-MedicalSession $fixture.State.Session)) 'Reset on own account requires the own-password change dialog'
 $beforeOwn=$script:accountUiPasswordCalls;& $fixture.Callbacks.Own
 Assert-AccountUi ($script:accountUiPasswordCalls -eq ($beforeOwn+1) -and (Test-MedicalSession $fixture.State.Session)) 'My password action retains valid session after cancelled password change'
 $script:accountUiChosenRole=$null;& $fixture.Callbacks.Role
 Assert-AccountUi ($fixture.State.Session.Role -eq 'Administrator' -and -not $fixture.Dialog.Closed) 'Cancelled role dialog does not change administrator privileges'
 $fixture.State.Busy=$true;$beforeEntry=$script:accountUiEntryCalls;& $fixture.Callbacks.Create
 Assert-AccountUi ($script:accountUiEntryCalls -eq $beforeEntry -and $fixture.State.Busy) 'Manager busy guard ignores duplicate button submit'
 $fixture.State.Busy=$false;$script:accountUiChosenRole='User';& $fixture.Callbacks.Role
 Assert-AccountUi ($fixture.State.Session.Role -eq 'User' -and $fixture.Dialog.Closed -and (Test-MedicalSession $fixture.State.Session)) 'Self-demotion refreshes session role and closes administrator manager'
 $admin2=Invoke-MedicalAccountLogin $context 'admin2' 'Second admin pass 71'
 $fixture=New-AccountUiManagerFixture $admin2;& $fixture.Refresh;Select-AccountUiManagerUser $fixture 'admin2'
 $calls=[Windows.Forms.MessageBox]::Calls;& $fixture.Callbacks.Enabled
 Assert-AccountUi (-not $fixture.Dialog.Closed -and $fixture.State.Selected.Enabled -and [Windows.Forms.MessageBox]::Calls -eq ($calls+1) -and -not $fixture.State.Busy) 'Last administrator disable is rejected with feedback while manager remains usable'
 Close-MedicalSession $admin2;& $fixture.Refresh
 Assert-AccountUi ($null -eq $fixture.State.Session -and $fixture.Dialog.Closed) 'Revoked session closes manager and returns no authenticated session'
 $source=[IO.File]::ReadAllText($sourcePath)
 Assert-AccountUi ($source -match '\$box\.UseSystemPasswordChar=\$true') 'Native password fields use system password masking'
 Assert-AccountUi ($source -match '\$boxes\.Username\.ReadOnly=\$true' -and $source -match '\$boxes\.Username\.TabStop=\$false') 'Lock username is read-only and excluded from keyboard focus'
 Assert-AccountUi ($source -match 'finally\{foreach\(\$passwordBox in \$passwordBoxes\)\{\$passwordBox\.Clear\(\)\}') 'All dialog outcomes clear native password text before disposal'
 Assert-AccountUi ($source -notmatch 'Write-(Host|Output|Information|Verbose|Debug)|Out-File|Set-Content|Add-Content') 'Account dialogs do not log or write credentials to files'
 $login=$ast.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Show-MedicalLogin'},$false)
 Assert-AccountUi ($login.Extent.Text -match 'Get-MedicalAccountsState' -and $login.Extent.Text -notmatch 'New-MedicalFirstAdministrator' -and $login.Extent.Text -notmatch 'Initialize-MedicalAccounts') 'Login checks initialized state and does not recreate an invalid database'
 $manager=$ast.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Show-MedicalAccountManager'},$false)
 Assert-AccountUi ($manager.Extent.Text -match 'Assert-MedicalAdministrator' -and $manager.Extent.Text -match 'Test-MedicalSession') 'Account manager checks administrator authorization and refreshes session validity'
 foreach($action in @('Create','Enabled','Role','Reset','Own')){
  Assert-AccountUi ($manager.Extent.Text -match ('\$buttons\.'+$action+'\.Add_Click')) ('Account manager exposes '+$action+' action')
 }
 foreach($file in [IO.Directory]::GetFiles($context.AccountsDirectory)){
  $bytes=[IO.File]::ReadAllBytes($file);$text=[Text.Encoding]::UTF8.GetString($bytes)
  Assert-AccountUi ($text -notmatch 'Administrator test 71|Doctor password 71|Updated doctor pass 71|Reset doctor pass 71') 'Account files do not contain UI-entered plaintext passwords'
 }
 Write-Output ('TOTAL '+$script:checks+' checks passed; production callbacks run against fake widgets; native Windows dialogs not run.')
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
