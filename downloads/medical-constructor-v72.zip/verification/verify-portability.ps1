﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v72'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Check([bool]$test,[string]$label){if(-not $test){throw $label};$script:checks++;Write-Output ('PASS '+$label)}
function Import-TestFunctions([string]$path,[string[]]$names=@()){
 $t=$null;$e=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$t,[ref]$e)
 if($e.Count){throw ($e|Out-String)}
 foreach($node in $ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
  if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}
 }
}
function Capture-Stage {Set-UniversalDemographics}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-v69-portable-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
try{
 Import-TestFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart','Get-HospitalizationValues','Get-FullRegistration','Read-CaseDocument')
 foreach($module in @('universal.ps1','forms-v59.ps1','portable-paths-v69.ps1','card-document-v65.ps1','template-recovery-v66.ps1','template-editor-v59.ps1','template-editor-operations-v61.ps1','clinical-stages-v67.ps1','backup-v67.ps1')){Import-TestFunctions (Join-Path $Project $module)}
 Import-TestFunctions (Join-Path $Project 'universal-ui.ps1') @('Set-UniversalDemographics')
 $old=Join-Path $temp 'ПК Первый/Конструктор';$new=Join-Path $temp 'Флешка Второй ПК/Новая папка';$external=Join-Path $temp 'Первый профиль/Внешние документы'
 foreach($folder in @($old,$new,$external)){[void][IO.Directory]::CreateDirectory($folder)}
 $script:medicalProgramRoot=$old;$script:medicalTemplatesFolder=Join-Path $old 'Шаблоны';$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 foreach($name in @('patientNameControl','patientBirthControl','patientAddressControl','streetControl','houseControl','apartmentControl')){Set-Variable -Scope Script -Name $name -Value ([pscustomobject]@{Text=''})}
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-14T10:20:30'};$script:hospitalControls=@{}
 $script:universalConfig=New-UniversalConfig;$script:universalValues=@{patient_name='ПЕРЕНОСИМЫЙ ТЕСТ';complaints='НЕ ТЕРЯТЬ'};$script:universalDetails=@{}
 $script:stage='initial';$script:diaryIndex=1;$script:stageTemplates=@{initial='';diary='';discharge=''};$script:stageData=@{}
 $script:activeMedicalFormPath=Join-Path $old 'Моя форма.mcform';$script:activeMedicalFormName='Моя форма';$script:caseFolder=Join-Path $old 'Карты';[void][IO.Directory]::CreateDirectory($script:caseFolder)
 $script:caseFile=Join-Path $script:caseFolder 'Пациент.docx';$script:caseLastSavedPatientName='ПЕРЕНОСИМЫЙ ТЕСТ'
 $script:medicalWorkspaceReady=$true;$script:medicalBackupBusy=$false;$script:medicalBackupPath='';$script:medicalBackupFormSavedSignature='';$script:medicalBackupCaseSavedSignature='';$script:medicalBackupEditorDraft=$null;$script:medicalBackupRetainedDraft=$null
 $custom=New-MedicalTemplateFile 'Мой собственный Word.docx' $script:universalConfig;$customHash=(Get-FileHash -LiteralPath $custom.Path).Hash
 $script:universalConfig.AutoTemplate=$false;$script:universalConfig.Template=$custom.RelativePath;$script:stageTemplates.initial=$custom.Path
 [void](Initialize-MedicalClinicalWorkspace);$diary=Add-MedicalClinicalDiary;Set-MedicalClinicalValue 'diary' $diary.Id 'diary_complaints' 'ДНЕВНИК ПЕРЕНОСА';Set-MedicalClinicalValue 'discharge' '' 'recommendations' 'ЭПИКРИЗ ПЕРЕНОСА'
 [void](Write-MedicalForm $script:activeMedicalFormPath $script:universalConfig $script:activeMedicalFormName)
 New-UniversalTemplate $script:caseFile $script:universalConfig
 $record=[pscustomobject]@{version=49;universal=(Get-UniversalState);patientName='ПЕРЕНОСИМЫЙ ТЕСТ';TemplateSnapshots=(Get-MedicalCardTemplateSnapshots);ClinicalForms=(Get-MedicalClinicalPortableForms $true);ClinicalState=(Get-MedicalClinicalState);templates=$script:stageTemplates;stages=@{};diaryCount=1}
 Set-MedicalCardDocumentState $script:caseFile $record
 [void](Initialize-MedicalSessionBackup $old);$checkpoint=Write-MedicalSessionBackup
 Assert-Check ($checkpoint.Payload.Data.Location.ProgramRoot -ceq $old) 'Checkpoint records installation origin without machine or user identifier'
 Assert-Check ($checkpoint.Payload.Data.Location.FormRelative -ceq 'Моя форма.mcform') 'Form save path is recorded relative to program'
 Assert-Check ($checkpoint.Payload.Data.Location.CaseRelative -ceq 'Карты/Пациент.docx') 'Case save path is recorded relative to program'
 $oldHashes=@{};foreach($file in Get-ChildItem -LiteralPath $old -File -Recurse){$oldHashes[$file.FullName]=(Get-FileHash -LiteralPath $file.FullName).Hash}
 foreach($child in Get-ChildItem -LiteralPath $old){Copy-Item -LiteralPath $child.FullName -Destination $new -Recurse}
 $script:medicalProgramRoot=$new;$script:medicalTemplatesFolder=Join-Path $new 'Шаблоны'
 $script:universalValues=@{};$script:medicalClinicalForms=$null;$script:medicalClinicalState=$null
 $movedBackup=Join-Path $new 'Резервные копии/working-session.mcbak';$restored=Restore-MedicalSessionBackup $movedBackup
 Assert-Check ($script:activeMedicalFormPath -ceq (Join-Path $new 'Моя форма.mcform')) 'Actual backup restore rebinds form to copied installation'
 Assert-Check ($script:caseFile -ceq (Join-Path $new 'Карты/Пациент.docx')) 'Actual backup restore rebinds card to copied installation'
 Assert-Check ($script:caseFolder -ceq (Join-Path $new 'Карты')) 'Actual backup restore rebinds card folder'
 Assert-Check ($script:universalValues.patient_name -ceq 'ПЕРЕНОСИМЫЙ ТЕСТ' -and $script:universalValues.complaints -ceq 'НЕ ТЕРЯТЬ') 'Actual backup restore preserves initial patient values'
 $restoredSource=Get-UniversalTemplatePath
 Assert-Check ((Test-MedicalPortablePathInside $restoredSource $new) -and (Get-FileHash -LiteralPath $restoredSource).Hash -ceq $customHash) 'Custom Word source restores inside copied installation with exact original bytes'
 Assert-Check ((Get-MedicalClinicalContext 'diary' $diary.Id).Values.diary_complaints -ceq 'ДНЕВНИК ПЕРЕНОСА') 'Actual backup restore preserves diary values'
 Assert-Check ((Get-MedicalClinicalContext 'discharge').Values.recommendations -ceq 'ЭПИКРИЗ ПЕРЕНОСА') 'Actual backup restore preserves discharge values'
 $readForm=Read-MedicalForm $script:activeMedicalFormPath
 Assert-Check ($readForm.Name -ceq 'Моя форма' -and @($readForm.StageForms.Diaries).Count -eq 1) 'Actual copied mcform opens with all diary structure'
 Assert-Check (-not (($readForm | ConvertTo-Json -Depth 100) -match 'ПЕРЕНОСИМЫЙ ТЕСТ|ДНЕВНИК ПЕРЕНОСА|ЭПИКРИЗ ПЕРЕНОСА')) 'Reusable copied form contains no patient answers'
 $readCard=Read-CaseDocument $script:caseFile
 Assert-Check ($readCard.universal.Values.patient_name -ceq 'ПЕРЕНОСИМЫЙ ТЕСТ') 'Actual copied card is readable with patient values'
 Assert-Check (@($readCard.ClinicalForms.Diaries).Count -eq 1 -and $readCard.ClinicalState.Diaries[0].Values.diary_complaints -ceq 'ДНЕВНИК ПЕРЕНОСА') 'Copied card includes diary layout and answers'
 foreach($file in @($oldHashes.Keys)){Assert-Check ((Get-FileHash -LiteralPath $file).Hash -ceq $oldHashes[$file]) ('Original installation unchanged: '+[IO.Path]::GetFileName($file))}
 $outsideForm=Join-Path $external 'Внешняя.mcform';$outsideCard=Join-Path $external 'Внешняя.docx';[IO.File]::WriteAllText($outsideForm,'untouched form');[IO.File]::WriteAllText($outsideCard,'untouched case')
 $script:medicalProgramRoot=$old;$script:activeMedicalFormPath=$outsideForm;$script:caseFile=$outsideCard;$script:caseFolder=$external
 $data=[pscustomobject]@{Location=(Get-MedicalPortableSessionLocation);Form=@{Path=$outsideForm};Case=@{Path=$outsideCard;Folder=$external}}
 Restore-MedicalPortableSessionLocation $data
 Assert-Check ($script:activeMedicalFormPath -ceq $outsideForm -and $script:caseFile -ceq $outsideCard) 'Existing external destinations remain when installation has not moved'
 $script:medicalProgramRoot=$new;Restore-MedicalPortableSessionLocation $data
 Assert-Check (-not $script:activeMedicalFormPath -and -not $script:caseFile -and -not $script:caseFolder) 'Moved installation clears external targets even if old files still exist'
 Assert-Check ($null -eq $script:caseLastSavedPatientName) 'Cleared case destination requires a new user-selected save'
 Assert-Check ([IO.File]::ReadAllText($outsideForm) -ceq 'untouched form' -and [IO.File]::ReadAllText($outsideCard) -ceq 'untouched case') 'External previous-PC files remain unchanged'
 $data.Location=$null;Restore-MedicalPortableSessionLocation $data
 Assert-Check (-not $script:activeMedicalFormPath -and -not $script:caseFile) 'Legacy checkpoint without root provenance does not adopt external files'
 $data.Form.Path=Join-Path $new 'Моя форма.mcform';$data.Case.Path=Join-Path $new 'Карты/Пациент.docx';$data.Case.Folder=Join-Path $new 'Карты';Restore-MedicalPortableSessionLocation $data
 Assert-Check ($script:activeMedicalFormPath -ceq $data.Form.Path -and $script:caseFile -ceq $data.Case.Path) 'Legacy checkpoint may keep exact existing current-folder targets'
 $data.Location=[pscustomobject]@{Version=1;ProgramRoot=$old;FormRelative='missing.mcform';CaseRelative='missing.docx';FolderRelative='missing'};Restore-MedicalPortableSessionLocation $data
 Assert-Check (-not $script:activeMedicalFormPath -and -not $script:caseFile -and -not $script:caseFolder) 'Missing relocated targets require choosing a destination'
 foreach($bad in @('../Внешняя.docx','..\Внешняя.docx','C:\Внешняя.docx','\\server\share\Внешняя.docx','/tmp/outside.docx')){Assert-Check (-not (Resolve-MedicalPortableRelativePath $bad $new)) ('Escaping or absolute portable reference rejected: '+$bad)}
 Assert-Check (-not (Test-MedicalPortablePathInside ($new+'-other/file.docx') $new)) 'Sibling with shared path prefix is not inside installation'
 Assert-Check ((Resolve-MedicalPortableRelativePath '.' $new $true) -ceq $new) 'Portable root directory itself can be restored'
 Assert-Check ((Get-MedicalPortableRelativePath $new ($new+[IO.Path]::DirectorySeparatorChar)) -ceq '.') 'Trailing directory separator retains portable root mapping'
 Assert-Check ((Get-MedicalPortableRelativePath ([IO.Path]::GetPathRoot($new)) ([IO.Path]::GetPathRoot($new))) -ceq '.') 'Drive root retains portable root mapping'
 Assert-Check ((Resolve-MedicalPortableRelativePath 'Карты\Пациент.docx' $new) -ceq (Join-Path $new 'Карты/Пациент.docx')) 'Windows separators in relative card paths relocate safely'
 Assert-Check ((Get-MedicalPortableSaveDirectory (Join-Path $new 'deleted/Моя форма.mcform')) -ceq $new) 'Save dialog falls back to program folder for a deleted previous directory'
 Assert-Check ((Get-MedicalPortableSaveDirectory (Join-Path $new 'Моя форма.mcform')) -ceq $new) 'Save dialog uses valid current form directory'
 $ctor=[IO.File]::ReadAllText((Join-Path $Project 'constructor.ps1'))
 Assert-Check ($ctor.Contains("'portable-paths-v69.ps1'")) 'Portable destination helpers are loaded by production constructor'
 $vbs=[IO.File]::ReadAllText((Join-Path $Project 'Медицинский конструктор.vbs'))
 Assert-Check ($vbs.Contains('WScript.ScriptFullName') -and $vbs.Contains('fs.BuildPath(dir, "launcher.ps1")')) 'VBS launcher resolves script from its own location'
 $launcher=[IO.File]::ReadAllText((Join-Path $Project 'launcher.ps1'))
 Assert-Check ($launcher.Contains('$MyInvocation.MyCommand.Path') -and $launcher.Contains("Join-Path `$root 'constructor.ps1'")) 'PowerShell launcher resolves its own program location'
 $start=[IO.File]::ReadAllText((Join-Path $Project 'START.cmd'))
 Assert-Check ($start.Contains('%~dp0constructor.ps1')) 'Command launcher resolves its own program location'
 Write-Output ('CHECKS '+$script:checks)
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
