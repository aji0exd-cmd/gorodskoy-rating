﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v72'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Check([bool]$test,[string]$label){if(-not $test){throw $label};$script:checks++;Write-Output ('PASS '+$label)}
function Assert-Reject([scriptblock]$operation,[string]$label){$threw=$false;try{& $operation | Out-Null}catch{$threw=$true};Assert-Check $threw $label}
function Import-TestFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors|Out-String)}
 foreach($node in $ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}}
}
function Get-TestXml([string]$path,[string]$part='word/document.xml'){$z=[IO.Compression.ZipFile]::OpenRead($path);try{return (Get-XmlPart $z $part)}finally{$z.Dispose()}}
function Get-TestText([string]$path,[string]$part='word/document.xml'){$x=Get-TestXml $path $part;$n=New-Object Xml.XmlNamespaceManager($x.NameTable);$n.AddNamespace('w',$script:ns);return (($x.SelectNodes('//w:t',$n)|ForEach-Object {$_.InnerText}) -join '')}
function Set-TestXml([string]$path,[string]$part,[string]$xml){$z=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update);try{$entry=$z.GetEntry($part);if($entry){$entry.Delete()};Write-UniversalZipText $z $part $xml}finally{$z.Dispose()}}
function Apply-DocumentFont($path){}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-diary-period-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 Import-TestFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
 foreach($module in @('universal.ps1','forms-v59.ps1','clinical-stages-v67.ps1','diary-period-v69.ps1','clinical-ui-v67.ps1','diary-document-v67.ps1','template-recovery-v66.ps1','card-document-v65.ps1','backup-v67.ps1')){Import-TestFunctions (Join-Path $Project $module)}
 $script:medicalProgramRoot=$temp;$script:medicalTemplatesFolder=Join-Path $temp 'Шаблоны';$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-01T10:20:30'}
 $script:universalConfig=New-UniversalConfig;$script:universalValues=@{patient_name='ТЕСТ ДИАПАЗОНА';complaints='ИСХОДНЫЕ ЖАЛОБЫ'};$script:universalDetails=@{}
 $script:medicalClinicalForms=$null;$script:medicalClinicalState=$null
 [void](Initialize-MedicalClinicalWorkspace);$first=Add-MedicalClinicalDiary;$second=Add-MedicalClinicalDiary
 Assert-Check ($first.DateCount -eq 1 -and $first.EndDateTime -eq $first.DateTime) 'New diaries default to one date with matching hidden end'
 Set-MedicalDiaryDateCount $first.Id 2
 Set-MedicalDiaryDates $first.Id ([datetime]'2026-10-02T09:15:00') ([datetime]'2026-10-05T11:45:00')
 $first=Get-MedicalClinicalContext 'diary' $first.Id
 Assert-Check ($first.DateCount -eq 2 -and $first.DateTime -eq [datetime]'2026-10-02T09:15:00' -and $first.EndDateTime -eq [datetime]'2026-10-05T11:45:00') 'Individual diary has independently editable start and end'
 Assert-Check ((Get-MedicalClinicalContext 'diary' $second.Id).DateCount -eq 1) 'Changing one diary leaves the other in one-date mode'
 Set-MedicalClinicalValue 'diary' $first.Id 'diary_complaints' 'ОСМОТР ЗА ПЕРИОД'
 $original=Get-MedicalClinicalState | ConvertTo-Json -Depth 70 -Compress
 Assert-Reject {Set-MedicalDiaryDates $first.Id ([datetime]'2026-10-06') ([datetime]'2026-10-05')} 'Reversed period rejected before state mutation'
 Assert-Check ((Get-MedicalClinicalState | ConvertTo-Json -Depth 70 -Compress) -ceq $original) 'Invalid range leaves all patient answers untouched'
 Assert-Reject {Set-MedicalDiaryDateCount $first.Id 3} 'Unsupported number of diary dates rejected'
 foreach($bad in @('2026-02-30T10:00:00','02.10.2026 10:00','1700-01-01T00:00:00')){Assert-Reject {Set-MedicalDiaryDates $first.Id $bad '2026-10-05T11:45:00'} ('Invalid diary start rejected: '+$bad)}
 Set-MedicalDiaryDateCount $first.Id 1
 Assert-Check ((Get-MedicalClinicalContext 'diary' $first.Id).EndDateTime -eq [datetime]'2026-10-05T11:45:00') 'Switching to one date preserves previously chosen range end'
 Set-MedicalDiaryDateCount $first.Id 2
 Assert-Check ((Get-MedicalClinicalContext 'diary' $first.Id).EndDateTime -eq [datetime]'2026-10-05T11:45:00') 'Switching back restores chosen end date'
 Set-MedicalClinicalDate $first.Id ([datetime]'2026-10-03T09:15:00')
 Assert-Check ((Get-MedicalClinicalContext 'diary' $first.Id).EndDateTime -eq [datetime]'2026-10-05T11:45:00') 'Editing range start retains a later valid end'
 Set-MedicalClinicalDate $first.Id ([datetime]'2026-10-06T12:00:00')
 Assert-Check ((Get-MedicalClinicalContext 'diary' $first.Id).EndDateTime -eq [datetime]'2026-10-06T12:00:00') 'Moving start beyond end keeps valid date order'
 Set-MedicalDiaryDates $first.Id ([datetime]'2026-10-02T09:15:00') ([datetime]'2026-10-05T11:45:00')
 $forms=Get-MedicalClinicalFormData;$state=Get-MedicalClinicalState
 Assert-Check ($forms.Diaries[0].DateCount -eq 2 -and $forms.Diaries[1].DateCount -eq 1) 'Reusable form preserves each diary date mode'
 $formJson=$forms|ConvertTo-Json -Depth 70 -Compress
 foreach($secret in @('EndDateTime','2026-10-02','2026-10-05','ОСМОТР ЗА ПЕРИОД','ТЕСТ ДИАПАЗОНА')){Assert-Check (-not $formJson.Contains($secret)) ('Reusable structure excludes patient data '+$secret)}
 $legacyForms=Copy-UniversalObject $forms;$legacyForms.Diaries[0].PSObject.Properties.Remove('DateCount')
 Assert-Check ((Copy-MedicalClinicalFormData $legacyForms).Diaries[0].DateCount -eq 1) 'Legacy diary forms without DateCount remain one-date forms'
 foreach($bad in @($true,0,3,'2',2.0)){
  $invalid=Copy-UniversalObject $forms;$invalid.Diaries[0].DateCount=$bad
  Assert-Reject {Copy-MedicalClinicalFormData $invalid} ('Malformed form date mode rejected: '+[string]$bad+' '+$bad.GetType().Name)
 }
 $portable=Get-MedicalClinicalPortableForms $false $forms
 Assert-Check ($portable.Diaries[0].DateCount -eq 2 -and $portable.Diaries[0].TemplateBase64.Length -gt 500) 'Portable form embeds range choice alongside clean Word source'
 $mcform=Join-Path $temp 'Периоды.mcform';[void](Write-MedicalForm $mcform $script:universalConfig 'Периоды' $forms);$read=Read-MedicalForm $mcform
 Assert-Check ($read.StageForms.Diaries[0].DateCount -eq 2 -and $read.StageForms.Diaries[1].DateCount -eq 1) 'Saved and reopened mcform retains individual diary date choices'
 $savedForm=[IO.File]::ReadAllText($mcform)
 foreach($secret in @('2026-10-02T09:15:00','2026-10-05T11:45:00','ОСМОТР ЗА ПЕРИОД')){Assert-Check (-not $savedForm.Contains($secret)) ('Actual mcform excludes '+$secret)}
 $legacyState=Copy-UniversalObject $state;$legacyState.Diaries[0].PSObject.Properties.Remove('EndDateTime')
 Assert-Check ((ConvertTo-MedicalDiaryDate (Copy-MedicalClinicalPatientState $legacyState $forms).Diaries[0].EndDateTime 'окончания') -eq (ConvertTo-MedicalDiaryDate $state.Diaries[0].DateTime 'начала')) 'Legacy card missing end timestamp defaults to its existing date'
 foreach($bad in @('2026-10-01T10:00:00','2026-02-30T10:00:00','1700-01-01T00:00:00')){
  $invalid=Copy-UniversalObject $state;$invalid.Diaries[0].EndDateTime=$bad
  Assert-Reject {Test-MedicalClinicalState $invalid $forms} ('Damaged card/backup range rejected: '+$bad)
 }
 [void](Initialize-MedicalClinicalWorkspace $portable)
 Assert-Check ((Get-MedicalClinicalContext 'diary' $first.Id).DateCount -eq 2 -and [string]::IsNullOrEmpty((Get-MedicalClinicalContext 'diary' $first.Id).Values.diary_complaints)) 'Opening reusable range form keeps mode and clears patient answers'
 Restore-MedicalClinicalState ($state|ConvertTo-Json -Depth 70 -Compress|ConvertFrom-Json)
 $first=Get-MedicalClinicalContext 'diary' $first.Id
 Assert-Check ($first.DateTime -eq [datetime]'2026-10-02T09:15:00' -and $first.EndDateTime -eq [datetime]'2026-10-05T11:45:00' -and $first.Values.diary_complaints -ceq 'ОСМОТР ЗА ПЕРИОД') 'Restored card/backup state keeps both timestamps and patient answers'
 $auto=Join-Path $temp 'auto.docx';Save-UniversalDocument $auto $first.Schema $first.Values $first.DateTime $first.Details $true 'diary';Set-MedicalDiaryPeriodDocument $auto $first
 $text=Get-TestText $auto
 Assert-Check ($text.Contains('Период осмотра: 02.10.2026 09:15 — 05.10.2026 11:45')) 'Generated diary shows entire inspection period in Word'
 Set-MedicalDiaryPeriodDocument $auto $first;$xml=Get-TestXml $auto;$n=New-Object Xml.XmlNamespaceManager($xml.NameTable);$n.AddNamespace('w',$script:ns)
 Assert-Check ($xml.SelectNodes('//w:bookmarkStart[@w:name="MedicalDiaryPeriod"]',$n).Count -eq 1) 'Repeated range formatting never duplicates fallback paragraph'
 $one=Copy-UniversalObject $first;$one.DateCount=1;Set-MedicalDiaryPeriodDocument $auto $one
 Assert-Check (-not (Get-TestText $auto).Contains('Период осмотра:')) 'Changing rendered copy to one date removes old fallback line'
 $source=Join-Path $temp 'custom.docx';New-UniversalTemplate $source $first.Schema
 $x=Get-TestXml $source;$body=$x.SelectSingleNode('/w:document/w:body',$n)
 $custom=[xml]('<w:p xmlns:w="'+$script:ns+'"><w:r><w:rPr><w:b/></w:rPr><w:t>Период: {{DIARY_STA</w:t></w:r><w:r><w:t>RT_DATE}} — {{DIARY_END_DATE}}; {{DIARY_PERIOD}}</w:t></w:r></w:p>')
 [void]$body.InsertBefore($x.ImportNode($custom.DocumentElement,$true),$body.FirstChild)
 Set-TestXml $source 'word/document.xml' $x.OuterXml
 Set-TestXml $source 'word/header1.xml' ('<w:hdr xmlns:w="'+$script:ns+'"><w:p><w:sdt><w:sdtPr><w:id w:val="99001"/><w:tag w:val="DIARY_END_DATETIME"/></w:sdtPr><w:sdtContent><w:r><w:t>Выберите дату</w:t></w:r></w:sdtContent></w:sdt></w:p></w:hdr>')
 $hash=(Get-FileHash $source).Hash;$schema=Copy-MedicalFormSchema $first.Schema;$schema.AutoTemplate=$false;$schema.Template=$source;$context=Copy-UniversalObject $first;$context.Schema=$schema
 $customOut=Join-Path $temp 'custom-out.docx';Save-UniversalDocument $customOut $schema $context.Values $context.DateTime $context.Details $true 'diary';Set-MedicalDiaryPeriodDocument $customOut $context
 Assert-Check ((Get-TestText $customOut).Contains('Период: 02.10.2026 — 05.10.2026; 02.10.2026 — 05.10.2026')) 'Custom split-run markers resolve using this diary start and end'
 Assert-Check ((Get-TestText $customOut 'word/header1.xml').Contains('05.10.2026 11:45')) 'Header content control resolves range timestamp'
 Assert-Check (-not (Get-TestText $customOut).Contains('Период осмотра:')) 'Explicit full-range placement suppresses extra fallback line'
 Assert-Check (-not (Get-TestText $customOut).Contains('{{DIARY_')) 'Completed Word contains no unresolved diary markers'
 $priorOutputHash=(Get-FileHash $customOut).Hash
 Assert-Reject {Save-UniversalDocument $customOut $schema $context.Values $context.DateTime $context.Details $true} 'Diary range markers in initial-examination template are rejected before output commit'
 Assert-Check ((Get-FileHash $customOut).Hash -ceq $priorOutputHash -and (Get-FileHash $source).Hash -ceq $hash) 'Wrong-stage marker rejection preserves previous output and original Word source'
 $outXml=Get-TestXml $customOut
 Assert-Check ($outXml.SelectNodes('//w:rPr/w:b',$n).Count -gt 0) 'Replacing split range markers preserves authored run formatting'
 Set-MedicalDiaryPeriodDocument $customOut $context
 Assert-Check (-not (Get-TestText $customOut).Contains('Период осмотра:')) 'Repeated authored marker processing does not add a duplicate range'
 Assert-Reject {Set-MedicalDiaryPeriodDocument $source $context} 'Range formatting refuses to modify original Word source'
 Assert-Check ((Get-FileHash $source).Hash -ceq $hash) 'Original Word source bytes remain unchanged'
 # A parent Word content control can erase nested system markers after its
 # own patient answer is filled. The complete range must still be visible.
 $lostSource=Join-Path $temp 'nested-parent.docx';New-UniversalTemplate $lostSource $first.Schema
 $lostXml=Get-TestXml $lostSource;$lostBody=$lostXml.SelectSingleNode('/w:document/w:body',$n)
 $nested=[xml]('<w:p xmlns:w="'+$script:ns+'"><w:sdt><w:sdtPr><w:id w:val="99100"/><w:tag w:val="DIARY_COMPLAINTS"/></w:sdtPr><w:sdtContent><w:r><w:t>{{DIARY_START_DATE}} — {{DIARY_END_DATE}}</w:t></w:r></w:sdtContent></w:sdt></w:p>')
 [void]$lostBody.InsertBefore($lostXml.ImportNode($nested.DocumentElement,$true),$lostBody.FirstChild);Set-TestXml $lostSource 'word/document.xml' $lostXml.OuterXml
 $lostContext=Copy-UniversalObject $first;$lostContext.Schema.AutoTemplate=$false;$lostContext.Schema.Template=$lostSource
 $lostOut=Join-Path $temp 'nested-parent-out.docx';Save-UniversalDocument $lostOut $lostContext.Schema $lostContext.Values $lostContext.DateTime $lostContext.Details $true 'diary'
 Assert-Check (-not (Get-TestText $lostOut).Contains('{{DIARY_')) 'Filled parent control can erase nested range tokens during normal render'
 Set-MedicalDiaryPeriodDocument $lostOut $lostContext
 Assert-Check ((Get-TestText $lostOut).Contains('Период осмотра: 02.10.2026 09:15 — 05.10.2026 11:45')) 'Fallback adds complete period when parent content control erased its markers'
 $annotation=Get-TestXml $customOut 'customXml/mc-diary-period.xml'
 Assert-Check ($annotation.DocumentElement.GetAttribute('names').Contains('DIARY_PERIOD') -and -not $annotation.OuterXml.Contains('2026')) 'Private annotation records resolved marker names without patient dates'
 $mergeCopy=Join-Path $temp 'premerge.docx';[IO.File]::Copy($customOut,$mergeCopy)
 Remove-MedicalDiarySnapshotState $mergeCopy
 $mergeArchive=[IO.Compression.ZipFile]::OpenRead($mergeCopy)
 try{
  Assert-Check (-not $mergeArchive.GetEntry('customXml/mc-diary-period.xml')) 'Private diary marker annotation removed before Word merge'
  $types=Get-XmlPart $mergeArchive '[Content_Types].xml';$rels=Get-XmlPart $mergeArchive 'word/_rels/document.xml.rels'
  Assert-Check (-not $types.OuterXml.Contains('mc-diary-period.xml') -and -not $rels.OuterXml.Contains('mc-diary-period.xml')) 'Premerge cleanup removes annotation package type and relationship'
 }finally{$mergeArchive.Dispose()}
 Assert-Check ((Get-TestText $mergeCopy).Contains('Период: 02.10.2026 — 05.10.2026')) 'Removing private annotation leaves authored visible period unchanged'
 # Actual card package round trip keeps both dates in patient state.
 $record=[pscustomobject]@{version=49;universal=(Get-UniversalState);stages=[pscustomobject]@{};templates=[pscustomobject]@{};admissionDate='2026-10-01';ClinicalForms=$portable;ClinicalState=$state}
 Set-MedicalCardDocumentState $customOut $record
 $zip=[IO.Compression.ZipFile]::OpenRead($customOut);try{$card=Read-MedicalCardDocumentState $zip}finally{$zip.Dispose()}
 Assert-Check ($card.ClinicalForms.Diaries[0].DateCount -eq 2 -and (ConvertTo-MedicalDiaryDate $card.ClinicalState.Diaries[0].EndDateTime 'окончания') -eq [datetime]'2026-10-05T11:45:00') 'Actual saved DOCX state round trip preserves per-diary range and end'
 [void](Test-MedicalClinicalState $card.ClinicalState $card.ClinicalForms)
 Assert-Check ((Get-TestText $customOut).Contains('02.10.2026 — 05.10.2026')) 'Adding full card state leaves the rendered period visible'
 $data=[pscustomobject]@{WorkspaceReady=$true;Record=$record;ClinicalForms=$portable;Clinical=$state;EditorDraft=$null;Form=[pscustomobject]@{Path='';Name='Периоды'};Case=[pscustomobject]@{Path='';Folder='';LastPatientName=$null};View=[pscustomobject]@{Stage='diary';DiaryIndex=1;ActiveDiaryId=$first.Id}}
 $formSignature=Get-MedicalBackupFormSignature $data;$caseSignature=Get-MedicalBackupCaseSignature $data
 $differentMode=Copy-UniversalObject $data;$differentMode.ClinicalForms.Diaries[0].DateCount=1
 Assert-Check ((Get-MedicalBackupFormSignature $differentMode) -cne $formSignature) 'Changing date-count choice marks reusable form as unsaved'
 $differentEnd=Copy-UniversalObject $data;$differentEnd.Clinical.Diaries[0].EndDateTime='2026-10-06T15:00:00'
 Assert-Check ((Get-MedicalBackupFormSignature $differentEnd) -ceq $formSignature) 'Changing patient end date never marks form structure as changed'
 Assert-Check ((Get-MedicalBackupCaseSignature $differentEnd) -cne $caseSignature) 'Changing patient end date marks card as unsaved'
 $backupFile=Join-Path $temp 'range.mcbak'
 $payload=[pscustomobject]@{Data=$data;FormSavedSignature='';CaseSavedSignature='';FormSignature=$formSignature;CaseSignature=$caseSignature}
 $envelope=[pscustomobject]@{Format='MedicalConstructorSession';Version=1;CreatedUtc=[datetime]::UtcNow.ToString('o');Closed=$false;PayloadJson=($payload|ConvertTo-Json -Depth 100 -Compress);Sha256='';CanonicalOrder='OrdinalV69'}
 $envelope.Sha256=Get-MedicalBackupEnvelopeHash $envelope
 [IO.File]::WriteAllText($backupFile,($envelope|ConvertTo-Json -Depth 10 -Compress),[Text.UTF8Encoding]::new($false))
 $backup=Read-MedicalSessionBackup $backupFile
 Assert-Check ($backup.Payload.Data.ClinicalForms.Diaries[0].DateCount -eq 2 -and (ConvertTo-MedicalDiaryDate $backup.Payload.Data.Clinical.Diaries[0].EndDateTime 'окончания') -eq [datetime]'2026-10-05T11:45:00') 'Actual backup envelope verifies and retains two diary dates'
 $badPayload=Copy-UniversalObject $payload;$badPayload.Data.Clinical.Diaries[0].EndDateTime='2026-10-01T00:00:00'
 $badPayload.CaseSignature=Get-MedicalBackupCaseSignature $badPayload.Data
 $envelope.PayloadJson=$badPayload|ConvertTo-Json -Depth 100 -Compress;$envelope.Sha256=Get-MedicalBackupEnvelopeHash $envelope
 [IO.File]::WriteAllText($backupFile,($envelope|ConvertTo-Json -Depth 10 -Compress),[Text.UTF8Encoding]::new($false))
 Assert-Reject {Read-MedicalSessionBackup $backupFile} 'Backup with valid checksum but reversed diary range is rejected'
 $singleContext=Copy-UniversalObject $context;$singleContext.DateCount=1;$singleOut=Join-Path $temp 'single.docx';Save-UniversalDocument $singleOut $schema $singleContext.Values $singleContext.DateTime $singleContext.Details $true 'diary';Set-MedicalDiaryPeriodDocument $singleOut $singleContext
 Assert-Check ((Get-TestText $singleOut).Contains('Период: 02.10.2026 — 02.10.2026; 02.10.2026')) 'One-date mode resolves optional end markers to the single selected date'
 foreach($marker in @('DIARY_START_DATE','DIARY_END_DATE','DIARY_START_DATETIME','DIARY_END_DATETIME','DIARY_PERIOD')){
  $badSchema=Copy-MedicalFormSchema $script:universalConfig;$badSchema.Sections[0].Fields[0].Marker=$marker
  Assert-Reject {Assert-UniversalConfig $badSchema} ('Diary system marker cannot be assigned to ordinary field '+$marker)
 }
 # Production event handlers run against lightweight native-control substitutes.
 Add-Type -CompilerOptions /langversion:5 -TypeDefinition @"
using System;using System.Collections;
public class RangeWidget {
 public object Tag {get;set;} public object Margin {get;set;} public bool AutoSize {get;set;} public bool Visible {get;set;} public int Width {get;set;} public string Text {get;set;} public string Format {get;set;} public string CustomFormat {get;set;} public string DropDownStyle {get;set;}
 public ArrayList Controls=new ArrayList(); public ArrayList Items=new ArrayList(); private int selected=-1;private DateTime value=DateTime.Now;
 public int SelectedIndex {get{return selected;}set{if(selected==value)return;selected=value;if(SelectedIndexChanged!=null)SelectedIndexChanged(this,EventArgs.Empty);}}
 public DateTime Value {get{return value;}set{if(this.value==value)return;this.value=value;Text="";if(ValueChanged!=null)ValueChanged(this,EventArgs.Empty);}}
 public event EventHandler SelectedIndexChanged;public event EventHandler ValueChanged;
}
public class SafeComboBox:RangeWidget{}
namespace Windows.Forms {public class FlowLayoutPanel:RangeWidget{}public class Label:RangeWidget{}public class DateTimePicker:RangeWidget{}public class Padding {public Padding(int a,int b,int c,int d){}}public static class MessageBox {public static int Calls=0;public static int Show(params object[] values){Calls++;return 0;}}}
"@
 $script:stage='diary';$script:medicalClinicalBuilding=$false;$context=Get-MedicalClinicalContext 'diary' $first.Id
 $toolbar=New-Object Windows.Forms.FlowLayoutPanel;$label=New-Object Windows.Forms.Label;$start=New-Object Windows.Forms.DateTimePicker;$start.Value=$context.DateTime
 $binding=[pscustomobject]@{Stage='diary';Id=$first.Id;DateControl=$start}
 $start.Tag=$binding;$start.Add_ValueChanged({Invoke-MedicalDiaryStartDateChanged $this.Tag $this.Value})
 Add-MedicalDiaryPeriodControls $toolbar $binding $context $label
 Assert-Check ($binding.DiaryModeControl.SelectedIndex -eq 1 -and $binding.DiaryEndControl.Visible -and $label.Text -ceq 'С') 'Range diary opens with visible start/end controls and correct selector'
 $binding.DiaryModeControl.SelectedIndex=0
 Assert-Check ((Get-MedicalClinicalContext 'diary' $first.Id).DateCount -eq 1 -and -not $binding.DiaryEndControl.Visible -and $label.Text -ceq 'Дата и время записи') 'Native selector event immediately switches this diary to one date'
 $binding.DiaryModeControl.SelectedIndex=1
 $binding.DiaryEndControl.Value=[datetime]'2026-10-07T12:30:00'
 Assert-Check ((Get-MedicalClinicalContext 'diary' $first.Id).EndDateTime -eq [datetime]'2026-10-07T12:30:00') 'Native end-date event stores independent range end'
 $binding.DiaryEndControl.Value=[datetime]'2026-10-01T12:30:00'
 Assert-Check ([Windows.Forms.MessageBox]::Calls -eq 1 -and (Get-MedicalClinicalContext 'diary' $first.Id).EndDateTime -eq [datetime]'2026-10-07T12:30:00') 'Invalid end-date event warns without changing saved range'
 Assert-Check ($binding.DiaryEndControl.Value -ge $binding.DateControl.Value) 'Invalid end-date widget is restored to a valid value'
 $start.Value=[datetime]'2026-10-08T10:00:00'
 Assert-Check ($binding.DiaryEndControl.Value -eq [datetime]'2026-10-08T10:00:00' -and (Get-MedicalClinicalContext 'diary' $first.Id).EndDateTime -eq [datetime]'2026-10-08T10:00:00') 'Moving start past end updates visible and saved end together'
 $start.Text='09.10.2026 09:00';$binding.DiaryEndControl.Text='11.10.2026 18:00';Capture-MedicalDiaryPeriodControls $binding
 $current=Get-MedicalClinicalContext 'diary' $first.Id
 Assert-Check ($current.DateTime -eq [datetime]'2026-10-09T09:00:00' -and $current.EndDateTime -eq [datetime]'2026-10-11T18:00:00') 'Save-time capture commits typed start and end before export'
 $beforeInvalid=(Get-MedicalClinicalState|ConvertTo-Json -Depth 70 -Compress);$start.Text='12.10.2026 09:00';$binding.DiaryEndControl.Text='10.10.2026 18:00'
 Assert-Reject {Capture-MedicalDiaryPeriodControls $binding} 'Save-time capture rejects a reversed typed range'
 Assert-Check ((Get-MedicalClinicalState|ConvertTo-Json -Depth 70 -Compress) -ceq $beforeInvalid) 'Invalid typed range never mutates saved patient timestamps'
 Write-Output ('TOTAL '+$script:checks+' diary period checks passed')
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
