﻿param(
 [string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v72'),
 [string]$LegacyProject=(Join-Path (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) 'medical-constructor-v63/Медицинский конструктор v63')
)
$ErrorActionPreference='Stop'
$script:layoutChecks=0
function Assert-Layout([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:layoutChecks++;Write-Output ('PASS '+$message)}
$sourcePath=Join-Path $Project 'universal-ui.ps1'
$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($sourcePath,[ref]$tokens,[ref]$errors)
Assert-Layout ($errors.Count -eq 0) 'Production universal form module parses without errors'
$bytes=[IO.File]::ReadAllBytes($sourcePath)
Assert-Layout ($bytes.Length -gt 3 -and $bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191) 'Production universal form retains UTF-8 BOM for Windows PowerShell 5.1'
# A scroll reset calls ScrollWindowEx with SW_SCROLLCHILDREN on Windows.
# This model applies that delta to each existing child window, while preserving
# the distinction between a child's visible Top and its content coordinates.
# It deliberately does not reset the display origin during suspended Clear().
# These are the native behaviors that previously made a replacement child move.
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @'
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
public class MedicalLayoutControl {
 public MedicalLayoutControls Controls {get;private set;}
 public MedicalLayoutControl Parent {get;set;}
 public Point Location {get;set;}
 public int Top {get{return Location.Y;}set{Location=new Point(Location.X,value);}}
 public int Left {get{return Location.X;}set{Location=new Point(value,Location.Y);}}
 public int Width {get;set;}
 private int height=30;
 public int Height {get {
  if(!AutoSize)return height;
  int size=0;
  foreach(MedicalLayoutControl child in Controls){
   int childSize=child.Height+child.Margin.Top+child.Margin.Bottom;
   if(RowCount==1 || (this is Windows.Forms.FlowLayoutPanel && FlowDirection!="TopDown"))size=Math.Max(size,childSize);
   else size+=childSize;
  }
  return Math.Max(22,size+Padding.Top+Padding.Bottom);
 }set{height=value;}}
 public int Bottom {get{return Top+Height;}}
 public bool AutoSize {get;set;}
 public string AutoSizeMode {get;set;}
 public string Anchor {get;set;}
 public string Dock {get;set;}
 public string FlowDirection {get;set;}
 public bool WrapContents {get;set;}
 public bool AutoScroll {get;set;}
 public bool Enabled {get;set;}
 public bool IsDisposed {get;private set;}
 public bool Multiline {get;set;}
 public bool AcceptsReturn {get;set;}
 public string ScrollBars {get;set;}
 public string CustomFormat {get;set;}
 public string Text {get;set;}
 public string AccessibleName {get;set;}
 public string TextAlign {get;set;}
 public object Tag {get;set;}
 public object Font {get;set;}
 public object BackColor {get;set;}
 public object ForeColor {get;set;}
 public Size ClientSize {get;set;}
 public Size MinimumSize {get;set;}
 public Size MaximumSize {get;set;}
 public Size Size {get{return new Size(Width,Height);}set{Width=value.Width;Height=value.Height;}}
 public Windows.Forms.Padding Padding {get;set;}
 public Windows.Forms.Padding Margin {get;set;}
 public ArrayList ColumnStyles {get;private set;}
 public int ColumnCount {get;set;}
 public int RowCount {get;set;}
 public int SuspendCount {get;private set;}
 public int ResumeCount {get;private set;}
 public int LayoutCount {get;private set;}
 public int RefreshCount {get;private set;}
 public Size AutoScrollMinSize {get;set;}
 private Point scroll=Point.Empty;
 public Point AutoScrollPosition {get{return scroll;}set{
  Point incoming=new Point(-Math.Max(0,value.X),-Math.Max(0,value.Y));
  int dx=incoming.X-scroll.X,dy=incoming.Y-scroll.Y;
  foreach(MedicalLayoutControl child in Controls)child.Location=new Point(child.Left+dx,child.Top+dy);
  scroll=incoming;
 }}
 public int ContentHeight {get{
  int bottom=AutoScrollMinSize.Height;
  foreach(MedicalLayoutControl child in Controls)bottom=Math.Max(bottom,child.Bottom-scroll.Y);
  return bottom;
 }}
 public MedicalLayoutControl(){Controls=new MedicalLayoutControls(this);Padding=new Windows.Forms.Padding(0);Margin=new Windows.Forms.Padding(0);ColumnStyles=new ArrayList();ClientSize=new Size(1100,600);Width=200;Enabled=true;Text="";}
 public void SuspendLayout(){SuspendCount++;}
 public void ResumeLayout(bool layout){ResumeCount++;if(layout)LayoutCount++;}
 public void PerformLayout(){LayoutCount++;}
 public void Refresh(){RefreshCount++;}
 public void Invalidate(bool children){}
 public bool Focus(){return true;}
 public void Dispose(){IsDisposed=true;}
 public void SetBounds(int x,int y,int width,int h){Location=new Point(x,y);Width=width;Height=h;}
 public event EventHandler Click;
 public event EventHandler TextChanged;
 public void RaiseClick(){if(Click!=null)Click(this,EventArgs.Empty);}
 public void RaiseTextChanged(){if(TextChanged!=null)TextChanged(this,EventArgs.Empty);}
}
public sealed class MedicalLayoutControls : IEnumerable {
 private List<MedicalLayoutControl> items=new List<MedicalLayoutControl>();
 private MedicalLayoutControl owner;
 public MedicalLayoutControls(MedicalLayoutControl control){owner=control;}
 public int Count {get{return items.Count;}}
 public MedicalLayoutControl this[int index]{get{return items[index];}}
 public void Add(MedicalLayoutControl child){
  if(child.Parent!=null)child.Parent.Controls.Remove(child);
  items.Add(child);child.Parent=owner;
 }
 public void Add(MedicalLayoutControl child,int column,int row){Add(child);}
 public bool Contains(MedicalLayoutControl child){return items.Contains(child);}
 public void Remove(MedicalLayoutControl child){if(items.Remove(child))child.Parent=null;}
 public void Clear(){foreach(MedicalLayoutControl child in items)child.Parent=null;items.Clear();}
 public IEnumerator GetEnumerator(){return items.GetEnumerator();}
}
namespace Windows.Forms {
 public enum SizeType{Absolute,Percent,AutoSize}
 public class Padding {
  public int Top {get;set;}public int Bottom {get;set;}public int Left {get;set;}public int Right {get;set;}
  public Padding(int all){Top=Bottom=Left=Right=all;}
  public Padding(int left,int top,int right,int bottom){Left=left;Top=top;Right=right;Bottom=bottom;}
 }
 public class ColumnStyle {public ColumnStyle(SizeType sizeType,float width){}}
 public class TableLayoutPanel:MedicalLayoutControl{}
 public class FlowLayoutPanel:MedicalLayoutControl{}
 public class TextBox:MedicalLayoutControl{}
 public class Label:MedicalLayoutControl{}
 public class Button:MedicalLayoutControl{}
}
namespace System.Windows.Forms {public class TableLayoutPanel:global::Windows.Forms.TableLayoutPanel{}}
public class MedicalOutlineTable:Windows.Forms.TableLayoutPanel{}
'@
# Font construction is the only GDI dependency in this layout-only fixture.
# Keep native primitive Point/Size constructors and real PowerShell object
# creation for all controls; no builder or event-handler body is rewritten.
function New-Object {
 [CmdletBinding()]param([Parameter(Position=0,Mandatory=$true)][string]$TypeName,[Parameter(Position=1)][object[]]$ArgumentList)
 if($TypeName -eq 'Drawing.Font'){return [pscustomobject]@{Name=$ArgumentList[0];Size=$ArgumentList[1]}}
 if($PSBoundParameters.ContainsKey('ArgumentList')){return (Microsoft.PowerShell.Utility\New-Object -TypeName $TypeName -ArgumentList $ArgumentList)}
 return (Microsoft.PowerShell.Utility\New-Object -TypeName $TypeName)
}
function Set-DarkTheme($root){}
function New-MedicalInputFrame($control){return $control}
. (Join-Path $Project 'universal.ps1')
. $sourcePath
$endSource=Join-Path $Project 'forms-ui-v59.ps1'
$endTokens=$null;$endErrors=$null;$endAst=[Management.Automation.Language.Parser]::ParseFile($endSource,[ref]$endTokens,[ref]$endErrors)
foreach($name in @('Remove-MedicalEndAction','Add-MedicalEndAction')){
 $definition=$endAst.Find({param($node)$node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $name},$false)
 if(-not $definition){throw ('Missing production end-action function: '+$name)}
 . ([scriptblock]::Create($definition.Extent.Text))
}
$script:stage='initial';$script:medicalWorkspaceReady=$true;$script:universalFlow=$null;$script:medicalEndActionHost=$null
$script:darkBg='Background';$script:darkPanel='Panel';$script:darkMuted='Muted';$script:uiSuccess='Success';$script:uiDanger='Danger'
$panel=New-Object MedicalLayoutControl;$panel.AutoScroll=$true;$panel.ClientSize=New-Object Drawing.Size(1100,600)
$form=New-Object MedicalLayoutControl;$save=New-Object MedicalLayoutControl;$caseSave=New-Object Windows.Forms.Button
$script:admissionControl=New-Object MedicalLayoutControl
$script:universalConfig=New-UniversalConfig;$script:universalValues=@{};$script:universalDetails=@{};$script:universalWordFields=@()
foreach($field in Get-UniversalFields $script:universalConfig){$script:universalValues[[string]$field.Id]='Сохранённый ответ '+$field.Id}
# Seed a long existing form so both native scroll axes have nonzero origins.
$oldFlow=New-Object Windows.Forms.TableLayoutPanel;$oldFlow.Height=3000;$oldFlow.Width=1600;$oldFlow.Location=New-Object Drawing.Point(20,15);$panel.Controls.Add($oldFlow)
$script:universalFlow=$oldFlow
$panel.AutoScrollPosition=New-Object Drawing.Point(73,470)
$panel.AutoScrollMinSize=New-Object Drawing.Size(1800,6000)
Show-UniversalInitial
Assert-Layout ($script:universalFlow.Top -eq 15 -and $script:universalFlow.Left -eq 20) 'Scrolled replacement form starts at its fixed content origin on both axes'
Assert-Layout ($panel.AutoScrollPosition.X -eq 0 -and $panel.AutoScrollPosition.Y -eq 0) 'Applying a form resets the viewport to the primary examination heading'
Assert-Layout ($panel.AutoScrollMinSize.Width -eq 0 -and $panel.AutoScrollMinSize.Height -eq 0) 'Initial-form rebuild clears stale minimum scroll area from the previous stage'
Assert-Layout ($panel.Controls.Count -eq 1 -and $panel.Controls.Contains($script:universalFlow)) 'One primary examination container remains after rebuilding'
Assert-Layout ($script:medicalEndActionHost.Parent -eq $script:universalFlow -and $caseSave.Parent -eq $script:medicalEndActionHost) 'Production Save Card action stays inside the final form row'
$baselineHeight=$panel.ContentHeight;$baselineRows=$script:universalFlow.Controls.Count;$baselineWidth=$script:universalFlow.Width
Assert-Layout ($baselineHeight -gt $panel.ClientSize.Height) 'Fixture contains a real long form rather than an unscrollable placeholder'
for($i=1;$i -le 12;$i++){
 $oldHost=$script:medicalEndActionHost
 $panel.AutoScrollPosition=New-Object Drawing.Point((7*$i),(43*$i))
 Show-UniversalInitial
 Assert-Layout ($script:universalFlow.Top -eq 15 -and $script:universalFlow.Left -eq 20) ('Rebuild '+$i+' preserves the form origin after scrolling')
 Assert-Layout ($panel.ContentHeight -eq $baselineHeight -and $script:universalFlow.Controls.Count -eq $baselineRows) ('Rebuild '+$i+' does not inflate form height or duplicate the final save row')
 Assert-Layout ($script:universalFlow.Width -eq $baselineWidth -and $script:universalFlow.MinimumSize.Width -eq $baselineWidth) ('Rebuild '+$i+' preserves responsive form width')
 Assert-Layout ($oldHost.IsDisposed -and $oldHost.Parent -eq $null -and $caseSave.Parent -eq $script:medicalEndActionHost) ('Rebuild '+$i+' replaces the old final-action host while keeping its button')
}
$inputs=Get-UniversalFields $script:universalConfig
Assert-Layout ($script:universalInputs.Count -eq $inputs.Count) 'Rebuilding retains every actual primary-examination field'
foreach($field in $inputs){Assert-Layout ($script:universalInputs[[string]$field.Id].Text -ceq [string]$script:universalValues[[string]$field.Id]) ('Rebuilding retains the patient answer for '+$field.Id)}
Assert-Layout (-not $script:universalBuilding -and $panel.SuspendCount -eq $panel.ResumeCount) 'Rebuilding always clears the building guard and resumes parent layout'
$previousHeight=$panel.ContentHeight
$panel.ClientSize=New-Object Drawing.Size(850,600);Resize-UniversalForm
Assert-Layout ($script:universalFlow.Width -eq 792 -and $script:universalFlow.MinimumSize.Width -eq 792 -and $script:universalFlow.MaximumSize.Width -eq 792) 'Production resize updates content width without changing the origin'
Assert-Layout ($script:universalFlow.Top -eq 15 -and $panel.ContentHeight -eq $previousHeight) 'Responsive resize does not accumulate vertical offsets or extra rows'
# The exact v63 builder remains a portable negative control, so this archive
# proves the late-reset regression even without an older release next to it.
$legacyPath=Join-Path $LegacyProject 'universal-ui.ps1'
if([IO.File]::Exists($legacyPath)){
 $legacyTokens=$null;$legacyErrors=$null;$legacyAst=[Management.Automation.Language.Parser]::ParseFile($legacyPath,[ref]$legacyTokens,[ref]$legacyErrors)
 $legacyDefinition=$legacyAst.Find({param($node)$node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Show-UniversalInitial'},$false)
 $legacyText=$legacyDefinition.Extent.Text.Replace('function Show-UniversalInitial','function Show-LegacyUniversalInitial')
}else{
 $definition=$ast.Find({param($node)$node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Show-UniversalInitial'},$false)
 $legacyText=$definition.Extent.Text.Replace('function Show-UniversalInitial','function Show-LegacyUniversalInitial')
 $legacyText=$legacyText -replace '(?m)^  # Reset scroll coordinates[^\r\n]*\r?\n  # reset[^\r\n]*\r?\n  # Reset[^\r\n]*\r?\n',''
 $legacyText=$legacyText -replace '(?m)^  \$panel\.AutoScrollPosition=New-Object Drawing\.Point\(0,0\)\r?\n  \$panel\.AutoScrollMinSize=New-Object Drawing\.Size\(0,0\)\r?\n  \$script:universalFlow=\$null\r?\n',''
}
. ([scriptblock]::Create($legacyText))
$panel.AutoScrollPosition=New-Object Drawing.Point(0,250)
Show-LegacyUniversalInitial
Assert-Layout ($script:universalFlow.Top -eq 265) 'Negative control reproduces v63 form shifted down by the old 250-pixel scroll position'
# Scrolling an already misplaced form to its bottom further amplifies the old
# gap; the fixed builder restores the original 15-pixel start even from here.
$firstGap=$script:universalFlow.Top
$panel.AutoScrollPosition=New-Object Drawing.Point(0,($panel.ContentHeight-$panel.ClientSize.Height))
$secondScroll=-$panel.AutoScrollPosition.Y
Show-LegacyUniversalInitial
Assert-Layout ($script:universalFlow.Top -eq (15+$secondScroll) -and $script:universalFlow.Top -gt $firstGap) 'Negative control reproduces the growing empty gap on a second edit after scrolling to the end'
$panel.AutoScrollPosition=New-Object Drawing.Point(41,320)
Show-UniversalInitial
Assert-Layout ($script:universalFlow.Top -eq 15 -and $script:universalFlow.Left -eq 20 -and $panel.ContentHeight -eq $baselineHeight) 'Fixed production builder repairs an already shifted view without changing schema or patient answers'
Write-Output ('CHECKS '+$script:layoutChecks)
