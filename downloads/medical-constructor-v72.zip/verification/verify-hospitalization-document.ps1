﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v72'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Hospitalization([bool]$test,[string]$message){if(-not $test){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
function Assert-HospitalizationRejected([scriptblock]$operation,[string]$message,[string]$contains=''){$errorText='';try{& $operation|Out-Null}catch{$errorText=$_.Exception.Message};Assert-Hospitalization (-not [string]::IsNullOrEmpty($errorText) -and (-not $contains -or $errorText.Contains($contains))) $message}
function Import-TestFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors);if($errors.Count){throw ($errors|Out-String)}
 foreach($node in $ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}}
}
function Apply-DocumentFont($path){throw ('Hospitalization export must retain authored per-stage formatting: '+($config | ConvertTo-Json -Depth 2 -Compress))}
function New-HospitalizationComMock {
 New-DiaryComMock;$script:renderedSnapshots=New-Object Collections.ArrayList
 $script:mockNativeOpen=$script:mock.Application.Documents.PSObject.Methods['Open'].Script
 $script:mock.Application.Documents|Add-Member ScriptMethod Open {
  param($path,$confirm,$readonly,$recent)
  $archive=[IO.Compression.ZipFile]::OpenRead($path)
  try{
   $parts=@{};foreach($entry in $archive.Entries){$stream=$entry.Open();$memory=New-Object IO.MemoryStream;try{$stream.CopyTo($memory);$parts[$entry.FullName]=$memory.ToArray()}finally{$stream.Dispose();$memory.Dispose()}}
   [void]$script:renderedSnapshots.Add([pscustomobject]@{Path=$path;Parts=$parts;Text=(Get-DiaryText $path);State=(Read-UniversalDocumentState $path)})
  }finally{$archive.Dispose()}
  return (& $script:mockNativeOpen $path $confirm $readonly $recent)
 } -Force
}
function New-HospitalizationAuthoredTemplate($schema,[string]$name,[string]$font,[int]$size,[int]$left,[string]$sentinel){
 $path=Join-Path $temp ($name+'.docx');New-UniversalTemplate $path $schema
 $archive=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{
  $styles=Get-MedicalDiaryXml $archive 'word/styles.xml';$n=New-Object Xml.XmlNamespaceManager($styles.NameTable);$n.AddNamespace('w',$script:ns)
  $fonts=$styles.SelectSingleNode('/w:styles/w:docDefaults/w:rPrDefault/w:rPr/w:rFonts',$n);foreach($attribute in @('ascii','hAnsi','cs')){[void]$fonts.SetAttribute($attribute,$script:ns,$font)}
  [void]$styles.SelectSingleNode('/w:styles/w:docDefaults/w:rPrDefault/w:rPr/w:sz',$n).SetAttribute('val',$script:ns,[string]$size)
  Set-MedicalDiaryXml $archive 'word/styles.xml' $styles
  $document=Get-MedicalDiaryXml $archive 'word/document.xml';$dn=New-Object Xml.XmlNamespaceManager($document.NameTable);$dn.AddNamespace('w',$script:ns)
  $section=$document.SelectSingleNode('/w:document/w:body/w:sectPr',$dn);$margins=$section.SelectSingleNode('w:pgMar',$dn);[void]$margins.SetAttribute('left',$script:ns,[string]$left)
  $paragraph=$document.CreateElement('w','p',$script:ns);$run=$document.CreateElement('w','r',$script:ns);$text=$document.CreateElement('w','t',$script:ns);$text.InnerText=$sentinel;[void]$run.AppendChild($text);[void]$paragraph.AppendChild($run);[void]$section.ParentNode.InsertBefore($paragraph,$section)
  Set-MedicalDiaryXml $archive 'word/document.xml' $document
  # A binary package part gives a source-preservation check alongside real XML.
  $media=$archive.CreateEntry('word/media/'+$name+'.png');$stream=$media.Open();$bytes=[Text.Encoding]::UTF8.GetBytes($sentinel);try{$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
 }finally{$archive.Dispose()}
 $copy=Copy-MedicalFormSchema $schema;$copy.AutoTemplate=$false;$copy.Template=$path;$copy | Add-Member -NotePropertyName PreserveTemplateFormatting -NotePropertyValue $true -Force
 return $copy
}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-hospitalization-tests-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 Add-Type -AssemblyName System.IO.Compression;Add-Type -AssemblyName System.IO.Compression.FileSystem
 # Reuse only native Word fixtures from the diary suite, never its test body.
 Import-TestFunctions (Join-Path $PSScriptRoot 'verify-diary-document.ps1') @('Read-DiaryPart','Get-DiaryText','New-TestRange','New-TestHeaderCollection','New-TestSection','New-DiaryComMock')
 Import-TestFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
 Import-TestFunctions (Join-Path $Project 'universal.ps1')
 Import-TestFunctions (Join-Path $Project 'forms-v59.ps1')
 Import-TestFunctions (Join-Path $Project 'clinical-stages-v67.ps1')
 Import-TestFunctions (Join-Path $Project 'diary-document-v67.ps1')
 Import-TestFunctions (Join-Path $Project 'hospitalization-document-v68.ps1')
 # The only production dependency replaced is the native Word application.
 function New-MedicalDiaryWordApplication {if($script:mock.MissingWord){throw 'Microsoft Word unavailable'};return $script:mock.Application}
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main';$script:medicalProgramRoot=$temp;$script:medicalTemplatesFolder=Join-Path $temp 'Шаблоны'
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-01T09:45:00'}
 $script:universalConfig=New-UniversalConfig;$script:universalValues=@{};$script:universalDetails=@{}
 foreach($field in Get-UniversalFields $script:universalConfig){$script:universalValues[[string]$field.Id]='ПОЛЕ '+[string]$field.Id}
 $script:universalValues.patient_name='ПАЦИЕНТ ПЕРВИЧНЫЙ';$script:universalValues.patient_birth='01.01.2000';$script:universalValues.patient_address='ТЕСТОВЫЙ АДРЕС';$script:universalValues.complaints='ЖАЛОБЫ ПЕРВИЧНОГО ОСМОТРА'
 $script:universalConfig=New-HospitalizationAuthoredTemplate $script:universalConfig 'initial' 'Arial' 22 1000 'БЛОК ПЕРВИЧНОГО ОСМОТРА'
 [void](Initialize-MedicalClinicalWorkspace)
 $first=Add-MedicalClinicalDiary;$second=Add-MedicalClinicalDiary
 [void](Set-MedicalClinicalSchema 'diary' $first.Id (New-HospitalizationAuthoredTemplate $first.Schema 'diary-first' 'Courier New' 20 1500 'БЛОК ПЕРВОГО ДНЕВНИКА'))
 [void](Set-MedicalClinicalSchema 'diary' $second.Id (New-HospitalizationAuthoredTemplate $second.Schema 'diary-second' 'Calibri' 26 1800 'БЛОК ВТОРОГО ДНЕВНИКА'))
 Set-MedicalClinicalValue 'diary' $first.Id 'diary_complaints' 'ПЕРВАЯ ЗАПИСЬ'
 Set-MedicalClinicalValue 'diary' $second.Id 'diary_complaints' 'ВТОРАЯ ЗАПИСЬ'
 # Deliberately reversed dates establish that saved card order is authoritative.
 Set-MedicalClinicalDate $first.Id ([datetime]'2026-10-05T10:00:00');Set-MedicalClinicalDate $second.Id ([datetime]'2026-10-02T11:30:00')
 $discharge=Get-MedicalClinicalContext 'discharge';[void](Set-MedicalClinicalSchema 'discharge' '' (New-HospitalizationAuthoredTemplate $discharge.Schema 'discharge' 'Times New Roman' 24 2000 'БЛОК ВЫПИСНОГО ЭПИКРИЗА'))
 Set-MedicalClinicalValue 'discharge' '' 'complaints' 'ОТРЕДАКТИРОВАННЫЕ ЖАЛОБЫ ЭПИКРИЗА'
 Set-MedicalClinicalValue 'discharge' '' 'final_diagnosis' 'ЗАКЛЮЧИТЕЛЬНЫЙ ДИАГНОЗ ТЕСТ'
 [void](Set-MedicalTreatmentPeriod '2026-10-01' '2026-10-10')
 $contexts=@(Get-MedicalHospitalizationContexts)
 Assert-Hospitalization ($contexts.Count -eq 4 -and ($contexts.Stage -join ',') -ceq 'initial,diary,diary,discharge') 'Hospitalization context order is initial examination, all diaries, discharge'
 Assert-Hospitalization ($contexts[1].Id -ceq $first.Id -and $contexts[2].Id -ceq $second.Id) 'Diary ordering follows saved structure instead of silently sorting edited dates'
 $sourceHashes=@{};foreach($context in $contexts){$path=Get-UniversalTemplatePath $context.Schema;$sourceHashes[$path]=(Get-FileHash $path).Hash}
 $script:stage='initial';$script:source='CANONICAL INITIAL SOURCE';$script:medicalActiveDiaryId=$second.Id;$script:medicalClinicalBindings=@{sentinel='UNCHANGED'}
 $formsBefore=Get-MedicalClinicalFormData|ConvertTo-Json -Depth 60 -Compress;$stateBefore=Get-MedicalClinicalState|ConvertTo-Json -Depth 60 -Compress
 $initialBefore=Get-UniversalState|ConvertTo-Json -Depth 60 -Compress
 $output=Join-Path $temp 'Hospitalization.docx';New-HospitalizationComMock;Export-MedicalHospitalizationDocument $output $true
 Assert-Hospitalization ([IO.File]::Exists($output)) 'Real per-stage DOCX export and native merge contract produce one hospitalization DOCX'
 Assert-Hospitalization ($script:mock.Opened.Count -eq 4 -and $script:mock.Insertions.Count -eq 3 -and $script:mock.Breaks -eq 3) 'Initial, two diaries and discharge each enter the same owned Word merge exactly once'
 $text=Get-DiaryText $output;$sentinels=@('БЛОК ПЕРВИЧНОГО ОСМОТРА','БЛОК ПЕРВОГО ДНЕВНИКА','БЛОК ВТОРОГО ДНЕВНИКА','БЛОК ВЫПИСНОГО ЭПИКРИЗА')
 $last=-1;foreach($sentinel in $sentinels){$position=$text.IndexOf($sentinel);Assert-Hospitalization ($position -gt $last) ('Visible hospitalization order retains '+$sentinel);$last=$position}
 Assert-Hospitalization ($text.Contains('ЖАЛОБЫ ПЕРВИЧНОГО ОСМОТРА') -and $text.Contains('ОТРЕДАКТИРОВАННЫЕ ЖАЛОБЫ ЭПИКРИЗА') -and $text.Contains('ЗАКЛЮЧИТЕЛЬНЫЙ ДИАГНОЗ ТЕСТ')) 'Discharge manual edits coexist with original initial examination answers'
 Assert-Hospitalization ($text.Contains('01.10.2026 09:45') -and $text.Contains('05.10.2026 10:00') -and $text.Contains('02.10.2026 11:30')) 'Individual corrected admission and diary timestamps render through the production template pipeline'
 $fonts=@('Arial','Courier New','Calibri','Times New Roman');$sizes=@(22,20,26,24);$margins=@(1000,1500,1800,2000);$styleIds=@()
 for($index=0;$index -lt 4;$index++){
  $snapshot=$script:renderedSnapshots[$index];$styles=[xml][Text.Encoding]::UTF8.GetString($snapshot.Parts['word/styles.xml']);$document=[xml][Text.Encoding]::UTF8.GetString($snapshot.Parts['word/document.xml']);$n=New-Object Xml.XmlNamespaceManager($styles.NameTable);$n.AddNamespace('w',$script:ns)
  $base=$styles.SelectSingleNode('/w:styles/w:style[contains(@w:styleId,"Base")]/w:rPr',$n)
  Assert-Hospitalization ($base.SelectSingleNode('w:rFonts',$n).GetAttribute('ascii',$script:ns) -ceq $fonts[$index]) ('Source font survives style isolation for stage '+$index)
  Assert-Hospitalization ($base.SelectSingleNode('w:sz',$n).GetAttribute('val',$script:ns) -ceq [string]$sizes[$index]) ('Source font size survives style isolation for stage '+$index)
  $dn=New-Object Xml.XmlNamespaceManager($document.NameTable);$dn.AddNamespace('w',$script:ns)
  Assert-Hospitalization ($document.SelectSingleNode('/w:document/w:body/w:sectPr/w:pgMar',$dn).GetAttribute('left',$script:ns) -ceq [string]$margins[$index]) ('Authored page margin reaches native Word unchanged for stage '+$index)
  $styleIds+=@($styles.SelectSingleNode('/w:styles/w:style[contains(@w:styleId,"Normal")]', $n).GetAttribute('styleId',$script:ns))
  Assert-Hospitalization ($null -eq $snapshot.State -and -not $snapshot.Parts.ContainsKey('customXml/mc49.xml')) ('Single-stage patient metadata is stripped before merge for stage '+$index)
  Assert-Hospitalization (@($snapshot.Parts.Keys|Where-Object {$_ -like 'word/media/*'}).Count -eq 1) ('Binary resource survives real per-stage rendering for stage '+$index)
  Assert-Hospitalization (-not [IO.File]::Exists($snapshot.Path)) ('Private stage snapshot is removed after export for stage '+$index)
 }
 Assert-Hospitalization (@($styleIds|Select-Object -Unique).Count -eq 4) 'Identically named template styles receive distinct namespaces before Word combines them'
 $periodLine=@([regex]::Split($script:renderedSnapshots[3].Text,'\r\n|\r|\n') | Where-Object {$_ -like 'Период лечения:*'})
 Assert-Hospitalization ($periodLine.Count -eq 1 -and $periodLine[0] -ceq 'Период лечения: 01.10.2026 — 10.10.2026' -and $periodLine[0] -notmatch '[0-9]{1,2}:[0-9]{2}') 'Discharge snapshot contains one date-only treatment period before merging'
 Assert-Hospitalization (-not $script:renderedSnapshots[0].Text.Contains('Период лечения:') -and -not $script:renderedSnapshots[1].Text.Contains('Период лечения:')) 'Treatment period annotation is confined to the discharge snapshot'
 $state=Read-UniversalDocumentState $output
 Assert-Hospitalization ($state.Version -eq 68 -and $state.Stage -ceq 'hospitalization' -and $state.NoTemplate -and $null -eq $state.Schema -and @($state.Stages).Count -eq 4) 'Merged patient document replaces individual metadata with a complete hospitalization collection marker'
 Assert-Hospitalization (($state.Stages.Stage -join ',') -ceq 'initial,diary,diary,discharge' -and $state.Stages[1].Id -ceq $first.Id -and $state.Stages[2].Id -ceq $second.Id) 'Hospitalization metadata follows the same visible order and stable diary identities'
 Assert-Hospitalization ($state.Stages[0].DateTime -eq '2026-10-01T09:45:00' -and $state.Stages[3].Values.complaints -ceq 'ОТРЕДАКТИРОВАННЫЕ ЖАЛОБЫ ЭПИКРИЗА') 'Collection metadata preserves corrected admission time and discharge overrides'
 Assert-HospitalizationRejected {Test-MedicalTemplateBytes ([IO.File]::ReadAllBytes($output))} 'Filled full-hospitalization export cannot be imported as a reusable Word template'
 Assert-Hospitalization ($script:stage -ceq 'initial' -and $script:source -ceq 'CANONICAL INITIAL SOURCE' -and $script:medicalActiveDiaryId -ceq $second.Id -and $script:medicalClinicalBindings.sentinel -ceq 'UNCHANGED') 'Composer preserves active stage, source, selected diary and live UI bindings'
 Assert-Hospitalization ((Get-UniversalState|ConvertTo-Json -Depth 60 -Compress) -ceq $initialBefore) 'Composer does not modify canonical initial examination configuration or patient state'
 Assert-Hospitalization ((Get-MedicalClinicalFormData|ConvertTo-Json -Depth 60 -Compress) -ceq $formsBefore -and (Get-MedicalClinicalState|ConvertTo-Json -Depth 60 -Compress) -ceq $stateBefore) 'Composer preserves diary form structure, patient answers and manual discharge overrides'
 $before=(Get-FileHash $output).Hash
 foreach($failure in @('MissingWord','FailInsert','FailSave','BadSections')){
  Clear-MedicalHospitalizationRenderCache
  New-HospitalizationComMock;switch($failure){'MissingWord'{$script:mock.MissingWord=$true};'FailInsert'{$script:mock.FailInsert=2};'FailSave'{$script:mock.FailSave=$true};'BadSections'{$script:mock.BadSections=$true}}
  Assert-HospitalizationRejected {Export-MedicalHospitalizationDocument $output $true} ('Native failure '+$failure+' rejects a partial hospitalization')
  Assert-Hospitalization ((Get-FileHash $output).Hash -ceq $before) ('Native failure '+$failure+' preserves the existing saved card')
  Assert-Hospitalization (@(Get-ChildItem -LiteralPath $temp -Filter 'mc-hospitalization-*.docx').Count -eq 0) ('Native failure '+$failure+' cleans target temporary files')
  foreach($entry in $script:mock.Opened){Assert-Hospitalization (-not [IO.File]::Exists($entry.Path)) ('Native failure '+$failure+' cleans its private stage snapshot')}
 }
 foreach($path in $sourceHashes.Keys){New-HospitalizationComMock;Assert-HospitalizationRejected {Export-MedicalHospitalizationDocument $path $true} ('Output path cannot overwrite original stage template '+[IO.Path]::GetFileName($path));Assert-Hospitalization ((Get-FileHash $path).Hash -ceq $sourceHashes[$path] -and $script:mock.Opened.Count -eq 0) ('Protected source remains unchanged and Word stays closed for '+[IO.Path]::GetFileName($path))}
 Assert-HospitalizationRejected {Export-MedicalHospitalizationDocument (Join-Path $temp 'not-card.dotx') $true} 'Hospitalization output requires the DOCX extension'
 $script:universalValues.complaints='';New-HospitalizationComMock
 Assert-HospitalizationRejected {Export-MedicalHospitalizationDocument $output $false} 'Strict export rejects a missing mandatory initial examination answer before replacing the card'
 Assert-Hospitalization ((Get-FileHash $output).Hash -ceq $before -and $script:mock.Opened.Count -eq 0) 'Strict validation failure leaves saved card intact and never starts Word'
 $script:universalValues.complaints='ЖАЛОБЫ ПЕРВИЧНОГО ОСМОТРА'
 $script:universalValues.patient_birth='31.02.2000';New-HospitalizationComMock
 Assert-HospitalizationRejected {Export-MedicalHospitalizationDocument $output $false} 'Strict export rejects an invalid mapped patient birth date before replacing the card' 'Дата рождения'
 Assert-Hospitalization ((Get-FileHash $output).Hash -ceq $before -and $script:mock.Opened.Count -eq 0) 'Strict birth-date validation preserves the existing card without starting Word'
 $script:universalValues.patient_birth='01.01.2000'
 $script:medicalClinicalForms.Diaries=@();$script:medicalClinicalState.Diaries=@();New-HospitalizationComMock
 $empty=Join-Path $temp 'No diaries.docx';Export-MedicalHospitalizationDocument $empty $true
 Assert-Hospitalization ($script:mock.Opened.Count -eq 2 -and (Read-UniversalDocumentState $empty).Stages.Count -eq 2) 'A hospitalization without diary records still contains initial examination followed by discharge'
 $emptyText=Get-DiaryText $empty;Assert-Hospitalization ($emptyText.IndexOf($sentinels[0]) -lt $emptyText.IndexOf($sentinels[3]) -and -not $emptyText.Contains($sentinels[1])) 'Empty diary list creates no diary placeholder or stray diary contents'
 New-HospitalizationComMock;Export-MedicalHospitalizationDocument $empty $true
 Assert-Hospitalization ((Read-UniversalDocumentState $empty).Stages.Count -eq 2) 'Repeated save atomically replaces the complete card with an explicit null backup path'
 $blocked=Join-Path $temp 'blocked.docx';[void][IO.Directory]::CreateDirectory($blocked);$keep=Join-Path $blocked 'keep.txt';[IO.File]::WriteAllText($keep,'KEEP');New-HospitalizationComMock
 Assert-HospitalizationRejected {Export-MedicalHospitalizationDocument $blocked $true} 'Invalid destination fails after rendering without deleting existing destination contents'
 Assert-Hospitalization ([IO.File]::ReadAllText($keep) -ceq 'KEEP' -and @(Get-ChildItem -LiteralPath $temp -Filter 'mc-hospitalization-*.docx').Count -eq 0) 'Final placement failure keeps destination contents and removes temporary card'
 foreach($path in $sourceHashes.Keys){Assert-Hospitalization ((Get-FileHash $path).Hash -ceq $sourceHashes[$path]) ('All success and failure paths preserve original Word template '+[IO.Path]::GetFileName($path))}
 # Simulate opening a reusable form with nine blank diary blueprints for a
 # patient who needs only three scheduled records. Structure is not patient data.
 [void](Initialize-MedicalClinicalWorkspace)
 for($index=0;$index -lt 9;$index++){[void](Add-MedicalClinicalDiary)}
 $nineDiaryForm=Get-MedicalClinicalFormData
 [void](Initialize-MedicalClinicalWorkspace $nineDiaryForm)
 Assert-Hospitalization (@(Get-MedicalHospitalizationContexts).Count -eq 11) 'Unscheduled form diary slots remain exportable until a treatment period is explicitly chosen'
 $scheduled=Add-MedicalClinicalDiaryPeriod '2026-10-01' '2026-10-04'
 Assert-Hospitalization ($scheduled.ReusedCount -eq 3 -and $scheduled.AddedCount -eq 0 -and $script:medicalClinicalForms.Diaries.Count -eq 9 -and $script:medicalClinicalState.Diaries.Count -eq 9) 'Choosing a shorter patient period reuses three of nine blank diary slots without duplicating or deleting form structure'
 $shortContexts=@(Get-MedicalHospitalizationContexts)
 Assert-Hospitalization ($shortContexts.Count -eq 5 -and ($shortContexts.Stage -join ',') -ceq 'initial,diary,diary,diary,discharge') 'Hospitalization exports only three scheduled diaries between initial examination and discharge'
 Assert-Hospitalization (($shortContexts[1..3] | ForEach-Object {$_.DateTime.ToString('dd.MM.yyyy')}) -join ',' -ceq '02.10.2026,03.10.2026,04.10.2026') 'Reused diary timestamps cover the day after admission through the final treatment date'
 $shortOutput=Join-Path $temp 'Short period.docx';New-HospitalizationComMock;Export-MedicalHospitalizationDocument $shortOutput $true
 Assert-Hospitalization ($script:mock.Opened.Count -eq 5 -and (Read-UniversalDocumentState $shortOutput).Stages.Count -eq 5 -and $script:medicalClinicalForms.Diaries.Count -eq 9) 'Real complete-card export omits leftover automatic blank slots while all nine reusable diary structures remain'
 $unusedTemplateId=[string]$script:medicalClinicalForms.Diaries[8].Id
 $unusedTemplateSchema=New-HospitalizationAuthoredTemplate $script:medicalClinicalForms.Diaries[8].Schema 'unused-blueprint' 'Tahoma' 22 1100 'НЕИСПОЛЬЗОВАННЫЙ ШАБЛОН'
 [void](Set-MedicalClinicalSchema 'diary' $unusedTemplateId $unusedTemplateSchema)
 $unusedTemplatePath=Get-UniversalTemplatePath $unusedTemplateSchema;$unusedTemplateHash=(Get-FileHash $unusedTemplatePath).Hash;New-HospitalizationComMock
 Assert-HospitalizationRejected {Export-MedicalHospitalizationDocument $unusedTemplatePath $true} 'Omitted automatic diary slot still protects its reusable Word source from being overwritten by a saved card'
 Assert-Hospitalization ((Get-FileHash $unusedTemplatePath).Hash -ceq $unusedTemplateHash -and $script:mock.Opened.Count -eq 0 -and @(Get-MedicalHospitalizationContexts).Count -eq 5) 'Omitted-slot source protection leaves all source bytes intact without changing the patient diary selection'
 $unusedId=[string]$script:medicalClinicalForms.Diaries[4].Id
 Set-MedicalClinicalValue 'diary' $unusedId 'diary_complaints' 'ЗАПОЛНЕННЫЙ ДНЕВНИК ВНЕ ПЕРИОДА'
 $filledContexts=@(Get-MedicalHospitalizationContexts)
 Assert-Hospitalization ($filledContexts.Count -eq 6 -and @($filledContexts | Where-Object {$_.Id -ceq $unusedId}).Count -eq 1) 'An independently filled diary outside the selected period is retained in the Word export'
 New-HospitalizationComMock;Export-MedicalHospitalizationDocument $shortOutput $true
 Assert-Hospitalization ((Get-DiaryText $shortOutput).Contains('ЗАПОЛНЕННЫЙ ДНЕВНИК ВНЕ ПЕРИОДА') -and (Read-UniversalDocumentState $shortOutput).Stages.Count -eq 6) 'Real repeated export preserves added patient observations outside the generated range'
 $manualId=[string]$script:medicalClinicalForms.Diaries[5].Id;Set-MedicalClinicalDate $manualId ([datetime]'2026-10-09T16:15:00')
 Assert-Hospitalization (@(Get-MedicalHospitalizationContexts).Count -eq 7) 'A manually dated diary remains in the export even when it is outside the generated range'
 Write-Output ('Completed '+$script:checks+' hospitalization-document checks. Individual DOCX rendering, style isolation, package metadata and atomic writes are real; native Word COM composition, pagination and section copying are mocked and remain untested in Windows.')
}finally{if(Get-Command Clear-MedicalHospitalizationRenderCache -ErrorAction SilentlyContinue){Clear-MedicalHospitalizationRenderCache};if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
