﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v72'))
$ErrorActionPreference='Stop'
$script:checks=0
function Assert-Check([bool]$condition,[string]$message){
 if(-not $condition){throw $message}
 $script:checks++;Write-Output ('PASS '+$message)
}
function Import-TestFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null
 $ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors | Out-String)}
 foreach($node in $ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
  if($names.Count -eq 0 -or $node.Name -in $names){
   . ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))
  }
 }
}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-v57-test-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
try{
 foreach($file in Get-ChildItem -LiteralPath $Project -Filter *.ps1){
  $tokens=$null;$errors=$null
  [void][Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
  Assert-Check ($errors.Count -eq 0) ('PowerShell syntax: '+$file.Name)
 }
 # These tests exercise data functions only. They do not emulate a Windows UI.
 Import-TestFunctions (Join-Path $Project 'ui-v57.ps1') @('Read-MedicalAppearance','Write-MedicalAppearance','Get-MedicalPatientSummary')
 $script:uiSettingsPath=Join-Path $temp 'appearance.json'
 Assert-Check ((Read-MedicalAppearance) -eq 'light') 'Default appearance'
 foreach($theme in @('light','dark','contrast')){
  Write-MedicalAppearance $theme
  Assert-Check ((Read-MedicalAppearance) -eq $theme) ('Appearance round trip: '+$theme)
 }
 $before=[IO.File]::ReadAllText($script:uiSettingsPath);$rejected=$false
 try{Write-MedicalAppearance 'unknown'}catch{$rejected=$true}
 Assert-Check ($rejected -and [IO.File]::ReadAllText($script:uiSettingsPath) -eq $before) 'Invalid appearance preserves settings'
 [IO.File]::WriteAllText($script:uiSettingsPath,'broken JSON')
 Assert-Check ((Read-MedicalAppearance -WarningAction SilentlyContinue) -eq 'light') 'Corrupt appearance falls back to light'
 Add-Type -TypeDefinition 'namespace System.Windows.Forms { public static class MessageBox { public static string Show(string message) { return "OK"; } public static string Show(string message,string title) { return "OK"; } } }'
 Import-TestFunctions (Join-Path $Project 'patients.ps1') @('Load-Patients','Save-Patients','Invoke-PatientChange')
 $script:dbFile=Join-Path $temp 'patients.json';$script:patientsLoadFailed=$false
 $script:patients=@([pscustomobject]@{Id='test-1';Name='Тестовый Пациент';Birth='01.01.2000';Docs=@('C:\Тест\осмотр.docx')})
 Save-Patients
 $initial=[IO.File]::ReadAllText($script:dbFile)
 Load-Patients
 Assert-Check ($script:patients.Count -eq 1 -and $script:patients[0].Name -eq 'Тестовый Пациент') 'Unicode patient data round trip'
 $script:patients+= [pscustomobject]@{Id='test-2';Name='Второй Тест';Birth='';Docs=@()}
 Save-Patients
 Assert-Check ([IO.File]::ReadAllText($script:dbFile+'.bak') -eq $initial) 'Patient backup contains previous version'
 Save-Patients
 Assert-Check (@(Get-Content ($script:dbFile+'.bak') -Raw|ConvertFrom-Json).Count -eq 2) 'Repeated writes refresh backup'
 $saved=Invoke-PatientChange {$script:patients[0].Docs+= 'C:\Тест\дневник.docx'}
 Load-Patients
 Assert-Check ($saved -and $script:patients[0].Docs.Count -eq 2) 'Patient transaction persists document attachment'
 Remove-Item -LiteralPath ($script:dbFile+'.bak')
 [void][IO.Directory]::CreateDirectory($script:dbFile+'.bak')
 $before=[IO.File]::ReadAllText($script:dbFile)
 $saved=Invoke-PatientChange {$script:patients[0].Docs=@();$script:patients[0].Name='Изменённый'}
 Assert-Check (-not $saved -and $script:patients[0].Name -eq 'Тестовый Пациент' -and $script:patients[0].Docs.Count -eq 2) 'Failed write rolls back in-memory edits'
 Assert-Check ([IO.File]::ReadAllText($script:dbFile) -eq $before) 'Failed write preserves stored patient data'
 Remove-Item -LiteralPath ($script:dbFile+'.bak') -Recurse
 [IO.File]::WriteAllText($script:dbFile,'invalid patient JSON');Load-Patients
 $rejected=$false;try{Save-Patients}catch{$rejected=$true}
 Assert-Check ($rejected -and [IO.File]::ReadAllText($script:dbFile) -eq 'invalid patient JSON') 'Corrupt patient database cannot be overwritten'
 Assert-Check (@(Get-ChildItem -LiteralPath $temp -Filter *.tmp).Count -eq 0) 'Patient and appearance temporary files cleaned up'
 Import-TestFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
 Import-TestFunctions (Join-Path $Project 'universal.ps1')
 Import-TestFunctions (Join-Path $Project 'workspace-settings.ps1') @('Load-DocumentFont','Set-DocumentFontXml','Apply-DocumentFont')
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 $script:fontFile=Join-Path $Project 'document-font.json'
 $script:universalDetails=@{}
 $config=Get-Content (Join-Path $Project 'form-settings.json') -Raw -Encoding UTF8 | ConvertFrom-Json
 $config.Template=Join-Path $Project $config.Template
 Assert-UniversalConfig $config
 Assert-Check $true 'Existing form schema remains valid'
 $values=@{}
 foreach($field in Get-UniversalFields $config){
  if($field.Type -eq 'heading'){continue}
  if($field.System -eq 'name'){$values[$field.Id]='Тестовый Пациент'}
  elseif($field.System -eq 'birth'){$values[$field.Id]='01.01.2000'}
  elseif($field.Type -in @('choice','choice_detail','multi','repeat')){if(@($field.Options).Count){$values[$field.Id]=[string]$field.Options[0]}else{$values[$field.Id]='Проверочный вариант'}}
  else{$values[$field.Id]='Проверочный текст '+$field.Label}
 }
 Assert-Check (@(Get-UniversalMissingFields $config $values).Count -eq 0) 'Filled form satisfies required fields'
 $required=@(Get-UniversalFields $config|Where-Object {Test-UniversalFieldRequired $_})
 $incomplete=@{};foreach($key in $values.Keys){$incomplete[$key]=$values[$key]}
 $incomplete[$required[0].Id]=''
 Assert-Check (@(Get-UniversalMissingFields $config $incomplete).Count -gt 0) 'Missing required input is detected'
 $output=Join-Path $temp 'осмотр.docx';$date=[datetime]'2026-10-13T12:30:00'
 Save-UniversalDocument $output $config $values $date
 $state=Read-UniversalDocumentState $output
 Assert-Check ($state.Version -eq 49 -and $state.AdmissionDateTime -eq '2026-10-13T12:30:00') 'DOCX retains compatible state and admission time'
 foreach($field in Get-UniversalFields $config){
  if($field.Type -eq 'heading'){continue}
  $value=[string]$state.Values.PSObject.Properties[[string]$field.Id].Value
  Assert-Check ($value -eq [string]$values[$field.Id]) ('DOCX field round trip: '+$field.Id)
 }
 $zip=[IO.Compression.ZipFile]::OpenRead($output)
 try{
  $xml=Get-XmlPart $zip 'word/document.xml'
  Assert-Check ($xml.OuterXml.Contains('Тестовый Пациент')) 'Generated Word document contains patient text'
  Assert-Check (-not ($xml.OuterXml -match '\{\{[A-Z][A-Z0-9_]*\}\}')) 'Generated Word document contains no unresolved markers'
 }finally{$zip.Dispose()}
 $script:universalConfig=$config;$script:universalValues=$values;$script:universalDetails=@{}
 $script:patientNameControl=[pscustomobject]@{Text='Старое имя'}
 $script:patientBirthControl=[pscustomobject]@{Text='02.02.1999'}
 $script:stage='initial'
 Assert-Check ((Get-MedicalPatientSummary).Contains('Тестовый Пациент')) 'Patient header uses current initial-exam values'
 $script:stage='diary'
 Assert-Check ((Get-MedicalPatientSummary).Contains('Старое имя')) 'Patient header uses active diary demographics'
 $custom=Copy-UniversalObject $config
 $custom.Template=Join-Path $temp 'собственный-шаблон.docx'
 New-UniversalTemplate $custom.Template $custom
 $custom.AutoTemplate=$false
 Save-UniversalDocument (Join-Path $temp 'по-шаблону.docx') $custom $values $date
 $customState=Read-UniversalDocumentState (Join-Path $temp 'по-шаблону.docx')
 Assert-Check ($customState.Values.patient_name -eq 'Тестовый Пациент') 'Compatible custom Word template export remains supported'
 $script:patientsLoadFailed=$false;$script:patients=@()
 Save-Patients;Load-Patients
 Assert-Check ($script:patients.Count -eq 0) 'Empty patient catalog round trip'
 $before=(Get-FileHash $output -Algorithm SHA256).Hash
 $config.AutoTemplate=$false;$config.Template=Join-Path $temp 'missing-template.docx'
 $rejected=$false;try{Save-UniversalDocument $output $config $values $date}catch{$rejected=$true}
 Assert-Check ($rejected -and (Get-FileHash $output -Algorithm SHA256).Hash -eq $before) 'Failed export preserves existing DOCX'
 Write-Output ('COMPLETED: '+$script:checks+' checks passed. Windows UI and printing remain untested.')
}finally{Remove-Item -LiteralPath $temp -Recurse -Force}
