﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v72'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Picker([bool]$Value,[string]$Message){if(-not $Value){throw $Message};$script:checks++;Write-Output ('PASS '+$Message)}
function Assert-PickerRejected([scriptblock]$Action,[string]$Message){$rejected=$false;try{$null=& $Action}catch{$rejected=$true};Assert-Picker $rejected $Message}
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @'
using System;
using System.Collections.Generic;
public class PickerWidget {
 public string Text=""; public bool Focused; public bool Enabled=true; public bool Closed; public string DialogResult="";
 public bool Focus(){Focused=true;return true;} public void Clear(){Text="";} public void Close(){Closed=true;}
}
public class PickerControls {public readonly List<object> Items=new List<object>(); public void Add(object value,int column,int row){Items.Add(value);}}
public class PickerLayout {public readonly PickerControls Controls=new PickerControls();}
namespace Windows.Forms {
 public sealed class Padding {public Padding(int a,int b,int c,int d){}}
 public class Label {public string Text;public string Dock;public string TextAlign;}
 public class ComboBox {
  public string Dock;public object Margin;public string DropDownStyle;public string DisplayMember;public int MaxDropDownItems;
  public readonly System.Collections.ArrayList Items=new System.Collections.ArrayList();public int SelectedIndex=-1;
  public object SelectedItem {get {return SelectedIndex>=0&&SelectedIndex<Items.Count?Items[SelectedIndex]:null;}}
 }
}
'@
. (Join-Path $Project 'accounts-v71.ps1')
. (Join-Path $Project 'accounts-ui-v71.ps1')
$tokens=$null;$errors=$null
$uiAst=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'accounts-ui-v71.ps1'),[ref]$tokens,[ref]$errors)
Assert-Picker ($errors.Count -eq 0) 'Updated account UI parses without syntax errors'
$entry=$uiAst.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Show-MedicalAccountEntryDialog'},$false)
$pickerIf=@($entry.FindAll({param($n)$n -is [Management.Automation.Language.IfStatementAst] -and $n.Clauses[0].Item1.Extent.Text -eq '$askLogin' -and $n.Extent.Text.Contains('$loginAccounts=@(')},$true))[0]
$pickerSource=$pickerIf.Extent.Text
$submitNode=@($entry.FindAll({param($n)$n -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $n.Expression.Extent.Text -eq '$submit' -and $n.Member.Value -eq 'Add_Click'},$true))[0]
$submitSource=$submitNode.Arguments[0].Extent.Text
$shownNode=@($entry.FindAll({param($n)$n -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $n.Expression.Extent.Text -eq '$dialog' -and $n.Member.Value -eq 'Add_Shown'},$true))[0]
$shownSource=$shownNode.Arguments[0].Extent.Text
$changedNode=@($entry.FindAll({param($n)$n -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $n.Expression.Extent.Text -eq '$loginPicker' -and $n.Member.Value -eq 'Add_SelectedIndexChanged'},$true))[0]
$changedSource=$changedNode.Arguments[0].Extent.Text
$askUsernameAssignment=@($entry.FindAll({param($n)$n -is [Management.Automation.Language.AssignmentStatementAst] -and $n.Left.Extent.Text -eq '$askUsername'},$true))[0].Extent.Text
function New-PickerFixture {
 param([string]$Mode='Login',$Context,$Session,[string]$Password='',[string]$Username='',[string]$DisplayName='',[string]$Confirmation='',[string]$CurrentPassword='',[string]$TargetUserId='',$LoginOverride=$null,$PreferenceOverride=$null)
 $commands=@{}
 foreach($name in @('Get-MedicalLoginAccounts','Get-MedicalLoginPreference','Save-MedicalLoginPreference','New-MedicalFirstAdministrator','Invoke-MedicalAccountLogin','New-MedicalUserAccount','Set-MedicalOwnPassword','Reset-MedicalAccountPassword')){$commands[$name]=Get-Command $name -CommandType Function -ErrorAction Stop}
 if($null -ne $LoginOverride){$commands['Invoke-MedicalAccountLogin']=$LoginOverride}
 if($null -ne $PreferenceOverride){$commands['Save-MedicalLoginPreference']=$PreferenceOverride}
 $askLogin=$Mode -eq 'Login';. ([scriptblock]::Create($askUsernameAssignment));$askCurrent=$Mode -eq 'OwnPassword'
 $askConfirm=$Mode -in @('FirstAdministrator','Create','OwnPassword','ResetPassword')
 $layout=New-Object PickerLayout;$row=1;$loginPicker=$null
 . ([scriptblock]::Create($pickerSource))
 $boxes=@{}
 foreach($name in @('Username','DisplayName','Password','ConfirmPassword','CurrentPassword')){$boxes[$name]=New-Object PickerWidget}
 $boxes.Username.Text=$Username;$boxes.DisplayName.Text=$DisplayName;$boxes.Password.Text=$Password;$boxes.ConfirmPassword.Text=$Confirmation;$boxes.CurrentPassword.Text=$CurrentPassword
 $passwordBoxes=New-Object 'Collections.Generic.List[object]';[void]$passwordBoxes.Add($boxes.Password)
 if($askConfirm){[void]$passwordBoxes.Add($boxes.ConfirmPassword)};if($askCurrent){[void]$passwordBoxes.Add($boxes.CurrentPassword)}
 $dialog=New-Object PickerWidget;$submit=New-Object PickerWidget;$errorLabel=New-Object PickerWidget;$roleBox=[pscustomobject]@{SelectedIndex=0};$state=@{Result=$null;Busy=$false}
 . ([scriptblock]::Create('$callback='+$submitSource));. ([scriptblock]::Create('$shown='+$shownSource));. ([scriptblock]::Create('$changed='+$changedSource))
 return [pscustomobject]@{Callback=$callback;Shown=$shown;Changed=$changed;State=$state;Dialog=$dialog;Submit=$submit;Error=$errorLabel;Boxes=$boxes;Picker=$loginPicker;Layout=$layout;Commands=$commands;AskUsername=$askUsername}
}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-login-picker-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 $context=Initialize-MedicalAccounts -Root $temp
 foreach($password in @('abc','',(' '*4),('x'*1025))){Assert-PickerRejected {Assert-MedicalAccountPassword $password} 'Password policy rejects fewer than four symbols whitespace-only and oversized input'}
 foreach($password in @('1234','парQ','A b!',('A'*1024))){Assert-MedicalAccountPassword $password;Assert-Picker $true 'Password policy accepts four-symbol Unicode spaces and maximum supported length'}
 Assert-PickerRejected {New-MedicalFirstAdministrator $context 'admin' 'Администратор' 'abc'} 'Three-symbol administrator password cannot initialize database'
 Assert-Picker (-not (Get-MedicalAccountsState $context).IsInitialized) 'Rejected first password leaves installation uninitialized'
 $admin=New-MedicalFirstAdministrator $context 'admin' 'Администратор' '1234'
 Assert-Picker ((Test-MedicalSession $admin) -and $admin.Role -ceq 'Administrator') 'Four-symbol administrator password creates a real authenticated session'
 $doctor=New-MedicalUserAccount $admin 'doctor' 'Врач' 'парQ'
 $legacy=New-MedicalUserAccount $admin 'legacy' 'Прежний сотрудник' 'Existing longer password 71'
 $disabled=New-MedicalUserAccount $admin 'hidden' 'Отключенный' '9876'
 $null=Set-MedicalAccountEnabled $admin $disabled.Id $false
 $roster=@(Get-MedicalLoginAccounts $context)
 Assert-Picker ($roster.Count -eq 3 -and $roster.Username -notcontains 'hidden') 'Anonymous picker lists only enabled administrator and employee accounts'
 foreach($account in $roster){Assert-Picker ((@($account.PSObject.Properties.Name|Sort-Object)-join ',') -ceq 'DisplayName,Id,Username') 'Public login roster contains exactly safe Id Username and DisplayName properties'}
 Assert-Picker ($roster.Id -contains $doctor.Id -and $roster.DisplayName -contains 'Врач') 'Public roster retains stable employee IDs and Unicode names'
 Assert-Picker ((Get-MedicalLoginPreference $context) -ceq '') 'Fresh installation has no selected-user preference'
 $fixture=New-PickerFixture -Context $context -Password '1234'
 Assert-Picker ($fixture.Picker -is [Windows.Forms.ComboBox] -and $fixture.Picker.DropDownStyle -ceq 'DropDownList') 'Exact production construction creates a noneditable native account dropdown'
 Assert-Picker (-not $fixture.AskUsername -and $fixture.Layout.Controls.Items.Count -eq 2) 'Login mode excludes typed username field and creates employee label with picker'
 Assert-Picker ($fixture.Picker.Items.Count -eq 3 -and $fixture.Picker.SelectedIndex -eq 0) 'Native picker receives only safe enabled records and a usable default selection'
 Assert-Picker ($fixture.Picker.Items[1].Label -ceq 'Врач (doctor)' -and $fixture.Picker.DisplayMember -ceq 'Label') 'Native picker displays employee name and username without exposing verifier or role'
 & $fixture.Shown
 Assert-Picker ($fixture.Boxes.Password.Focused -and -not $fixture.Boxes.Username.Focused) 'Login dialog starts directly in password input'
 & $fixture.Callback
 Assert-Picker ($fixture.Dialog.Closed -and $fixture.State.Result.UserId -ceq $admin.UserId) 'Exact Login callback authenticates the dropdown account using password only'
 Assert-Picker ((Get-MedicalLoginPreference $context) -ceq $admin.UserId) 'Successful login remembers its stable user ID'
 $preferencePath=Join-Path $context.AccountsDirectory 'login-preference.json'
 $preference=ConvertFrom-Json -InputObject ([IO.File]::ReadAllText($preferencePath))
 Assert-Picker ((@($preference.PSObject.Properties.Name|Sort-Object)-join ',') -ceq 'UserId,Version') 'Preference file contains only version and stable selected-user ID'
 Assert-Picker ($preference.Version -eq 1 -and $preference.UserId -ceq $admin.UserId) 'Preference contains no password verifier role token or machine-specific path'
 $fixture=New-PickerFixture -Context $context -Password 'incorrect'
 $fixture.Picker.SelectedIndex=1;$before=[IO.File]::ReadAllText($preferencePath)
 & $fixture.Callback
 Assert-Picker (-not $fixture.Dialog.Closed -and $null -eq $fixture.State.Result) 'Incorrect password leaves Login open without authenticated result'
 Assert-Picker ($fixture.Boxes.Password.Text -ceq '' -and $fixture.Picker.SelectedIndex -eq 1) 'Rejected Login clears only secret input while retaining chosen employee'
 Assert-Picker ([IO.File]::ReadAllText($preferencePath) -ceq $before) 'Failed login does not remember a different account'
 $fixture.Boxes.Password.Text='парQ';& $fixture.Callback
 $doctorSession=$fixture.State.Result
 Assert-Picker ($fixture.Dialog.Closed -and $doctorSession.UserId -ceq $doctor.Id) 'Four-symbol Unicode password logs into selected employee through real callback'
 Assert-Picker ((Get-MedicalLoginPreference $context) -ceq $doctor.Id) 'Valid employee login updates remembered choice only after authentication'
 $fixture=New-PickerFixture -Context $context -Password 'secret input'
 Assert-Picker ($fixture.Picker.SelectedItem.Id -ceq $doctor.Id) 'Subsequent login opens with previously authenticated employee selected'
 $fixture.Error.Text='Old error';$fixture.Picker.SelectedIndex=2;& $fixture.Changed
 Assert-Picker ($fixture.Boxes.Password.Text -ceq '' -and $fixture.Error.Text -ceq '' -and $fixture.Boxes.Password.Focused) 'Exact account-selection event clears previous password and focuses fresh password input'
 $fixture.Picker.SelectedIndex=-1;$fixture.Boxes.Password.Text='Existing longer password 71';& $fixture.Callback
 Assert-Picker (-not $fixture.Dialog.Closed -and $fixture.Error.Text -match 'Выберите сотрудника') 'Submit with missing account selection is rejected safely'
 $fixture.Picker.SelectedIndex=2;$fixture.Boxes.Password.Text='Existing longer password 71';& $fixture.Callback
 Assert-Picker ($fixture.State.Result.UserId -ceq $legacy.Id) 'Previously issued longer passwords remain valid without migration'
 $fixture=New-PickerFixture -Mode Lock -Session $doctorSession -Password 'парQ'
 Assert-Picker ($null -eq $fixture.Picker -and $fixture.AskUsername) 'Lock screen provides no account switcher'
 & $fixture.Callback
 Assert-Picker ($fixture.Dialog.Closed -and $fixture.State.Result.UserId -ceq $doctor.Id) 'Lock password reauthenticates the exact current employee'
 function Get-PickerWrongLogin {param($Context,$Username,$Password)return [pscustomobject]@{UserId='different-account'}}
 $fixture=New-PickerFixture -Mode Lock -Session $doctorSession -Password 'test' -LoginOverride (Get-Command Get-PickerWrongLogin)
 & $fixture.Callback
 Assert-Picker (-not $fixture.Dialog.Closed -and $null -eq $fixture.State.Result) 'Lock rejects any substituted account instead of changing identity'
 $before=[IO.File]::ReadAllText($preferencePath)
 Assert-PickerRejected {Set-MedicalOwnPassword $doctorSession 'парQ' 'abc'} 'Own-password change rejects three symbols in core'
 $doctorSession=Set-MedicalOwnPassword $doctorSession 'парQ' 'новQ'
 Assert-Picker (Test-MedicalSession $doctorSession) 'Own-password change accepts a four-symbol replacement and renews session'
 Assert-PickerRejected {Reset-MedicalAccountPassword $admin $doctor.Id 'abc'} 'Administrator reset rejects a three-symbol replacement'
 Reset-MedicalAccountPassword $admin $doctor.Id '4321'
 Assert-Picker (-not (Test-MedicalSession $doctorSession)) 'Four-symbol administrator reset still revokes prior employee sessions'
 $doctorSession=Invoke-MedicalAccountLogin $context 'doctor' '4321'
 Assert-Picker ($doctorSession.UserId -ceq $doctor.Id) 'Reset four-symbol password authenticates normally'
 Save-MedicalLoginPreference $doctorSession
 $null=Set-MedicalAccountEnabled $admin $doctor.Id $false
 Assert-Picker ((Get-MedicalLoginPreference $context) -ceq '') 'Disabled remembered employee is ignored on next login'
 $fixture=New-PickerFixture -Context $context
 Assert-Picker ($fixture.Picker.Items.Count -eq 2 -and $fixture.Picker.SelectedItem.Id -ceq $admin.UserId) 'Picker falls back to an enabled account after remembered employee is disabled'
 Assert-PickerRejected {Save-MedicalLoginPreference $doctorSession} 'Revoked or disabled sessions cannot update login preference'
 Assert-Picker ([IO.File]::ReadAllText($preferencePath) -ceq ('{"Version":1,"UserId":"'+$doctor.Id+'"}')) 'Failed preference update preserves previous preference bytes'
 foreach($bad in @('{bad json','{"Version":1,"UserId":"unknown"}','{"Version":1,"UserId":42}','{"Version":1,"UserId":"x","Password":"bad"}',('x'*4097))){
  [IO.File]::WriteAllText($preferencePath,$bad,(New-Object Text.UTF8Encoding($false)))
  Assert-Picker ((Get-MedicalLoginPreference $context) -ceq '') 'Malformed oversized unknown-ID or extra-field preference is ignored safely'
 }
 Save-MedicalLoginPreference $admin
 Assert-Picker ((Get-MedicalLoginPreference $context) -ceq $admin.UserId) 'Valid login replaces corrupt optional preference atomically'
 Assert-Picker (@([IO.Directory]::GetFiles($context.AccountsDirectory,'login-preference-*.tmp')).Count -eq 0) 'Atomic preference save removes temporary files'
 $copy=Join-Path $temp 'moved';[void][IO.Directory]::CreateDirectory($copy);$copyContext=Initialize-MedicalAccounts $copy
 [IO.File]::Copy($context.DatabasePath,$copyContext.DatabasePath);[IO.File]::Copy($context.BackupPath,$copyContext.BackupPath)
 [IO.File]::Copy($preferencePath,(Join-Path $copyContext.AccountsDirectory 'login-preference.json'))
 Assert-Picker ((Get-MedicalLoginPreference $copyContext) -ceq $admin.UserId) 'Selected-user preference remains portable after installation-folder move'
 function Save-PickerPreferenceFailure {param($Session)throw 'Read-only preferences'}
 $fixture=New-PickerFixture -Context $context -Password '1234' -PreferenceOverride (Get-Command Save-PickerPreferenceFailure)
 & $fixture.Callback
 Assert-Picker ($fixture.Dialog.Closed -and (Test-MedicalSession $fixture.State.Result)) 'Optional preference write failure does not reject a valid password login'
 $fixture=New-PickerFixture -Mode Create -Session $admin -Username 'newdoctor' -DisplayName 'Новый врач' -Password 'abc' -Confirmation 'abc'
 & $fixture.Callback
 Assert-Picker (-not $fixture.Dialog.Closed -and $fixture.Error.Text -match '4 символов') 'Exact Create callback rejects three-symbol password with updated message'
 $fixture.Boxes.Password.Text='4567';$fixture.Boxes.ConfirmPassword.Text='4567';& $fixture.Callback
 Assert-Picker ($fixture.Dialog.Closed -and @(Get-MedicalLoginAccounts $context|Where-Object Username -eq 'newdoctor').Count -eq 1) 'Exact Create callback accepts a four-symbol password for typed new employee name'
 $stalePicker=New-PickerFixture -Context $context -Password '4567'
 for($i=0;$i -lt $stalePicker.Picker.Items.Count;$i++){if($stalePicker.Picker.Items[$i].Username -ceq 'newdoctor'){$stalePicker.Picker.SelectedIndex=$i}}
 $newDoctor=@(Get-MedicalAccounts $admin|Where-Object Username -eq 'newdoctor')[0]
 $null=Set-MedicalAccountEnabled $admin $newDoctor.Id $false;& $stalePicker.Callback
 Assert-Picker (-not $stalePicker.Dialog.Closed -and $null -eq $stalePicker.State.Result) 'Employee disabled after picker population still cannot authenticate from stale dropdown'
 $setupRoot=Join-Path $temp 'first-setup';[void][IO.Directory]::CreateDirectory($setupRoot);$setupContext=Initialize-MedicalAccounts $setupRoot
 $fixture=New-PickerFixture -Mode FirstAdministrator -Context $setupContext -Username 'owner' -DisplayName 'Владелец' -Password 'абв4' -Confirmation 'абв4';& $fixture.Callback
 Assert-Picker ($fixture.Dialog.Closed -and $fixture.State.Result.Role -ceq 'Administrator') 'Exact first-administrator callback accepts four-symbol Unicode password'
 Assert-Picker ((Get-MedicalLoginPreference $setupContext) -ceq $fixture.State.Result.UserId) 'Successful first setup remembers new administrator without storing its password'
 $fixture=New-PickerFixture -Mode ResetPassword -Session $admin -TargetUserId $legacy.Id -Password '8765' -Confirmation '8765';& $fixture.Callback
 Assert-Picker ($fixture.Dialog.Closed -and $fixture.State.Result -eq $true) 'Exact Reset callback accepts four-symbol password'
 $legacySession=Invoke-MedicalAccountLogin $context 'legacy' '8765'
 $fixture=New-PickerFixture -Mode OwnPassword -Session $legacySession -Password '5555' -Confirmation '5555' -CurrentPassword '8765';& $fixture.Callback
 Assert-Picker ($fixture.Dialog.Closed -and (Test-MedicalSession $fixture.State.Result)) 'Exact OwnPassword callback accepts a four-symbol password while checking old password'
 $validDatabase=[IO.File]::ReadAllBytes($context.DatabasePath)
 [IO.File]::WriteAllText($context.DatabasePath,'{broken database',(New-Object Text.UTF8Encoding($false)))
 Assert-PickerRejected {Get-MedicalLoginAccounts $context} 'Corrupt account database closes anonymous account listing'
 Assert-PickerRejected {Get-MedicalLoginPreference $context} 'Valid saved preference never bypasses a corrupt account database'
 Assert-PickerRejected {New-PickerFixture -Context $context} 'Login construction fails closed when database cannot be validated'
 Assert-PickerRejected {Invoke-MedicalAccountLogin $context 'admin' '1234'} 'Corrupt database never authenticates using saved preference or backup fallback'
 [IO.File]::WriteAllBytes($context.DatabasePath,$validDatabase)
 $core=[IO.File]::ReadAllText((Join-Path $Project 'accounts-v71.ps1'))
 Assert-Picker ($core -match 'Iterations=600000' -and $core -match 'PBKDF2-SHA256') 'Four-symbol policy retains PBKDF2-SHA256 and 600000 iterations'
 $source=[IO.File]::ReadAllText((Join-Path $Project 'accounts-ui-v71.ps1'))
 Assert-Picker ($source -match '\$boxes\.Username\.ReadOnly=\$true' -and $source -match '\$boxes\.Username\.TabStop=\$false') 'Native lock identity stays read-only and excluded from keyboard focus'
 Assert-Picker ($source -notmatch 'не менее 10 символов|Length -lt 10') 'All account dialog password instructions and checks use the updated policy'
 Write-Output ('TOTAL '+$script:checks+' checks passed; exact production picker construction and callbacks with native-like controls; real account database and password hashing; native Windows dialog not run.')
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
