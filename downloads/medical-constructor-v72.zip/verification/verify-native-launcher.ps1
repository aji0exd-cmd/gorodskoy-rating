﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v72'),[string]$ReferenceAssemblies='/tmp/net472-ref/build/.NETFramework/v4.7.2')
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Native([bool]$Value,[string]$Message){if(-not $Value){throw $Message};$script:checks++;Write-Output ('PASS '+$Message)}
$path=Join-Path $Project 'Медицинский конструктор.exe';$sourcePath=Join-Path $Project 'Source/NativeLauncher.cs';$manifestPath=Join-Path $Project 'Source/app.manifest'
Assert-Native ([IO.File]::Exists($path) -and (Get-Item -LiteralPath $path).Length -gt 4096) 'Delivery contains a real compiled Windows executable'
$stream=[IO.File]::OpenRead($path)
$pe=New-Object Reflection.PortableExecutable.PEReader($stream)
try{
 $headers=$pe.PEHeaders
 Assert-Native ($headers.PEHeader.Subsystem -eq [Reflection.PortableExecutable.Subsystem]::WindowsGui) 'PE subsystem is Windows GUI and opens no console'
 Assert-Native ($headers.CorHeader -ne $null -and ($headers.CorHeader.Flags -band [Reflection.PortableExecutable.CorFlags]::ILOnly)) 'Binary contains real managed CLR entry point and IL'
 Assert-Native (-not ($headers.CorHeader.Flags -band [Reflection.PortableExecutable.CorFlags]::Requires32Bit) -and -not ($headers.CorHeader.Flags -band [Reflection.PortableExecutable.CorFlags]::Prefers32Bit)) 'AnyCPU image uses 64-bit runtime on 64-bit Windows'
 Assert-Native ($headers.CorHeader.EntryPointTokenOrRelativeVirtualAddress -ne 0) 'Executable has a nonempty managed Main entry point'
 Assert-Native ($headers.PEHeader.ResourceTableDirectory.Size -gt 0) 'Executable embeds native Windows resources and manifest'
 $metadata=[Reflection.Metadata.PEReaderExtensions]::GetMetadataReader($pe)
 Assert-Native ($metadata.MetadataVersion -eq 'v4.0.30319') 'Executable targets desktop CLR 4 rather than modern .NET runtime'
 $assembly=$metadata.GetAssemblyDefinition()
 Assert-Native ($assembly.Version.ToString() -eq '72.0.0.0') 'Compiled assembly carries application version 72'
 $refs=@(foreach($handle in $metadata.AssemblyReferences){$reference=$metadata.GetAssemblyReference($handle);$metadata.GetString($reference.Name)})
 Assert-Native ($refs -contains 'mscorlib' -and $refs -contains 'System.Windows.Forms') 'Compiled executable references desktop framework and native WinForms'
 Assert-Native ($refs -notcontains 'System.Private.CoreLib' -and $refs -notcontains 'System.Management.Automation') 'Binary has no PowerShell 7 or modern .NET assembly binding dependency'
}finally{$pe.Dispose();$stream.Dispose()}
$bytes=[IO.File]::ReadAllBytes($path);$binaryText=[Text.Encoding]::UTF8.GetString($bytes)
Assert-Native ($binaryText.Contains('.NETFramework,Version=v4.7.2')) 'Compiled target-framework attribute declares .NET Framework 4.7.2'
Assert-Native ($binaryText.Contains('STAThreadAttribute')) 'Compiled entry point includes STAThread attribute'
Assert-Native ($binaryText.Contains('requestedExecutionLevel level="asInvoker"')) 'Embedded manifest runs as the current Windows user'
Assert-Native ($binaryText.Contains('<dpiAware xmlns="http://schemas.microsoft.com/SMI/2005/WindowsSettings">true</dpiAware>')) 'Embedded manifest uses stable system DPI awareness'
Assert-Native (-not $binaryText.Contains('requireAdministrator') -and -not $binaryText.Contains('PerMonitorV2')) 'Native host requests neither elevation nor untested per-monitor DPI mode'
$source=[IO.File]::ReadAllText($sourcePath)
Assert-Native ($source.Contains('Assembly.Load(EngineName)') -and $source.Contains('Version=3.0.0.0') -and $source.Contains('31bf3856ad364e35')) 'Host binds the strong-named Windows PowerShell desktop engine'
Assert-Native ($source -notmatch 'Process\.Start|new Process|powershell\.exe|cmd\.exe|AddScript\(') 'Host does not spawn an interpreter or interpolate executable script text'
Assert-Native ($source -notmatch 'error\.Message|error\.ToString\(|StackTrace') 'Native fallback never logs raw exception content or stack traces'
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-native-v72-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
$oldDirectory=[Environment]::CurrentDirectory;$oldPolicy=[Environment]::GetEnvironmentVariable('PSExecutionPolicyPreference','Process')
try{
 if([IO.File]::Exists((Join-Path $ReferenceAssemblies 'mscorlib.dll'))){
  $rebuilt=Join-Path $temp 'rebuild.exe'
  $null=& (Join-Path $PSScriptRoot 'build-native-launcher.ps1') -Project $Project -ReferenceAssemblies $ReferenceAssemblies -OutputPath $rebuilt
  Assert-Native ((Get-FileHash -LiteralPath $rebuilt -Algorithm SHA256).Hash -ceq (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash) 'Rebuilding C# 5 against official .NET Framework references reproduces exact binary bytes'
 }else{throw 'Native release verification requires official .NET Framework 4.7.2 references.'}
 # Execute the production C# bootstrap with ONLY platform assembly loading, root and WinForms adapted.
 # Reflection invocation, STA/thread options, literal path, diagnostics and cleanup remain unchanged.
 $probe=@'
public static class NativeHostProbe {
 public static string Root; public static string Command;public static int Opened,Invoked,GenericInvoked,PipelineDisposed,RunspaceDisposed,Messages;public static string Message;
 public static bool FactoryFailure,OpenFailure,InvokeFailure,HadErrors,DisposeFailure;
 public static ApartmentState Apartment;public static System.Management.Automation.Runspaces.PSThreadOptions Threads;
 public static void Reset(){Command=null;Opened=Invoked=GenericInvoked=PipelineDisposed=RunspaceDisposed=Messages=0;Message=null;FactoryFailure=OpenFailure=InvokeFailure=HadErrors=DisposeFailure=false;}
}
namespace System.Windows.Forms {
 public enum MessageBoxButtons {OK} public enum MessageBoxIcon {Error}
 public static class Application {public static void EnableVisualStyles(){}public static void SetCompatibleTextRenderingDefault(bool value){}}
 public static class MessageBox {public static void Show(string message,string title,MessageBoxButtons buttons,MessageBoxIcon icon){NativeHostProbe.Messages++;NativeHostProbe.Message=message;}}
}
namespace System.Management.Automation.Runspaces {
 public enum PSThreadOptions {Default,UseNewThread,UseCurrentThread}
 public class Runspace:IDisposable {
  public ApartmentState ApartmentState {get{return NativeHostProbe.Apartment;}set{NativeHostProbe.Apartment=value;}}
  public PSThreadOptions ThreadOptions {get{return NativeHostProbe.Threads;}set{NativeHostProbe.Threads=value;}}
  public void Open(){NativeHostProbe.Opened++;if(NativeHostProbe.OpenFailure)throw new Exception("SECRET_PATIENT_OPEN");}
  public void Dispose(){NativeHostProbe.RunspaceDisposed++;if(NativeHostProbe.DisposeFailure)throw new Exception("SECRET_PATIENT_DISPOSE");}
 }
 public static class RunspaceFactory {public static Runspace CreateRunspace(){if(NativeHostProbe.FactoryFailure)throw new Exception("SECRET_PATIENT_FACTORY");return new Runspace();}}
}
namespace System.Management.Automation {
 public sealed class PowerShell:IDisposable {
  public Runspaces.Runspace Runspace {get;set;} public bool HadErrors {get{return NativeHostProbe.HadErrors;}}
  public static PowerShell Create(){return new PowerShell();}
  public PowerShell AddCommand(string path){NativeHostProbe.Command=path;return this;}
  public T[] Invoke<T>(){NativeHostProbe.GenericInvoked++;throw new Exception("Wrong generic Invoke");}
  public object[] Invoke(){NativeHostProbe.Invoked++;if(NativeHostProbe.InvokeFailure)throw new Exception("SECRET_PATIENT_INVOKE");return new object[0];}
  public void Dispose(){NativeHostProbe.PipelineDisposed++;if(NativeHostProbe.DisposeFailure)throw new Exception("SECRET_PATIENT_DISPOSE");}
 }
}
'@
 $adapted=$source.Replace('namespace MedicalConstructor.Native {','namespace MedicalConstructor.NativeVerificationV72 {').Replace('AppDomain.CurrentDomain.BaseDirectory','NativeHostProbe.Root').Replace('Assembly engine=Assembly.Load(EngineName);','Assembly engine=Assembly.GetExecutingAssembly();')
 Add-Type -CompilerOptions @('/langversion:5','/nowarn:0436') -TypeDefinition ($adapted+"`n"+$probe)
 $hostType=[NativeHostProbe].Assembly.GetType('MedicalConstructor.NativeVerificationV72.Program')
 $main=$hostType.GetMethod('Main',[Reflection.BindingFlags]'NonPublic,Static')
 Assert-Native ($null -ne $main) 'Production native Main compiles with C# 5 using platform-only adapters'
 Assert-Native (@($main.GetCustomAttributesData()|Where-Object {$_.AttributeType.FullName -ceq 'System.STAThreadAttribute'}).Count -eq 1) 'Production Main itself carries STAThread startup attribute'
 $root=Join-Path $temp 'Программа с пробелами & $literal';[void][IO.Directory]::CreateDirectory($root);[NativeHostProbe]::Root=$root
 [IO.File]::WriteAllText((Join-Path $root 'launcher.ps1'),'# test launcher');[IO.File]::WriteAllText((Join-Path $root 'constructor.ps1'),'# test constructor')
 [NativeHostProbe]::Reset();$exit=$main.Invoke($null,$null)
 Assert-Native ($exit -eq 0 -and [NativeHostProbe]::Invoked -eq 1) 'Production host opens and invokes the application in its own runspace'
 Assert-Native ([NativeHostProbe]::Apartment -eq 'STA' -and [NativeHostProbe]::Threads -eq 'UseCurrentThread') 'Runspace uses STA and the current GUI thread'
 Assert-Native ([NativeHostProbe]::Command -ceq (Join-Path $root 'launcher.ps1')) 'AddCommand receives literal absolute script path including Unicode spaces and shell metacharacters'
 Assert-Native ([NativeHostProbe]::GenericInvoked -eq 0) 'Reflection explicitly selects non-generic parameterless Invoke overload'
 Assert-Native ([NativeHostProbe]::Opened -eq 1 -and [NativeHostProbe]::Messages -eq 0) 'Successful startup opens exactly one runspace and shows no error dialog'
 Assert-Native ([NativeHostProbe]::PipelineDisposed -eq 1 -and [NativeHostProbe]::RunspaceDisposed -eq 1) 'Normal close disposes pipeline and runspace exactly once'
 Assert-Native ([Environment]::CurrentDirectory -ceq $root -and [Environment]::GetEnvironmentVariable('PSExecutionPolicyPreference','Process') -ceq 'Bypass') 'Native startup sets portable program directory and process-only script policy'
 Assert-Native (-not [IO.File]::Exists((Join-Path $root 'startup_error.txt'))) 'Successful native startup creates no failure log'
 foreach($failure in @('FactoryFailure','OpenFailure','InvokeFailure','HadErrors')){
  [NativeHostProbe]::Reset();[NativeHostProbe].GetField($failure).SetValue($null,$true);$exit=$main.Invoke($null,$null)
  Assert-Native ($exit -eq 1 -and [NativeHostProbe]::Messages -eq 1) ('Production '+$failure+' failure returns controlled error and one native message')
  $log=[IO.File]::ReadAllText((Join-Path $root 'startup_error.txt'))
  Assert-Native ($log -match 'Incident: [0-9a-f]{32}' -and $log -notmatch 'SECRET_PATIENT|Программа с пробелами|Exception calling| at ') ('Production '+$failure+' fallback writes bounded safe incident metadata only')
  Assert-Native ([NativeHostProbe]::Message -notmatch 'SECRET_PATIENT') ('Production '+$failure+' message excludes exception content')
  if($failure -ne 'FactoryFailure'){Assert-Native ([NativeHostProbe]::RunspaceDisposed -eq 1) ('Production '+$failure+' failure disposes opened or opening runspace')}
  if($failure -in @('InvokeFailure','HadErrors')){Assert-Native ([NativeHostProbe]::PipelineDisposed -eq 1) ('Production '+$failure+' failure disposes pipeline')}
 }
 [NativeHostProbe]::Reset();[NativeHostProbe]::DisposeFailure=$true;$exit=$main.Invoke($null,$null)
 Assert-Native ($exit -eq 0 -and [NativeHostProbe]::PipelineDisposed -eq 1 -and [NativeHostProbe]::RunspaceDisposed -eq 1) 'Failure disposing pipeline does not prevent runspace cleanup or crash shutdown'
 [IO.File]::Delete((Join-Path $root 'constructor.ps1'));[NativeHostProbe]::Reset();$exit=$main.Invoke($null,$null)
 Assert-Native ($exit -eq 1 -and [NativeHostProbe]::Opened -eq 0 -and [NativeHostProbe]::Invoked -eq 0) 'Incomplete application files stop before opening any PowerShell runspace'
 Write-Output ('TOTAL '+$script:checks+' checks passed; real Windows GUI PE metadata, deterministic C# 5/.NET Framework build and production bootstrap with platform adapters verified; native Windows execution not run.')
}finally{
 [Environment]::CurrentDirectory=$oldDirectory;[Environment]::SetEnvironmentVariable('PSExecutionPolicyPreference',$oldPolicy,'Process')
 if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}
}
