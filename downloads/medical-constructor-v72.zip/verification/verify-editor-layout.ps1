﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v72'))
$ErrorActionPreference='Stop';$script:layoutChecks=0
function Assert-Layout([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:layoutChecks++;Write-Output ('PASS '+$message)}
$helperPath=Join-Path $Project 'editor-layout-v70.ps1'
$editorPath=Join-Path $Project 'template-editor-v59.ps1'
foreach($path in @($helperPath,$editorPath)){
 $tokens=$null;$errors=$null;[void][Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 Assert-Layout ($errors.Count -eq 0) ('Production layout source parses: '+[IO.Path]::GetFileName($path))
 Assert-Layout ([IO.File]::ReadAllBytes($path)[0] -eq 239) ('Windows PowerShell UTF-8 BOM: '+[IO.Path]::GetFileName($path))
}
# Minimal native-like controls record real production parenting and geometry.
# Splitters use native defaults, constrained distances, bounds clamping and
# proportional resize. Shown and drag events execute production callbacks.
# These fakes do not render fonts or claim native Windows visual verification.
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @'
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
namespace Drawing {public class Font {public string Name;public float Size;public Font(string name,float size){Name=name;Size=size;}}}
namespace Windows.Forms {
 public enum Orientation {Vertical,Horizontal}
 public enum FixedPanel {None,Panel1,Panel2}
 public enum SizeType {Absolute,Percent,AutoSize}
 public class Padding {public int Left,Top,Right,Bottom;public int Horizontal {get{return Left+Right;}}public int Vertical {get{return Top+Bottom;}}public Padding(int a){Left=Top=Right=Bottom=a;}public Padding(int l,int t,int r,int b){Left=l;Top=t;Right=r;Bottom=b;}}
 public class RowStyle {public SizeType SizeType;public float Height;public RowStyle(string type,float height){SizeType=(SizeType)Enum.Parse(typeof(SizeType),type);Height=height;}}
 public class ColumnStyle {public SizeType SizeType;public float Width;public ColumnStyle(string type,float width){SizeType=(SizeType)Enum.Parse(typeof(SizeType),type);Width=width;}}
 public class ItemsCollection:ArrayList {public object Add(string text){base.Add(text);return new Control{Text=text};}public void AddRange(object[] items){foreach(object value in items)base.Add(value);}}
 public class ControlCollection:IEnumerable {
  private readonly Control owner;private readonly List<Control> items=new List<Control>();public ControlCollection(Control p){owner=p;}public int Count {get{return items.Count;}}public Control this[int i] {get{return items[i];}}
  public void Add(Control c){Add(c,-1,-1);}public void Add(Control c,int column,int row){if(c.Parent!=null)c.Parent.Controls.Remove(c);items.Add(c);c.Parent=owner;c.Column=column;c.Row=row;if(column>=0)owner.ColumnCount=Math.Max(owner.ColumnCount,column+1);if(row>=0)owner.RowCount=Math.Max(owner.RowCount,row+1);owner.PerformLayout();}public void Remove(Control c){items.Remove(c);c.Parent=null;}public bool Contains(Control c){return items.Contains(c);}public void Clear(){foreach(Control c in items)c.Parent=null;items.Clear();}public IEnumerator GetEnumerator(){return items.GetEnumerator();}public Control[] Snapshot(){return items.ToArray();}
 }
 public class Control {
  private Size size=new Size(200,100);private bool laying;public int Column=-1,Row=-1,ColumnSpan=1,RowSpan=1;public Control Parent;public string Name="",Text="",Dock="None",TextAlign="MiddleLeft",Anchor="Top, Left",BorderStyle="None",FlowDirection="LeftToRight",DropDownStyle="DropDown",ScrollBars="None",DialogResult="None",StartPosition="Manual",AutoScaleMode="None";public object Font,Tag,SelectedTab,CancelButton,ContextMenuStrip;public bool IsDisposed;public bool Visible=true,Enabled=true,AutoSize,AutoScroll,WrapContents=true,HideSelection,FullRowSelect,ReadOnly,Multiline,Checked,HorizontalScrollbar,ScriptErrorsSuppressed,AllowWebBrowserDrop,IsWebBrowserContextMenuEnabled,WebBrowserShortcutsEnabled,KeyPreview,UseWaitCursor,TabStop=true;public int SelectedIndex=-1,TabIndex;public float DeviceDpi=96;public Size MinimumSize=new Size(0,0),AutoScaleDimensions=new Size(0,0),AutoScrollMinSize=new Size(0,0);public Padding Padding=new Padding(0),Margin=new Padding(0);public ControlCollection Controls {get;private set;}public ItemsCollection Items=new ItemsCollection();public ArrayList RowStyles=new ArrayList(),ColumnStyles=new ArrayList();public int ColumnCount=1,RowCount=1;public int Left,Top;
  public Control(){Controls=new ControlCollection(this);}public virtual Size Size {get{return size;}set{SetSize(value.Width,value.Height);}}public Size ClientSize {get{return Size;}set{Size=value;}}public int Width {get{return size.Width;}set{SetSize(value,size.Height);}}public int Height {get{return size.Height;}set{SetSize(size.Width,value);}}public Rectangle Bounds {get{return new Rectangle(Left,Top,Width,Height);}set{SetBounds(value.X,value.Y,value.Width,value.Height);}}public Rectangle ClientRectangle {get{return new Rectangle(0,0,Width,Height);}}
  public event EventHandler SizeChanged,Resize,Shown;public void RaiseShown(){if(Shown!=null)Shown(this,EventArgs.Empty);}protected virtual void SetSize(int w,int h){if(w<0||h<0)throw new ArgumentOutOfRangeException("size");if(w==size.Width&&h==size.Height)return;size=new Size(w,h);PerformLayout();if(SizeChanged!=null)SizeChanged(this,EventArgs.Empty);if(Resize!=null)Resize(this,EventArgs.Empty);}public void SetBounds(int l,int t,int w,int h){Left=l;Top=t;SetSize(Math.Max(0,w),Math.Max(0,h));}public void SuspendLayout(){}public void ResumeLayout(){PerformLayout();}public void ResumeLayout(bool perform){if(perform)PerformLayout();}public void BringToFront(){}public void SendToBack(){}public bool Focus(){return true;}public void Dispose(){IsDisposed=true;}public FakeGraphics CreateGraphics(){return new FakeGraphics{DpiX=DeviceDpi};}public void Refresh(){}public void Invalidate(){}public void SetColumnSpan(Control c,int n){c.ColumnSpan=n;}public void SetRowSpan(Control c,int n){c.RowSpan=n;}
  public virtual Rectangle DisplayRectangle {get{return new Rectangle(0,0,Width,Height);}}public virtual void PerformLayout(){if(laying)return;laying=true;try{int l=Padding.Left,t=Padding.Top,w=Math.Max(0,Width-Padding.Horizontal),h=Math.Max(0,Height-Padding.Vertical);foreach(Control c in Controls.Snapshot()){if(c.Dock=="Fill")c.SetBounds(l,t,w,h);else if(c.Dock=="Top"){c.SetBounds(l,t,w,c.Height);t+=c.Height;h=Math.Max(0,h-c.Height);}else if(c.Dock=="Bottom"){c.SetBounds(l,t+h-c.Height,w,c.Height);h=Math.Max(0,h-c.Height);}}}finally{laying=false;}}
 }
 public class FakeGraphics:IDisposable {public float DpiX;public void Dispose(){}}public class Screen {public static Rectangle Area=new Rectangle(0,0,1920,1080);public Rectangle WorkingArea {get{return Area;}}public static Screen PrimaryScreen {get{return new Screen();}}public static Screen FromControl(Control owner){return new Screen();}}
 public class Form:Control {} public class Panel:Control {}public class GroupBox:Control {}
 public class FlowLayoutPanel:Control {
  private bool active;private Rectangle display;public override Rectangle DisplayRectangle {get{return display;}}
  public override void PerformLayout(){if(active)return;active=true;try{int x=Padding.Left,y=Padding.Top,line=0,maxX=Width,maxY=Height;bool reverse=FlowDirection=="RightToLeft";if(reverse)x=Width-Padding.Right;foreach(Control c in Controls.Snapshot()){if(!c.Visible)continue;int need=c.Width+c.Margin.Horizontal;if(WrapContents&&((!reverse&&x+need>Width-Padding.Right)||(reverse&&x-need<Padding.Left))&&line>0){x=reverse?Width-Padding.Right:Padding.Left;y+=line;line=0;}int l=reverse?x-c.Margin.Right-c.Width:x+c.Margin.Left;c.SetBounds(l,y+c.Margin.Top,c.Width,c.Height);x+=reverse?-need:need;line=Math.Max(line,c.Height+c.Margin.Vertical);maxX=Math.Max(maxX,l+c.Width+c.Margin.Right);maxY=Math.Max(maxY,y+line);if(reverse&&l<0)maxX=Math.Max(maxX,Width-l);}display=new Rectangle(0,0,maxX,maxY);}finally{active=false;}}
 }public class TreeView:Control {}public class TabPage:Control {}public class TextBox:Control {}public class ComboBox:Control {}public class CheckBox:Control {}public class Label:Control {}public class Button:Control {}public class ListBox:Control {}public class WebBrowser:Control {}public class ContextMenuStrip:Control {}
 public class TabControl:Control {public ControlCollection TabPages {get{return Controls;}}public override void PerformLayout(){foreach(Control page in Controls.Snapshot())page.SetBounds(4,24,Math.Max(0,Width-8),Math.Max(0,Height-28));}}
 public class SplitContainer:Control {
  private int first=25,second=25,distance=50,width=4;private Orientation orientation=Orientation.Vertical;private bool arranging;public readonly Panel Panel1=new Panel(),Panel2=new Panel();public FixedPanel FixedPanel=FixedPanel.None;public bool IsSplitterFixed,Panel1Collapsed,Panel2Collapsed;public int SplitterMoveCalls;public event EventHandler SplitterMoved;
  public SplitContainer(){Panel1.Parent=this;Panel2.Parent=this;Size=new Size(150,100);PerformLayout();}
  public Orientation Orientation {get{return orientation;}set{orientation=value;PerformLayout();}}private int Extent {get{return orientation==Orientation.Vertical?Width:Height;}}public int SplitterWidth {get{return width;}set{if(value<1)throw new ArgumentOutOfRangeException("SplitterWidth");width=value;PerformLayout();}}public int Panel1MinSize {get{return first;}set{if(value<0)throw new ArgumentOutOfRangeException("Panel1MinSize");first=value;if(distance<value)SplitterDistance=value;}}
  public int Panel2MinSize {get{return second;}set{if(value<0)throw new ArgumentOutOfRangeException("Panel2MinSize");second=value;if(Extent-width-distance<value)SplitterDistance=Extent-width-value;}}public int SplitterDistance {get{return distance;}set{if(value<0)throw new ArgumentOutOfRangeException("SplitterDistance");int actual=Math.Min(Math.Max(value,first),Extent-width-second);if(actual<0)throw new InvalidOperationException("SplitterDistance cannot fit panel minima");if(distance==actual)return;distance=actual;PerformLayout();if(SplitterMoved!=null)SplitterMoved(this,EventArgs.Empty);}}public void DragTo(int value){SplitterDistance=value;SplitterMoveCalls++;}
  protected override void SetSize(int w,int h){int prior=Extent;if(orientation==Orientation.Vertical)w=Math.Max(w,first+second+width);else h=Math.Max(h,first+second+width);int next=orientation==Orientation.Vertical?w:h;if(prior>0&&next!=prior){if(FixedPanel==FixedPanel.None)distance=(int)Math.Floor(next*(double)distance/prior);else if(FixedPanel==FixedPanel.Panel2)distance+=next-prior;}distance=Math.Max(first,Math.Min(Math.Max(0,next-width-second),distance));base.SetSize(w,h);}
  public override void PerformLayout(){if(Panel1==null||Panel2==null||arranging)return;arranging=true;try{int available=Math.Max(0,Extent-width);distance=Math.Max(0,Math.Min(distance,available));if(orientation==Orientation.Vertical){Panel1.SetBounds(0,0,distance,Height);Panel2.SetBounds(distance+width,0,available-distance,Height);}else{Panel1.SetBounds(0,0,Width,distance);Panel2.SetBounds(0,distance+width,Width,available-distance);}}finally{arranging=false;}}
 }
 public class TableLayoutPanel:Control {
  private bool active;private int[] Parts(ArrayList styles,int count,int extent,bool rows){int[] sizes=new int[count];float percent=0;int used=0;for(int i=0;i<count;i++){if(i>=styles.Count){percent+=100;continue;}if(rows){RowStyle s=(RowStyle)styles[i];if(s.SizeType==SizeType.Absolute){sizes[i]=(int)s.Height;used+=sizes[i];}else percent+=s.Height;}else{ColumnStyle s=(ColumnStyle)styles[i];if(s.SizeType==SizeType.Absolute){sizes[i]=(int)s.Width;used+=sizes[i];}else percent+=s.Width;}}int remainder=Math.Max(0,extent-used);for(int i=0;i<count;i++){bool relative=i>=styles.Count || (rows?((RowStyle)styles[i]).SizeType:((ColumnStyle)styles[i]).SizeType)!=SizeType.Absolute;if(relative){float p=i>=styles.Count?100:(rows?((RowStyle)styles[i]).Height:((ColumnStyle)styles[i]).Width);sizes[i]=percent==0?0:(int)(remainder*p/percent);}}return sizes;}
  public override void PerformLayout(){if(active)return;active=true;try{if(AutoSize&&Dock=="Top"){int preferred=Padding.Vertical;foreach(RowStyle style in RowStyles)if(style.SizeType==SizeType.Absolute)preferred+=(int)style.Height;if(preferred>0)Height=preferred;}int[] cols=Parts(ColumnStyles,ColumnCount,Math.Max(0,Width-Padding.Horizontal),false),rows=Parts(RowStyles,RowCount,Math.Max(0,Height-Padding.Vertical),true);foreach(Control c in Controls.Snapshot()){if(c.Column<0||c.Row<0)continue;int left=Padding.Left,top=Padding.Top;for(int i=0;i<c.Column&&i<cols.Length;i++)left+=cols[i];for(int i=0;i<c.Row&&i<rows.Length;i++)top+=rows[i];int w=0,h=0;for(int i=c.Column;i<c.Column+c.ColumnSpan&&i<cols.Length;i++)w+=cols[i];for(int i=c.Row;i<c.Row+c.RowSpan&&i<rows.Length;i++)h+=rows[i];c.SetBounds(left,top,w,h);}}finally{active=false;}}
 }
}

'@
. $helperPath
$source=[IO.File]::ReadAllText($editorPath)
$tokens=$null;$errors=$null;$editorAst=[Management.Automation.Language.Parser]::ParseFile($editorPath,[ref]$tokens,[ref]$errors)
foreach($name in @('New-MedicalEditorButton','New-MedicalEditorLabel')){
 $node=$editorAst.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$false)
 if(-not $node){throw ('Missing production helper '+$name)};. ([scriptblock]::Create($node.Extent.Text))
}
function Get-MedicalFormDisplayName([string]$path,[string]$fallback){return 'Тестовый шаблон'}
function New-MedicalParagraphFormatEditor($state,$owner){return [pscustomobject]@{Root=(New-Object Windows.Forms.Panel);Editor=(New-Object Windows.Forms.TextBox)}}
$editor=$editorAst.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Show-MedicalFormTemplateEditor'},$false)
$dialogAssignment=$editor.Find({param($n)$n -is [Management.Automation.Language.AssignmentStatementAst] -and $n.Left -is [Management.Automation.Language.VariableExpressionAst] -and $n.Left.VariablePath.UserPath -eq 'dialog'},$true)
$commandsAssignment=$editor.Find({param($n)$n -is [Management.Automation.Language.AssignmentStatementAst] -and $n.Left -is [Management.Automation.Language.VariableExpressionAst] -and $n.Left.VariablePath.UserPath -eq 'editorCommands'},$true)
if(-not $dialogAssignment -or -not $commandsAssignment){throw 'Actual editor construction block unavailable'}
$construction=$source.Substring($dialogAssignment.Extent.StartOffset,$commandsAssignment.Extent.StartOffset-$dialogAssignment.Extent.StartOffset)
function New-TestEditorGeometry([int]$width,[int]$height,[int]$dpi=96){
 $owner=$null;$schema=[pscustomobject]@{AutoTemplate=$false;Sections=@([pscustomobject]@{Id='section';Title='Раздел';Fields=@([pscustomobject]@{Id='field';Label='Поле';Marker='FIELD'})})};$model=[pscustomobject]@{TemplateExtension='.docx';Parts=@{'word/document.xml'='<document>ТЕКСТ {{FIELD}}</document>'}};$source='test-template.docx';$state=@{Schema=$schema;Model=$model;Loading=$false}
 $before=ConvertTo-Json -InputObject $state -Depth 12 -Compress
 Invoke-Expression $construction
 $dialog.DeviceDpi=$dpi;$dialog.Size=New-Object Drawing.Size($width,$height);$dialog.RaiseShown()
 return [pscustomobject]@{Workspace=$workspace;Dialog=$dialog;Tree=$tree;Tabs=$tabs;FieldTab=$fieldTab;DetailTab=$detailTab;Properties=$properties;ParagraphList=$paragraphList;DocumentTabs=$documentTabs;TextEditorHost=$textEditorHost;FieldName=$fieldName;FieldMarker=$fieldMarker;Save=$save;SaveForm=$saveForm;Cancel=$cancel;Footer=$footer;State=$state;Before=$before;MarkerTools=$markerTools;TemplateTools=$templateTools;PartCombo=$partCombo;LayoutBrowser=$layoutBrowser;LayoutTab=$layoutTab;FormatTab=$formatTab;WordTab=$wordTab;DetailProperties=$detailProperties;LeftButtons=$leftButtons}
}
function Get-GlobalLayoutRectangle($control){
 $x=$control.Left;$y=$control.Top;$p=$control.Parent
 while($p){$x+=$p.Left;$y+=$p.Top;$p=$p.Parent}
 return [Drawing.Rectangle]::new($x,$y,$control.Width,$control.Height)
}
function Assert-SplitterSafe($split,[string]$label){
 $extent=if([string]$split.Orientation -eq 'Horizontal'){$split.ClientSize.Height}else{$split.ClientSize.Width}
 $available=[Math]::Max(0,$extent-$split.SplitterWidth)
 Assert-Layout ($split.SplitterDistance -ge $split.Panel1MinSize -and $split.SplitterDistance -le $available-$split.Panel2MinSize) ($label+' remains within native splitter constraints')
}
# Native .NET WinForms SplitContainer behavior is modeled from default bounds,
# minimum panel extents and FixedPanel=None proportional resizing. We deliberately
# do not mock Windows font measurement, Word, browser painting or window chrome.
# A direct fixture probe prevents a permissive fake from hiding native constraints.
$probe=New-Object Windows.Forms.SplitContainer
Assert-Layout ($probe.Width -eq 150 -and $probe.Height -eq 100 -and $probe.Panel1MinSize -eq 25 -and $probe.Panel2MinSize -eq 25 -and $probe.SplitterWidth -eq 4) 'Fixture enforces native SplitContainer defaults'
$probe.Size=New-Object Drawing.Size(3,100)
Assert-Layout ($probe.Width -eq 54) 'Fixture clamps container bounds to native panel minima'
$probe.Size=New-Object Drawing.Size(1000,100);$probe.SplitterDistance=400;$probe.Width=1500
Assert-Layout ($probe.SplitterDistance -eq 600) 'Fixture preserves native user splitter ratio while resizing'
$probe.SplitterDistance=0
Assert-Layout ($probe.SplitterDistance -eq 25) 'Fixture clamps native splitter distance to first minimum'
$probe.SplitterDistance=9999
Assert-Layout ($probe.SplitterDistance -eq $probe.Width-29) 'Fixture clamps native splitter distance to second minimum'
# The limit function handles transient empty windows, narrow widths, and DPI.
foreach($length in @(0,1,2,6,7,8,20,80,240,460,800,1900)){
 foreach($scale in @(1.0,1.25,1.5)){
  $limits=Get-MedicalEditorSplitterLimits $length 7 330 470 $scale
  Assert-Layout ($limits.FirstMinimum -ge 0 -and $limits.SecondMinimum -ge 0 -and $limits.MaximumDistance -ge $limits.FirstMinimum -and $limits.FirstMinimum+$limits.SecondMinimum -le $limits.Available) ('Safe limits at '+$length+' pixels, scale '+$scale)
 }
}
foreach($scale in @(0,-1,[double]::NaN,[double]::PositiveInfinity)){
 $limits=Get-MedicalEditorSplitterLimits 1000 7 330 470 $scale
 Assert-Layout ($limits.FirstMinimum -eq 330 -and $limits.SecondMinimum -eq 470) ('Invalid display scale defaults safely: '+$scale)
}
# Real construction includes every existing Word, field and Save control.
foreach($geometry in @(@(1100,740,96),@(1280,720,96),@(1366,768,96),@(1920,1080,96),@(1280,720,120),@(1366,768,144),@(1920,1080,144))){
 $view=New-TestEditorGeometry $geometry[0] $geometry[1] $geometry[2];$w=$view.Workspace;$suffix=' at '+($geometry -join 'x')
 Assert-Layout ($w -and $w.State.Initialized -and $w.Root.Parent -eq $view.Dialog) ('Actual editor uses new workspace shell'+$suffix)
 Assert-Layout ([Math]::Abs([double]$w.State.Scale-$geometry[2]/96.0) -lt .001) ('Shown callback detects actual display DPI'+$suffix)
 Assert-Layout ($w.WordHost.Parent -eq $w.OuterSplit.Panel1 -and $w.StructureHost.Parent -eq $w.RightSplit.Panel2 -and $w.FieldsHost.Parent -eq $w.FieldsSplit.Panel1 -and $w.PropertiesHost.Parent -eq $w.FieldsSplit.Panel2) ('Four panes follow requested parent hierarchy'+$suffix)
 $word=Get-GlobalLayoutRectangle $w.WordHost;$fields=Get-GlobalLayoutRectangle $w.FieldsHost;$properties=Get-GlobalLayoutRectangle $w.PropertiesHost;$structure=Get-GlobalLayoutRectangle $w.StructureHost
 Assert-Layout ($word.Left -lt $fields.Left -and $word.Top -eq $fields.Top -and $word.Bottom -eq $structure.Bottom) ('Word page occupies full left height'+$suffix)
 Assert-Layout ($fields.Left -lt $properties.Left -and $fields.Top -eq $properties.Top -and $fields.Bottom -le $structure.Top -and $properties.Bottom -le $structure.Top) ('Fields and properties share top-right row above structure'+$suffix)
 Assert-Layout ($structure.Left -eq $fields.Left -and $structure.Right -eq $properties.Right) ('Structure occupies full lower-right width'+$suffix)
 Assert-Layout ($word.Right -le $fields.Left -and $fields.Right -le $properties.Left -and $word.Top -ge 0 -and $properties.Right -le $view.Dialog.Width -and $structure.Bottom -le $view.Dialog.Height) ('Requested panes remain non-overlapping within supported window bounds'+$suffix)
 Assert-Layout ($view.Tree.Parent -and $view.Tree.Parent.Parent -eq $w.FieldsHost -and $view.Tabs.Parent -eq $w.PropertiesHost) ('Actual field tree and properties reside in distinct panes'+$suffix)
 Assert-Layout ($view.ParagraphList.Parent -and $view.ParagraphList.Parent.Parent -eq $w.StructureHost -and $view.TextEditorHost.Parent -and $view.TextEditorHost.Parent.Parent -eq $w.WordHost) ('Actual document editor and paragraph structure reside in correct panes'+$suffix)
 Assert-Layout ($view.FieldTab.AutoScroll -and $view.DetailTab.AutoScroll -and $view.Properties.AutoSize) ('Field and detail settings remain scroll-accessible'+$suffix)
 Assert-Layout ($view.LeftButtons.AutoScroll -and $view.LeftButtons.WrapContents -and $view.TemplateTools.AutoScroll -and $view.MarkerTools.AutoScroll) ('Field and document actions remain reachable in narrow panes'+$suffix)
 Assert-Layout ($view.FieldName.Width -gt 40 -and $view.FieldMarker.Width -gt 40 -and -not $view.FieldName.ReadOnly -and -not $view.FieldMarker.ReadOnly) ('Field property inputs retain editable space'+$suffix)
 Assert-Layout ($view.SaveForm.Parent -eq $w.Footer -and $view.Save.Parent -eq $w.Footer -and $view.Cancel.Parent -eq $w.Footer -and $w.Footer.AutoScroll) ('Save, Apply, Close remain in accessible footer'+$suffix)
 $footerRect=Get-GlobalLayoutRectangle $w.Footer
 Assert-Layout ($footerRect.Bottom -le $view.Dialog.ClientSize.Height -and $footerRect.Left -ge 0 -and $footerRect.Height -ge 60) ('Save footer stays inside dialog client area'+$suffix)
 $saveRect=Get-GlobalLayoutRectangle $view.SaveForm
 Assert-Layout ($saveRect.Height -gt 0 -and $saveRect.Top -ge $footerRect.Top -and $saveRect.Bottom -le $footerRect.Bottom -and ($saveRect.Left -ge $footerRect.Left -and $saveRect.Right -le $footerRect.Right)) ('Save action stays fully visible in footer'+$suffix)
 Assert-Layout ($view.LayoutBrowser.Width -gt 100 -and $view.LayoutBrowser.Height -gt 100 -and $view.ParagraphList.Width -gt 100 -and $view.ParagraphList.Height -gt 80 -and $view.Tree.Width -gt 100 -and $view.Tree.Height -gt 25) ('Word page, structure rows and field tree receive positive usable space'+$suffix)
 Assert-Layout ($view.DocumentTabs.SelectedTab -eq $view.LayoutTab -and $view.LayoutTab.Parent -eq $view.DocumentTabs -and $view.FormatTab.Parent -eq $view.DocumentTabs -and $view.WordTab.Parent -eq $view.DocumentTabs) ('Full Word sheet is the initial view while both formatting views remain available'+$suffix)
 Assert-Layout ($view.Properties.Height -gt $view.FieldTab.Height -and $view.DetailProperties.Height -gt $view.DetailTab.Height -and $view.FieldTab.AutoScroll -and $view.DetailTab.AutoScroll) ('Long field and clarification settings can scroll within short upper pane'+$suffix)
 Assert-Layout ($view.Dialog.KeyPreview -and $view.Dialog.CancelButton -eq $view.Cancel) ('Ctrl+S and guarded Escape retain dialog routing'+$suffix)
 Assert-Layout (($view.State | ConvertTo-Json -Depth 12 -Compress) -ceq $view.Before) ('Constructing and showing layout preserves schema and Word source'+$suffix)
 foreach($split in @($w.OuterSplit,$w.RightSplit,$w.FieldsSplit)){Assert-SplitterSafe $split ($split.Name+$suffix);Assert-Layout (-not $split.IsSplitterFixed -and -not $split.Panel1Collapsed -and -not $split.Panel2Collapsed) ($split.Name+' remains draggable with both panes visible'+$suffix)}
 if($geometry[0] -eq 1920 -and $geometry[2] -eq 96){
  Assert-Layout ([Math]::Abs($word.Width/($word.Width+$fields.Width+$properties.Width+7)-.44) -lt .02) 'Wide window starts with Word pane at forty-four percent'
  Assert-Layout ([Math]::Abs($fields.Height/($fields.Height+$structure.Height)-.38) -lt .02) 'Wide window gives most right height to document structure'
 }
 $view.Dialog.Dispose()
}
# User moves all separators; later Resize/Shown must not restore defaults.
$view=New-TestEditorGeometry 1920 1080 96;$w=$view.Workspace
$w.OuterSplit.DragTo(780);$w.RightSplit.DragTo(350);$w.FieldsSplit.DragTo(420)
$beforeDistances=@($w.OuterSplit.SplitterDistance,$w.RightSplit.SplitterDistance,$w.FieldsSplit.SplitterDistance)
$view.Dialog.RaiseShown();Update-MedicalEditorWorkspaceLayout $w $false
Assert-Layout (($beforeDistances -join ',') -ceq (@($w.OuterSplit.SplitterDistance,$w.RightSplit.SplitterDistance,$w.FieldsSplit.SplitterDistance) -join ',')) 'Showing or refreshing an existing editor preserves all dragged separators'
$beforeRatios=@(($w.OuterSplit.SplitterDistance/[double]$w.OuterSplit.Width),($w.RightSplit.SplitterDistance/[double]$w.RightSplit.Height),($w.FieldsSplit.SplitterDistance/[double]$w.FieldsSplit.Width))
$view.Dialog.Size=New-Object Drawing.Size(2100,1150)
$afterRatios=@(($w.OuterSplit.SplitterDistance/[double]$w.OuterSplit.Width),($w.RightSplit.SplitterDistance/[double]$w.RightSplit.Height),($w.FieldsSplit.SplitterDistance/[double]$w.FieldsSplit.Width))
for($i=0;$i -lt 3;$i++){Assert-Layout ([Math]::Abs($beforeRatios[$i]-$afterRatios[$i]) -lt .005) ('Expanding window retains user-adjusted splitter ratio '+$i)}
foreach($size in @(@(980,640),@(640,480),@(320,220),@(80,80),@(8,8),@(0,0),@(1366,768),@(1920,1080))){
 $view.Dialog.Size=New-Object Drawing.Size($size[0],$size[1]);Update-MedicalEditorWorkspaceLayout $w $false
 foreach($split in @($w.OuterSplit,$w.RightSplit,$w.FieldsSplit)){
  $extent=if([string]$split.Orientation -eq 'Horizontal'){$split.Height}else{$split.Width}
  if($extent -ge 9){Assert-SplitterSafe $split ($split.Name+' after resize '+($size -join 'x'))}
 }
 Assert-Layout (-not $w.State.Resizing) ('Resize lock releases after '+($size -join 'x'))
}
Assert-Layout (($view.State | ConvertTo-Json -Depth 12 -Compress) -ceq $view.Before) 'Repeated narrow/wide resize preserves all schema and Word source content'
# Default bounds fit screens smaller than the preferred window.
foreach($screen in @(@(1920,1080),@(1366,768),@(1280,720),@(1024,768))){
 [Windows.Forms.Screen]::Area=[Drawing.Rectangle]::new(0,0,$screen[0],$screen[1]);$dialog=New-Object Windows.Forms.Form;Set-MedicalEditorWindowBounds $dialog $null
 Assert-Layout ($dialog.Width -le $screen[0] -and $dialog.Height -le $screen[1] -and $dialog.MinimumSize.Width -le $dialog.Width -and $dialog.MinimumSize.Height -le $dialog.Height) ('Initial editor bounds fit '+($screen -join 'x')+' screen')
}
'ALL '+$script:layoutChecks+' EDITOR LAYOUT CHECKS PASSED'
