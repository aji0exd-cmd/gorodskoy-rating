﻿# Reusable forms and template selection. Patient answers belong to saved cases.
$script:medicalWorkspaceReady=$false
$script:activeMedicalFormPath=''
$script:activeMedicalFormName='Новая форма'
$script:medicalFormBaseline=''

function Get-MedicalFormSignature($config){
 $schemas=@((Copy-MedicalFormSchema $config));$stageForms=$null
 if($script:medicalClinicalForms){
  $stageForms=Get-MedicalClinicalFormData
  foreach($entry in @($stageForms.Diaries)){$schemas+=@($entry.Schema)}
  if($stageForms.Discharge){$schemas+=@($stageForms.Discharge.Schema)}
 }
 $templates=@(foreach($schema in $schemas){
  if($schema.AutoTemplate){'по структуре'}else{
   $templatePath=Get-UniversalTemplatePath $schema
   if([IO.File]::Exists($templatePath)){Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($templatePath))}else{'шаблон отсутствует'}
  }
 })
 $signature=[pscustomobject]@{Schema=$schemas[0];StageForms=$stageForms;Templates=$templates}
 return (Get-MedicalBytesSha256 ([Text.Encoding]::UTF8.GetBytes(($signature|ConvertTo-Json -Depth 50 -Compress))))
}
function Test-MedicalWorkspaceHasData {
 if($script:medicalWorkspaceReady -and -not $script:activeMedicalFormPath){return $true}
 foreach($map in @($script:universalValues,$script:universalDetails)){
  if($map){foreach($value in $map.Values){if(-not [string]::IsNullOrWhiteSpace([string]$value)){return $true}}}
 }
 if($script:stageData){foreach($entry in $script:stageData.Values){foreach($value in @($entry)){if(-not [string]::IsNullOrWhiteSpace([string]$value)){return $true}}}}
 if($script:medicalClinicalState){
  foreach($entry in @($script:medicalClinicalState.Diaries)+@($script:medicalClinicalState.Discharge)){
   foreach($map in @($entry.Values,$entry.Details)){if($map){foreach($value in $map.Values){if(-not [string]::IsNullOrWhiteSpace([string]$value)){return $true}}}}
  }
 }
 if($script:medicalFormBaseline -and (Get-MedicalFormSignature $script:universalConfig) -ne $script:medicalFormBaseline){return $true}
 return $false
}
function Confirm-MedicalFormReset {
 if(-not $script:medicalWorkspaceReady){return $true}
 Capture-Stage
 if(-not (Test-MedicalWorkspaceHasData)){return $true}
 if([Windows.Forms.MessageBox]::Show($form,'Создание или открытие формы начинает новый осмотр. Ответы пациента и текущие дневники будут очищены. Сохраните карту и изменения формы перед продолжением. Продолжить?','Новая форма / открытие формы','YesNo','Question') -ne 'Yes'){return $false}
 if(Get-Command Write-MedicalSessionBackup -CommandType Function -ErrorAction SilentlyContinue){
  try{[void](Write-MedicalSessionBackup);Archive-MedicalPendingBackup}
  catch{[void][Windows.Forms.MessageBox]::Show($form,'Текущая работа не заменена: резервная копия не записана. '+$_.Exception.Message,'Открытие новой формы');return $false}
 }
 return $true
}
function Get-MedicalGeneratedSchema($config){
 $candidate=Copy-MedicalFormSchema $config
 $source=Get-UniversalTemplatePath $candidate
 $wordFields=@();if([IO.File]::Exists($source)){$wordFields=@(Get-UniversalWordFields $source)}
 foreach($field in Get-UniversalFields $candidate){
  if($field.Type -in @('choice','choice_detail') -and @($field.Options).Count -eq 0){
   $bound=@($wordFields | Where-Object {$_.Id -eq $field.WordId})
   if($bound.Count){$field.Options=@($bound[0].Options)}
   if(@($field.Options).Count -eq 0){throw ('Добавьте варианты списка для поля «'+$field.Label+'» перед созданием шаблона по структуре.')}
  }
  $field | Add-Member -NotePropertyName WordId -NotePropertyValue '' -Force
 }
 Assert-UniversalConfig $candidate
 return $candidate
}
function Set-MedicalGeneratedTemplateReference($config){
 $candidate=Get-MedicalGeneratedSchema $config
 $template=New-MedicalTemplateFile 'Шаблон по структуре формы.docx' $candidate
 $config.Template=$template.RelativePath
 foreach($field in Get-UniversalFields $config){
  $generated=@(Get-UniversalFields $candidate | Where-Object {$_.Id -eq $field.Id})[0]
  $field.Options=@($generated.Options);$field | Add-Member -NotePropertyName WordId -NotePropertyValue '' -Force
 }
}
# Local import is staged in memory and private temporary files. The original
# document is never written, and cancelling recognition keeps the imported text
# available for manual marker placement in the unified editor.
function Import-MedicalLocalTemplateChoice($owner,$config,[string]$path,[bool]$newForm=$true){
 $localImport=$null;$reviewFolder=''
 try{
  $localImport=Import-MedicalLocalDocument -Path $path -Owner $owner
  if(-not $localImport){return $null}
  $warnings=@($localImport.Warnings | Where-Object {-not [string]::IsNullOrWhiteSpace([string]$_)})
  if($warnings.Count){[void][Windows.Forms.MessageBox]::Show($owner,($warnings -join "`r`n"),'Загрузка документа','OK','Information')}
  $extension=[IO.Path]::GetExtension([string]$localImport.Path)
  $name=(Get-MedicalFormDisplayName ([IO.Path]::GetFileNameWithoutExtension($path)) 'Шаблон формы')+$extension
  if(-not $newForm){
   # Recovery must keep the patient's existing field IDs and answer bindings.
   $recovery=Import-MedicalRecoveryTemplate $config $localImport.Path
   $item=Import-MedicalTemplateBytes ([IO.File]::ReadAllBytes($recovery.Template.Path)) $name $true
   $candidate=$recovery.Schema
  }else{
   $item=Import-MedicalTemplateBytes ([IO.File]::ReadAllBytes($localImport.Path)) $name $true
   $candidate=New-MedicalSchemaFromTemplate $item.Path
   $model=Read-MedicalTemplateModel $item.Path
   $recognized=Invoke-MedicalTemplateRecognition $owner $model $candidate
   if($null -ne $recognized){
    Assert-UniversalConfig $recognized.Schema
    if(-not $recognized.Model -or -not $recognized.Model.Parts.ContainsKey('word/document.xml')){throw 'Распознавание не вернуло корректный Word-шаблон.'}
    $reviewFolder=Join-Path ([IO.Path]::GetTempPath()) ('mc-recognized-'+[guid]::NewGuid().ToString('N'))
    [void][IO.Directory]::CreateDirectory($reviewFolder);$reviewPath=Join-Path $reviewFolder $name
    Write-MedicalTemplateModel $reviewPath $recognized.Model
    $item=Import-MedicalTemplateBytes ([IO.File]::ReadAllBytes($reviewPath)) $name $true
    $candidate=$recognized.Schema
   }
  }
  $candidate.Template=$item.RelativePath;$candidate.AutoTemplate=$false
  $candidate | Add-Member -NotePropertyName PreserveTemplateFormatting -NotePropertyValue $true -Force
  Assert-UniversalConfig $candidate
  return [pscustomobject]@{Schema=$candidate;Template=$item;Name=(Get-MedicalFormDisplayName $name 'Шаблон формы')}
 }finally{
  try{if($reviewFolder -and [IO.Directory]::Exists($reviewFolder)){[IO.Directory]::Delete($reviewFolder,$true)}}
  finally{if($localImport){Remove-MedicalLocalImport -Import $localImport}}
 }
}

function Show-MedicalTemplateChoice($owner,$config,[bool]$newForm=$true){
 [void](Initialize-MedicalTemplateFolder)
 $templates=@(Get-MedicalTemplates)
 $dialog=New-Object Windows.Forms.Form;$dialog.Text='Шаблоны';$dialog.Size=New-Object Drawing.Size(680,455)
 $dialog.StartPosition='CenterParent';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false
 $result=[pscustomobject]@{Schema=$null;Template=$null;Name=''}
 $hint=New-Object Windows.Forms.Label;$hint.SetBounds(20,20,620,68)
 $hint.Text=if($templates.Count){'Выберите Word-шаблон из папки «Шаблоны», создайте новый по структуре формы или загрузите документ для локального распознавания.'}else{'Папка «Шаблоны» пока пустая. Создайте шаблон по структуре формы или загрузите документ / изображение.'}
 $dialog.Controls.Add($hint)
 $list=New-Object Windows.Forms.ComboBox;$list.DropDownStyle='DropDownList';$list.SetBounds(20,105,620,30)
 foreach($template in $templates){[void]$list.Items.Add((Get-MedicalFormDisplayName $template.Name 'Шаблон Word'))}
 if($templates.Count){$list.SelectedIndex=0};$dialog.Controls.Add($list)
 $select=New-Object Windows.Forms.Button;$select.Text='Выбрать';$select.SetBounds(20,159,190,42);$select.Enabled=$templates.Count -gt 0;$dialog.Controls.Add($select)
 $create=New-Object Windows.Forms.Button;$create.Text='Создать шаблон';$create.SetBounds(220,159,195,42);$dialog.Controls.Add($create)
 $import=New-Object Windows.Forms.Button;$import.Text='Загрузить свой';$import.SetBounds(425,159,215,42);$dialog.Controls.Add($import)
 $help=New-Object Windows.Forms.Label;$help.SetBounds(20,224,620,112)
 $help.Text='DOCX / DOTX, DOC, PDF, TXT и изображения. Документы обрабатываются локально; для DOC и PDF нужен Word, для изображений — системное распознавание Windows. Проверьте предложения маркеров перед применением. Исходный файл сохраняется; Word-копия хранится в папке «Шаблоны».';$dialog.Controls.Add($help)
 $cancel=New-Object Windows.Forms.Button;$cancel.Text='Отмена';$cancel.SetBounds(440,351,200,36);$cancel.DialogResult='Cancel';$dialog.Controls.Add($cancel);$dialog.CancelButton=$cancel
 $select.Add_Click({
  try{
   $item=$templates[$list.SelectedIndex]
   Test-MedicalTemplateBytes ([IO.File]::ReadAllBytes($item.Path))
   if($newForm){$candidate=New-MedicalSchemaFromTemplate $item.Path}else{$recovery=Import-MedicalRecoveryTemplate $config $item.Path;$candidate=$recovery.Schema;$item=$recovery.Template}
   $candidate.Template=$item.RelativePath;$candidate.AutoTemplate=$false
   Assert-UniversalConfig $candidate
   $result.Schema=$candidate;$result.Template=$item;$result.Name=[IO.Path]::GetFileNameWithoutExtension($item.Name)
   $dialog.DialogResult='OK';$dialog.Close()
  }catch{[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Шаблон')}
 })
 $create.Add_Click({
  try{
   $name=Show-UniversalTextPrompt $dialog 'Название нового шаблона DOCX' 'Мой шаблон.docx'
   if(-not $name){return}
   if([IO.Path]::GetExtension($name) -and [IO.Path]::GetExtension($name) -ne '.docx'){throw 'Для нового шаблона используйте .docx. Готовый .dotx можно загрузить отдельной кнопкой.'}
   $candidate=Get-MedicalGeneratedSchema $config
   $item=New-MedicalTemplateFile $name $candidate
   $candidate.Template=$item.RelativePath;$candidate.AutoTemplate=$false
   $result.Schema=$candidate;$result.Template=$item;$result.Name=[IO.Path]::GetFileNameWithoutExtension($item.Name)
   $dialog.DialogResult='OK';$dialog.Close()
  }catch{[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Создание шаблона')}
 })
 $localChoiceCommand=Get-Command -Name Import-MedicalLocalTemplateChoice -CommandType Function -ErrorAction Stop
 $localDocumentFilter=Get-MedicalLocalDocumentFilter
 $import.Add_Click({
  $picker=New-Object Windows.Forms.OpenFileDialog;$picker.Filter=$localDocumentFilter;$picker.Title='Загрузить документ для шаблона';$picker.CheckFileExists=$true;$picker.Multiselect=$false
  try{
   if($picker.ShowDialog($dialog) -ne 'OK'){return}
   $choice=& $localChoiceCommand $dialog $config $picker.FileName $newForm
   if(-not $choice){return}
   $result.Schema=$choice.Schema;$result.Template=$choice.Template;$result.Name=$choice.Name
   $dialog.DialogResult='OK';$dialog.Close()
  }catch{[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Загрузка шаблона')}
  finally{$picker.Dispose()}
 })
 Set-DarkTheme $dialog
 try{if($dialog.ShowDialog($owner) -eq 'OK'){return $result};return $null}finally{$dialog.Dispose()}
}
function Show-MedicalTemplateRecoveryChoice($owner,$config,[string]$purpose='сохранение'){
 $recoveryProgramRoot=[string]$script:medicalProgramRoot
 [void](Initialize-MedicalTemplateFolder)
 $templates=@(Get-MedicalTemplates)
 $dialog=New-Object Windows.Forms.Form;$dialog.Text='Восстановить Word-шаблон';$dialog.Size=New-Object Drawing.Size(760,470)
 $dialog.StartPosition='CenterParent';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false
 $result=[pscustomobject]@{Schema=$null;Template=$null;Name=''}
 $hint=New-Object Windows.Forms.Label;$hint.SetBounds(20,20,700,82)
 $hint.Text='Связанный Word-шаблон не найден. Форма и введённые ответы сохранены. Выберите исходный DOCX / DOTX или файл .mcform этой формы: из него будет взят только Word-шаблон. После выбора можно продолжить '+$purpose+'.';$dialog.Controls.Add($hint)
 $list=New-Object Windows.Forms.ComboBox;$list.DropDownStyle='DropDownList';$list.SetBounds(20,116,700,30)
 foreach($item in $templates){[void]$list.Items.Add((Get-MedicalFormDisplayName $item.Name 'Шаблон Word'))}
 if($templates.Count){$list.SelectedIndex=0}else{[void]$list.Items.Add('В папке «Шаблоны» нет файлов');$list.SelectedIndex=0;$list.Enabled=$false};$dialog.Controls.Add($list)
 $select=New-Object Windows.Forms.Button;$select.Text='Выбрать из папки';$select.SetBounds(20,169,210,42);$select.Enabled=$templates.Count -gt 0;$dialog.Controls.Add($select)
 $browse=New-Object Windows.Forms.Button;$browse.Text='Выбрать Word / форму…';$browse.SetBounds(245,169,240,42);$dialog.Controls.Add($browse)
 $create=New-Object Windows.Forms.Button;$create.Text='Создать по структуре';$create.SetBounds(500,169,220,42);$dialog.Controls.Add($create)
 $help=New-Object Windows.Forms.Label;$help.SetBounds(20,233,700,98)
 $help.Text='Выбранный шаблон проверяется по маркерам и элементам Word текущей формы. Разделы, поля, ответы пациента, уточнения и дневники сохраняются. «Создать по структуре» создаёт новый документ с простым оформлением; оформление утраченного оригинала при этом восстановить нельзя.';$dialog.Controls.Add($help)
 $cancel=New-Object Windows.Forms.Button;$cancel.Text='Продолжить без шаблона';$cancel.SetBounds(435,360,285,36);$cancel.DialogResult='Cancel';$dialog.Controls.Add($cancel);$dialog.CancelButton=$cancel
 $recoveryCommands=@{}
 foreach($commandName in @('Import-MedicalRecoveryTemplate','Get-MedicalGeneratedSchema','New-MedicalTemplateFile','Get-MedicalFormDisplayName')){
  $recoveryCommands[$commandName]=Get-Command $commandName -CommandType Function -ErrorAction Stop
 }
 $select.Add_Click({
  if($list.SelectedIndex -lt 0 -or $list.SelectedIndex -ge $templates.Count){return}
  try{
   $choice=& $recoveryCommands['Import-MedicalRecoveryTemplate'] $config $templates[$list.SelectedIndex].Path
   $result.Schema=$choice.Schema;$result.Template=$choice.Template;$result.Name=& $recoveryCommands['Get-MedicalFormDisplayName'] $choice.Template.Name 'Шаблон Word'
   $dialog.DialogResult='OK';$dialog.Close()
  }catch{[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Выбор Word-шаблона')}
 }.GetNewClosure())
 $browse.Add_Click({
  $picker=New-Object Windows.Forms.OpenFileDialog;$picker.Filter='Word-шаблоны и формы|*.docx;*.dotx;*.mcform|Шаблоны Word|*.docx;*.dotx|Формы конструктора|*.mcform'
  $picker.Title='Выберите исходный Word-шаблон или сохранённую форму';$picker.InitialDirectory=$recoveryProgramRoot;$picker.CheckFileExists=$true;$picker.Multiselect=$false
  try{
   if($picker.ShowDialog($dialog) -ne 'OK'){return}
   $choice=& $recoveryCommands['Import-MedicalRecoveryTemplate'] $config $picker.FileName
   $result.Schema=$choice.Schema;$result.Template=$choice.Template;$result.Name=& $recoveryCommands['Get-MedicalFormDisplayName'] $choice.Template.Name 'Шаблон Word'
   $dialog.DialogResult='OK';$dialog.Close()
  }catch{[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Восстановление Word-шаблона')}
  finally{$picker.Dispose()}
 }.GetNewClosure())
 $create.Add_Click({
  try{
   $candidate=& $recoveryCommands['Get-MedicalGeneratedSchema'] $config
   $item=& $recoveryCommands['New-MedicalTemplateFile'] 'Восстановленный шаблон по структуре.docx' $candidate
   $candidate.Template=$item.RelativePath;$candidate.AutoTemplate=$false
   $candidate | Add-Member -NotePropertyName PreserveTemplateFormatting -NotePropertyValue $true -Force
   $result.Schema=$candidate;$result.Template=$item;$result.Name=& $recoveryCommands['Get-MedicalFormDisplayName'] $item.Name 'Шаблон Word'
   $dialog.DialogResult='OK';$dialog.Close()
  }catch{[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Создание Word-шаблона')}
 }.GetNewClosure())
 Set-DarkTheme $dialog
 try{if($dialog.ShowDialog($owner) -eq 'OK'){return $result};return $null}finally{$dialog.Dispose()}
}
function Set-MedicalRecoveredInitialTemplate($choice){
 if(-not $choice -or -not $choice.Schema -or -not $choice.Template){throw 'Не выбран Word-шаблон для восстановления.'}
 $candidate=Copy-MedicalFormSchema $choice.Schema
 $candidate.Template=$choice.Template.RelativePath;$candidate.AutoTemplate=$false
 Save-UniversalConfig $candidate
 $script:universalConfig=$candidate;$script:stageTemplates.initial=$choice.Template.Path
 if($script:stage -eq 'initial'){Open-UniversalInitial}
}
function Ensure-MedicalCurrentTemplate([string]$purpose='сохранение',[bool]$initialOnly=$false){
 if(-not $initialOnly -and $script:medicalClinicalForms -and $script:stage -ne 'initial'){return (Ensure-MedicalClinicalTemplate $purpose)}
 if($initialOnly -or $script:stage -eq 'initial'){
  if($script:universalConfig.AutoTemplate){return $true}
  $path=Get-UniversalTemplatePath
  if([IO.File]::Exists($path)){return $true}
  $relocated=Resolve-MedicalTemplateReference ([string]$script:universalConfig.Template) ([string]$script:caseFile)
  if($relocated){
   $script:universalConfig.Template=$relocated;$script:stageTemplates.initial=$relocated
   if($script:stage -eq 'initial'){$script:source=$relocated}
   return $true
  }
  Capture-Stage
  $choice=Show-MedicalTemplateRecoveryChoice $form $script:universalConfig $purpose
  if(-not $choice){return $false}
  Set-MedicalRecoveredInitialTemplate $choice
  return $true
 }
 $path=[string]$script:stageTemplates[$script:stage]
 if([IO.File]::Exists($path)){
  if($script:source -ne $path -or @($script:fields).Count -eq 0 -or @($script:controls).Count -eq 0){Open-Stage}
  $script:source=$path;return $true
 }
 $relocated=Resolve-MedicalTemplateReference $path ([string]$script:caseFile)
 if($relocated){$script:stageTemplates[$script:stage]=$relocated;Open-Stage;return $true}
 Capture-Stage
 $picker=New-Object Windows.Forms.OpenFileDialog;$picker.Filter='Шаблоны Word|*.docx;*.dotx';$picker.Title='Выберите исходный Word-шаблон текущего этапа';$picker.InitialDirectory=$script:medicalTemplatesFolder;$picker.CheckFileExists=$true
 try{
  if($picker.ShowDialog($form) -ne 'OK'){return $false}
  if($script:stageData.ContainsKey((Get-StageKey))){
   $text='Карта хранит ответы этого этапа по порядку полей. Используйте исходный шаблон этого дневника или эпикриза: в другом шаблоне ответы могут попасть в другие поля. Применить выбранный исходный шаблон?'
   if([Windows.Forms.MessageBox]::Show($form,$text,'Шаблон текущего этапа','YesNo','Question') -ne 'Yes'){return $false}
  }
  $item=Import-MedicalTemplate $picker.FileName
  $script:stageTemplates[$script:stage]=$item.Path
  Open-Stage
  return $true
 }finally{$picker.Dispose()}
}
function Use-MedicalFormSchema($config,[string]$name,[string]$path='',$stageForms=$null){
 $candidate=Copy-MedicalFormSchema $config
 $templatePath=Get-UniversalTemplatePath $candidate
 if(-not $candidate.AutoTemplate){Test-MedicalTemplateBytes ([IO.File]::ReadAllBytes($templatePath))}
 if($null -ne $stageForms){$stageForms=Resolve-MedicalClinicalPortableForms $stageForms}else{$stageForms=New-MedicalClinicalFormData $candidate}
 # Validate and persist the schema before clearing the current patient.
 Save-UniversalConfig $candidate
 Reset-NewPatientCase $candidate
 [void](Initialize-MedicalClinicalWorkspace $stageForms)
 $script:medicalActiveDiaryId='';$script:medicalClinicalBindings=@{};$script:medicalClinicalFlow=$null
 $script:stage='initial';$script:medicalWorkspaceReady=$true
 $script:activeMedicalFormName=Get-MedicalFormDisplayName $name;$script:activeMedicalFormPath=$path
 $script:medicalFormBaseline=Get-MedicalFormSignature $candidate
 foreach($button in @($stageInitial,$stageDiary,$stageDischarge)){$button.Enabled=$true}
 try{Open-Stage}catch{
  $script:medicalWorkspaceReady=$false
  foreach($button in @($stageInitial,$stageDiary,$stageDischarge)){$button.Enabled=$false}
  $save.Enabled=$false
  throw
 }
 if(Get-Command Reset-MedicalBackupSaveBaselines -CommandType Function -ErrorAction SilentlyContinue){Reset-MedicalBackupSaveBaselines ([bool]$path)}
 Request-MedicalClinicalCheckpoint
}
function Set-MedicalEditorSavedFormMetadata($result){
 if(-not $result -or -not $result.SavedFormPath){return}
 $script:activeMedicalFormPath=[string]$result.SavedFormPath;$script:activeMedicalFormName=[string]$result.SavedFormName
 if($result.SavedSnapshotMatches){
  $script:medicalFormBaseline=Get-MedicalFormSignature $script:universalConfig
  if(Get-Command Mark-MedicalFormSaved -CommandType Function -ErrorAction SilentlyContinue){Mark-MedicalFormSaved}
 }
 Request-MedicalClinicalCheckpoint
}

function Invoke-MedicalNewForm {
 try{
  $choice=Show-MedicalTemplateChoice $form (New-UniversalConfig) $true
  if(-not $choice){return}
  $result=Show-MedicalFormTemplateEditor $form $choice.Schema $null 'new'
  if(-not $result){return}
  if(-not (Confirm-MedicalFormReset)){return}
  $name=if($result.SavedFormName){$result.SavedFormName}else{$choice.Name}
  Use-MedicalFormSchema $result.Schema $name ([string]$result.SavedFormPath) $result.SavedStageForms
  Set-MedicalEditorSavedFormMetadata $result
 }catch{[void][Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,'Создание формы')}
}
function Invoke-MedicalOpenForm {
 $picker=New-Object Windows.Forms.OpenFileDialog;$picker.Filter='Формы конструктора|*.mcform';$picker.Title='Открыть форму';$picker.InitialDirectory=$script:medicalProgramRoot
 try{
  if($picker.ShowDialog($form) -ne 'OK'){return}
  $candidate=Read-MedicalForm $picker.FileName
  if(-not (Confirm-MedicalFormReset)){return}
  Use-MedicalFormSchema $candidate.Schema $candidate.Name $picker.FileName $candidate.StageForms
 }catch{[void][Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,'Открытие формы')}
 finally{$picker.Dispose()}
}
function Invoke-MedicalSaveForm {
 if(-not $script:medicalWorkspaceReady){Invoke-MedicalNewForm;return}
 try{if(-not (Ensure-MedicalCurrentTemplate 'сохранение формы' $true)){return}}
 catch{[void][Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,'Сохранение формы');return}
 $picker=New-Object Windows.Forms.SaveFileDialog;$picker.Filter='Форма конструктора|*.mcform';$picker.DefaultExt='mcform';$picker.AddExtension=$true;$picker.OverwritePrompt=$true;$picker.Title='Сохранить форму и связанный Word-шаблон'
 $picker.InitialDirectory=$script:medicalProgramRoot
 if($script:activeMedicalFormPath){
  if(Get-Command Get-MedicalPortableSaveDirectory -CommandType Function -ErrorAction SilentlyContinue){$picker.InitialDirectory=Get-MedicalPortableSaveDirectory ([string]$script:activeMedicalFormPath)}
  else{$previousFolder=[IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($script:activeMedicalFormPath));if([IO.Directory]::Exists($previousFolder)){$picker.InitialDirectory=$previousFolder}}
  $picker.FileName=[IO.Path]::GetFileName($script:activeMedicalFormPath)
 }else{
  $safeName=(Get-MedicalFormDisplayName $script:activeMedicalFormName) -replace '[\\/:*?"<>|]','_'
  $picker.FileName=$safeName+'.mcform'
 }
 try{
  if($picker.ShowDialog($form) -ne 'OK'){return}
  if([IO.Path]::GetExtension($picker.FileName) -ne '.mcform'){throw 'Сохраните форму в файле с расширением .mcform.'}
  [void](Write-MedicalForm $picker.FileName $script:universalConfig ([IO.Path]::GetFileNameWithoutExtension($picker.FileName)))
  $script:activeMedicalFormPath=$picker.FileName;$script:activeMedicalFormName=Get-MedicalFormDisplayName ([IO.Path]::GetFileNameWithoutExtension($picker.FileName))
  $script:medicalFormBaseline=Get-MedicalFormSignature $script:universalConfig
  if(Get-Command Mark-MedicalFormSaved -CommandType Function -ErrorAction SilentlyContinue){Mark-MedicalFormSaved}
  Request-MedicalClinicalCheckpoint
  [void][Windows.Forms.MessageBox]::Show($form,'Форма, структура всех дневников и эпикриза, а также их Word-шаблоны сохранены. Ответы пациента сохраняются в карте.','Форма сохранена')
 }catch{[void][Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,'Сохранение формы')}
 finally{$picker.Dispose()}
}
function Invoke-MedicalChooseTemplate {
 if(-not $script:medicalWorkspaceReady){Invoke-MedicalNewForm;return}
 try{
  Capture-Stage
  if($script:stage -ne 'initial'){
   $context=Get-MedicalActiveClinicalContext
   if(-not $context){Invoke-MedicalAddDiary;$context=Get-MedicalActiveClinicalContext}
   $choice=Show-MedicalTemplateChoice $form $context.Schema $false
   if(-not $choice){return}
   [void](Set-MedicalClinicalSchema $script:stage $context.Id $choice.Schema)
   Open-MedicalClinicalStage;Request-MedicalClinicalCheckpoint
   return
  }
  if($script:stage -eq 'initial' -and -not $script:universalConfig.AutoTemplate -and -not [IO.File]::Exists((Get-UniversalTemplatePath))){
   [void](Ensure-MedicalCurrentTemplate 'работу с шаблоном' $true);return
  }
  if($script:stage -ne 'initial' -and -not [IO.File]::Exists([string]$script:stageTemplates[$script:stage])){[void](Ensure-MedicalCurrentTemplate 'работу с шаблоном');return}
  $choice=Show-MedicalTemplateChoice $form $script:universalConfig ($script:stage -ne 'initial')
  if(-not $choice){return}
  if($script:stage -eq 'initial'){
   Set-MedicalRecoveredInitialTemplate $choice
  }else{
   if([Windows.Forms.MessageBox]::Show($form,'Заменить Word-шаблон текущего этапа? Поля этого этапа будут загружены заново; другие этапы сохранятся.','Шаблон этапа','YesNo','Question') -ne 'Yes'){return}
   [void]$script:stageData.Remove((Get-StageKey));$script:stageTemplates[$script:stage]=$choice.Template.Path;Open-Stage
  }
 }catch{[void][Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,'Шаблоны')}
}
function Invoke-MedicalFormTemplateEditor {
 try{
  if($script:medicalWorkspaceReady -and $script:stage -ne 'initial'){
   Capture-MedicalClinicalStage
   $context=Get-MedicalActiveClinicalContext
   if(-not $context){Invoke-MedicalAddDiary;$context=Get-MedicalActiveClinicalContext}
   if(-not (Ensure-MedicalClinicalTemplate 'редактирование формы и Word')){return}
   $context=Get-MedicalActiveClinicalContext
   $candidate=Copy-MedicalFormSchema $context.Schema
   if($candidate.AutoTemplate){$candidate=Get-MedicalGeneratedSchema $candidate}
   $result=Show-MedicalFormTemplateEditor $form $candidate
   if(-not $result){return}
   [void](Set-MedicalClinicalSchema $script:stage $context.Id $result.Schema)
   Open-MedicalClinicalStage;Set-MedicalEditorSavedFormMetadata $result;Request-MedicalClinicalCheckpoint
   return
  }
  if($script:medicalWorkspaceReady -and -not (Ensure-MedicalCurrentTemplate 'редактирование формы и Word' $true)){return}
  $candidate=if($script:medicalWorkspaceReady){Copy-MedicalFormSchema $script:universalConfig}else{New-UniversalConfig}
  if($candidate.AutoTemplate){$candidate=Get-MedicalGeneratedSchema $candidate}
  $purpose=if($script:medicalWorkspaceReady){'edit'}else{'new'}
  $result=Show-MedicalFormTemplateEditor $form $candidate $null $purpose
  if(-not $result){return}
  if($script:medicalWorkspaceReady){
   Capture-Stage
   Apply-UniversalSettingsDraft $result.Schema
  }else{
   $name=if($result.SavedFormName){$result.SavedFormName}else{[IO.Path]::GetFileNameWithoutExtension($result.Template.Name)}
   Use-MedicalFormSchema $result.Schema $name ([string]$result.SavedFormPath) $result.SavedStageForms
  }
  Set-MedicalEditorSavedFormMetadata $result
 }catch{[void][Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,'Форма и Word-шаблон')}
}
function Get-MedicalLocalForms([string]$folder=$script:medicalProgramRoot){
 if(-not [IO.Directory]::Exists($folder)){return @()}
 $items=@(foreach($path in [IO.Directory]::GetFiles($folder,'*.mcform',[IO.SearchOption]::TopDirectoryOnly)){
  [pscustomobject]@{Path=$path;Name=(Get-MedicalFormDisplayName ([IO.Path]::GetFileNameWithoutExtension($path)) 'Сохранённая форма')}
 })
 return @($items | Sort-Object Name,Path)
}
function Clear-MedicalFormsWorkspace {
 # Startup always begins with no selected form or patient, even if settings remain on disk.
 $script:medicalWorkspaceReady=$false
 $script:activeMedicalFormPath='';$script:activeMedicalFormName='Новая форма';$script:medicalFormBaseline=''
 Reset-NewPatientCase (New-UniversalConfig)
 foreach($button in @($stageInitial,$stageDiary,$stageDischarge)){$button.Enabled=$false}
 Remove-MedicalEndAction
 $script:universalFlow=$null;$script:universalCompletionLabel=$null;$script:universalIndicators=@{}
 $script:medicalClinicalBindings=@{};$script:medicalClinicalFlow=$null;$script:medicalActiveDiaryId=''
 Clear-MedicalWorkspacePanels;$save.Enabled=$false
 $panel.AutoScrollPosition=New-Object Drawing.Point(0,0)
 $panel.AutoScrollMinSize=New-Object Drawing.Size(0,0)
 $message=New-Object Windows.Forms.Label
 $message.Text='Откройте сохранённую форму или создайте новую. Формы сохраняются в папке программы; при открытии можно выбрать файл из другой папки.'
 $message.SetBounds(25,25,930,100);$message.Anchor='Top,Left,Right';$panel.Controls.Add($message)
 Set-DarkTheme $panel
 if($script:uiMedicalFormStatus){$script:uiMedicalFormStatus.Text='Форма не открыта'}
}
function Test-MedicalWorkspaceReady {return [bool]$script:medicalWorkspaceReady}
function Show-MedicalFormStartupChoice($owner){
 $forms=@(Get-MedicalLocalForms)
 $dialog=New-Object Windows.Forms.Form;$dialog.Text='Выберите форму';$dialog.Size=New-Object Drawing.Size(720,380)
 $dialog.StartPosition='CenterParent';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false
 $hint=New-Object Windows.Forms.Label;$hint.SetBounds(20,20,660,68)
 $hint.Text='Для нового осмотра выберите сохранённую форму или создайте новую. Ответы пациента заполняются с нуля. Форма и связанный Word-шаблон хранятся вместе в файле .mcform.';$dialog.Controls.Add($hint)
 $localLabel=New-Object Windows.Forms.Label;$localLabel.SetBounds(20,93,660,26);$localLabel.Text='Сохранённые формы в папке программы';$dialog.Controls.Add($localLabel)
 $list=New-Object Windows.Forms.ComboBox;$list.DropDownStyle='DropDownList';$list.SetBounds(20,123,660,30)
 foreach($item in $forms){[void]$list.Items.Add($item.Name)}
 if($forms.Count){$list.SelectedIndex=0}else{[void]$list.Items.Add('Сохранённых форм пока нет');$list.SelectedIndex=0;$list.Enabled=$false}
 $dialog.Controls.Add($list)
 $open=New-Object Windows.Forms.Button;$open.Text='Открыть выбранную';$open.SetBounds(20,174,205,42);$open.Enabled=$forms.Count -gt 0;$dialog.Controls.Add($open)
 $browse=New-Object Windows.Forms.Button;$browse.Text='Выбрать файл…';$browse.SetBounds(235,174,205,42);$dialog.Controls.Add($browse)
 $create=New-Object Windows.Forms.Button;$create.Text='Создать новую форму';$create.SetBounds(450,174,230,42);$dialog.Controls.Add($create)
 $help=New-Object Windows.Forms.Label;$help.SetBounds(20,237,660,42);$help.Text='«Выбрать файл» открывает .mcform из любой папки. При создании новой формы можно загрузить свой Word-шаблон.';$dialog.Controls.Add($help)
 $cancel=New-Object Windows.Forms.Button;$cancel.Text='Позже';$cancel.SetBounds(480,294,200,36);$cancel.DialogResult='Cancel';$dialog.Controls.Add($cancel);$dialog.CancelButton=$cancel
 $startupCommands=@{}
 foreach($commandName in @('Read-MedicalForm','Use-MedicalFormSchema','Invoke-MedicalOpenForm','Invoke-MedicalNewForm','Test-MedicalWorkspaceReady')){
  $startupCommands[$commandName]=Get-Command $commandName -CommandType Function -ErrorAction Stop
 }
 $open.Add_Click({
  if($list.SelectedIndex -lt 0 -or $list.SelectedIndex -ge $forms.Count){return}
  try{
   $path=$forms[$list.SelectedIndex].Path
   $candidate=& $startupCommands['Read-MedicalForm'] $path
   & $startupCommands['Use-MedicalFormSchema'] $candidate.Schema $candidate.Name $path $candidate.StageForms
   if((& $startupCommands['Test-MedicalWorkspaceReady'])){$dialog.DialogResult='OK';$dialog.Close()}
  }catch{[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Открытие формы')}
 }.GetNewClosure())
 $browse.Add_Click({
  & $startupCommands['Invoke-MedicalOpenForm']
  if((& $startupCommands['Test-MedicalWorkspaceReady'])){$dialog.DialogResult='OK';$dialog.Close()}
 }.GetNewClosure())
 $create.Add_Click({
  & $startupCommands['Invoke-MedicalNewForm']
  if((& $startupCommands['Test-MedicalWorkspaceReady'])){$dialog.DialogResult='OK';$dialog.Close()}
 }.GetNewClosure())
 Set-DarkTheme $dialog
 try{[void]$dialog.ShowDialog($owner);return [bool]$script:medicalWorkspaceReady}finally{$dialog.Dispose()}
}
function Start-MedicalFormsWorkspace {
 Clear-MedicalFormsWorkspace
 try{
  [void](Initialize-MedicalTemplateFolder)
  [void](Show-MedicalFormStartupChoice $form)
 }catch{[void][Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,'Выбор формы')}
}
function Remove-MedicalEndAction {
 if($caseSave -and $caseSave.Parent){$caseSave.Parent.Controls.Remove($caseSave)}
 if($script:medicalEndActionHost -and -not $script:medicalEndActionHost.IsDisposed){
  if($script:medicalEndActionHost.Parent){$script:medicalEndActionHost.Parent.Controls.Remove($script:medicalEndActionHost)}
  $script:medicalEndActionHost.Dispose();$script:medicalEndActionHost=$null
 }
}
function Add-MedicalEndAction {
 # v72: every global command lives in the top menu, including Save Card.
 if($form -and $form.MainMenuStrip){return}
 if(-not $caseSave -or -not $panel -or -not $script:medicalWorkspaceReady){return}
 Remove-MedicalEndAction
 $hostPanel=New-Object Windows.Forms.FlowLayoutPanel;$hostPanel.AutoSize=$true;$hostPanel.FlowDirection='TopDown';$hostPanel.WrapContents=$false
 $hostPanel.Padding=New-Object Windows.Forms.Padding(10);$hostPanel.Margin=New-Object Windows.Forms.Padding(0,20,0,12)
 $hint=New-Object Windows.Forms.Label;$hint.Text='Карта сохранит ответы пациента и все этапы госпитализации.';$hint.AutoSize=$true;$hostPanel.Controls.Add($hint)
 $caseSave.Width=260;$caseSave.Height=44;$caseSave.Dock='None';$caseSave.Anchor='Top,Left';$caseSave.Margin=New-Object Windows.Forms.Padding(0,10,0,0);$hostPanel.Controls.Add($caseSave)
 if($script:stage -eq 'initial' -and $script:universalFlow -and $panel.Controls.Contains($script:universalFlow)){
  $hostPanel.Dock='Top';$script:universalFlow.Controls.Add($hostPanel)
 }elseif($script:stage -ne 'initial' -and $script:medicalClinicalFlow -and $panel.Controls.Contains($script:medicalClinicalFlow)){
  $hostPanel.Dock='Top';$script:medicalClinicalFlow.Controls.Add($hostPanel)
 }else{
  $bottom=0;foreach($control in $panel.Controls){$bottom=[Math]::Max($bottom,$control.Bottom)}
  $hostPanel.SetBounds(25,($bottom+20),[Math]::Max(600,($panel.ClientSize.Width-55)),90);$hostPanel.Anchor='Top,Left,Right';$panel.Controls.Add($hostPanel)
  $panel.AutoScrollMinSize=New-Object Drawing.Size(0,($bottom+$hostPanel.Height+50))
 }
 $script:medicalEndActionHost=$hostPanel
 Set-DarkTheme $hostPanel
}

function Invoke-MedicalRestoreEditorDraft {
 if(-not (Get-Command Get-MedicalRecoveredEditorDraft -CommandType Function -ErrorAction SilentlyContinue)){return}
 try{
  $recovery=Get-MedicalRecoveredEditorDraft
  if(-not $recovery){return}
  $targetStage=if($recovery.Stage -in @('initial','diary','discharge')){[string]$recovery.Stage}else{[string]$script:stage}
  $targetId=if($recovery.ClinicalId){[string]$recovery.ClinicalId}else{[string]$script:medicalActiveDiaryId}
  Capture-Stage
  $purpose=if($recovery.Purpose -eq 'new'){'new'}else{'edit'}
  if($purpose -eq 'new'){$candidate=$recovery.Schema}
  elseif($targetStage -eq 'initial'){$candidate=$script:universalConfig}
  else{$candidate=(Get-MedicalClinicalContext $targetStage $targetId).Schema}
  $saveContext=New-MedicalEditorSaveContext $candidate $purpose $targetStage $targetId
  $result=Show-MedicalFormTemplateEditor $form $candidate $recovery $purpose $saveContext
  if(-not $result){return}
  if($purpose -eq 'new'){
   if(-not (Confirm-MedicalFormReset)){return}
   $name=if($result.Template -and $result.Template.Name){[IO.Path]::GetFileNameWithoutExtension([string]$result.Template.Name)}else{'Новая форма'}
   if($result.SavedFormName){$name=$result.SavedFormName}
   Use-MedicalFormSchema $result.Schema $name ([string]$result.SavedFormPath) $result.SavedStageForms
  }elseif($targetStage -eq 'initial'){Apply-UniversalSettingsDraft $result.Schema}
  else{
   [void](Set-MedicalClinicalSchema $targetStage $targetId $result.Schema)
   $script:stage=$targetStage
   if($targetStage -eq 'diary'){$script:medicalActiveDiaryId=$targetId}
   Open-MedicalClinicalStage
  }
  Set-MedicalEditorSavedFormMetadata $result
  $script:medicalEditorRecoveryDraft=$null;$script:medicalBackupRetainedDraft=$null
  Request-MedicalClinicalCheckpoint
 }catch{[void][Windows.Forms.MessageBox]::Show($form,'Незавершённый редактор не применён. Резервная копия сохранена: '+$_.Exception.Message,'Восстановление формы и Word')}
}
