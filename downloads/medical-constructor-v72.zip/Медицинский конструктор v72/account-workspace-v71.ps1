﻿# Account-specific working files. Exported documents remain ordinary Word files;
# Windows permissions are required to protect them outside this application.
function Assert-MedicalActiveAccount([bool]$AllowLocked=$false){
 if(-not $script:medicalAccountsContext){return $null}
 if(-not $script:medicalAuthSession){throw 'Выполните вход в программу.'}
 if($script:medicalAccountLocked -and -not $AllowLocked){throw 'Рабочее окно заблокировано. Введите пароль для продолжения.'}
 return (Assert-MedicalAccountSession $script:medicalAuthSession)
}
function Test-MedicalAccountPathInside([string]$Path,[string]$Root){
 $full=[IO.Path]::GetFullPath($Path);$base=[IO.Path]::GetFullPath($Root).TrimEnd([char[]]@('\','/'))
 return ($full.Equals($base,[StringComparison]::OrdinalIgnoreCase) -or $full.StartsWith($base+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase))
}
function Assert-MedicalAccountPath([string]$Path,[bool]$Backup=$false){
 if(-not $script:medicalAccountsContext){return}
 if(-not $script:medicalAuthSession -or -not $script:medicalAccountWorkspace){throw 'Рабочая папка учетной записи не открыта.'}
 if(-not $Backup -and -not $script:medicalBackupBusy){$null=Assert-MedicalActiveAccount}
 # Background checkpoints can preserve the already authenticated session even
 # after its password is reset. They never choose another account's destination.
 $full=[IO.Path]::GetFullPath($Path);$workspace=$script:medicalAccountWorkspace
 if($Backup -and -not (Test-MedicalAccountPathInside $full $workspace.DataRoot)){throw 'Резервная копия должна находиться в рабочей папке текущего пользователя.'}
 $accountsRoot=Join-Path $script:medicalInstallationRoot 'Учетные записи'
 if(Test-MedicalAccountPathInside $full $accountsRoot){throw 'Файлы учетных записей нельзя открывать или заменять как документы.'}
 $usersRoot=Join-Path $script:medicalInstallationRoot 'Данные'
 if((Test-MedicalAccountPathInside $full $usersRoot) -and -not (Test-MedicalAccountPathInside $full $workspace.DataRoot)){
  throw 'Выберите файл из своей рабочей папки. Данные сотрудников разделены.'
 }
 # A junction inside the managed tree must not redirect one profile to another.
 if(Test-MedicalAccountPathInside $full $usersRoot){Assert-MedicalAccountManagedPath $full $script:medicalInstallationRoot}
}
function Assert-MedicalAccountManagedPath([string]$Path,[string]$Root){
 $cursor=[IO.Path]::GetFullPath($Path);$base=[IO.Path]::GetFullPath($Root)
 if(-not (Test-MedicalAccountPathInside $cursor $base)){throw 'Неверная рабочая папка.'}
 while($cursor -and (Test-MedicalAccountPathInside $cursor $base)){
  $attributes=$null
  try{$attributes=[IO.File]::GetAttributes($cursor)}catch [IO.FileNotFoundException]{}catch [IO.DirectoryNotFoundException]{}
  if($null -ne $attributes -and ($attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Рабочая папка не должна содержать перенаправления.'}
  if($cursor.Equals($base,[StringComparison]::OrdinalIgnoreCase)){break};$cursor=[IO.Path]::GetDirectoryName($cursor)
 }
}
function Initialize-MedicalAccountWorkspace($Session,[string]$InstallationRoot){
 $Session=Assert-MedicalAccountSession $Session
 $root=[IO.Path]::GetFullPath($InstallationRoot)
 if(-not $root.Equals([IO.Path]::GetFullPath($Session.Context.Root),[StringComparison]::OrdinalIgnoreCase)){throw 'Учетная запись относится к другой папке программы.'}
 $expected=Join-Path (Join-Path $root 'Данные') ([string]$Session.UserId)
 if(-not ([IO.Path]::GetFullPath($Session.DataRoot)).Equals([IO.Path]::GetFullPath($expected),[StringComparison]::OrdinalIgnoreCase)){throw 'Неверная рабочая папка учетной записи.'}
 # Check existing ancestors before creating anything, including a redirected
 # users directory left by another process or an older installation.
 Assert-MedicalAccountManagedPath $expected $root
 [void][IO.Directory]::CreateDirectory($expected)
 Assert-MedicalAccountManagedPath $expected $root
 foreach($name in @('.session.lock','Карты','Шаблоны','Резервные копии','template.dotx','Универсальный первичный осмотр.docx','Шаблон первичного осмотра.docx','diagnosis-templates.json','document-font.json','form-settings.json','patients.json','appearance.json')){
  Assert-MedicalAccountManagedPath (Join-Path $expected $name) $root
 }
 $lease=$null
 try{
  try{$lease=[IO.File]::Open((Join-Path $expected '.session.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}catch [IO.IOException]{throw 'Эта учетная запись уже открыта в другом экземпляре программы.'}
  foreach($folder in @('Карты','Шаблоны','Резервные копии')){[void][IO.Directory]::CreateDirectory((Join-Path $expected $folder))}
  # Seed only shipped reusable resources; never migrate earlier patient data.
  foreach($name in @('template.dotx','Универсальный первичный осмотр.docx','Шаблон первичного осмотра.docx','diagnosis-templates.json','document-font.json')){
   $source=Join-Path $root $name;$target=Join-Path $expected $name
   if([IO.File]::Exists($source) -and -not [IO.File]::Exists($target)){[IO.File]::Copy($source,$target,$false)}
  }
  $workspace=[pscustomobject]@{InstallationRoot=$root;DataRoot=$expected;CardsRoot=(Join-Path $expected 'Карты');Lease=$lease;UserId=$Session.UserId}
  $script:medicalInstallationRoot=$root;$script:medicalAccountWorkspace=$workspace;$script:medicalAuthSession=$Session
  $script:medicalProgramRoot=$expected;$script:medicalTemplatesFolder=Join-Path $expected 'Шаблоны'
  $script:universalConfigPath=Join-Path $expected 'form-settings.json';$script:profileFile=Join-Path $expected 'diagnosis-templates.json'
  $script:fontFile=Join-Path $expected 'document-font.json';$script:uiSettingsPath=Join-Path $expected 'appearance.json';$script:dbFile=Join-Path $expected 'patients.json'
  $script:medicalBackupPath='';$script:medicalAccountLocked=$false;$script:medicalAuthClosingLocked=$false
  return $workspace
 }catch{if($lease){$lease.Dispose()};throw}
}
function Close-MedicalAccountWorkspace {
 if($script:medicalAccountWorkspace -and $script:medicalAccountWorkspace.Lease){$script:medicalAccountWorkspace.Lease.Dispose();$script:medicalAccountWorkspace.Lease=$null}
 if($script:medicalAuthSession){Close-MedicalSession $script:medicalAuthSession}
 $script:medicalAuthSession=$null
}
function Get-MedicalAccountCardsDirectory {
 if($script:medicalAccountsContext){$null=Assert-MedicalActiveAccount;return $script:medicalAccountWorkspace.CardsRoot}
 return ''
}
function Test-MedicalAccountLockedClose {return [bool]$script:medicalAuthClosingLocked}
function Initialize-MedicalAccountActivityType {
 if('MedicalAccountActivityV71' -as [type]){return}
 Add-Type -ReferencedAssemblies 'System.Windows.Forms' -TypeDefinition @'
using System;
using System.Diagnostics;
using System.Windows.Forms;
public sealed class MedicalAccountActivityV71 : IMessageFilter {
 private long last=Stopwatch.GetTimestamp();
 public double IdleSeconds {get{return (Stopwatch.GetTimestamp()-last)/(double)Stopwatch.Frequency;}}
 public void Reset(){last=Stopwatch.GetTimestamp();}
 public bool PreFilterMessage(ref Message message){
  int code=message.Msg;
  if((code>=0x100&&code<=0x109)||(code>=0x200&&code<=0x20E))Reset();
  return false;
 }
}
'@
}
function Invoke-MedicalAccountLock($Owner){
 if($script:medicalAccountLocked -or -not $script:medicalAuthSession){return}
 $script:medicalAccountLocked=$true;$saved=New-Object Collections.ArrayList
 $templateWasRunning=$script:templateTimer -and $script:templateTimer.Enabled
 if($script:templateTimer){$script:templateTimer.Stop()}
 try{
  # Opacity preserves modal editor loops, unlike Hide/Close. Disable every
  # existing application window so keyboard switching cannot bypass the lock.
  foreach($window in @([Windows.Forms.Application]::OpenForms)){
   if($window.IsDisposed){continue}
   [void]$saved.Add([pscustomobject]@{Form=$window;Opacity=$window.Opacity;Enabled=$window.Enabled})
   $window.Opacity=0;$window.Enabled=$false
  }
  while($true){
   $next=$null
   try{$next=Show-MedicalLockScreen $Owner $script:medicalAuthSession}catch{
    [void][Windows.Forms.MessageBox]::Show('Окно входа недоступно. Рабочие данные останутся скрыты; программа будет закрыта с попыткой резервного сохранения.','Блокировка','OK','Warning')
   }
   if($next){
    try{
     $null=Assert-MedicalAccountSession $next
     if($next.UserId -cne $script:medicalAccountWorkspace.UserId){throw 'Для продолжения требуется текущая учетная запись.'}
    }catch{Close-MedicalSession $next;continue}
    Close-MedicalSession $script:medicalAuthSession;$script:medicalAuthSession=$next;$script:medicalAccountLocked=$false
    break
   }
   # Exit from the lock screen leaves a private checkpoint without opening
   # dialogs containing document paths or patient data.
   try{if($script:medicalWorkspaceReady -or $script:medicalBackupEditorDraft -or $script:medicalBackupRetainedDraft){$null=Write-MedicalSessionBackup}}catch{
    $choice=[Windows.Forms.MessageBox]::Show('Обновить резервную копию не удалось. Закрыть программу без сохранения последних изменений?','Закрытие программы','YesNo','Warning')
    if($choice -ne 'Yes'){continue}
   }
   $script:medicalAuthClosingLocked=$true
   if($script:medicalBackupEditorDraft -and $script:medicalBackupEditorDraft.State){$script:medicalBackupEditorDraft.State.AccountClose=$true}
   foreach($entry in $saved){if($entry.Form -ne $Owner -and -not $entry.Form.IsDisposed){$entry.Form.Close()}}
   $Owner.Close()
   break
  }
 }finally{
  if(-not $script:medicalAuthClosingLocked -and -not $script:medicalAccountLocked){
   foreach($entry in $saved){if(-not $entry.Form.IsDisposed){$entry.Form.Opacity=$entry.Opacity;$entry.Form.Enabled=$entry.Enabled}}
   if($script:medicalAccountActivity){$script:medicalAccountActivity.Reset()}
   if($templateWasRunning -and $script:templateTimer){$script:templateTimer.Start()}
  }
 }
}
function Invoke-MedicalAccountActivityTick($Owner){
 if($script:medicalAccountLocked -or $Owner.IsDisposed){return}
 if($script:medicalAccountActivity.IdleSeconds -ge 600 -or -not (Test-MedicalSession $script:medicalAuthSession)){Invoke-MedicalAccountLock $Owner}
}
function Invoke-MedicalPasswordChangeAction($Owner){
 try{$null=Assert-MedicalActiveAccount;$null=Show-MedicalPasswordChange $Owner $script:medicalAuthSession}catch{[void][Windows.Forms.MessageBox]::Show('Не удалось изменить пароль. Проверьте учетную запись.','Учетная запись')}
}
function Invoke-MedicalAccountsManagerAction($Owner){
 try{$null=Assert-MedicalActiveAccount;Show-MedicalAccountManager $Owner $script:medicalAuthSession}catch{[void][Windows.Forms.MessageBox]::Show('Управление учетными записями недоступно.','Учетные записи')}
}
function Start-MedicalAccountActivity($Owner){
 Initialize-MedicalAccountActivityType
 $script:medicalAccountActivity=New-Object MedicalAccountActivityV71
 [Windows.Forms.Application]::AddMessageFilter($script:medicalAccountActivity)
 $script:medicalAccountTimer=New-Object Windows.Forms.Timer;$script:medicalAccountTimer.Interval=15000
 $lockCommand=Get-Command Invoke-MedicalAccountLock -CommandType Function -ErrorAction Stop
 $tickCommand=Get-Command Invoke-MedicalAccountActivityTick -CommandType Function -ErrorAction Stop
 $script:medicalAccountTimer.Add_Tick({& $tickCommand $Owner}.GetNewClosure())
 $script:medicalAccountTimer.Start()
}
function Stop-MedicalAccountActivity {
 if($script:medicalAccountTimer){$script:medicalAccountTimer.Stop();$script:medicalAccountTimer.Dispose();$script:medicalAccountTimer=$null}
 if($script:medicalAccountActivity){[Windows.Forms.Application]::RemoveMessageFilter($script:medicalAccountActivity);$script:medicalAccountActivity=$null}
}
function Add-MedicalAccountControls($Owner,$Sidebar){
 Add-MedicalSidebarHeading $Sidebar 'УЧЕТНАЯ ЗАПИСЬ'
 $name=New-Object Windows.Forms.Label;$name.Text=$script:medicalAuthSession.DisplayName;$name.Width=190;$name.Height=38;$name.AutoEllipsis=$true;$name.UseMnemonic=$false;$Sidebar.Controls.Add($name)
 $password=New-Object Windows.Forms.Button;$password.Text='Изменить пароль';Move-MedicalSidebarButton $Sidebar $password
 $passwordCommand=Get-Command Invoke-MedicalPasswordChangeAction -CommandType Function -ErrorAction Stop
 $password.Add_Click({& $passwordCommand $Owner}.GetNewClosure())
 if($script:medicalAuthSession.Role -ceq 'Administrator'){
  $accounts=New-Object Windows.Forms.Button;$accounts.Text='Управление сотрудниками';Move-MedicalSidebarButton $Sidebar $accounts
  $manager=Get-Command Invoke-MedicalAccountsManagerAction -CommandType Function -ErrorAction Stop
  $accounts.Add_Click({& $manager $Owner}.GetNewClosure())
 }
 $lock=New-Object Windows.Forms.Button;$lock.Text='Заблокировать';Move-MedicalSidebarButton $Sidebar $lock
 $lockCommand=Get-Command Invoke-MedicalAccountLock -CommandType Function -ErrorAction Stop
 $lock.Add_Click({& $lockCommand $Owner}.GetNewClosure())
}
