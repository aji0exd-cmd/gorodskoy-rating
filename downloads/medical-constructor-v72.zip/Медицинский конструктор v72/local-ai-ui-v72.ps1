﻿# v72: local model UI. Requests stay in memory; changes require an explicit review.
function Get-MedicalAiEditableTarget($Owner,$Target=$null){
 if($null -ne $Target){$control=$Target}else{$control=$Owner}
 for($depth=0;$depth -lt 24 -and $control;$depth++){
  if($control -is [Windows.Forms.TextBoxBase]){if(-not $control.IsDisposed -and $control.Enabled -and -not $control.ReadOnly){return $control};return $null}
  if($control.PSObject.Properties['ActiveControl'] -and $control.ActiveControl){$control=$control.ActiveControl}else{break}
 }
 return $null
}
function New-MedicalAiTextSnapshot($Target){
 if($null -eq $Target -or $Target.IsDisposed -or $Target.ReadOnly -or -not $Target.Enabled){return $null}
 $start=[int]$Target.SelectionStart;$length=[int]$Target.SelectionLength;$text=[string]$Target.Text
 if($start -lt 0 -or $length -lt 0 -or $start+$length -gt $text.Length){throw 'Выделение текста изменилось.'}
 return [pscustomobject]@{Target=$Target;OriginalText=$text;Start=$(if($length -gt 0){$start}else{0});Length=$(if($length -gt 0){$length}else{$text.Length});Input=$(if($length -gt 0){$text.Substring($start,$length)}else{$text})}
}
function Apply-MedicalAiTextResult($Snapshot,[string]$Text){
 if(-not $Snapshot -or -not $Snapshot.Target){throw 'Нет поля для замены. Скопируйте результат отдельной кнопкой.'}
 $target=$Snapshot.Target
 if($target.IsDisposed -or $target.ReadOnly -or -not $target.Enabled){throw 'Исходное поле уже недоступно. Результат не применён.'}
 if([string]$target.Text -cne [string]$Snapshot.OriginalText){throw 'Исходный текст изменился. Проверьте его и запустите помощника заново.'}
 if([string]::IsNullOrWhiteSpace($Text)){throw 'Пустой ответ не применяется.'}
 if($Snapshot.Start -lt 0 -or $Snapshot.Length -lt 0 -or $Snapshot.Start+$Snapshot.Length -gt $target.Text.Length){throw 'Выделение текста больше не существует.'}
 $beforeTokens=@([regex]::Matches([string]$Snapshot.Input,'\{\{[A-Z][A-Z0-9_]*\}\}')|ForEach-Object {$_.Value}|Sort-Object)
 $afterTokens=@([regex]::Matches($Text,'\{\{[A-Z][A-Z0-9_]*\}\}')|ForEach-Object {$_.Value}|Sort-Object)
 if(($beforeTokens -join '|') -cne ($afterTokens -join '|')){throw 'ИИ изменил маркеры шаблона. Применение отменено; исправьте результат вручную.'}
 $target.Select([int]$Snapshot.Start,[int]$Snapshot.Length);$target.SelectedText=$Text
 return $true
}
function New-MedicalAiUiJob {
 param([string]$AppRoot,[string]$ProfileRoot,[ValidateSet('Text','Markers')][string]$Task,[string]$InputText,$Paragraphs=$null,$Schema=$null,[string]$Instruction='',[ValidateRange(1,300)][int]$TimeoutSeconds=120)
 $backend=Join-Path $AppRoot 'local-ai-v72.ps1'
 if(-not [IO.File]::Exists($backend)){throw 'Модуль локального ИИ не найден.'}
 $cancel=New-Object Threading.CancellationTokenSource;$cancel.CancelAfter($TimeoutSeconds*1000)
 $runtimeRegistry=[hashtable]::Synchronized(@{})
 $runspace=[runspacefactory]::CreateRunspace();$runspace.ApartmentState='MTA';$runspace.Open()
 $powershell=[powershell]::Create();$powershell.Runspace=$runspace
 $worker={param($backend,$appRoot,$profileRoot,$task,$inputText,$paragraphs,$schema,$instruction,$cancellationToken,$timeoutSeconds,$runtimeRegistry)
  $ErrorActionPreference='Stop'
  . $backend
  $script:medicalLocalAiRuntimeRegistry=$runtimeRegistry
  Initialize-MedicalLocalAi -AppRoot $appRoot -ProfileRoot $profileRoot -RuntimeRegistry $runtimeRegistry | Out-Null
  try{
   if($task -eq 'Markers'){. (Join-Path $appRoot 'local-ai-ui-v72.ps1');Invoke-MedicalAiMarkerBatches -Paragraphs $paragraphs -Schema $schema -CancellationToken $cancellationToken -TimeoutSeconds $timeoutSeconds}
   else{Invoke-MedicalLocalAi -Task $task -Input $inputText -Paragraphs $paragraphs -Schema $schema -Instruction $instruction -CancellationToken $cancellationToken -TimeoutSeconds $timeoutSeconds}
  }finally{Stop-MedicalLocalAiRuntime}
 }
 try{
  [void]$powershell.AddScript($worker.ToString()).AddArgument($backend).AddArgument($AppRoot).AddArgument($ProfileRoot).AddArgument($Task).AddArgument($InputText).AddArgument($Paragraphs).AddArgument($Schema).AddArgument($Instruction).AddArgument($cancel.Token).AddArgument($TimeoutSeconds).AddArgument($runtimeRegistry)
  $handle=$powershell.BeginInvoke()
  return [pscustomobject]@{PowerShell=$powershell;Runspace=$runspace;Cancellation=$cancel;Handle=$handle;RuntimeRegistry=$runtimeRegistry;CancelAt=$null;StopHandle=$null;Disposed=$false}
 }catch{$powershell.Dispose();$runspace.Dispose();$cancel.Dispose();throw}
}
function Request-MedicalAiUiCancellation($Job){
 if(-not $Job -or $Job.Disposed){return}
 if($null -eq $Job.CancelAt){$Job.CancelAt=[DateTime]::UtcNow;$Job.Cancellation.Cancel()}
}
function Complete-MedicalAiUiJob($Job){
 if(-not $Job -or $Job.Disposed){throw 'Задание ИИ уже завершено.'}
 if(-not $Job.Handle.IsCompleted){
  if($null -ne $Job.CancelAt -and ([DateTime]::UtcNow-$Job.CancelAt).TotalSeconds -ge 5 -and -not $Job.StopHandle){$Job.StopHandle=$Job.PowerShell.BeginStop($null,$null)}
  return $null
 }
 $timedOut=$Job.Cancellation.IsCancellationRequested -and $null -eq $Job.CancelAt
 try{
  $output=@($Job.PowerShell.EndInvoke($Job.Handle))
  if($null -ne $Job.CancelAt){return [pscustomobject]@{Success=$false;Error='Операция отменена.';Cancelled=$true}}
  if($timedOut){return [pscustomobject]@{Success=$false;Error='Истекло время локального анализа. Выберите меньший фрагмент и повторите.';Cancelled=$false}}
  $result=@($output|Where-Object {$_.PSObject.Properties['Success']})|Select-Object -Last 1
  if(-not $result){return [pscustomobject]@{Success=$false;Error='Локальный ИИ не вернул результат.';Cancelled=$false}}
  return $result
 }catch{return [pscustomobject]@{Success=$false;Error=$(if($null -ne $Job.CancelAt){'Операция отменена.'}elseif($timedOut){'Истекло время локального анализа. Выберите меньший фрагмент и повторите.'}else{'Не удалось выполнить запрос локального ИИ.'});Cancelled=($null -ne $Job.CancelAt)}}
 finally{if($Job.StopHandle){try{$Job.PowerShell.EndStop($Job.StopHandle)}catch{}};$Job.PowerShell.Dispose();$Job.Runspace.Dispose();$Job.Cancellation.Dispose();$Job.Disposed=$true}
}
function Stop-MedicalAiUiJob($Job){
 if(-not $Job -or $Job.Disposed){return}
 Request-MedicalAiUiCancellation $Job
 # Cancellation aborts local HTTP; a stopped PowerShell pipeline still executes worker finally.
 if(-not $Job.Handle.IsCompleted){[void]$Job.Handle.AsyncWaitHandle.WaitOne(1000)}
 if(-not $Job.Handle.IsCompleted -and -not $Job.StopHandle){try{$Job.StopHandle=$Job.PowerShell.BeginStop($null,$null)}catch{}}
 if(-not $Job.Handle.IsCompleted){[void]$Job.Handle.AsyncWaitHandle.WaitOne(6000)}
 if(-not $Job.Handle.IsCompleted -and $Job.RuntimeRegistry -and $Job.RuntimeRegistry.ContainsKey('Owned')){
  # The registry contains only a process created by this exact worker. Check identity again.
  $owned=$Job.RuntimeRegistry['Owned']
  try{
   $process=$owned.Process
   if($process -and -not $process.HasExited -and $process.Id -eq $owned.Id -and $process.StartTime.ToUniversalTime().Ticks -eq $owned.StartTicks -and [string]$process.MainModule.FileName -ieq [string]$owned.Path){$process.Kill();[void]$process.WaitForExit(2000)}
  }catch{}finally{if($owned -and $owned.PSObject.Properties['Key']){$owned.Key=''};if($owned -is [Collections.IDictionary] -and $owned.Contains('Key')){$owned['Key']=''};$Job.RuntimeRegistry['Owned']=$null}
 }
 if($Job.Handle.IsCompleted){[void](Complete-MedicalAiUiJob $Job);return}
 try{$Job.PowerShell.Dispose()}finally{$Job.Runspace.Dispose();$Job.Cancellation.Dispose();$Job.Disposed=$true}
}
function Show-MedicalAiProgress {
 param($Owner,[ValidateSet('Text','Markers')][string]$Task,[string]$InputText,$Paragraphs=$null,$Schema=$null,[string]$Instruction='')
 $commands=@{};foreach($name in @('Get-MedicalLocalAiStatus','New-MedicalAiUiJob','Complete-MedicalAiUiJob','Request-MedicalAiUiCancellation','Stop-MedicalAiUiJob')){$commands[$name]=Get-Command $name -CommandType Function -ErrorAction Stop}
 $context=& $commands['Get-MedicalLocalAiStatus']
 $job=& $commands['New-MedicalAiUiJob'] -AppRoot $context.AppRoot -ProfileRoot $context.ProfileRoot -Task $Task -InputText $InputText -Paragraphs $Paragraphs -Schema $Schema -Instruction $Instruction
 $dialog=$null;$timer=$null
 try{
 $dialog=New-Object Windows.Forms.Form;$dialog.Text='Локальный ИИ';$dialog.StartPosition='CenterParent';$dialog.AutoScaleMode='Font';$dialog.ClientSize=New-Object Drawing.Size(510,160);$dialog.FormBorderStyle='FixedDialog';$dialog.ControlBox=$true;$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false;$dialog.Font=New-Object Drawing.Font('Segoe UI',10)
 $label=New-Object Windows.Forms.Label;$label.Dock='Top';$label.Height=80;$label.Padding=New-Object Windows.Forms.Padding(14);$label.Text='Модель работает на этом компьютере. Документ не отправляется в интернет. Первый ответ может занять до двух минут.';$dialog.Controls.Add($label)
 $progress=New-Object Windows.Forms.ProgressBar;$progress.Dock='Top';$progress.Style='Marquee';$progress.Height=18;$dialog.Controls.Add($progress);$progress.BringToFront()
 $cancel=New-Object Windows.Forms.Button;$cancel.Text='Отмена';$cancel.Size=New-Object Drawing.Size(120,34);$cancel.Location=New-Object Drawing.Point(370,110);$dialog.Controls.Add($cancel)
 $state=@{Result=$null;AllowClose=$false};$timer=New-Object Windows.Forms.Timer;$timer.Interval=100
 $cancelAction={& $commands['Request-MedicalAiUiCancellation'] $job;$cancel.Enabled=$false;$label.Text='Отмена запроса и завершение локального процесса…'}.GetNewClosure()
 $cancel.Add_Click($cancelAction)
 $dialog.Add_FormClosing({param($sender,$eventArgs)if(-not $state.AllowClose -and -not $job.Disposed){$eventArgs.Cancel=$true;& $cancelAction}}.GetNewClosure())
 $timer.Add_Tick({
  try{$result=& $commands['Complete-MedicalAiUiJob'] $job;if($null -ne $result){$state.Result=$result;$timer.Stop();$state.AllowClose=$true;$dialog.Close()}}
  catch{$state.Result=[pscustomobject]@{Success=$false;Error='Не удалось завершить запрос локального ИИ.'};$timer.Stop();$state.AllowClose=$true;$dialog.Close()}
 }.GetNewClosure())
 $timer.Start();[void]$dialog.ShowDialog($Owner);return $state.Result
 }finally{if($timer){$timer.Stop();$timer.Dispose()};if(-not $job.Disposed){& $commands['Stop-MedicalAiUiJob'] $job};if($dialog){$dialog.Dispose()}}
}
function Invoke-MedicalLocalAssistant($Owner,$Target=$null){
 $commands=@{};foreach($name in @('Get-MedicalAiEditableTarget','New-MedicalAiTextSnapshot','Apply-MedicalAiTextResult','Show-MedicalAiProgress','Show-MedicalAiSettings')){$commands[$name]=Get-Command $name -CommandType Function -ErrorAction Stop}
 $target=& $commands['Get-MedicalAiEditableTarget'] $Owner $Target;$snapshot=if($target){& $commands['New-MedicalAiTextSnapshot'] $target}else{$null}
 $dialog=New-Object Windows.Forms.Form;$dialog.Text='ИИ — редактирование текста с проверкой';$dialog.StartPosition='CenterParent';$dialog.AutoScaleMode='Font';$dialog.Size=New-Object Drawing.Size(1040,760);$dialog.MinimumSize=New-Object Drawing.Size(800,580);$dialog.Font=New-Object Drawing.Font('Segoe UI',10)
 $layout=New-Object Windows.Forms.TableLayoutPanel;$layout.Dock='Fill';$layout.ColumnCount=1;$layout.RowCount=6
 foreach($size in @(62,48,36)){[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',$size)))}
 [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)));[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',62)));[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',52)));$dialog.Controls.Add($layout)
 $hint=New-Object Windows.Forms.Label;$hint.Dock='Fill';$hint.Padding=New-Object Windows.Forms.Padding(8);$hint.Text='Локальная языковая модель предлагает текст. Проверьте все медицинские факты, даты и числа. Изменения применяются только вашей кнопкой. Если поле не выбрано, вставьте текст слева.';$layout.Controls.Add($hint,0,0)
 $instruction=New-Object Windows.Forms.TextBox;$instruction.Dock='Fill';$instruction.Text='Исправь орфографию и оформление. Сохрани все факты, имена, даты, числа и маркеры без изменений. Не добавляй диагнозы и назначения.';$layout.Controls.Add($instruction,0,1)
 $titles=New-Object Windows.Forms.Label;$titles.Dock='Fill';$titles.Text='Было (можно вставить свой текст)                                        Станет (проверьте и при необходимости исправьте)';$layout.Controls.Add($titles,0,2)
 $split=New-Object Windows.Forms.SplitContainer;$split.Dock='Fill';$split.Size=New-Object Drawing.Size(980,450);$split.SplitterDistance=490;$layout.Controls.Add($split,0,3)
 $before=New-Object Windows.Forms.TextBox;$before.Dock='Fill';$before.Multiline=$true;$before.ScrollBars='Both';$before.MaxLength=200000;$before.AcceptsReturn=$true;if($snapshot){$before.Text=$snapshot.Input};$split.Panel1.Controls.Add($before)
 $after=New-Object Windows.Forms.TextBox;$after.Dock='Fill';$after.Multiline=$true;$after.ScrollBars='Both';$after.MaxLength=200000;$after.AcceptsReturn=$true;$split.Panel2.Controls.Add($after)
 $status=New-Object Windows.Forms.Label;$status.Dock='Fill';$status.Padding=New-Object Windows.Forms.Padding(6);$status.Text='Для работы выберите GGUF-модель в настройках ИИ. Компактная модель рассчитана на компьютер с 8 ГБ памяти.';$layout.Controls.Add($status,0,4)
 $footer=New-Object Windows.Forms.FlowLayoutPanel;$footer.Dock='Fill';$footer.WrapContents=$false;$footer.AutoScroll=$true
 $run=New-Object Windows.Forms.Button;$run.Text='Получить предложение';$run.Size=New-Object Drawing.Size(205,34)
 $apply=New-Object Windows.Forms.Button;$apply.Text='Применить в поле';$apply.Size=New-Object Drawing.Size(175,34);$apply.Enabled=$false
 $copy=New-Object Windows.Forms.Button;$copy.Text='Копировать результат';$copy.Size=New-Object Drawing.Size(185,34);$copy.Enabled=$false
 $settings=New-Object Windows.Forms.Button;$settings.Text='Настройки ИИ';$settings.Size=New-Object Drawing.Size(145,34)
 $close=New-Object Windows.Forms.Button;$close.Text='Закрыть';$close.Size=New-Object Drawing.Size(110,34);$close.DialogResult='Cancel';$dialog.CancelButton=$close
 foreach($button in @($run,$apply,$copy,$settings,$close)){$footer.Controls.Add($button)};$layout.Controls.Add($footer,0,5)
 $state=@{Busy=$false;ResultInput='';HasResult=$false}
 $settings.Add_Click({& $commands['Show-MedicalAiSettings'] $dialog}.GetNewClosure())
 $before.Add_TextChanged({$state.HasResult=$false;$apply.Enabled=$false;$copy.Enabled=$false}.GetNewClosure())
 $run.Add_Click({
  if($state.Busy){return};if([string]::IsNullOrWhiteSpace($before.Text)){$status.Text='Введите текст в левое поле.';return}
  $state.Busy=$true;$run.Enabled=$false;$apply.Enabled=$false;$copy.Enabled=$false
  try{
   $state.ResultInput=[string]$before.Text;$result=& $commands['Show-MedicalAiProgress'] -Owner $dialog -Task Text -InputText $state.ResultInput -Instruction $instruction.Text
   if(-not $result -or -not $result.Success){$status.Text=if($result){[string]$result.Error}else{'Запрос отменён.'};return}
   $after.Text=[string]$result.Text;$state.HasResult=$true;$copy.Enabled=$true;$apply.Enabled=($null -ne $snapshot -and $state.ResultInput -ceq $snapshot.Input)
   $status.Text='Предложение готово. Сверьте факты и формулировки. '+(@($result.Warnings) -join ' ')
  }catch{$status.Text=$_.Exception.Message}finally{$state.Busy=$false;$run.Enabled=$true}
 }.GetNewClosure())
 $apply.Add_Click({
  try{
   if(-not $state.HasResult -or $before.Text -cne $state.ResultInput -or $state.ResultInput -cne $snapshot.Input){throw 'Исходный текст изменился. Выполните запрос заново.'}
   [void](& $commands['Apply-MedicalAiTextResult'] $snapshot $after.Text);$status.Text='Проверенный результат вставлен в исходное поле.';$apply.Enabled=$false
  }catch{$status.Text=$_.Exception.Message}
 }.GetNewClosure())
 $copy.Add_Click({try{if($state.HasResult -and -not [string]::IsNullOrWhiteSpace($after.Text)){[Windows.Forms.Clipboard]::SetText($after.Text);$status.Text='Результат скопирован по вашей команде.'}}catch{$status.Text='Буфер обмена недоступен. Выделите и скопируйте результат вручную.'}}.GetNewClosure())
 try{[void]$dialog.ShowDialog($Owner)}finally{$before.Clear();$after.Clear();$dialog.Dispose()}
}

function Invoke-MedicalAiMarkerBatches {
 param($Paragraphs,$Schema,[Threading.CancellationToken]$CancellationToken=[Threading.CancellationToken]::None,[ValidateRange(1,300)][int]$TimeoutSeconds=120)
 $suggestions=New-Object Collections.ArrayList;$warnings=New-Object Collections.ArrayList;$clock=[Diagnostics.Stopwatch]::StartNew();$provider='';$model=''
 try{
  $chunks=New-Object Collections.ArrayList;$chunkIndex=@{};$number=0
  foreach($paragraph in @($Paragraphs)){
   $source=[string]$paragraph.Text;$offset=0
   do{
    $CancellationToken.ThrowIfCancellationRequested();$length=[Math]::Min(700,$source.Length-$offset)
    if($offset+$length -lt $source.Length){$break=$source.LastIndexOf(' ',$offset+$length-1,$length);if($break -gt $offset+350){$length=$break-$offset+1}}
    $number++;if($number -gt 512){throw 'Документ слишком большой для одного анализа. Разделите его на части.'}
    $chunk=[pscustomobject]@{Id=('ai_chunk_'+$number);Text=$source.Substring($offset,$length);OriginalId=[string]$paragraph.Id;OriginalText=$source;Offset=$offset}
    [void]$chunks.Add($chunk);$chunkIndex[$chunk.Id]=$chunk;$offset+=$length
   }while($offset -lt $source.Length)
  }
  $batches=New-Object Collections.ArrayList;$batch=New-Object Collections.ArrayList;$characters=0
  foreach($chunk in $chunks){
   if($batch.Count -ge 8 -or ($batch.Count -gt 0 -and $characters+$chunk.Text.Length -gt 700)){[void]$batches.Add(@($batch.ToArray()));$batch.Clear();$characters=0}
   [void]$batch.Add([pscustomobject]@{Id=$chunk.Id;Text=$chunk.Text});$characters+=$chunk.Text.Length
  }
  if($batch.Count){[void]$batches.Add(@($batch.ToArray()))}
  foreach($batch in $batches){
   $CancellationToken.ThrowIfCancellationRequested();$remaining=$TimeoutSeconds-[int]$clock.Elapsed.TotalSeconds;if($remaining -lt 1){throw 'Истекло время анализа документа. Выберите меньше абзацев и повторите.'}
   $json=ConvertTo-Json -InputObject @($batch) -Depth 5 -Compress
   $result=Invoke-MedicalLocalAi -Task Markers -Input $json -Paragraphs @($batch) -Schema $Schema -CancellationToken $CancellationToken -TimeoutSeconds $remaining
   if(-not $result.Success){throw [string]$result.Error};$provider=[string]$result.Provider;$model=[string]$result.Model
   foreach($proposal in @($result.Suggestions)){
    if(-not $chunkIndex.ContainsKey([string]$proposal.ParagraphId)){throw 'ИИ вернул неизвестный абзац.'}
    $chunk=$chunkIndex[[string]$proposal.ParagraphId];$source=[string]$chunk.OriginalText;$offset=[int]$chunk.Offset;$start=$offset+[int]$proposal.Start;$span=[int]$proposal.Length
    if($start -lt $offset -or $span -lt 0 -or $start+$span -gt $offset+$chunk.Text.Length){throw 'ИИ вернул неверный диапазон текста.'}
    [void]$suggestions.Add([pscustomobject]@{ParagraphId=[string]$chunk.OriginalId;Marker=[string]$proposal.Marker;Start=$start;Length=$span;OriginalText=$source;ReplacementText=($source.Substring(0,$start)+'{{'+$proposal.Marker+'}}'+$source.Substring($start+$span));Reason=[string]$proposal.Reason;Selected=$false})
   }
   foreach($warning in @($result.Warnings)){if(-not $warnings.Contains([string]$warning)){[void]$warnings.Add([string]$warning)}}
  }
  return [pscustomobject]@{Success=$true;Task='Markers';Text='';Suggestions=@($suggestions.ToArray());Warnings=@($warnings.ToArray());Error='';Provider=$provider;Model=$model;NeedsReview=$true}
 }catch{return [pscustomobject]@{Success=$false;Task='Markers';Text='';Suggestions=@();Warnings=@();Error=$_.Exception.Message;Provider=$provider;Model=$model;NeedsReview=$true}}
}
function Show-MedicalAiSettings($Owner){
 $commands=@{};foreach($name in @('Get-MedicalLocalAiConfig','Set-MedicalLocalAiConfig','Get-MedicalLocalAiStatus','Get-MedicalLocalAiModels','Test-MedicalLocalAiModel','Install-MedicalAiModel','Get-MedicalAiModelManifest')){$commands[$name]=Get-Command $name -CommandType Function -ErrorAction Stop}
 $config=& $commands['Get-MedicalLocalAiConfig'];$context=& $commands['Get-MedicalLocalAiStatus'];$manifest=& $commands['Get-MedicalAiModelManifest'] $context.AppRoot
 $dialog=New-Object Windows.Forms.Form;$dialog.Text='Настройки локального ИИ';$dialog.StartPosition='CenterParent';$dialog.AutoScaleMode='Font';$dialog.Size=New-Object Drawing.Size(850,680);$dialog.MinimumSize=New-Object Drawing.Size(720,600);$dialog.Font=New-Object Drawing.Font('Segoe UI',10)
 $layout=New-Object Windows.Forms.TableLayoutPanel;$layout.Dock='Fill';$layout.Padding=New-Object Windows.Forms.Padding(12);$layout.ColumnCount=2;$layout.RowCount=9
 [void]$layout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Absolute',170)));[void]$layout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',100)))
 foreach($size in @(78,42,80,82,48,42,42)){[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',$size)))};[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)));[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',48)));$dialog.Controls.Add($layout)
 $hint=New-Object Windows.Forms.Label;$hint.Dock='Fill';$hint.Text='Локальная модель редактирует текст и предлагает маркеры. Документы остаются на компьютере. Модель скачивается отдельно один раз или выбирается из вашего GGUF-файла. Для 8 ГБ ОЗУ используйте компактную модель.';$layout.Controls.Add($hint,0,0);$layout.SetColumnSpan($hint,2)
 $providerLabel=New-Object Windows.Forms.Label;$providerLabel.Text='Движок';$providerLabel.Dock='Fill';$layout.Controls.Add($providerLabel,0,1)
 $provider=New-Object Windows.Forms.ComboBox;$provider.Dock='Fill';$provider.DropDownStyle='DropDownList';[void]$provider.Items.Add('Встроенный llama.cpp (CPU)');[void]$provider.Items.Add('Локальный Ollama');$provider.SelectedIndex=if($config.Backend -eq 'ollama'){1}else{0};$layout.Controls.Add($provider,1,1)
 $modelLabel=New-Object Windows.Forms.Label;$modelLabel.Text='GGUF-модель';$modelLabel.Dock='Fill';$layout.Controls.Add($modelLabel,0,2)
 $modelPanel=New-Object Windows.Forms.TableLayoutPanel;$modelPanel.Dock='Fill';$modelPanel.ColumnCount=2;$modelPanel.RowCount=2;[void]$modelPanel.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',100)));[void]$modelPanel.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Absolute',130)))
 $modelPath=New-Object Windows.Forms.TextBox;$modelPath.Dock='Fill';$modelPath.Text=[string]$config.ModelPath;$modelPanel.Controls.Add($modelPath,0,0)
 $browse=New-Object Windows.Forms.Button;$browse.Text='Загрузить GGUF';$browse.Dock='Fill';$modelPanel.Controls.Add($browse,1,0)
 $installed=New-Object Windows.Forms.ComboBox;$installed.Dock='Fill';$installed.DropDownStyle='DropDownList';$installed.DisplayMember='Name';foreach($item in @(& $commands['Get-MedicalLocalAiModels'])){[void]$installed.Items.Add($item)};$modelPanel.Controls.Add($installed,0,1);$modelPanel.SetColumnSpan($installed,2);$layout.Controls.Add($modelPanel,1,2)
 $download=New-Object Windows.Forms.Button;$download.Text='Скачать компактную модель (~'+[Math]::Ceiling([double]$manifest.Bytes/1000000)+' МБ)';$download.Dock='Fill';$layout.Controls.Add($download,0,3)
 $downloadInfo=New-Object Windows.Forms.Label;$downloadInfo.Dock='Fill';$downloadInfo.Text=[string]$manifest.Name+"`r`n"+'Только веса модели из интернета; документы не передаются. Лицензия: '+[string]$manifest.License;$layout.Controls.Add($downloadInfo,1,3)
 $endpointLabel=New-Object Windows.Forms.Label;$endpointLabel.Text='Адрес Ollama';$endpointLabel.Dock='Fill';$layout.Controls.Add($endpointLabel,0,4)
 $endpoint=New-Object Windows.Forms.TextBox;$endpoint.Text=[string]$config.OllamaEndpoint;$endpoint.Dock='Fill';$layout.Controls.Add($endpoint,1,4)
 $ollamaLabel=New-Object Windows.Forms.Label;$ollamaLabel.Text='Модель Ollama';$ollamaLabel.Dock='Fill';$layout.Controls.Add($ollamaLabel,0,5)
 $ollamaModel=New-Object Windows.Forms.TextBox;$ollamaModel.Text=[string]$config.OllamaModel;$ollamaModel.Dock='Fill';$layout.Controls.Add($ollamaModel,1,5)
 $threadLabel=New-Object Windows.Forms.Label;$threadLabel.Text='Потоки CPU (1–4)';$threadLabel.Dock='Fill';$layout.Controls.Add($threadLabel,0,6)
 $threads=New-Object Windows.Forms.NumericUpDown;$threads.Minimum=1;$threads.Maximum=4;$threads.Value=[int]$config.Threads;$threads.Dock='Left';$layout.Controls.Add($threads,1,6)
 $status=New-Object Windows.Forms.Label;$status.Dock='Fill';$status.Text=[string]$context.Message;$layout.Controls.Add($status,0,7);$layout.SetColumnSpan($status,2)
 $footer=New-Object Windows.Forms.FlowLayoutPanel;$footer.Dock='Fill';$footer.FlowDirection='RightToLeft'
 $close=New-Object Windows.Forms.Button;$close.Text='Отмена';$close.Width=110;$close.Height=34;$close.DialogResult='Cancel';$dialog.CancelButton=$close
 $save=New-Object Windows.Forms.Button;$save.Text='Сохранить настройки';$save.Width=215;$save.Height=34
 [void]$footer.Controls.Add($close);[void]$footer.Controls.Add($save);$layout.Controls.Add($footer,0,8);$layout.SetColumnSpan($footer,2)
 $browse.Add_Click({$picker=New-Object Windows.Forms.OpenFileDialog;$picker.Filter='Модель GGUF (*.gguf)|*.gguf';$picker.CheckFileExists=$true;try{if($picker.ShowDialog($dialog) -eq 'OK'){$imported=& $commands['Install-MedicalAiModel'] $dialog $context.AppRoot $context.ProfileRoot $picker.FileName;if($imported){$modelPath.Text=[string]$imported}}}catch{$status.Text=$_.Exception.Message}finally{$picker.Dispose()}}.GetNewClosure())
 $installed.Add_SelectedIndexChanged({if($installed.SelectedItem){$modelPath.Text=[string]$installed.SelectedItem.Path}}.GetNewClosure())
 $refresh={ $native=$provider.SelectedIndex -eq 0;$modelPanel.Enabled=$native;$download.Enabled=$native;$endpoint.Enabled=-not $native;$ollamaModel.Enabled=-not $native }.GetNewClosure()
 $provider.Add_SelectedIndexChanged($refresh);& $refresh
 $download.Add_Click({
  $download.Enabled=$false;$save.Enabled=$false
  try{$path=& $commands['Install-MedicalAiModel'] $dialog $context.AppRoot $context.ProfileRoot;if($path){$modelPath.Text=[string]$path;$status.Text='Модель установлена. Нажмите «Сохранить настройки».'}}
  catch{$status.Text=$_.Exception.Message}finally{$save.Enabled=$true;& $refresh}
 }.GetNewClosure())
 $save.Add_Click({
  try{
   if($provider.SelectedIndex -eq 0 -and $modelPath.Text){[void](& $commands['Test-MedicalLocalAiModel'] $modelPath.Text)}
   $candidate=[pscustomobject]@{Backend=$(if($provider.SelectedIndex -eq 0){'llama'}else{'ollama'});ModelPath=$modelPath.Text;OllamaEndpoint=$endpoint.Text;OllamaModel=$ollamaModel.Text;Threads=[int]$threads.Value;TimeoutSeconds=[int]$config.TimeoutSeconds}
   [void](& $commands['Set-MedicalLocalAiConfig'] $candidate);$dialog.DialogResult='OK';$dialog.Close()
  }catch{$status.Text=$_.Exception.Message}
 }.GetNewClosure())
 try{[void]$dialog.ShowDialog($Owner)}finally{$dialog.Dispose()}
}

function New-MedicalAiReviewPlan($Model,$Schema,$Suggestions){
 $definitions=@(Get-MedicalRecognitionDefinitions $Schema);$allowed=@{};foreach($definition in $definitions){$allowed[[string]$definition.Marker]=$definition}
 $byId=@{};foreach($paragraph in $Model.Paragraphs){$byId[[string]$paragraph.Id]=$paragraph}
 $rows=New-Object Collections.ArrayList;$number=0
 foreach($proposal in @($Suggestions)){
  $id=[string]$proposal.ParagraphId;$marker=[string]$proposal.Marker;$start=[int]$proposal.Start;$length=[int]$proposal.Length
  if(-not $byId.ContainsKey($id) -or -not $allowed.ContainsKey($marker)){throw 'Неизвестный абзац или маркер в предложении ИИ.'}
  $paragraph=$byId[$id];$text=[string]$paragraph.Text
  if(-not $paragraph.Editable -or $paragraph.Part -cne 'word/document.xml'){throw 'ИИ предложил изменение сложного элемента Word. Измените его вручную.'}
  if($text -cne [string]$proposal.OriginalText -or $start -lt 0 -or $length -lt 0 -or $start+$length -gt $text.Length -or ($length -eq 0 -and $text.Length -gt 0)){throw 'Исходный текст или диапазон предложения изменился.'}
  foreach($token in [regex]::Matches($text,'\{\{[^{}]+\}\}')){if($start -lt $token.Index+$token.Length -and $start+$length -gt $token.Index){throw 'Предложение затрагивает существующий маркер.'}}
  foreach($prior in $rows){if($prior.ParagraphId -ceq $id -and (($start -lt $prior.Start+$prior.Length -and $start+$length -gt $prior.Start) -or $start -eq $prior.Start)){throw 'Предложения ИИ пересекаются.'}}
  $number++;$row=New-MedicalRecognitionRow ('ai_'+$number) $paragraph ([string]$allowed[$marker].Label) $marker 'replace' $start $length ([string]$proposal.Reason) $false
  Update-MedicalRecognitionRow $row;[void]$rows.Add($row)
  if($rows.Count -gt 512){throw 'Слишком много предложений за один анализ.'}
 }
 $allText=@($Model.Paragraphs|ForEach-Object {[string]$_.Text}) -join "`n";$datePresent=($allText.Contains('{{ADMISSION_DATETIME}}') -or ($allText.Contains('{{ADMISSION_DATE}}') -and $allText.Contains('{{ADMISSION_TIME}}')))
 if(@(Get-UniversalFields $Schema).Count -eq 0 -and -not $datePresent -and @($rows|Where-Object {$_.Marker -ceq 'ADMISSION_DATETIME'}).Count -eq 0){
  $number++;$date=New-MedicalRecognitionRow ('ai_'+$number) $null 'Дата и время поступления' 'ADMISSION_DATETIME' 'add-date' 0 0 'Для новой формы нужна дата. Добавление выполняется только после отметки этой строки.' $false;Update-MedicalRecognitionRow $date;[void]$rows.Add($date)
 }
 return [pscustomobject]@{Fingerprint=(Get-MedicalRecognitionFingerprint $Model $Schema);Rows=@($rows.ToArray());Definitions=$definitions;NewSchema=(@(Get-UniversalFields $Schema).Count -eq 0)}
}
function Apply-MedicalAiReviewPlan($Model,$Schema,$Plan,[string[]]$SelectedIds){
 if((Get-MedicalRecognitionFingerprint $Model $Schema) -cne [string]$Plan.Fingerprint){throw 'Документ или форма изменились. Запустите ИИ повторно.'}
 $rows=@($Plan.Rows|Where-Object {$_.Id -cin $SelectedIds})
 if(-not $rows.Count -or $rows.Count -ne $SelectedIds.Count -or @($SelectedIds|Select-Object -Unique).Count -ne $SelectedIds.Count){throw 'Отметьте существующие предложения без повторов.'}
 $definitions=@{};foreach($definition in $Plan.Definitions){$definitions[[string]$definition.Marker]=$definition}
 $proposals=@(foreach($row in $rows){if($row.Action -ne 'add-date'){[pscustomobject]@{ParagraphId=$row.ParagraphId;Marker=$row.Marker;Start=$row.Start;Length=$row.Length;OriginalText=$row.OriginalText;Reason=$row.Reason}}})
 # Revalidate the selected ranges and allowed marker catalogue independently of grid cell state.
 $validated=New-MedicalAiReviewPlan $Model $Schema $proposals
 $copy=Copy-MedicalRecognitionModel $Model;$candidate=Copy-MedicalFormSchema $Schema;$applied=@{}
 foreach($group in @($rows|Where-Object {$_.Action -eq 'replace'}|Group-Object ParagraphId)){
  $paragraph=@($copy.Paragraphs|Where-Object {$_.Id -ceq $group.Name})|Select-Object -First 1
  foreach($row in @($group.Group|Sort-Object Start -Descending)){
   if(-not $definitions.ContainsKey([string]$row.Marker)){throw 'Неизвестный маркер.'}
   Set-MedicalRecognitionTextRange $copy $paragraph ([int]$row.Start) ([int]$row.Length) ('{{'+$row.Marker+'}}');$applied[[string]$row.Marker]=$true
  }
 }
 foreach($row in @($rows|Where-Object {$_.Action -ne 'replace'})){
  if($row.Action -cne 'add-date' -or $row.Marker -cne 'ADMISSION_DATETIME' -or -not $Plan.NewSchema){throw 'Неизвестное действие предложения ИИ.'}
  $first=@($copy.Paragraphs|Where-Object {$_.Part -ceq 'word/document.xml' -and $_.Node.ParentNode.LocalName -ceq 'body'})|Select-Object -First 1
  if(-not $first){throw 'Добавьте обычный абзац для даты в редакторе.'}
  [void](Add-MedicalTemplateParagraph $copy 'word/document.xml' $first.Id 'Дата и время поступления: {{ADMISSION_DATETIME}}');$applied['ADMISSION_DATETIME']=$true
 }
 Update-MedicalEditorParagraphs $copy
 if($Plan.NewSchema){
  if(@($applied.Keys|Where-Object {-not $definitions[$_].System}).Count -eq 0){throw 'Выберите хотя бы одно поле формы.'}
  $candidate.Sections=@();$sections=@{}
  foreach($definition in $Plan.Definitions){
   if($definition.System -or -not $applied.ContainsKey([string]$definition.Marker)){continue}
   $sectionId=[string]$definition.SectionId
   if(-not $sections.ContainsKey($sectionId)){$sections[$sectionId]=[pscustomobject]@{Id=$sectionId;Title=[string]$definition.SectionTitle;Fields=@()};$candidate.Sections+=@($sections[$sectionId])}
   $field=Copy-UniversalObject $definition.Field;$field.WordId='';$field.Required=$false
   if($field.Type -in @('choice','choice_detail','multi','repeat') -and @($field.Options).Count -eq 0){$field.Type='multiline'}
   $sections[$sectionId].Fields+=@($field)
  }
  $candidate.AutoTemplate=$false;$candidate|Add-Member -NotePropertyName PreserveTemplateFormatting -NotePropertyValue $true -Force
  Assert-MedicalEditorTemplateCoverage $candidate $copy
 }else{Assert-UniversalConfig $candidate}
 return [pscustomobject]@{Model=$copy;Schema=$candidate;AppliedCount=$rows.Count}
}
function Invoke-MedicalAiTemplateRecognition($Owner,$Model,$Schema){
 $commands=@{};foreach($name in @('Get-MedicalRecognitionDefinitions','Show-MedicalAiProgress','New-MedicalAiReviewPlan','Apply-MedicalAiReviewPlan')){$commands[$name]=Get-Command $name -CommandType Function -ErrorAction Stop}
 $paragraphs=@($Model.Paragraphs|Where-Object {$_.Editable -and $_.Part -ceq 'word/document.xml'}|ForEach-Object {[pscustomobject]@{Id=[string]$_.Id;Text=[string]$_.Text}})
 if(-not $paragraphs.Count){[void][Windows.Forms.MessageBox]::Show($Owner,'В документе нет обычных текстовых абзацев для анализа.','Локальный ИИ','OK','Information');return $null}
 $definitions=@(& $commands['Get-MedicalRecognitionDefinitions'] $Schema|ForEach-Object {[pscustomobject]@{Marker=[string]$_.Marker;Label=[string]$_.Label}})
 $result=& $commands['Show-MedicalAiProgress'] -Owner $Owner -Task Markers -InputText 'Проверка структуры шаблона' -Paragraphs $paragraphs -Schema $definitions
 if(-not $result -or -not $result.Success){if($result -and -not $result.Cancelled){[void][Windows.Forms.MessageBox]::Show($Owner,[string]$result.Error,'Локальный ИИ','OK','Warning')};return $null}
 if(-not @($result.Suggestions).Count){[void][Windows.Forms.MessageBox]::Show($Owner,'Модель не предложила уверенных замен. Документ не изменён. Используйте распознавание подписей или расставьте маркеры вручную.','Локальный ИИ','OK','Information');return $null}
 $plan=& $commands['New-MedicalAiReviewPlan'] $Model $Schema $result.Suggestions
 $dialog=New-Object Windows.Forms.Form;$dialog.Text='Предложения ИИ — проверьте маркеры';$dialog.StartPosition='CenterParent';$dialog.AutoScaleMode='Font';$dialog.Size=New-Object Drawing.Size(1180,750);$dialog.MinimumSize=New-Object Drawing.Size(800,560);$dialog.Font=New-Object Drawing.Font('Segoe UI',10)
 $layout=New-Object Windows.Forms.TableLayoutPanel;$layout.Dock='Fill';$layout.ColumnCount=1;$layout.RowCount=4
 [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',78)));[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)));[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',70)));[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',50)));$dialog.Controls.Add($layout)
 $hint=New-Object Windows.Forms.Label;$hint.Dock='Fill';$hint.Padding=New-Object Windows.Forms.Padding(10);$hint.Text='Каждое предложение изначально отключено. Отметьте только проверенные замены и сверьте «Было / Станет». Постоянный текст должен сохраниться. Перед сохранением многоразовой формы удалите все исходные ответы пациента. Исходный Word-файл не меняется.';$layout.Controls.Add($hint,0,0)
 $grid=New-Object Windows.Forms.DataGridView;$grid.Dock='Fill';$grid.AutoGenerateColumns=$false;$grid.AllowUserToAddRows=$false;$grid.AllowUserToDeleteRows=$false;$grid.RowHeadersVisible=$false;$grid.AutoSizeRowsMode='AllCells';$grid.DefaultCellStyle.WrapMode='True';$grid.BackgroundColor=[Drawing.Color]::White
 $check=New-Object Windows.Forms.DataGridViewCheckBoxColumn;$check.Name='Apply';$check.HeaderText='Применить';$check.Width=88;[void]$grid.Columns.Add($check)
 foreach($columnInfo in @(@('Marker','Маркер',22),@('Before','Было',39),@('After','Станет',39))){$column=New-Object Windows.Forms.DataGridViewTextBoxColumn;$column.Name=$columnInfo[0];$column.HeaderText=$columnInfo[1];$column.ReadOnly=$true;$column.AutoSizeMode='Fill';$column.FillWeight=[int]$columnInfo[2];[void]$grid.Columns.Add($column)}
 foreach($proposal in $plan.Rows){$index=$grid.Rows.Add();$row=$grid.Rows[$index];$row.Tag=$proposal;$row.Cells['Apply'].Value=$false;$row.Cells['Marker'].Value='{{'+$proposal.Marker+'}}';$row.Cells['Before'].Value=if($proposal.Action -eq 'add-date'){'Новый абзац после заголовка'}else{$proposal.OriginalText};$row.Cells['After'].Value=$proposal.ReplacementText;$row.Cells['After'].ToolTipText=$proposal.Reason}
 $layout.Controls.Add($grid,0,1)
 $status=New-Object Windows.Forms.Label;$status.Dock='Fill';$status.Padding=New-Object Windows.Forms.Padding(6);$status.Text=(@($result.Warnings) -join ' ');$layout.Controls.Add($status,0,2)
 $footer=New-Object Windows.Forms.FlowLayoutPanel;$footer.Dock='Fill';$footer.FlowDirection='RightToLeft'
 $cancel=New-Object Windows.Forms.Button;$cancel.Text='Отмена';$cancel.Size=New-Object Drawing.Size(120,34);$cancel.DialogResult='Cancel';$dialog.CancelButton=$cancel
 $apply=New-Object Windows.Forms.Button;$apply.Text='Применить отмеченные';$apply.Size=New-Object Drawing.Size(240,34);$footer.Controls.Add($cancel);$footer.Controls.Add($apply);$layout.Controls.Add($footer,0,3)
 $state=@{Result=$null}
 $grid.Add_CurrentCellDirtyStateChanged({if($grid.IsCurrentCellDirty){[void]$grid.CommitEdit([Windows.Forms.DataGridViewDataErrorContexts]::Commit)}}.GetNewClosure())
 $apply.Add_Click({
  try{[void]$grid.EndEdit();$ids=@(foreach($row in $grid.Rows){if([bool]$row.Cells['Apply'].Value){[string]$row.Tag.Id}});$state.Result=& $commands['Apply-MedicalAiReviewPlan'] $Model $Schema $plan $ids;$dialog.DialogResult='OK';$dialog.Close()}
  catch{$status.Text=$_.Exception.Message}
 }.GetNewClosure())
 try{if($dialog.ShowDialog($Owner) -eq 'OK'){return $state.Result};return $null}finally{$dialog.Dispose()}
}
