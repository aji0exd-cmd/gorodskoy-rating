﻿# Open Card accepts saved application cards and ordinary reusable Word documents.
# Classification reads a bounded, safe XML view before changing the live patient.
function Get-MedicalOpenDocumentFilter {
 return 'Карты и документы Word|*.docx;*.dotx;*.doc;*.dot;*.rtf|Документы Word|*.docx;*.doc;*.rtf|Шаблоны Word|*.dotx;*.dot'
}
function Read-MedicalOpenPackageXml($entry,[long]$maximum=33554432){
 if($null -eq $entry -or $entry.Length -gt $maximum){throw 'Часть документа отсутствует или превышает допустимый размер.'}
 $settings=New-Object Xml.XmlReaderSettings;$settings.DtdProcessing=[Xml.DtdProcessing]::Prohibit;$settings.XmlResolver=$null;$settings.MaxCharactersInDocument=$maximum
 $stream=$entry.Open();$reader=$null
 try{
  $reader=[Xml.XmlReader]::Create($stream,$settings);$xml=New-Object Xml.XmlDocument;$xml.XmlResolver=$null;$xml.Load($reader);return ,$xml
 }finally{if($reader){$reader.Dispose()};$stream.Dispose()}
}
function Test-MedicalLegacyCardRecord($record){
 if(-not $record -or $record -is [Array] -or $record -is [string]){return $false}
 $version=0;if(-not [int]::TryParse([string]$record.version,[ref]$version) -or $version -lt 24 -or $version -gt 49){return $false}
 return ($null -ne $record.stages -and $null -ne $record.templates -and $null -ne $record.PSObject.Properties['patientName'])
}
function Get-MedicalDocumentKind([string]$path){
 # Check account ownership before inspecting existence, bytes, or package parts.
 if(Get-Command Assert-MedicalAccountPath -CommandType Function -ErrorAction SilentlyContinue){Assert-MedicalAccountPath $path}
 if([string]::IsNullOrWhiteSpace($path)){throw 'Выберите карту или документ Word.'}
 $full=[IO.Path]::GetFullPath($path)
 if(-not [IO.File]::Exists($full)){throw 'Документ Word не найден.'}
 $extension=[IO.Path]::GetExtension($full).ToLowerInvariant()
 if($extension -notin @('.docx','.dotx','.doc','.dot','.rtf')){throw 'Откройте DOCX, DOTX, DOC, DOT или RTF. Защищённые паролем файлы сначала сохраните в Word без пароля; DOCM и DOTM сохраните как DOCX или DOTX.'}
 $info=New-Object IO.FileInfo $full
 if($info.Length -eq 0){throw 'Документ Word пуст.'}
 if($info.Length -gt 209715200){throw 'Размер документа превышает 200 МБ. Разделите его на несколько файлов.'}
 $stream=[IO.File]::OpenRead($full)
 try{$first=$stream.ReadByte();$second=$stream.ReadByte()}finally{$stream.Dispose()}
 if($first -ne 0x50 -or $second -ne 0x4b){
  if($extension -in @('.docx','.dotx')){throw 'Файл не является доступным пакетом Word. Если он защищён паролем, откройте его в Word и сохраните копию DOCX без пароля.'}
  return [pscustomobject]@{Kind='Template';Path=$full;Format=$extension;Legacy=$true}
 }
 $zip=$null
 try{
  $zip=[IO.Compression.ZipFile]::OpenRead($full);$entries=@{}
  if($zip.Entries.Count -gt 4096){throw 'В документе слишком много частей.'}
  foreach($entry in $zip.Entries){
   if($entries.ContainsKey([string]$entry.FullName)){throw ('Повторяющаяся часть документа: '+$entry.FullName)}
   $entries[[string]$entry.FullName]=$entry
  }
  if(-not $entries.ContainsKey('word/document.xml')){throw 'В файле не найден основной документ Word.'}
  # A known state part, including malformed XML, is never downgraded to a template.
  if($entries.ContainsKey('customXml/mc-case.xml')){
   if($entries['customXml/mc-case.xml'].Length -gt 201326592){throw 'Состояние карты превышает допустимый размер.'}
   $record=Read-MedicalCardDocumentState $zip
   if(-not $record){throw 'Повреждено состояние карты госпитализации.'}
   return [pscustomobject]@{Kind='Card';Path=$full;Format=$extension;Legacy=$false}
  }
  # A removed state part still leaves its reference in the package; report damage.
  foreach($partName in @('[Content_Types].xml','word/_rels/document.xml.rels')){
   if(-not $entries.ContainsKey($partName)){continue}
   $references=Read-MedicalOpenPackageXml $entries[$partName] 4194304
   foreach($node in @($references.DocumentElement.ChildNodes)){
    if($node -isnot [Xml.XmlElement]){continue}
    $target=if($partName -eq '[Content_Types].xml'){$node.GetAttribute('PartName')}else{$node.GetAttribute('Target')}
    $target=$target.Replace('\','/').ToLowerInvariant()
    if($target -in @('/customxml/mc-case.xml','../customxml/mc-case.xml') -and -not $entries.ContainsKey('customXml/mc-case.xml')){throw 'В карте отсутствует часть состояния госпитализации. Откройте резервную копию карты.'}
    if($target -in @('/customxml/mc49.xml','../customxml/mc49.xml') -and -not $entries.ContainsKey('customXml/mc49.xml')){throw 'В заполненном документе отсутствует часть данных формы. Откройте резервную копию.'}
   }
  }
  $document=Read-MedicalOpenPackageXml $entries['word/document.xml']
  $wordNamespace='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
  if(-not $document.DocumentElement -or $document.DocumentElement.LocalName -cne 'document' -or $document.DocumentElement.NamespaceURI -cne $wordNamespace){throw 'В файле нет корректного документа Word.'}
  $namespaces=New-Object Xml.XmlNamespaceManager $document.NameTable;$namespaces.AddNamespace('w',$wordNamespace)
  if(-not $document.SelectSingleNode('/w:document/w:body',$namespaces)){throw 'В документе отсутствует основной текст Word.'}
  $text=(($document.SelectNodes('//w:t',$namespaces) | ForEach-Object {$_.InnerText}) -join '')
  foreach($match in [regex]::Matches($text,'MC_CASE_V24:([A-Za-z0-9+/=]+):END_MC_CASE')){
   $record=$null
   try{$utf8=New-Object Text.UTF8Encoding($false,$true);$record=($utf8.GetString([Convert]::FromBase64String($match.Groups[1].Value)) | ConvertFrom-Json)}catch{throw 'Повреждены встроенные данные старой карты госпитализации.'}
   if(-not (Test-MedicalLegacyCardRecord $record)){throw 'Неизвестный или повреждённый формат старой карты госпитализации.'}
   return [pscustomobject]@{Kind='Card';Path=$full;Format=$extension;Legacy=$true}
  }
  $hiddenText=(($document.SelectNodes('//w:r[w:rPr/w:vanish]//w:t',$namespaces) | ForEach-Object {$_.InnerText}) -join '')
  if($hiddenText.Contains('MC_CASE_V24:')){throw 'Повреждены скрытые данные старой карты. Выберите резервную копию.'}
  if($entries.ContainsKey('customXml/mc49.xml')){
   $stateXml=Read-MedicalOpenPackageXml $entries['customXml/mc49.xml'] 201326592
   $root=$stateXml.DocumentElement
   if(-not $root -or $root.LocalName -cne 'state' -or $root.NamespaceURI -cne 'urn:medical-constructor:v49' -or @($root.ChildNodes | Where-Object {$_ -is [Xml.XmlElement]}).Count){throw 'Повреждено состояние заполненного документа конструктора.'}
   try{$utf8=New-Object Text.UTF8Encoding($false,$true);$state=($utf8.GetString([Convert]::FromBase64String($root.InnerText)) | ConvertFrom-Json)}catch{throw 'Повреждены данные заполненного документа конструктора.'}
   if(-not $state -or $state -is [Array] -or $state.Version -notin @(49,67,68) -or (-not $state.Schema -and $state.Stage -notin @('diaries','hospitalization'))){throw 'В заполненном документе отсутствует структура формы.'}
   return [pscustomobject]@{Kind='Stage';Path=$full;Format=$extension;Legacy=$false}
  }
  return [pscustomobject]@{Kind='Template';Path=$full;Format=$extension;Legacy=$false}
 }finally{if($zip){$zip.Dispose()}}
}
function Open-MedicalDocumentPath([string]$path,$owner=$null){
 $kind=Get-MedicalDocumentKind $path
 if($null -eq $owner){$owner=$form}
 if($kind.Kind -eq 'Card'){
  # Fully read before asking to replace the working patient, then let the existing
  # card reader repeat its integrity validation at the actual restoration point.
  $null=Read-CaseDocument $kind.Path
  if(-not (Confirm-MedicalFormReset)){return $false}
  Open-CasePath $kind.Path;return $true
 }
 if($kind.Kind -eq 'Stage'){
  Open-UniversalDocument $kind.Path;return
 }
 # Ordinary Word files always begin a new reusable form, regardless of the active
 # diary/discharge tab. Patient values are never inferred from an arbitrary file.
 $choice=Import-MedicalLocalTemplateChoice $owner (New-UniversalConfig) $kind.Path $true
 if(-not $choice){return $false}
 $saveContext=New-MedicalEditorSaveContext $choice.Schema 'new';$saveContext.Name=[string]$choice.Name
 $result=Show-MedicalFormTemplateEditor $owner $choice.Schema $null 'new' $saveContext
 if(-not $result){return $false}
 Assert-UniversalConfig $result.Schema
 if(-not (Confirm-MedicalFormReset)){return $false}
 $name=if($result.SavedFormName){[string]$result.SavedFormName}else{[string]$choice.Name}
 Use-MedicalFormSchema $result.Schema $name ([string]$result.SavedFormPath) $result.SavedStageForms
 Set-MedicalEditorSavedFormMetadata $result
 return $true
}
