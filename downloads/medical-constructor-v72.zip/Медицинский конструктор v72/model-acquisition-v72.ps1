﻿# Explicit model acquisition only. The remote request contains public model names;
# documents, prompts, account names, and medical data never enter this transport.
function Assert-MedicalAiManagedModelPath([string]$Path,[string]$Root){
 $full=[IO.Path]::GetFullPath($Path);$base=[IO.Path]::GetFullPath($Root).TrimEnd([char[]]@('\','/'))
 if(-not ($full.Equals($base,[StringComparison]::OrdinalIgnoreCase) -or $full.StartsWith($base+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase))){throw 'Неверная папка моделей ИИ.'}
 # Inspect existing ancestors too, including dangling symlinks/junctions. A
 # shared weights directory must never redirect into a patient's working files.
 $cursor=$full
 while($cursor){
  $attributes=$null
  try{$attributes=[IO.File]::GetAttributes($cursor)}catch [IO.FileNotFoundException]{}catch [IO.DirectoryNotFoundException]{}
  if($null -ne $attributes -and ($attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Папка моделей ИИ не должна содержать перенаправления.'}
  $parent=[IO.Path]::GetDirectoryName($cursor);if(-not $parent -or $parent -eq $cursor){break};$cursor=$parent
 }
 return $full
}
function Get-MedicalAiModelManifest([string]$AppRoot){
 $root=[IO.Path]::GetFullPath($AppRoot);$path=Assert-MedicalAiManagedModelPath (Join-Path $root 'ИИ/model-manifest.json') $root
 if(-not [IO.File]::Exists($path) -or (New-Object IO.FileInfo $path).Length -gt 16384){throw 'Не найден корректный паспорт рекомендуемой модели. Распакуйте программу полностью.'}
 $manifest=[IO.File]::ReadAllText($path,[Text.Encoding]::UTF8)|ConvertFrom-Json
 if(-not $manifest -or $manifest -is [Array] -or $manifest.Version -ne 1 -or $manifest.Repository -cne 'Qwen/Qwen2.5-0.5B-Instruct-GGUF' -or $manifest.FileName -cne 'qwen2.5-0.5b-instruct-q4_k_m.gguf' -or $manifest.ApiUrl -cne 'https://huggingface.co/api/models/Qwen/Qwen2.5-0.5B-Instruct-GGUF?blobs=true' -or $manifest.License -cne 'Apache-2.0' -or $manifest.ContextSize -ne 2048){throw 'Паспорт рекомендуемой модели не соответствует этой версии программы.'}
 if([string]::IsNullOrWhiteSpace([string]$manifest.Name) -or ([string]$manifest.Name).Length -gt 160 -or [long]$manifest.Bytes -lt 1048576 -or [long]$manifest.Bytes -gt 1073741824){throw 'Паспорт модели содержит недопустимые параметры.'}
 if($manifest.Sha256 -and ([string]$manifest.Sha256) -cnotmatch '^[a-fA-F0-9]{64}$'){throw 'В паспорте модели повреждена контрольная сумма.'}
 return $manifest
}
function Assert-MedicalAiModelDownloadUri([string]$Address){
 $uri=$null
 if(-not [Uri]::TryCreate($Address,[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -cne 'https' -or $uri.Port -ne 443 -or $uri.UserInfo -or $uri.Fragment){throw 'Загрузка модели разрешена только по проверенному HTTPS-адресу поставщика.'}
 $hostName=$uri.DnsSafeHost.ToLowerInvariant()
 if(-not ($hostName -ceq 'huggingface.co' -or $hostName.EndsWith('.huggingface.co',[StringComparison]::Ordinal) -or $hostName.EndsWith('.hf.co',[StringComparison]::Ordinal))){throw 'Поставщик перенаправил загрузку модели на неподдерживаемый адрес.'}
 return $uri
}
function Resolve-MedicalAiModelDownload($Manifest,$Metadata){
 # Only the LFS SHA-256 and exact byte count at an immutable upstream revision
 # authenticate the preset. The approximate size in the shipped passport is UI.
 if($Manifest.Repository -cne 'Qwen/Qwen2.5-0.5B-Instruct-GGUF' -or $Manifest.FileName -cne 'qwen2.5-0.5b-instruct-q4_k_m.gguf'){throw 'Неизвестный поставщик рекомендуемой модели.'}
 if(-not $Metadata -or ([string]$Metadata.sha) -cnotmatch '^[a-fA-F0-9]{40}$'){throw 'Поставщик не сообщил неизменяемую версию модели.'}
 $matches=@($Metadata.siblings | Where-Object {[string]::Equals([string]$_.rfilename,[string]$Manifest.FileName,[StringComparison]::OrdinalIgnoreCase)})
 if($matches.Count -ne 1){throw 'В официальном каталоге не найден единственный файл рекомендуемой модели.'}
 $file=$matches[0];$hash=[string]$file.lfs.sha256;$size=0L
 if($hash -cnotmatch '^[a-fA-F0-9]{64}$' -or -not [long]::TryParse([string]$file.lfs.size,[ref]$size) -or $size -lt 1048576 -or $size -gt 1073741824){throw 'Поставщик не сообщил проверяемую контрольную сумму и размер модели.'}
 if($null -ne $file.PSObject.Properties['size'] -and [long]$file.size -ne $size){throw 'Размер модели в официальных метаданных противоречив.'}
 $revision=([string]$Metadata.sha).ToLowerInvariant();$actualName=[string]$file.rfilename;$uri='https://huggingface.co/'+$Manifest.Repository+'/resolve/'+$revision+'/'+[Uri]::EscapeDataString($actualName)+'?download=true'
 $null=Assert-MedicalAiModelDownloadUri $uri
 return [pscustomobject]@{Repository=[string]$Manifest.Repository;Revision=$revision;FileName=$actualName;Sha256=$hash.ToLowerInvariant();Bytes=$size;Uri=$uri}
}
function New-MedicalAiAcquisitionContext($Owner,[bool]$Downloading){
 $context=@{Owner=$Owner;Dialog=$null;Label=$null;Progress=$null;OwnerWasEnabled=$true;OwnerDisabled=$false;Cancel=(New-Object Threading.CancellationTokenSource);Cancelled=$false;Watch=[Diagnostics.Stopwatch]::StartNew();HttpClient=$null;HttpHandler=$null;PreviousTls=$null;LastProgress=-1;TotalSeconds=1800;IoSeconds=60}
 if($Owner){
  try{
   $dialog=New-Object Windows.Forms.Form;$context.Dialog=$dialog;$dialog.Text=if($Downloading){'Загрузка локальной модели ИИ'}else{'Установка локальной модели ИИ'};$dialog.Width=550;$dialog.Height=210;$dialog.FormBorderStyle='FixedDialog';$dialog.StartPosition='CenterParent';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false;$dialog.ShowInTaskbar=$false
   $label=New-Object Windows.Forms.Label;$context.Label=$label;$label.Dock='Fill';$label.Padding=New-Object Windows.Forms.Padding 12;$label.Text=if($Downloading){'Загружаются только общедоступные веса модели. Документы и данные пациентов не отправляются.'}else{'Копирование выбранной модели. Исходный файл не изменяется.'}
   $progress=New-Object Windows.Forms.ProgressBar;$context.Progress=$progress;$progress.Dock='Bottom';$progress.Height=20;$progress.Minimum=0;$progress.Maximum=100
   $cancel=New-Object Windows.Forms.Button;$cancel.Text='Отмена';$cancel.Dock='Bottom';$cancel.Height=36;$cancel.Add_Click({$context.Cancelled=$true;$context.Cancel.Cancel()}.GetNewClosure())
   $dialog.Add_FormClosing({$context.Cancelled=$true;$context.Cancel.Cancel()}.GetNewClosure())
   $dialog.Controls.Add($label);$dialog.Controls.Add($progress);$dialog.Controls.Add($cancel);$dialog.Show($Owner)
   $context.OwnerWasEnabled=$Owner.Enabled;$Owner.Enabled=$false;$context.OwnerDisabled=$true
  }catch{Close-MedicalAiAcquisitionContext $context;throw}
 }
 return $context
}
function Close-MedicalAiAcquisitionContext($Context){
 if(-not $Context){return}
 if($Context.Cancel){try{$Context.Cancel.Cancel()}catch{}}
 try{if($Context.HttpClient){$Context.HttpClient.Dispose()}}catch{}
 try{if($null -ne $Context.PreviousTls){[Net.ServicePointManager]::SecurityProtocol=$Context.PreviousTls}}catch{}
 try{if($Context.Dialog -and -not $Context.Dialog.IsDisposed){$Context.Dialog.Dispose()}}catch{}
 try{if($Context.OwnerDisabled -and $Context.Owner -and -not $Context.Owner.IsDisposed){$Context.Owner.Enabled=$Context.OwnerWasEnabled;try{[void]$Context.Owner.Activate()}catch{}}}finally{
  try{if($Context.Cancel){$Context.Cancel.Dispose()}}catch{}
  if($Context.Watch){$Context.Watch.Stop()}
 }
}
function Invoke-MedicalAiAcquisitionPump($Context){
 if($Context.Dialog){[Windows.Forms.Application]::DoEvents()}
 if(($Context.Owner -and $Context.Owner.IsDisposed) -or ($Context.Dialog -and $Context.Dialog.IsDisposed)){$Context.Cancelled=$true}
 if($Context.Cancelled -or $Context.Cancel.IsCancellationRequested){$Context.Cancel.Cancel();throw (New-Object OperationCanceledException 'Установка модели отменена. Исходный файл и ранее установленные модели сохранены.')}
 if($Context.Watch.Elapsed.TotalSeconds -gt $Context.TotalSeconds){$Context.Cancel.Cancel();throw (New-Object TimeoutException 'Загрузка модели превысила 30 минут. Повторите загрузку или выберите готовый GGUF на компьютере.')}
}
function Wait-MedicalAiAcquisitionTask($Task,$Context){
 $watch=[Diagnostics.Stopwatch]::StartNew()
 while(-not $Task.IsCompleted){
  Invoke-MedicalAiAcquisitionPump $Context
  if($watch.Elapsed.TotalSeconds -gt $Context.IoSeconds){$Context.Cancel.Cancel();throw (New-Object TimeoutException 'Источник модели не отвечает. Повторите загрузку или выберите готовый файл GGUF.')}
  [Threading.Thread]::Sleep($(if($watch.ElapsedMilliseconds -lt 40){1}else{15}))
 }
 Invoke-MedicalAiAcquisitionPump $Context
 return $Task.GetAwaiter().GetResult()
}
function Set-MedicalAiAcquisitionProgress($Context,[long]$Current,[long]$Total,[string]$Message){
 Invoke-MedicalAiAcquisitionPump $Context
 if($Context.Label){$percent=if($Total -gt 0){[int][Math]::Min(100,[Math]::Floor(100.0*$Current/$Total))}else{0};if($percent -ne $Context.LastProgress){$Context.LastProgress=$percent;$Context.Label.Text=$Message+' '+$percent+'% ('+[Math]::Round($Current/1048576,1)+' из '+[Math]::Round($Total/1048576,1)+' МБ)';if($Context.Progress){$Context.Progress.Value=$percent}}}
}
function New-MedicalAiAcquisitionHttpClient($Context){
 Add-Type -AssemblyName System.Net.Http
 $handler=New-Object Net.Http.HttpClientHandler;$handler.AllowAutoRedirect=$false;$handler.UseCookies=$false;$handler.UseProxy=$false;$handler.Credentials=$null;$handler.UseDefaultCredentials=$false
 $client=New-Object Net.Http.HttpClient($handler,$true);$client.Timeout=[Threading.Timeout]::InfiniteTimeSpan
 [void]$client.DefaultRequestHeaders.UserAgent.ParseAdd('MedicalConstructor/72 ModelDownload')
 $Context.PreviousTls=[Net.ServicePointManager]::SecurityProtocol;[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
 $Context.HttpClient=$client;$Context.HttpHandler=$handler;return $client
}
function Invoke-MedicalAiModelHttpSend($Client,[Uri]$Uri,$Context){
 $request=New-Object Net.Http.HttpRequestMessage([Net.Http.HttpMethod]::Get,$Uri)
 try{return (Wait-MedicalAiAcquisitionTask ($Client.SendAsync($request,[Net.Http.HttpCompletionOption]::ResponseHeadersRead,$Context.Cancel.Token)) $Context)}finally{$request.Dispose()}
}
function Get-MedicalAiModelHttpResponse($Client,[string]$Address,$Context){
 $uri=Assert-MedicalAiModelDownloadUri $Address
 for($redirect=0;$redirect -le 8;$redirect++){
  $response=Invoke-MedicalAiModelHttpSend $Client $uri $Context;$status=[int]$response.StatusCode
  if($status -in @(301,302,303,307,308)){
   try{
    if($redirect -ge 8 -or -not $response.Headers.Location){throw 'Превышено число перенаправлений загрузки модели.'}
    $next=New-Object Uri($uri,$response.Headers.Location);$uri=Assert-MedicalAiModelDownloadUri $next.AbsoluteUri
   }finally{$response.Dispose()}
   continue
  }
  if($status -ne 200){$response.Dispose();throw ('Поставщик модели вернул HTTP '+$status+'. Повторите загрузку позже или выберите локальный GGUF.')}
  return $response
 }
 throw 'Не удалось получить модель по проверенному адресу.'
}
function Read-MedicalAiModelMetadata($Client,$Manifest,$Context){
 $response=$null;$stream=$null;$memory=New-Object IO.MemoryStream
 try{
  $response=Get-MedicalAiModelHttpResponse $Client ([string]$Manifest.ApiUrl) $Context
  if($response.Content.Headers.ContentLength -gt 2097152){throw 'Официальный каталог модели превышает допустимый размер.'}
  $stream=Wait-MedicalAiAcquisitionTask ($response.Content.ReadAsStreamAsync()) $Context;$buffer=New-Object byte[] 65536
  while($true){$read=Wait-MedicalAiAcquisitionTask ($stream.ReadAsync($buffer,0,$buffer.Length,$Context.Cancel.Token)) $Context;if($read -eq 0){break};if($memory.Length+$read -gt 2097152){throw 'Официальный каталог модели превышает допустимый размер.'};$memory.Write($buffer,0,$read)}
  $utf8=New-Object Text.UTF8Encoding($false,$true);$metadata=$utf8.GetString($memory.ToArray())|ConvertFrom-Json
  return (Resolve-MedicalAiModelDownload $Manifest $metadata)
 }finally{if($stream){$stream.Dispose()};if($response){$response.Dispose()};$memory.Dispose()}
}
function Test-MedicalAiAcquiredGguf([string]$Path,[long]$Maximum=2147483648){
 if(-not [IO.File]::Exists($Path)){throw 'Файл модели GGUF не найден.'}
 $info=New-Object IO.FileInfo $Path
 if($info.Length -lt 1048576 -or $info.Length -gt $Maximum -or ($info.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Нужен обычный файл GGUF размером от 1 МБ до 2 ГБ.'}
 $stream=[IO.File]::Open($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
 try{$header=New-Object byte[] 8;if($stream.Read($header,0,8) -ne 8 -or [Text.Encoding]::ASCII.GetString($header,0,4) -cne 'GGUF' -or [BitConverter]::ToUInt32($header,4) -notin @(2,3)){throw 'Выбранный файл не является поддерживаемой моделью GGUF версии 2 или 3.'}}finally{$stream.Dispose()}
 return $info.Length
}
function Get-MedicalAiAcquisitionFileHash([string]$Path,$Context){
 $stream=[IO.FileStream]::new($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read,65536,[IO.FileOptions]::Asynchronous);$sha=[Security.Cryptography.SHA256]::Create()
 try{$buffer=New-Object byte[] 65536;while($true){$read=Wait-MedicalAiAcquisitionTask ($stream.ReadAsync($buffer,0,$buffer.Length,$Context.Cancel.Token)) $Context;if($read -eq 0){break};[void]$sha.TransformBlock($buffer,0,$read,$buffer,0)};[void]$sha.TransformFinalBlock([byte[]]@(),0,0);return ([BitConverter]::ToString($sha.Hash).Replace('-','').ToLowerInvariant())}finally{$sha.Dispose();$stream.Dispose()}
}
function Copy-MedicalAiAcquisitionStream($InputStream,[string]$Destination,[long]$ExpectedBytes,[long]$Maximum,$Context){
 $output=$null;$sha=[Security.Cryptography.SHA256]::Create();$count=0L
 try{
  $output=[IO.FileStream]::new($Destination,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None,65536,[IO.FileOptions]::Asynchronous);$buffer=New-Object byte[] 65536
  while($true){
   $read=Wait-MedicalAiAcquisitionTask ($InputStream.ReadAsync($buffer,0,$buffer.Length,$Context.Cancel.Token)) $Context;if($read -eq 0){break}
   $count+=$read;if($count -gt $Maximum -or ($ExpectedBytes -gt 0 -and $count -gt $ExpectedBytes)){throw 'Размер полученной модели не соответствует допустимому размеру.'}
   $null=Wait-MedicalAiAcquisitionTask ($output.WriteAsync($buffer,0,$read,$Context.Cancel.Token)) $Context;[void]$sha.TransformBlock($buffer,0,$read,$buffer,0)
   Set-MedicalAiAcquisitionProgress $Context $count $ExpectedBytes 'Получение модели:'
  }
  if($count -lt 1048576 -or ($ExpectedBytes -gt 0 -and $count -ne $ExpectedBytes)){throw 'Модель получена не полностью. Повторите установку.'}
  $null=Wait-MedicalAiAcquisitionTask ($output.FlushAsync($Context.Cancel.Token)) $Context;[void]$sha.TransformFinalBlock([byte[]]@(),0,0)
  return [pscustomobject]@{Bytes=$count;Sha256=([BitConverter]::ToString($sha.Hash).Replace('-','').ToLowerInvariant())}
 }finally{if($output){$output.Dispose()};$sha.Dispose()}
}
function Install-MedicalAiModel($Owner,[string]$AppRoot,[string]$ProfileRoot,[string]$SourcePath=''){
 $context=$null;$modelStream=$null;$response=$null;$partial='';$metadataPartial='';$published='';$publishedHere=$false
 try{
  if(Get-Command Assert-MedicalActiveAccount -CommandType Function -ErrorAction SilentlyContinue){$null=Assert-MedicalActiveAccount}
  if([string]::IsNullOrWhiteSpace($AppRoot) -or -not [IO.Directory]::Exists($AppRoot)){throw 'Папка приложения не найдена.'}
  $app=[IO.Path]::GetFullPath($AppRoot);$folder=Assert-MedicalAiManagedModelPath (Join-Path $app 'ИИ/Модели') $app
  $download=[string]::IsNullOrWhiteSpace($SourcePath);$manifest=$null;$resolved=$null;$length=0L
  if($download){$manifest=Get-MedicalAiModelManifest $app}
  else{
   if(Get-Command Assert-MedicalAccountPath -CommandType Function -ErrorAction SilentlyContinue){Assert-MedicalAccountPath $SourcePath}
   $SourcePath=[IO.Path]::GetFullPath($SourcePath)
   if($SourcePath.StartsWith('\\') -or $SourcePath.StartsWith('//')){throw 'Для локальной установки сначала скопируйте GGUF с сетевого диска на компьютер.'}
   if([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT){$drive=New-Object IO.DriveInfo ([IO.Path]::GetPathRoot($SourcePath));if($drive.DriveType -eq [IO.DriveType]::Network){throw 'Скопируйте модель с сетевого диска на локальный диск перед установкой.'}}
   if([IO.Path]::GetExtension($SourcePath) -ine '.gguf'){throw 'Выберите файл модели с расширением .gguf.'}
   $length=Test-MedicalAiAcquiredGguf $SourcePath
  }
  [void][IO.Directory]::CreateDirectory($folder);$null=Assert-MedicalAiManagedModelPath $folder $app
  $context=New-MedicalAiAcquisitionContext $Owner $download
  if($download){$client=New-MedicalAiAcquisitionHttpClient $context;$resolved=Read-MedicalAiModelMetadata $client $manifest $context;$length=$resolved.Bytes;$response=Get-MedicalAiModelHttpResponse $client $resolved.Uri $context;if($null -ne $response.Content.Headers.ContentLength -and $response.Content.Headers.ContentLength -ne $length){throw 'Размер загрузки противоречит официальным метаданным модели.'};$modelStream=Wait-MedicalAiAcquisitionTask ($response.Content.ReadAsStreamAsync()) $context}
  else{$modelStream=[IO.FileStream]::new($SourcePath,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read,65536,[IO.FileOptions]::Asynchronous)}
  $partial=Join-Path $folder ('.model-'+[guid]::NewGuid().ToString('N')+'.partial');$null=Assert-MedicalAiManagedModelPath $partial $app
  $received=Copy-MedicalAiAcquisitionStream $modelStream $partial $length $(if($download){1073741824L}else{2147483648L}) $context
  $modelStream.Dispose();$modelStream=$null;if($response){$response.Dispose();$response=$null}
  $null=Test-MedicalAiAcquiredGguf $partial
  if($resolved -and ($received.Sha256 -cne $resolved.Sha256 -or $received.Bytes -ne $resolved.Bytes)){throw 'Контрольная сумма загруженной модели не совпала с официальной. Повреждённый файл не установлен.'}
  # Hash the on-disk copy as well; a partial/corrupted disk write cannot publish.
  Set-MedicalAiAcquisitionProgress $context 0 $received.Bytes 'Проверка модели:'
  if((Get-MedicalAiAcquisitionFileHash $partial $context) -cne $received.Sha256){throw 'Проверка сохранённой модели не пройдена.'}
  $leaf='model-'+$received.Sha256.Substring(0,12)+'.gguf';$target=Join-Path $folder $leaf;$null=Assert-MedicalAiManagedModelPath $target $app
  $metadataPath=$target+'.json';$null=Assert-MedicalAiManagedModelPath $metadataPath $app
  if([IO.File]::Exists($target)){
   if((Test-MedicalAiAcquiredGguf $target) -ne $received.Bytes -or (Get-MedicalAiAcquisitionFileHash $target $context) -cne $received.Sha256){throw 'Файл с таким именем уже существует и отличается. Он сохранён без изменений; выберите другую папку программы.'}
   return $target
  }
  Set-MedicalAiAcquisitionProgress $context $received.Bytes $received.Bytes 'Модель проверена:'
  $metadata=[ordered]@{Version=1;Kind=$(if($download){'OfficialPreset'}else{'ImportedFile'});Name=$(if($download){[string]$manifest.Name}else{'Локальная модель GGUF'});FileName=$leaf;Repository=$(if($download){[string]$resolved.Repository}else{''});Revision=$(if($download){[string]$resolved.Revision}else{''});Source=$(if($download){'huggingface.co'}else{'LocalFile'});Sha256=[string]$received.Sha256;Bytes=[long]$received.Bytes;License=$(if($download){[string]$manifest.License}else{''});InstalledUtc=[datetime]::UtcNow.ToString('o',[Globalization.CultureInfo]::InvariantCulture)}
  $metadataPartial=Join-Path $folder ('.model-info-'+[guid]::NewGuid().ToString('N')+'.partial');$null=Assert-MedicalAiManagedModelPath $metadataPartial $app
  [IO.File]::WriteAllText($metadataPartial,($metadata|ConvertTo-Json -Depth 5),(New-Object Text.UTF8Encoding($true)))
  Invoke-MedicalAiAcquisitionPump $context
  # Neither Move can replace a previously installed model. Publish only checked
  # bytes; failures before publication remove the private partial files.
  [IO.File]::Move($partial,$target);$partial='';$published=$target;$publishedHere=$true
  [IO.File]::Move($metadataPartial,$metadataPath);$metadataPartial=''
  $publishedHere=$false
  return $target
 }finally{
  try{if($modelStream){$modelStream.Dispose()}}catch{}
  try{if($response){$response.Dispose()}}catch{}
  foreach($temporary in @($partial,$metadataPartial)){if($temporary -and [IO.File]::Exists($temporary)){try{[IO.File]::Delete($temporary)}catch{}}}
  if($publishedHere -and $published -and [IO.File]::Exists($published)){try{[IO.File]::Delete($published)}catch{}}
  Close-MedicalAiAcquisitionContext $context
 }
}
