﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $root
$log = Join-Path $root 'startup_error.txt'
try {
    if (Test-Path -LiteralPath $log) { Remove-Item -LiteralPath $log -Force }
    $Error.Clear()
    & (Join-Path $root 'constructor.ps1') 2>&1 | ForEach-Object {
        if ($_ -is [System.Management.Automation.ErrorRecord]) { throw $_ }
    }
    if (-not $?) { throw 'constructor.ps1 finished with an error.' }
} catch {
    $safeCode=[guid]::NewGuid().ToString('N')
    try{
        . (Join-Path $root 'core-guard-v71.ps1')
        [void](Initialize-MedicalCoreGuard $root)
        $incident=Write-MedicalCoreIncident $_ 'startup'
        $safeCode=$incident.Incident.Id
    }catch{}
    $details='Startup failed. Incident code: '+$safeCode+'. No passwords or document contents are included in this log.'
    try{[System.IO.File]::WriteAllText($log, $details, [System.Text.UTF8Encoding]::new($true))}catch{}
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("Program could not start. Incident code is saved to startup_error.txt in the program folder.", "Medical Constructor - Startup Error", 'OK', 'Error') | Out-Null
}
