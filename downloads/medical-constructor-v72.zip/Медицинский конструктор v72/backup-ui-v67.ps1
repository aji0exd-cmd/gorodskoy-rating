﻿function Show-MedicalSessionCloseChoice($owner,[bool]$formDirty,[bool]$caseDirty,[string]$backupPath,[bool]$backupAvailable=$true){
 $dialog=New-Object Windows.Forms.Form;$dialog.Text='Сохранить работу перед закрытием';$dialog.Size=New-Object Drawing.Size(780,380)
 $dialog.StartPosition='CenterParent';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false
 $hint=New-Object Windows.Forms.Label;$hint.SetBounds(20,20,730,125)
 $items=@();if($formDirty){$items+='структура формы и Word-шаблоны'};if($caseDirty){$items+='ответы пациента, дневники и эпикриз'}
 $hint.Text='Не сохранены: '+($items -join '; ')+".`r`n«Сохранить и закрыть» обновляет файлы формы и карты. «Закрыть без сохранения» оставляет эти файлы без изменений. Ранее созданные резервные копии остаются в папке «Резервные копии»."
 if($backupAvailable){$hint.Text+="`r`nРезервная копия записана и проверена. «Закрыть с резервной копией» предложит восстановление при следующем запуске."}else{$hint.Text+="`r`nОбновить резервную копию не удалось. Можно продолжить работу или закрыть без сохранения текущих изменений."}
 $dialog.Controls.Add($hint)
 $location=New-Object Windows.Forms.Label;$location.SetBounds(20,152,730,50);$location.Text=if($backupAvailable){'Резервная копия: '+$backupPath}else{'Текущие изменения не подтверждены резервной копией.'};$dialog.Controls.Add($location)
 $result=[pscustomobject]@{Choice='Cancel'}
 $save=New-Object Windows.Forms.Button;$save.Text='Сохранить и закрыть';$save.SetBounds(20,217,350,42);$save.Enabled=$backupAvailable;$dialog.Controls.Add($save)
 $backup=New-Object Windows.Forms.Button;$backup.Text='Закрыть с резервной копией';$backup.SetBounds(390,217,360,42);$backup.Enabled=$backupAvailable;$dialog.Controls.Add($backup)
 $discard=New-Object Windows.Forms.Button;$discard.Text='Закрыть без сохранения';$discard.SetBounds(20,273,350,42);$dialog.Controls.Add($discard)
 $cancel=New-Object Windows.Forms.Button;$cancel.Text='Продолжить работу';$cancel.SetBounds(390,273,360,42);$cancel.DialogResult='Cancel';$dialog.CancelButton=$cancel;$dialog.Controls.Add($cancel)
 $save.Add_Click({$result.Choice='Save';$dialog.DialogResult='OK';$dialog.Close()}.GetNewClosure())
 $backup.Add_Click({$result.Choice='Backup';$dialog.DialogResult='OK';$dialog.Close()}.GetNewClosure())
 $discard.Add_Click({$result.Choice='Discard';$dialog.DialogResult='OK';$dialog.Close()}.GetNewClosure())
 Set-DarkTheme $dialog
 try{[void]$dialog.ShowDialog($owner);return $result.Choice}finally{$dialog.Dispose()}
}
function Confirm-MedicalSessionClose($owner,[string]$reason='UserClosing'){
 if($script:medicalSessionCloseBusy){return $false}
 $script:medicalSessionCloseBusy=$true
 try{
 if(-not $script:medicalWorkspaceReady -and -not $script:medicalBackupEditorDraft -and -not $script:medicalBackupRetainedDraft){return $true}
 $shutdown=$reason -in @('WindowsShutDown','TaskManagerClosing')
 $checkpoint=$null;$backupAvailable=$true
 try{$checkpoint=Write-MedicalSessionBackup}
 catch{
  if($shutdown){return $true}
  $backupAvailable=$false
 }
 if($shutdown){return $true}
 if(-not $backupAvailable){
  $choice=Show-MedicalSessionCloseChoice $owner $true ([bool]$script:medicalWorkspaceReady) '' $false
  if($choice -ne 'Discard'){return $false}
  # Explicit discard remains possible when the checkpoint folder is unavailable.
  # Never remove previously saved cards, forms or backup archives.
  try{Archive-MedicalPendingBackup}catch{}
  return $true
 }
 $payload=$checkpoint.Payload
 $formDirty=([string]$payload.FormSignature -cne [string]$script:medicalBackupFormSavedSignature)
 $caseDirty=$script:medicalWorkspaceReady -and ([string]$payload.CaseSignature -cne [string]$script:medicalBackupCaseSavedSignature)
 if($checkpoint.Payload.Data.EditorDraft){$formDirty=$true}
 if(-not $formDirty -and -not $caseDirty){
  try{[void](Write-MedicalSessionBackup $true);return $true}catch{[void][Windows.Forms.MessageBox]::Show($owner,$_.Exception.Message,'Резервное сохранение');return $false}
 }
 $choice=Show-MedicalSessionCloseChoice $owner $formDirty $caseDirty $checkpoint.Path
 if($choice -eq 'Cancel'){return $false}
 if($choice -eq 'Discard'){
  # Keep checkpoints as manual archives, without automatically restoring the
  # discarded session at next launch. No ordinary save action is called.
  try{Archive-MedicalPendingBackup}catch{
   [void][Windows.Forms.MessageBox]::Show($owner,'Файлы формы и карты не изменены. Резервную копию не удалось перенести в архив; при следующем запуске может появиться предложение восстановления.','Закрытие без сохранения','OK','Information')
  }
  return $true
 }
 if($choice -eq 'Backup'){return $true}
 if($choice -ne 'Save'){return $false}
 if($checkpoint.Payload.Data.EditorDraft){
  [void][Windows.Forms.MessageBox]::Show($owner,'Сначала примените изменения в редакторе формы и Word или закройте программу с резервной копией.','Незавершённый редактор','OK','Information')
  return $false
 }
 try{
  # Only successful save hooks update the signatures. Canceled pickers do not.
  if($formDirty){
   $saveForm=Get-Command Invoke-MedicalSaveForm -CommandType Function -ErrorAction Stop
   & $saveForm | Out-Null
   $next=Write-MedicalSessionBackup
   if([string]$next.Payload.FormSignature -cne [string]$script:medicalBackupFormSavedSignature -or -not [IO.File]::Exists([string]$script:activeMedicalFormPath)){return $false}
  }
  if($caseDirty){
   $saveCase=Get-Command Save-Case -CommandType Function -ErrorAction Stop
   & $saveCase | Out-Null
   $next=Write-MedicalSessionBackup
   if([string]$next.Payload.CaseSignature -cne [string]$script:medicalBackupCaseSavedSignature -or -not [IO.File]::Exists([string]$script:caseFile)){return $false}
  }
  [void](Write-MedicalSessionBackup $true)
  return $true
 }catch{
  [void][Windows.Forms.MessageBox]::Show($owner,'Сохранение не завершено. Программа остаётся открытой: '+$_.Exception.Message,'Закрытие программы','OK','Warning')
  return $false
 }
 }finally{$script:medicalSessionCloseBusy=$false}
}
function Show-MedicalBackupRecoveryChoice($owner,$backup){
 $dialog=New-Object Windows.Forms.Form;$dialog.Text='Восстановление сохранённой работы';$dialog.Size=New-Object Drawing.Size(780,345)
 $dialog.StartPosition='CenterParent';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false
 $hint=New-Object Windows.Forms.Label;$hint.SetBounds(20,20,730,125)
 $name=[string]$backup.Payload.Data.Form.Name
 $hint.Text='Найдена незавершённая работа: '+$name+".`r`nКопия содержит структуру формы, Word-шаблоны, ответы пациента, дневники и эпикриз. Восстановление вернёт их в рабочее окно. При начале новой работы эта копия останется в папке «Резервные копии»."
 if($backup.Payload.Data.EditorDraft){$hint.Text+="`r`nВ копии есть незавершённые изменения редактора формы и Word."}
 $dialog.Controls.Add($hint)
 $path=New-Object Windows.Forms.Label;$path.SetBounds(20,152,730,52);$path.Text=$backup.Path;$dialog.Controls.Add($path)
 $result=[pscustomobject]@{Choice='Later'}
 $restore=New-Object Windows.Forms.Button;$restore.Text='Восстановить работу';$restore.SetBounds(20,231,220,42);$dialog.Controls.Add($restore)
 $new=New-Object Windows.Forms.Button;$new.Text='Начать новую';$new.SetBounds(255,231,220,42);$dialog.Controls.Add($new)
 $later=New-Object Windows.Forms.Button;$later.Text='Решить позже';$later.SetBounds(490,231,260,42);$later.DialogResult='Cancel';$dialog.CancelButton=$later;$dialog.Controls.Add($later)
 $restore.Add_Click({$result.Choice='Restore';$dialog.DialogResult='OK';$dialog.Close()}.GetNewClosure())
 $new.Add_Click({$result.Choice='New';$dialog.DialogResult='OK';$dialog.Close()}.GetNewClosure())
 Set-DarkTheme $dialog
 try{[void]$dialog.ShowDialog($owner);return $result.Choice}finally{$dialog.Dispose()}
}
function Start-MedicalBackupRecovery($owner){
 try{
  [void](Initialize-MedicalSessionBackup)
  $pending=Get-MedicalPendingBackup
  if(-not $pending){return 'New'}
  $choice=Show-MedicalBackupRecoveryChoice $owner $pending
  if($choice -eq 'Later'){$script:medicalBackupPendingDeferred=$true;return 'Later'}
  if($choice -eq 'New'){Archive-MedicalPendingBackup;$script:medicalBackupPendingDeferred=$false;return 'New'}
  if($choice -eq 'Restore'){
   [void](Restore-MedicalSessionBackup $pending)
   $script:medicalBackupPendingDeferred=$false
   return 'Restored'
  }
  return 'Later'
 }catch{
  [void][Windows.Forms.MessageBox]::Show($owner,'Восстановление не завершено. Резервные файлы сохранены: '+$_.Exception.Message,'Резервная копия','OK','Warning')
  return 'Later'
 }
}
