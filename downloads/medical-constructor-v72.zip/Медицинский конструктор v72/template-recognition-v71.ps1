﻿# v71: offline label recognition. Rules propose changes; only reviewed rows are applied.
# No model download, network request, medical interpretation or source file write.
function Normalize-MedicalRecognitionLabel([string]$text){
 if([string]::IsNullOrWhiteSpace($text)){return ''}
 $text=$text.Normalize([Text.NormalizationForm]::FormKC).ToLowerInvariant().Replace('ё','е')
 $text=[regex]::Replace($text,'^\s*(?:\d+(?:\.\d+)*[.)]\s*|[ivx]+[.)]\s*)','')
 $text=[regex]::Replace($text,'\([^)]*\)',' ')
 return [regex]::Replace($text,'[^\p{L}\p{N}]','')
}
function Get-MedicalRecognitionFingerprint($model,$schema){
 $builder=New-Object Text.StringBuilder
 foreach($part in $model.PartOrder){[void]$builder.Append([string]$part);[void]$builder.Append([char]0);[void]$builder.Append($model.Parts[$part].Xml.OuterXml);[void]$builder.Append([char]0)}
 [void]$builder.Append(($schema|ConvertTo-Json -Depth 40 -Compress))
 $sha=[Security.Cryptography.SHA256]::Create()
 try{return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($builder.ToString())))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
}
function Copy-MedicalRecognitionModel($model){
 $copy=[pscustomobject]@{SourcePath=[string]$model.SourcePath;TemplateExtension=[string]$model.TemplateExtension;Entries=(New-Object Collections.ArrayList);Parts=@{};PartOrder=@($model.PartOrder);Paragraphs=(New-Object Collections.ArrayList)}
 foreach($entry in $model.Entries){[void]$copy.Entries.Add([pscustomobject]@{Name=[string]$entry.Name;Bytes=([byte[]]$entry.Bytes.Clone());LastWriteTime=$entry.LastWriteTime;ExternalAttributes=$entry.ExternalAttributes})}
 foreach($part in $model.PartOrder){$copy.Parts[$part]=[pscustomobject]@{Xml=$model.Parts[$part].Xml.CloneNode($true);Modified=[bool]$model.Parts[$part].Modified}}
 Update-MedicalEditorParagraphs $copy
 return $copy
}
function Get-MedicalRecognitionDefinitions($schema){
 $hasFields=@(Get-UniversalFields $schema).Count -gt 0
 $source=if($hasFields){$schema}else{New-UniversalConfig}
 $definitions=New-Object Collections.ArrayList;$markers=@{}
 foreach($section in $source.Sections){foreach($field in $section.Fields){
  $marker=[string]$field.Marker;if($markers.ContainsKey($marker)){continue};$markers[$marker]=$true
  [void]$definitions.Add([pscustomobject]@{Marker=$marker;Label=[string]$field.Label;Field=(Copy-UniversalObject $field);SectionId=[string]$section.Id;SectionTitle=[string]$section.Title;Aliases=@([string]$field.Label,[string]$field.Marker);System=$false})
 }}
 if(-not $hasFields){foreach($extra in @(@('FINAL_DIAGNOSIS','Заключительный диагноз'),@('EXAMINATION_RESULTS','Результаты обследования'),@('TREATMENT_RESULTS','Результаты лечения'),@('RECOMMENDATIONS','Рекомендации'),@('DIARY_PROGRESS','Динамика состояния'))){
  $marker=$extra[0];$field=New-UniversalField ('recognized_'+$marker.ToLowerInvariant()) $extra[1] $marker 'multiline';$field.Required=$false
  [void]$definitions.Add([pscustomobject]@{Marker=$marker;Label=$extra[1];Field=$field;SectionId=('recognized_'+$marker.ToLowerInvariant());SectionTitle=$extra[1];Aliases=@($extra[1],$marker);System=$false})
 }}
 $aliasMap=@{
  PATIENT_NAME=@('Ф.И.О.','ФИО пациента','Фамилия, имя, отчество','Фамилия имя отчество пациента','Пациент');PATIENT_BIRTH=@('Дата рождения','Дата рождения пациента');PATIENT_ADDRESS=@('Адрес','Адрес регистрации','Адрес проживания','Место жительства');
  COMPLAINTS=@('Жалобы','Жалобы при поступлении');DISEASE_HISTORY=@('Анамнез заболевания','Анамнез настоящего заболевания','История настоящего заболевания','Anamnesis morbi');EXAMINATION=@('Объективное состояние','Объективный статус','Объективно','Общий осмотр','Осмотр пациента','Осмотр пациента на момент поступления','Status praesens');
  PRELIMINARY_DIAGNOSIS=@('Предварительный диагноз','Диагноз при поступлении');EXAMINATION_PLAN=@('План обследования','План обследований');PRESCRIPTIONS=@('Назначения','Лечение и назначения','План лечения');FINAL_DIAGNOSIS=@('Заключительный диагноз','Клинический диагноз','Выписной диагноз');EXAMINATION_RESULTS=@('Результаты обследования','Результаты обследований','Данные обследований');TREATMENT_RESULTS=@('Результаты лечения','Проведенное лечение','Проведённое лечение');RECOMMENDATIONS=@('Рекомендации','Рекомендации при выписке');
  DIARY_COMPLAINTS=@('Жалобы','Жалобы на момент осмотра');DIARY_EXAMINATION=@('Объективное состояние','Объективный статус','Объективно','Осмотр');DIARY_PROGRESS=@('Динамика состояния','Динамика');DIARY_TREATMENT=@('Лечение и назначения','Назначения','Лечение')
 }
 foreach($definition in $definitions){
  if($aliasMap.ContainsKey($definition.Marker)){$definition.Aliases+=@($aliasMap[$definition.Marker])}
  if($definition.Field -and $definition.Field.System){$roleMarker=switch([string]$definition.Field.System){'name'{'PATIENT_NAME'}'birth'{'PATIENT_BIRTH'}'address'{'PATIENT_ADDRESS'}default{''}};if($roleMarker){$definition.Aliases+=@($aliasMap[$roleMarker])}}
 }
 # System dates are rendered from the case, not stored as reusable patient answers.
 [void]$definitions.Add([pscustomobject]@{Marker='ADMISSION_DATETIME';Label='Дата и время поступления';Field=$null;SectionId='';SectionTitle='';Aliases=@('Дата и время поступления','Дата и время осмотра','Дата осмотра','Дата поступления','Дата и время приема','Дата и время приёма');System=$true})
 foreach($definition in $definitions){$definition.Aliases=@($definition.Aliases|ForEach-Object {Normalize-MedicalRecognitionLabel $_}|Where-Object {$_}|Select-Object -Unique)}
 return $definitions
}
function New-MedicalRecognitionRow([string]$id,$paragraph,[string]$label,[string]$marker,[string]$action,[int]$start,[int]$length,[string]$reason,[bool]$selected=$false){
 $text=if($paragraph){[string]$paragraph.Text}else{''}
 return [pscustomobject]@{Id=$id;ParagraphId=$(if($paragraph){[string]$paragraph.Id}else{''});Part=$(if($paragraph){[string]$paragraph.Part}else{'word/document.xml'});Label=$label;Marker=$marker;Action=$action;Start=$start;Length=$length;OriginalText=$text;ReplacementText='';Reason=$reason;Selected=$selected;ManualField=$false;NewFieldLabel=''}
}
function Update-MedicalRecognitionRow($row){
 if(-not $row.Marker){$row.ReplacementText='Выберите маркер или создайте поле';$row.Selected=$false;return}
 if([string]$row.Marker -cnotmatch '^[A-Z][A-Z0-9_]*$'){throw 'Некорректный маркер распознавания.'}
 $token='{{'+$row.Marker+'}}'
 if($row.Action -ceq 'replace' -and $row.Length -eq 0 -and $row.Start -gt 0 -and $row.OriginalText[$row.Start-1] -notmatch '\s'){$token=' '+$token}
 if($row.Action -eq 'add-date'){$row.ReplacementText='Дата и время поступления: '+$token;return}
 if($row.Action -ne 'replace' -or $row.Start -lt 0 -or $row.Length -lt 0 -or $row.Start+$row.Length -gt $row.OriginalText.Length){throw 'Некорректный диапазон распознавания.'}
 $row.ReplacementText=$row.OriginalText.Substring(0,$row.Start)+$token+$row.OriginalText.Substring($row.Start+$row.Length)
}
function Get-MedicalTemplateRecognitionPlan($model,$schema){
 $definitions=@(Get-MedicalRecognitionDefinitions $schema);$index=@{}
 foreach($definition in $definitions){foreach($alias in $definition.Aliases){if(-not $index.ContainsKey($alias)){$index[$alias]=@()};$index[$alias]+=@($definition)}}
 $rows=New-Object Collections.ArrayList;$warnings=New-Object Collections.ArrayList;$used=@{};$number=0;$allText=(@($model.Paragraphs|ForEach-Object {[string]$_.Text}) -join "`n")
 $datePresent=($allText -match '\{\{ADMISSION_DATETIME\}\}' -or ($allText -match '\{\{ADMISSION_DATE\}\}' -and $allText -match '\{\{ADMISSION_TIME\}\}'))
 # Table lookups refer to real paragraph node identity, never to screen positions.
 $paragraphByNode=New-Object 'Collections.Generic.Dictionary[Xml.XmlNode,object]'
 foreach($paragraph in $model.Paragraphs){$paragraphByNode[$paragraph.Node]=$paragraph}
 foreach($paragraph in $model.Paragraphs){
  if($paragraph.Part -cne 'word/document.xml' -or $used.ContainsKey($paragraph.Id)){continue}
  $text=[string]$paragraph.Text
  if([string]::IsNullOrWhiteSpace($text) -or $text.Contains('{{')){continue}
  $label='';$tailStart=-1;$separator=[regex]::Match($text,'^\s*([^:\r\n]{1,100}?)\s*[:：]\s*')
  if($separator.Success){$label=$separator.Groups[1].Value.Trim();$tailStart=$separator.Length}
  else{$label=$text.Trim().TrimEnd(':','：')}
  $key=Normalize-MedicalRecognitionLabel $label;$definitionsForLabel=@();if($index.ContainsKey($key)){$definitionsForLabel=@($index[$key])}
  if(-not $definitionsForLabel.Count -and -not $separator.Success){continue}
  if($definitionsForLabel.Count -eq 1 -and ($allText.Contains('{{'+$definitionsForLabel[0].Marker+'}}') -or ($definitionsForLabel[0].Marker -ceq 'ADMISSION_DATETIME' -and $datePresent))){continue}
  if($label.Length -gt 100 -or $label -notmatch '\p{L}'){continue}
  if(-not $paragraph.Editable){[void]$warnings.Add(('Не изменён сложный элемент: '+$label+' — '+$paragraph.Reason));continue}
  $target=$paragraph;$start=$tailStart;$length=0;$reason='';$selected=$false
  if($tailStart -ge 0 -and $tailStart -lt $text.Length){$length=$text.Length-$tailStart;$reason='Заменить текст после подписи. Проверьте, что это ответ, а не постоянная часть шаблона.';$selected=($text.Substring($tailStart) -match '^[\s_.…\-–—\[\]<>]*$')}
  elseif($tailStart -ge 0 -and $definitionsForLabel.Count -eq 0){$start=$text.Length;$reason='Подпись не распознана. Выберите маркер или создайте поле.'}
  else{
   $next=$null;$ns=Get-MedicalEditorNamespace $paragraph.Node.OwnerDocument;$cell=$paragraph.Node.ParentNode
   if($cell -and $cell.LocalName -ceq 'tc'){
    $nextCell=$cell.NextSibling
    while($nextCell -and $nextCell -isnot [Xml.XmlElement]){$nextCell=$nextCell.NextSibling}
    if($nextCell -and $nextCell.NamespaceURI -ceq $cell.NamespaceURI -and $nextCell.LocalName -ceq 'tc'){
     $candidates=@($nextCell.SelectNodes('./w:p',$ns))
     if($candidates.Count -eq 1 -and $paragraphByNode.ContainsKey($candidates[0])){$next=$paragraphByNode[$candidates[0]]}
    }
   }
   if(-not $next){
    $nextNode=$paragraph.Node.NextSibling;while($nextNode -and $nextNode -isnot [Xml.XmlElement]){$nextNode=$nextNode.NextSibling}
    if($nextNode -and $nextNode.NamespaceURI -ceq $paragraph.Node.NamespaceURI -and $nextNode.LocalName -ceq 'p' -and $paragraphByNode.ContainsKey($nextNode)){$next=$paragraphByNode[$nextNode]}
   }
   if($next -and $next.Editable -and -not $used.ContainsKey($next.Id) -and -not $next.Text.Contains('{{')){
    $nextKey=Normalize-MedicalRecognitionLabel $next.Text
    if($index.ContainsKey($nextKey) -or ($next.Text -match '^\s*[^:\r\n]{1,100}[:：]')){$next=$null}
   }else{$next=$null}
   if($next){$target=$next;$start=0;$length=$next.Text.Length;$selected=($next.Text -match '^[\s_.…\-–—\[\]<>]*$');$reason='Заменить абзац или ячейку после подписи. Непустой ответ требует отдельного выбора.'}
   else{$start=$text.Length;$length=0;$reason='Добавить маркер после подписи в этом абзаце.';$selected=$definitionsForLabel.Count -eq 1}
  }
  if($used.ContainsKey($target.Id)){continue}
  if($length -gt 0 -and $target.Text.Substring($start,$length) -match '[\r\n\t]'){[void]$warnings.Add(('Измените вручную многострочный ответ или табуляцию: '+$label));continue}
  if($rows.Count -ge 2000){[void]$warnings.Add('Показаны первые 2000 подписей. Остальные поля отредактируйте вручную.');break}
  $marker=if($definitionsForLabel.Count -eq 1){[string]$definitionsForLabel[0].Marker}else{''}
  if($definitionsForLabel.Count -gt 1){$reason='Неоднозначная подпись: '+(($definitionsForLabel|ForEach-Object {$_.Marker}) -join ', ')+'. Выберите маркер вручную.';$selected=$false}
  elseif($definitionsForLabel.Count -eq 0){$reason='Подпись не распознана. Выберите маркер или создайте поле.';$selected=$false}
  $number++;$row=New-MedicalRecognitionRow ('recognition_'+$number) $target $label $marker 'replace' $start $length $reason $selected
  Update-MedicalRecognitionRow $row;[void]$rows.Add($row);$used[$target.Id]=$true
 }

 if(-not $datePresent -and @($rows|Where-Object {$_.Marker -ceq 'ADMISSION_DATETIME'}).Count -eq 0){
  $number++;$row=New-MedicalRecognitionRow ('recognition_'+$number) $null 'Дата и время поступления' 'ADMISSION_DATETIME' 'add-date' 0 0 'В шаблоне не найдена дата. Отметьте строку, чтобы добавить дату и время после заголовка.' $false
  Update-MedicalRecognitionRow $row;[void]$rows.Add($row)
 }
 $missing=@(foreach($definition in $definitions){if(-not $definition.System -and -not $allText.Contains('{{'+$definition.Marker+'}}') -and @($rows|Where-Object {$_.Marker -ceq $definition.Marker}).Count -eq 0){$definition.Label+' — {{'+$definition.Marker+'}}'}})
 return [pscustomobject]@{Fingerprint=(Get-MedicalRecognitionFingerprint $model $schema);Rows=@($rows);Definitions=$definitions;Warnings=@($warnings);Missing=$missing;NewSchema=(@(Get-UniversalFields $schema).Count -eq 0);DatePresent=$datePresent}
}
function Set-MedicalRecognitionTextRange($model,$paragraph,[int]$start,[int]$length,[string]$replacement){
 $ns=Get-MedicalEditorNamespace $paragraph.Node.OwnerDocument
 $reason=Get-MedicalEditorParagraphRestriction $paragraph.Node $ns
 if($reason -or -not $paragraph.Editable){throw 'Этот элемент Word нельзя безопасно заменить.'}
 $old=[string]$paragraph.Text
 if($start -lt 0 -or $length -lt 0 -or $start+$length -gt $old.Length){throw 'Диапазон текста больше не существует.'}
 # Normal paragraphs can include line breaks or tabs; their untouched XML remains intact.
 # Replacing a range through such control nodes would need structural editing, so refuse it.
 $nodes=@($paragraph.Node.SelectNodes('./w:r/w:t|./w:r/w:br|./w:r/w:cr|./w:r/w:tab',$ns));$offset=0;$anchor=$null;$anchorPosition=0
 foreach($node in $nodes){$span=if($node.LocalName -ceq 't'){$node.InnerText.Length}elseif($node.LocalName -ceq 'tab'){1}else{2}
  if($node.LocalName -cne 't' -and $offset -lt $start+$length -and $offset+$span -gt $start){throw 'Заменяемый текст содержит перенос или табуляцию. Измените этот абзац вручную.'}
  if(-not $anchor -and $node.LocalName -ceq 't' -and $start -ge $offset -and ($start -lt $offset+$span -or ($length -eq 0 -and $start -eq $offset+$span))){$anchor=$node;$anchorPosition=$start-$offset}
  $offset+=$span
 }
 if($offset -ne $old.Length){throw 'Структура текста изменилась. Запустите распознавание повторно.'}
 if(-not $anchor){
  if($start -ne $old.Length -or $length -ne 0){throw 'Не найдена точка вставки маркера.'}
  $xml=$paragraph.Node.OwnerDocument;$run=$xml.CreateElement('w','r',$paragraph.Node.NamespaceURI);$lastRun=$paragraph.Node.SelectSingleNode('./w:r[last()]',$ns)
  if($lastRun){$style=$lastRun.SelectSingleNode('./w:rPr',$ns);if($style){[void]$run.AppendChild($style.CloneNode($true))}}
  $anchor=$xml.CreateElement('w','t',$paragraph.Node.NamespaceURI);[void]$run.AppendChild($anchor);[void]$paragraph.Node.AppendChild($run);$anchorPosition=0
 }
 $offset=0
 foreach($node in $nodes){$span=if($node.LocalName -ceq 't'){$node.InnerText.Length}elseif($node.LocalName -ceq 'tab'){1}else{2}
  if($node.LocalName -ceq 't'){
   $left=[Math]::Max(0,$start-$offset);$right=[Math]::Min($span,$start+$length-$offset)
   if($right -gt $left){$node.InnerText=$node.InnerText.Substring(0,$left)+$node.InnerText.Substring($right)}
  }
  $offset+=$span
 }
 $anchor.InnerText=$anchor.InnerText.Insert($anchorPosition,$replacement)
 foreach($node in $paragraph.Node.SelectNodes('./w:r/w:t',$ns)){$space=$node.OwnerDocument.CreateAttribute('xml','space','http://www.w3.org/XML/1998/namespace');$space.Value='preserve';[void]$node.Attributes.Append($space)}
 $paragraph.Text=$old.Substring(0,$start)+$replacement+$old.Substring($start+$length);$model.Parts[$paragraph.Part].Modified=$true
}
function Set-MedicalRecognitionCustomField($plan,$row,[string]$label=''){
 if([string]::IsNullOrWhiteSpace($label)){$label=[string]$row.Label}
 $label=$label.Trim();if(-not $label -or $label.Length -gt 100){throw 'Укажите подпись поля не длиннее 100 символов.'}
 $sha=[Security.Cryptography.SHA256]::Create()
 try{$suffix=([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes((Normalize-MedicalRecognitionLabel $label))))).Replace('-','').Substring(0,12)}finally{$sha.Dispose()}
 $marker='FIELD_AUTO_'+$suffix;$existing=@($plan.Definitions|Where-Object {$_.Marker -ceq $marker})
 $row.Marker=$marker;$row.ManualField=$true;$row.NewFieldLabel=$label;$row.Selected=$true
 if(-not $existing.Count){
  $field=New-UniversalField ('recognized_'+$suffix.ToLowerInvariant()) $label $marker 'multiline';$field.Required=$false
  $plan.Definitions+=@([pscustomobject]@{Marker=$marker;Label=$label;Field=$field;SectionId='recognized_custom';SectionTitle='Распознанные поля';Aliases=@((Normalize-MedicalRecognitionLabel $label));System=$false})
 }
 Update-MedicalRecognitionRow $row
}
function Apply-MedicalTemplateRecognitionPlan($model,$schema,$plan,[string[]]$selectedIds){
 if((Get-MedicalRecognitionFingerprint $model $schema) -cne $plan.Fingerprint){throw 'Документ или форма изменились. Запустите распознавание повторно.'}
 $rows=@($plan.Rows|Where-Object {$_.Id -cin $selectedIds})
 if(-not $rows.Count){throw 'Отметьте хотя бы одну замену.'}
 if(@($selectedIds|Select-Object -Unique).Count -ne $selectedIds.Count -or $rows.Count -ne $selectedIds.Count){throw 'Список выбранных замен изменился.'}
 $definitions=@{};foreach($definition in $plan.Definitions){if($definitions.ContainsKey($definition.Marker)){throw 'Маркер распознавания повторяется.'};$definitions[$definition.Marker]=$definition}
 $copy=Copy-MedicalRecognitionModel $model;$candidate=Copy-MedicalFormSchema $schema;$applied=@{};$usedParagraphs=@{}
 foreach($row in $rows){
  if(-not $definitions.ContainsKey([string]$row.Marker)){throw 'Для выбранной строки укажите известный маркер или создайте поле.'}
  Update-MedicalRecognitionRow $row
  if($row.Action -ceq 'add-date'){
   if($row.Marker -cne 'ADMISSION_DATETIME'){throw 'Некорректная системная дата.'};continue
  }
  if($usedParagraphs.ContainsKey($row.ParagraphId)){throw 'Для одного абзаца выбрано несколько замен.'};$usedParagraphs[$row.ParagraphId]=$true
  $paragraph=@($copy.Paragraphs|Where-Object {$_.Id -ceq $row.ParagraphId -and $_.Part -ceq $row.Part})
  if($paragraph.Count -ne 1 -or $paragraph[0].Text -cne $row.OriginalText){throw 'Текст выбранного абзаца изменился. Запустите распознавание повторно.'}
  $replacement=$row.ReplacementText.Substring($row.Start,$row.ReplacementText.Length-$row.OriginalText.Length+$row.Length)
  Set-MedicalRecognitionTextRange $copy $paragraph[0] $row.Start $row.Length $replacement;$applied[$row.Marker]=$true
 }
 foreach($row in @($rows|Where-Object {$_.Action -ceq 'add-date'})){
  $first=@($copy.Paragraphs|Where-Object {$_.Part -ceq 'word/document.xml' -and $_.Node.ParentNode.LocalName -ceq 'body'})|Select-Object -First 1
  if(-not $first){throw 'В документе нет обычного абзаца для даты. Добавьте его вручную.'}
  [void](Add-MedicalTemplateParagraph $copy 'word/document.xml' $first.Id $row.ReplacementText);$applied[$row.Marker]=$true
 }
 Update-MedicalEditorParagraphs $copy
 if($plan.NewSchema){
  $matched=@($applied.Keys|Where-Object {-not $definitions[$_].System})
  if(-not $matched.Count){throw 'Не распознаны поля формы. Выберите маркеры для подписей или создайте поля вручную.'}
  $candidate.Sections=@();$sections=@{}
  foreach($definition in $plan.Definitions){
   if($definition.System -or -not $applied.ContainsKey($definition.Marker)){continue}
   $sectionId=[string]$definition.SectionId
   if(-not $sections.ContainsKey($sectionId)){$sections[$sectionId]=[pscustomobject]@{Id=$sectionId;Title=[string]$definition.SectionTitle;Fields=@()};$candidate.Sections+=@($sections[$sectionId])}
   $field=Copy-UniversalObject $definition.Field;$field.WordId='';$field.Required=$false
   if($field.Type -in @('choice','choice_detail','multi','repeat') -and @($field.Options).Count -eq 0){$field.Type='multiline'}
   $sections[$sectionId].Fields+=@($field)
  }
  $candidate.AutoTemplate=$false;$candidate|Add-Member -NotePropertyName PreserveTemplateFormatting -NotePropertyValue $true -Force
  Assert-MedicalEditorTemplateCoverage $candidate $copy
 }else{
  foreach($row in $rows){
   if($definitions[$row.Marker].System -or @((Get-UniversalFields $candidate)|Where-Object {$_.Marker -ceq $row.Marker}).Count){continue}
   $definition=$definitions[$row.Marker];$section=@($candidate.Sections|Where-Object {$_.Id -ceq 'recognized_custom'})|Select-Object -First 1
   if(-not $section){$section=[pscustomobject]@{Id='recognized_custom';Title='Распознанные поля';Fields=@()};$candidate.Sections+=@($section)}
   $section.Fields+=@(Copy-UniversalObject $definition.Field)
  }
  Assert-UniversalConfig $candidate
 }
 return [pscustomobject]@{Model=$copy;Schema=$candidate;AppliedCount=$rows.Count}
}
