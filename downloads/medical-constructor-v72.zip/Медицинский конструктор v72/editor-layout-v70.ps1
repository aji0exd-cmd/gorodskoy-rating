﻿# v70: independently resizable document, fields, properties and structure panes.
# Splitter constraints are derived from the current client area, including the
# transient sizes WinForms uses while docking and scaling a window.
function Get-MedicalEditorSplitterLimits([int]$length,[int]$splitterWidth,[int]$panel1Minimum,[int]$panel2Minimum,[double]$scale=1){
 if([double]::IsNaN($scale) -or [double]::IsInfinity($scale) -or $scale -le 0){$scale=1}
 $available=[Math]::Max(0,$length-[Math]::Max(0,$splitterWidth))
 $first=[Math]::Min([Math]::Max(0,[int][Math]::Round($panel1Minimum*$scale)),[int][Math]::Floor($available*0.47))
 $second=[Math]::Min([Math]::Max(0,[int][Math]::Round($panel2Minimum*$scale)),[Math]::Max(0,$available-$first))
 return [pscustomobject]@{Available=$available;FirstMinimum=$first;SecondMinimum=$second;MaximumDistance=($available-$second)}
}
function Set-MedicalEditorSplitter($split,[double]$ratio,[bool]$initialize,[int]$firstMinimum,[int]$secondMinimum,[double]$scale=1){
 $length=if([string]$split.Orientation -eq 'Horizontal'){$split.ClientSize.Height}else{$split.ClientSize.Width}
 $limits=Get-MedicalEditorSplitterLimits $length $split.SplitterWidth $firstMinimum $secondMinimum $scale
 if($limits.Available -lt 2){return}
 # Clear both old constraints before changing either bound. Otherwise a small
 # intermediate docked size can reject a perfectly valid final arrangement.
 $split.Panel1MinSize=0;$split.Panel2MinSize=0
 $distance=if($initialize){[int][Math]::Round($limits.Available*$ratio)}else{[int]$split.SplitterDistance}
 $distance=[Math]::Max($limits.FirstMinimum,[Math]::Min($limits.MaximumDistance,$distance))
 if($split.SplitterDistance -ne $distance){$split.SplitterDistance=$distance}
 $split.Panel1MinSize=$limits.FirstMinimum;$split.Panel2MinSize=$limits.SecondMinimum
}
function Set-MedicalEditorWindowBounds($dialog,$owner){
 $width=1520;$height=940;$minimumWidth=1100;$minimumHeight=740
 try{
  $screen=if($owner){[Windows.Forms.Screen]::FromControl($owner)}else{[Windows.Forms.Screen]::PrimaryScreen}
  $width=[Math]::Min($width,[Math]::Max(640,$screen.WorkingArea.Width-24))
  $height=[Math]::Min($height,[Math]::Max(480,$screen.WorkingArea.Height-24))
  $minimumWidth=[Math]::Min($minimumWidth,$width);$minimumHeight=[Math]::Min($minimumHeight,$height)
 }catch{}
 $dialog.Size=New-Object Drawing.Size($width,$height)
 $dialog.MinimumSize=New-Object Drawing.Size($minimumWidth,$minimumHeight)
}
function Update-MedicalEditorWorkspaceLayout($workspace,[bool]$initialize=$false){
 if($workspace.State.Resizing -or $workspace.Root.IsDisposed){return}
 $workspace.State.Resizing=$true
 try{
  $scale=[double]$workspace.State.Scale
  Set-MedicalEditorSplitter $workspace.OuterSplit 0.44 $initialize 330 470 $scale
  Set-MedicalEditorSplitter $workspace.RightSplit 0.38 $initialize 190 180 $scale
  Set-MedicalEditorSplitter $workspace.FieldsSplit 0.45 $initialize 175 230 $scale
 }finally{$workspace.State.Resizing=$false}
}
function New-MedicalEditorWorkspaceLayout($dialog){
 $root=New-Object Windows.Forms.TableLayoutPanel;$root.Name='medicalEditorWorkspace';$root.Dock='Fill';$root.ColumnCount=1;$root.RowCount=2;$root.Padding=New-Object Windows.Forms.Padding(4);$root.Size=New-Object Drawing.Size($dialog.ClientSize.Width,$dialog.ClientSize.Height)
 [void]$root.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)))
 [void]$root.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',72)))
 $width=[Math]::Max(800,$dialog.ClientSize.Width-8);$height=[Math]::Max(420,$dialog.ClientSize.Height-80)
 $outer=New-Object Windows.Forms.SplitContainer;$outer.Name='medicalEditorDocumentSplit';$outer.Orientation='Vertical';$outer.Size=New-Object Drawing.Size($width,$height);$outer.SplitterWidth=7;$outer.Dock='Fill'
 Set-MedicalEditorSplitter $outer 0.44 $true 330 470
 $right=New-Object Windows.Forms.SplitContainer;$right.Name='medicalEditorStructureSplit';$right.Orientation='Horizontal';$right.Size=New-Object Drawing.Size([Math]::Max(460,$outer.Panel2.ClientSize.Width),$height);$right.SplitterWidth=7;$right.Dock='Fill'
 Set-MedicalEditorSplitter $right 0.38 $true 190 180
 $fields=New-Object Windows.Forms.SplitContainer;$fields.Name='medicalEditorPropertiesSplit';$fields.Orientation='Vertical';$fields.Size=New-Object Drawing.Size([Math]::Max(460,$right.Panel1.ClientSize.Width),[Math]::Max(190,$right.Panel1.ClientSize.Height));$fields.SplitterWidth=7;$fields.Dock='Fill'
 Set-MedicalEditorSplitter $fields 0.45 $true 175 230
 $wordHost=New-Object Windows.Forms.GroupBox;$wordHost.Name='medicalEditorWordPane';$wordHost.Text='Лист Word'
 $fieldsHost=New-Object Windows.Forms.GroupBox;$fieldsHost.Name='medicalEditorFieldsPane';$fieldsHost.Text='Поля'
 $propertiesHost=New-Object Windows.Forms.GroupBox;$propertiesHost.Name='medicalEditorPropertiesPane';$propertiesHost.Text='Редактор полей'
 $structureHost=New-Object Windows.Forms.GroupBox;$structureHost.Name='medicalEditorStructurePane';$structureHost.Text='Структура документа'
 foreach($pane in @($wordHost,$fieldsHost,$propertiesHost,$structureHost)){$pane.Dock='Fill';$pane.Padding=New-Object Windows.Forms.Padding(6,22,6,6)}
 $outer.Panel1.Controls.Add($wordHost);$outer.Panel2.Controls.Add($right)
 $right.Panel1.Controls.Add($fields);$right.Panel2.Controls.Add($structureHost)
 $fields.Panel1.Controls.Add($fieldsHost);$fields.Panel2.Controls.Add($propertiesHost)
 $footer=New-Object Windows.Forms.FlowLayoutPanel;$footer.Name='medicalEditorSaveActions';$footer.Dock='Fill';$footer.FlowDirection='RightToLeft';$footer.WrapContents=$false;$footer.AutoScroll=$true
 $root.Controls.Add($outer,0,0);$root.Controls.Add($footer,0,1);$dialog.Controls.Add($root)
 $workspace=[pscustomobject]@{Root=$root;OuterSplit=$outer;RightSplit=$right;FieldsSplit=$fields;WordHost=$wordHost;FieldsHost=$fieldsHost;PropertiesHost=$propertiesHost;StructureHost=$structureHost;Footer=$footer;State=@{Resizing=$false;Initialized=$false;Scale=1.0}}
 # Capture FunctionInfo before GetNewClosure, which creates a private module.
 $update=Get-Command Update-MedicalEditorWorkspaceLayout -CommandType Function -ErrorAction Stop
 $resize={if($workspace.State.Initialized){& $update $workspace $false}}.GetNewClosure()
 $outer.Add_SizeChanged($resize);$right.Add_SizeChanged($resize);$fields.Add_SizeChanged($resize)
 $dialog.Add_Shown({
  if($workspace.State.Initialized){return}
  try{$graphics=$dialog.CreateGraphics();try{$workspace.State.Scale=[Math]::Max(1.0,$graphics.DpiX/96.0)}finally{$graphics.Dispose()}}catch{}
  & $update $workspace $true;$workspace.State.Initialized=$true
 }.GetNewClosure())
 return $workspace
}
