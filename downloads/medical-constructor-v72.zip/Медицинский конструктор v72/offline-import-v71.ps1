﻿# Local-only document import. No web services, cloud APIs or dependency downloads.
$script:medicalLocalImportModulePath=$PSCommandPath

function Get-MedicalLocalDocumentFilter {
 return 'Поддерживаемые документы|*.docx;*.dotx;*.doc;*.dot;*.rtf;*.txt;*.pdf;*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff|Word|*.docx;*.dotx;*.doc;*.dot;*.rtf|Обычный текст|*.txt|PDF и изображения|*.pdf;*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff'
}
function Get-MedicalLocalOcrSize([long]$Width,[long]$Height,[int]$EngineMaxDimension=2400){
 $limits=Get-MedicalLocalImportLimits
 if($Width -le 0 -or $Height -le 0){throw 'Изображение имеет некорректный размер.'}
 if($Width -gt 60000000 -or $Height -gt 60000000 -or $Width*$Height -gt $limits.MaxImagePixels){throw 'Изображение больше 60 мегапикселей. Уменьшите размер перед распознаванием.'}
 if($EngineMaxDimension -lt 1){throw 'OCR сообщил некорректный максимальный размер изображения.'}
 $max=[Math]::Min($EngineMaxDimension,$limits.MaxOcrDimension);$scale=[Math]::Min([double]1,([double]$max/[Math]::Max($Width,$Height)))
 return [pscustomobject]@{Width=[uint32][Math]::Max(1,[Math]::Floor($Width*$scale));Height=[uint32][Math]::Max(1,[Math]::Floor($Height*$scale))}
}
function Select-MedicalLocalOcrEngine([object[]]$Languages,[scriptblock]$CreateLanguage,[scriptblock]$CreateProfile){
 if($Languages.Count -eq 0){throw 'В Windows не установлен ни один язык OCR. Установите компонент распознавания текста для русского языка в параметрах Windows, затем повторите импорт.'}
 $russian=@($Languages | Where-Object {$_.LanguageTag -like 'ru*'});$engine=$null;$warning=''
 if($russian.Count){$engine=& $CreateLanguage $russian[0]}
 if(-not $engine){$engine=& $CreateProfile;$warning='Русский язык OCR не установлен или недоступен: распознавание использует языки профиля Windows. Проверьте каждую строку; для русского текста рекомендуется установить русский компонент OCR.'}
 if(-not $engine){throw 'Не удалось включить локальный OCR. Установите компонент распознавания текста для языка документа в параметрах Windows.'}
 return [pscustomobject]@{Engine=$engine;Warning=$warning}
}
function Get-MedicalLocalImportLimits {
 return [pscustomobject]@{MaxFileBytes=52428800L;MaxTextBytes=2097152L;MaxTextCharacters=1500000;MaxPages=30;MaxImagePixels=60000000L;MaxOcrDimension=2400;AsyncTimeoutSeconds=40;WorkerTimeoutSeconds=720;WordTimeoutSeconds=90}
}
function Assert-MedicalLocalImportPath([string]$Path){
 if([string]::IsNullOrWhiteSpace($Path)){throw 'Выберите документ для распознавания.'}
 $full=[IO.Path]::GetFullPath($Path)
 if(-not [IO.File]::Exists($full)){throw 'Файл для распознавания не найден.'}
 if($full.StartsWith('\\') -or $full.StartsWith('//')){throw 'Для локального распознавания скопируйте файл с сетевого диска в папку на этом компьютере.'}
 if([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT){$drive=New-Object IO.DriveInfo ([IO.Path]::GetPathRoot($full));if($drive.DriveType -eq [IO.DriveType]::Network){throw 'Скопируйте документ с сетевого диска в локальную папку перед распознаванием.'}}
 $limits=Get-MedicalLocalImportLimits;$info=New-Object IO.FileInfo $full
 if($info.Length -eq 0){throw 'Выбранный файл пуст.'}
 if($info.Length -gt $limits.MaxFileBytes){throw 'Размер документа превышает 50 МБ. Разделите его на несколько файлов.'}
 $extension=[IO.Path]::GetExtension($full).ToLowerInvariant()
 if($extension -notin @('.docx','.dotx','.doc','.dot','.rtf','.txt','.pdf','.png','.jpg','.jpeg','.bmp','.tif','.tiff')){throw 'Поддерживаются DOCX, DOTX, DOC, DOT, RTF, TXT, PDF, PNG, JPEG, BMP и TIFF.'}
 if($extension -eq '.txt' -and $info.Length -gt $limits.MaxTextBytes){throw 'Текстовый файл превышает 2 МБ.'}
 return $full
}
function New-MedicalLocalImportDirectory {
 $parent=Join-Path ([IO.Path]::GetTempPath()) 'MedicalConstructor-LocalImport'
 [void][IO.Directory]::CreateDirectory($parent)
 $directory=Join-Path $parent ([guid]::NewGuid().ToString('N'))
 [void][IO.Directory]::CreateDirectory($directory)
 return $directory
}
function Remove-MedicalLocalImport($Import){
 if($null -eq $Import -or -not $Import.Temporary -or -not $Import.WorkingDirectory){return}
 $parent=[IO.Path]::GetFullPath((Join-Path ([IO.Path]::GetTempPath()) 'MedicalConstructor-LocalImport')).TrimEnd([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar)
 $directory=[IO.Path]::GetFullPath([string]$Import.WorkingDirectory)
 # Never delete arbitrary user-supplied directories, even if the cleanup object is malformed.
 if([IO.Path]::GetDirectoryName($directory).TrimEnd([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar) -cne $parent -or [IO.Path]::GetFileName($directory) -notmatch '^[a-f0-9]{32}$'){throw 'Недопустимая папка временного импорта.'}
 if([IO.Directory]::Exists($directory)){[IO.Directory]::Delete($directory,$true)}
}
function Read-MedicalLocalText([string]$Path){
 $bytes=[IO.File]::ReadAllBytes($Path);$limits=Get-MedicalLocalImportLimits
 if($bytes.Length -gt $limits.MaxTextBytes){throw 'Текстовый файл превышает 2 МБ.'}
 $text=''
 if($bytes.Length -ge 4 -and (($bytes[0] -eq 0xff -and $bytes[1] -eq 0xfe -and $bytes[2] -eq 0 -and $bytes[3] -eq 0) -or ($bytes[0] -eq 0 -and $bytes[1] -eq 0 -and $bytes[2] -eq 0xfe -and $bytes[3] -eq 0xff))){
  $encoding=New-Object Text.UTF32Encoding ($bytes[0] -eq 0),$true,$true;$text=$encoding.GetString($bytes,4,$bytes.Length-4)
 }elseif($bytes.Length -ge 3 -and $bytes[0] -eq 0xef -and $bytes[1] -eq 0xbb -and $bytes[2] -eq 0xbf){$text=(New-Object Text.UTF8Encoding $false,$true).GetString($bytes,3,$bytes.Length-3)
 }elseif($bytes.Length -ge 2 -and $bytes[0] -eq 0xff -and $bytes[1] -eq 0xfe){$text=(New-Object Text.UnicodeEncoding $false,$true,$true).GetString($bytes,2,$bytes.Length-2)
 }elseif($bytes.Length -ge 2 -and $bytes[0] -eq 0xfe -and $bytes[1] -eq 0xff){$text=(New-Object Text.UnicodeEncoding $true,$true,$true).GetString($bytes,2,$bytes.Length-2)
 }else{
  try{$text=(New-Object Text.UTF8Encoding $false,$true).GetString($bytes)}catch [Text.DecoderFallbackException]{$text=[Text.Encoding]::GetEncoding(1251).GetString($bytes)}
 }
 if($text.IndexOf([char]0) -ge 0){throw 'Файл содержит двоичные данные вместо обычного текста. Сохраните его как TXT в кодировке UTF-8.'}
 if($text.Length -gt $limits.MaxTextCharacters){throw 'В документе слишком много текста для одного шаблона.'}
 return $text
}
function Write-MedicalLocalTextTemplate([string]$Path,[string]$Text){
 $limits=Get-MedicalLocalImportLimits
 if([string]::IsNullOrWhiteSpace($Text)){throw 'В документе не найден читаемый текст.'}
 if($Text.Length -gt $limits.MaxTextCharacters){throw 'В документе слишком много текста для одного шаблона.'}
 # XML 1.0 excludes most ASCII control characters. Preserve tabs and paragraph boundaries.
 $safe=[regex]::Replace($Text,'[\x00-\x08\x0B\x0C\x0E-\x1F]','')
 $body=New-Object Text.StringBuilder
 foreach($line in [regex]::Split($safe,'\r\n|\n|\r')){
  [void]$body.Append('<w:p><w:r><w:t xml:space="preserve">'+[Security.SecurityElement]::Escape($line)+'</w:t></w:r></w:p>')
 }
 $ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 $parts=[ordered]@{
  '[Content_Types].xml'='<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>'
  '_rels/.rels'='<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>'
  'word/document.xml'=('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="'+$ns+'"><w:body>'+$body.ToString()+'<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1417"/></w:sectPr></w:body></w:document>')
  'word/styles.xml'=('<?xml version="1.0" encoding="UTF-8"?><w:styles xmlns:w="'+$ns+'"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman"/><w:sz w:val="24"/><w:lang w:val="ru-RU"/></w:rPr></w:rPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style></w:styles>')
  'word/_rels/document.xml.rels'='<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'
 }
 Add-Type -AssemblyName System.IO.Compression.FileSystem
 $zip=[IO.Compression.ZipFile]::Open($Path,[IO.Compression.ZipArchiveMode]::Create)
 try{foreach($name in $parts.Keys){$entry=$zip.CreateEntry($name);$stream=$entry.Open();try{$bytes=(New-Object Text.UTF8Encoding $false).GetBytes([string]$parts[$name]);$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}}}finally{$zip.Dispose()}
}
function Write-MedicalLocalImportProgress([string]$Directory,[string]$Message,[int]$Current=0,[int]$Total=0){
 $data=[pscustomobject]@{Message=$Message;Current=$Current;Total=$Total}
 [IO.File]::WriteAllText((Join-Path $Directory 'progress.json'),($data|ConvertTo-Json -Compress),(New-Object Text.UTF8Encoding $false))
}
function Wait-MedicalLocalWinRt($Operation,[Type]$ResultType,[int]$TimeoutSeconds=40){
 $methods=[System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {$_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1}
 if($ResultType){$method=@($methods | Where-Object {$_.IsGenericMethodDefinition -and $_.GetGenericArguments().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'})[0];$task=$method.MakeGenericMethod(@($ResultType)).Invoke($null,@($Operation))
 }else{$method=@($methods | Where-Object {-not $_.IsGenericMethodDefinition -and $_.GetParameters()[0].ParameterType.FullName -eq 'Windows.Foundation.IAsyncAction'})[0];$task=$method.Invoke($null,@($Operation))}
 if(-not $task.Wait([TimeSpan]::FromSeconds($TimeoutSeconds))){try{$Operation.Cancel()}catch{};throw 'Локальное распознавание превысило время ожидания. Попробуйте файл меньшего размера.'}
 if($ResultType){return ,$task.GetAwaiter().GetResult()}
 $null=$task.GetAwaiter().GetResult()
}
function Initialize-MedicalLocalOcr {
 if([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT){throw 'Распознавание изображений и PDF доступно в Windows 10/11 с установленным компонентом OCR.'}
 Add-Type -AssemblyName System.Runtime.WindowsRuntime
 $null=[Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime]
 $null=[Windows.Storage.Streams.IRandomAccessStreamWithContentType,Windows.Storage.Streams,ContentType=WindowsRuntime]
 $null=[Windows.Storage.Streams.InMemoryRandomAccessStream,Windows.Storage.Streams,ContentType=WindowsRuntime]
 $null=[Windows.Graphics.Imaging.BitmapDecoder,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
 $null=[Windows.Graphics.Imaging.SoftwareBitmap,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
 $null=[Windows.Graphics.Imaging.BitmapFrame,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
 $null=[Windows.Graphics.Imaging.BitmapTransform,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
 $null=[Windows.Graphics.Imaging.ExifOrientationMode,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
 $null=[Windows.Graphics.Imaging.ColorManagementMode,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
 $null=[Windows.Storage.FileAccessMode,Windows.Storage,ContentType=WindowsRuntime]
 $null=[Windows.Graphics.Imaging.BitmapPixelFormat,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
 $null=[Windows.Graphics.Imaging.BitmapAlphaMode,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
 $null=[Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime]
 $null=[Windows.Media.Ocr.OcrResult,Windows.Foundation,ContentType=WindowsRuntime]
 $null=[Windows.Globalization.Language,Windows.Globalization,ContentType=WindowsRuntime]
 $null=[Windows.Data.Pdf.PdfDocument,Windows.Data.Pdf,ContentType=WindowsRuntime]
 $null=[Windows.Data.Pdf.PdfPageRenderOptions,Windows.Data.Pdf,ContentType=WindowsRuntime]
 $languages=@([Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages)
 $selected=Select-MedicalLocalOcrEngine $languages {param($language) [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($language)} {[Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()}
 return [pscustomobject]@{Engine=$selected.Engine;Warning=$selected.Warning;MaxDimension=[int][Windows.Media.Ocr.OcrEngine]::MaxImageDimension}
}
function Get-MedicalLocalOcrText($Engine,$Bitmap){
 $result=Wait-MedicalLocalWinRt ($Engine.RecognizeAsync($Bitmap)) ([Windows.Media.Ocr.OcrResult])
 # OCR.Result.Text has spaces between lines on some Windows versions; explicit Lines retains structure.
 return (@($result.Lines | ForEach-Object {[string]$_.Text}) -join "`r`n")
}
function Invoke-MedicalLocalNativeOcr([string]$Path,[string]$Directory){
 $limits=Get-MedicalLocalImportLimits;$runtime=Initialize-MedicalLocalOcr;$warnings=New-Object Collections.ArrayList
 if($runtime.Warning){[void]$warnings.Add($runtime.Warning)}
 [void]$warnings.Add('Текст распознан локально. OCR может ошибаться в датах, фамилиях и знаках; проверьте текст и предложенные маркеры перед применением. Оформление скана не переносится.')
 $file=Wait-MedicalLocalWinRt ([Windows.Storage.StorageFile]::GetFileFromPathAsync($Path)) ([Windows.Storage.StorageFile])
 $texts=New-Object Collections.Generic.List[string];$pdf=$null;$stream=$null
 try{
  if([IO.Path]::GetExtension($Path).ToLowerInvariant() -eq '.pdf'){
   $pdf=Wait-MedicalLocalWinRt ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($file)) ([Windows.Data.Pdf.PdfDocument]);$count=[int]$pdf.PageCount
   if($count -gt $limits.MaxPages){throw 'В PDF больше 30 страниц. Разделите документ перед распознаванием.'}
   for($index=0;$index -lt $count;$index++){
    Write-MedicalLocalImportProgress $Directory ('Распознаётся страница '+($index+1)+' из '+$count) ($index+1) $count
    $page=$null;$memory=$null;$bitmap=$null
    try{
     $page=$pdf.GetPage([uint32]$index);$memory=New-Object Windows.Storage.Streams.InMemoryRandomAccessStream
     $max=[Math]::Min($runtime.MaxDimension,$limits.MaxOcrDimension);$scale=[Math]::Min(2.2,($max/[Math]::Max($page.Size.Width,$page.Size.Height)))
     $options=New-Object Windows.Data.Pdf.PdfPageRenderOptions;$options.DestinationWidth=[uint32][Math]::Max(1,[Math]::Floor($page.Size.Width*$scale));$options.DestinationHeight=[uint32][Math]::Max(1,[Math]::Floor($page.Size.Height*$scale))
     Wait-MedicalLocalWinRt ($page.RenderToStreamAsync($memory,$options)) $null
     $memory.Seek(0)
     $decoder=Wait-MedicalLocalWinRt ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($memory)) ([Windows.Graphics.Imaging.BitmapDecoder])
     $bitmap=Wait-MedicalLocalWinRt ($decoder.GetSoftwareBitmapAsync([Windows.Graphics.Imaging.BitmapPixelFormat]::Bgra8,[Windows.Graphics.Imaging.BitmapAlphaMode]::Premultiplied)) ([Windows.Graphics.Imaging.SoftwareBitmap])
     $texts.Add((Get-MedicalLocalOcrText $runtime.Engine $bitmap))
    }finally{if($bitmap){$bitmap.Dispose()};if($memory){$memory.Dispose()};if($page){$page.Dispose()}}
   }
  }else{
   $stream=Wait-MedicalLocalWinRt ($file.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])
   $decoder=Wait-MedicalLocalWinRt ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder]);$count=[int]$decoder.FrameCount
   if($count -gt $limits.MaxPages){throw 'В изображении TIFF больше 30 страниц. Разделите файл перед распознаванием.'}
   for($index=0;$index -lt $count;$index++){
    Write-MedicalLocalImportProgress $Directory ('Распознаётся изображение '+($index+1)+' из '+$count) ($index+1) $count
    $bitmap=$null
    try{
     $frame=Wait-MedicalLocalWinRt ($decoder.GetFrameAsync([uint32]$index)) ([Windows.Graphics.Imaging.BitmapFrame])
     $size=Get-MedicalLocalOcrSize ([long]$frame.PixelWidth) ([long]$frame.PixelHeight) $runtime.MaxDimension
     $transform=New-Object Windows.Graphics.Imaging.BitmapTransform;$transform.ScaledWidth=$size.Width;$transform.ScaledHeight=$size.Height
     $bitmap=Wait-MedicalLocalWinRt ($frame.GetSoftwareBitmapAsync([Windows.Graphics.Imaging.BitmapPixelFormat]::Bgra8,[Windows.Graphics.Imaging.BitmapAlphaMode]::Premultiplied,$transform,[Windows.Graphics.Imaging.ExifOrientationMode]::RespectExifOrientation,[Windows.Graphics.Imaging.ColorManagementMode]::DoNotColorManage)) ([Windows.Graphics.Imaging.SoftwareBitmap])
     $texts.Add((Get-MedicalLocalOcrText $runtime.Engine $bitmap))
    }finally{if($bitmap){$bitmap.Dispose()}}
   }
  }
 }finally{if($stream){$stream.Dispose()};$pdf=$null} # PdfDocument is not IClosable; pages and streams are disposed above.
 return [pscustomobject]@{Text=($texts -join "`r`n`r`n");Warnings=@($warnings)}
}
function New-MedicalLocalWordApplication {
 if([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT){throw 'Для импорта DOC, DOT и RTF нужен настольный Microsoft Word в Windows.'}
 return New-Object -ComObject Word.Application
}
function Get-MedicalLocalWordProcessId($Word){
 if(-not ('MedicalConstructorImportNative' -as [type])){Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class MedicalConstructorImportNative { [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId); }'}
 [uint32]$wordProcessId=0;[void][MedicalConstructorImportNative]::GetWindowThreadProcessId([IntPtr]$Word.Hwnd,[ref]$wordProcessId)
 return $wordProcessId
}
function Get-MedicalLocalWordProcess([uint32]$Id=0){
 if($Id -eq 0){return @(Get-Process -Name WINWORD -ErrorAction SilentlyContinue)}
 return Get-Process -Id $Id -ErrorAction Stop
}
function Release-MedicalLocalComReference($Reference){
 if($Reference -and [Runtime.InteropServices.Marshal]::IsComObject($Reference)){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($Reference)}
}
function Convert-MedicalLocalWordDocument([string]$Path,[string]$Destination,[string]$Directory){
 Write-MedicalLocalImportProgress $Directory 'Word преобразует документ только для чтения…'
 $word=$null;$document=$null;$wordOwned=$false;$before=@(Get-MedicalLocalWordProcess | ForEach-Object {$_.Id})
 try{
  $word=New-MedicalLocalWordApplication
  $wordProcessId=Get-MedicalLocalWordProcessId $word
  # Establish exclusive ownership before changing options or opening a document.
  if($wordProcessId -gt 0 -and $wordProcessId -notin $before){
   $process=Get-MedicalLocalWordProcess $wordProcessId
   if($process.ProcessName -ine 'WINWORD'){throw 'Не удалось подтвердить отдельный процесс Word для импорта.'}
   $wordOwned=$true;$owned=[pscustomobject]@{Id=$wordProcessId;StartTimeUtc=$process.StartTime.ToUniversalTime().ToString('o')}
   [IO.File]::WriteAllText((Join-Path $Directory 'word-process.json'),($owned|ConvertTo-Json -Compress),(New-Object Text.UTF8Encoding $false))
  }else{throw 'Word не создал отдельный процесс для импорта. Сохраните открытые документы, закройте Word и повторите импорт.'}
  $word.Visible=$false;$word.DisplayAlerts=0;$word.AutomationSecurity=3
  try{$word.Options.UpdateLinksAtOpen=$false}catch{}
  $document=$word.Documents.Open($Path,$false,$true,$false)
  try{$document.UpdateStylesOnOpen=$false}catch{}
  $document.SaveAs2($Destination,12) # wdFormatXMLDocument, strips any old-format macros from the editable copy.
 }finally{
  if($document){try{$document.Close(0)}catch{};try{Release-MedicalLocalComReference $document}catch{}}
  if($word){if($wordOwned){try{$word.Quit(0)}catch{}};try{Release-MedicalLocalComReference $word}catch{}}
 }
}
function Stop-MedicalLocalImportWord([string]$Directory){
 $metadata=Join-Path $Directory 'word-process.json';if(-not [IO.File]::Exists($metadata)){return}
 try{$owned=[IO.File]::ReadAllText($metadata)|ConvertFrom-Json;$process=Get-Process -Id ([int]$owned.Id) -ErrorAction Stop
  if($process.ProcessName -ieq 'WINWORD' -and $process.StartTime.ToUniversalTime().ToString('o') -ceq [string]$owned.StartTimeUtc){$process.Kill()}
 }catch{}
}
function Invoke-MedicalLocalImportWorker([string]$RequestPath){
 $request=$null;$result=$null
 try{
  $request=[IO.File]::ReadAllText($RequestPath)|ConvertFrom-Json;$path=Assert-MedicalLocalImportPath ([string]$request.Path);$directory=[string]$request.Directory;$destination=Join-Path $directory 'import.docx';$extension=[IO.Path]::GetExtension($path).ToLowerInvariant();$warnings=@()
  if($extension -in @('.doc','.dot','.rtf')){Convert-MedicalLocalWordDocument $path $destination $directory;$kind='word';$warnings=@('Старая версия Word преобразована в отдельную копию DOCX. Проверьте оформление перед применением.')
  }else{$ocr=Invoke-MedicalLocalNativeOcr $path $directory;Write-MedicalLocalTextTemplate $destination ([string]$ocr.Text);$warnings=@($ocr.Warnings);$kind=if($extension -eq '.pdf'){'pdf-ocr'}else{'image-ocr'}}
  $result=[pscustomobject]@{Success=$true;Path=$destination;SourceKind=$kind;Warnings=$warnings;Error=''}
 }catch{$result=[pscustomobject]@{Success=$false;Path='';SourceKind='';Warnings=@();Error=[string]$_.Exception.Message}}
 if($request){[IO.File]::WriteAllText((Join-Path ([string]$request.Directory) 'result.json'),($result|ConvertTo-Json -Depth 6),(New-Object Text.UTF8Encoding $false))}
}
function Register-MedicalLocalImportCancellation($Dialog,$Cancellation){
 $Dialog.Add_FormClosing({$Cancellation.Value=$true}.GetNewClosure())
}
function Test-MedicalLocalImportUiClosed($Owner,$Dialog){
 return [bool](($Owner -and $Owner.IsDisposed) -or ($Dialog -and $Dialog.IsDisposed))
}
function Start-MedicalLocalImportWorker([string]$Path,[string]$Directory,$Owner=$null){
 if([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT){throw 'Импорт этого формата доступен в Windows с установленным Word или компонентом OCR.'}
 $requestPath=Join-Path $Directory 'request.json';[IO.File]::WriteAllText($requestPath,([pscustomobject]@{Path=$Path;Directory=$Directory}|ConvertTo-Json -Compress),(New-Object Text.UTF8Encoding $false))
 $module=$script:medicalLocalImportModulePath
 if(-not $module -or -not [IO.File]::Exists($module)){throw 'Не найден локальный модуль распознавания. Распакуйте всю папку программы.'}
 $command='$ErrorActionPreference=''Stop''; . '''+$module.Replace("'","''")+'''; Invoke-MedicalLocalImportWorker '''+$requestPath.Replace("'","''")+''''
 $info=New-Object Diagnostics.ProcessStartInfo;$info.FileName=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe';$info.Arguments='-NoLogo -NoProfile -NonInteractive -Sta -ExecutionPolicy Bypass -EncodedCommand '+[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($command));$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.WorkingDirectory=$Directory
 $process=$null;$processStarted=$false;$dialog=$null;$label=$null;$cancelled=@{Value=$false};$timedOut=$false;$ownerWasEnabled=$true;$limits=Get-MedicalLocalImportLimits
 try{
  if($Owner){
   $dialog=New-Object Windows.Forms.Form;$dialog.Text='Локальное распознавание';$dialog.Width=510;$dialog.Height=180;$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false;$dialog.StartPosition='CenterParent';$dialog.ControlBox=$false;$dialog.ShowInTaskbar=$false
   Register-MedicalLocalImportCancellation $dialog $cancelled
   $label=New-Object Windows.Forms.Label;$label.Text='Документ обрабатывается на этом компьютере…';$label.AutoSize=$false;$label.Dock='Fill';$label.Padding=New-Object Windows.Forms.Padding 14
   $cancel=New-Object Windows.Forms.Button;$cancel.Text='Отмена';$cancel.Dock='Bottom';$cancel.Height=38;$cancel.Add_Click({$cancelled.Value=$true}.GetNewClosure());$dialog.Controls.Add($label);$dialog.Controls.Add($cancel);$dialog.Show($Owner);$ownerWasEnabled=$Owner.Enabled;$Owner.Enabled=$false
  }
  $process=New-Object Diagnostics.Process;$process.StartInfo=$info;[void]$process.Start();$processStarted=$true;$watch=[Diagnostics.Stopwatch]::StartNew();$timeout=if([IO.Path]::GetExtension($Path).ToLowerInvariant() -in @('.doc','.dot','.rtf')){$limits.WordTimeoutSeconds}else{$limits.WorkerTimeoutSeconds}
  while(-not $process.WaitForExit(75)){
   if(Test-MedicalLocalImportUiClosed $Owner $dialog){$cancelled.Value=$true;break}
   if($dialog){[Windows.Forms.Application]::DoEvents();if(Test-MedicalLocalImportUiClosed $Owner $dialog){$cancelled.Value=$true;break};$progressPath=Join-Path $Directory 'progress.json';if([IO.File]::Exists($progressPath)){try{$progress=[IO.File]::ReadAllText($progressPath)|ConvertFrom-Json;$label.Text=[string]$progress.Message}catch{}}}
   if($cancelled.Value){break}
   if($watch.Elapsed.TotalSeconds -gt $timeout){$timedOut=$true;break}
  }
  if($cancelled.Value -or $timedOut){if(-not $process.HasExited){$process.Kill();[void]$process.WaitForExit(3000)};Stop-MedicalLocalImportWord $Directory;if($cancelled.Value){throw (New-Object OperationCanceledException 'Распознавание отменено. Исходный файл не изменён.')};throw 'Превышено время обработки документа. Закройте окна Word, уменьшите файл и повторите импорт.'}
  $resultPath=Join-Path $Directory 'result.json';if(-not [IO.File]::Exists($resultPath)){throw 'Не удалось завершить локальное распознавание. Проверьте, что Word или язык OCR установлен и файл не повреждён.'}
  $result=[IO.File]::ReadAllText($resultPath)|ConvertFrom-Json;if(-not $result.Success){throw ([string]$result.Error)}
  return $result
 }finally{
  if($process){try{if($processStarted -and -not $process.HasExited){try{$process.Kill();[void]$process.WaitForExit(3000)}catch{}}}finally{$process.Dispose()}}
  Stop-MedicalLocalImportWord $Directory
  if($dialog){if(-not $dialog.IsDisposed){$dialog.Close();$dialog.Dispose()};if($Owner -and -not $Owner.IsDisposed){$Owner.Enabled=$ownerWasEnabled;$Owner.Activate()}}
 }
}
function Import-MedicalLocalDocument([string]$Path,$Owner=$null){
 if(Get-Command Assert-MedicalAccountPath -CommandType Function -ErrorAction SilentlyContinue){Assert-MedicalAccountPath $Path}
 $path=Assert-MedicalLocalImportPath $Path;$extension=[IO.Path]::GetExtension($path).ToLowerInvariant()
 if($extension -in @('.docx','.dotx')){
  # The editor validates the complete OOXML package before replacing its working model.
  return [pscustomobject]@{Path=$path;Temporary=$false;SourceKind='word';Warnings=@();WorkingDirectory=''}
 }
 $directory=New-MedicalLocalImportDirectory;$import=[pscustomobject]@{Path=(Join-Path $directory 'import.docx');Temporary=$true;SourceKind='';Warnings=@();WorkingDirectory=$directory}
 try{
  if($extension -eq '.txt'){Write-MedicalLocalTextTemplate $import.Path (Read-MedicalLocalText $path);$import.SourceKind='text';$import.Warnings=@('Импортирован обычный текст. Проверьте заголовки, маркеры и оформление перед применением.')
  }else{$result=Start-MedicalLocalImportWorker $path $directory $Owner;$import.SourceKind=[string]$result.SourceKind;$import.Warnings=@($result.Warnings)}
  if(-not [IO.File]::Exists($import.Path)){throw 'Не создана временная копия документа.'}
  return $import
 }catch{Remove-MedicalLocalImport $import;throw}
}
