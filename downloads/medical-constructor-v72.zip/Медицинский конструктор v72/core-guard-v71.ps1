﻿# A last-resort boundary for exceptions escaping native UI callbacks. It is not
# a replacement for validation/atomic writes and cannot handle process/power loss.
$script:medicalCoreGuard=$null
function Initialize-MedicalCoreGuard([string]$programRoot){
 if($script:medicalCoreGuard -and $script:medicalCoreGuard.Handler){Unregister-MedicalUiExceptionGuard}
 $path=''
 try{
  $folder=Join-Path ([IO.Path]::GetFullPath($programRoot)) 'Журнал работы'
  [void][IO.Directory]::CreateDirectory($folder)
  $path=Join-Path $folder 'core-events.jsonl'
 }catch{}
 $script:medicalCoreGuard=[pscustomobject]@{Path=$path;Busy=$false;LogBusy=$false;Handler=$null;Owner=$null;LastIncident=$null;ModeReady=$false}
 # Call initialization before the first WinForms window is constructed.
 if('Windows.Forms.Application' -as [type]){
  try{[Windows.Forms.Application]::SetUnhandledExceptionMode('CatchException');$script:medicalCoreGuard.ModeReady=$true}catch{}
 }
 return [bool]$path
}
function Write-MedicalCoreIncident($exception,[string]$area='ui'){
 if(-not $script:medicalCoreGuard){[void](Initialize-MedicalCoreGuard $PSScriptRoot)}
 $state=$script:medicalCoreGuard
 if($exception -is [Management.Automation.ErrorRecord]){$exception=$exception.Exception}
 $type='System.Exception';$hresult=0
 if($exception -is [Exception]){$type=$exception.GetType().FullName;$hresult=$exception.HResult}
 if($type -notmatch '^[A-Za-z0-9_.+\[\],` ]{1,160}$'){$type='System.Exception'}
 if($area -notin @('ui','startup','backup','save','import')){$area='ui'}
 $stage=if($script:stage -in @('initial','diary','discharge')){[string]$script:stage}else{'none'}
 # Never serialize exception messages, stack traces, arguments, paths or state.
 $incident=[pscustomobject][ordered]@{Id=[guid]::NewGuid().ToString('N');Utc=[datetime]::UtcNow.ToString('o');Version=71;Area=$area;Stage=$stage;Type=$type;HResult=[int]$hresult}
 $result=[pscustomobject]@{Incident=$incident;LogWritten=$false;BackupSaved=$false}
 $state.LastIncident=$result
 if(-not $state.Path -or $state.LogBusy){return $result}
 $state.LogBusy=$true;$temp=''
 try{
  $lines=New-Object Collections.ArrayList
  # Bounded input/output: a damaged or replaced log cannot allocate unbounded
  # memory or forward arbitrary text into new diagnostic entries.
  if([IO.File]::Exists($state.Path) -and ([IO.FileInfo]$state.Path).Length -le 65536){
   foreach($line in @([IO.File]::ReadAllLines($state.Path) | Select-Object -Last 127)){
    try{
     $item=$line | ConvertFrom-Json
     if($item.Id -cnotmatch '^[a-f0-9]{32}$' -or $item.Version -ne 71 -or $item.Area -notin @('ui','startup','backup','save','import') -or $item.Stage -notin @('none','initial','diary','discharge') -or $item.Type -notmatch '^[A-Za-z0-9_.+\[\],` ]{1,160}$'){continue}
     $date=[datetimeoffset]::MinValue
     $dateText=if($item.Utc -is [datetime]){$item.Utc.ToUniversalTime().ToString('o')}elseif($item.Utc -is [datetimeoffset]){$item.Utc.ToUniversalTime().ToString('o')}else{[string]$item.Utc}
     if(-not [datetimeoffset]::TryParseExact($dateText,'o',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$date)){continue}
     $safe=[ordered]@{Id=[string]$item.Id;Utc=$date.ToUniversalTime().ToString('o');Version=71;Area=[string]$item.Area;Stage=[string]$item.Stage;Type=[string]$item.Type;HResult=[int]$item.HResult}
     [void]$lines.Add(($safe | ConvertTo-Json -Compress))
    }catch{}
   }
  }
  [void]$lines.Add(($incident | ConvertTo-Json -Compress))
  $temp=Join-Path ([IO.Path]::GetDirectoryName($state.Path)) ('.mc-core-'+[guid]::NewGuid().ToString('N')+'.tmp')
  $bytes=[Text.UTF8Encoding]::new($false).GetBytes((($lines -join "`r`n")+"`r`n"))
  if($bytes.Length -gt 65536){throw 'Diagnostic size limit'}
  $stream=[IO.File]::Open($temp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
  try{$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)}finally{$stream.Dispose()}
  if([IO.File]::Exists($state.Path)){[IO.File]::Replace($temp,$state.Path,[Management.Automation.Language.NullString]::Value)}else{[IO.File]::Move($temp,$state.Path)}
  $temp='';$result.LogWritten=$true
 }catch{}finally{if($temp -and [IO.File]::Exists($temp)){try{[IO.File]::Delete($temp)}catch{}};$state.LogBusy=$false}
 return $result
}
function Invoke-MedicalUiExceptionRecovery($exception,$owner=$null){
 if(-not $script:medicalCoreGuard){[void](Initialize-MedicalCoreGuard $PSScriptRoot)}
 $state=$script:medicalCoreGuard
 if($state.Busy){return $null}
 $state.Busy=$true
 try{
  $incident=Write-MedicalCoreIncident $exception 'ui'
  # A nested checkpoint/notification failure must never recursively re-enter
  # the UI exception handler or replace the original diagnostic incident.
  if(($script:medicalWorkspaceReady -or $script:medicalBackupEditorDraft -or $script:medicalBackupRetainedDraft) -and (-not $script:medicalAccountsContext -or $script:medicalAuthSession) -and -not $script:medicalBackupBusy){
   $checkpointCommand=Get-Command Write-MedicalSessionBackup -CommandType Function -ErrorAction SilentlyContinue
   if($checkpointCommand){try{$checkpoint=& $checkpointCommand;if($checkpoint){$incident.BackupSaved=$true}}catch{}}
  }
  $message='Не удалось выполнить действие. Проверьте введённые данные, сохраните работу и перезапустите программу.'
  if($incident.BackupSaved){$message+="`r`nРезервная копия обновлена."}else{$message+="`r`nОбновление резервной копии не подтверждено."}
  $message+="`r`nКод события: "+$incident.Incident.Id
  try{[void][Windows.Forms.MessageBox]::Show($owner,$message,'Ошибка действия','OK','Warning')}catch{}
  return $incident
 }finally{$state.Busy=$false}
}
function Register-MedicalUiExceptionGuard($owner=$null){
 if(-not $script:medicalCoreGuard){[void](Initialize-MedicalCoreGuard $PSScriptRoot)}
 $state=$script:medicalCoreGuard;$state.Owner=$owner
 if($state.Handler){return $true}
 $recover=Get-Command Invoke-MedicalUiExceptionRecovery -CommandType Function -ErrorAction Stop
 $handler=[Threading.ThreadExceptionEventHandler]({param($sender,$eventArgs)
  try{& $recover $eventArgs.Exception $state.Owner | Out-Null}catch{}
 }.GetNewClosure())
 [Windows.Forms.Application]::add_ThreadException($handler)
 $state.Handler=$handler
 return $true
}
function Unregister-MedicalUiExceptionGuard {
 if(-not $script:medicalCoreGuard){return}
 $state=$script:medicalCoreGuard
 if($state.Handler){
  try{[Windows.Forms.Application]::remove_ThreadException($state.Handler)}finally{$state.Handler=$null;$state.Owner=$null}
 }
}
