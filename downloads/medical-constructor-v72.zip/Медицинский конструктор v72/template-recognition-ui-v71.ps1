﻿# v71: review offline recognition proposals before touching the working form.
function Invoke-MedicalTemplateRecognition($owner,$model,$schema){
 $commands=@{}
 foreach($name in @('Get-MedicalTemplateRecognitionPlan','Apply-MedicalTemplateRecognitionPlan','Update-MedicalRecognitionRow','Set-MedicalRecognitionCustomField')){$commands[$name]=Get-Command $name -CommandType Function -ErrorAction Stop}
 $plan=& $commands['Get-MedicalTemplateRecognitionPlan'] $model $schema
 if(-not @($plan.Rows|Where-Object {$_.Action -ne 'add-date'}).Count){
  [void][Windows.Forms.MessageBox]::Show($owner,'Подписи полей не найдены. Распознавание работает с текстом DOCX/DOTX: используйте подписи вида «Жалобы:» или заголовок с отдельным абзацем. Поля можно добавить вручную в редакторе.','Распознавание полей','OK','Information')
  return $null
 }
 $dialog=New-Object Windows.Forms.Form;$dialog.Text='Локальное распознавание полей — проверка замен';$dialog.StartPosition='CenterParent';$dialog.Size=New-Object Drawing.Size(1180,740);$dialog.MinimumSize=New-Object Drawing.Size(800,560);$dialog.Font=New-Object Drawing.Font('Segoe UI',10);$dialog.KeyPreview=$true
 $layout=New-Object Windows.Forms.TableLayoutPanel;$layout.Dock='Fill';$layout.ColumnCount=1;$layout.RowCount=4
 [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',90)));[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)));[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',132)));[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',60)));$dialog.Controls.Add($layout)
 $hint=New-Object Windows.Forms.Label;$hint.Dock='Fill';$hint.Padding=New-Object Windows.Forms.Padding(10);$hint.Text='Проверьте «Было» и «Станет» и отметьте нужные замены. Это локальное распознавание подписей, без отправки файлов в интернет. Непустые ответы не отмечены автоматически. При загрузке заполненного осмотра удалите все исходные ответы пациента перед сохранением формы. Исходный файл сохраняется без изменений.';$layout.Controls.Add($hint,0,0)
 $grid=New-Object Windows.Forms.DataGridView;$grid.Dock='Fill';$grid.AutoGenerateColumns=$false;$grid.AllowUserToAddRows=$false;$grid.AllowUserToDeleteRows=$false;$grid.MultiSelect=$false;$grid.SelectionMode='FullRowSelect';$grid.RowHeadersVisible=$false;$grid.AutoSizeRowsMode='AllCells';$grid.BackgroundColor=[Drawing.Color]::White;$grid.DefaultCellStyle.WrapMode='True'
 $check=New-Object Windows.Forms.DataGridViewCheckBoxColumn;$check.Name='Apply';$check.HeaderText='Заменить';$check.Width=82
 $label=New-Object Windows.Forms.DataGridViewTextBoxColumn;$label.Name='Label';$label.HeaderText='Подпись';$label.Width=170;$label.ReadOnly=$true
 $marker=New-Object Windows.Forms.DataGridViewComboBoxColumn;$marker.Name='Marker';$marker.HeaderText='Маркер';$marker.Width=210;$marker.DisplayStyle='DropDownButton';[void]$marker.Items.Add('')
 foreach($definition in $plan.Definitions){if(-not $marker.Items.Contains($definition.Marker)){[void]$marker.Items.Add([string]$definition.Marker)}}
 $before=New-Object Windows.Forms.DataGridViewTextBoxColumn;$before.Name='Before';$before.HeaderText='Было';$before.ReadOnly=$true;$before.AutoSizeMode='Fill';$before.FillWeight=50
 $after=New-Object Windows.Forms.DataGridViewTextBoxColumn;$after.Name='After';$after.HeaderText='Станет';$after.ReadOnly=$true;$after.AutoSizeMode='Fill';$after.FillWeight=50
 foreach($column in @($check,$label,$marker,$before,$after)){[void]$grid.Columns.Add($column)}
 foreach($proposal in $plan.Rows){$index=$grid.Rows.Add();$row=$grid.Rows[$index];$row.Tag=$proposal;$row.Cells['Apply'].Value=[bool]$proposal.Selected;$row.Cells['Label'].Value=$proposal.Label;$row.Cells['Marker'].Value=$proposal.Marker;$row.Cells['Before'].Value=if($proposal.Action -eq 'add-date'){'Новый абзац после заголовка'}else{$proposal.OriginalText};$row.Cells['After'].Value=$proposal.ReplacementText;$row.Cells['Label'].ToolTipText=$proposal.Reason}
 $layout.Controls.Add($grid,0,1)
 $status=New-Object Windows.Forms.TextBox;$status.Dock='Fill';$status.Multiline=$true;$status.ReadOnly=$true;$status.ScrollBars='Vertical';$status.WordWrap=$true
 $lines=@('Маркер можно выбрать вручную. Для неизвестной подписи выберите строку и нажмите «Создать поле из подписи».')
 if($plan.NewSchema){$lines+=@('Будет создана новая структура только из отмеченных полей. Для сохранения нужен маркер даты и времени: при его отсутствии отметьте отдельную строку добавления даты.')}
 if($plan.Missing.Count){$lines+=@('Не найдены подписи: '+($plan.Missing -join '; ')+'. Их можно расставить в редакторе вручную.')}
 $lines+=@($plan.Warnings);$status.Text=$lines -join "`r`n";$layout.Controls.Add($status,0,2)
 $footer=New-Object Windows.Forms.FlowLayoutPanel;$footer.Dock='Fill';$footer.FlowDirection='LeftToRight';$footer.WrapContents=$false;$footer.AutoScroll=$true;$footer.Padding=New-Object Windows.Forms.Padding(7)
 $custom=New-Object Windows.Forms.Button;$custom.Text='Создать поле из подписи';$custom.Size=New-Object Drawing.Size(240,36)
 $apply=New-Object Windows.Forms.Button;$apply.Text='Применить отмеченные';$apply.Size=New-Object Drawing.Size(225,36)
 $cancel=New-Object Windows.Forms.Button;$cancel.Text='Отмена';$cancel.Size=New-Object Drawing.Size(120,36);$cancel.DialogResult='Cancel';$dialog.CancelButton=$cancel
 foreach($button in @($custom,$apply,$cancel)){$footer.Controls.Add($button)};$layout.Controls.Add($footer,0,3)
 $state=@{Result=$null;Loading=$false;LastError=''}
 $grid.Add_CurrentCellDirtyStateChanged({if($grid.IsCurrentCellDirty){[void]$grid.CommitEdit([Windows.Forms.DataGridViewDataErrorContexts]::Commit)}}.GetNewClosure())
 $grid.Add_CellValueChanged({param($sender,$eventArgs)
  if($state.Loading -or $eventArgs.RowIndex -lt 0 -or $eventArgs.ColumnIndex -lt 0){return}
  $viewRow=$grid.Rows[$eventArgs.RowIndex];$proposal=$viewRow.Tag;if(-not $proposal){return}
  try{
   $columnName=$grid.Columns[$eventArgs.ColumnIndex].Name
   if($columnName -eq 'Marker'){
    $proposal.Marker=[string]$viewRow.Cells['Marker'].Value;$proposal.ManualField=$false
    & $commands['Update-MedicalRecognitionRow'] $proposal
    $state.Loading=$true;try{$viewRow.Cells['After'].Value=$proposal.ReplacementText;if(-not $proposal.Marker){$viewRow.Cells['Apply'].Value=$false}}finally{$state.Loading=$false}
   }elseif($columnName -eq 'Apply'){
    if([bool]$viewRow.Cells['Apply'].Value -and -not $proposal.Marker){$state.Loading=$true;try{$viewRow.Cells['Apply'].Value=$false}finally{$state.Loading=$false};$status.Text='Сначала выберите маркер в этой строке или создайте поле из подписи.'}
   }
  }catch{$status.Text=$_.Exception.Message}
 }.GetNewClosure())
 $grid.Add_DataError({param($sender,$eventArgs)$eventArgs.ThrowException=$false;$status.Text='Не удалось выбрать маркер. Выберите значение из списка.'}.GetNewClosure())
 $custom.Add_Click({
  try{
   if(-not $grid.CurrentRow -or -not $grid.CurrentRow.Tag){return};$viewRow=$grid.CurrentRow;$proposal=$viewRow.Tag
   if($proposal.Action -eq 'add-date'){throw 'Системная дата не является полем формы.'}
   & $commands['Set-MedicalRecognitionCustomField'] $plan $proposal $proposal.Label
   $state.Loading=$true
   try{if(-not $marker.Items.Contains($proposal.Marker)){[void]$marker.Items.Add($proposal.Marker)};$viewRow.Cells['Marker'].Value=$proposal.Marker;$viewRow.Cells['Apply'].Value=$true;$viewRow.Cells['After'].Value=$proposal.ReplacementText}finally{$state.Loading=$false}
   $status.Text='Создано поле «'+$proposal.NewFieldLabel+'» с маркером {{'+$proposal.Marker+'}}. Проверьте замену и нажмите «Применить отмеченные».'
  }catch{$status.Text=$_.Exception.Message}
 }.GetNewClosure())
 $apply.Add_Click({
  try{
   [void]$grid.EndEdit();$ids=@(foreach($viewRow in $grid.Rows){if([bool]$viewRow.Cells['Apply'].Value){[string]$viewRow.Tag.Id}})
   $state.Result=& $commands['Apply-MedicalTemplateRecognitionPlan'] $model $schema $plan $ids
   $dialog.DialogResult='OK';$dialog.Close()
  }catch{$status.Text=$_.Exception.Message;[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Проверка замен','OK','Warning')}
 }.GetNewClosure())
 # Readable light review surface intentionally makes changed text and checkboxes clear.
 try{if($dialog.ShowDialog($owner) -eq 'OK'){return $state.Result};return $null}finally{$dialog.Dispose()}
}
