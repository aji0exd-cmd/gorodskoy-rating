﻿# v57: local appearance settings and a reusable WinForms workspace.
$script:uiSettingsPath=Join-Path $env:LOCALAPPDATA 'MedicalConstructor\appearance.json'
function Read-MedicalAppearance {
 if(Test-Path -LiteralPath $script:uiSettingsPath){
  try{ $settings=Get-Content -LiteralPath $script:uiSettingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
   if([string]$settings.Theme -in @('light','dark','contrast')){return [string]$settings.Theme}
  }catch{Write-Warning 'Настройки оформления повреждены. Используется светлая тема.'}
 }
 return 'light'
}
function Write-MedicalAppearance([string]$theme){
 if($theme -notin @('light','dark','contrast')){throw 'Неизвестная тема оформления.'}
 $folder=Split-Path -Parent $script:uiSettingsPath
 [void][IO.Directory]::CreateDirectory($folder)
 $temp=$script:uiSettingsPath+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
 try{
  [IO.File]::WriteAllText($temp,(@{Version=1;Theme=$theme}|ConvertTo-Json),[Text.UTF8Encoding]::new($true))
  if(Test-Path -LiteralPath $script:uiSettingsPath){[IO.File]::Replace($temp,$script:uiSettingsPath,($script:uiSettingsPath+'.bak'))}
  else{[IO.File]::Move($temp,$script:uiSettingsPath)}
 }finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force}}
}
function Set-MedicalPalette([string]$theme){
 $script:uiTheme=$theme
 switch($theme){
  'dark' {$colors=@('#111923','#1C2836','#15202D','#EDF3FA','#B1BED0','#66D1BC','#6B8199','#223F3D','#10251F','#70DEA1','#FF9F9F')}
  'contrast' {$colors=@('#EEEEEE','#FFFFFF','#FFFFFF','#111111','#333333','#154B9A','#303030','#EAF0FF','#FFFFFF','#176537','#AC2121')}
  default {$colors=@('#F1F5F9','#FFFFFF','#FFFFFF','#192A40','#526479','#176858','#94A3B8','#E5F3EF','#FFFFFF','#176537','#AE3030')}
 }
 $names=@('darkBg','darkPanel','darkInput','darkText','darkMuted','darkAccent','uiBorder','uiSoft','uiAccentText','uiSuccess','uiDanger')
 for($i=0;$i -lt $names.Count;$i++){Set-Variable -Scope Script -Name $names[$i] -Value ([Drawing.ColorTranslator]::FromHtml($colors[$i]))}
}
Add-Type -ReferencedAssemblies 'System.Windows.Forms','System.Drawing' -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
public class MedicalOutlinePanel : Panel {
    public Color OutlineColor { get; set; }
    public Color FocusColor { get; set; }
    public int CornerRadius { get; set; }
    public bool IsInput { get; set; }
    public MedicalOutlinePanel() {
        DoubleBuffered = true; ResizeRedraw = true;
        CornerRadius = 6; OutlineColor = Color.SlateGray; FocusColor = Color.SeaGreen;
    }
    protected override void OnPaint(PaintEventArgs e) {
        base.OnPaint(e);
        if (ClientSize.Width < 3 || ClientSize.Height < 3) return;
        float width = IsInput && ContainsFocus ? 2 : 1;
        float inset = width / 2;
        RectangleF r = new RectangleF(inset, inset, ClientSize.Width-width-1, ClientSize.Height-width-1);
        float d = Math.Min(CornerRadius * 2, Math.Min(r.Width, r.Height));
        if (d < 1) return;
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        using (GraphicsPath p = new GraphicsPath()) {
            p.AddArc(r.Left,r.Top,d,d,180,90); p.AddArc(r.Right-d,r.Top,d,d,270,90);
            p.AddArc(r.Right-d,r.Bottom-d,d,d,0,90); p.AddArc(r.Left,r.Bottom-d,d,d,90,90);
            p.CloseFigure();
            using (Pen pen = new Pen(IsInput && ContainsFocus ? FocusColor : OutlineColor,width)) e.Graphics.DrawPath(pen,p);
        }
    }
}
public class MedicalOutlineTable : TableLayoutPanel {
    public Color OutlineColor { get; set; }
    public Color FocusColor { get; set; }
    public bool IsInput { get; set; }
    public MedicalOutlineTable() { DoubleBuffered = true; ResizeRedraw = true; OutlineColor = Color.SlateGray; }
    protected override void OnPaint(PaintEventArgs e) {
        base.OnPaint(e);
        if (ClientSize.Width < 2 || ClientSize.Height < 2) return;
        using (Pen pen = new Pen(OutlineColor,1)) e.Graphics.DrawRectangle(pen,0,0,ClientSize.Width-1,ClientSize.Height-1);
    }
}
'@
function New-MedicalInputFrame($control){
 $frame=New-Object MedicalOutlinePanel
 $frame.IsInput=$true;$frame.CornerRadius=4;$frame.Dock='Top'
 $frame.Padding=New-Object Windows.Forms.Padding(9,8,9,8)
 $frame.Margin=$control.Margin
 $frame.Height=[Math]::Max(42,($control.Height+18))
 $control.Margin=New-Object Windows.Forms.Padding(0)
 $control.BorderStyle='None';$control.Dock='Fill'
 $frame.Controls.Add($control)
 $control.Add_Enter({if($this.Parent -is [MedicalOutlinePanel]){$this.Parent.Invalidate()}})
 $control.Add_Leave({if($this.Parent -is [MedicalOutlinePanel]){$this.Parent.Invalidate()}})
 return $frame
}
# Keep the public theme function names used by existing dialogs and form builders.
function Set-DarkTheme($root){
 $queue=New-Object 'System.Collections.Generic.Queue[System.Windows.Forms.Control]'
 $queue.Enqueue($root)
 while($queue.Count -gt 0){
  $c=$queue.Dequeue()
  $c.ForeColor=$script:darkText
  if($c -is [Windows.Forms.Form]){$c.BackColor=$script:darkBg}
  elseif($c -is [MedicalOutlinePanel] -or $c -is [MedicalOutlineTable]){$c.BackColor=$script:darkPanel;$c.OutlineColor=$script:uiBorder;$c.FocusColor=$script:darkAccent;$c.Invalidate()}
  elseif($c -is [Windows.Forms.TextBox]){
   $c.BackColor=$script:darkInput
   if($c.Parent -is [MedicalOutlinePanel] -and $c.Parent.IsInput){$c.BorderStyle='None'}else{$c.BorderStyle='FixedSingle'}
  }
  elseif($c -is [Windows.Forms.ComboBox]){$c.BackColor=$script:darkInput;$c.FlatStyle='Flat'}
  elseif($c -is [Windows.Forms.Button]){
   $c.Region=$null;$c.UseVisualStyleBackColor=$false;$c.FlatStyle='Flat'
   $c.FlatAppearance.BorderColor=$script:uiBorder;$c.FlatAppearance.BorderSize=1
   $c.FlatAppearance.MouseOverBackColor=$script:uiSoft
   $c.FlatAppearance.MouseDownBackColor=$script:uiSoft
   $c.BackColor=$script:darkInput
   if($c.Name -in @('mc-export','mc-case-save')){$c.BackColor=$script:darkAccent;$c.ForeColor=$script:uiAccentText;$c.FlatAppearance.MouseOverBackColor=$script:darkAccent;$c.FlatAppearance.MouseDownBackColor=$script:darkAccent}
  }
  elseif($c -is [Windows.Forms.DataGridView]){
   $c.BackgroundColor=$script:darkPanel;$c.GridColor=$script:uiBorder;$c.EnableHeadersVisualStyles=$false
   $c.ColumnHeadersDefaultCellStyle.BackColor=$script:uiSoft;$c.ColumnHeadersDefaultCellStyle.ForeColor=$script:darkText
   $c.DefaultCellStyle.BackColor=$script:darkPanel;$c.DefaultCellStyle.ForeColor=$script:darkText
   $c.DefaultCellStyle.SelectionBackColor=$script:darkAccent;$c.DefaultCellStyle.SelectionForeColor=$script:uiAccentText
  }
  elseif($c -is [Windows.Forms.Label]){$c.BackColor=[Drawing.Color]::Transparent;if($c.Name -like 'mc-muted*'){$c.ForeColor=$script:darkMuted}}
  else{$c.BackColor=$script:darkPanel}
  foreach($child in $c.Controls){$queue.Enqueue($child)}
 }
 if($script:uiNavButtons){Update-MedicalNavigation}
 if($script:medicalMainMenu){Set-MedicalMenuPalette $script:medicalMainMenu}
}
function Set-RoundedTheme($root){
 # Native input regions must remain intact: do not crop text, caret or borders.
}
function Update-MedicalNavigation {
 if(-not $script:uiNavButtons){return}
 $canExport=[bool]$script:medicalWorkspaceReady
 if($canExport -and $script:stage -eq 'diary' -and $script:medicalClinicalForms){$canExport=(@($script:medicalClinicalForms.Diaries).Count -gt 0)}
 foreach($actionButton in @($previewButton,$printButton)){if($actionButton){$actionButton.Enabled=$canExport}}
 foreach($key in @('initial','diary','discharge')){
  $button=$script:uiNavButtons[$key]
  $active=($script:stage -eq $key)
  $background=if($active){$script:uiSoft}else{$script:darkPanel};$foreground=if($active){$script:darkAccent}else{$script:darkText};$border=if($active){$script:darkAccent}else{$script:uiBorder}
  if($button.BackColor -ne $background){$button.BackColor=$background};if($button.ForeColor -ne $foreground){$button.ForeColor=$foreground};if($button.FlatAppearance.BorderColor -ne $border){$button.FlatAppearance.BorderColor=$border}
 }
 if($script:medicalMainMenu){Update-MedicalMainMenu}
}
function Get-MedicalPatientSummary {
 $name=([string]$script:patientNameControl.Text).Trim()
 $birth=([string]$script:patientBirthControl.Text).Trim()
 if($script:stage -eq 'initial'){
  $identityFields=@(foreach($section in $script:universalConfig.Sections){foreach($field in $section.Fields){if($field.System -in @('name','birth')){$field}}})
  $identitySchema=[pscustomobject]@{Sections=@([pscustomobject]@{Fields=$identityFields})}
  $display=Get-UniversalExportValues $identitySchema $script:universalValues $script:universalDetails
  $name='';$birth=''
  foreach($field in $identityFields){
   if($field.System -eq 'name'){$name=([string]$display[[string]$field.Id]).Trim()}
   elseif($field.System -eq 'birth'){$birth=([string]$display[[string]$field.Id]).Trim()}
  }
 }
 if(-not $name){$name='Новый пациент'}
 if($birth){return ($name+'  •  Дата рождения: '+$birth)}
 return ($name+'  •  Дата рождения не указана')
}
function Add-MedicalSidebarHeading($hostPanel,[string]$text){
 $label=New-Object Windows.Forms.Label;$label.Text=$text;$label.AutoSize=$true
 $label.Name='mc-muted-heading';$label.Font=New-Object Drawing.Font('Segoe UI',9,[Drawing.FontStyle]::Bold)
 $label.Margin=New-Object Windows.Forms.Padding(0,16,0,8);$hostPanel.Controls.Add($label)
}
function Move-MedicalSidebarButton($hostPanel,$button){
 $button.Anchor='Top,Left';$button.Dock='None';$button.AutoSize=$false
 $button.Width=190;$button.Height=40;$button.Margin=New-Object Windows.Forms.Padding(0,0,0,7)
 $button.TextAlign='MiddleLeft';$button.Padding=New-Object Windows.Forms.Padding(8,0,0,0)
 $hostPanel.Controls.Add($button)
}
function Initialize-MedicalWorkspace {
 $form.SuspendLayout()
 try{
  $form.Text='Медицинский конструктор v72 — Первичный осмотр'
  $form.Size=New-Object Drawing.Size(1320,900)
  $form.MinimumSize=New-Object Drawing.Size(1100,680)
  $form.AutoScaleMode='Dpi';$form.AutoScaleDimensions=New-Object Drawing.SizeF(96,96)
  $layout.Controls.Remove($panel);$layout.Controls.Remove($top);$form.Controls.Remove($layout)
  # Existing handlers remain on their original controls. A hidden command host
  # keeps them alive; menus dispatch through OnClick, not CanSelect/PerformClick.
  $top.Dock='None';$top.Visible=$false;$top.Name='mc-command-host';$top.TabStop=$false
  foreach($button in @($caseOpen,$stageInitial,$stageDiary,$stageDischarge,$save,$previewButton,$printButton,$filePreviewButton,$newInitial,$openFormButton,$saveFormButton,$configure,$fieldSettingsButton,$open,$documentFontButton)){$top.Controls.Add($button)}
  $form.Controls.Add($top)
  $script:uiNavButtons=@{initial=$stageInitial;diary=$stageDiary;discharge=$stageDischarge}
  $save.Name='mc-export';$save.Text='Сохранить карту в Word';$caseSave.Name='mc-case-save'
  $newInitial.Text='Создать новую форму';$configure.Text='Форма и шаблон Word';$open.Text='Выбрать Word-шаблон'
  $theme=New-Object Windows.Forms.ComboBox;$theme.DropDownStyle='DropDownList';$theme.Visible=$false
  $theme.AccessibleName='Тема интерфейса';$theme.Items.AddRange([object[]]@('Светлая клиническая','Тёмная графитовая','Высокая контрастность'))
  $theme.SelectedIndex=@('light','dark','contrast').IndexOf($script:uiTheme);$script:uiThemeControl=$theme;$top.Controls.Add($theme)
  $theme.Add_SelectedIndexChanged({
   if($this.SelectedIndex -lt 0){return}
   $selected=@('light','dark','contrast')[$this.SelectedIndex]
   Set-MedicalPalette $selected;Set-DarkTheme $form
   $panel.BackColor=$script:darkBg
   if($script:universalFlow -and -not $script:universalFlow.IsDisposed){$script:universalFlow.BackColor=$script:darkBg}
   if($script:medicalClinicalFlow -and -not $script:medicalClinicalFlow.IsDisposed){$script:medicalClinicalFlow.BackColor=$script:darkBg}
   if($script:medicalClinicalForms -and $script:stage -ne 'initial'){Update-MedicalClinicalCompletion}else{Update-UniversalCompletion}
   Update-MedicalNavigation
   try{Write-MedicalAppearance $selected}catch{[void][Windows.Forms.MessageBox]::Show('Тема применена, но не сохранена: '+$_.Exception.Message,'Оформление')}
  })
  $root=New-Object Windows.Forms.TableLayoutPanel
  $root.Name='mc-full-workspace';$root.Dock='Fill';$root.ColumnCount=1;$root.RowCount=5;$root.Padding=New-Object Windows.Forms.Padding(0);$root.Margin=New-Object Windows.Forms.Padding(0)
  [void]$root.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
  [void]$root.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::AutoSize)))
  foreach($height in @(68,42)){[void]$root.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute,$height)))}
  [void]$root.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent,100)))
  [void]$root.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute,36)))
  $buttons=@{OpenCard=$caseOpen;NewForm=$newInitial;OpenForm=$openFormButton;SaveForm=$saveFormButton;SaveCard=$caseSave;Export=$save;Preview=$previewButton;Print=$printButton;PreviewFile=$filePreviewButton;TemplateEditor=$configure;FieldSettings=$fieldSettingsButton;Templates=$open;Font=$documentFontButton;initial=$stageInitial;diary=$stageDiary;discharge=$stageDischarge}
  $menu=New-MedicalMainMenu $form $buttons $theme
  $form.MainMenuStrip=$menu;$root.Controls.Add($menu,0,0)
  $header=New-Object Windows.Forms.TableLayoutPanel;$header.Dock='Fill';$header.ColumnCount=2;$header.RowCount=1
  $header.Padding=New-Object Windows.Forms.Padding(18,6,18,4);$header.Margin=New-Object Windows.Forms.Padding(0)
  [void]$header.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,68)))
  [void]$header.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,32)))
  $identity=New-Object Windows.Forms.FlowLayoutPanel;$identity.FlowDirection='TopDown';$identity.WrapContents=$false;$identity.Dock='Fill'
  $brand.AutoSize=$true;$brand.Font=New-Object Drawing.Font('Segoe UI',13,[Drawing.FontStyle]::Bold);$brand.Margin=New-Object Windows.Forms.Padding(0,0,0,2);$identity.Controls.Add($brand)
  $version.Text='v72  •  Осмотр, дневники и эпикриз'
  if($script:medicalAuthSession){$version.Text+='  •  '+$script:medicalAuthSession.DisplayName}
  $version.Name='mc-muted-version';$version.AutoSize=$true;$version.UseMnemonic=$false;$version.Anchor='Top,Left';$version.TextAlign='MiddleLeft';$version.Margin=New-Object Windows.Forms.Padding(0);$identity.Controls.Add($version)
  $stageLabel=New-Object Windows.Forms.Label;$stageLabel.Name='mc-current-stage';$stageLabel.Dock='Fill';$stageLabel.TextAlign='MiddleRight';$stageLabel.AutoEllipsis=$true;$stageLabel.Font=New-Object Drawing.Font('Segoe UI',11,[Drawing.FontStyle]::Bold)
  $script:medicalMenuStageLabel=$stageLabel
  $header.Controls.Add($identity,0,0);$header.Controls.Add($stageLabel,1,0);$root.Controls.Add($header,0,1)
  $patient=New-Object Windows.Forms.Label;$patient.Dock='Fill';$patient.Margin=New-Object Windows.Forms.Padding(20,0,20,0)
  $patient.TextAlign='MiddleLeft';$patient.AutoEllipsis=$true;$patient.UseMnemonic=$false;$patient.Font=New-Object Drawing.Font('Segoe UI',11,[Drawing.FontStyle]::Bold)
  $patient.Text='Новый пациент';$script:uiPatientLabel=$patient;$root.Controls.Add($patient,0,2)
  $panel.Dock='Fill';$panel.Margin=New-Object Windows.Forms.Padding(0);$root.Controls.Add($panel,0,3)
  $status=New-Object Windows.Forms.TableLayoutPanel;$status.ColumnCount=2;$status.RowCount=1;$status.Dock='Fill';$status.Padding=New-Object Windows.Forms.Padding(16,0,16,0);$status.Margin=New-Object Windows.Forms.Padding(0)
  [void]$status.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,55)))
  [void]$status.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,45)))
  $formStatus=New-Object Windows.Forms.Label;$formStatus.Dock='Fill';$formStatus.Name='mc-muted-form';$formStatus.TextAlign='MiddleLeft';$formStatus.AutoEllipsis=$true;$formStatus.UseMnemonic=$false;$formStatus.Margin=New-Object Windows.Forms.Padding(0);$script:uiMedicalFormStatus=$formStatus
  $script:progressLabel.Dock='Fill';$script:progressLabel.TextAlign='MiddleRight';$script:progressLabel.Margin=New-Object Windows.Forms.Padding(0)
  $status.Controls.Add($formStatus,0,0);$status.Controls.Add($script:progressLabel,1,0);$root.Controls.Add($status,0,4)
  $form.Controls.Add($root);$script:uiRoot=$root
  $layout.Dispose()
  Set-DarkTheme $form;$panel.BackColor=$script:darkBg
  $script:uiTooltip=New-Object Windows.Forms.ToolTip
  $script:uiTooltip.SetToolTip($patient,'Этапы карты: меню «Вид». Сохранение и открытие: меню «Файл».')
  $form.KeyPreview=$true
  Update-MedicalNavigation
 }finally{$form.ResumeLayout($true)}
}
Set-MedicalPalette (Read-MedicalAppearance)
