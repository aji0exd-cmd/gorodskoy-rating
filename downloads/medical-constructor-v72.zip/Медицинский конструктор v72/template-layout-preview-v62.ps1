﻿# v62: local, approximate layout of the template; exact pagination remains Word's job.
# The renderer creates no links or scripts and never reads patient answers.

function Get-MedicalHtmlProperty($value,[string]$name,$fallback){
 if($value -is [Collections.IDictionary] -and $value.Contains($name)){return $value[$name]};if($null -ne $value -and $null -ne $value.PSObject.Properties[$name]){return $value.$name};return $fallback
}

function ConvertTo-MedicalHtmlNumber($number,[double]$fallback=0,[double]$minimum=-1000,[double]$maximum=1000){
 try{$value=[double]$number;if([double]::IsNaN($value) -or [double]::IsInfinity($value)){throw 'Invalid number'}}catch{$value=$fallback}
 return ([Math]::Max($minimum,[Math]::Min($maximum,$value))).ToString('0.###',[Globalization.CultureInfo]::InvariantCulture)
}

function ConvertTo-MedicalHtmlFont([string]$name){
 # Restrict user fonts to names, so a name can never introduce a CSS declaration.
 $safe=[regex]::Replace($name,'[^\p{L}\p{N}\p{M} _\-]','')
 if([string]::IsNullOrWhiteSpace($safe)){$safe='Times New Roman'}
 return [Net.WebUtility]::HtmlEncode($safe)
}

function Get-MedicalHtmlParagraphCss($format){
 $alignment=[string](Get-MedicalHtmlProperty $format 'Alignment' 'left')
 if($alignment -eq 'both'){$alignment='justify'}
 if($alignment -notin @('left','center','right','justify')){$alignment='left'}
 $font=ConvertTo-MedicalHtmlFont ([string](Get-MedicalHtmlProperty $format 'FontName' 'Times New Roman'))
 $size=ConvertTo-MedicalHtmlNumber (Get-MedicalHtmlProperty $format 'FontSize' 12) 12 1 200
 $color=[string](Get-MedicalHtmlProperty $format 'FontColor' '#000000');$color=$color.TrimStart('#');if($color -notmatch '^[a-fA-F0-9]{6}$'){$color='000000'}
 $weight=if(Get-MedicalHtmlProperty $format 'Bold' $false){'bold'}else{'normal'}
 $italic=if(Get-MedicalHtmlProperty $format 'Italic' $false){'italic'}else{'normal'}
 $underline='none' # Underlining belongs to the individual spans; ancestor decoration cannot be undone by a normal run.
 $left=ConvertTo-MedicalHtmlNumber (Get-MedicalHtmlProperty $format 'LeftIndentCm' 0) 0 -50 50
 $right=ConvertTo-MedicalHtmlNumber (Get-MedicalHtmlProperty $format 'RightIndentCm' 0) 0 -50 50
 $first=ConvertTo-MedicalHtmlNumber (Get-MedicalHtmlProperty $format 'FirstLineCm' 0) 0 -50 50
 $before=ConvertTo-MedicalHtmlNumber (Get-MedicalHtmlProperty $format 'SpaceBeforePt' 0) 0 0 2000
 $after=ConvertTo-MedicalHtmlNumber (Get-MedicalHtmlProperty $format 'SpaceAfterPt' 0) 0 0 2000
 $lineRule=[string](Get-MedicalHtmlProperty $format 'LineRule' 'auto')
 $line=[double](Get-MedicalHtmlProperty $format 'LineSpacing' 1);if($lineRule -in @('exact','atLeast')){$line=[double](Get-MedicalHtmlProperty $format 'LineSpacingPt' 12)}
 $lineCss=if($lineRule -in @('exact','atLeast')){(ConvertTo-MedicalHtmlNumber $line 12 1 1000)+'pt'}else{ConvertTo-MedicalHtmlNumber $line 1 0.1 20}
 return ('text-align:'+$alignment+';font-family:&quot;'+$font+'&quot;,serif;font-size:'+$size+'pt;font-weight:'+$weight+';font-style:'+$italic+';text-decoration:'+$underline+';color:#'+$color+';margin-left:'+$left+'cm;margin-right:'+$right+'cm;text-indent:'+$first+'cm;margin-top:'+$before+'pt;margin-bottom:'+$after+'pt;line-height:'+$lineCss+';')
}

function Get-MedicalHtmlStyleChain($context,[string]$id){
 if(-not $id -or -not $context.Styles){return @()}
 if(-not $context.StyleChains.ContainsKey($id)){$context.StyleChains[$id]=@(Get-MedicalFormatStyleChain $context.Styles $id)}
 return @($context.StyleChains[$id])
}

function Get-MedicalHtmlRunCss($node,$namespaces,$context){
 $paragraph=$node.SelectSingleNode('ancestor::w:p[1]',$namespaces)
 if(-not $context.RunBases.ContainsKey($paragraph)){
  $base=@{FontName='Times New Roman';FontSize=12.0;Bold=$false;Italic=$false;Underline=$false;FontColor='#000000'}
  $styleId=Get-MedicalFormatAttribute ($paragraph.SelectSingleNode('./w:pPr/w:pStyle',$namespaces)) 'val'
  if($context.Styles){
   $styleNs=Get-MedicalEditorNamespace $context.Styles
   Update-MedicalEffectiveRunFormat $base ($context.Styles.SelectSingleNode('/w:styles/w:docDefaults/w:rPrDefault/w:rPr',$styleNs)) $false $context.Theme
   if(-not $styleId){$styleId=Get-MedicalFormatAttribute ($context.Styles.SelectSingleNode('/w:styles/w:style[@w:type="paragraph" and (@w:default="1" or @w:default="true")]',$styleNs)) 'styleId'}
   foreach($style in Get-MedicalHtmlStyleChain $context $styleId){Update-MedicalEffectiveRunFormat $base ($style.SelectSingleNode('./w:rPr',$styleNs)) $true $context.Theme}
  }
  $context.RunBases.Add($paragraph,$base)
 }
 $format=@{};foreach($key in $context.RunBases[$paragraph].Keys){$format[$key]=$context.RunBases[$paragraph][$key]}
 $runStyle=Get-MedicalFormatAttribute ($node.SelectSingleNode('./w:rPr/w:rStyle',$namespaces)) 'val'
 if($context.Styles -and $runStyle){$styleNs=Get-MedicalEditorNamespace $context.Styles;foreach($style in Get-MedicalHtmlStyleChain $context $runStyle){Update-MedicalEffectiveRunFormat $format ($style.SelectSingleNode('./w:rPr',$styleNs)) $true $context.Theme}}
 $properties=$node.SelectSingleNode('./w:rPr',$namespaces);Update-MedicalEffectiveRunFormat $format $properties $false $context.Theme
 $css=New-Object Text.StringBuilder
 [void]$css.Append('font-family:&quot;'+(ConvertTo-MedicalHtmlFont $format.FontName)+'&quot;,serif;font-size:'+(ConvertTo-MedicalHtmlNumber $format.FontSize 12 1 200)+'pt;')
 [void]$css.Append('font-weight:'+$(if($format.Bold){'bold'}else{'normal'})+';font-style:'+$(if($format.Italic){'italic'}else{'normal'})+';text-decoration:'+$(if($format.Underline){'underline'}else{'none'})+';')
 $color=[string]$format.FontColor;if($color -notmatch '^#[a-fA-F0-9]{6}$'){$color='#000000'};[void]$css.Append('color:'+$color+';')
 if($properties){$vertical=$properties.SelectSingleNode('./w:vertAlign',$namespaces);if($vertical){switch(Get-MedicalFormatAttribute $vertical 'val'){'superscript'{[void]$css.Append('vertical-align:super;font-size:smaller;')} 'subscript'{[void]$css.Append('vertical-align:sub;font-size:smaller;')}}}}
 return $css.ToString()
}

function Get-MedicalHtmlImage($node,$context,[string]$partName){
 $relationNamespace='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
 $imageNamespaces=New-Object Xml.XmlNamespaceManager($node.OwnerDocument.NameTable)
 $imageNamespaces.AddNamespace('a','http://schemas.openxmlformats.org/drawingml/2006/main')
 $imageNamespaces.AddNamespace('v','urn:schemas-microsoft-com:vml')
 $blip=$node.SelectSingleNode('.//a:blip|.//v:imagedata',$imageNamespaces)
 $id=if($blip){if($blip.LocalName -eq 'blip'){$blip.GetAttribute('embed',$relationNamespace)}else{$blip.GetAttribute('id',$relationNamespace)}}else{''}
 $partDirectory=[IO.Path]::GetDirectoryName($partName).Replace('\','/')
 $relsName=$partDirectory+'/_rels/'+[IO.Path]::GetFileName($partName)+'.rels'
 $rels=$context.Relationships[$relsName]
 if($id -and $rels -and $rels.ContainsKey($id)){
  $relationship=$rels[$id]
  if($relationship.Mode -ne 'External' -and $relationship.Type.EndsWith('/image')){
   try{
    # URI resolution normalizes relative .. segments, but only package-local media are used.
    $target=([Uri]::new([Uri]('https://package.invalid/'+$partName),[string]$relationship.Target)).AbsolutePath.TrimStart('/')
    if($target.StartsWith('word/media/') -and $context.Entries.ContainsKey($target)){
     $bytes=$context.Entries[$target];$mime=''
     if($bytes.Length -le 8388608 -and $bytes.Length -ge 8){
      if($bytes[0] -eq 137 -and $bytes[1] -eq 80 -and $bytes[2] -eq 78 -and $bytes[3] -eq 71){$mime='image/png'}
      elseif($bytes[0] -eq 255 -and $bytes[1] -eq 216 -and $bytes[2] -eq 255){$mime='image/jpeg'}
     }
     if($mime){
      $drawingNs=New-Object Xml.XmlNamespaceManager($node.OwnerDocument.NameTable);$drawingNs.AddNamespace('wp','http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing')
      $extent=$node.SelectSingleNode('.//wp:extent',$drawingNs);$sizeStyle=''
      if($extent){$imageWidth=0.0;$imageHeight=0.0;if([double]::TryParse($extent.GetAttribute('cx'),[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$imageWidth) -and [double]::TryParse($extent.GetAttribute('cy'),[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$imageHeight)){$sizeStyle=' style="width:'+(ConvertTo-MedicalHtmlNumber ($imageWidth*2.54/914400) 3 0.1 100)+'cm;height:'+(ConvertTo-MedicalHtmlNumber ($imageHeight*2.54/914400) 3 0.1 100)+'cm;"'}}
      return '<img class="word-image" alt="Изображение Word"'+$sizeStyle+' src="data:'+$mime+';base64,'+[Convert]::ToBase64String($bytes)+'" />'
     }
    }
   }catch{}
  }
 }
 return '<span class="object-placeholder">[Изображение — точный вид в «Просмотр Word»]</span>'
}

function ConvertTo-MedicalHtmlInline($node,$context,[string]$partName,$namespaces){
 $html=New-Object Text.StringBuilder
 foreach($child in $node.ChildNodes){
  if($child -isnot [Xml.XmlElement]){continue}
  if($child.NamespaceURI -ne 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'){continue}
  switch($child.LocalName){
   't'{[void]$html.Append([Net.WebUtility]::HtmlEncode($child.InnerText))}
   'tab'{[void]$html.Append('<span class="word-tab">&#9;</span>')}
   'br'{if($child.GetAttribute('type',$child.NamespaceURI) -in @('page','column')){[void]$html.Append('<span class="page-break">Разрыв страницы / колонки</span>')}else{[void]$html.Append('<br />')}}
   'cr'{[void]$html.Append('<br />')}
   'r'{[void]$html.Append('<span style="'+(Get-MedicalHtmlRunCss $child $namespaces $context)+'">'+(ConvertTo-MedicalHtmlInline $child $context $partName $namespaces)+'</span>')}
   'drawing'{[void]$html.Append((Get-MedicalHtmlImage $child $context $partName))}
   'pict'{[void]$html.Append((Get-MedicalHtmlImage $child $context $partName))}
   'object'{[void]$html.Append('<span class="object-placeholder">[Объект Word]</span>')}
   'sym'{[void]$html.Append('<span class="object-placeholder">[Символ Word]</span>')}
   'sdt'{[void]$html.Append((ConvertTo-MedicalHtmlInline $child $context $partName $namespaces))}
   'sdtContent'{[void]$html.Append((ConvertTo-MedicalHtmlInline $child $context $partName $namespaces))}
   'hyperlink'{[void]$html.Append((ConvertTo-MedicalHtmlInline $child $context $partName $namespaces))}
   'ins'{[void]$html.Append((ConvertTo-MedicalHtmlInline $child $context $partName $namespaces))}
   'smartTag'{[void]$html.Append((ConvertTo-MedicalHtmlInline $child $context $partName $namespaces))}
  }
 }
 return $html.ToString()
}

function ConvertTo-MedicalHtmlBlocks($node,$context,[string]$partName,$namespaces){
 $html=New-Object Text.StringBuilder;$ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 foreach($child in $node.ChildNodes){
  if($child -isnot [Xml.XmlElement] -or $child.NamespaceURI -ne $ns){continue}
  switch($child.LocalName){
   'p'{
    $record=$context.Paragraphs[$child]
    $format=if($record){Get-MedicalParagraphFormat $context.Model $record.Id}else{$null}
    $selected=($record -and $record.Id -ceq $context.SelectedId)
    $class=if($selected){'word-paragraph selected'}else{'word-paragraph'}
    $id=if($selected){' id="selected-paragraph"'}else{''}
    # Native WebBrowser click handling uses this inert, escaped model identifier.
    $paragraphAttribute=if($record){' data-mc-paragraph="'+[Net.WebUtility]::HtmlEncode([string]$record.Id)+'"'}else{''}
    $inline=ConvertTo-MedicalHtmlInline $child $context $partName $namespaces;if(-not $inline){$inline='&#160;'}
    $prefix='';if(Get-MedicalFormatToggle ($child.SelectSingleNode('./w:pPr/w:pageBreakBefore',$namespaces))){$prefix='<div class="page-break">Разрыв страницы перед абзацем</div>'}
    [void]$html.Append($prefix+'<div class="'+$class+'"'+$id+$paragraphAttribute+' style="'+(Get-MedicalHtmlParagraphCss $format)+'">'+$inline+'</div>')
    if($child.SelectSingleNode('./w:pPr/w:sectPr',$namespaces)){[void]$html.Append('<div class="section-break">Конец раздела Word</div>')}
   }
   'tbl'{
    $width=$child.SelectSingleNode('./w:tblPr/w:tblW',$namespaces);$tableCss=''
    if($width -and $width.GetAttribute('type',$ns) -eq 'dxa'){$tableCss='width:'+(ConvertTo-MedicalHtmlNumber ((Get-MedicalFormatNumber $width 'w' 8505)/567) 15 0.1 100)+'cm;'}
    elseif($width -and $width.GetAttribute('type',$ns) -eq 'pct'){$tableCss='width:'+(ConvertTo-MedicalHtmlNumber ((Get-MedicalFormatNumber $width 'w' 5000)/50) 100 1 100)+'%;'}
    [void]$html.Append('<table class="word-table" style="'+$tableCss+'">')
    $grid=@($child.SelectNodes('./w:tblGrid/w:gridCol',$namespaces))
    if($grid.Count){[void]$html.Append('<colgroup>');foreach($column in $grid){[void]$html.Append('<col style="width:'+(ConvertTo-MedicalHtmlNumber ((Get-MedicalFormatNumber $column 'w' 1701)/567) 3 0.1 100)+'cm;" />')};[void]$html.Append('</colgroup>')}
    foreach($row in $child.SelectNodes('./w:tr',$namespaces)){
     [void]$html.Append('<tr>')
     foreach($cell in $row.SelectNodes('./w:tc',$namespaces)){
      $span=$cell.SelectSingleNode('./w:tcPr/w:gridSpan',$namespaces);$spanAttribute=''
      if($span){$count=ConvertTo-MedicalHtmlNumber $span.GetAttribute('val',$ns) 1 1 64;$spanAttribute=' colspan="'+$count+'"'}
      $cellWidth=$cell.SelectSingleNode('./w:tcPr/w:tcW',$namespaces);$cellCss=''
      if($cellWidth -and $cellWidth.GetAttribute('type',$ns) -eq 'dxa'){$cellCss='width:'+(ConvertTo-MedicalHtmlNumber ((Get-MedicalFormatNumber $cellWidth 'w' 1701)/567) 3 0.1 100)+'cm;'}
      [void]$html.Append('<td'+$spanAttribute+' style="'+$cellCss+'">'+(ConvertTo-MedicalHtmlBlocks $cell $context $partName $namespaces)+'</td>')
     }
     [void]$html.Append('</tr>')
    }
    [void]$html.Append('</table>')
   }
   'sdt'{[void]$html.Append((ConvertTo-MedicalHtmlBlocks $child $context $partName $namespaces))}
   'sdtContent'{[void]$html.Append((ConvertTo-MedicalHtmlBlocks $child $context $partName $namespaces))}
   'ins'{[void]$html.Append((ConvertTo-MedicalHtmlBlocks $child $context $partName $namespaces))}
   'customXml'{[void]$html.Append((ConvertTo-MedicalHtmlBlocks $child $context $partName $namespaces))}
  }
 }
 return $html.ToString()
}

function ConvertTo-MedicalTemplateHtml($model,[string]$selectedId='',[double]$viewportWidth=0){
 $map=New-Object 'Collections.Generic.Dictionary[Xml.XmlNode,object]'
 foreach($paragraph in $model.Paragraphs){$map.Add($paragraph.Node,$paragraph)}
 $entries=@{};$relationships=@{}
 foreach($entry in $model.Entries){
  $entries[$entry.Name]=$entry.Bytes
  if($entry.Name -cmatch '^word/(?:.*?/)?_rels/[^/]+\.rels$'){
   try{
    $xml=Read-MedicalEditorXml $entry.Bytes;$rels=@{}
    foreach($relationship in $xml.DocumentElement.ChildNodes){
     if($relationship -is [Xml.XmlElement] -and $relationship.LocalName -eq 'Relationship'){
      $rels[$relationship.GetAttribute('Id')]=[pscustomobject]@{Type=$relationship.GetAttribute('Type');Target=$relationship.GetAttribute('Target');Mode=$relationship.GetAttribute('TargetMode')}
     }
    }
    $relationships[$entry.Name]=$rels
   }catch{}
  }
 }
 $context=[pscustomobject]@{Model=$model;Paragraphs=$map;Entries=$entries;Relationships=$relationships;SelectedId=$selectedId;Styles=(Get-MedicalFormatResourceXml $model 'word/styles.xml');Theme=(Get-MedicalFormatResourceXml $model 'word/theme/theme1.xml');StyleChains=@{};RunBases=(New-Object 'Collections.Generic.Dictionary[Xml.XmlNode,object]')}
 $bodyRecord=@($model.Paragraphs | Where-Object {$_.Part -ceq 'word/document.xml'}) | Select-Object -First 1
 $layout=Get-MedicalPageLayout $model $(if($bodyRecord){$bodyRecord.Id}else{''})
 $width=ConvertTo-MedicalHtmlNumber (Get-MedicalHtmlProperty $layout 'PageWidthCm' 21) 21 1 100
 $height=ConvertTo-MedicalHtmlNumber (Get-MedicalHtmlProperty $layout 'PageHeightCm' 29.7) 29.7 1 100
 # IE's CSS zoom fits the sheet without rewriting Word dimensions or requiring scripts.
 # A zero width keeps standalone/export rendering at the original physical scale.
 $zoomCss=''
 if($viewportWidth -gt 0 -and -not [double]::IsInfinity($viewportWidth)){
  $pagePixels=[double]::Parse($width,[Globalization.CultureInfo]::InvariantCulture)*96/2.54
  $zoom=ConvertTo-MedicalHtmlNumber (($viewportWidth-32)/$pagePixels) 1 0.1 1
  $zoomCss='zoom:'+$zoom+';'
 }
 $left=ConvertTo-MedicalHtmlNumber (Get-MedicalHtmlProperty $layout 'MarginLeftCm' 2) 2 0 50
 $right=ConvertTo-MedicalHtmlNumber (Get-MedicalHtmlProperty $layout 'MarginRightCm' 2) 2 0 50
 $top=ConvertTo-MedicalHtmlNumber (Get-MedicalHtmlProperty $layout 'MarginTopCm' 2) 2 0 50
 $bottom=ConvertTo-MedicalHtmlNumber (Get-MedicalHtmlProperty $layout 'MarginBottomCm' 2) 2 0 50
 $html=New-Object Text.StringBuilder
 [void]$html.Append('<!DOCTYPE html><html><head><meta http-equiv="X-UA-Compatible" content="IE=edge" /><meta charset="utf-8" /><meta http-equiv="Content-Security-Policy" content="default-src &#39;none&#39;; img-src data:; style-src &#39;unsafe-inline&#39;" /><title>Макет шаблона Word</title><style>html,body{margin:0;padding:0;background:#dce2e8;color:#111}body{font:12px Segoe UI,sans-serif}.notice{padding:8px 12px;background:#eff4f9;color:#334455}.sheet{background:white;box-sizing:border-box;margin:14px auto;box-shadow:0 1px 6px #8694a3;overflow-wrap:break-word;word-wrap:break-word}.word-paragraph{padding:0;white-space:pre-wrap;min-height:1em;cursor:pointer}.selected{outline:1px solid #2473bd;background:#eef6ff}.word-tab{white-space:pre}.word-table{border-collapse:collapse;table-layout:fixed;max-width:100%;margin:0}.word-table td{border:1px solid #c5c5c5;vertical-align:top;padding:2pt 4pt;overflow-wrap:break-word}.word-table .word-paragraph{margin:0}.word-image{max-width:100%;height:auto}.object-placeholder{font:10pt Segoe UI,sans-serif;color:#6d6d6d;background:#f1f1f1}.page-break,.section-break{display:block;text-align:center;text-indent:0;border-top:1px dashed #9da8b3;color:#6a7886;font:9pt Segoe UI,sans-serif;margin:8pt 0;padding:4pt}.part-label{font:9pt Segoe UI,sans-serif;color:#788696;margin:0 0 8pt;border-bottom:1px solid #e1e6ec}.header-part,.footer-part{margin:8pt 0}.footer-part{border-top:1px solid #e1e6ec;padding-top:6pt}</style></head><body><div class="notice">Макет без пагинации Word. Для точных страниц используйте «Просмотр Word». Границы таблиц показаны для удобства.</div><div class="sheet" style="width:'+$width+'cm;padding:'+$top+'cm '+$right+'cm '+$bottom+'cm '+$left+'cm;min-height:'+$height+'cm;'+$zoomCss+'">')
 foreach($partName in $model.PartOrder | Where-Object {$_ -cmatch '^word/header'}){
  $xml=$model.Parts[$partName].Xml;[void]$html.Append('<div class="header-part"><div class="part-label">Верхний колонтитул: '+[Net.WebUtility]::HtmlEncode($partName)+'</div>'+(ConvertTo-MedicalHtmlBlocks $xml.DocumentElement $context $partName (Get-MedicalEditorNamespace $xml))+'</div>')
 }
 $document=$model.Parts['word/document.xml'].Xml;$namespaces=Get-MedicalEditorNamespace $document
 $body=$document.SelectSingleNode('/w:document/w:body',$namespaces)
 [void]$html.Append((ConvertTo-MedicalHtmlBlocks $body $context 'word/document.xml' $namespaces))
 foreach($partName in $model.PartOrder | Where-Object {$_ -cmatch '^word/footer'}){
  $xml=$model.Parts[$partName].Xml;[void]$html.Append('<div class="footer-part"><div class="part-label">Нижний колонтитул: '+[Net.WebUtility]::HtmlEncode($partName)+'</div>'+(ConvertTo-MedicalHtmlBlocks $xml.DocumentElement $context $partName (Get-MedicalEditorNamespace $xml))+'</div>')
 }
 [void]$html.Append('</div></body></html>');return $html.ToString()
}
