﻿# Clinical schemas belong to reusable forms. Patient values belong to cases only.
$script:medicalClinicalForms=$null
$script:medicalClinicalState=$null

function ConvertTo-MedicalClinicalMap($source){
 $result=@{}
 if($source -is [Collections.IDictionary]){foreach($key in $source.Keys){$result[[string]$key]=$source[$key]}}
 elseif($source){foreach($property in $source.PSObject.Properties){$result[$property.Name]=$property.Value}}
 return $result
}
function Copy-MedicalClinicalValues($source,$schema,[bool]$details=$false){
 $map=ConvertTo-MedicalClinicalMap $source;$result=@{}
 foreach($field in Get-UniversalFields $schema){
  $id=[string]$field.Id
  if($map.ContainsKey($id) -and (-not $details -or $field.Type -eq 'choice_detail')){$result[$id]=[string]$map[$id]}
 }
 return $result
}
function Get-MedicalInitialState {return (Get-UniversalState)}
function New-MedicalDiarySchema($initial=$script:universalConfig){
 $patientFields=@(foreach($source in Get-UniversalFields $initial){
  if($source.System){
   $field=New-UniversalField ([string]$source.Id) ([string]$source.Label) ([string]$source.Marker) 'text' ([string]$source.System)
   $field.Required=$false;$field
  }
 })
 $sections=@();$usedIds=@{};$usedMarkers=@{}
 foreach($field in $patientFields){$usedIds[[string]$field.Id]=$true;$usedMarkers[[string]$field.Marker]=$true}
 if($patientFields.Count){$sections+=@([pscustomobject]@{Id='diary_patient';Title='Сведения о пациенте';Fields=$patientFields})}
 foreach($definition in @(
  @('diary_complaints','Жалобы','DIARY_COMPLAINTS'),
  @('diary_examination','Объективное состояние','DIARY_EXAMINATION'),
  @('diary_progress','Динамика состояния','DIARY_PROGRESS'),
  @('diary_treatment','Лечение и назначения','DIARY_TREATMENT')
 )){
  $id=$definition[0];$marker=$definition[2];$suffix=1
  while($usedIds.ContainsKey($id)){$id=$definition[0]+'_'+$suffix;$suffix++}
  $suffix=1;while($usedMarkers.ContainsKey($marker)){$marker=$definition[2]+'_'+$suffix;$suffix++}
  $usedIds[$id]=$true;$usedMarkers[$marker]=$true
  $field=New-UniversalField $id $definition[1] $marker;$field.Required=$false
  $sections+=@([pscustomobject]@{Id=$id;Title=$definition[1];Fields=@($field)})
 }
 $schema=[pscustomobject]@{Version=49;AutoTemplate=$true;Template='Дневник наблюдения.docx';DocumentTitle='Дневник наблюдения';DateTimeLabel='Дата и время записи';PreserveTemplateFormatting=$true;Sections=$sections}
 Assert-UniversalConfig $schema;return $schema
}
function New-MedicalDischargeSchema($initial=$script:universalConfig){
 $schema=Copy-MedicalFormSchema $initial
 # An automatic stage template contains markers, so copied Word dropdown IDs
 # must become ordinary options rather than dangling bindings to another file.
 $wordFields=@()
 $initialPath=Get-UniversalTemplatePath $initial
 if([IO.File]::Exists($initialPath)){$wordFields=@(Get-UniversalWordFields $initialPath)}
 foreach($field in Get-UniversalFields $schema){
  if($field.Type -in @('choice','choice_detail') -and @($field.Options).Count -eq 0){
   $bound=@($wordFields | Where-Object {[string]$_.Id -eq [string]$field.WordId})
   if($bound.Count){$field.Options=@($bound[0].Options)}
   if(@($field.Options).Count -eq 0){throw ('Для эпикриза добавьте варианты списка «'+$field.Label+'» в первичную форму.')}
  }
  $field.WordId=''
 }
 $existingIds=@{};$existingMarkers=@{}
 foreach($field in Get-UniversalFields $schema){$existingIds[[string]$field.Id]=$true;$existingMarkers[[string]$field.Marker]=$true;if($field.DetailMarker){$existingMarkers[[string]$field.DetailMarker]=$true}}
 foreach($definition in @(
  @('final_diagnosis','Заключительный диагноз','FINAL_DIAGNOSIS'),
  @('examination_results','Результаты обследования','EXAMINATION_RESULTS'),
  @('treatment_results','Результаты лечения','TREATMENT_RESULTS'),
  @('recommendations','Рекомендации','RECOMMENDATIONS')
 )){
  $id=$definition[0];$marker=$definition[2];$suffix=1
  while($existingIds.ContainsKey($id)){$id=$definition[0]+'_'+$suffix;$suffix++}
  $suffix=1;while($existingMarkers.ContainsKey($marker)){$marker=$definition[2]+'_'+$suffix;$suffix++}
  $existingIds[$id]=$true;$existingMarkers[$marker]=$true
  $sectionId='discharge_'+$id
  while(@($schema.Sections | Where-Object {[string]$_.Id -eq $sectionId}).Count){$sectionId+='x'}
  $field=New-UniversalField $id $definition[1] $marker;$field.Required=$false
  $schema.Sections+=@([pscustomobject]@{Id=$sectionId;Title=$definition[1];Fields=@($field)})
 }
 $schema.AutoTemplate=$true;$schema.Template='Выписной эпикриз.docx'
 $schema | Add-Member -NotePropertyName DocumentTitle -NotePropertyValue 'Выписной эпикриз' -Force
 $schema | Add-Member -NotePropertyName DateTimeLabel -NotePropertyValue 'Дата и время поступления' -Force
 $schema | Add-Member -NotePropertyName PreserveTemplateFormatting -NotePropertyValue $true -Force
 Assert-UniversalConfig $schema;return $schema
}
function Get-MedicalClinicalDefaultLinks($schema,$initial=$script:universalConfig,[bool]$diagnosis=$false){
 $sources=@(Get-UniversalFields $initial);$result=@{}
 foreach($field in Get-UniversalFields $schema){
  $match=@($sources | Where-Object {[string]$_.Id -eq [string]$field.Id})
  if(-not $match.Count -and $field.System){$match=@($sources | Where-Object {[string]$_.System -eq [string]$field.System})}
  if($match.Count){$result[[string]$field.Id]=[string]$match[0].Id}
  elseif($diagnosis -and [string]$field.Marker -match '^FINAL_DIAGNOSIS(?:_[0-9]+)?$'){
   $match=@($sources | Where-Object {[string]$_.Marker -eq 'PRELIMINARY_DIAGNOSIS'})
   if($match.Count){$result[[string]$field.Id]=[string]$match[0].Id}
  }
 }
 return $result
}
function Copy-MedicalClinicalFormData($source){
 if(-not $source -or [int]$source.Version -ne 1){throw 'Неизвестный формат структуры дневников и эпикриза.'}
 $result=[pscustomobject]@{Version=1;Diaries=@();Discharge=$null};$ids=@{}
 foreach($entry in @($source.Diaries)){
  if(-not $entry){continue}
  $id=[string]$entry.Id
  if($entry.Id -isnot [string] -or [string]::IsNullOrWhiteSpace($id) -or $id.Length -gt 200 -or $ids.ContainsKey($id)){throw 'Повтор или отсутствие строкового идентификатора дневника.'}
  $ids[$id]=$true;$schema=Copy-MedicalFormSchema $entry.Schema
  $title=([string]$entry.Title).Trim();if(-not $title){throw 'Укажите название дневника.'}
  $links=ConvertTo-MedicalClinicalMap $entry.Links;$allowed=@{}
  foreach($field in Get-UniversalFields $schema){
   $fieldId=[string]$field.Id
   if($links.ContainsKey($fieldId) -and -not [string]::IsNullOrWhiteSpace([string]$links[$fieldId])){$allowed[$fieldId]=[string]$links[$fieldId]}
  }
  $result.Diaries+=@([pscustomobject]@{Id=$id;Title=$title;Schema=$schema;Links=$allowed})
 }
 if($source.Discharge){
  $schema=Copy-MedicalFormSchema $source.Discharge.Schema;$links=ConvertTo-MedicalClinicalMap $source.Discharge.Links;$allowed=@{}
  foreach($field in Get-UniversalFields $schema){
   $id=[string]$field.Id
   if($links.ContainsKey($id) -and -not [string]::IsNullOrWhiteSpace([string]$links[$id])){$allowed[$id]=[string]$links[$id]}
  }
  $result.Discharge=[pscustomobject]@{Schema=$schema;Links=$allowed}
  if($source.Discharge.FollowInitialSchema -eq $true){
   if($source.Discharge.FollowInitialSchema -isnot [bool] -or [string]$source.Discharge.InitialSchemaSignature -cnotmatch '^[a-f0-9]{64}$'){throw 'Некорректная связь структуры эпикриза с первичным осмотром.'}
   $generated=ConvertTo-MedicalClinicalMap $source.Discharge.GeneratedFieldIds;$fieldIds=@{};foreach($field in Get-UniversalFields $schema){$fieldIds[[string]$field.Id]=$true}
   $safeGenerated=@{};foreach($category in @('final_diagnosis','examination_results','treatment_results','recommendations')){if($generated[$category] -isnot [string] -or -not $fieldIds.ContainsKey([string]$generated[$category])){throw 'Некорректный идентификатор итогового поля эпикриза.'};$safeGenerated[$category]=[string]$generated[$category]}
   $result.Discharge | Add-Member -NotePropertyName FollowInitialSchema -NotePropertyValue $true
   $result.Discharge | Add-Member -NotePropertyName InitialSchemaSignature -NotePropertyValue ([string]$source.Discharge.InitialSchemaSignature)
   $result.Discharge | Add-Member -NotePropertyName GeneratedFieldIds -NotePropertyValue $safeGenerated
  }
 }
 return $result
}
function New-MedicalClinicalPatientState($forms){
 $state=[pscustomobject]@{Version=1;Diaries=@();Discharge=[pscustomobject]@{Values=@{};Details=@{};Overrides=@{}}}
 foreach($entry in @($forms.Diaries)){
  $state.Diaries+=@([pscustomobject]@{Id=[string]$entry.Id;DateTime=[datetime]::Now.ToString('yyyy-MM-ddTHH:mm:ss');Values=@{};Details=@{};Overrides=@{}})
 }
 return $state
}
function New-MedicalClinicalFormData($initial=$script:universalConfig){
 $discharge=New-MedicalDischargeSchema $initial
 $candidate=[pscustomobject]@{Version=1;Diaries=@();Discharge=[pscustomobject]@{Schema=$discharge;Links=(Get-MedicalClinicalDefaultLinks $discharge $initial $true);FollowInitialSchema=$true;InitialSchemaSignature=(Get-MedicalClinicalInitialSignature $initial);GeneratedFieldIds=(Get-MedicalDischargeGeneratedFieldIds $discharge)}}
 return (Copy-MedicalClinicalFormData $candidate)
}
function Initialize-MedicalClinicalWorkspace($stageForms=$null){
 if($null -ne $stageForms){$candidate=Resolve-MedicalClinicalPortableForms $stageForms}
 else{$candidate=New-MedicalClinicalFormData $script:universalConfig}
 $script:medicalClinicalForms=Copy-MedicalClinicalFormData $candidate
 $script:medicalClinicalState=New-MedicalClinicalPatientState $script:medicalClinicalForms
 return $script:medicalClinicalForms
}
function Get-MedicalClinicalFormData {
 if(-not $script:medicalClinicalForms){[void](Initialize-MedicalClinicalWorkspace)}
 Sync-MedicalDischargeSchemaFromInitial
 return (Copy-MedicalClinicalFormData $script:medicalClinicalForms)
}
function Restore-MedicalClinicalFormData($forms){
 $candidate=Resolve-MedicalClinicalPortableForms $forms
 $script:medicalClinicalForms=Copy-MedicalClinicalFormData $candidate
 $script:medicalClinicalState=New-MedicalClinicalPatientState $script:medicalClinicalForms
}
function Get-MedicalClinicalState {
 if(-not $script:medicalClinicalForms){[void](Initialize-MedicalClinicalWorkspace)}
 foreach($entry in @($script:medicalClinicalForms.Diaries)){
  $binding=Get-MedicalClinicalBinding 'diary' ([string]$entry.Id);Sync-MedicalClinicalLinks $binding.Definition $binding.State
 }
 Sync-MedicalDischargeFromInitial
 return (Copy-UniversalObject $script:medicalClinicalState)
}
function Copy-MedicalClinicalPatientState($source,$forms){
 if(-not $source){return (New-MedicalClinicalPatientState $forms)}
 if([int]$source.Version -ne 1){throw 'Неизвестная версия ответов дневников и эпикриза.'}
 $forms=Copy-MedicalClinicalFormData $forms;$candidate=New-MedicalClinicalPatientState $forms;$seen=@{}
 foreach($entry in @($source.Diaries)){
  if(-not $entry){continue}
  $id=[string]$entry.Id
  if($entry.Id -isnot [string] -or -not $id -or $seen.ContainsKey($id)){throw 'Повтор или отсутствие строкового идентификатора ответов дневника.'};$seen[$id]=$true
  $definition=@($forms.Diaries | Where-Object {[string]$_.Id -eq $id})
  if(-not $definition.Count){throw 'Ответы дневника не соответствуют структуре текущей формы.'}
  $target=@($candidate.Diaries | Where-Object {[string]$_.Id -eq $id})[0]
  $date=[datetime]::MinValue
  if($entry.DateTime -is [datetime]){$date=[datetime]$entry.DateTime}
  elseif(-not [datetime]::TryParseExact([string]$entry.DateTime,'yyyy-MM-ddTHH:mm:ss',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$date)){throw 'Некорректная дата дневника.'}
  if($date -lt [datetime]'1753-01-01' -or $date -gt [datetime]'9998-12-31'){throw 'Дата дневника находится вне допустимого диапазона календаря.'}
  $target.DateTime=$date.ToString('yyyy-MM-ddTHH:mm:ss')
  $target.Values=Copy-MedicalClinicalValues $entry.Values $definition[0].Schema
  $target.Details=Copy-MedicalClinicalValues $entry.Details $definition[0].Schema $true
  $overrides=ConvertTo-MedicalClinicalMap $entry.Overrides;$target.Overrides=@{}
  foreach($field in Get-UniversalFields $definition[0].Schema){if($overrides[[string]$field.Id] -eq $true){$target.Overrides[[string]$field.Id]=$true}}
 }
 if($forms.Discharge -and $source.Discharge){
  $candidate.Discharge.Values=Copy-MedicalClinicalValues $source.Discharge.Values $forms.Discharge.Schema
  $candidate.Discharge.Details=Copy-MedicalClinicalValues $source.Discharge.Details $forms.Discharge.Schema $true
  $overrides=ConvertTo-MedicalClinicalMap $source.Discharge.Overrides
  foreach($field in Get-UniversalFields $forms.Discharge.Schema){if($overrides[[string]$field.Id] -eq $true){$candidate.Discharge.Overrides[[string]$field.Id]=$true}}
 }
 return $candidate
}
function Test-MedicalClinicalState($source,$forms){
 [void](Copy-MedicalClinicalPatientState $source $forms)
}
function Restore-MedicalClinicalState($source){
 if(-not $source){return}
 $candidate=Copy-MedicalClinicalPatientState $source (Get-MedicalClinicalFormData)
 $script:medicalClinicalState=$candidate
 Sync-MedicalDischargeFromInitial
}
function Get-MedicalClinicalBinding([string]$stage,[string]$id=''){
 if(-not $script:medicalClinicalForms){[void](Initialize-MedicalClinicalWorkspace)}
 Sync-MedicalDischargeSchemaFromInitial
 if($stage -eq 'diary'){
  $definition=@($script:medicalClinicalForms.Diaries | Where-Object {[string]$_.Id -eq $id})
  $state=@($script:medicalClinicalState.Diaries | Where-Object {[string]$_.Id -eq $id})
  if($definition.Count -ne 1 -or $state.Count -ne 1){throw 'Дневник не найден в текущей форме.'}
  return [pscustomobject]@{Definition=$definition[0];State=$state[0]}
 }
 if($stage -eq 'discharge' -and $script:medicalClinicalForms.Discharge){return [pscustomobject]@{Definition=$script:medicalClinicalForms.Discharge;State=$script:medicalClinicalState.Discharge}}
 throw 'Выберите дневник или выписной эпикриз.'
}
function Sync-MedicalClinicalLinks($definition,$state){
 $values=ConvertTo-MedicalClinicalMap $script:universalValues;$details=ConvertTo-MedicalClinicalMap $script:universalDetails
 $initialIds=@{};foreach($field in Get-UniversalFields $script:universalConfig){$initialIds[[string]$field.Id]=$field}
 $displayValues=Get-UniversalExportValues $script:universalConfig $values $details
 foreach($targetId in @($definition.Links.Keys)){
  $sourceId=[string]$definition.Links[$targetId]
  if(-not $state.Overrides.ContainsKey([string]$targetId) -and $initialIds.ContainsKey($sourceId)){
   $target=@(Get-UniversalFields $definition.Schema | Where-Object {[string]$_.Id -eq [string]$targetId})
   if($target.Count -and $target[0].Type -ne $initialIds[$sourceId].Type){$state.Values[[string]$targetId]=[string]$displayValues[$sourceId]}
   else{$state.Values[[string]$targetId]=[string]$values[$sourceId]}
   if($target.Count -and $target[0].Type -eq 'choice_detail'){$state.Details[[string]$targetId]=[string]$details[$sourceId]}
  }
 }
}
function Sync-MedicalDischargeFromInitial {
 Sync-MedicalDischargeSchemaFromInitial
 if($script:medicalClinicalForms -and $script:medicalClinicalForms.Discharge){Sync-MedicalClinicalLinks $script:medicalClinicalForms.Discharge $script:medicalClinicalState.Discharge}
}
function Get-MedicalClinicalContext([string]$stage,[string]$id=''){
 $binding=Get-MedicalClinicalBinding $stage $id
 Sync-MedicalClinicalLinks $binding.Definition $binding.State
 $date=[datetime]::Now
 if($stage -eq 'diary'){$date=[datetime]::ParseExact([string]$binding.State.DateTime,'yyyy-MM-ddTHH:mm:ss',[Globalization.CultureInfo]::InvariantCulture)}
 elseif($script:admissionControl){$date=$script:admissionControl.Value}
 $title=if($stage -eq 'diary'){[string]$binding.Definition.Title}else{'Выписной эпикриз'}
 return [pscustomobject]@{Id=$id;Title=$title;Schema=$binding.Definition.Schema;Values=$binding.State.Values;Details=$binding.State.Details;DateTime=$date;Overrides=$binding.State.Overrides}
}
function Get-MedicalClinicalDiaryContexts {
 if(-not $script:medicalClinicalForms){[void](Initialize-MedicalClinicalWorkspace)}
 foreach($entry in @($script:medicalClinicalForms.Diaries)){Get-MedicalClinicalContext 'diary' ([string]$entry.Id)}
}
function Add-MedicalClinicalDiary($schema=$null,[string]$title=''){
 if(-not $script:medicalClinicalForms){[void](Initialize-MedicalClinicalWorkspace)}
 if($null -eq $schema){
  if(@($script:medicalClinicalForms.Diaries).Count){$schema=Copy-MedicalFormSchema $script:medicalClinicalForms.Diaries[-1].Schema}
  else{$schema=New-MedicalDiarySchema}
 }
 $schema=Copy-MedicalFormSchema $schema;$id=[guid]::NewGuid().ToString('N')
 if([string]::IsNullOrWhiteSpace($title)){$title='Дневник наблюдения №'+(@($script:medicalClinicalForms.Diaries).Count+1)}
 $definition=[pscustomobject]@{Id=$id;Title=$title.Trim();Schema=$schema;Links=(Get-MedicalClinicalDefaultLinks $schema)}
 $script:medicalClinicalForms.Diaries+=@($definition)
 $script:medicalClinicalState.Diaries+=@([pscustomobject]@{Id=$id;DateTime=[datetime]::Now.ToString('yyyy-MM-ddTHH:mm:ss');Values=@{};Details=@{};Overrides=@{}})
 return (Get-MedicalClinicalContext 'diary' $id)
}
function Remove-MedicalClinicalDiary([string]$id){
 [void](Get-MedicalClinicalBinding 'diary' $id)
 $script:medicalClinicalForms.Diaries=@($script:medicalClinicalForms.Diaries | Where-Object {[string]$_.Id -ne $id})
 $script:medicalClinicalState.Diaries=@($script:medicalClinicalState.Diaries | Where-Object {[string]$_.Id -ne $id})
}
function Set-MedicalClinicalDate([string]$id,[datetime]$date){
 $binding=Get-MedicalClinicalBinding 'diary' $id;$binding.State.DateTime=$date.ToString('yyyy-MM-ddTHH:mm:ss')
}
function Set-MedicalClinicalValue([string]$stage,[string]$id,[string]$fieldId,[string]$value,$detailValue=$null){
 $binding=Get-MedicalClinicalBinding $stage $id
 $field=@(Get-UniversalFields $binding.Definition.Schema | Where-Object {[string]$_.Id -eq $fieldId})
 if($field.Count -ne 1){throw 'Поле не найдено в текущем этапе.'}
 $newDetail=if($null -eq $detailValue){[string]$binding.State.Details[$fieldId]}else{[string]$detailValue}
 if($binding.Definition.Links.ContainsKey($fieldId)){
  $sourceId=[string]$binding.Definition.Links[$fieldId]
  $sourceField=@(Get-UniversalFields $script:universalConfig | Where-Object {[string]$_.Id -eq $sourceId})
  $sourceValue=[string]$script:universalValues[$sourceId]
  if($sourceField.Count -and $field[0].Type -ne $sourceField[0].Type){$sourceValues=Get-UniversalExportValues $script:universalConfig $script:universalValues $script:universalDetails;$sourceValue=[string]$sourceValues[$sourceId]}
  if($value -cne $sourceValue -or ($field[0].Type -eq 'choice_detail' -and $newDetail -cne [string]$script:universalDetails[$sourceId])){$binding.State.Overrides[$fieldId]=$true}
 }
 $binding.State.Values[$fieldId]=$value
 if($field[0].Type -eq 'choice_detail'){$binding.State.Details[$fieldId]=$newDetail}
}
function Reset-MedicalClinicalLink([string]$stage,[string]$id,[string]$fieldId){
 $binding=Get-MedicalClinicalBinding $stage $id
 if(-not $binding.Definition.Links.ContainsKey($fieldId)){throw 'Это поле не связано с первичным осмотром.'}
 $binding.State.Overrides.Remove($fieldId);Sync-MedicalClinicalLinks $binding.Definition $binding.State
}
function Set-MedicalClinicalSchema([string]$stage,[string]$id,$schema,[string]$title=''){
 $candidate=Copy-MedicalFormSchema $schema;$binding=Get-MedicalClinicalBinding $stage $id
 $values=Copy-MedicalClinicalValues $binding.State.Values $candidate
 $details=Copy-MedicalClinicalValues $binding.State.Details $candidate $true
 $links=Get-MedicalClinicalDefaultLinks $candidate $script:universalConfig ($stage -eq 'discharge')
 foreach($field in Get-UniversalFields $candidate){
  $fieldId=[string]$field.Id
  if($binding.Definition.Links.ContainsKey($fieldId)){$links[$fieldId]=[string]$binding.Definition.Links[$fieldId]}
 }
 $binding.Definition.Schema=$candidate;$binding.Definition.Links=$links
 if($stage -eq 'discharge'){$binding.Definition | Add-Member -NotePropertyName FollowInitialSchema -NotePropertyValue $false -Force}
 if($stage -eq 'diary' -and -not [string]::IsNullOrWhiteSpace($title)){$binding.Definition.Title=$title.Trim()}
 $binding.State.Values=$values;$binding.State.Details=$details
 $overrides=@{};foreach($field in Get-UniversalFields $candidate){if($binding.State.Overrides.ContainsKey([string]$field.Id)){$overrides[[string]$field.Id]=$true}}
 $binding.State.Overrides=$overrides
 Sync-MedicalClinicalLinks $binding.Definition $binding.State
 return (Get-MedicalClinicalContext $stage $id)
}
function Get-MedicalClinicalExportValues([string]$stage,[string]$id=''){
 $context=Get-MedicalClinicalContext $stage $id
 return (Get-UniversalExportValues $context.Schema $context.Values $context.Details)
}

# Portable structure snapshots use the same checked template envelope as .mcform.
# Missing Word files may be retained in a recovery snapshot without blocking data.
function Get-MedicalClinicalPortableForms([bool]$allowMissing=$false,$forms=$null){
 if($null -eq $forms){$forms=Get-MedicalClinicalFormData}
 $copy=Copy-MedicalClinicalFormData $forms
 $definitions=@($copy.Diaries);if($copy.Discharge){$definitions+=@($copy.Discharge)}
 foreach($definition in $definitions){
  try{
   $asset=Get-MedicalFormTemplateAsset $definition.Schema
   foreach($property in @('TemplateName','TemplateSha256','TemplateBase64')){$definition | Add-Member -NotePropertyName $property -NotePropertyValue $asset.$property -Force}
   $definition.Schema.Template='Шаблоны/'+$asset.TemplateName
  }catch{if(-not $allowMissing){throw};$definition | Add-Member -NotePropertyName TemplateMissing -NotePropertyValue $true -Force}
 }
 return $copy
}
function Resolve-MedicalClinicalPortableForms($forms){
 $copy=Copy-MedicalClinicalFormData $forms
 $original=@($forms.Diaries);$definitions=@($copy.Diaries)
 if($forms.Discharge){$original+=@($forms.Discharge);$definitions+=@($copy.Discharge)}
 $assets=@()
 for($i=0;$i -lt $original.Count;$i++){
  $source=$original[$i]
  if($source.PSObject.Properties['TemplateBase64']){$assets+=@(Test-MedicalFormTemplateAsset $source)}else{$assets+=@($null)}
 }
 # Validate every schema and every hash before importing even the first template.
 for($i=0;$i -lt $definitions.Count;$i++){
  if($assets[$i]){
   $template=Import-MedicalTemplateBytes $assets[$i].Bytes $assets[$i].TemplateName
   $definitions[$i].Schema.Template=$template.RelativePath
  }
 }
 return $copy
}

function Test-MedicalClinicalPortableForms($forms,[bool]$requireAssets=$false){
 [void](Copy-MedicalClinicalFormData $forms)
 $definitions=@($forms.Diaries);if($forms.Discharge){$definitions+=@($forms.Discharge)}
 foreach($definition in $definitions){
  if($definition.PSObject.Properties['TemplateBase64']){[void](Test-MedicalFormTemplateAsset $definition)}
  elseif($requireAssets){throw 'В сохранённой форме отсутствует Word-шаблон дневника или эпикриза.'}
 }
}

# Legacy stages stored positional arrays. Read every main-document SDT in its
# original XML order; aliases/IDs are metadata, never hints for clinical meaning.
function Get-MedicalLegacyClinicalProperty($source,[string]$name){
 if($source -is [Collections.IDictionary]){return $source[$name]}
 if($null -ne $source){return $source.$name}
 return $null
}
function New-MedicalLegacyClinicalStage([string]$templatePath,$saved,[string]$title,[string]$prefix,$baseSchema=$null){
 $saved=@($saved);$fields=@();$values=@{};$sourceBytes=$null;$xml=$null;$n=$null;$controls=@()
 if(-not [string]::IsNullOrWhiteSpace($templatePath)){
  $path=$templatePath.Replace('\',[IO.Path]::DirectorySeparatorChar)
  if(-not [IO.Path]::IsPathRooted($path)){$path=Join-Path $script:medicalProgramRoot $path}
  if([IO.File]::Exists($path)){
   try{
    $sourceBytes=[IO.File]::ReadAllBytes($path);Test-MedicalTemplateBytes $sourceBytes
    $archive=[IO.Compression.ZipFile]::OpenRead($path)
    try{$xml=Get-XmlPart $archive 'word/document.xml'}finally{$archive.Dispose()}
    $n=[Xml.XmlNamespaceManager]::new($xml.NameTable);$n.AddNamespace('w',$script:ns)
    $controls=@($xml.SelectNodes('//w:sdt',$n))
   }catch{$sourceBytes=$null;$xml=$null;$n=$null;$controls=@()}
  }
 }
 $schema=if($null -eq $baseSchema){[pscustomobject]@{Version=49;AutoTemplate=$true;Template=($title+'.docx');DocumentTitle=$title;DateTimeLabel='Дата и время записи';PreserveTemplateFormatting=$true;Sections=@()}}else{Copy-MedicalFormSchema $baseSchema}
 $ids=@{};$markers=@{};$wordIds=@{}
 foreach($field in Get-UniversalFields $schema){$ids[[string]$field.Id]=$true;$markers[[string]$field.Marker]=$true;if($field.DetailMarker){$markers[[string]$field.DetailMarker]=$true};if($field.WordId){$wordIds[[string]$field.WordId]=$true}}
 $count=[Math]::Max($saved.Count,$controls.Count)
 for($i=0;$i -lt $count;$i++){
  $number=$i+1;$fieldId=$prefix+'_'+$number;$marker=($prefix.ToUpperInvariant()+'_'+$number)
  while($ids.ContainsKey($fieldId)){$fieldId+='x'};while($markers.ContainsKey($marker)){$marker+='_X'}
  $ids[$fieldId]=$true;$markers[$marker]=$true
  $label='Поле прежней карты '+$number;$options=@();$wordId=''
  if($i -lt $controls.Count){
   $control=$controls[$i];$properties=$control.SelectSingleNode('./w:sdtPr',$n)
   if(-not $properties){$properties=$xml.CreateElement('w','sdtPr',$script:ns);[void]$control.PrependChild($properties)}
   $alias=$properties.SelectSingleNode('./w:alias',$n);$tag=$properties.SelectSingleNode('./w:tag',$n)
   if($alias -and -not [string]::IsNullOrWhiteSpace($alias.GetAttribute('val',$script:ns))){$label=$alias.GetAttribute('val',$script:ns)}
   elseif($tag -and -not [string]::IsNullOrWhiteSpace($tag.GetAttribute('val',$script:ns))){$label=$tag.GetAttribute('val',$script:ns)}
   foreach($option in $properties.SelectNodes('.//w:listItem',$n)){$text=$option.GetAttribute('displayText',$script:ns);if(-not $text){$text=$option.GetAttribute('value',$script:ns)};if($text -and $text -ne 'Выберите элемент.'){$options+=@($text)}}
   $idNode=$properties.SelectSingleNode('./w:id',$n)
   if($idNode){$wordId=$idNode.GetAttribute('val',$script:ns)}
   if(-not $wordId -or $wordIds.ContainsKey($wordId)){
    $sequence=1000000000+$number;while($wordIds.ContainsKey([string]$sequence)){$sequence++};$wordId=[string]$sequence
    if(-not $idNode){$idNode=$xml.CreateElement('w','id',$script:ns);[void]$properties.AppendChild($idNode)}
    [void]$idNode.SetAttribute('val',$script:ns,$wordId)
   }
   $wordIds[$wordId]=$true
   # The portable form contains an unfilled source, not the saved answers.
   Set-UniversalControlValue $control '' $n
  }
  $type=if($options.Count){'choice'}else{'multiline'}
  $field=New-UniversalField $fieldId $label $marker $type;$field.Required=$false;$field.Options=$options;$field.WordId=$wordId
  $fields+=@($field)
  if($i -lt $saved.Count){$values[$fieldId]=[string]$saved[$i]}else{$values[$fieldId]=''}
 }
 if($fields.Count){
  $sectionId=$prefix;while(@($schema.Sections | Where-Object {[string]$_.Id -eq $sectionId}).Count){$sectionId+='x'}
  $schema.Sections+=@([pscustomobject]@{Id=$sectionId;Title='Поля прежней карты';Fields=$fields})
 }
 if($xml){
  $body=$xml.SelectSingleNode('/w:document/w:body',$n);$sectionProperties=$body.SelectSingleNode('./w:sectPr',$n)
  $allText=(($xml.SelectNodes('//w:t',$n) | ForEach-Object {$_.InnerText}) -join '')
  if($allText -notmatch '\{\{ADMISSION_DATETIME\}\}' -and -not ($allText -match '\{\{ADMISSION_DATE\}\}' -and $allText -match '\{\{ADMISSION_TIME\}\}')){
   $paragraph=$xml.CreateElement('w','p',$script:ns);$run=$xml.CreateElement('w','r',$script:ns);$text=$xml.CreateElement('w','t',$script:ns);$text.InnerText=([string]$schema.DateTimeLabel+': {{ADMISSION_DATETIME}}');[void]$run.AppendChild($text);[void]$paragraph.AppendChild($run)
   if($sectionProperties){[void]$body.InsertBefore($paragraph,$sectionProperties)}else{[void]$body.AppendChild($paragraph)}
  }
  # Additional saved array positions and new linked discharge sections need
  # real markers in the portable Word source, beyond the original SDT fields.
  foreach($section in $schema.Sections){
   $unbound=@($section.Fields | Where-Object {-not $_.WordId})
   if(-not $unbound.Count){continue}
   $paragraph=$xml.CreateElement('w','p',$script:ns);$run=$xml.CreateElement('w','r',$script:ns);$text=$xml.CreateElement('w','t',$script:ns);$text.InnerText=[string]$section.Title;[void]$run.AppendChild($text);[void]$paragraph.AppendChild($run)
   if($sectionProperties){[void]$body.InsertBefore($paragraph,$sectionProperties)}else{[void]$body.AppendChild($paragraph)}
   foreach($field in $unbound){
    $paragraph=$xml.CreateElement('w','p',$script:ns);$run=$xml.CreateElement('w','r',$script:ns);$text=$xml.CreateElement('w','t',$script:ns);$text.InnerText=([string]$field.Label+': {{'+[string]$field.Marker+'}}')
    if($field.Type -eq 'choice_detail' -and (Get-UniversalDetailWordPosition $field) -eq 'marker'){$text.InnerText+=' {{'+[string]$field.DetailMarker+'}}'}
    [void]$run.AppendChild($text);[void]$paragraph.AppendChild($run)
    if($sectionProperties){[void]$body.InsertBefore($paragraph,$sectionProperties)}else{[void]$body.AppendChild($paragraph)}
   }
  }
  $memory=[IO.MemoryStream]::new();$archive=$null;$input=$null;$output=$null
  try{
   $memory.Write($sourceBytes,0,$sourceBytes.Length);$memory.Position=0
   $archive=[IO.Compression.ZipArchive]::new($memory,[IO.Compression.ZipArchiveMode]::Update,$true)
   $entry=$archive.GetEntry('word/document.xml');$entry.Delete();$entry=$archive.CreateEntry('word/document.xml')
   $output=$entry.Open();$writer=[IO.StreamWriter]::new($output,[Text.UTF8Encoding]::new($false));try{$writer.Write($xml.OuterXml)}finally{$writer.Dispose();$output=$null}
   $archive.Dispose();$archive=$null
   $template=Import-MedicalTemplateBytes $memory.ToArray() ('Восстановленный '+$title+'.docx')
   $schema.Template=$template.RelativePath;$schema.AutoTemplate=$false
  }finally{if($output){$output.Dispose()};if($archive){$archive.Dispose()};$memory.Dispose()}
 }
 Assert-UniversalConfig $schema
 return [pscustomobject]@{Schema=(Copy-MedicalFormSchema $schema);Values=$values}
}
function Import-MedicalLegacyClinicalStages($record){
 $stages=ConvertTo-MedicalClinicalMap (Get-MedicalLegacyClinicalProperty $record 'stages')
 if(-not $stages.Count){$stages=ConvertTo-MedicalClinicalMap (Get-MedicalLegacyClinicalProperty $record 'stageData')}
 $templates=ConvertTo-MedicalClinicalMap (Get-MedicalLegacyClinicalProperty $record 'templates')
 $numbers=@{};$count=0;$diaryCount=Get-MedicalLegacyClinicalProperty $record 'diaryCount'
 if($diaryCount -and [int]::TryParse([string]$diaryCount,[ref]$count)){if($count -gt 1000 -or $count -lt 0){throw 'Некорректное число дневников прежней карты.'};for($i=1;$i -le $count;$i++){$numbers[$i]=$true}}
 foreach($key in @($stages.Keys)){if([string]$key -match '^diary_([1-9][0-9]*)$'){$number=[int]$Matches[1];if($number -gt 1000){throw 'Некорректный номер дневника прежней карты.'};$numbers[$number]=$true}}
 $forms=Get-MedicalClinicalFormData;$forms.Diaries=@();$state=New-MedicalClinicalPatientState $forms
 $date=[datetime]::Now;$dateSource=Get-MedicalLegacyClinicalProperty $record 'admissionDate';$parsed=[datetime]::MinValue
 if($dateSource -is [datetime]){$date=[datetime]$dateSource}
 elseif([datetime]::TryParseExact([string]$dateSource,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$parsed)){$date=$parsed}
 foreach($number in @($numbers.Keys | Sort-Object {[int]$_})){
  $id='legacy_diary_'+$number;$title='Дневник наблюдения №'+$number
  $migration=New-MedicalLegacyClinicalStage ([string]$templates['diary']) @($stages['diary_'+$number]) $title ('legacy_diary'+$number)
  if(@(Get-UniversalFields $migration.Schema).Count -eq 0){$migration.Schema=New-MedicalDiarySchema}
  $forms.Diaries+=@([pscustomobject]@{Id=$id;Title=$title;Schema=$migration.Schema;Links=@{}})
  $overrides=@{};foreach($key in @($migration.Values.Keys)){$overrides[$key]=$true}
  $state.Diaries+=@([pscustomobject]@{Id=$id;DateTime=$date.ToString('yyyy-MM-ddTHH:mm:ss');Values=$migration.Values;Details=@{};Overrides=$overrides})
 }
 if($stages.ContainsKey('discharge')){
  $migration=New-MedicalLegacyClinicalStage ([string]$templates['discharge']) @($stages['discharge']) 'Выписной эпикриз' 'legacy_discharge' $forms.Discharge.Schema
  $forms.Discharge.Schema=$migration.Schema
  $forms.Discharge | Add-Member -NotePropertyName FollowInitialSchema -NotePropertyValue $false -Force
  $state.Discharge.Values=$migration.Values;$state.Discharge.Overrides=@{}
  foreach($key in @($migration.Values.Keys)){$state.Discharge.Overrides[$key]=$true}
 }
 # Validate candidates before replacing any live structures or patient values.
 $forms=Copy-MedicalClinicalFormData $forms;$state=Copy-MedicalClinicalPatientState $state $forms
 $script:medicalClinicalForms=$forms;$script:medicalClinicalState=$state
 Sync-MedicalDischargeFromInitial
 return $forms
}

function Get-MedicalClinicalInitialSignature($initial){
 $schema=Copy-MedicalFormSchema $initial
 $text=$schema|ConvertTo-Json -Depth 40 -Compress
 if(-not $schema.AutoTemplate){$path=Get-UniversalTemplatePath $schema;if([IO.File]::Exists($path)){$text+='|'+(Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($path)))}}
 return (Get-MedicalBytesSha256 ([Text.Encoding]::UTF8.GetBytes($text)))
}
function Get-MedicalDischargeGeneratedFieldIds($schema){
 $categories=@('final_diagnosis','examination_results','treatment_results','recommendations');$result=@{}
 if(@($schema.Sections).Count -lt 4){throw 'В эпикризе отсутствуют итоговые разделы.'}
 for($i=0;$i -lt 4;$i++){$section=@($schema.Sections)[@($schema.Sections).Count-4+$i];$result[$categories[$i]]=[string]@($section.Fields)[0].Id}
 return $result
}
function Sync-MedicalDischargeSchemaFromInitial {
 if(-not $script:medicalClinicalForms -or -not $script:medicalClinicalForms.Discharge -or -not $script:medicalClinicalState){return}
 $definition=$script:medicalClinicalForms.Discharge
 if($definition.FollowInitialSchema -ne $true){return}
 $signature=Get-MedicalClinicalInitialSignature $script:universalConfig
 if([string]$definition.InitialSchemaSignature -ceq $signature){return}
 if(-not $script:universalConfig.AutoTemplate -and -not [IO.File]::Exists((Get-UniversalTemplatePath $script:universalConfig))){return}
 $schema=New-MedicalDischargeSchema $script:universalConfig;$generated=Get-MedicalDischargeGeneratedFieldIds $schema
 $oldGenerated=ConvertTo-MedicalClinicalMap $definition.GeneratedFieldIds;$mapping=@{}
 $sourceIds=@{};foreach($field in Get-UniversalFields $script:universalConfig){$sourceIds[[string]$field.Id]=$true}
 foreach($field in Get-UniversalFields $definition.Schema){if($sourceIds.ContainsKey([string]$field.Id)){$mapping[[string]$field.Id]=[string]$field.Id}}
 foreach($category in @($generated.Keys)){if($oldGenerated.ContainsKey($category)){$mapping[[string]$oldGenerated[$category]]=[string]$generated[$category]}}
 $patient=$script:medicalClinicalState.Discharge;$values=@{};$details=@{};$overrides=@{}
 foreach($oldId in @($mapping.Keys)){
  $newId=[string]$mapping[$oldId]
  if($patient.Values.ContainsKey($oldId)){$values[$newId]=[string]$patient.Values[$oldId]}
  if($patient.Details.ContainsKey($oldId)){$details[$newId]=[string]$patient.Details[$oldId]}
  if($patient.Overrides.ContainsKey($oldId)){$overrides[$newId]=$true}
 }
 # Compute and validate everything before changing the live schema or answers.
 $links=Get-MedicalClinicalDefaultLinks $schema $script:universalConfig $true
 $values=Copy-MedicalClinicalValues $values $schema;$details=Copy-MedicalClinicalValues $details $schema $true
 $definition.Schema=$schema;$definition.Links=$links;$definition.GeneratedFieldIds=$generated;$definition.InitialSchemaSignature=$signature
 $patient.Values=$values;$patient.Details=$details;$patient.Overrides=$overrides
}
