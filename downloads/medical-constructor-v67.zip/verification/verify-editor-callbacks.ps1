﻿param(
 [string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v67'),
 [string]$LegacyProject=(Join-Path (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) 'medical-constructor-v59/Медицинский конструктор v59'),
 [string]$LegacyNamingProject=(Join-Path (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) 'medical-constructor-v62/Медицинский конструктор v62')
)
$ErrorActionPreference='Stop'
# This harness deliberately keeps application helpers private to a child .ps1.
# Promoting extracted functions to the parent script/global scope would hide v59's bug.
function Get-CallbackSpec([string]$path,[bool]$legacyOnly=$false,[bool]$legacyNaming=$false){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors | Out-String)}
 $editor=$ast.Find({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Show-MedicalFormTemplateEditor'},$false)
 $assignments=@{}
 foreach($name in $(if($legacyOnly){@('commitParagraph')}else{@('commitProperties','commitParagraph','updateAvailability','pasteParagraphText','loadProperties','refreshTree','loadParagraph','refreshParagraphs','refreshParts','clearWordPreview','resizeWordPages','renameSection')})){
  $nodes=@($editor.FindAll({param($node) $node -is [Management.Automation.Language.AssignmentStatementAst] -and $node.Left -is [Management.Automation.Language.VariableExpressionAst] -and $node.Left.VariablePath.UserPath -eq $name},$true))
  if($legacyNaming -and $nodes.Count -eq 0 -and $name -eq 'renameSection'){continue}
  if($nodes.Count -ne 1){throw ('Expected one production assignment: '+$name)}
  $assignments[$name]=$nodes[0].Extent.Text
 }
 $handlers=@{}
 foreach($item in $(if($legacyOnly){@()}else{@(@('addSection','Add_Click'),@('tree','Add_AfterSelect'),@('fieldName','Add_TextChanged'),@('fieldMarker','Add_TextChanged'),@('paragraphText','Add_TextChanged'),@('addField','Add_Click'),@('insertField','Add_Click'),@('insertDetail','Add_Click'),@('addParagraph','Add_Click'),@('buildTemplate','Add_Click'),@('save','Add_Click'),@('paragraphList','Add_SelectedIndexChanged'),@('detailEnable','Add_Click'),@('pasteText','Add_Click'),@('deleteParagraph','Add_Click'),@('fieldType','Add_SelectedIndexChanged'),@('detailWord','Add_SelectedIndexChanged'),@('documentTabs','Add_SelectedIndexChanged'),@('wordPreviewButton','Add_Click'),@('sectionFieldPicker','Add_SelectedIndexChanged'),@('sectionFieldName','Add_TextChanged'),@('editSection','Add_Click'),@('treeDoubleClick','Add_NodeMouseDoubleClick'),@('treeKeyDown','Add_KeyDown'))})){
  $control=$item[0];$event=$item[1];$sourceControl=if($control -in @('treeDoubleClick','treeKeyDown')){'tree'}else{$control}
  $nodes=@($editor.FindAll({param($node) $node -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $node.Expression -is [Management.Automation.Language.VariableExpressionAst] -and $node.Expression.VariablePath.UserPath -eq $sourceControl -and $node.Member.Value -eq $event},$true))
  if($legacyNaming -and $nodes.Count -eq 0 -and $control -in @('fieldName','fieldMarker','paragraphText','sectionFieldPicker','sectionFieldName','editSection','treeDoubleClick','treeKeyDown')){continue}
  if($nodes.Count -ne 1){throw ('Expected one production handler: '+$control)}
  $handlers[$control]=$nodes[0].Arguments[0].Extent.Text
 }
 $binding=$editor.Find({param($node) $node -is [Management.Automation.Language.AssignmentStatementAst] -and $node.Left -is [Management.Automation.Language.VariableExpressionAst] -and $node.Left.VariablePath.UserPath -eq 'editorCommands'},$true)
 $bindings=''
 if($binding){
  $first=$editor.Find({param($node) $node -is [Management.Automation.Language.AssignmentStatementAst] -and $node.Left -is [Management.Automation.Language.VariableExpressionAst] -and $node.Left.VariablePath.UserPath -eq 'commitProperties'},$true)
  $source=[IO.File]::ReadAllText($path);$bindings=$source.Substring($binding.Extent.StartOffset,$first.Extent.StartOffset-$binding.Extent.StartOffset)
 }
 return [pscustomobject]@{Assignments=$assignments;Handlers=$handlers;Bindings=$bindings}
}
$spec=Get-CallbackSpec (Join-Path $Project 'template-editor-v59.ps1')
if([IO.File]::Exists((Join-Path $LegacyProject 'template-editor-v59.ps1'))){$legacy=Get-CallbackSpec (Join-Path $LegacyProject 'template-editor-v59.ps1') $true}
else{
 # Exact v59 callback retained so a downloaded v60 test archive remains standalone.
 $legacy=[pscustomobject]@{Assignments=@{commitParagraph='$commitParagraph={if($state.Paragraph -and -not $state.Loading){Set-MedicalTemplateParagraph $state.Model $state.Paragraph.Id $paragraphText.Text}}.GetNewClosure()'};Handlers=@{};Bindings=''}
}
$legacyNamingPath=Join-Path $LegacyNamingProject 'template-editor-v59.ps1'
if([IO.File]::Exists($legacyNamingPath)){$legacyNaming=Get-CallbackSpec $legacyNamingPath $false $true}
else{
 # The exact v62 commit callback makes this regression portable when the old
 # archive is unavailable. Its unchanged tree construction uses the current
 # production callbacks; v62 had no live TextChanged handlers.
 $legacyNaming=[pscustomobject]@{Assignments=@{};Handlers=@{};Bindings=$spec.Bindings}
 foreach($entry in $spec.Assignments.GetEnumerator()){$legacyNaming.Assignments[$entry.Key]=$entry.Value}
 foreach($entry in $spec.Handlers.GetEnumerator()){if($entry.Key -notin @('fieldName','fieldMarker','paragraphText')){$legacyNaming.Handlers[$entry.Key]=$entry.Value}}
 $legacyNaming.Assignments.commitProperties=@'
  $commitProperties={
   if($state.Loading -or -not $state.Selected){return}
   $selection=$state.Selected
   if($selection.Kind -eq 'section'){$selection.Section.Title=$fieldName.Text.Trim();return}
   $field=$selection.Field;$field.Label=$fieldName.Text.Trim();$field.Marker=$fieldMarker.Text.Trim().ToUpperInvariant()
   if($fieldType.SelectedIndex -ge 0){$field.Type=$typeIds[$fieldType.SelectedIndex]}
   $field.Options=@($fieldOptions.Lines | Where-Object {-not [string]::IsNullOrWhiteSpace($_)})
   $field.System=$roleIds[[Math]::Max(0,$fieldRole.SelectedIndex)];$field.WordId=$fieldWordId.Text.Trim()
   $field | Add-Member -NotePropertyName Required -NotePropertyValue ([bool]$fieldRequired.Checked) -Force
   if($field.Type -in @('heading','multi','repeat')){$field.System='';$field.WordId=''}
   if($field.Type -eq 'heading'){$field.Required=$false;$field.Options=@()}
   if($field.Type -eq 'choice_detail'){
    $field | Add-Member -NotePropertyName DetailFormPosition -NotePropertyValue @('below','above','right')[[Math]::Max(0,$detailForm.SelectedIndex)] -Force
    $field | Add-Member -NotePropertyName DetailWordPosition -NotePropertyValue @('after','before','newline','marker')[[Math]::Max(0,$detailWord.SelectedIndex)] -Force
    $field | Add-Member -NotePropertyName DetailMarker -NotePropertyValue $detailMarker.Text.Trim().ToUpperInvariant() -Force
   }
  }.GetNewClosure()
'@
}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-callback-test-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
$child=Join-Path $temp 'private-application-scope.ps1'
$childSource=@'
param([string]$Project,[string]$TestRoot,$Spec,$Legacy,$LegacyNaming)
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Callback([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @"
using System;
using System.Collections;
public sealed class MedicalCallbackSize {public int Width {get;set;} public MedicalCallbackSize(){Width=800;}}
public sealed class MedicalCallbackRowStyle {public int Height {get;set;}}
public sealed class MedicalCallbackWidget {
 private string text="";
 public string Text {get {return text;} set {string incoming=value ?? "";if(text==incoming)return;text=incoming;if(TextChanged!=null)TextChanged(this,EventArgs.Empty);}}
 public bool Focused {get;private set;}
 public int BeginUpdateCount {get;private set;}
 public ArrayList Nodes {get;private set;}
 private Windows.Forms.TreeNode selectedNode;
 public Windows.Forms.TreeNode SelectedNode {get {return selectedNode;} set {if(Object.ReferenceEquals(value,selectedNode))return;selectedNode=value;if(AfterSelect!=null)AfterSelect(this,EventArgs.Empty);}}
 public event EventHandler AfterSelect;
 public event EventHandler TextChanged;
 public string DocumentText {get;set;}
 public object SelectedTab {get;set;}
 public bool UseWaitCursor {get;set;}
 public MedicalCallbackSize ClientSize {get;private set;}
 public ArrayList Controls {get;private set;}
 public ArrayList RowStyles {get;private set;}
 private string lastInsertedText="";
 public int SelectionStart {get;set;}
 public int SelectionLength {get;set;}
 public string SelectedText {get {return lastInsertedText;} set {
  string insert=value ?? "";int start=Math.Max(0,Math.Min(SelectionStart,Text.Length));int count=Math.Max(0,Math.Min(SelectionLength,Text.Length-start));
  Text=Text.Substring(0,start)+insert+Text.Substring(start+count);SelectionStart=start+insert.Length;SelectionLength=0;lastInsertedText=insert;
 }}
 public bool Enabled {get;set;}
 public bool Visible {get;set;}
 public bool Checked {get;set;}
 public bool ReadOnly {get;set;}
 public bool Closed {get;private set;}
 public string DialogResult {get;set;}
 public int SelectedIndex {get;set;}
 public ArrayList Items {get;private set;}
 public MedicalCallbackWidget(){Nodes=new ArrayList();ClientSize=new MedicalCallbackSize();Controls=new ArrayList();Text="";SelectedText="";Enabled=true;DialogResult="";SelectedIndex=-1;Items=new ArrayList();RowStyles=new ArrayList();for(int i=0;i<10;i++)RowStyles.Add(new MedicalCallbackRowStyle());}
 public string[] Lines {get {return Text.Split(new string[] {"\r\n","\n","\r"},StringSplitOptions.None);}}
 public object SelectedItem {get {return SelectedIndex >= 0 && SelectedIndex < Items.Count ? Items[SelectedIndex] : null;}}
 public event EventHandler SelectedIndexChanged;
 public event EventHandler Click;
 public event EventHandler<Windows.Forms.TreeNodeMouseClickEventArgs> NodeMouseDoubleClick;
 public event EventHandler<Windows.Forms.KeyEventArgs> KeyDown;
 public void RaiseNodeMouseDoubleClick(Windows.Forms.TreeNode node){if(NodeMouseDoubleClick!=null)NodeMouseDoubleClick(this,new Windows.Forms.TreeNodeMouseClickEventArgs(node));}
 public Windows.Forms.KeyEventArgs RaiseKeyDown(Windows.Forms.Keys key){Windows.Forms.KeyEventArgs args=new Windows.Forms.KeyEventArgs(key);if(KeyDown!=null)KeyDown(this,args);return args;}
 public void RaiseClick(){if(Click!=null)Click(this,EventArgs.Empty);}
 public void RaiseSelectedIndexChanged(){if(SelectedIndexChanged!=null)SelectedIndexChanged(this,EventArgs.Empty);}
 public void Refresh(){}
 public void BeginUpdate(){BeginUpdateCount++;}
 public void EndUpdate(){}
 public bool Focus(){Focused=true;return true;}
 public void Close(){Closed=true;}
}
namespace Windows.Forms {
 public enum Keys {None,F2,Enter}
 public sealed class KeyEventArgs:EventArgs {public Keys KeyCode {get;set;} public bool Handled {get;set;} public bool SuppressKeyPress {get;set;} public KeyEventArgs(Keys key){KeyCode=key;}}
 public sealed class TreeNodeMouseClickEventArgs:EventArgs {public TreeNode Node {get;private set;} public TreeNodeMouseClickEventArgs(TreeNode node){Node=node;}}

 public sealed class TreeNode {
  public string Text {get;set;}
  public object Tag {get;set;}
  public ArrayList Nodes {get;private set;}
  public TreeNode(string text){Text=text;Nodes=new ArrayList();}
  public void Expand(){}
 }
 public static class MessageBox {public static string Response="Yes";public static string Show(params object[] args){return Response;}}
 public enum TextDataFormat {Text,UnicodeText,Rtf,Html,CommaSeparatedValue}
 public static class Clipboard {
  public static string Text="";public static int ReadCount=0;
  public static bool ContainsText(){return !String.IsNullOrEmpty(Text);}
  public static bool ContainsText(TextDataFormat format){return !String.IsNullOrEmpty(Text);}
  public static string GetText(){ReadCount++;return Text;}
  public static string GetText(TextDataFormat format){ReadCount++;return Text;}
 }
}
"@
# Get-XmlPart is the only dependency in constructor.ps1; do not execute its GUI.
$tokens=$null;$errors=$null;$constructor=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'constructor.ps1'),[ref]$tokens,[ref]$errors)
$getXml=$constructor.Find({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Get-XmlPart'},$false)
. ([scriptblock]::Create($getXml.Extent.Text))
# These are genuine dot-sourced application files in this CHILD SCRIPT scope.
. (Join-Path $Project 'universal.ps1')
. (Join-Path $Project 'forms-v59.ps1')
. (Join-Path $Project 'template-editor-v59.ps1')
. (Join-Path $Project 'template-editor-operations-v61.ps1')
. (Join-Path $Project 'template-format-v62.ps1')
. (Join-Path $Project 'template-layout-preview-v62.ps1')
. (Join-Path $Project 'word-preview-v62.ps1')
. (Join-Path $Project 'section-editor-v64.ps1')
$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
$script:medicalProgramRoot=Join-Path $TestRoot 'program'
$script:medicalTemplatesFolder=Join-Path $script:medicalProgramRoot 'Шаблоны'
[void][IO.Directory]::CreateDirectory($script:medicalProgramRoot)
Assert-Callback (-not (Get-Item Function:global:Set-MedicalTemplateParagraph -ErrorAction SilentlyContinue)) 'Application paragraph helper stays out of global scope'
$config=[pscustomobject]@{Version=49;AutoTemplate=$false;Template='';Sections=@([pscustomobject]@{Id='test';Title='Раздел';Fields=@((New-UniversalField 'text' 'Текст' 'TEXT' 'text'),(New-UniversalField 'choice' 'Выбор' 'CHOICE' 'choice_detail'))})}
$detail=$config.Sections[0].Fields[1];$detail.Options=@('Да','Нет')
$detail | Add-Member -NotePropertyName DetailFormPosition -NotePropertyValue 'right'
$detail | Add-Member -NotePropertyName DetailWordPosition -NotePropertyValue 'marker'
$detail | Add-Member -NotePropertyName DetailMarker -NotePropertyValue 'CHOICE_DETAIL'
$source=Join-Path $script:medicalProgramRoot 'original.docx';$config.Template=$source
New-UniversalTemplate $source $config
$sourceHash=Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($source))
function New-TestCallbacks($callbackSpec,$schema,$model,[bool]$legacyOnly=$false){
 $state=@{Schema=$schema;Model=$model;Selected=[pscustomobject]@{Kind='field';Section=$schema.Sections[0];Field=$schema.Sections[0].Fields[1]};SelectedNode=$null;PropertiesSelection=$null;PropertiesNode=$null;PropertiesFieldNode=$null;SectionFieldIds=@{};SectionFieldOptions=@();Paragraph=$model.Paragraphs[0];Loading=$false;Result=$null;VisibleParagraphs=@();WordPreview=$null}
 $testState=@{LastError=$null;TreeRefreshCount=0;FormatLoadCount=0}
 $widgets=@{}
 foreach($name in @('tree','tabs','fieldTab','fieldName','fieldMarker','fieldType','fieldOptions','fieldRequired','fieldRole','fieldWordId','detailTab','detailStatus','detailEnable','detailForm','detailWord','detailMarker','paragraphText','paragraphTitle','paragraphList','partCombo','hint','insertField','insertDetail','insertDate','pasteText','deleteParagraph','addParagraph','addField','addSection','buildTemplate','save','templateName','dialog','documentTabs','formatTab','layoutTab','layoutBrowser','wordPages','wordStatus','wordPreviewButton','properties','propertyNameLabel','sectionFieldPicker','sectionFieldName','sectionFieldPickerLabel','sectionFieldNameLabel','sectionInfo','editSection')){
  $widget=New-Object MedicalCallbackWidget;$widgets[$name]=$widget;Set-Variable -Name $name -Value $widget
 }
 $paragraphFormatEditor=[pscustomobject]@{Editor=$paragraphText;Load={$testState.FormatLoadCount++}.GetNewClosure();RestorePaperColors={}}
 $partCombo.SelectedIndex=0;$templateName.Text='edited.docx';$typeIds=@('text','multiline','choice','choice_detail','heading','multi','repeat');$roleIds=@('','name','birth','address')
 $showError={param($record)$testState.LastError=$record}.GetNewClosure()
 if($legacyOnly){Invoke-Expression $callbackSpec.Assignments.commitParagraph;return [pscustomobject]@{State=$state;Widgets=$widgets;CommitParagraph=$commitParagraph;Errors=$testState}}
 # Execute exactly the production command-binding statements and callback bodies.
 Invoke-Expression $callbackSpec.Bindings
 foreach($name in $(if($legacyOnly){@('commitParagraph')}else{@('commitProperties','commitParagraph','updateAvailability','pasteParagraphText','loadProperties','refreshTree','loadParagraph','refreshParagraphs','refreshParts','clearWordPreview','resizeWordPages','renameSection')})){if($callbackSpec.Assignments.ContainsKey($name)){Invoke-Expression $callbackSpec.Assignments[$name]}}
 $handlers=@{}
 foreach($entry in $callbackSpec.Handlers.GetEnumerator()){$handlers[$entry.Key]=Invoke-Expression $entry.Value}
 $tree.Add_AfterSelect($handlers.tree)
 foreach($buttonName in @('addSection','addField','buildTemplate','save','editSection','insertField','insertDetail','addParagraph')){if($handlers.ContainsKey($buttonName)){$widgets[$buttonName].Add_Click($handlers[$buttonName])}}
 foreach($controlName in @('fieldName','fieldMarker','paragraphText','sectionFieldName')){if($handlers.ContainsKey($controlName)){$widgets[$controlName].Add_TextChanged($handlers[$controlName])}}
 if($handlers.ContainsKey('sectionFieldPicker')){$sectionFieldPicker.Add_SelectedIndexChanged($handlers.sectionFieldPicker)}
 if($handlers.ContainsKey('treeDoubleClick')){$tree.Add_NodeMouseDoubleClick($handlers.treeDoubleClick)}
 if($handlers.ContainsKey('treeKeyDown')){$tree.Add_KeyDown($handlers.treeKeyDown)}
 $paragraphList.Add_SelectedIndexChanged($handlers.paragraphList)
 $fieldType.Add_SelectedIndexChanged($handlers.fieldType);$detailWord.Add_SelectedIndexChanged($handlers.detailWord)
 $detailEnable.Add_Click($handlers.detailEnable);$pasteText.Add_Click($handlers.pasteText);$deleteParagraph.Add_Click($handlers.deleteParagraph)
 $documentTabs.Add_SelectedIndexChanged($handlers.documentTabs);$wordPreviewButton.Add_Click($handlers.wordPreviewButton)
 & $refreshTree $schema.Sections[0].Fields[1].Id
 return [pscustomobject]@{State=$state;Widgets=$widgets;Commands=$editorCommands;CommitProperties=$commitProperties;CommitParagraph=$commitParagraph;LoadProperties=$loadProperties;LoadParagraph=$loadParagraph;UpdateAvailability=$updateAvailability;RefreshTree=$refreshTree;RefreshParagraphs=$refreshParagraphs;RefreshParts=$refreshParts;Handlers=$handlers;Errors=$testState}
}
$old=New-TestCallbacks $Legacy (Copy-MedicalFormSchema $config) (Read-MedicalTemplateModel $source) $true
$old.Widgets.paragraphText.Text='Legacy edited paragraph'
$oldError=$null;try{& $old.CommitParagraph}catch{$oldError=$_}
Assert-Callback ($null -ne $oldError -and $oldError.Exception -is [Management.Automation.CommandNotFoundException] -and $oldError.Exception.Message.Contains('Set-MedicalTemplateParagraph')) 'Actual v59 closure reproduces missing Set-MedicalTemplateParagraph'
Assert-Callback ($old.State.Model.Paragraphs[0].Text -ne 'Legacy edited paragraph') 'Failed legacy callback cannot commit the paragraph'
$oldNaming=New-TestCallbacks $LegacyNaming (Copy-MedicalFormSchema $config) (Read-MedicalTemplateModel $source)
$oldNaming.Widgets.tree.SelectedNode=$oldNaming.Widgets.tree.Nodes[0]
$oldNaming.Widgets.fieldName.Text=''
$oldNaming.Widgets.addField.RaiseClick()
Assert-Callback ($oldNaming.State.Schema.Sections[0].Title -ceq '' -and $oldNaming.Widgets.tree.Nodes[0].Text -ceq '') 'Exact v62 callbacks reproduce an empty parent section after clearing its name and adding a field'
$oldNamingError=$null;try{Assert-UniversalConfig $oldNaming.State.Schema}catch{$oldNamingError=$_}
Assert-Callback ($null -ne $oldNamingError -and $oldNamingError.Exception.Message.Contains('Укажите название каждого раздела')) 'The reproduced v62 empty title triggers the same section-name validation reported by the user'

# Exercise the genuine tree refresh and native change events. The earlier harness
# stubbed refreshTree, so it never tested the section/field property binding.
$namingSchema=Copy-MedicalFormSchema $config
$namingSchema.Sections+=@([pscustomobject]@{Id='other';Title='Другой раздел';Fields=@()})
$naming=New-TestCallbacks $Spec $namingSchema (Read-MedicalTemplateModel $source)
$naming.Widgets.tree.SelectedNode=$naming.Widgets.tree.Nodes[0]
Assert-Callback ($naming.State.Selected.Kind -eq 'section' -and $naming.Widgets.fieldName.Text -ceq 'Раздел' -and $naming.State.Selected.Field -eq $null -and [object]::ReferenceEquals($naming.State.PropertiesSelection.Section,$naming.State.Selected.Section) -and [object]::ReferenceEquals($naming.State.PropertiesSelection.Field,$naming.State.Schema.Sections[0].Fields[0])) 'Native section selection binds name controls to the loaded section'
$naming.Widgets.fieldName.Text='Сведения о пациенте'
Assert-Callback ($naming.State.Schema.Sections[0].Title -ceq 'Сведения о пациенте' -and $naming.Widgets.tree.Nodes[0].Text -ceq 'Сведения о пациенте') 'Typing a section name immediately updates its schema and visible tree caption'
$naming.Widgets.fieldName.Text=''
Assert-Callback ($naming.State.Schema.Sections[0].Title -ceq 'Сведения о пациенте' -and $naming.Widgets.tree.Nodes[0].Text -ceq 'Сведения о пациенте') 'Clearing a section name for replacement does not erase its stored title'
$naming.Widgets.addField.RaiseClick()
Assert-Callback ($null -eq $naming.Errors.LastError -and $naming.State.Schema.Sections[0].Title -ceq 'Сведения о пациенте' -and $naming.Widgets.tree.Nodes[0].Text -ceq 'Сведения о пациенте') 'Native Add Field after a temporarily blank section name retains the parent title'
Assert-Callback ($naming.State.Selected.Kind -eq 'field' -and $naming.Widgets.fieldName.Text -ceq 'Новое поле' -and [object]::ReferenceEquals($naming.State.PropertiesNode,$naming.Widgets.tree.SelectedNode)) 'Actual tree rebuild selects the new field and binds its property controls'
$newField=$naming.State.Selected.Field;$newFieldId=$newField.Id
$naming.Widgets.fieldName.Text='Экспертный анамнез'
Assert-Callback ($newField.Label -ceq 'Экспертный анамнез' -and $naming.Widgets.tree.SelectedNode.Text.StartsWith('Экспертный анамнез  {{')) 'Typing a field name immediately replaces New Field in the actual tree'
$naming.Widgets.fieldMarker.Text='expert_history'
Assert-Callback ($newField.Marker -ceq 'EXPERT_HISTORY' -and $naming.Widgets.tree.SelectedNode.Text -ceq 'Экспертный анамнез  {{EXPERT_HISTORY}}') 'Lowercase marker input is normalized in the schema and visible field caption'
$naming.Widgets.fieldMarker.Text='';$naming.Widgets.fieldMarker.Text='1'
Assert-Callback ($newField.Marker -ceq 'EXPERT_HISTORY' -and $naming.Widgets.tree.SelectedNode.Text -ceq 'Экспертный анамнез  {{EXPERT_HISTORY}}' -and $null -eq $naming.Errors.LastError) 'Transient incomplete marker input preserves the last valid marker without an event error'
$naming.Widgets.fieldMarker.Text='expert_history'
$naming.Widgets.tree.SelectedNode=$naming.Widgets.tree.Nodes[1]
Assert-Callback ($naming.Widgets.fieldName.Text -ceq 'Другой раздел' -and $naming.State.Schema.Sections[1].Title -ceq 'Другой раздел' -and $newField.Label -ceq 'Экспертный анамнез') 'Selecting another section loads its own name without copying the prior field label'
$naming.Widgets.fieldName.Text='План обследования'
$naming.Widgets.tree.SelectedNode=$naming.Widgets.tree.Nodes[0]
Assert-Callback ($naming.Widgets.tree.Nodes[1].Text -ceq 'План обследования' -and $naming.State.Schema.Sections[1].Title -ceq 'План обследования' -and $naming.Widgets.fieldName.Text -ceq 'Сведения о пациенте') 'Section rename survives native navigation and does not rename the next selection'
$naming.Widgets.fieldName.Text='';$modelBeforeBuild=$naming.State.Model
$naming.Widgets.buildTemplate.RaiseClick()
Assert-Callback ($naming.Errors.LastError.Exception.Message.Contains('Введите название выбранного раздела') -and $naming.Widgets.fieldName.Focused -and [object]::ReferenceEquals($naming.Widgets.tabs.SelectedTab,$naming.Widgets.fieldTab)) 'Build with a blank section name focuses its exact name input and explains the required title'
Assert-Callback ([object]::ReferenceEquals($naming.State.Model,$modelBeforeBuild) -and $naming.State.Schema.Sections[0].Title -ceq 'Сведения о пациенте') 'Blank-name validation keeps the current Word model and valid stored section title'
$naming.Errors.LastError=$null;$naming.Widgets.fieldName.Text='Сведения о пациенте'
& $naming.RefreshTree $newFieldId
$naming.Widgets.fieldName.Text=''
$naming.Widgets.save.RaiseClick()
Assert-Callback ($naming.Errors.LastError.Exception.Message.Contains('Введите название выбранного поля') -and -not $naming.Widgets.dialog.Closed -and $null -eq $naming.State.Result -and $newField.Label -ceq 'Экспертный анамнез') 'Apply with a blank field name leaves the editor open and retains its valid stored label'
$naming.Errors.LastError=$null;$naming.Widgets.fieldName.Text='Экспертный анамнез';$naming.Widgets.fieldMarker.Text='1INVALID'
$naming.Widgets.buildTemplate.RaiseClick()
Assert-Callback ($null -ne $naming.Errors.LastError -and $naming.Errors.LastError.Exception.Message.Contains('Маркер поля') -and -not [object]::ReferenceEquals($naming.State.Model,$null) -and $newField.Marker -ceq '1INVALID') 'Final commit passes an invalid complete marker to the actual schema validator'
$naming.Errors.LastError=$null;$naming.Widgets.fieldMarker.Text='expert_history'
$naming.Widgets.buildTemplate.RaiseClick()
Assert-Callback ($null -eq $naming.Errors.LastError -and (@($naming.State.Model.Paragraphs | Where-Object {$_.Text -match 'Экспертный анамнез'})).Count -eq 1) 'Corrected field name generates a Word paragraph with the actual renamed label'
& $naming.RefreshTree $newFieldId
$naming.Widgets.templateName.Text='named-native-callback.docx';$naming.Widgets.save.RaiseClick()
Assert-Callback ($null -eq $naming.Errors.LastError -and $naming.State.Result.Schema.Sections[0].Fields[-1].Label -ceq 'Экспертный анамнез' -and $naming.State.Result.Schema.Sections[0].Title -ceq 'Сведения о пациенте') 'Names committed through real change events survive final schema and Word-template save'
$namingSavedModel=Read-MedicalTemplateModel $naming.State.Result.Template.Path
Assert-Callback ((@($namingSavedModel.Paragraphs | Where-Object {$_.Text -ceq 'Экспертный анамнез: {{EXPERT_HISTORY}}'})).Count -eq 1) 'Renamed field and normalized marker survive reading the actual saved DOCX'
$naming.Widgets.tree.SelectedNode=$naming.Widgets.tree.Nodes[1]
$naming.Widgets.fieldName.Text='Раздел обследования'
$naming.Widgets.addSection.RaiseClick()
Assert-Callback ($null -eq $naming.Errors.LastError -and $naming.State.Schema.Sections[1].Title -ceq 'Раздел обследования' -and $naming.State.Selected.Kind -eq 'section' -and $naming.Widgets.tree.SelectedNode.Text -ceq 'Новый раздел') 'Native Add Section retains the previous section rename and selects the newly created section'
$naming.Widgets.fieldName.Text='Новый план лечения';$newSectionId=$naming.State.Selected.Section.Id
Assert-Callback ($naming.Widgets.tree.SelectedNode.Text -ceq 'Новый план лечения' -and $naming.State.Schema.Sections[-1].Title -ceq 'Новый план лечения') 'New section receives the entered name immediately in its real tree node and schema'
$naming.Widgets.tree.SelectedNode=$naming.Widgets.tree.Nodes[0]
Assert-Callback ($naming.State.Schema.Sections[-1].Title -ceq 'Новый план лечения' -and $naming.Widgets.fieldName.Text -ceq 'Сведения о пациенте') 'New section name persists when a native selection event returns to the patient section'
& $naming.RefreshTree $newFieldId

# Preserve nested loading guards: live native events during a reload must not
# bind the current control text to an unrelated selected record.
$naming.State.Loading=$true; & $naming.LoadProperties
Assert-Callback ($naming.State.Loading -and $newField.Label -ceq 'Экспертный анамнез') 'Property reload restores an existing loading guard after native TextChanged events'
& $naming.RefreshTree $newFieldId
Assert-Callback ($naming.State.Loading -and $naming.State.Schema.Sections[0].Title -ceq 'Сведения о пациенте') 'Tree rebuild preserves a surrounding loading guard and all section titles'
$naming.State.Loading=$false

# A section selects an actual child field for marker/type/value settings. Keep
# the section tree tag intact so delete/move continue to act on the section.
$sectionSchema=Copy-MedicalFormSchema $config
$sectionSchema.Sections+=@([pscustomobject]@{Id='empty-section';Title='Пустой раздел';Fields=@()})
$sections=New-TestCallbacks $Spec $sectionSchema (Read-MedicalTemplateModel $source)
$sections.Widgets.tree.SelectedNode=$sections.Widgets.tree.Nodes[0]
$firstChild=$sectionSchema.Sections[0].Fields[0];$secondChild=$sectionSchema.Sections[0].Fields[1]
Assert-Callback ($sections.State.Selected.Kind -eq 'section' -and $null -eq $sections.State.Selected.Field -and [object]::ReferenceEquals($sections.State.PropertiesSelection.Field,$firstChild)) 'Selecting a section binds its first actual child without replacing the section tree tag'
Assert-Callback ($sections.Widgets.fieldName.Enabled -and -not $sections.Widgets.fieldName.ReadOnly -and $sections.Widgets.fieldName.Text -ceq 'Раздел' -and $sections.Widgets.propertyNameLabel.Text -ceq 'Название раздела') 'Section title remains editable with a distinct section-name caption'
Assert-Callback ($sections.Widgets.sectionFieldPicker.Visible -and $sections.Widgets.sectionFieldPicker.Enabled -and $sections.Widgets.sectionFieldPicker.Items.Count -eq 2 -and $sections.Widgets.sectionFieldName.Text -ceq 'Текст') 'Section exposes its real child picker and a separate editable child name'
Assert-Callback ($sections.Widgets.fieldMarker.Enabled -and -not $sections.Widgets.fieldMarker.ReadOnly -and $sections.Widgets.fieldType.Enabled -and $sections.Widgets.fieldRequired.Enabled -and $sections.Widgets.fieldRole.Enabled -and $sections.Widgets.fieldWordId.Enabled -and -not $sections.Widgets.fieldWordId.ReadOnly) 'Marker, type, required setting, patient role and Word binding are active for the selected section child'
Assert-Callback ($sections.Widgets.properties.RowStyles[1].Height -gt 0 -and $sections.Widgets.properties.RowStyles[2].Height -gt 0 -and $sections.Widgets.sectionInfo.Text.Contains('Поле раздела')) 'Section-specific property rows provide child selection and explain which field is edited'
$sections.Widgets.fieldName.Text='Сведения'
Assert-Callback ($sectionSchema.Sections[0].Title -ceq 'Сведения' -and $firstChild.Label -ceq 'Текст' -and $sections.Widgets.tree.Nodes[0].Text -ceq 'Сведения') 'Renaming a section preserves a child whose name was already distinct from the section title'
$sections.Widgets.sectionFieldName.Text='Основное поле';$sections.Widgets.fieldMarker.Text='section_primary'
Assert-Callback ($firstChild.Label -ceq 'Основное поле' -and $firstChild.Marker -ceq 'SECTION_PRIMARY' -and $sections.Widgets.tree.Nodes[0].Nodes[0].Text -ceq 'Основное поле  {{SECTION_PRIMARY}}' -and $sections.Widgets.sectionFieldPicker.Items[0] -ceq 'Основное поле') 'Native child-name and marker events update the actual section child, tree caption and picker caption'
$sections.Widgets.fieldType.SelectedIndex=2;$sections.Widgets.fieldType.RaiseSelectedIndexChanged()
Assert-Callback ($sections.Widgets.fieldOptions.Enabled -and $sections.Widgets.detailEnable.Enabled) 'Section child type selection enables its real choice options and clarification conversion'
$sections.Widgets.fieldOptions.Text="Первый`r`nВторой";$sections.Widgets.fieldRequired.Checked=$false;$sections.Widgets.fieldRole.SelectedIndex=1;$sections.Widgets.fieldWordId.Text='172'
$sections.Widgets.sectionFieldPicker.SelectedIndex=1;$sections.Widgets.sectionFieldPicker.RaiseSelectedIndexChanged()
Assert-Callback ($null -eq $sections.Errors.LastError -and $firstChild.Type -ceq 'choice' -and (@($firstChild.Options) -join '|') -ceq 'Первый|Второй' -and -not $firstChild.Required -and $firstChild.System -ceq 'name' -and $firstChild.WordId -ceq '172') 'Changing the section child commits every setting to the previous actual child before reloading'
Assert-Callback ([object]::ReferenceEquals($sections.State.PropertiesSelection.Field,$secondChild) -and $sections.Widgets.fieldMarker.Text -ceq 'CHOICE' -and $sections.Widgets.sectionFieldName.Text -ceq 'Выбор' -and $secondChild.Type -ceq 'choice_detail' -and $secondChild.System -ceq '' -and $secondChild.WordId -ceq '') 'Second child loads its own settings and is not overwritten by the first child controls'
Assert-Callback ($sections.State.Selected.Kind -ceq 'section' -and $null -eq $sections.State.Selected.Field -and $sections.Widgets.fieldName.Text -ceq 'Сведения' -and $sections.State.SectionFieldIds.test -ceq 'choice') 'Child picker keeps the section selected and stores its child ID independently'
$sections.Widgets.sectionFieldName.Text='Адрес';$sections.Widgets.fieldMarker.Text='section_address';$sections.Widgets.detailMarker.Text='section_address_detail';$sections.Widgets.fieldRole.SelectedIndex=3
& $sections.CommitProperties
$sections.Widgets.insertField.RaiseClick()
Assert-Callback ($null -eq $sections.Errors.LastError -and $sections.Widgets.paragraphText.SelectedText -ceq '{{SECTION_ADDRESS}}') 'Section marker insertion uses its actual selected child despite an empty field in the tree tag'
$sections.Widgets.insertDetail.RaiseClick()
Assert-Callback ($null -eq $sections.Errors.LastError -and $sections.Widgets.paragraphText.SelectedText -ceq '{{SECTION_ADDRESS_DETAIL}}') 'Section clarification insertion uses the selected child and its independent detail marker'
$sections.Widgets.tree.SelectedNode=$sections.Widgets.tree.Nodes[1]
Assert-Callback ($sectionSchema.Sections[1].Fields.Count -eq 0 -and $sections.Widgets.fieldName.Enabled -and -not $sections.Widgets.fieldName.ReadOnly -and -not $sections.Widgets.fieldMarker.Enabled -and -not $sections.Widgets.fieldRole.Enabled -and -not $sections.Widgets.sectionFieldPicker.Enabled -and -not $sections.Widgets.insertField.Enabled) 'Existing empty section stays empty and allows a title edit while explaining that it needs a field'
$sections.Widgets.fieldName.Text='Дополнительный раздел';$sections.Widgets.tree.SelectedNode=$sections.Widgets.tree.Nodes[0]
Assert-Callback ([object]::ReferenceEquals($sections.State.PropertiesSelection.Field,$secondChild) -and $sections.Widgets.sectionFieldPicker.SelectedIndex -eq 1 -and $sections.Widgets.fieldMarker.Text -ceq 'SECTION_ADDRESS' -and $sections.Widgets.fieldRole.SelectedIndex -eq 3) 'Leaving and returning to a section restores its chosen child and the edited patient role'
$sections.Widgets.tree.SelectedNode=$sections.Widgets.tree.Nodes[0].Nodes[0]
Assert-Callback (-not $sections.Widgets.sectionFieldPicker.Visible -and -not $sections.Widgets.sectionFieldName.Visible -and -not $sections.Widgets.sectionInfo.Visible -and $sections.Widgets.properties.RowStyles[1].Height -eq 0 -and $sections.Widgets.properties.RowStyles[2].Height -eq 0 -and $sections.Widgets.propertyNameLabel.Text -ceq 'Название поля') 'Selecting a child directly hides section-specific rows and presents the normal field editor'
Assert-Callback ($sections.Widgets.fieldName.Text -ceq 'Основное поле' -and $sections.Widgets.fieldMarker.Text -ceq 'SECTION_PRIMARY' -and $sections.Widgets.fieldRole.SelectedIndex -eq 1 -and $sections.Widgets.fieldWordId.Text -ceq '172') 'Direct field selection loads the settings previously committed while its parent section was selected'
$sections.Widgets.tree.SelectedNode=$sections.Widgets.tree.Nodes[1];$sections.Widgets.addField.RaiseClick()
Assert-Callback ($null -eq $sections.Errors.LastError -and $sectionSchema.Sections[1].Fields.Count -eq 1 -and $sections.State.Selected.Kind -ceq 'field' -and $sections.Widgets.fieldMarker.Enabled) 'Add Field is the explicit action that populates an old empty section and activates its normal settings'
$sections.Widgets.addSection.RaiseClick();$newSection=$sectionSchema.Sections[-1];$newMain=$newSection.Fields[0]
Assert-Callback ($null -eq $sections.Errors.LastError -and $newSection.Fields.Count -eq 1 -and $newMain.Type -ceq 'multiline' -and $newMain.Marker -cmatch '^FIELD_[A-F0-9]{8}$' -and $newMain.Id -cne $newSection.Id -and $sections.Widgets.fieldMarker.Enabled) 'New Section creates one real multiline main field with its own stable ID and usable marker'
$sections.Widgets.fieldName.Text='План';
Assert-Callback ($newSection.Title -ceq 'План' -and $newMain.Label -ceq 'План' -and $sections.Widgets.sectionFieldName.Text -ceq 'План' -and $sections.Widgets.tree.SelectedNode.Nodes[0].Text.StartsWith('План  {{')) 'New section title synchronizes its matching default main-field name through native title events'
$sections.Widgets.sectionFieldName.Text='Назначения';$sections.Widgets.fieldName.Text='Лечение'
Assert-Callback ($newSection.Title -ceq 'Лечение' -and $newMain.Label -ceq 'Назначения' -and $sections.Widgets.sectionFieldName.Text -ceq 'Назначения') 'Custom child name remains independent when the parent section is renamed later'
$sections.Widgets.fieldType.SelectedIndex=0;$sections.Widgets.fieldType.RaiseSelectedIndexChanged();$sections.Widgets.detailEnable.RaiseClick()
Assert-Callback ($null -eq $sections.Errors.LastError -and $newMain.Type -ceq 'choice_detail' -and $sections.Widgets.fieldOptions.Enabled -and $sections.Widgets.detailForm.Enabled -and $sections.Widgets.detailWord.Enabled) 'New one-field section supports native clarification conversion and activates all relevant child settings'
$sections.Widgets.fieldMarker.Text='new_section_main';$sections.Widgets.fieldOptions.Text="Указать`r`nПропустить";$sections.Widgets.fieldRequired.Checked=$false;$sections.Widgets.fieldRole.SelectedIndex=2;$sections.Widgets.fieldWordId.Text='819';$sections.Widgets.detailForm.SelectedIndex=1;$sections.Widgets.detailWord.SelectedIndex=3;$sections.Widgets.detailWord.RaiseSelectedIndexChanged();$sections.Widgets.detailMarker.Text='new_section_extra'
& $sections.CommitProperties
Assert-Callback ($newMain.Marker -ceq 'NEW_SECTION_MAIN' -and (@($newMain.Options) -join '|') -ceq 'Указать|Пропустить' -and -not $newMain.Required -and $newMain.System -ceq 'birth' -and $newMain.WordId -ceq '819' -and $newMain.DetailFormPosition -ceq 'above' -and $newMain.DetailWordPosition -ceq 'marker' -and $newMain.DetailMarker -ceq 'NEW_SECTION_EXTRA') 'New one-field section commits marker, options, validation, patient role, Word ID and both clarification placements to its actual main field'
& $sections.RefreshParts;$sections.State.Paragraph.Editable=$false;& $sections.LoadParagraph
Assert-Callback ($sections.Widgets.fieldName.Enabled -and $sections.Widgets.sectionFieldName.Enabled -and $sections.Widgets.fieldMarker.Enabled -and $sections.Widgets.fieldRole.Enabled -and -not $sections.Widgets.insertField.Enabled -and -not $sections.Widgets.insertDetail.Enabled) 'Read-only complex Word paragraph disables insertion while section title and child settings remain editable'
$sections.State.Paragraph.Editable=$true;& $sections.LoadParagraph

$sections.Widgets.tree.SelectedNode=$sections.Widgets.tree.Nodes[0];$sections.Widgets.fieldRole.SelectedIndex=1;$sections.Widgets.buildTemplate.RaiseClick()
Assert-Callback ($null -ne $sections.Errors.LastError -and $sections.Errors.LastError.Exception.Message.Contains('Роль поля пациента должна быть уникальной')) 'Section editing retains validation that a patient role belongs to only one real field'
$sections.Errors.LastError=$null;$sections.Widgets.fieldRole.SelectedIndex=3;$sections.Widgets.buildTemplate.RaiseClick()
Assert-Callback ($null -eq $sections.Errors.LastError -and (@($sections.State.Model.Paragraphs | Where-Object {$_.Text -ceq 'Сведения'})).Count -eq 1 -and (@($sections.State.Model.Paragraphs | Where-Object {$_.Text -ceq 'Основное поле: {{SECTION_PRIMARY}}'})).Count -eq 1) 'Generating Word uses the edited section title and its independently configured child label and marker'
$sections.Widgets.templateName.Text='section-settings-native.docx';$sections.Widgets.save.RaiseClick()
Assert-Callback ($null -eq $sections.Errors.LastError -and $null -ne $sections.State.Result -and $sections.Widgets.dialog.Closed) 'Section settings pass actual form coverage and atomic Word-template save'
$sectionResult=$sections.State.Result.Schema;$savedPrimary=$sectionResult.Sections[0].Fields[0];$savedAddress=$sectionResult.Sections[0].Fields[1]
Assert-Callback ($sectionResult.Sections[0].Title -ceq 'Сведения' -and $savedPrimary.Marker -ceq 'SECTION_PRIMARY' -and $savedPrimary.Type -ceq 'choice' -and (@($savedPrimary.Options) -join '|') -ceq 'Первый|Второй' -and -not $savedPrimary.Required -and $savedPrimary.System -ceq 'name' -and $savedPrimary.WordId -ceq '172') 'Saved schema retains every editable main-child setting and the independent section title'
Assert-Callback ($savedAddress.Label -ceq 'Адрес' -and $savedAddress.Marker -ceq 'SECTION_ADDRESS' -and $savedAddress.System -ceq 'address' -and $savedAddress.DetailWordPosition -ceq 'marker' -and $savedAddress.DetailMarker -ceq 'SECTION_ADDRESS_DETAIL') 'Saved schema retains the second child and its role and clarification binding without cross-field corruption'
$savedMain=$sectionResult.Sections[-1].Fields[0]
Assert-Callback ($sectionResult.Sections[-1].Title -ceq 'Лечение' -and $savedMain.Label -ceq 'Назначения' -and $savedMain.Marker -ceq 'NEW_SECTION_MAIN' -and $savedMain.System -ceq 'birth' -and $savedMain.WordId -ceq '819' -and $savedMain.DetailFormPosition -ceq 'above' -and $savedMain.DetailMarker -ceq 'NEW_SECTION_EXTRA') 'Saving the new one-field section retains its independent title, child name and complete field and clarification bindings'

$sectionFormPath=Join-Path $TestRoot 'section-native.mcform';[void](Write-MedicalForm $sectionFormPath $sectionResult 'Настроенные разделы');$reopenedForm=Read-MedicalForm $sectionFormPath
Assert-Callback ($reopenedForm.Schema.Sections[0].Title -ceq 'Сведения' -and $reopenedForm.Schema.Sections[0].Fields[0].System -ceq 'name' -and $reopenedForm.Schema.Sections[0].Fields[1].DetailMarker -ceq 'SECTION_ADDRESS_DETAIL') 'The real portable form round trip preserves section-child roles and Word marker bindings'
$exportValues=@{};foreach($f in Get-UniversalFields $reopenedForm.Schema){$exportValues[[string]$f.Id]=if($f.Type -in @('choice','choice_detail')){[string]$f.Options[0]}else{'Ответ '+$f.Label}}
$exportDetails=@{choice='ул. Ленина, 10'};$exported=Join-Path $TestRoot 'section-native-export.docx'
$exportSchema=Copy-MedicalFormSchema $reopenedForm.Schema;$exportSchema.Template=Join-Path $script:medicalProgramRoot $exportSchema.Template
Save-UniversalDocument $exported $exportSchema $exportValues ([datetime]'2026-10-13T22:40:00') $exportDetails
$exportZip=[IO.Compression.ZipFile]::OpenRead($exported)
try{$exportXml=Get-XmlPart $exportZip 'word/document.xml';$exportNs=Get-MedicalEditorNamespace $exportXml;$exportText=@($exportXml.SelectNodes('//w:t',$exportNs) | ForEach-Object {$_.InnerText}) -join ' '}finally{$exportZip.Dispose()}
Assert-Callback ($exportText.Contains('Основное поле: Первый') -and $exportText.Contains('Адрес: Да') -and $exportText.Contains('ул. Ленина, 10') -and -not $exportText.Contains('{{SECTION_PRIMARY}}') -and -not $exportText.Contains('{{SECTION_ADDRESS_DETAIL}}')) 'Actual DOCX export resolves the edited section-child values and separate clarification marker'
$sections.State.Selected=$null;& $sections.LoadProperties
Assert-Callback (-not $sections.Widgets.fieldName.Enabled -and -not $sections.Widgets.fieldMarker.Enabled -and -not $sections.Widgets.fieldRole.Enabled -and -not $sections.Widgets.editSection.Enabled -and -not $sections.Widgets.sectionFieldPicker.Visible) 'No tree selection disables settings and hides section-specific controls without retaining a stale field'

# Only modal user input is replaced; private production rename callbacks still
# execute the actual stable-ID backend and refresh native tree/list selections.
$renameFactory=Get-Command Show-MedicalSectionRenameDialog -CommandType Function
$script:callbackRenameChoice=@{Title='';Cancel=$false;ReplaceWord=$false;Calls=0;SectionId=''}
try{
 Set-Item Function:Show-MedicalSectionRenameDialog -Value {
  param($owner,$schema,[string]$sectionId,$model=$null,$paragraph=$null)
  $script:callbackRenameChoice.Calls++;$script:callbackRenameChoice.SectionId=$sectionId
  if($script:callbackRenameChoice.Cancel){return $null}
  return Invoke-MedicalSectionRename $schema $sectionId $script:callbackRenameChoice.Title $model $(if($paragraph){$paragraph.Id}else{''}) ([bool]$script:callbackRenameChoice.ReplaceWord)
 }
 $renameSchema=Copy-MedicalFormSchema $config;$renameSchema.Sections+=@([pscustomobject]@{Id='rename-empty';Title='Второй';Fields=@()})
 $renames=New-TestCallbacks $Spec $renameSchema (Read-MedicalTemplateModel $source);& $renames.RefreshParts
 $renames.Widgets.tree.SelectedNode=$renames.Widgets.tree.Nodes[0];$oldParagraph=[string]$renames.State.Paragraph.Text
 $script:callbackRenameChoice.Title='Переименован кнопкой';$renames.Widgets.editSection.RaiseClick()
 Assert-Callback ($null -eq $renames.Errors.LastError -and $script:callbackRenameChoice.Calls -eq 1 -and $script:callbackRenameChoice.SectionId -ceq 'test' -and $renameSchema.Sections[0].Title -ceq 'Переименован кнопкой' -and $renames.Widgets.fieldName.Text -ceq 'Переименован кнопкой' -and $renames.State.Paragraph.Text -ceq $oldParagraph) 'Native Edit Section button resolves its private dialog command and renames only the selected section by stable ID'
 $script:callbackRenameChoice.Title='Двойной щелчок';$renames.Widgets.tree.RaiseNodeMouseDoubleClick($renames.Widgets.tree.Nodes[1])
 Assert-Callback ($null -eq $renames.Errors.LastError -and $script:callbackRenameChoice.Calls -eq 2 -and $script:callbackRenameChoice.SectionId -ceq 'rename-empty' -and $renameSchema.Sections[1].Title -ceq 'Двойной щелчок' -and $renameSchema.Sections[0].Title -ceq 'Переименован кнопкой' -and $renames.State.Selected.Section.Id -ceq 'rename-empty') 'Native double-click edits the clicked section even when another section was previously selected'
 $script:callbackRenameChoice.Title='Заголовок по F2';$script:callbackRenameChoice.ReplaceWord=$true;$keyArgs=$renames.Widgets.tree.RaiseKeyDown([Windows.Forms.Keys]::F2)
 Assert-Callback ($null -eq $renames.Errors.LastError -and $script:callbackRenameChoice.Calls -eq 3 -and $keyArgs.Handled -and $keyArgs.SuppressKeyPress -and $renameSchema.Sections[1].Title -ceq 'Заголовок по F2' -and $renames.State.Paragraph.Text -ceq 'Заголовок по F2' -and $renames.Widgets.paragraphText.Text -ceq 'Заголовок по F2') 'Native F2 rename optionally updates the selected Word paragraph and refreshes its visible editor'
 $script:callbackRenameChoice.Cancel=$true;$renames.Widgets.editSection.RaiseClick()
 Assert-Callback ($script:callbackRenameChoice.Calls -eq 4 -and $renameSchema.Sections[1].Title -ceq 'Заголовок по F2' -and $renames.State.Paragraph.Text -ceq 'Заголовок по F2') 'Cancel in the section dialog leaves the form title and Word text unchanged'
 $beforeCalls=$script:callbackRenameChoice.Calls;[void]$renames.Widgets.tree.RaiseKeyDown([Windows.Forms.Keys]::Enter);$renames.Widgets.tree.RaiseNodeMouseDoubleClick($renames.Widgets.tree.Nodes[0].Nodes[0])
 Assert-Callback ($script:callbackRenameChoice.Calls -eq $beforeCalls) 'Other keys and double-clicking a field do not open a section rename dialog'
 $renames.Widgets.tree.SelectedNode=$renames.Widgets.tree.Nodes[0].Nodes[0];$renames.Widgets.editSection.RaiseClick();[void]$renames.Widgets.tree.RaiseKeyDown([Windows.Forms.Keys]::F2)
 Assert-Callback (-not $renames.Widgets.editSection.Enabled -and $script:callbackRenameChoice.Calls -eq $beforeCalls -and $renameSchema.Sections[0].Fields[0].Label -ceq 'Текст') 'Section rename guard remains inactive for a field and preserves its ordinary name editor'
 Assert-Callback (-not (Get-Item Function:global:Show-MedicalSectionRenameDialog -ErrorAction SilentlyContinue)) 'Section rename callbacks do not promote the private dialog helper into global scope'
}finally{Set-Item Function:Show-MedicalSectionRenameDialog -Value $renameFactory.ScriptBlock}

$plain=New-TestCallbacks $Spec (Copy-MedicalFormSchema $config) (Read-MedicalTemplateModel $source)
$plain.State.Selected=[pscustomobject]@{Kind='field';Section=$plain.State.Schema.Sections[0];Field=$plain.State.Schema.Sections[0].Fields[0]}
& $plain.LoadProperties
Assert-Callback ($plain.Widgets.detailTab.Enabled -and $plain.Widgets.detailStatus.Text.Length -gt 0) 'Clarification tab remains accessible and explains a plain text field'
Assert-Callback ($plain.Widgets.detailEnable.Enabled -and -not $plain.Widgets.detailForm.Enabled -and -not $plain.Widgets.detailWord.Enabled) 'Plain text field offers clarification conversion while its settings are inactive'
Assert-Callback (-not $plain.Widgets.fieldOptions.Enabled) 'Plain text field does not show an active option editor'
$plain.Widgets.detailEnable.RaiseClick()
Assert-Callback ($null -eq $plain.Errors.LastError -and $plain.State.Selected.Field.Type -eq 'choice_detail' -and $plain.Widgets.fieldType.SelectedIndex -eq 3) 'Native enable-clarification event converts the selected text field'
Assert-Callback ($plain.Widgets.detailForm.Enabled -and $plain.Widgets.detailWord.Enabled -and $plain.Widgets.fieldOptions.Enabled) 'Converted clarification field enables its placement and options controls immediately'
Assert-Callback (-not $plain.Widgets.detailMarker.Enabled -and -not $plain.Widgets.insertDetail.Enabled) 'Separate clarification marker stays inactive while Word appends the detail'
$plain.Widgets.detailWord.SelectedIndex=3;$plain.Widgets.detailWord.RaiseSelectedIndexChanged()
Assert-Callback ($plain.Widgets.detailMarker.Enabled -and $plain.Widgets.insertDetail.Enabled) 'Native Word-placement event immediately enables the separate clarification marker'
$plain.Widgets.detailForm.SelectedIndex=1;$plain.Widgets.detailMarker.Text='text_detail'
& $plain.CommitProperties
Assert-Callback ($plain.State.Selected.Field.DetailFormPosition -eq 'above' -and $plain.State.Selected.Field.DetailWordPosition -eq 'marker' -and $plain.State.Selected.Field.DetailMarker -eq 'TEXT_DETAIL') 'Converted field commits form placement, Word placement and normalized detail marker'
$plain.Widgets.fieldType.SelectedIndex=0;$plain.Widgets.fieldType.RaiseSelectedIndexChanged()
Assert-Callback ($plain.Widgets.detailTab.Enabled -and $plain.Widgets.detailEnable.Enabled -and -not $plain.Widgets.detailForm.Enabled -and -not $plain.Widgets.insertDetail.Enabled) 'Native type-change event updates clarification controls without hiding their tab'
$plain.Widgets.tree.SelectedNode=$plain.Widgets.tree.Nodes[0]
Assert-Callback ($plain.Widgets.detailTab.Enabled -and $plain.Widgets.detailEnable.Enabled -and -not $plain.Widgets.detailForm.Enabled -and $plain.Widgets.detailStatus.Text.Length -gt 0) 'Section selection offers clarification for its selected child field while retaining a readable explanation'
$plain.State.Selected=$null;& $plain.LoadProperties
Assert-Callback ($plain.Widgets.detailTab.Enabled -and -not $plain.Widgets.detailEnable.Enabled -and -not $plain.Widgets.insertField.Enabled) 'No form selection does not expose field or clarification insertion'
$current=New-TestCallbacks $Spec (Copy-MedicalFormSchema $config) (Read-MedicalTemplateModel $source)
Assert-Callback ($current.Commands.Count -eq 17) 'Production binding captures all seventeen private helper commands'
foreach($command in $current.Commands.Values){Assert-Callback ($command -is [Management.Automation.FunctionInfo]) ('Private function captured as a command object: '+$command.Name)}
& $current.LoadProperties
Assert-Callback ($current.Widgets.fieldName.Text -eq 'Выбор' -and $current.Widgets.fieldType.SelectedIndex -eq 3) 'Loading field properties resolves private application helpers'
Assert-Callback ($current.Widgets.fieldRequired.Checked -and $current.Widgets.detailForm.SelectedIndex -eq 2 -and $current.Widgets.detailWord.SelectedIndex -eq 3) 'Required and clarification settings load through all three helpers'
& $current.RefreshParts
Assert-Callback ($current.Widgets.paragraphList.Items[0] -is [string] -and $current.State.VisibleParagraphs.Count -eq $current.Widgets.paragraphList.Items.Count) 'Native list uses display strings with a separate paragraph index mapping'
Assert-Callback ($current.State.Paragraph -and -not $current.Widgets.paragraphText.ReadOnly -and $current.Widgets.paragraphText.Text.Length -gt 0 -and $current.Widgets.paragraphTitle.Text.Length -gt 0) 'Initial paragraph selection loads visible editable text and its caption'
Assert-Callback ($current.Errors.FormatLoadCount -eq 1) 'Initial paragraph selection loads its formatting component through the production closure'
$firstId=$current.State.Paragraph.Id;$originalFirst=$current.State.Paragraph.Text
$paragraphNode=$current.State.Paragraph.Node
$namespaces=Get-MedicalEditorNamespace $paragraphNode.OwnerDocument
$beforeParagraphStyle=$paragraphNode.SelectSingleNode('./w:pPr',$namespaces).OuterXml
$beforeRunStyle=$paragraphNode.SelectSingleNode('./w:r/w:rPr',$namespaces).OuterXml
$current.Widgets.paragraphText.Text=$originalFirst+' edited by event'
Assert-Callback ($current.State.Paragraph.Text -ceq ($originalFirst+' edited by event') -and $current.Widgets.paragraphList.Items[0] -ceq ($current.State.Paragraph.Location+' | '+$originalFirst+' edited by event')) 'Native text change immediately updates the real paragraph XML model and its visible list caption'
Assert-Callback ($paragraphNode.SelectSingleNode('./w:pPr',$namespaces).OuterXml -ceq $beforeParagraphStyle -and $paragraphNode.SelectSingleNode('./w:r/w:rPr',$namespaces).OuterXml -ceq $beforeRunStyle) 'Live paragraph changes preserve its original paragraph and first-run Word formatting'
$liveCaption=$current.Widgets.paragraphList.Items[0]
$current.Widgets.paragraphText.Text="Новый абзац`r`nсо второй строкой`tи табуляцией" 
Assert-Callback ($current.Widgets.paragraphList.Items[0] -ceq ($current.State.Paragraph.Location+' | Новый абзац со второй строкой и табуляцией')) 'Live paragraph list caption presents multiline and tabbed text as one readable line'
$current.Widgets.paragraphText.Text=('д'*170)
Assert-Callback ($current.Widgets.paragraphList.Items[0] -ceq ($current.State.Paragraph.Location+' | '+('д'*145)+'…') -and $current.State.Paragraph.Text.Length -eq 170) 'Live list preview truncates its caption while preserving the complete paragraph text'
$current.Widgets.paragraphText.Text=$originalFirst+' edited by event' 
$current.Widgets.paragraphList.SelectedIndex=1
# C# raises the real PowerShell delegate; this is not a direct & handler call.
$current.Widgets.paragraphList.RaiseSelectedIndexChanged()
Assert-Callback ($null -eq $current.Errors.LastError) 'Native .NET event dispatch resolves the private paragraph helper'
Assert-Callback ((@($current.State.Model.Paragraphs | Where-Object {$_.Id -ceq $firstId})[0]).Text -eq ($originalFirst+' edited by event')) 'Switching paragraphs commits the previous paragraph through the real callback'
Assert-Callback ($current.State.Paragraph.Id -ne $firstId -and $current.Widgets.paragraphText.Text -eq $current.State.Paragraph.Text) 'Switching paragraphs loads the newly selected text'
Assert-Callback ($current.Errors.FormatLoadCount -eq 2) 'Native paragraph-selection event reloads the selected paragraph formatting component'
$formatLoads=$current.Errors.FormatLoadCount;$current.Widgets.documentTabs.SelectedTab=$current.Widgets.formatTab
$current.Widgets.documentTabs.RaiseSelectedIndexChanged()
Assert-Callback ($null -eq $current.Errors.LastError -and $current.Errors.FormatLoadCount -eq $formatLoads+1) 'Native editor-tab event invokes its paragraph formatting loader'
$current.Widgets.documentTabs.SelectedTab=$current.Widgets.layoutTab;$current.Widgets.documentTabs.RaiseSelectedIndexChanged()
Assert-Callback ($null -eq $current.Errors.LastError -and $current.Widgets.layoutBrowser.DocumentText -match '<html' -and $current.Widgets.layoutBrowser.DocumentText.Contains('{{TEXT}}')) 'Native layout-tab event renders the actual HTML through its captured private helper'
Assert-Callback (-not (Get-Item Function:global:ConvertTo-MedicalTemplateHtml -ErrorAction SilentlyContinue)) 'HTML rendering callback preserves private application scope'
# Force Word's unavailable path without executing COM, independent of host platform.
# The production callback and renderer remain unchanged and resolve nested helpers.
$wordFactory=Get-Command New-MedicalPreviewWordApplication -CommandType Function
$wordCache=Join-Path ([IO.Path]::GetTempPath()) ('mc-word-preview-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($wordCache);[IO.File]::WriteAllText((Join-Path $wordCache 'preview.docx'),'private callback test cache')
$current.State.WordPreview=[pscustomobject]@{TempFolder=$wordCache}
try{
 Set-Item Function:New-MedicalPreviewWordApplication -Value {throw 'Private callback test: Word unavailable'}
 $current.Widgets.wordPreviewButton.RaiseClick()
 Assert-Callback ($null -eq $current.Errors.LastError -and $current.State.WordPreview.Available -eq $false -and $current.Widgets.wordStatus.Text -eq 'Private callback test: Word unavailable') 'Native Word-preview event resolves its captured renderer and displays an unavailable result without COM'
 Assert-Callback (-not [IO.Directory]::Exists($wordCache)) 'Word-preview callback resolves its private cleanup helper before replacing its previous cache'
 Assert-Callback ($current.Widgets.wordPreviewButton.Enabled -and -not $current.Widgets.dialog.UseWaitCursor) 'Unavailable Word preview restores the button and normal editor cursor'
}finally{
 Set-Item Function:New-MedicalPreviewWordApplication -Value $wordFactory.ScriptBlock
 if([IO.Directory]::Exists($wordCache)){[IO.Directory]::Delete($wordCache,$true)}
}

& $current.Handlers.insertDetail
Assert-Callback ($null -eq $current.Errors.LastError -and $current.Widgets.paragraphText.SelectedText -eq '{{CHOICE_DETAIL}}') 'Clarification-marker callback invokes its private helper'
& $current.Handlers.insertField
Assert-Callback ($current.Widgets.paragraphText.SelectedText -eq '{{CHOICE}}') 'Field-marker callback uses the selected field'
$count=$current.State.Model.Paragraphs.Count
& $current.Handlers.addParagraph
Assert-Callback ($null -eq $current.Errors.LastError -and $current.State.Model.Paragraphs.Count -eq $count+1) 'Add-paragraph callback reaches nested XML helpers'
Assert-Callback ($current.State.Paragraph.Id -eq $current.State.VisibleParagraphs[$current.Widgets.paragraphList.SelectedIndex].Id -and -not $current.Widgets.paragraphText.ReadOnly) 'New paragraph is selected through its mapped list index and can accept text'
$current.Widgets.paragraphText.Text='before after';$current.Widgets.paragraphText.SelectionStart=6;$current.Widgets.paragraphText.SelectionLength=0
[Windows.Forms.Clipboard]::Text="вставка`r`nстрока";$reads=[Windows.Forms.Clipboard]::ReadCount
$current.Widgets.pasteText.RaiseClick()
Assert-Callback ($null -eq $current.Errors.LastError -and $current.Widgets.paragraphText.Text -eq "beforeвставка`r`nстрока after" -and [Windows.Forms.Clipboard]::ReadCount -eq $reads+1) 'Native paste event inserts Unicode multiline text at the cursor'
$current.Widgets.paragraphText.SelectionStart=0;$current.Widgets.paragraphText.SelectionLength=6;[Windows.Forms.Clipboard]::Text='замена '
$current.Widgets.pasteText.RaiseClick()
Assert-Callback ($current.Widgets.paragraphText.Text -eq "замена вставка`r`nстрока after") 'Paste replaces the selected text while preserving text on either side'
[Windows.Forms.Clipboard]::Text='';$beforePaste=$current.Widgets.paragraphText.Text;$reads=[Windows.Forms.Clipboard]::ReadCount
$current.Widgets.pasteText.RaiseClick()
Assert-Callback ($current.Widgets.paragraphText.Text -ceq $beforePaste -and [Windows.Forms.Clipboard]::ReadCount -eq $reads) 'Empty clipboard leaves paragraph text unchanged'
$current.Errors.LastError=$null
# The same mutable paragraph record drives selection, availability and the callback guard.
& $current.CommitParagraph
$current.State.Paragraph.Editable=$false;& $current.LoadParagraph
Assert-Callback ($current.Widgets.paragraphText.ReadOnly -and -not $current.Widgets.pasteText.Enabled -and -not $current.Widgets.deleteParagraph.Enabled) 'Read-only paragraph disables text mutation and deletion controls'
[Windows.Forms.Clipboard]::Text='blocked';$countBefore=$current.State.Model.Paragraphs.Count
$current.Widgets.pasteText.RaiseClick();$current.Widgets.deleteParagraph.RaiseClick()
Assert-Callback ($null -eq $current.Errors.LastError -and $current.Widgets.paragraphText.Text -ceq $beforePaste -and [Windows.Forms.Clipboard]::ReadCount -eq $reads -and $current.State.Model.Paragraphs.Count -eq $countBefore) 'Read-only callback guards reject paste and deletion even when events are raised programmatically'
$current.State.Paragraph.Editable=$true;& $current.LoadParagraph
$current.Widgets.paragraphText.Text="Сохранить до удаления`r`nВторая строка";[Windows.Forms.MessageBox]::Response='No'
$current.Widgets.deleteParagraph.RaiseClick()
Assert-Callback ($current.State.Model.Paragraphs.Count -eq $countBefore -and $current.State.Paragraph.Text -eq "Сохранить до удаления`r`nВторая строка") 'Cancel deletion retains the paragraph and commits its edited text'
[Windows.Forms.MessageBox]::Response='Yes';$removedNode=$current.State.Paragraph.Node
$current.Widgets.deleteParagraph.RaiseClick()
Assert-Callback ($null -eq $current.Errors.LastError -and $current.State.Model.Paragraphs.Count -eq $countBefore-1 -and $null -eq $removedNode.ParentNode) 'Confirmed native delete event removes the selected editable XML paragraph'
Assert-Callback ($current.State.Paragraph -and $current.State.Paragraph.Id -eq $current.State.VisibleParagraphs[$current.Widgets.paragraphList.SelectedIndex].Id -and $current.Widgets.paragraphText.Text -ceq $current.State.Paragraph.Text) 'Deleting a paragraph reloads the remaining mapped selection and its text'
$current.State.Paragraph=$null;& $current.UpdateAvailability;$noSelectionText=$current.Widgets.paragraphText.Text;$countBefore=$current.State.Model.Paragraphs.Count
$current.Widgets.pasteText.RaiseClick();$current.Widgets.deleteParagraph.RaiseClick()
Assert-Callback (-not $current.Widgets.pasteText.Enabled -and -not $current.Widgets.deleteParagraph.Enabled -and $current.Widgets.paragraphText.Text -ceq $noSelectionText -and $current.State.Model.Paragraphs.Count -eq $countBefore -and [Windows.Forms.Clipboard]::ReadCount -eq $reads) 'No paragraph selection cannot paste text or delete a paragraph'
$formatLoads=$current.Errors.FormatLoadCount;$selectedIndex=$current.Widgets.paragraphList.SelectedIndex
$current.Widgets.paragraphList.SelectedIndex=-1;& $current.LoadParagraph
Assert-Callback ($null -eq $current.State.Paragraph -and $current.Widgets.paragraphText.ReadOnly -and $current.Errors.FormatLoadCount -eq $formatLoads+1) 'Empty paragraph selection still loads the formatting component so it can disable its controls'
$current.Widgets.paragraphList.SelectedIndex=$selectedIndex;& $current.LoadParagraph

$fieldCount=$current.State.Schema.Sections[0].Fields.Count;$treeRefreshes=$current.Widgets.tree.BeginUpdateCount
& $current.Handlers.addField
Assert-Callback ($null -eq $current.Errors.LastError -and $current.State.Schema.Sections[0].Fields.Count -eq $fieldCount+1) 'Add-field callback resolves New-UniversalField'
Assert-Callback ($current.Widgets.tree.BeginUpdateCount -eq $treeRefreshes+1) 'Add-field callback refreshes the form after inserting its field'
& $current.Handlers.buildTemplate
Assert-Callback ($null -eq $current.Errors.LastError -and $current.Widgets.templateName.Text -eq 'Мой шаблон.docx') 'Build-template callback validates, generates and reloads through three private helpers'
Assert-Callback ((@($current.State.Model.Paragraphs | Where-Object {$_.Text -like '*{{FIELD_*}}*'})).Count -eq 1) 'Generated Word template includes the field created by its callback'
$current.Widgets.templateName.Text='saved-from-callback.docx'
$current.Widgets.paragraphText.Text=$current.State.Paragraph.Text+' saved edit'
& $current.Handlers.save
Assert-Callback ($null -eq $current.Errors.LastError -and $null -ne $current.State.Result) 'Apply callback completes real Word-template validation and atomic save'
Assert-Callback ($current.Widgets.dialog.Closed -and $current.Widgets.dialog.DialogResult -eq 'OK') 'Apply callback closes its editor only after a successful save'
$saved=$current.State.Result.Template.Path
Assert-Callback ($saved.StartsWith($script:medicalTemplatesFolder) -and [IO.File]::Exists($saved)) 'Save callback retains original script-root template folder'
$roundTrip=Read-MedicalTemplateModel $saved
Assert-Callback ((@($roundTrip.Paragraphs | Where-Object {$_.Text -like '* saved edit'})).Count -eq 1) 'Edited paragraph survives saving and reloading the actual DOCX'
Assert-MedicalEditorTemplateCoverage $current.State.Result.Schema $roundTrip
Assert-Callback $true 'Saved callback result retains every form and clarification marker'
Assert-Callback ((Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($source))) -ceq $sourceHash) 'All callbacks preserve the original Word template'
Assert-Callback (-not (Get-Item Function:global:Set-MedicalTemplateParagraph -ErrorAction SilentlyContinue)) 'Regression fix does not promote application helpers globally'
Write-Output ('Callback regression checks passed: '+$script:checks)
'@
try{
 [IO.File]::WriteAllText($child,($childSource -replace '\r?\n',"`r`n"),[Text.UTF8Encoding]::new($true))
 & $child -Project $Project -TestRoot $temp -Spec $spec -Legacy $legacy -LegacyNaming $legacyNaming
 if(Get-Command Set-MedicalTemplateParagraph -ErrorAction SilentlyContinue){throw 'Child application scope leaked into the verification script.'}
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
