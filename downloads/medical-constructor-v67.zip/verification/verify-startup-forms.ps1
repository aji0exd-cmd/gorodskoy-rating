﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v67'))
$ErrorActionPreference='Stop';$script:checks=0;$script:startupPassLog=New-Object 'System.Collections.Generic.List[string]'
function Assert-Startup([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;$script:startupPassLog.Add('PASS '+$message)}
function Import-StartupFunction([string]$path,[string[]]$names){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors | Out-String)}
 foreach($name in $names){
  $definition=$ast.Find({param($node)$node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $name},$false)
  if(-not $definition){throw ('Missing production function '+$name)}
  . ([scriptblock]::Create(($definition.Extent.Text -replace '^function\s+','function script:')))
 }
}
# Only native widgets, modal scheduling and view rendering are adapted below.
# The actual startup handlers, form selection, reset and on-disk serializers run
# unchanged, with script-local helpers captured into their original closures.
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @'
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
public class MedicalStartupControl {
 public List<MedicalStartupControl> Controls {get;private set;}
 public ArrayList Items {get;private set;}
 public string Text {get;set;}
 public bool Enabled {get;set;}
 public bool AutoSize {get;set;}
 public string Anchor {get;set;}
 public object Tag {get;set;}
 public object Font {get;set;}
 public bool IsDisposed {get;private set;}
 public MedicalStartupControl Parent {get;set;}
 public int SelectedIndex {get;set;}
 public string DropDownStyle {get;set;}
 public string Dock {get;set;}
 public Size Size {get;set;}
 public Size AutoScrollMinSize {get;set;}
 public Point AutoScrollPosition {get;set;}
 public int Width {get;set;}
 public int Height {get;set;}
 public string AccessibleName {get;set;}
 public object DialogResult {get;set;}
 public MedicalStartupControl(){Controls=new List<MedicalStartupControl>();Items=new ArrayList();Text="";Enabled=true;SelectedIndex=-1;}
 public void SetBounds(int x,int y,int w,int h){Width=w;Height=h;}
 public void SuspendLayout(){}
 public void ResumeLayout(bool perform){}
 public void PerformLayout(){}
 public void Refresh(){}
 public void Dispose(){IsDisposed=true;}
 public bool Focus(){return true;}
 public event EventHandler Click;
 public void RaiseClick(){if(Click!=null)Click(this,EventArgs.Empty);}
}
namespace Windows.Forms {
 public class Label:MedicalStartupControl{}
 public class Button:MedicalStartupControl{}
 public class ComboBox:MedicalStartupControl{}
 public class ListBox:MedicalStartupControl{}
 public class Form:MedicalStartupControl {
  public static Action<Form> Plan;
  public static int Calls=0;
  public string StartPosition {get;set;}
  public string FormBorderStyle {get;set;}
  public bool MaximizeBox {get;set;}
  public bool MinimizeBox {get;set;}
  public bool ShowInTaskbar {get;set;}
  public object CancelButton {get;set;}
  public object AcceptButton {get;set;}
  public bool Closed {get;private set;}
  public object ShowDialog(object owner){Calls++;if(Plan!=null)Plan(this);return DialogResult??"Cancel";}
  public void Close(){Closed=true;}
 }
 public class OpenFileDialog {
  public static string PickedPath="";
  public static string Result="OK";
  public static string CapturedDirectory="";
  public static string CapturedName="";
  public static int Calls=0;
  public string Filter {get;set;}
  public string Title {get;set;}
  public string InitialDirectory {get;set;}
  public string FileName {get;set;}
  public bool CheckFileExists {get;set;}
  public bool Multiselect {get;set;}
  public object ShowDialog(object owner){Calls++;CapturedDirectory=InitialDirectory;CapturedName=FileName;FileName=PickedPath;return Result;}
  public void Dispose(){}
 }
 public class SaveFileDialog {
  public static string PickedPath="";
  public static string Result="OK";
  public static string CapturedDirectory="";
  public static string CapturedName="";
  public static int Calls=0;
  public string Filter {get;set;}
  public string Title {get;set;}
  public string InitialDirectory {get;set;}
  public string FileName {get;set;}
  public string DefaultExt {get;set;}
  public bool AddExtension {get;set;}
  public bool OverwritePrompt {get;set;}
  public object ShowDialog(object owner){Calls++;CapturedDirectory=InitialDirectory;CapturedName=FileName;FileName=PickedPath.Length>0?PickedPath:System.IO.Path.Combine(InitialDirectory,FileName);return Result;}
  public void Dispose(){}
 }
 public static class MessageBox {
  public static string Result="OK";
  public static List<string> Messages=new List<string>();
  public static string Show(params object[] args){Messages.Add(args.Length>1?Convert.ToString(args[1]):"");return Result;}
 }
}
namespace System.Windows.Forms {public class ComboBox:global::Windows.Forms.ComboBox{}}
'@
function Set-DarkTheme($control){}
function Capture-Stage {$script:capturedStages++}
function Open-Stage {
 $script:openedStages++
 $panel.Controls.Clear()
 foreach($field in Get-UniversalFields $script:universalConfig){$control=New-Object MedicalStartupControl;$control.Text=[string]$script:universalValues[[string]$field.Id];[void]$panel.Controls.Add($control)}
 $save.Enabled=$true
}
function Get-StartupButton($dialog,[string]$text){
 $buttons=@($dialog.Controls | Where-Object {$_ -is [Windows.Forms.Button] -and $_.Text -ceq $text})
 if($buttons.Count -ne 1){throw ('Missing/ambiguous startup button '+$text)}
 return $buttons[0]
}
function Get-StartupList($dialog){
 $lists=@($dialog.Controls | Where-Object {$_ -is [Windows.Forms.ComboBox] -or $_ -is [Windows.Forms.ListBox]})
 if($lists.Count -ne 1){throw 'Missing/ambiguous startup forms list'}
 return $lists[0]
}
function Set-StartupDirtyState {
 $script:universalConfig=Copy-MedicalFormSchema $script:fixtureSchema
 $script:universalValues=@{patient_name='Старый Пациент';complaints='Старый ответ'};$script:universalDetails=@{history='Старое уточнение'}
 $script:universalInputs=@{old=[pscustomobject]@{Text='Старое поле'}};$script:universalDetailInputs=@{old=[pscustomobject]@{Text='Старое уточнение'}};$script:universalMultiInputs=@{old='старый список'};$script:universalRepeatInputs=@{old='старый повтор'}
 $script:stageData=@{initial=@('Старый осмотр');diary_1=@('Старый дневник')};$script:stage='discharge';$script:stageTemplates=@{initial=$script:fixtureSchema.Template;diary='Старый дневник.docx';discharge='Старая выписка.docx'}
 $script:caseFile='Старая карта.docx';$script:caseFolder='Старая папка';$script:caseLastSavedPatientName='Старый Пациент';$script:pendingDocument='Старый результат.docx';$script:diaryIndex=5;$script:currentPatient=8
 $script:medicalWorkspaceReady=$true;$script:activeMedicalFormPath='Старая форма.mcform';$script:activeMedicalFormName='Старая форма';$script:medicalFormBaseline=Get-MedicalFormSignature $script:universalConfig
 $script:universalFlow=New-Object MedicalStartupControl;$script:universalCompletionLabel=New-Object MedicalStartupControl;$script:universalIndicators=@{old=(New-Object MedicalStartupControl)};$script:uiMedicalFormStatus=New-Object MedicalStartupControl;$script:uiMedicalFormStatus.Text='Форма: Старые технические идентификаторы'
 foreach($button in @($stageInitial,$stageDiary,$stageDischarge,$save)){$button.Enabled=$true}
 $panel.Controls.Clear();[void]$panel.Controls.Add((New-Object MedicalStartupControl))
 $script:openedStages=0;$script:capturedStages=0;$script:newChoiceCalls=0;$script:newEditorCalls=0;$script:newChoiceResult=$null;$script:newEditorResult=$null
 [Windows.Forms.MessageBox]::Messages.Clear();[Windows.Forms.MessageBox]::Result='OK';[Windows.Forms.OpenFileDialog]::Calls=0;[Windows.Forms.OpenFileDialog]::Result='OK';[Windows.Forms.SaveFileDialog]::Calls=0;[Windows.Forms.SaveFileDialog]::Result='OK';[Windows.Forms.SaveFileDialog]::PickedPath=''
}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-v65-startup-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 $root=Join-Path $temp 'program';[void][IO.Directory]::CreateDirectory($root)
 foreach($name in @('universal.ps1','forms-v59.ps1','template-recovery-v66.ps1','forms-ui-v59.ps1','clinical-stages-v67.ps1','clinical-ui-v67.ps1')){Copy-Item -LiteralPath (Join-Path $Project $name) -Destination (Join-Path $root $name)}
 . (Join-Path $root 'universal.ps1')
 . (Join-Path $root 'forms-v59.ps1')
 . (Join-Path $root 'template-recovery-v66.ps1')
 . (Join-Path $root 'forms-ui-v59.ps1')
 . (Join-Path $root 'clinical-stages-v67.ps1')
 . (Join-Path $root 'clinical-ui-v67.ps1')
 Import-StartupFunction (Join-Path $Project 'universal-ui.ps1') @('Clear-MedicalWorkspacePanels')
 function Show-MedicalTemplateChoice($owner,$config,[bool]$newForm=$true){$script:newChoiceCalls++;return $script:newChoiceResult}
 function Show-MedicalFormTemplateEditor($owner,$config){$script:newEditorCalls++;return $script:newEditorResult}
 Import-StartupFunction (Join-Path $Project 'constructor.ps1') @('Get-XmlPart','Reset-NewPatientCase')
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 $form=New-Object MedicalStartupControl;$panel=New-Object MedicalStartupControl;$save=New-Object MedicalStartupControl;$caseSave=New-Object MedicalStartupControl
 $stageInitial=New-Object MedicalStartupControl;$stageDiary=New-Object MedicalStartupControl;$stageDischarge=New-Object MedicalStartupControl
 $script:hospitalControls=@{};$script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-13T13:00:00'}
 foreach($name in @('patientNameControl','patientBirthControl','patientAddressControl','streetControl','houseControl','apartmentControl')){Set-Variable -Scope Script -Name $name -Value ([pscustomobject]@{Text='Старый Пациент'})}
 $script:fixtureSchema=New-UniversalConfig;$script:fixtureSchema.AutoTemplate=$false;$script:fixtureSchema.Template=Join-Path $root 'Шаблоны/Форма с понятным именем.docx'
 [void](Initialize-MedicalTemplateFolder);New-UniversalTemplate $script:fixtureSchema.Template $script:fixtureSchema
 $localPath=Join-Path $root 'Первичный осмотр.mcform';[void](Write-MedicalForm $localPath $script:fixtureSchema 'Первичный осмотр')
 $secondPath=Join-Path $root 'Выписка.mcform';[void](Write-MedicalForm $secondPath $script:fixtureSchema 'Выписка')
 [IO.File]::WriteAllText((Join-Path $root 'Поврежденная.mcform'),'invalid JSON',[Text.UTF8Encoding]::new($true))
 [IO.File]::WriteAllText((Join-Path $root 'Не форма.json'),'{}')
 $outside=Join-Path $temp 'outside';[void][IO.Directory]::CreateDirectory($outside)
 $externalPath=Join-Path $outside 'Моя особая форма.mcform';[void](Write-MedicalForm $externalPath $script:fixtureSchema 'Моя особая форма')
 Save-UniversalConfig $script:fixtureSchema
 $cachedBytes=[Convert]::ToBase64String([IO.File]::ReadAllBytes($script:universalConfigPath))
 $forms=@(Get-MedicalLocalForms)
 Assert-Startup ($forms.Count -eq 3 -and $forms.Path -contains $localPath -and $forms.Path -contains $secondPath) 'Startup enumerates saved mcform files beside the program'
 Assert-Startup ($forms.Path -notcontains $externalPath -and @($forms | Where-Object {$_.Path.EndsWith('.json')}).Count -eq 0) 'Startup list excludes external forms and unrelated JSON files'
 Assert-Startup (@($forms | Where-Object {[string]::IsNullOrWhiteSpace($_.Name)}).Count -eq 0) 'Every startup form has a visible friendly list name'
 $otherForms=@(Get-MedicalLocalForms $outside)
 Assert-Startup ($otherForms.Count -eq 1 -and $otherForms[0].Path -ceq $externalPath) 'Local form enumeration uses an explicit folder when supplied'
 Assert-Startup (@(Get-MedicalLocalForms (Join-Path $temp 'not-there')).Count -eq 0) 'A missing forms directory yields an empty list without loading a schema'
 # Plans below interact with actual button delegates registered by production.
 # Cancellation must stay blank even with a valid cached config and templates.
 Set-StartupDirtyState
 $script:chooserObserved=$false
 [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{
  param($dialog)
  $script:chooserObserved=$true
  Assert-Startup (-not $script:medicalWorkspaceReady -and $script:openedStages -eq 0) 'Startup shows the chooser before using any cached form'
  Assert-Startup (-not $stageInitial.Enabled -and -not $stageDiary.Enabled -and -not $stageDischarge.Enabled -and -not $save.Enabled) 'Stage and document actions stay disabled while no form was selected'
  Assert-Startup ($script:universalValues.Count -eq 0 -and $script:universalDetails.Count -eq 0 -and $script:stageData.Count -eq 0) 'Entering startup clears patient answers, clarifications and previous stages'
  $dialog.DialogResult='Cancel'
 }
 Start-MedicalFormsWorkspace
 Assert-Startup ($script:chooserObserved -and -not $script:medicalWorkspaceReady -and $script:openedStages -eq 0) 'Canceling startup does not autoload the valid cached form'
 Assert-Startup ($script:activeMedicalFormPath -ceq '' -and $script:activeMedicalFormName -notmatch '[0-9a-f]{8}-[0-9a-f]{4}') 'Canceled startup has no stale form path or technical identifier in its name'
 Assert-Startup ($script:caseFile -ceq '' -and $script:caseFolder -ceq '' -and $script:caseLastSavedPatientName -eq $null) 'Canceled startup retains no bindings to a previous patient card'
 Assert-Startup ([Convert]::ToBase64String([IO.File]::ReadAllBytes($script:universalConfigPath)) -ceq $cachedBytes) 'Canceling startup preserves the cached configuration file bytes'
 Assert-Startup ($panel.Controls.Count -eq 1 -and $panel.Controls[0] -is [Windows.Forms.Label]) 'Canceled startup shows only the instructions for selecting a form'
 Assert-Startup ($script:universalFlow -eq $null -and $script:universalCompletionLabel -eq $null -and $script:universalIndicators.Count -eq 0) 'Canceled startup releases stale form, completion and field-indicator references'
 Assert-Startup ($script:uiMedicalFormStatus.Text -ceq 'Форма не открыта') 'Canceled startup replaces the old technical status with Form Not Opened'
 Assert-Startup ([Windows.Forms.MessageBox]::Messages.Count -eq 0) 'A valid cached config and templates do not trigger startup errors'
 Invoke-MedicalSaveForm
 Assert-Startup ([Windows.Forms.SaveFileDialog]::Calls -eq 0 -and $script:newChoiceCalls -eq 1 -and -not $script:medicalWorkspaceReady) 'Save Form in an unopened workspace cannot save the old schema and only offers new-form creation'
 Assert-Startup ([Convert]::ToBase64String([IO.File]::ReadAllBytes($script:universalConfigPath)) -ceq $cachedBytes) 'Canceling creation from Save Form preserves the old cached config bytes'
 # Exact v64 automatic branch is retained as a portable negative control.
 function Start-LegacyMedicalFormsWorkspace {
  foreach($button in @($stageInitial,$stageDiary,$stageDischarge)){$button.Enabled=$false}
  [void](Initialize-MedicalTemplateFolder)
  $templates=@(Get-MedicalTemplates)
  $currentPath=Get-UniversalTemplatePath $script:universalConfig
  $prefix=[IO.Path]::GetFullPath($script:medicalTemplatesFolder)+[IO.Path]::DirectorySeparatorChar
  if($templates.Count -gt 0 -and [IO.File]::Exists($currentPath) -and [IO.Path]::GetFullPath($currentPath).StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)){
   Use-MedicalFormSchema $script:universalConfig ([IO.Path]::GetFileNameWithoutExtension($currentPath))
   return
  }
 }
 Set-StartupDirtyState;$script:chooserObserved=$false
 Start-LegacyMedicalFormsWorkspace
 Assert-Startup ($script:medicalWorkspaceReady -and $script:openedStages -eq 1 -and -not $script:chooserObserved) 'Negative control reproduces the v64 automatic opening without a form choice'
 Set-StartupDirtyState
 [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{
  param($dialog)
  Assert-Startup (-not $script:medicalWorkspaceReady -and $script:openedStages -eq 0) 'A second application start again waits for an explicit selection'
  $list=Get-StartupList $dialog;$list.SelectedIndex=[array]::IndexOf([object[]]$list.Items,'Первичный осмотр')
  Assert-Startup ($list.SelectedIndex -ge 0) 'The saved form appears by its readable filename in the chooser'
  (Get-StartupButton $dialog 'Открыть выбранную').RaiseClick()
  Assert-Startup ($dialog.Closed -and $dialog.DialogResult -eq 'OK') 'Actual selected-form callback closes the chooser only after a successful open'
 }
 Start-MedicalFormsWorkspace
 Assert-Startup ($script:medicalWorkspaceReady -and $script:openedStages -eq 1) 'Explicit selection opens exactly one form and enables the workspace'
 Assert-Startup ($script:activeMedicalFormPath -ceq $localPath -and $script:activeMedicalFormName -ceq 'Первичный осмотр') 'Explicit selection binds the exact selected mcform and its readable name'
 Assert-Startup ($stageInitial.Enabled -and $stageDiary.Enabled -and $stageDischarge.Enabled -and $save.Enabled) 'Successful explicit opening enables all stages and document actions'
 Assert-Startup ($script:universalValues.Count -eq 0 -and $script:universalDetails.Count -eq 0 -and $script:stageData.Count -eq 0 -and $script:caseFile -ceq '') 'A selected reusable form begins with empty patient and card state'
 Assert-Startup ($panel.Controls.Count -eq @(Get-UniversalFields $script:universalConfig).Count -and @($panel.Controls | Where-Object {-not [string]::IsNullOrEmpty($_.Text)}).Count -eq 0) 'Rendered fields of an explicitly opened form contain no prior patient answers'
 Assert-Startup ($script:patientNameControl.Text -ceq '' -and $script:patientName -ceq '' -and $script:pendingDocument -eq $null -and $script:diaryIndex -eq 1) 'Opening a reusable form also resets hidden identity, pending exports and diary numbering'
 Assert-Startup ([Windows.Forms.MessageBox]::Messages.Count -eq 0) 'Script-private selected-form helpers execute inside the real closure without scope errors'
 # Sidebar Open Form must also preserve the current patient on cancel or No.
 Set-StartupDirtyState
 $beforeOpenSchema=$script:universalConfig | ConvertTo-Json -Depth 40 -Compress;$beforeOpenConfig=[Convert]::ToBase64String([IO.File]::ReadAllBytes($script:universalConfigPath))
 [Windows.Forms.OpenFileDialog]::Result='Cancel';Invoke-MedicalOpenForm
 Assert-Startup ($script:openedStages -eq 0 -and $script:capturedStages -eq 0 -and $script:activeMedicalFormPath -ceq 'Старая форма.mcform' -and $script:caseFile -ceq 'Старая карта.docx') 'Canceling sidebar Open Form preserves the selected form and current card without capturing or opening a stage'
 Assert-Startup ($script:universalValues.patient_name -ceq 'Старый Пациент' -and $script:universalDetails.history -ceq 'Старое уточнение' -and $script:stageData.diary_1[0] -ceq 'Старый дневник') 'Canceling sidebar Open Form preserves current patient answers, clarifications and diary'
 [Windows.Forms.OpenFileDialog]::Result='OK';[Windows.Forms.OpenFileDialog]::PickedPath=$externalPath;[Windows.Forms.MessageBox]::Result='No';Invoke-MedicalOpenForm
 Assert-Startup ($script:capturedStages -eq 1 -and $script:openedStages -eq 0 -and $script:activeMedicalFormPath -ceq 'Старая форма.mcform' -and $script:caseFile -ceq 'Старая карта.docx') 'Declining the patient-reset confirmation preserves the current form and card'
 Assert-Startup (($script:universalConfig | ConvertTo-Json -Depth 40 -Compress) -ceq $beforeOpenSchema -and [Convert]::ToBase64String([IO.File]::ReadAllBytes($script:universalConfigPath)) -ceq $beforeOpenConfig) 'Declining Open Form preserves the current schema and cached config bytes'
 Assert-Startup ($script:universalValues.patient_name -ceq 'Старый Пациент' -and $script:universalDetails.history -ceq 'Старое уточнение' -and $script:stageData.diary_1[0] -ceq 'Старый дневник') 'Declining Open Form preserves all existing patient state'
 # Errors and nested cancel stay in the chooser, permitting an immediate retry.
 Set-StartupDirtyState
 [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{
  param($dialog)
  $list=Get-StartupList $dialog;$list.SelectedIndex=[array]::IndexOf([object[]]$list.Items,'Поврежденная')
  (Get-StartupButton $dialog 'Открыть выбранную').RaiseClick()
  Assert-Startup (-not $dialog.Closed -and -not $script:medicalWorkspaceReady -and $script:openedStages -eq 0) 'An invalid selected mcform leaves the startup chooser open and the workspace empty'
  Assert-Startup ([Windows.Forms.MessageBox]::Messages.Count -eq 1) 'An invalid selected form produces one useful error before retry'
  [Windows.Forms.OpenFileDialog]::Result='Cancel'
  (Get-StartupButton $dialog 'Выбрать файл…').RaiseClick()
  Assert-Startup (-not $dialog.Closed -and -not $script:medicalWorkspaceReady -and $script:openedStages -eq 0) 'Canceling the nested browse dialog keeps the chooser open without selecting a form'
  Assert-Startup ([Windows.Forms.OpenFileDialog]::CapturedDirectory -ceq $root) 'The startup browse dialog starts beside the program'
  [Windows.Forms.OpenFileDialog]::Result='OK';[Windows.Forms.OpenFileDialog]::PickedPath=$externalPath
  (Get-StartupButton $dialog 'Выбрать файл…').RaiseClick()
  Assert-Startup ($dialog.Closed -and $dialog.DialogResult -eq 'OK') 'A successful browse after invalid selection and cancel closes the same chooser'
 }
 Start-MedicalFormsWorkspace
 Assert-Startup ($script:medicalWorkspaceReady -and $script:openedStages -eq 1 -and $script:activeMedicalFormPath -ceq $externalPath -and $script:activeMedicalFormName -ceq 'Моя особая форма') 'Startup can explicitly open an mcform outside the program folder'
 Assert-Startup ([Windows.Forms.OpenFileDialog]::Calls -eq 2 -and [Windows.Forms.MessageBox]::Messages.Count -eq 1) 'Startup retry succeeds through actual private browse helpers without extra errors'
 # Existing user-selected locations remain available for subsequent save.
 Invoke-MedicalSaveForm
 Assert-Startup ([Windows.Forms.SaveFileDialog]::CapturedDirectory -ceq $outside -and [Windows.Forms.SaveFileDialog]::CapturedName -ceq 'Моя особая форма.mcform') 'Saving an externally opened form starts in its exact chosen directory and filename'
 Assert-Startup ($script:activeMedicalFormPath -ceq $externalPath -and [IO.File]::Exists($externalPath)) 'Repeated save respects the externally opened form path'
 # A program folder without any mcform must still show Create and Browse.
 $holding=Join-Path $temp 'held-local-forms';[void][IO.Directory]::CreateDirectory($holding)
 foreach($path in @($localPath,$secondPath,(Join-Path $root 'Поврежденная.mcform'))){Move-Item -LiteralPath $path -Destination $holding}
 Set-StartupDirtyState
 [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{
  param($dialog)
  $list=Get-StartupList $dialog
  Assert-Startup (-not $list.Enabled -and -not (Get-StartupButton $dialog 'Открыть выбранную').Enabled -and (Get-StartupButton $dialog 'Создать новую форму').Enabled) 'An empty program folder disables the empty local list while keeping creation available'
  (Get-StartupButton $dialog 'Открыть выбранную').RaiseClick()
  Assert-Startup (-not $script:medicalWorkspaceReady -and -not $dialog.Closed) 'An empty local selection cannot accidentally open the cached schema'
  (Get-StartupButton $dialog 'Создать новую форму').RaiseClick()
  Assert-Startup ($script:newChoiceCalls -eq 1 -and $script:newEditorCalls -eq 0 -and -not $dialog.Closed -and -not $script:medicalWorkspaceReady) 'Canceling new-template selection keeps the startup chooser open'
  $script:newChoiceResult=[pscustomobject]@{Schema=$script:fixtureSchema;Name='Моя клиническая форма'}
  (Get-StartupButton $dialog 'Создать новую форму').RaiseClick()
  Assert-Startup ($script:newChoiceCalls -eq 2 -and $script:newEditorCalls -eq 1 -and -not $dialog.Closed -and -not $script:medicalWorkspaceReady) 'Canceling the new-form editor keeps the chooser open without loading a form'
  $script:newEditorResult=[pscustomobject]@{Schema=$script:fixtureSchema}
  (Get-StartupButton $dialog 'Создать новую форму').RaiseClick()
  Assert-Startup ($dialog.Closed -and $dialog.DialogResult -eq 'OK') 'The chooser closes after a newly created form is actually accepted'
 }
 Start-MedicalFormsWorkspace
 Assert-Startup ($script:medicalWorkspaceReady -and $script:openedStages -eq 1 -and $script:activeMedicalFormPath -ceq '' -and $script:activeMedicalFormName -ceq 'Моя клиническая форма') 'Explicit creation activates one new named form without inventing an mcform path'
 Assert-Startup ([Windows.Forms.MessageBox]::Messages.Count -eq 0) 'Create and canceled-create callbacks resolve script-private application helpers without scope errors'
 foreach($path in Get-ChildItem -LiteralPath $holding -File){Move-Item -LiteralPath $path.FullName -Destination $root}
 # The real Save handler writes a portable schema and Word snapshot by default.
 $script:universalValues.patient_name='НЕ ВКЛЮЧАТЬ ПАЦИЕНТА';$script:universalDetails.history='НЕ ВКЛЮЧАТЬ УТОЧНЕНИЕ';$script:stageData.diary_1=@('НЕ ВКЛЮЧАТЬ ДНЕВНИК');$script:caseFile=Join-Path $outside 'Карта пациента.docx'
 [IO.File]::WriteAllText($script:caseFile,'Не менять карту пациента');$cardBytes=[Convert]::ToBase64String([IO.File]::ReadAllBytes($script:caseFile))
 Invoke-MedicalSaveForm
 $newPath=Join-Path $root 'Моя клиническая форма.mcform'
 Assert-Startup ([Windows.Forms.SaveFileDialog]::CapturedDirectory -ceq $root -and [Windows.Forms.SaveFileDialog]::CapturedName -ceq 'Моя клиническая форма.mcform') 'The first save of a newly created form defaults to the program folder and friendly name'
 Assert-Startup ([IO.File]::Exists($newPath) -and $script:activeMedicalFormPath -ceq $newPath -and $script:activeMedicalFormName -ceq 'Моя клиническая форма') 'Saving the newly created form commits its real mcform path and display name'
 $saved=Read-MedicalForm $newPath;$savedText=[IO.File]::ReadAllText($newPath)
 Assert-Startup ($saved.Name -ceq 'Моя клиническая форма' -and $saved.Schema.Sections.Count -eq $script:universalConfig.Sections.Count -and -not [string]::IsNullOrWhiteSpace($saved.TemplateBase64)) 'The saved form includes its complete schema and associated Word snapshot'
 Assert-Startup (-not $savedText.Contains('НЕ ВКЛЮЧАТЬ') -and -not $savedText.Contains('Карта пациента.docx') -and $saved.PSObject.Properties.Name -notcontains 'Values') 'The saved mcform excludes patient answers, clarifications, stages and card bindings'
 Assert-Startup ($script:universalValues.patient_name -ceq 'НЕ ВКЛЮЧАТЬ ПАЦИЕНТА' -and $script:universalDetails.history -ceq 'НЕ ВКЛЮЧАТЬ УТОЧНЕНИЕ' -and $script:stageData.diary_1[0] -ceq 'НЕ ВКЛЮЧАТЬ ДНЕВНИК') 'Saving a reusable form preserves the currently entered patient state in memory'
 Assert-Startup ([Convert]::ToBase64String([IO.File]::ReadAllBytes($script:caseFile)) -ceq $cardBytes) 'Saving a reusable form preserves the patient card bytes'
 $savedFormBytes=[Convert]::ToBase64String([IO.File]::ReadAllBytes($newPath));$savedConfigBytes=[Convert]::ToBase64String([IO.File]::ReadAllBytes($script:universalConfigPath));$savedBaseline=$script:medicalFormBaseline
 $script:universalConfig.Sections[0].Title='Изменения пока без сохранения';[Windows.Forms.SaveFileDialog]::Result='Cancel';Invoke-MedicalSaveForm
 Assert-Startup ($script:activeMedicalFormPath -ceq $newPath -and $script:activeMedicalFormName -ceq 'Моя клиническая форма' -and $script:medicalFormBaseline -ceq $savedBaseline) 'Canceling Save Form preserves the previous path, display name and saved baseline'
 Assert-Startup ([Convert]::ToBase64String([IO.File]::ReadAllBytes($newPath)) -ceq $savedFormBytes -and [Convert]::ToBase64String([IO.File]::ReadAllBytes($script:universalConfigPath)) -ceq $savedConfigBytes) 'Canceling Save Form preserves the saved form and cached config bytes'
 Assert-Startup ($script:universalConfig.Sections[0].Title -ceq 'Изменения пока без сохранения' -and [Convert]::ToBase64String([IO.File]::ReadAllBytes($script:caseFile)) -ceq $cardBytes) 'Canceling Save Form retains unsaved structure changes and preserves the patient card'
 [Windows.Forms.SaveFileDialog]::Result='OK';[Windows.Forms.SaveFileDialog]::PickedPath=Join-Path $root 'Недопустимый файл.txt';Invoke-MedicalSaveForm
 Assert-Startup (-not [IO.File]::Exists([Windows.Forms.SaveFileDialog]::PickedPath) -and $script:activeMedicalFormPath -ceq $newPath -and $script:medicalFormBaseline -ceq $savedBaseline) 'A wrong form extension is rejected before path or baseline mutation'
 [Windows.Forms.SaveFileDialog]::PickedPath=Join-Path $temp 'missing/save.mcform';Invoke-MedicalSaveForm
 Assert-Startup ($script:activeMedicalFormPath -ceq $newPath -and $script:medicalFormBaseline -ceq $savedBaseline -and [Convert]::ToBase64String([IO.File]::ReadAllBytes($newPath)) -ceq $savedFormBytes) 'A failed form write preserves the old path, baseline and saved file bytes'
 [Windows.Forms.SaveFileDialog]::PickedPath='';$script:activeMedicalFormPath='';$script:activeMedicalFormName='01-b92192ba816b-9dff67722061-0ea467e5a8f9-3c129c65f0fc-6e85b5f77cc7-776ba4abfd46-d509696d6f1b-020b7a3a752e-3cf22a1012ea-9e647c1a2b89-47ad6c683aab-2079d42d11f4-14fbebbe3beb-2bffe353c11c-c11c1dd5ed75';Invoke-MedicalSaveForm
 Assert-Startup ([Windows.Forms.SaveFileDialog]::CapturedDirectory -ceq $root -and [Windows.Forms.SaveFileDialog]::CapturedName -ceq '01.mcform') 'The screenshot hash chain is removed from Save Form while its original 01 filename is preserved'
 Assert-Startup ($script:activeMedicalFormName -ceq '01' -and $script:activeMedicalFormPath -ceq (Join-Path $root '01.mcform')) 'Saving a legacy technical-name form commits its readable original name beside the program'
 $script:activeMedicalFormPath='';$script:activeMedicalFormName='d853ae38-8c9e-4a51-b708-84075f87b763';Invoke-MedicalSaveForm
 Assert-Startup ([Windows.Forms.SaveFileDialog]::CapturedName -ceq 'Новая форма.mcform' -and $script:activeMedicalFormName -ceq 'Новая форма') 'An entirely technical GUID name uses the readable New Form fallback on save'
 # Constructor startup initialization must not read old settings, even invalid.
 [IO.File]::WriteAllText($script:universalConfigPath,'broken cached settings',[Text.UTF8Encoding]::new($true))
 $tokens=$null;$parseErrors=$null;$constructor=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'constructor.ps1'),[ref]$tokens,[ref]$parseErrors)
 Assert-Startup ($parseErrors.Count -eq 0) 'The production constructor parses after changing startup initialization'
 $initializers=@($constructor.EndBlock.Statements | Where-Object {$_ -is [Management.Automation.Language.AssignmentStatementAst] -and $_.Left.Extent.Text -ceq '$script:universalConfig'})
 Assert-Startup ($initializers.Count -eq 1) 'The constructor has one explicit initial schema assignment before the first window'
 . ([scriptblock]::Create($initializers[0].Extent.Text))
 Assert-Startup ($script:universalConfig.AutoTemplate -eq $true -and $script:universalConfig.Sections[0].Title -ceq 'Сведения о пациенте') 'The actual initial assignment uses a fresh schema instead of reading a corrupt cached file'
 Set-StartupDirtyState
 [Windows.Forms.Form]::Plan=[Action[Windows.Forms.Form]]{param($dialog)$dialog.DialogResult='Cancel'}
 Start-MedicalFormsWorkspace
 Assert-Startup (-not $script:medicalWorkspaceReady -and $script:openedStages -eq 0 -and [Windows.Forms.MessageBox]::Messages.Count -eq 0) 'A corrupt cached config still reaches the explicit chooser and allows clean cancel'
 Assert-Startup ([IO.File]::ReadAllText($script:universalConfigPath) -ceq 'broken cached settings') 'Startup never rewrites even a corrupt cached file without explicit form selection'
 Assert-Startup (@(Get-ChildItem -LiteralPath $root -Recurse -File | Where-Object {$_.Extension -ceq '.tmp'}).Count -eq 0) 'Startup and Save Form clean all temporary files after success, cancel and failure'
 foreach($line in $script:startupPassLog){Write-Output $line}
 Write-Output ('CHECKS '+$script:checks)
}finally{[Windows.Forms.Form]::Plan=$null;Remove-Item -LiteralPath $temp -Recurse -Force}
