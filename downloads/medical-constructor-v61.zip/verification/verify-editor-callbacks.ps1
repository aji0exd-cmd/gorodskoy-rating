﻿param(
 [string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v61'),
 [string]$LegacyProject=(Join-Path (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) 'medical-constructor-v59/Медицинский конструктор v59')
)
$ErrorActionPreference='Stop'
# This harness deliberately keeps application helpers private to a child .ps1.
# Promoting extracted functions to the parent script/global scope would hide v59's bug.
function Get-CallbackSpec([string]$path,[bool]$legacyOnly=$false){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors | Out-String)}
 $editor=$ast.Find({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Show-MedicalFormTemplateEditor'},$false)
 $assignments=@{}
 foreach($name in $(if($legacyOnly){@('commitParagraph')}else{@('commitProperties','commitParagraph','updateAvailability','pasteParagraphText','loadProperties','loadParagraph','refreshParagraphs','refreshParts')})){
  $nodes=@($editor.FindAll({param($node) $node -is [Management.Automation.Language.AssignmentStatementAst] -and $node.Left -is [Management.Automation.Language.VariableExpressionAst] -and $node.Left.VariablePath.UserPath -eq $name},$true))
  if($nodes.Count -ne 1){throw ('Expected one production assignment: '+$name)}
  $assignments[$name]=$nodes[0].Extent.Text
 }
 $handlers=@{}
 foreach($item in $(if($legacyOnly){@()}else{@(@('addField','Add_Click'),@('insertField','Add_Click'),@('insertDetail','Add_Click'),@('addParagraph','Add_Click'),@('buildTemplate','Add_Click'),@('save','Add_Click'),@('paragraphList','Add_SelectedIndexChanged'),@('detailEnable','Add_Click'),@('pasteText','Add_Click'),@('deleteParagraph','Add_Click'),@('fieldType','Add_SelectedIndexChanged'),@('detailWord','Add_SelectedIndexChanged'))})){
  $control=$item[0];$event=$item[1]
  $nodes=@($editor.FindAll({param($node) $node -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $node.Expression -is [Management.Automation.Language.VariableExpressionAst] -and $node.Expression.VariablePath.UserPath -eq $control -and $node.Member.Value -eq $event},$true))
  if($nodes.Count -ne 1){throw ('Expected one production handler: '+$control)}
  $handlers[$control]=$nodes[0].Arguments[0].Extent.Text
 }
 $binding=$editor.Find({param($node) $node -is [Management.Automation.Language.AssignmentStatementAst] -and $node.Left -is [Management.Automation.Language.VariableExpressionAst] -and $node.Left.VariablePath.UserPath -eq 'editorCommands'},$true)
 $bindings=''
 if($binding){
  $first=$editor.Find({param($node) $node -is [Management.Automation.Language.AssignmentStatementAst] -and $node.Left -is [Management.Automation.Language.VariableExpressionAst] -and $node.Left.VariablePath.UserPath -eq 'commitProperties'},$true)
  $source=[IO.File]::ReadAllText($path);$bindings=$source.Substring($binding.Extent.StartOffset,$first.Extent.StartOffset-$binding.Extent.StartOffset)
 }
 return [pscustomobject]@{Assignments=$assignments;Handlers=$handlers;Bindings=$bindings}
}
$spec=Get-CallbackSpec (Join-Path $Project 'template-editor-v59.ps1')
if([IO.File]::Exists((Join-Path $LegacyProject 'template-editor-v59.ps1'))){$legacy=Get-CallbackSpec (Join-Path $LegacyProject 'template-editor-v59.ps1') $true}
else{
 # Exact v59 callback retained so a downloaded v60 test archive remains standalone.
 $legacy=[pscustomobject]@{Assignments=@{commitParagraph='$commitParagraph={if($state.Paragraph -and -not $state.Loading){Set-MedicalTemplateParagraph $state.Model $state.Paragraph.Id $paragraphText.Text}}.GetNewClosure()'};Handlers=@{};Bindings=''}
}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-callback-test-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
$child=Join-Path $temp 'private-application-scope.ps1'
$childSource=@'
param([string]$Project,[string]$TestRoot,$Spec,$Legacy)
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Callback([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @"
using System;
using System.Collections;
public sealed class MedicalCallbackWidget {
 public string Text {get;set;}
 private string lastInsertedText="";
 public int SelectionStart {get;set;}
 public int SelectionLength {get;set;}
 public string SelectedText {get {return lastInsertedText;} set {
  string insert=value ?? "";int start=Math.Max(0,Math.Min(SelectionStart,Text.Length));int count=Math.Max(0,Math.Min(SelectionLength,Text.Length-start));
  Text=Text.Substring(0,start)+insert+Text.Substring(start+count);SelectionStart=start+insert.Length;SelectionLength=0;lastInsertedText=insert;
 }}
 public bool Enabled {get;set;}
 public bool Visible {get;set;}
 public bool Checked {get;set;}
 public bool ReadOnly {get;set;}
 public bool Closed {get;private set;}
 public string DialogResult {get;set;}
 public int SelectedIndex {get;set;}
 public ArrayList Items {get;private set;}
 public MedicalCallbackWidget(){Text="";SelectedText="";Enabled=true;DialogResult="";SelectedIndex=-1;Items=new ArrayList();}
 public string[] Lines {get {return Text.Split(new string[] {"\r\n","\n","\r"},StringSplitOptions.None);}}
 public object SelectedItem {get {return SelectedIndex >= 0 && SelectedIndex < Items.Count ? Items[SelectedIndex] : null;}}
 public event EventHandler SelectedIndexChanged;
 public event EventHandler Click;
 public void RaiseClick(){if(Click!=null)Click(this,EventArgs.Empty);}
 public void RaiseSelectedIndexChanged(){if(SelectedIndexChanged!=null)SelectedIndexChanged(this,EventArgs.Empty);}
 public void BeginUpdate(){}
 public void EndUpdate(){}
 public bool Focus(){return true;}
 public void Close(){Closed=true;}
}
namespace Windows.Forms {
 public static class MessageBox {public static string Response="Yes";public static string Show(params object[] args){return Response;}}
 public enum TextDataFormat {Text,UnicodeText,Rtf,Html,CommaSeparatedValue}
 public static class Clipboard {
  public static string Text="";public static int ReadCount=0;
  public static bool ContainsText(){return !String.IsNullOrEmpty(Text);}
  public static bool ContainsText(TextDataFormat format){return !String.IsNullOrEmpty(Text);}
  public static string GetText(){ReadCount++;return Text;}
  public static string GetText(TextDataFormat format){ReadCount++;return Text;}
 }
}
"@
# Get-XmlPart is the only dependency in constructor.ps1; do not execute its GUI.
$tokens=$null;$errors=$null;$constructor=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'constructor.ps1'),[ref]$tokens,[ref]$errors)
$getXml=$constructor.Find({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Get-XmlPart'},$false)
. ([scriptblock]::Create($getXml.Extent.Text))
# These are genuine dot-sourced application files in this CHILD SCRIPT scope.
. (Join-Path $Project 'universal.ps1')
. (Join-Path $Project 'forms-v59.ps1')
. (Join-Path $Project 'template-editor-v59.ps1')
. (Join-Path $Project 'template-editor-operations-v61.ps1')
$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
$script:medicalProgramRoot=Join-Path $TestRoot 'program'
$script:medicalTemplatesFolder=Join-Path $script:medicalProgramRoot 'Шаблоны'
[void][IO.Directory]::CreateDirectory($script:medicalProgramRoot)
Assert-Callback (-not (Get-Item Function:global:Set-MedicalTemplateParagraph -ErrorAction SilentlyContinue)) 'Application paragraph helper stays out of global scope'
$config=[pscustomobject]@{Version=49;AutoTemplate=$false;Template='';Sections=@([pscustomobject]@{Id='test';Title='Раздел';Fields=@((New-UniversalField 'text' 'Текст' 'TEXT' 'text'),(New-UniversalField 'choice' 'Выбор' 'CHOICE' 'choice_detail'))})}
$detail=$config.Sections[0].Fields[1];$detail.Options=@('Да','Нет')
$detail | Add-Member -NotePropertyName DetailFormPosition -NotePropertyValue 'right'
$detail | Add-Member -NotePropertyName DetailWordPosition -NotePropertyValue 'marker'
$detail | Add-Member -NotePropertyName DetailMarker -NotePropertyValue 'CHOICE_DETAIL'
$source=Join-Path $script:medicalProgramRoot 'original.docx';$config.Template=$source
New-UniversalTemplate $source $config
$sourceHash=Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($source))
function New-TestCallbacks($callbackSpec,$schema,$model,[bool]$legacyOnly=$false){
 $state=@{Schema=$schema;Model=$model;Selected=[pscustomobject]@{Kind='field';Section=$schema.Sections[0];Field=$schema.Sections[0].Fields[1]};Paragraph=$model.Paragraphs[0];Loading=$false;Result=$null;VisibleParagraphs=@()}
 $testState=@{LastError=$null;TreeRefreshCount=0}
 $widgets=@{}
 foreach($name in @('fieldName','fieldMarker','fieldType','fieldOptions','fieldRequired','fieldRole','fieldWordId','detailTab','detailStatus','detailEnable','detailForm','detailWord','detailMarker','paragraphText','paragraphTitle','paragraphList','partCombo','hint','insertField','insertDetail','insertDate','pasteText','deleteParagraph','addParagraph','templateName','dialog')){
  $widget=New-Object MedicalCallbackWidget;$widgets[$name]=$widget;Set-Variable -Name $name -Value $widget
 }
 $partCombo.SelectedIndex=0;$templateName.Text='edited.docx';$typeIds=@('text','multiline','choice','choice_detail','heading','multi','repeat');$roleIds=@('','name','birth','address')
 $showError={param($record)$testState.LastError=$record}.GetNewClosure()
 $refreshTree={param($selectedId)$testState.TreeRefreshCount++}.GetNewClosure()
 if($legacyOnly){Invoke-Expression $callbackSpec.Assignments.commitParagraph;return [pscustomobject]@{State=$state;Widgets=$widgets;CommitParagraph=$commitParagraph;Errors=$testState}}
 # Execute exactly the production command-binding statements and callback bodies.
 Invoke-Expression $callbackSpec.Bindings
 foreach($name in $(if($legacyOnly){@('commitParagraph')}else{@('commitProperties','commitParagraph','updateAvailability','pasteParagraphText','loadProperties','loadParagraph','refreshParagraphs','refreshParts')})){Invoke-Expression $callbackSpec.Assignments[$name]}
 $handlers=@{}
 foreach($entry in $callbackSpec.Handlers.GetEnumerator()){$handlers[$entry.Key]=Invoke-Expression $entry.Value}
 $paragraphList.Add_SelectedIndexChanged($handlers.paragraphList)
 $fieldType.Add_SelectedIndexChanged($handlers.fieldType);$detailWord.Add_SelectedIndexChanged($handlers.detailWord)
 $detailEnable.Add_Click($handlers.detailEnable);$pasteText.Add_Click($handlers.pasteText);$deleteParagraph.Add_Click($handlers.deleteParagraph)
 return [pscustomobject]@{State=$state;Widgets=$widgets;Commands=$editorCommands;CommitProperties=$commitProperties;CommitParagraph=$commitParagraph;LoadProperties=$loadProperties;LoadParagraph=$loadParagraph;UpdateAvailability=$updateAvailability;RefreshParagraphs=$refreshParagraphs;RefreshParts=$refreshParts;Handlers=$handlers;Errors=$testState}
}
$old=New-TestCallbacks $Legacy (Copy-MedicalFormSchema $config) (Read-MedicalTemplateModel $source) $true
$old.Widgets.paragraphText.Text='Legacy edited paragraph'
$oldError=$null;try{& $old.CommitParagraph}catch{$oldError=$_}
Assert-Callback ($null -ne $oldError -and $oldError.Exception -is [Management.Automation.CommandNotFoundException] -and $oldError.Exception.Message.Contains('Set-MedicalTemplateParagraph')) 'Actual v59 closure reproduces missing Set-MedicalTemplateParagraph'
Assert-Callback ($old.State.Model.Paragraphs[0].Text -ne 'Legacy edited paragraph') 'Failed legacy callback cannot commit the paragraph'
$plain=New-TestCallbacks $Spec (Copy-MedicalFormSchema $config) (Read-MedicalTemplateModel $source)
$plain.State.Selected=[pscustomobject]@{Kind='field';Section=$plain.State.Schema.Sections[0];Field=$plain.State.Schema.Sections[0].Fields[0]}
& $plain.LoadProperties
Assert-Callback ($plain.Widgets.detailTab.Enabled -and $plain.Widgets.detailStatus.Text.Length -gt 0) 'Clarification tab remains accessible and explains a plain text field'
Assert-Callback ($plain.Widgets.detailEnable.Enabled -and -not $plain.Widgets.detailForm.Enabled -and -not $plain.Widgets.detailWord.Enabled) 'Plain text field offers clarification conversion while its settings are inactive'
Assert-Callback (-not $plain.Widgets.fieldOptions.Enabled) 'Plain text field does not show an active option editor'
$plain.Widgets.detailEnable.RaiseClick()
Assert-Callback ($null -eq $plain.Errors.LastError -and $plain.State.Selected.Field.Type -eq 'choice_detail' -and $plain.Widgets.fieldType.SelectedIndex -eq 3) 'Native enable-clarification event converts the selected text field'
Assert-Callback ($plain.Widgets.detailForm.Enabled -and $plain.Widgets.detailWord.Enabled -and $plain.Widgets.fieldOptions.Enabled) 'Converted clarification field enables its placement and options controls immediately'
Assert-Callback (-not $plain.Widgets.detailMarker.Enabled -and -not $plain.Widgets.insertDetail.Enabled) 'Separate clarification marker stays inactive while Word appends the detail'
$plain.Widgets.detailWord.SelectedIndex=3;$plain.Widgets.detailWord.RaiseSelectedIndexChanged()
Assert-Callback ($plain.Widgets.detailMarker.Enabled -and $plain.Widgets.insertDetail.Enabled) 'Native Word-placement event immediately enables the separate clarification marker'
$plain.Widgets.detailForm.SelectedIndex=1;$plain.Widgets.detailMarker.Text='text_detail'
& $plain.CommitProperties
Assert-Callback ($plain.State.Selected.Field.DetailFormPosition -eq 'above' -and $plain.State.Selected.Field.DetailWordPosition -eq 'marker' -and $plain.State.Selected.Field.DetailMarker -eq 'TEXT_DETAIL') 'Converted field commits form placement, Word placement and normalized detail marker'
$plain.Widgets.fieldType.SelectedIndex=0;$plain.Widgets.fieldType.RaiseSelectedIndexChanged()
Assert-Callback ($plain.Widgets.detailTab.Enabled -and $plain.Widgets.detailEnable.Enabled -and -not $plain.Widgets.detailForm.Enabled -and -not $plain.Widgets.insertDetail.Enabled) 'Native type-change event updates clarification controls without hiding their tab'
$plain.State.Selected=[pscustomobject]@{Kind='section';Section=$plain.State.Schema.Sections[0];Field=$null}
& $plain.LoadProperties
Assert-Callback ($plain.Widgets.detailTab.Enabled -and -not $plain.Widgets.detailEnable.Enabled -and -not $plain.Widgets.detailForm.Enabled -and $plain.Widgets.detailStatus.Text.Length -gt 0) 'Section selection keeps a readable clarification explanation without enabling field controls'
$plain.State.Selected=$null;& $plain.LoadProperties
Assert-Callback ($plain.Widgets.detailTab.Enabled -and -not $plain.Widgets.detailEnable.Enabled -and -not $plain.Widgets.insertField.Enabled) 'No form selection does not expose field or clarification insertion'
$current=New-TestCallbacks $Spec (Copy-MedicalFormSchema $config) (Read-MedicalTemplateModel $source)
Assert-Callback ($current.Commands.Count -eq 11) 'Production binding captures all eleven helper commands'
foreach($command in $current.Commands.Values){Assert-Callback ($command -is [Management.Automation.FunctionInfo]) ('Private function captured as a command object: '+$command.Name)}
& $current.LoadProperties
Assert-Callback ($current.Widgets.fieldName.Text -eq 'Выбор' -and $current.Widgets.fieldType.SelectedIndex -eq 3) 'Loading field properties resolves private application helpers'
Assert-Callback ($current.Widgets.fieldRequired.Checked -and $current.Widgets.detailForm.SelectedIndex -eq 2 -and $current.Widgets.detailWord.SelectedIndex -eq 3) 'Required and clarification settings load through all three helpers'
& $current.RefreshParts
Assert-Callback ($current.Widgets.paragraphList.Items[0] -is [string] -and $current.State.VisibleParagraphs.Count -eq $current.Widgets.paragraphList.Items.Count) 'Native list uses display strings with a separate paragraph index mapping'
Assert-Callback ($current.State.Paragraph -and -not $current.Widgets.paragraphText.ReadOnly -and $current.Widgets.paragraphText.Text.Length -gt 0 -and $current.Widgets.paragraphTitle.Text.Length -gt 0) 'Initial paragraph selection loads visible editable text and its caption'
$firstId=$current.State.Paragraph.Id;$originalFirst=$current.State.Paragraph.Text
$current.Widgets.paragraphText.Text=$originalFirst+' edited by event'
$current.Widgets.paragraphList.SelectedIndex=1
# C# raises the real PowerShell delegate; this is not a direct & handler call.
$current.Widgets.paragraphList.RaiseSelectedIndexChanged()
Assert-Callback ($null -eq $current.Errors.LastError) 'Native .NET event dispatch resolves the private paragraph helper'
Assert-Callback ((@($current.State.Model.Paragraphs | Where-Object {$_.Id -ceq $firstId})[0]).Text -eq ($originalFirst+' edited by event')) 'Switching paragraphs commits the previous paragraph through the real callback'
Assert-Callback ($current.State.Paragraph.Id -ne $firstId -and $current.Widgets.paragraphText.Text -eq $current.State.Paragraph.Text) 'Switching paragraphs loads the newly selected text'
& $current.Handlers.insertDetail
Assert-Callback ($null -eq $current.Errors.LastError -and $current.Widgets.paragraphText.SelectedText -eq '{{CHOICE_DETAIL}}') 'Clarification-marker callback invokes its private helper'
& $current.Handlers.insertField
Assert-Callback ($current.Widgets.paragraphText.SelectedText -eq '{{CHOICE}}') 'Field-marker callback uses the selected field'
$count=$current.State.Model.Paragraphs.Count
& $current.Handlers.addParagraph
Assert-Callback ($null -eq $current.Errors.LastError -and $current.State.Model.Paragraphs.Count -eq $count+1) 'Add-paragraph callback reaches nested XML helpers'
Assert-Callback ($current.State.Paragraph.Id -eq $current.State.VisibleParagraphs[$current.Widgets.paragraphList.SelectedIndex].Id -and -not $current.Widgets.paragraphText.ReadOnly) 'New paragraph is selected through its mapped list index and can accept text'
$current.Widgets.paragraphText.Text='before after';$current.Widgets.paragraphText.SelectionStart=6;$current.Widgets.paragraphText.SelectionLength=0
[Windows.Forms.Clipboard]::Text="вставка`r`nстрока";$reads=[Windows.Forms.Clipboard]::ReadCount
$current.Widgets.pasteText.RaiseClick()
Assert-Callback ($null -eq $current.Errors.LastError -and $current.Widgets.paragraphText.Text -eq "beforeвставка`r`nстрока after" -and [Windows.Forms.Clipboard]::ReadCount -eq $reads+1) 'Native paste event inserts Unicode multiline text at the cursor'
$current.Widgets.paragraphText.SelectionStart=0;$current.Widgets.paragraphText.SelectionLength=6;[Windows.Forms.Clipboard]::Text='замена '
$current.Widgets.pasteText.RaiseClick()
Assert-Callback ($current.Widgets.paragraphText.Text -eq "замена вставка`r`nстрока after") 'Paste replaces the selected text while preserving text on either side'
[Windows.Forms.Clipboard]::Text='';$beforePaste=$current.Widgets.paragraphText.Text;$reads=[Windows.Forms.Clipboard]::ReadCount
$current.Widgets.pasteText.RaiseClick()
Assert-Callback ($current.Widgets.paragraphText.Text -ceq $beforePaste -and [Windows.Forms.Clipboard]::ReadCount -eq $reads) 'Empty clipboard leaves paragraph text unchanged'
$current.Errors.LastError=$null
# The same mutable paragraph record drives selection, availability and the callback guard.
& $current.CommitParagraph
$current.State.Paragraph.Editable=$false;& $current.LoadParagraph
Assert-Callback ($current.Widgets.paragraphText.ReadOnly -and -not $current.Widgets.pasteText.Enabled -and -not $current.Widgets.deleteParagraph.Enabled) 'Read-only paragraph disables text mutation and deletion controls'
[Windows.Forms.Clipboard]::Text='blocked';$countBefore=$current.State.Model.Paragraphs.Count
$current.Widgets.pasteText.RaiseClick();$current.Widgets.deleteParagraph.RaiseClick()
Assert-Callback ($null -eq $current.Errors.LastError -and $current.Widgets.paragraphText.Text -ceq $beforePaste -and [Windows.Forms.Clipboard]::ReadCount -eq $reads -and $current.State.Model.Paragraphs.Count -eq $countBefore) 'Read-only callback guards reject paste and deletion even when events are raised programmatically'
$current.State.Paragraph.Editable=$true;& $current.LoadParagraph
$current.Widgets.paragraphText.Text="Сохранить до удаления`r`nВторая строка";[Windows.Forms.MessageBox]::Response='No'
$current.Widgets.deleteParagraph.RaiseClick()
Assert-Callback ($current.State.Model.Paragraphs.Count -eq $countBefore -and $current.State.Paragraph.Text -eq "Сохранить до удаления`r`nВторая строка") 'Cancel deletion retains the paragraph and commits its edited text'
[Windows.Forms.MessageBox]::Response='Yes';$removedNode=$current.State.Paragraph.Node
$current.Widgets.deleteParagraph.RaiseClick()
Assert-Callback ($null -eq $current.Errors.LastError -and $current.State.Model.Paragraphs.Count -eq $countBefore-1 -and $null -eq $removedNode.ParentNode) 'Confirmed native delete event removes the selected editable XML paragraph'
Assert-Callback ($current.State.Paragraph -and $current.State.Paragraph.Id -eq $current.State.VisibleParagraphs[$current.Widgets.paragraphList.SelectedIndex].Id -and $current.Widgets.paragraphText.Text -ceq $current.State.Paragraph.Text) 'Deleting a paragraph reloads the remaining mapped selection and its text'
$current.State.Paragraph=$null;& $current.UpdateAvailability;$noSelectionText=$current.Widgets.paragraphText.Text;$countBefore=$current.State.Model.Paragraphs.Count
$current.Widgets.pasteText.RaiseClick();$current.Widgets.deleteParagraph.RaiseClick()
Assert-Callback (-not $current.Widgets.pasteText.Enabled -and -not $current.Widgets.deleteParagraph.Enabled -and $current.Widgets.paragraphText.Text -ceq $noSelectionText -and $current.State.Model.Paragraphs.Count -eq $countBefore -and [Windows.Forms.Clipboard]::ReadCount -eq $reads) 'No paragraph selection cannot paste text or delete a paragraph'
& $current.LoadParagraph

$fieldCount=$current.State.Schema.Sections[0].Fields.Count
& $current.Handlers.addField
Assert-Callback ($null -eq $current.Errors.LastError -and $current.State.Schema.Sections[0].Fields.Count -eq $fieldCount+1) 'Add-field callback resolves New-UniversalField'
Assert-Callback ($current.Errors.TreeRefreshCount -eq 1) 'Add-field callback refreshes the form after inserting its field'
& $current.Handlers.buildTemplate
Assert-Callback ($null -eq $current.Errors.LastError -and $current.Widgets.templateName.Text -eq 'Мой шаблон.docx') 'Build-template callback validates, generates and reloads through three private helpers'
Assert-Callback ((@($current.State.Model.Paragraphs | Where-Object {$_.Text -like '*{{FIELD_*}}*'})).Count -eq 1) 'Generated Word template includes the field created by its callback'
$current.Widgets.templateName.Text='saved-from-callback.docx'
$current.Widgets.paragraphText.Text=$current.State.Paragraph.Text+' saved edit'
& $current.Handlers.save
Assert-Callback ($null -eq $current.Errors.LastError -and $null -ne $current.State.Result) 'Apply callback completes real Word-template validation and atomic save'
Assert-Callback ($current.Widgets.dialog.Closed -and $current.Widgets.dialog.DialogResult -eq 'OK') 'Apply callback closes its editor only after a successful save'
$saved=$current.State.Result.Template.Path
Assert-Callback ($saved.StartsWith($script:medicalTemplatesFolder) -and [IO.File]::Exists($saved)) 'Save callback retains original script-root template folder'
$roundTrip=Read-MedicalTemplateModel $saved
Assert-Callback ((@($roundTrip.Paragraphs | Where-Object {$_.Text -like '* saved edit'})).Count -eq 1) 'Edited paragraph survives saving and reloading the actual DOCX'
Assert-MedicalEditorTemplateCoverage $current.State.Result.Schema $roundTrip
Assert-Callback $true 'Saved callback result retains every form and clarification marker'
Assert-Callback ((Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($source))) -ceq $sourceHash) 'All callbacks preserve the original Word template'
Assert-Callback (-not (Get-Item Function:global:Set-MedicalTemplateParagraph -ErrorAction SilentlyContinue)) 'Regression fix does not promote application helpers globally'
Write-Output ('Callback regression checks passed: '+$script:checks)
'@
try{
 [IO.File]::WriteAllText($child,($childSource -replace '\r?\n',"`r`n"),[Text.UTF8Encoding]::new($true))
 & $child -Project $Project -TestRoot $temp -Spec $spec -Legacy $legacy
 if(Get-Command Set-MedicalTemplateParagraph -ErrorAction SilentlyContinue){throw 'Child application scope leaked into the verification script.'}
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
