﻿# Local patient catalog and on-demand document search. No network calls.
$script:dbFile=Join-Path $env:LOCALAPPDATA 'MedicalConstructor\patients.json'
$script:patients=@()
$script:patientsLoadFailed=$false
function Load-Patients {
 $script:patients=@();$script:patientsLoadFailed=$false
 if(Test-Path $script:dbFile){try {$raw=Get-Content -LiteralPath $script:dbFile -Raw -Encoding UTF8; $data=ConvertFrom-Json -InputObject $raw; if($data){$script:patients=@($data)}}catch{$script:patientsLoadFailed=$true;[System.Windows.Forms.MessageBox]::Show('Ошибка чтения базы: '+$_.Exception.Message) | Out-Null}}
}
function Save-Patients {
 if($script:patientsLoadFailed){throw 'База пациентов не была прочитана. Сохранение остановлено, чтобы не перезаписать повреждённый файл. Проверьте patients.json и patients.json.bak.'}
 $dir=Split-Path $script:dbFile -Parent
 [void][IO.Directory]::CreateDirectory($dir)
 $json=ConvertTo-Json -InputObject @($script:patients) -Depth 8
 $temp=$script:dbFile+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
 try{
  [IO.File]::WriteAllText($temp,$json,[Text.UTF8Encoding]::new($true))
  if(Test-Path -LiteralPath $script:dbFile){[IO.File]::Replace($temp,$script:dbFile,($script:dbFile+'.bak'))}
  else{[IO.File]::Move($temp,$script:dbFile)}
 }finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force}}
}
function Invoke-PatientChange([scriptblock]$change){
 $snapshot=ConvertTo-Json -InputObject @($script:patients) -Depth 8
 try{
  if($script:patientsLoadFailed){throw 'База пациентов не прочитана. Исправьте или восстановите её перед изменениями.'}
  & $change
  Save-Patients
  return $true
 }catch{
  $script:patients=@(ConvertFrom-Json -InputObject $snapshot)
  [void][Windows.Forms.MessageBox]::Show('Изменения не сохранены: '+$_.Exception.Message,'База пациентов')
  return $false
 }
}
function Get-DocText([string]$path){
 $z=$null
 try {
  $z=[System.IO.Compression.ZipFile]::OpenRead($path)
  $parts=@($z.Entries | Where-Object { $_.FullName -match '^word/(document|header[0-9]*|footer[0-9]*)\.xml$' })
  $sb=New-Object System.Text.StringBuilder
  foreach($part in $parts){$reader=[System.IO.StreamReader]::new($part.Open());try{$xml=[xml]$reader.ReadToEnd()}finally{$reader.Dispose()};$ns=[System.Xml.XmlNamespaceManager]::new($xml.NameTable);$ns.AddNamespace('w','http://schemas.openxmlformats.org/wordprocessingml/2006/main');foreach($node in $xml.SelectNodes('//w:t',$ns)){[void]$sb.Append($node.InnerText)}}
  return $sb.ToString()
 }catch{return ''}finally{if($z){$z.Dispose()}}
}
function Show-Patients {
 Load-Patients
 $pf=New-Object System.Windows.Forms.Form;$pf.Text='Пациенты и документы — v61';$pf.Size=New-Object System.Drawing.Size(1050,740);$pf.StartPosition='CenterParent';$pf.Font=New-Object System.Drawing.Font('Segoe UI',9)
 $tabs=New-Object System.Windows.Forms.TabControl;$tabs.Dock='Fill';$pf.Controls.Add($tabs)
 $tab1=New-Object System.Windows.Forms.TabPage;$tab1.Text='Карточки пациентов';$tabs.TabPages.Add($tab1)
 $tab2=New-Object System.Windows.Forms.TabPage;$tab2.Text='Проводник C: / D:';$tabs.TabPages.Add($tab2)
 $searchPatient=New-Object System.Windows.Forms.TextBox;$searchPatient.SetBounds(12,12,400,28);$tab1.Controls.Add($searchPatient)
 $add=New-Object System.Windows.Forms.Button;$add.Text='Добавить пациента';$add.SetBounds(425,11,175,30);$tab1.Controls.Add($add)
 $remove=New-Object System.Windows.Forms.Button;$remove.Text='Удалить карточку';$remove.SetBounds(610,11,175,30);$tab1.Controls.Add($remove)
 $grid=New-Object System.Windows.Forms.DataGridView;$grid.SetBounds(12,52,995,290);$grid.Anchor='Top,Left,Right';$grid.ReadOnly=$true;$grid.AllowUserToAddRows=$false;$grid.SelectionMode='FullRowSelect';$grid.MultiSelect=$false;$grid.AutoSizeColumnsMode='Fill';$grid.RowHeadersVisible=$false
 [void]$grid.Columns.Add('name','ФИО');[void]$grid.Columns.Add('birth','Дата рождения');[void]$grid.Columns.Add('count','Документов');$tab1.Controls.Add($grid)
 $documents=New-Object System.Windows.Forms.ListBox;$documents.SetBounds(12,382,995,230);$documents.Anchor='Top,Left,Right,Bottom';$tab1.Controls.Add($documents)
 $openDoc=New-Object System.Windows.Forms.Button;$openDoc.Text='Открыть в конструкторе';$openDoc.SetBounds(12,350,250,28);$tab1.Controls.Add($openDoc)
 $unlink=New-Object System.Windows.Forms.Button;$unlink.Text='Отвязать документ';$unlink.SetBounds(275,350,185,28);$tab1.Controls.Add($unlink)
 $script:currentPatient=-1
 function Refresh-PatientsGrid {
  $grid.Rows.Clear();$filter=$searchPatient.Text.Trim()
  for($i=0;$i -lt $script:patients.Count;$i++){$p=$script:patients[$i];if(-not $filter -or $p.Name.IndexOf($filter,[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -or $p.Birth -like "*$filter*"){$r=$grid.Rows.Add($p.Name,$p.Birth,@($p.Docs).Count);$grid.Rows[$r].Tag=$i}}
 }
 function Refresh-PatientDocs {
  $documents.Items.Clear();$script:currentPatient=-1
  if($grid.SelectedRows.Count -gt 0){$script:currentPatient=[int]$grid.SelectedRows[0].Tag;foreach($p in @($script:patients[$script:currentPatient].Docs)){[void]$documents.Items.Add([string]$p)}}
 }
 $searchPatient.Add_TextChanged({Refresh-PatientsGrid})
 $grid.Add_SelectionChanged({Refresh-PatientDocs})
 $add.Add_Click({
  $f=New-Object System.Windows.Forms.Form;$f.Text='Новая карточка';$f.Size=New-Object System.Drawing.Size(420,205);$f.StartPosition='CenterParent'
  $l1=New-Object System.Windows.Forms.Label;$l1.Text='ФИО';$l1.SetBounds(12,15,350,20);$f.Controls.Add($l1)
  $n=New-Object System.Windows.Forms.TextBox;$n.SetBounds(12,38,375,25);$f.Controls.Add($n)
  $l2=New-Object System.Windows.Forms.Label;$l2.Text='Дата рождения (необязательно)';$l2.SetBounds(12,70,350,20);$f.Controls.Add($l2)
  $b=New-Object System.Windows.Forms.TextBox;$b.SetBounds(12,93,375,25);$f.Controls.Add($b)
  $ok=New-Object System.Windows.Forms.Button;$ok.Text='Сохранить';$ok.SetBounds(12,128,140,30);$ok.DialogResult='OK';$f.Controls.Add($ok);$f.AcceptButton=$ok
  Set-DarkTheme $f
  if($f.ShowDialog($pf) -eq 'OK' -and $n.Text.Trim()){if(Invoke-PatientChange {$script:patients+= [pscustomobject]@{Id=[guid]::NewGuid().ToString();Name=$n.Text.Trim();Birth=$b.Text.Trim();Docs=@()}}){Refresh-PatientsGrid}}
  $f.Dispose()
 })
 $remove.Add_Click({if($script:currentPatient -ge 0 -and [System.Windows.Forms.MessageBox]::Show('Удалить карточку? Файлы на диске не удаляются.','Подтверждение','YesNo') -eq 'Yes'){if(Invoke-PatientChange {$script:patients=@($script:patients | Where-Object {$_.Id -ne $script:patients[$script:currentPatient].Id})}){Refresh-PatientsGrid;Refresh-PatientDocs}}})
 $openDoc.Add_Click({if($documents.SelectedItem -and (Test-Path -LiteralPath ([string]$documents.SelectedItem))){$script:pendingDocument=[string]$documents.SelectedItem;$pf.Close()}else{[System.Windows.Forms.MessageBox]::Show('Выберите существующий файл.')|Out-Null}})
 $previewPatient=New-Object System.Windows.Forms.Button;$previewPatient.Text='Предпросмотр';$previewPatient.SetBounds(473,350,165,28);$tab1.Controls.Add($previewPatient)
 $printPatient=New-Object System.Windows.Forms.Button;$printPatient.Text='Печать';$printPatient.SetBounds(650,350,130,28);$tab1.Controls.Add($printPatient)
 $previewPatient.Add_Click({try{if(-not $documents.SelectedItem){throw 'Выберите документ в списке.'};Start-WordDocumentAction ([string]$documents.SelectedItem) 'Preview'}catch{[void][System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Предпросмотр')}})
 $printPatient.Add_Click({try{if(-not $documents.SelectedItem){throw 'Выберите документ в списке.'};Start-WordDocumentAction ([string]$documents.SelectedItem) 'Print'}catch{[void][System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Печать')}})
 $unlink.Add_Click({if($script:currentPatient -ge 0 -and $documents.SelectedItem){$path=[string]$documents.SelectedItem;if(Invoke-PatientChange {$p=$script:patients[$script:currentPatient];$p.Docs=@($p.Docs | Where-Object {$_ -ne $path})}){Refresh-PatientsGrid;Refresh-PatientDocs}}})

 # Embedded file explorer: local folders and Word documents only.
 $script:explorerPath=''
 $script:explorerEntries=@()
 $pathBox=New-Object System.Windows.Forms.TextBox
 $pathBox.SetBounds(12,12,705,27);$pathBox.ReadOnly=$true;$pathBox.Anchor='Top,Left,Right';$tab2.Controls.Add($pathBox)
 $up=New-Object System.Windows.Forms.Button;$up.Text='Вверх';$up.SetBounds(730,10,100,30);$up.Anchor='Top,Right';$tab2.Controls.Add($up)
 $refresh=New-Object System.Windows.Forms.Button;$refresh.Text='Обновить';$refresh.SetBounds(840,10,160,30);$refresh.Anchor='Top,Right';$tab2.Controls.Add($refresh)
 $filter=New-Object System.Windows.Forms.TextBox;$filter.SetBounds(12,50,750,27);$filter.Anchor='Top,Left,Right';$tab2.Controls.Add($filter)
 $filterHint=New-Object System.Windows.Forms.Label;$filterHint.Text='Поиск по имени в текущей папке:';$filterHint.SetBounds(770,53,235,24);$filterHint.Anchor='Top,Right';$tab2.Controls.Add($filterHint)
 $tree=New-Object System.Windows.Forms.TreeView;$tree.SetBounds(12,88,245,445);$tree.Anchor='Top,Bottom,Left';$tree.HideSelection=$false;$tab2.Controls.Add($tree)
 $files=New-Object System.Windows.Forms.ListView;$files.SetBounds(267,88,733,445);$files.Anchor='Top,Bottom,Left,Right';$files.View='Details';$files.FullRowSelect=$true;$files.MultiSelect=$false;$files.HideSelection=$false
 [void]$files.Columns.Add('Имя',350);[void]$files.Columns.Add('Тип',100);[void]$files.Columns.Add('Размер',110);$tab2.Controls.Add($files)
 $attach=New-Object System.Windows.Forms.Button;$attach.Text='Привязать документ к пациенту';$attach.SetBounds(267,546,320,35);$attach.Anchor='Bottom,Left';$tab2.Controls.Add($attach)
 $openSelected=New-Object System.Windows.Forms.Button;$openSelected.Text='Открыть в конструкторе';$openSelected.SetBounds(595,546,160,35);$openSelected.Anchor='Bottom,Left';$tab2.Controls.Add($openSelected)
 $previewSelected=New-Object System.Windows.Forms.Button;$previewSelected.Text='Предпросмотр';$previewSelected.SetBounds(267,590,180,32);$previewSelected.Anchor='Bottom,Left';$tab2.Controls.Add($previewSelected)
 $printSelected=New-Object System.Windows.Forms.Button;$printSelected.Text='Печать';$printSelected.SetBounds(459,590,140,32);$printSelected.Anchor='Bottom,Left';$tab2.Controls.Add($printSelected)
 $previewSelected.Add_Click({
  try{if($files.SelectedItems.Count -eq 0 -or $files.SelectedItems[0].Tag.IsFolder){throw 'Выберите файл Word, а не папку.'};Start-WordDocumentAction ([string]$files.SelectedItems[0].Tag.FullPath) 'Preview'}catch{[void][System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Предпросмотр')}
 })
 $printSelected.Add_Click({
  try{if($files.SelectedItems.Count -eq 0 -or $files.SelectedItems[0].Tag.IsFolder){throw 'Выберите файл Word, а не папку.'};Start-WordDocumentAction ([string]$files.SelectedItems[0].Tag.FullPath) 'Print'}catch{[void][System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Печать')}
 })

 $status=New-Object System.Windows.Forms.Label;$status.SetBounds(12,632,985,32);$status.Anchor='Bottom,Left,Right';$status.Text='Выберите диск или папку. Двойной щелчок открывает папку.';$tab2.Controls.Add($status)
 function Refresh-ExplorerList {
  $files.BeginUpdate()
  try {
   $files.Items.Clear()
   $q=$filter.Text.Trim()
   foreach($entry in @($script:explorerEntries)){
    if($q -and $entry.Name.IndexOf($q,[System.StringComparison]::OrdinalIgnoreCase) -lt 0){continue}
    $kind=if($entry.IsFolder){'Папка'}else{'Документ Word'}
    $item=New-Object System.Windows.Forms.ListViewItem($entry.Name)
    [void]$item.SubItems.Add($kind)
    [void]$item.SubItems.Add($entry.Size)
    $item.Tag=$entry
    [void]$files.Items.Add($item)
   }
  }finally{$files.EndUpdate()}
 }
 function Set-ExplorerFolder([string]$target){
  $script:explorerEntries=@()
  if(-not $target){
   $script:explorerPath='';$pathBox.Text='Этот компьютер';$status.Text='Выберите диск C: или D:.'
   foreach($drive in @('C:\','D:\')){
    if([System.IO.Directory]::Exists($drive)){
     $script:explorerEntries+= [pscustomobject]@{Name=$drive;FullPath=$drive;IsFolder=$true;Size=''}
    }
   }
  }else{
   if(-not [System.IO.Directory]::Exists($target)){$status.Text='Папка не существует: '+$target;return}
   $script:explorerPath=$target;$pathBox.Text=$target
   $errors=0
   try {
    foreach($d in [System.IO.Directory]::EnumerateDirectories($target)){
     try {$name=[System.IO.Path]::GetFileName($d);if(-not $name){$name=$d};$script:explorerEntries+= [pscustomobject]@{Name=$name;FullPath=$d;IsFolder=$true;Size=''}}catch{$errors++}
    }
   }catch{$errors++;$status.Text='Недостаточно прав для чтения папок: '+$_.Exception.Message}
   try {
    foreach($f in [System.IO.Directory]::EnumerateFiles($target)){
     try {$ext=[System.IO.Path]::GetExtension($f).ToLowerInvariant();if($ext -notin @('.docx','.dotx')){continue};$fi=New-Object System.IO.FileInfo($f);$script:explorerEntries+= [pscustomobject]@{Name=$fi.Name;FullPath=$f;IsFolder=$false;Size=('{0:N0} КБ' -f [math]::Ceiling($fi.Length/1024.0))}}catch{$errors++}
    }
   }catch{$errors++;$status.Text='Недостаточно прав для чтения файлов: '+$_.Exception.Message}
   $status.Text='Элементов: '+$script:explorerEntries.Count+'; ошибок доступа: '+$errors+'. Поиск по имени работает в открытой папке.'
  }
  $filter.Text='';Refresh-ExplorerList
 }
 function Add-TreeChildren($node){
  if($node.Nodes.Count -eq 1 -and $node.Nodes[0].Tag -eq '__dummy__'){
   $node.Nodes.Clear()
   try{
    foreach($d in [System.IO.Directory]::EnumerateDirectories([string]$node.Tag)){
     try{$name=[System.IO.Path]::GetFileName($d);$child=New-Object System.Windows.Forms.TreeNode($name);$child.Tag=$d;$placeholder=New-Object System.Windows.Forms.TreeNode('...');$placeholder.Tag='__dummy__';[void]$child.Nodes.Add($placeholder);[void]$node.Nodes.Add($child)}catch{}
    }
   }catch{$status.Text='Нет доступа к подпапкам: '+$_.Exception.Message}
  }
 }
 foreach($disk in @('C:\','D:\')){
  if([System.IO.Directory]::Exists($disk)){
   $node=New-Object System.Windows.Forms.TreeNode($disk);$node.Tag=$disk
   $dummy=New-Object System.Windows.Forms.TreeNode('...');$dummy.Tag='__dummy__';[void]$node.Nodes.Add($dummy)
   [void]$tree.Nodes.Add($node)
  }
 }
 $tree.Add_BeforeExpand({param($sender,$e) Add-TreeChildren $e.Node})
 $tree.Add_AfterSelect({param($sender,$e) if($e.Node.Tag -and $e.Node.Tag -ne '__dummy__'){Set-ExplorerFolder ([string]$e.Node.Tag)}})
 $files.Add_DoubleClick({
  if($files.SelectedItems.Count -eq 0){return}
  $entry=$files.SelectedItems[0].Tag
  if($entry.IsFolder){Set-ExplorerFolder ([string]$entry.FullPath)}
  elseif([System.IO.File]::Exists([string]$entry.FullPath)){$script:pendingDocument=[string]$entry.FullPath;$pf.Close()}
 })
 $up.Add_Click({
  if(-not $script:explorerPath){return}
  $parent=[System.IO.Directory]::GetParent($script:explorerPath)
  if($parent){Set-ExplorerFolder $parent.FullName}else{Set-ExplorerFolder ''}
 })
 $refresh.Add_Click({Set-ExplorerFolder $script:explorerPath})
 $filter.Add_TextChanged({Refresh-ExplorerList})
 $openSelected.Add_Click({
  if($files.SelectedItems.Count -eq 0){return}
  $entry=$files.SelectedItems[0].Tag
  if($entry.IsFolder){Set-ExplorerFolder ([string]$entry.FullPath)}elseif([System.IO.File]::Exists([string]$entry.FullPath)){$script:pendingDocument=[string]$entry.FullPath;$pf.Close()}
 })
 $attach.Add_Click({
  if($files.SelectedItems.Count -eq 0){[System.Windows.Forms.MessageBox]::Show('Выберите документ Word.')|Out-Null;return}
  $entry=$files.SelectedItems[0].Tag
  if($entry.IsFolder){[System.Windows.Forms.MessageBox]::Show('Выберите файл, а не папку.')|Out-Null;return}
  if($script:currentPatient -lt 0){[System.Windows.Forms.MessageBox]::Show('Сначала выберите пациента на вкладке «Карточки пациентов».')|Out-Null;return}
  $p=$script:patients[$script:currentPatient];$docPath=[string]$entry.FullPath
  if(-not (@($p.Docs) -contains $docPath)){if(-not (Invoke-PatientChange {$p.Docs=@($p.Docs)+@($docPath)})){return}}
  Refresh-PatientsGrid
  [System.Windows.Forms.MessageBox]::Show('Документ привязан к карточке пациента.')|Out-Null
 })
 Set-ExplorerFolder ''
 Refresh-PatientsGrid
 Set-DarkTheme $pf
 $pf.Add_Shown({Set-DarkTheme $pf})
 $pf.ShowDialog($form)
 $pf.Dispose()
}
