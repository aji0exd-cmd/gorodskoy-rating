﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v62'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-FormatCheck([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
function Assert-FormatNear([double]$actual,[double]$expected,[string]$message,[double]$tolerance=0.002){Assert-FormatCheck ([Math]::Abs($actual-$expected) -lt $tolerance) ($message+' ['+$actual+']')}
function Assert-FormatRejected([scriptblock]$operation,[string]$message){$rejected=$false;try{& $operation}catch{$rejected=$true};Assert-FormatCheck $rejected $message}
function Import-FormatFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors | Out-String)}
 foreach($node in $ast.FindAll({param($item) $item -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}}
}
function Set-FormatTestPart([string]$path,[string]$name,[string]$text){
 $zip=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{$old=$zip.GetEntry($name);if($old){$old.Delete()};$entry=$zip.CreateEntry($name);$stream=$entry.Open();$bytes=[Text.Encoding]::UTF8.GetBytes($text);try{$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}}
 finally{$zip.Dispose()}
}
function Get-FormatEntryHash($model,[string]$name){return Get-MedicalBytesSha256 (@($model.Entries | Where-Object {$_.Name -ceq $name})[0].Bytes)}
function Find-FormatParagraph($model,[string]$text){return @($model.Paragraphs | Where-Object {$_.Text -ceq $text})[0]}
function Assert-FormatChildOrder($parent,[string[]]$order,[string]$message){
 $last=-1;$valid=$true
 foreach($child in $parent.ChildNodes){$rank=[array]::IndexOf($order,$child.LocalName);if($rank -ge 0){if($rank -lt $last){$valid=$false};$last=$rank}}
 Assert-FormatCheck $valid $message
}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-format-test-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 Import-FormatFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
 foreach($name in @('universal.ps1','forms-v59.ps1','template-editor-v59.ps1','template-format-v62.ps1','workspace-settings.ps1')){Import-FormatFunctions (Join-Path $Project $name)}
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main';$script:medicalProgramRoot=$Project;$script:fontFile=Join-Path $temp 'font.json';[IO.File]::WriteAllText($script:fontFile,'{"Enabled":false,"Name":"Times New Roman","Size":12}')
 $field=New-UniversalField 'text' 'Текст' 'TEXT'
 $config=[pscustomobject]@{Version=49;AutoTemplate=$false;Template='';Sections=@([pscustomobject]@{Id='test';Title='Раздел';Fields=@($field)})}
 $source=Join-Path $temp 'source.docx';New-UniversalTemplate $source $config;$config.Template=$source
 $document='<w:document xmlns:w="'+$script:ns+'" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><w:body>'+
 '<w:p><w:pPr><w:pStyle w:val="Child"/><w:keepNext/><w:spacing w:before="0"/><w:ind w:hanging="284"/><w:jc w:val="right"/><w:rPr><w:lang w:val="ru-RU"/></w:rPr></w:pPr><w:r><w:rPr><w:rStyle w:val="Character"/><w:b w:val="0"/><w:i w:val="0"/><w:color w:val="123456"/><w:sz w:val="26"/><w:u w:val="single"/></w:rPr><w:t>{{TEXT}}</w:t></w:r><w:r><w:rPr><w:b/><w:sz w:val="28"/></w:rPr><w:t> хвост</w:t></w:r></w:p>'+
 '<w:p><w:r><w:t>{{ADMISSION_DATETIME}}</w:t></w:r></w:p>'+
 '<w:p><w:pPr><w:sectPr><w:headerReference w:type="default" r:id="rIdHeader"/><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="500" w:footer="600" w:gutter="0"/><w:cols w:num="1"/></w:sectPr></w:pPr><w:r><w:t>Разрыв раздела</w:t></w:r></w:p>'+
 '<w:p><w:pPr><w:pStyle w:val="Child"/></w:pPr><w:r><w:t>Второй раздел</w:t></w:r></w:p>'+
 '<w:tbl><w:tblPr><w:tblW w:w="9000" w:type="dxa"/><w:tblCellMar><w:left w:w="100" w:type="dxa"/><w:right w:w="100" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid><w:gridCol w:w="4500"/><w:gridCol w:w="4500"/></w:tblGrid><w:tr><w:tc><w:tcPr><w:tcW w:w="4500" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>Ячейка</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Ячейка 2</w:t></w:r></w:p></w:tc></w:tr></w:tbl>'+
 '<w:p><w:bookmarkStart w:id="1" w:name="Keep"/><w:r><w:t>Закладка</w:t></w:r><w:bookmarkEnd w:id="1"/></w:p>'+
 '<w:sectPr><w:footerReference w:type="default" r:id="rIdFooter"/><w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/><w:pgMar w:top="1440" w:right="1800" w:bottom="1440" w:left="1440" w:header="567" w:footer="567" w:gutter="0"/><w:cols w:num="1"/><w:titlePg/></w:sectPr></w:body></w:document>'
 $styles='<w:styles xmlns:w="'+$script:ns+'"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri"/><w:b w:val="0"/><w:i w:val="0"/><w:sz w:val="22"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>'+
 '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:rPr><w:rFonts w:ascii="Times New Roman"/><w:b/><w:sz w:val="24"/></w:rPr></w:style>'+
 '<w:style w:type="paragraph" w:styleId="Parent"><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:before="240"/><w:ind w:left="720" w:right="360" w:firstLine="284"/><w:jc w:val="both"/></w:pPr><w:rPr><w:i/><w:sz w:val="28"/></w:rPr></w:style>'+
 '<w:style w:type="paragraph" w:styleId="Child"><w:basedOn w:val="Parent"/><w:rPr><w:b w:val="0"/></w:rPr></w:style>'+
 '<w:style w:type="character" w:styleId="Character"><w:rPr><w:rFonts w:ascii="Arial"/></w:rPr></w:style></w:styles>'
 Set-FormatTestPart $source 'word/document.xml' $document;Set-FormatTestPart $source 'word/styles.xml' $styles
 Set-FormatTestPart $source 'word/header1.xml' ('<w:hdr xmlns:w="'+$script:ns+'"><w:p><w:r><w:t>Header</w:t></w:r></w:p></w:hdr>')
 Set-FormatTestPart $source 'word/footer1.xml' ('<w:ftr xmlns:w="'+$script:ns+'"><w:p><w:r><w:t>Footer</w:t></w:r></w:p></w:ftr>')
 Set-FormatTestPart $source 'word/_rels/document.xml.rels' '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdHeader" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header1.xml"/><Relationship Id="rIdFooter" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/></Relationships>'
 $sourceHash=Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($source));$model=Read-MedicalTemplateModel $source;$paragraph=Find-FormatParagraph $model '{{TEXT}} хвост';$id=$paragraph.Id;$namespaces=Get-MedicalEditorNamespace $paragraph.Node.OwnerDocument
 $format=Get-MedicalParagraphFormat $model $id
 Assert-FormatCheck ($format.FontName -ceq 'Arial' -and $format.FontSize -eq 13) 'Character style plus direct run size overrides paragraph/default styles'
 Assert-FormatCheck (-not $format.Bold -and -not $format.Italic -and $format.Underline) 'Explicit zero bold and italic override inherited toggles'
 Assert-FormatCheck ($format.Alignment -ceq 'right' -and $format.FontColor -ceq '#123456') 'Direct paragraph alignment and run color resolved'
 Assert-FormatNear $format.LeftIndentCm 1.27 'Based-on left indent inherited'
 Assert-FormatNear $format.RightIndentCm 0.635 'Based-on right indent inherited'
 Assert-FormatNear $format.FirstLineCm -0.5 'Direct hanging indent overrides inherited first line'
 Assert-FormatNear $format.SpaceBeforePt 0 'Zero before spacing overrides inherited value'
 Assert-FormatNear $format.SpaceAfterPt 6 'Document default after spacing inherited'
 Assert-FormatNear $format.LineSpacing 1.15 'Document default automatic line spacing inherited'
 Assert-FormatCheck $format.MixedRunFormatting 'Mixed bold/size run styling reported'
 $second=Find-FormatParagraph $model 'Второй раздел';$secondFormat=Get-MedicalParagraphFormat $model $second.Id
 Assert-FormatCheck ($secondFormat.Bold -and $secondFormat.Italic -and $secondFormat.FontSize -eq 14) 'Styles based-on chain includes paragraph bold, italic, size'
 Assert-FormatNear $secondFormat.FirstLineCm 0.5 'Style first line preserved in another paragraph'
 $plain=Find-FormatParagraph $model '{{ADMISSION_DATETIME}}';$plainFormat=Get-MedicalParagraphFormat $model $plain.Id
 Assert-FormatCheck ($plainFormat.FontName -eq 'Times New Roman' -and $plainFormat.FontSize -eq 12 -and $plainFormat.Bold) 'Default paragraph style used when no pStyle present'
 $firstLayout=Get-MedicalPageLayout $model $id;$secondLayout=Get-MedicalPageLayout $model $second.Id
 Assert-FormatCheck ($firstLayout.SectionIndex -eq 1 -and $secondLayout.SectionIndex -eq 2) 'Following section break governs preceding paragraphs'
 Assert-FormatCheck ($firstLayout.Orientation -eq 'portrait' -and $secondLayout.Orientation -eq 'landscape') 'Page orientation resolved separately per section'
 Assert-FormatNear $firstLayout.PageWidthCm 21 'A4 portrait width read'
 Assert-FormatNear $secondLayout.PageWidthCm 29.7 'A4 landscape width read'
 $sectionParagraph=Find-FormatParagraph $model 'Разрыв раздела'
 Assert-FormatCheck ((Get-MedicalPageLayout $model $sectionParagraph.Id).SectionIndex -eq 1) 'Section break paragraph governed by its own sectPr'
 $header=Find-FormatParagraph $model 'Header';$footer=Find-FormatParagraph $model 'Footer'
 Assert-FormatCheck ((Get-MedicalPageLayout $model $header.Id).SectionIndex -eq 1 -and (Get-MedicalPageLayout $model $footer.Id).SectionIndex -eq 2) 'Header/footer relationships resolve their owning section'
 $table=Find-FormatParagraph $model 'Ячейка';$tableXml=$table.Node.ParentNode.ParentNode.ParentNode.OuterXml;$tableLayout=Get-MedicalPageLayout $model $table.Id
 Assert-FormatCheck $tableLayout.IsTable 'Cell paragraph exposes table context'
 Assert-FormatNear $tableLayout.ContentWidthCm (4300*2.54/1440) 'Cell width excludes effective table cell margins'
 $runXml=($paragraph.Node.SelectNodes('./w:r',$namespaces) | ForEach-Object {$_.OuterXml}) -join ''
 Set-MedicalParagraphFormat $model $id @{Alignment='both'}
 Assert-FormatCheck ((($paragraph.Node.SelectNodes('./w:r',$namespaces) | ForEach-Object {$_.OuterXml}) -join '') -ceq $runXml) 'Alignment-only change preserves all mixed inline XML exactly'
 Assert-FormatCheck ((Get-MedicalParagraphFormat $model $id).MixedRunFormatting) 'Alignment-only change retains mixed formatting'
 Assert-FormatCheck ((Get-MedicalParagraphFormat $model $id).Alignment -eq 'both') 'Alignment written to real paragraph XML'
 $before=$model.Parts['word/document.xml'].Xml.OuterXml
 foreach($invalid in @(@{FontSize=0},@{FontSize=[double]::NaN},@{Bold='false'},@{FontName="bad`nfont"},@{Alignment='invalid'},@{FontColor='#XXX'},@{LeftIndentCm=-1},@{RightIndentCm=25},@{LineSpacing=0.5},@{SpaceBeforePt=201},@{FirstLineCm=25},@{Alignment='center';FontSize='wrong'})){
  Assert-FormatRejected {Set-MedicalParagraphFormat $model $id $invalid} ('Invalid format rejected: '+($invalid.Keys -join ','))
  Assert-FormatCheck ($before -ceq $model.Parts['word/document.xml'].Xml.OuterXml) 'Failed format operation leaves all XML byte-identical'
 }
 $protected=Find-FormatParagraph $model 'Закладка';Assert-FormatRejected {Set-MedicalParagraphFormat $model $protected.Id @{Alignment='center'}} 'Formatting protected complex paragraph refused'
 Assert-FormatRejected {Set-MedicalParagraphFormat $model 'missing' @{Alignment='left'}} 'Unknown paragraph ID refused'
 Assert-FormatCheck ($before -ceq $model.Parts['word/document.xml'].Xml.OuterXml) 'Protection and unknown-ID failures preserve XML'
 $textBefore=Get-MedicalEditorParagraphText $paragraph.Node $namespaces
 $all=@{Alignment='center';FontName='Arial';FontSize=15.5;Bold=$true;Italic=$true;Underline=$false;FontColor='#A1B2C3';LeftIndentCm=1;RightIndentCm=0.5;FirstLineCm=0.75;SpaceBeforePt=8;SpaceAfterPt=10;LineSpacing=1.5}
 Set-MedicalParagraphFormat $model $id $all;$updated=Get-MedicalParagraphFormat $model $id
 foreach($key in @('Alignment','FontName','FontSize','Bold','Italic','Underline','FontColor')){Assert-FormatCheck ($updated.$key -ceq $all[$key]) ('Complete formatting round-trip: '+$key)}
 foreach($key in @('LeftIndentCm','RightIndentCm','FirstLineCm','SpaceBeforePt','SpaceAfterPt','LineSpacing')){Assert-FormatNear $updated.$key $all[$key] ('Complete numeric formatting round-trip: '+$key)}
 Assert-FormatCheck (-not $updated.MixedRunFormatting) 'Applying complete run formatting unifies selected paragraph runs'
 Assert-FormatCheck ((Get-MedicalEditorParagraphText $paragraph.Node $namespaces) -ceq $textBefore) 'Formatting does not rewrite text or markers'
 Assert-FormatCheck ($null -ne $paragraph.Node.SelectSingleNode('./w:pPr/w:keepNext',$namespaces) -and $paragraph.Node.SelectSingleNode('./w:pPr/w:pStyle',$namespaces).GetAttribute('val',$script:ns) -eq 'Child' -and $paragraph.Node.SelectSingleNode('./w:pPr/w:rPr/w:lang',$namespaces).GetAttribute('val',$script:ns) -eq 'ru-RU') 'Unrelated paragraph style, keep-next and language survive'
 Assert-FormatCheck ($paragraph.Node.SelectSingleNode('./w:r/w:rPr/w:rStyle',$namespaces).GetAttribute('val',$script:ns) -eq 'Character') 'Character style reference survives explicit formatting'
 Assert-FormatChildOrder ($paragraph.Node.SelectSingleNode('./w:pPr',$namespaces)) @('pStyle','keepNext','spacing','ind','jc','rPr','sectPr') 'Written paragraph properties follow OOXML canonical order'
 foreach($rPr in $paragraph.Node.SelectNodes('./w:r/w:rPr|./w:pPr/w:rPr',$namespaces)){Assert-FormatChildOrder $rPr @('rStyle','rFonts','b','bCs','i','iCs','color','sz','szCs','u','lang') 'Written run properties follow OOXML canonical order'}
 Set-MedicalParagraphFormat $model $id @{Bold=$false;Italic=$false;Underline=$true;FirstLineCm=-0.3}
 $updated=Get-MedicalParagraphFormat $model $id;Assert-FormatCheck (-not $updated.Bold -and -not $updated.Italic -and $updated.Underline) 'Explicit false direct properties suppress inherited bold and italic'
 Assert-FormatNear $updated.FirstLineCm -0.3 'Negative first-line value writes hanging indentation'
 Assert-FormatCheck (-not $paragraph.Node.SelectSingleNode('./w:pPr/w:ind',$namespaces).HasAttribute('firstLine',$script:ns)) 'Hanging change clears mutually exclusive firstLine'
 Set-MedicalParagraphFormat $model $table.Id @{Alignment='center';FontSize=10}
 Assert-FormatCheck ((Get-MedicalParagraphFormat $model $table.Id).Alignment -eq 'center') 'Table paragraph formatting editable in its cell'
 Assert-FormatCheck ($model.Parts['word/document.xml'].Xml.SelectNodes('//w:tbl',$namespaces).Count -eq 1 -and $table.Node.ParentNode.SelectSingleNode('./w:tcPr/w:tcW',$namespaces).GetAttribute('w',$script:ns) -eq '4500') 'Table structure and width survive paragraph formatting'
 $before=$model.Parts['word/document.xml'].Xml.OuterXml
 foreach($invalid in @(@{PageWidthCm=0},@{PageHeightCm=[double]::Infinity},@{MarginLeftCm=-1},@{MarginRightCm=20},@{MarginTopCm=20;MarginBottomCm=20},@{PageWidthCm=14.8;MarginLeftCm=20})){
  Assert-FormatRejected {Set-MedicalPageLayout $model $invalid $id} ('Invalid page layout rejected: '+($invalid.Keys -join ','))
  Assert-FormatCheck ($before -ceq $model.Parts['word/document.xml'].Xml.OuterXml) 'Failed page operation leaves all XML byte-identical'
 }
 $secondSection=Get-MedicalSectionProperties $model $second.Id;$secondBefore=$secondSection.Node.OuterXml
 Set-MedicalPageLayout $model @{PageWidthCm=14.8;PageHeightCm=21;MarginLeftCm=1;MarginRightCm=1.5;MarginTopCm=1.2;MarginBottomCm=1.3} $id
 $layout=Get-MedicalPageLayout $model $id
 foreach($record in @(@('PageWidthCm',14.8),@('PageHeightCm',21),@('MarginLeftCm',1),@('MarginRightCm',1.5),@('MarginTopCm',1.2),@('MarginBottomCm',1.3))){Assert-FormatNear $layout.($record[0]) $record[1] ('Page layout numeric round-trip: '+$record[0])}
 Assert-FormatCheck ((Get-MedicalSectionProperties $model $second.Id).Node.OuterXml -ceq $secondBefore) 'Changing one section leaves later section XML exactly intact'
 $firstSection=Get-MedicalSectionProperties $model $id
 Assert-FormatCheck ($firstSection.Node.SelectSingleNode('./w:headerReference',$namespaces).GetAttribute('id','http://schemas.openxmlformats.org/officeDocument/2006/relationships') -eq 'rIdHeader' -and $null -ne $firstSection.Node.SelectSingleNode('./w:cols',$namespaces)) 'Section headers and columns survive page changes'
 Assert-FormatCheck ($firstSection.Node.SelectSingleNode('./w:pgMar',$namespaces).GetAttribute('header',$script:ns) -eq '500' -and $firstSection.Node.SelectSingleNode('./w:pgMar',$namespaces).GetAttribute('footer',$script:ns) -eq '600') 'Header/footer distances preserve source values'
 Assert-FormatChildOrder $firstSection.Node @('headerReference','footerReference','pgSz','pgMar','cols','titlePg') 'Written section properties follow OOXML canonical order'
 $sizeBefore=$firstSection.Node.SelectSingleNode('./w:pgSz',$namespaces).OuterXml
 Set-MedicalPageLayout $model @{MarginLeftCm=1.1} $id
 Assert-FormatCheck ((Get-MedicalSectionProperties $model $id).Node.SelectSingleNode('./w:pgSz',$namespaces).OuterXml -ceq $sizeBefore) 'Partial margin update preserves paper size and orientation exactly'
 $saved=Join-Path $temp 'formatted.docx';Write-MedicalTemplateModel $saved $model;$read=Read-MedicalTemplateModel $saved
 $round=Get-MedicalParagraphFormat $read $id;Assert-FormatCheck ($round.FontName -eq 'Arial' -and $round.FontSize -eq 15.5 -and -not $round.Bold -and $round.Alignment -eq 'center') 'Paragraph formatting survives save and read-back'
 Assert-FormatNear (Get-MedicalPageLayout $read $id).MarginLeftCm 1.1 'Page layout survives save and read-back'
 foreach($entry in $model.Entries | Where-Object {$_.Name -ne 'word/document.xml'}){Assert-FormatCheck ((Get-FormatEntryHash $read $entry.Name) -ceq (Get-FormatEntryHash $model $entry.Name)) ('Unchanged ZIP resources preserve exact bytes: '+$entry.Name)}
 $config.Template=$saved;$export=Join-Path $temp 'exported.docx';Save-UniversalDocument $export $config @{text='Тестовый текст'} ([datetime]'2026-01-01T12:00:00') @{}
 $archive=[IO.Compression.ZipFile]::OpenRead($export);try{$exportXml=Get-XmlPart $archive 'word/document.xml'}finally{$archive.Dispose()}
 $exportNs=Get-MedicalEditorNamespace $exportXml;$exportParagraph=$exportXml.SelectSingleNode('//w:p[w:r/w:t[contains(text(),"Тестовый текст")]]',$exportNs)
 Assert-FormatCheck ($exportParagraph -and $exportParagraph.SelectSingleNode('./w:pPr/w:jc',$exportNs).GetAttribute('val',$script:ns) -eq 'center' -and $exportParagraph.SelectSingleNode('./w:r/w:rPr/w:sz',$exportNs).GetAttribute('val',$script:ns) -eq '31') 'Real Word marker export preserves authored paragraph/run formatting'
 Assert-FormatCheck ($exportXml.SelectSingleNode('/w:document/w:body/w:p/w:pPr/w:sectPr/w:pgSz',$exportNs).GetAttribute('w',$script:ns) -eq ([string][int][Math]::Round(14.8*1440/2.54))) 'Real Word export preserves authored section dimensions'
 # Per-form preservation must survive enabled old global settings and portable forms.
 Assert-FormatCheck ($null -eq $config.PSObject.Properties['PreserveTemplateFormatting']) 'Legacy schema without preservation flag remains accepted'
 $preserved=Copy-MedicalFormSchema $config;$preserved | Add-Member -NotePropertyName PreserveTemplateFormatting -NotePropertyValue $true
 $formatted18=Read-MedicalTemplateModel $saved;Set-MedicalParagraphFormat $formatted18 $id @{FontSize=18};$path18=Join-Path $temp 'formatted18.docx';Write-MedicalTemplateModel $path18 $formatted18;$preserved.Template=$path18
 [IO.File]::WriteAllText($script:fontFile,'{"Enabled":true,"Name":"Times New Roman","Size":12}')
 $preserveExport=Join-Path $temp 'preserve-export.docx';Save-UniversalDocument $preserveExport $preserved @{text='Сохранить оформление'} ([datetime]'2026-01-01') @{}
 $archive=[IO.Compression.ZipFile]::OpenRead($preserveExport);try{$preserveXml=Get-XmlPart $archive 'word/document.xml'}finally{$archive.Dispose()}
 Assert-FormatCheck ($preserveXml.SelectSingleNode('//w:p[w:r/w:t[contains(text(),"Сохранить оформление")]]/w:r/w:rPr/w:sz',(Get-MedicalEditorNamespace $preserveXml)).GetAttribute('val',$script:ns) -eq '36') 'Preservation flag keeps authored 18pt when old global font override is enabled'
 $override=Copy-MedicalFormSchema $preserved;$override.PreserveTemplateFormatting=$false
 $overrideExport=Join-Path $temp 'override-export.docx';Save-UniversalDocument $overrideExport $override @{text='Глобальный шрифт'} ([datetime]'2026-01-01') @{}
 $archive=[IO.Compression.ZipFile]::OpenRead($overrideExport);try{$overrideXml=Get-XmlPart $archive 'word/document.xml'}finally{$archive.Dispose()}
 Assert-FormatCheck ($overrideXml.SelectSingleNode('//w:p[w:r/w:t[contains(text(),"Глобальный шрифт")]]/w:r/w:rPr/w:sz',(Get-MedicalEditorNamespace $overrideXml)).GetAttribute('val',$script:ns) -eq '24') 'Explicit false preservation flag retains global font override behavior'
 $oldCopy=Copy-MedicalFormSchema $config;Assert-UniversalConfig $oldCopy
 Assert-FormatCheck ($null -eq $oldCopy.PSObject.Properties['PreserveTemplateFormatting']) 'Copying an old schema does not invent a preservation flag'
 $invalidFlag=Copy-MedicalFormSchema $config;$invalidFlag | Add-Member -NotePropertyName PreserveTemplateFormatting -NotePropertyValue 'yes'
 Assert-FormatRejected {Assert-UniversalConfig $invalidFlag} 'Non-boolean preservation flag rejected by schema validation'
 Assert-FormatRejected {Copy-MedicalFormSchema $invalidFlag} 'Non-boolean preservation flag rejected by portable schema copy'
 $script:medicalProgramRoot=Join-Path $temp 'forms-program';$script:medicalTemplatesFolder=Join-Path $script:medicalProgramRoot 'Шаблоны';[void][IO.Directory]::CreateDirectory($script:medicalProgramRoot)
 $formPath=Join-Path $temp 'formatted.mcform';[void](Write-MedicalForm $formPath $preserved 'Оформленная форма');$formRead=Read-MedicalForm $formPath
 Assert-FormatCheck ($formRead.Schema.PreserveTemplateFormatting -is [bool] -and $formRead.Schema.PreserveTemplateFormatting) 'Portable form preserves formatting flag after save/read'
 Assert-FormatCheck (-not ([IO.File]::ReadAllText($formPath).Contains('Сохранить оформление'))) 'Saved form contains no patient answer from preceding export'
 $script:medicalProgramRoot=$Project
 [IO.File]::WriteAllText($script:fontFile,'{"Enabled":false,"Name":"Times New Roman","Size":12}')
 Assert-FormatCheck ((Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($source))) -ceq $sourceHash) 'Original source template remains byte-identical'
 foreach($name in @('Шаблон первичного осмотра.docx','Универсальный первичный осмотр.docx','template.dotx')){
  $actual=Read-MedicalTemplateModel (Join-Path $Project $name);$original=$actual.Parts['word/document.xml'].Xml.OuterXml
  foreach($record in $actual.Paragraphs){$f=Get-MedicalParagraphFormat $actual $record.Id;$p=Get-MedicalPageLayout $actual $record.Id;Assert-FormatCheck ($f.FontSize -gt 0 -and $f.FontName -and $p.PageWidthCm -gt 0 -and $p.ContentWidthCm -gt 0) ('Real shipped template effective format resolved: '+$name+' '+$record.Id)}
  Assert-FormatCheck ($original -ceq $actual.Parts['word/document.xml'].Xml.OuterXml -and -not $actual.Parts['word/document.xml'].Modified) ('Read-only format inspection preserves real shipped template: '+$name)
 }
 $themeModel=Read-MedicalTemplateModel $saved
 Set-FormatTestPart $saved 'word/theme/theme1.xml' '<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:themeElements><a:fontScheme><a:majorFont><a:latin typeface="Cambria"/></a:majorFont><a:minorFont><a:latin typeface="Calibri"/></a:minorFont></a:fontScheme></a:themeElements></a:theme>'
 Set-FormatTestPart $saved 'word/styles.xml' ('<w:styles xmlns:w="'+$script:ns+'"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:asciiTheme="majorHAnsi"/><w:sz w:val="24"/></w:rPr></w:rPrDefault></w:docDefaults></w:styles>')
 $themeModel=Read-MedicalTemplateModel $saved;$plainTheme=Find-FormatParagraph $themeModel '{{ADMISSION_DATETIME}}'
 Assert-FormatCheck ((Get-MedicalParagraphFormat $themeModel $plainTheme.Id).FontName -eq 'Cambria') 'Theme major font resolves through resource font scheme'
 $without=Read-MedicalTemplateModel $source;$body=$without.Parts['word/document.xml'].Xml.SelectSingleNode('/w:document/w:body',$namespaces)
 foreach($sectionNode in @($without.Parts['word/document.xml'].Xml.SelectNodes('//w:sectPr',$namespaces))){[void]$sectionNode.ParentNode.RemoveChild($sectionNode)}
 $defaultLayout=Get-MedicalPageLayout $without
 Assert-FormatNear $defaultLayout.PageWidthCm 21 'Missing section uses A4 width fallback'
 Set-MedicalPageLayout $without @{MarginLeftCm=1}
 Assert-FormatCheck ($body.LastChild.LocalName -eq 'sectPr' -and $body.LastChild.SelectSingleNode('./w:pgMar',$namespaces).Attributes.Count -eq 7) 'Missing section created at body end with required margin attributes'
 Assert-FormatCheck ($body.LastChild.SelectSingleNode('./w:pgSz',$namespaces).GetAttribute('w',$script:ns) -eq '11906') 'Missing section writes explicit A4 size even for margin-only edit'
 Set-MedicalParagraphFormat $without $plain.Id @{}
 Assert-FormatCheck $true 'Empty partial property bag performs safe no-op'
 Write-Output ('TOTAL '+$script:checks+' format checks passed.')
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
