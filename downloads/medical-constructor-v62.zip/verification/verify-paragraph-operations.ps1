﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v62'))
$ErrorActionPreference='Stop'
$script:checks=0
function Assert-ParagraphCheck([bool]$condition,[string]$message){
 if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)
}
function Assert-ParagraphRejected([scriptblock]$operation,[string]$message,[string]$reason=''){
 $failure='';try{& $operation | Out-Null}catch{$failure=$_.Exception.Message}
 Assert-ParagraphCheck (-not [string]::IsNullOrEmpty($failure)) $message
 if($reason){Assert-ParagraphCheck ($failure.Contains($reason)) ($message+' gives a clear reason')}
}
function Get-ParagraphHash([byte[]]$bytes){
 $hash=[Security.Cryptography.SHA256]::Create()
 try{return ([BitConverter]::ToString($hash.ComputeHash($bytes))).Replace('-','').ToLowerInvariant()}finally{$hash.Dispose()}
}
function Set-ParagraphTestEntry([string]$path,[string]$name,[byte[]]$bytes){
 $archive=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{
  $entry=$archive.GetEntry($name);if($entry){$entry.Delete()};$entry=$archive.CreateEntry($name)
  $stream=$entry.Open();try{$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
 }finally{$archive.Dispose()}
}
function Set-ParagraphTestXml([string]$path,[string]$name,[string]$xml){Set-ParagraphTestEntry $path $name ([Text.Encoding]::UTF8.GetBytes($xml))}
function Find-ParagraphTest($model,[string]$text,[string]$part='word/document.xml'){
 $matches=@($model.Paragraphs | Where-Object {$_.Part -ceq $part -and $_.Text -ceq $text})
 if($matches.Count -ne 1){throw ('Expected one paragraph: '+$text)};return $matches[0]
}
function New-ParagraphTestModel([string]$path,[string]$body=''){
 $config=[pscustomobject]@{Version=49;AutoTemplate=$false;Template=$path;Sections=@([pscustomobject]@{Id='section';Title='Section';Fields=@((New-UniversalField 'text' 'Text' 'TEXT'))})}
 New-UniversalTemplate $path $config
 if(-not $body){
  $body='<w:p><w:r><w:t>{{ADMISSION_DATETIME}}</w:t></w:r></w:p>'+
   '<w:p><w:r><w:t>{{TEXT}}</w:t></w:r></w:p>'+
   '<w:p w:rsidR="11111111"><w:pPr><w:pStyle w:val="Heading1"/></w:pPr><w:r><w:t>Delete plain</w:t></w:r></w:p>'+
   '<w:tbl><w:tblPr/><w:tblGrid><w:gridCol/><w:gridCol/><w:gridCol/></w:tblGrid><w:tr>'+
   '<w:tc><w:tcPr/><w:p><w:r><w:t>Cell first</w:t></w:r></w:p><w:p><w:r><w:t>Cell last</w:t></w:r></w:p></w:tc>'+
   '<w:tc><w:tcPr/><w:p w:rsidR="22222222"><w:pPr><w:jc w:val="right"/></w:pPr><w:r><w:t>Only cell</w:t></w:r></w:p></w:tc>'+
   '<w:tc><w:p><w:r><w:t>Before nested</w:t></w:r></w:p><w:tbl><w:tblPr/><w:tblGrid><w:gridCol/></w:tblGrid><w:tr><w:tc><w:p><w:r><w:t>Nested</w:t></w:r></w:p></w:tc></w:tr></w:tbl><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:t>After nested</w:t></w:r></w:p></w:tc>'+
   '</w:tr></w:tbl>'+
   '<w:p w:rsidR="33333333"><w:pPr><w:spacing w:after="240"/><w:sectPr><w:headerReference w:type="default" r:id="rIdHeader"/><w:type w:val="continuous"/><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1234" w:right="2345" w:bottom="3456" w:left="4567"/></w:sectPr></w:pPr><w:r><w:t>Section break</w:t></w:r></w:p>'+
   '<w:p><w:bookmarkStart w:id="1" w:name="Bookmark"/><w:r><w:t>Bookmark</w:t></w:r><w:bookmarkEnd w:id="1"/></w:p>'+
   '<w:p><w:sdt><w:sdtPr><w:id w:val="7"/></w:sdtPr><w:sdtContent><w:r><w:t>Inline control</w:t></w:r></w:sdtContent></w:sdt></w:p>'+
   '<w:p><w:r><w:pict/></w:r></w:p>'+
   '<w:p><w:hyperlink r:id="rIdLink"><w:r><w:t>Link</w:t></w:r></w:hyperlink></w:p>'+
   '<w:p><w:r><w:fldChar w:fldCharType="begin"/><w:instrText>PAGE</w:instrText><w:fldChar w:fldCharType="end"/></w:r></w:p>'+
   '<w:p><w:ins w:id="1" w:author="Test"><w:r><w:t>Revision</w:t></w:r></w:ins></w:p>'+
   '<w:sdt><w:sdtPr><w:id w:val="8"/></w:sdtPr><w:sdtContent><w:p><w:r><w:t>Block control</w:t></w:r></w:p></w:sdtContent></w:sdt>'+
   '<w:p><w:r><w:br w:type="page"/><w:t>Page break</w:t></w:r></w:p>'+
   '<w:p><w:r><w:t>Last ordinary</w:t></w:r></w:p>'+
   '<w:sectPr><w:headerReference w:type="default" r:id="rIdHeader"/><w:footerReference w:type="default" r:id="rIdFooter"/><w:pgSz w:w="11906" w:h="16838"/></w:sectPr>'
 }
 Set-ParagraphTestXml $path 'word/document.xml' ('<?xml version="1.0"?><w:document xmlns:w="'+$script:ns+'" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><w:body>'+$body+'</w:body></w:document>')
 Set-ParagraphTestXml $path 'word/header1.xml' ('<?xml version="1.0"?><w:hdr xmlns:w="'+$script:ns+'"><w:p><w:r><w:t>Header first</w:t></w:r></w:p><w:p><w:r><w:t>Header last</w:t></w:r></w:p></w:hdr>')
 Set-ParagraphTestXml $path 'word/footer1.xml' ('<?xml version="1.0"?><w:ftr xmlns:w="'+$script:ns+'"><w:p w:rsidR="44444444"><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:t>Only footer</w:t></w:r></w:p></w:ftr>')
 $archive=[IO.Compression.ZipFile]::OpenRead($path)
 try{
  $reader=[IO.StreamReader]::new($archive.GetEntry('[Content_Types].xml').Open())
  try{[xml]$types=$reader.ReadToEnd()}finally{$reader.Dispose()}
  $reader=[IO.StreamReader]::new($archive.GetEntry('word/_rels/document.xml.rels').Open())
  try{[xml]$relationships=$reader.ReadToEnd()}finally{$reader.Dispose()}
 }finally{$archive.Dispose()}
 foreach($record in @(@('/word/header1.xml','header'),@('/word/footer1.xml','footer'))){
  $item=$types.CreateElement('Override',$types.DocumentElement.NamespaceURI);$item.SetAttribute('PartName',$record[0]);$item.SetAttribute('ContentType',('application/vnd.openxmlformats-officedocument.wordprocessingml.'+$record[1]+'+xml'));[void]$types.DocumentElement.AppendChild($item)
 }
 foreach($record in @(@('rIdHeader','header','header1.xml'),@('rIdFooter','footer','footer1.xml'),@('rIdLink','hyperlink','https://example.org/'))){
  $item=$relationships.CreateElement('Relationship',$relationships.DocumentElement.NamespaceURI);$item.SetAttribute('Id',$record[0]);$item.SetAttribute('Type',('http://schemas.openxmlformats.org/officeDocument/2006/relationships/'+$record[1]));$item.SetAttribute('Target',$record[2]);if($record[1] -eq 'hyperlink'){$item.SetAttribute('TargetMode','External')};[void]$relationships.DocumentElement.AppendChild($item)
 }
 Set-ParagraphTestXml $path '[Content_Types].xml' $types.OuterXml
 Set-ParagraphTestXml $path 'word/_rels/document.xml.rels' $relationships.OuterXml
 return (Read-MedicalTemplateModel $path)
}

$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-paragraph-tests-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
try{
 # Dot-source the real application files in this script scope. Do not rewrite
 # function declarations or import them globally: the editor uses these helpers.
 . (Join-Path $Project 'universal.ps1')
 . (Join-Path $Project 'template-editor-v59.ps1')
 . (Join-Path $Project 'template-editor-operations-v61.ps1')
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 $source=Join-Path $temp 'source.docx';$model=New-ParagraphTestModel $source
 $sourceHash=Get-ParagraphHash ([IO.File]::ReadAllBytes($source))
 $capturedRemove=Get-Command 'Remove-MedicalTemplateParagraph' -CommandType Function
 $callback={param($callbackModel,[string]$paragraphId) & $capturedRemove $callbackModel $paragraphId}.GetNewClosure()
 $callbackModel=Read-MedicalTemplateModel $source;$callbackParagraph=Find-ParagraphTest $callbackModel 'Delete plain'
 $callbackSelection=& $callback $callbackModel $callbackParagraph.Id
 Assert-ParagraphCheck ($callbackSelection.Text -ceq 'Cell first' -and $null -eq $callbackParagraph.Node.ParentNode) 'Captured editor callback resolves script-scoped deletion and its nested helpers'
 $config=[pscustomobject]@{Version=49;AutoTemplate=$false;Template=$source;Sections=@([pscustomobject]@{Id='section';Title='Section';Fields=@((New-UniversalField 'text' 'Text' 'TEXT'))})}
 Assert-MedicalEditorTemplateCoverage $config $model
 $beforeCount=$model.Paragraphs.Count;$beforeHeader=$model.Parts['word/header1.xml'].Xml.OuterXml;$beforeFooter=$model.Parts['word/footer1.xml'].Xml.OuterXml
 $plain=Find-ParagraphTest $model 'Delete plain';$next=Find-ParagraphTest $model 'Cell first'
 $selected=Remove-MedicalTemplateParagraph $model $plain.Id
 Assert-ParagraphCheck ($model.Paragraphs.Count -eq $beforeCount-1 -and $null -eq $plain.Node.ParentNode) 'Ordinary paragraph is removed from XML and model'
 Assert-ParagraphCheck ([object]::ReferenceEquals($selected.Node,$next.Node) -and $selected.Id -ceq 'word/document.xml#3') 'Next paragraph remains selected using its refreshed ID'
 Assert-ParagraphCheck ($model.Parts['word/document.xml'].Modified -and -not $model.Parts['word/header1.xml'].Modified -and -not $model.Parts['word/footer1.xml'].Modified) 'Only the edited Word part is marked modified'
 Assert-ParagraphCheck ($beforeHeader -ceq $model.Parts['word/header1.xml'].Xml.OuterXml -and $beforeFooter -ceq $model.Parts['word/footer1.xml'].Xml.OuterXml) 'Other Word parts remain untouched'
 Assert-MedicalEditorTemplateCoverage $config $model
 Assert-ParagraphCheck ($true) 'Deleting an unused text paragraph retains real export marker coverage'
 $namespaces=Get-MedicalEditorNamespace $model.Parts['word/document.xml'].Xml
 $tableCount=$model.Parts['word/document.xml'].Xml.SelectNodes('//w:tbl',$namespaces).Count
 $cellFirst=Find-ParagraphTest $model 'Cell first';$cellLast=Find-ParagraphTest $model 'Cell last'
 $selected=Remove-MedicalTemplateParagraph $model $cellLast.Id
 Assert-ParagraphCheck ($null -eq $cellLast.Node.ParentNode -and $cellFirst.Node.ParentNode.SelectNodes('./w:p',$namespaces).Count -eq 1) 'Deleting a redundant table paragraph retains the other paragraph'
 Assert-ParagraphCheck ($model.Parts['word/document.xml'].Xml.SelectNodes('//w:tbl',$namespaces).Count -eq $tableCount) 'Deleting a table paragraph preserves all tables and cells'
 $onlyCell=Find-ParagraphTest $model 'Only cell';$properties=$onlyCell.Node.SelectSingleNode('./w:pPr',$namespaces).OuterXml
 $selected=Remove-MedicalTemplateParagraph $model $onlyCell.Id
 Assert-ParagraphCheck ([object]::ReferenceEquals($selected.Node,$onlyCell.Node) -and $selected.Text -ceq '' -and $selected.Node.ParentNode.LocalName -ceq 'tc') 'The final paragraph in a cell remains empty and selected'
 Assert-ParagraphCheck ($selected.Node.SelectSingleNode('./w:pPr',$namespaces).OuterXml -ceq $properties -and $selected.Node.GetAttribute('rsidR',$script:ns) -ceq '22222222') 'Clearing a required table paragraph preserves its style and attributes'
 $afterNested=Find-ParagraphTest $model 'After nested';$parent=$afterNested.Node.ParentNode;$beforeNested=Find-ParagraphTest $model 'Before nested'
 $selected=Remove-MedicalTemplateParagraph $model $afterNested.Id
 Assert-ParagraphCheck ([object]::ReferenceEquals($selected.Node,$afterNested.Node) -and $selected.Text -ceq '' -and $selected.Node.PreviousSibling.LocalName -ceq 'tbl') 'A required trailing paragraph after a nested table remains empty'
 Assert-ParagraphCheck ($beforeNested.Text -ceq 'Before nested' -and $parent.SelectNodes('./w:tbl',$namespaces).Count -eq 1) 'Nested table and earlier cell text remain intact'
 $section=Find-ParagraphTest $model 'Section break';$properties=$section.Node.SelectSingleNode('./w:pPr',$namespaces).OuterXml
 $selected=Remove-MedicalTemplateParagraph $model $section.Id
 Assert-ParagraphCheck ([object]::ReferenceEquals($selected.Node,$section.Node) -and $selected.Text -ceq '') 'A paragraph carrying section properties is cleared rather than removed'
 Assert-ParagraphCheck ($selected.Node.SelectSingleNode('./w:pPr',$namespaces).OuterXml -ceq $properties -and $selected.Node.GetAttribute('rsidR',$script:ns) -ceq '33333333') 'Section page size, margins, header binding and paragraph properties remain intact'
 $protected=@($model.Paragraphs | Where-Object {-not $_.Editable})
 Assert-ParagraphCheck ($protected.Count -eq 8) 'Fixture includes bookmarks, controls, images, hyperlinks, fields, revisions and page breaks'
 foreach($paragraph in $protected){
  $before=$model.Parts[$paragraph.Part].Xml.OuterXml
  Assert-ParagraphRejected {Remove-MedicalTemplateParagraph $model $paragraph.Id} ('Protected paragraph deletion refused: '+$paragraph.Id) 'Удаление недоступно.'
  Assert-ParagraphCheck ($before -ceq $model.Parts[$paragraph.Part].Xml.OuterXml) ('Rejected deletion preserves complete XML: '+$paragraph.Id)
 }
 Assert-ParagraphRejected {Remove-MedicalTemplateParagraph $model 'word/document.xml#99999'} 'Unknown paragraph ID is rejected' 'не найден'
 Assert-ParagraphRejected {Remove-MedicalTemplateParagraph $model 'WORD/document.xml#1'} 'Paragraph ID matching is case sensitive' 'не найден'
 $bodyLast=Find-ParagraphTest $model 'Last ordinary';$previous=@($model.Paragraphs | Where-Object {$_.Part -ceq 'word/document.xml'})[-2]
 $selected=Remove-MedicalTemplateParagraph $model $bodyLast.Id
 Assert-ParagraphCheck ([object]::ReferenceEquals($selected.Node,$previous.Node)) 'Removing the last ordinary paragraph selects the previous paragraph'
 $headerFirst=Find-ParagraphTest $model 'Header first' 'word/header1.xml';$headerLast=Find-ParagraphTest $model 'Header last' 'word/header1.xml'
 $selected=Remove-MedicalTemplateParagraph $model $headerFirst.Id
 Assert-ParagraphCheck ([object]::ReferenceEquals($selected.Node,$headerLast.Node) -and $selected.Id -ceq 'word/header1.xml#1') 'Header paragraphs can be deleted and reindexed'
 $selected=Remove-MedicalTemplateParagraph $model $selected.Id
 Assert-ParagraphCheck ($selected.Text -ceq '' -and $selected.Node.ParentNode.LocalName -ceq 'hdr' -and @($model.Paragraphs | Where-Object {$_.Part -ceq 'word/header1.xml'}).Count -eq 1) 'The final header paragraph remains empty'
 $footer=Find-ParagraphTest $model 'Only footer' 'word/footer1.xml';$footerNamespaces=Get-MedicalEditorNamespace $footer.Node.OwnerDocument;$properties=$footer.Node.SelectSingleNode('./w:pPr',$footerNamespaces).OuterXml
 $selected=Remove-MedicalTemplateParagraph $model $footer.Id
 Assert-ParagraphCheck ($selected.Text -ceq '' -and $selected.Node.ParentNode.LocalName -ceq 'ftr' -and $selected.Node.SelectSingleNode('./w:pPr',$footerNamespaces).OuterXml -ceq $properties) 'The final footer paragraph remains empty with its paragraph style'
 $output=Join-Path $temp 'edited.docx';Write-MedicalTemplateModel $output $model;$reread=Read-MedicalTemplateModel $output
 Assert-MedicalEditorTemplateCoverage $config $reread
 Assert-ParagraphCheck ($reread.Paragraphs.Count -eq $model.Paragraphs.Count) 'Deleted and cleared paragraphs survive archive write and reload'
 Assert-ParagraphCheck ((Find-ParagraphTest $reread '' 'word/footer1.xml').Node.ParentNode.LocalName -ceq 'ftr') 'An empty required footer paragraph survives reload'
 $rereadNamespaces=Get-MedicalEditorNamespace $reread.Parts['word/document.xml'].Xml
 Assert-ParagraphCheck ($reread.Parts['word/document.xml'].Xml.SelectSingleNode('//w:p/w:pPr/w:sectPr/w:pgMar',$rereadNamespaces).GetAttribute('left',$script:ns) -ceq '4567') 'Section margins survive archive write and reload'
 foreach($entry in $model.Entries | Where-Object {$_.Name -notin $model.PartOrder}){
  $rereadEntry=@($reread.Entries | Where-Object {$_.Name -ceq $entry.Name})[0]
  Assert-ParagraphCheck ((Get-ParagraphHash $entry.Bytes) -ceq (Get-ParagraphHash $rereadEntry.Bytes)) ('Deletion preserves unrelated ZIP entry bytes: '+$entry.Name)
 }
 Assert-ParagraphCheck ((Get-ParagraphHash ([IO.File]::ReadAllBytes($source))) -ceq $sourceHash) 'All editing and export leave the original template file unchanged'
 $missing=Read-MedicalTemplateModel $source;$marker=Find-ParagraphTest $missing '{{TEXT}}';[void](Remove-MedicalTemplateParagraph $missing $marker.Id)
 Assert-ParagraphRejected {Assert-MedicalEditorTemplateCoverage $config $missing} 'Real export validation rejects a deleted required field marker' '{{TEXT}}'
 $missing=Read-MedicalTemplateModel $source;$marker=Find-ParagraphTest $missing '{{ADMISSION_DATETIME}}';[void](Remove-MedicalTemplateParagraph $missing $marker.Id)
 Assert-ParagraphRejected {Assert-MedicalEditorTemplateCoverage $config $missing} 'Real export validation rejects a deleted date and time marker' '{{ADMISSION_DATETIME}}'
 $single=New-ParagraphTestModel (Join-Path $temp 'single.docx') '<w:p w:rsidR="55555555"><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:t>Only body</w:t></w:r></w:p><w:sectPr><w:pgSz w:w="11906" w:h="16838"/></w:sectPr>'
 $only=Find-ParagraphTest $single 'Only body';$selected=Remove-MedicalTemplateParagraph $single $only.Id
 Assert-ParagraphCheck ($selected.Text -ceq '' -and [object]::ReferenceEquals($selected.Node,$only.Node) -and $selected.Node.NextSibling.LocalName -ceq 'sectPr') 'The final body paragraph remains empty before final section properties'
 Assert-ParagraphCheck ($selected.Node.GetAttribute('rsidR',$script:ns) -ceq '55555555') 'Clearing the final body paragraph retains paragraph attributes'
 $again=Remove-MedicalTemplateParagraph $single $selected.Id
 Assert-ParagraphCheck ($again.Id -ceq $selected.Id -and $again.Text -ceq '') 'Repeated deletion of a required empty paragraph leaves a valid paragraph'
 $unsafe=Read-MedicalTemplateModel $source;$unsafeParagraph=@($unsafe.Paragraphs | Where-Object {-not $_.Editable})[0];$unsafeParagraph.Editable=$true
 Assert-ParagraphRejected {Remove-MedicalTemplateParagraph $unsafe $unsafeParagraph.Id} 'Deletion rechecks XML restrictions even if a cached editable flag is stale' 'Удаление недоступно.'
 $textBox=New-ParagraphTestModel (Join-Path $temp 'textbox.docx') '<w:p><w:r><w:pict><w:txbxContent><w:p><w:r><w:t>Inside textbox</w:t></w:r></w:p></w:txbxContent></w:pict></w:r></w:p>'
 $inside=Find-ParagraphTest $textBox 'Inside textbox';Assert-ParagraphRejected {Remove-MedicalTemplateParagraph $textBox $inside.Id} 'Deletion inside an unsupported Word text box is refused' 'Выберите другое место.'
 foreach($name in @('Универсальный первичный осмотр.docx','Шаблон первичного осмотра.docx','template.dotx')){
  $originalPath=Join-Path $Project $name;$originalHash=Get-ParagraphHash ([IO.File]::ReadAllBytes($originalPath))
  $real=Read-MedicalTemplateModel $originalPath;$plain=@($real.Paragraphs | Where-Object {$_.Editable -and $_.Node.ParentNode.LocalName -in @('body','tc','hdr','ftr') -and $_.Text})[0]
  Assert-ParagraphCheck ($null -ne $plain) ('Real shipped template contains an editable paragraph: '+$name)
  $plainNode=$plain.Node;[void](Remove-MedicalTemplateParagraph $real $plain.Id)
  Assert-ParagraphCheck ($null -eq $plainNode.ParentNode -or (Get-MedicalEditorParagraphText $plainNode (Get-MedicalEditorNamespace $plainNode.OwnerDocument)) -ceq '') ('Real shipped template paragraph is removed or cleared: '+$name)
  $copy=Join-Path $temp ('real-'+$name);Write-MedicalTemplateModel $copy $real;$verified=Read-MedicalTemplateModel $copy
  Assert-ParagraphCheck ($verified.TemplateExtension -ceq [IO.Path]::GetExtension($name)) ('Real shipped template format survives deletion and reload: '+$name)
  Assert-ParagraphCheck ((Get-ParagraphHash ([IO.File]::ReadAllBytes($originalPath))) -ceq $originalHash) ('Real shipped original is unchanged: '+$name)
 }
 Write-Output ('TOTAL '+$script:checks+' checks passed')
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
