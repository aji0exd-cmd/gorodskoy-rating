﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.Windows.Forms.Application]::EnableVisualStyles()
$ErrorActionPreference='Stop'
$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'

. (Join-Path $PSScriptRoot 'ui-v57.ps1')

$script:fields=@()
$script:source=''
$script:controls=@()
$script:patientName=''
$script:patientAddress=''
$script:patientBirthYear=''
$script:addressBase=''
$script:addressStreet=''
$script:addressHouse=''
$script:addressApartment=''
$script:patientNameControl=$null
$script:patientAddressControl=$null
$script:patientBirthControl=$null
# Custom dropdown: mouse wheel scrolls the form, never changes the selected option.
Add-Type -ReferencedAssemblies 'System.Windows.Forms','System.Drawing' -TypeDefinition @'
using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;
public class SafeComboBox : ComboBox {
    private const int WM_MOUSEWHEEL = 0x020A;
    private const int WM_MOUSEHWHEEL = 0x020E;
    protected override void WndProc(ref Message m) {
        if (m.Msg == WM_MOUSEWHEEL || m.Msg == WM_MOUSEHWHEEL) {
            Control p = Parent;
            while (p != null && !(p is ScrollableControl && ((ScrollableControl)p).AutoScroll)) p = p.Parent;
            if (p != null && m.Msg == WM_MOUSEWHEEL)
                FormWheelFilter.Scroll((ScrollableControl)p, (short)((m.WParam.ToInt64() >> 16) & 0xffff));
            return;
        }
        base.WndProc(ref m);
    }
}
// Consume wheel messages before nested text boxes can swallow them.
// No SendMessage: forwarding native wheel messages can re-enter child controls.
public sealed class FormWheelFilter : IMessageFilter {
    private readonly ScrollableControl panel;
    private int remainder;
    public FormWheelFilter(ScrollableControl target) { panel = target; }
    [DllImport("user32.dll")]
    private static extern IntPtr WindowFromPoint(System.Drawing.Point point);
    public bool PreFilterMessage(ref Message m) {
        if (m.Msg != 0x020A || panel.IsDisposed || !panel.Visible || !panel.Enabled) return false;
        Form owner = panel.FindForm();
        if (owner == null || !owner.Enabled || !owner.ContainsFocus) return false;
        Control under = Control.FromChildHandle(WindowFromPoint(Control.MousePosition));
        if (under != panel && (under == null || !panel.Contains(under))) return false;
        // Ctrl+wheel keeps native scrolling inside a long text field.
        if ((Control.ModifierKeys & Keys.Control) != 0 && under is TextBoxBase) return false;
        ComboBox combo = under as ComboBox;
        if (combo != null && combo.DroppedDown) return false;
        remainder += (short)((m.WParam.ToInt64() >> 16) & 0xffff);
        int steps = remainder / 120;
        remainder %= 120;
        if (steps != 0) Scroll(panel, steps * 120);
        return true;
    }
    public static void Scroll(ScrollableControl target, int delta) {
        int lines = SystemInformation.MouseWheelScrollLines;
        if (lines == 0) return;
        int step = lines < 0 ? target.ClientSize.Height : Math.Max(1, lines) * 20;
        int current = -target.AutoScrollPosition.Y;
        int maximum = Math.Max(0, target.DisplayRectangle.Height - target.ClientSize.Height);
        int next = Math.Max(0, Math.Min(maximum, current - (delta / 120) * step));
        if (current != next)
            target.AutoScrollPosition = new System.Drawing.Point(-target.AutoScrollPosition.X, next);
    }
}

'@
function Get-XmlPart($zip,$name) {
 $entry=$zip.GetEntry($name); if(-not $entry){return $null}
 $r=[System.IO.StreamReader]::new($entry.Open()); try {$raw=$r.ReadToEnd()} finally {$r.Dispose()}
 $x=New-Object System.Xml.XmlDocument; $x.PreserveWhitespace=$true; $x.LoadXml($raw); return $x
}
# v48: bind by paragraph and ordinal within that paragraph, never by global position.
function Get-InitialExamBindings($x){
 $n=[System.Xml.XmlNamespaceManager]::new($x.NameTable);$n.AddNamespace('w',$script:ns)
 $all=@($x.SelectNodes('//w:sdt',$n));$result=@{}
 foreach($p in $x.SelectNodes('//w:p',$n)){
  $text=(($p.SelectNodes('.//w:t',$n) | ForEach-Object {$_.InnerText}) -join '').Trim()
  $keys=@()
  if($text -match '^Жалобы\s*:'){$keys=@('complaints')}
  elseif($text -match '^Анамнез настоящего заболевания\s*:'){
   $keys=@('alcoholDays','lastAlcohol','alcoholOutcome','complaintsRepeat')
  }else{continue}
  $local=@($p.SelectNodes('.//w:sdt[w:sdtPr/w:dropDownList or w:sdtPr/w:comboBox]',$n))
  # Unexpected template structures remain available in the generic v47 editor.
  if($local.Count -ne $keys.Count){continue}
  for($j=0;$j -lt $local.Count;$j++){
   for($i=0;$i -lt $all.Count;$i++){
    if([object]::ReferenceEquals($local[$j],$all[$i])){
     if(-not $result.ContainsKey($keys[$j])){$result[$keys[$j]]=$i}
     break
    }
   }
  }
 }
 # Never hide the fourth control unless there is an authoritative complaints list.
 if(-not $result.ContainsKey('complaints')){[void]$result.Remove('complaintsRepeat')}
 return $result
}
function Sync-InitialExamValues($values){
 if($script:stage -ne 'initial'){return}
 $sourceIndex=-1;$repeatIndex=-1
 for($j=0;$j -lt $script:fields.Count;$j++){
  if($script:fields[$j].ClinicalKey -eq 'complaints'){$sourceIndex=$j}
  elseif($script:fields[$j].ClinicalKey -eq 'complaintsRepeat'){$repeatIndex=$j}
 }
 if($sourceIndex -lt 0 -or $repeatIndex -lt 0){return}
 if($null -ne $values){
  $values[$repeatIndex]=[string]$values[$sourceIndex]
  $script:fields[$repeatIndex].Value=[string]$values[$sourceIndex]
 }elseif($sourceIndex -lt $script:controls.Count -and $script:controls[$sourceIndex]){
  $script:fields[$repeatIndex].Value=[string]$script:controls[$sourceIndex].Text
 }
}
function Read-Template($path) {
 $script:fields=@(); $script:source=$path
 $script:patientName=''; $script:patientAddress=''
$script:patientBirthYear=''
 $zip=[System.IO.Compression.ZipFile]::OpenRead($path)
 try {
  $x=Get-XmlPart $zip 'word/document.xml'; if(-not $x){throw 'Файл не содержит документ Word.'}
  $n=[System.Xml.XmlNamespaceManager]::new($x.NameTable);$n.AddNamespace('w',$script:ns)
  $ps=$x.SelectNodes('//w:p',$n)
  foreach($para in $ps){
   $txt=(($para.SelectNodes('.//w:t',$n) | ForEach-Object {$_.InnerText}) -join '')
   if(-not $script:patientName -and $txt -match 'Ф\.И\.О\s*:\s*(.*?)\s+г\.р\.'){$script:patientName=$Matches[1].Trim()}
   if(-not $script:patientBirthYear -and $txt -match 'г\.р\.\s*(\d{2}\.\d{2}\.\d{4})'){$script:patientBirthYear=$Matches[1]}
   if(-not $script:patientAddress -and $txt -match 'Место регистрации:\s*(.+)'){
    $v=$Matches[1].Trim();if($v -ne 'Выберите элемент.'){$script:patientAddress=$v}
   }
  }
  # A newly opened template is a blank form, not a previously filled patient record.
  if($script:openingFreshTemplate){
   $script:patientName='';$script:patientBirthYear='';$script:patientAddress=''
  }
  # Assign every content control to the nearest preceding clinical heading in document order.
  $script:sectionByIndex=@{}
  $currentSection='Поступление и экспертный анамнез'; $controlNumber=0
  foreach($paragraph in $ps){
   $paragraphText=(($paragraph.SelectNodes('.//w:t',$n) | ForEach-Object {$_.InnerText}) -join '').Trim()
   if($paragraphText -match '^Жалобы\s*:'){$currentSection='Жалобы'}
   elseif($paragraphText -match '^Эпид\.?\s*анамнез\s*:'){$currentSection='Эпид. анамнез'}
   elseif($paragraphText -match '^Анамнез настоящего заболевания\s*:'){$currentSection='Анамнез настоящего заболевания'}
   elseif($paragraphText -match '^Соматический статус\s*:'){$currentSection='Соматический статус'}
   elseif($paragraphText -match '^Неврологический статус\s*:'){$currentSection='Неврологический статус'}
   elseif($paragraphText -match '^Психический статус\s*:'){$currentSection='Психический статус'}
   elseif($paragraphText -match '^На основании осмотра|^Диагноз\s*:'){$currentSection='Диагноз'}
   elseif($paragraphText -match '^План обследования\s*:'){$currentSection='План обследования'}
   elseif($paragraphText -match '^Назначения\s*:|^Инфузионная терапия\s*:|^В систему\s*:|^Перорально\s*:'){$currentSection='Назначения'}
   foreach($contentControl in $paragraph.SelectNodes('.//w:sdt',$n)){
    $controlNumber++
    $script:sectionByIndex[$controlNumber]=$currentSection
   }
  }
  # Identify the four existing Word dropdowns inside the hospitalization sentence.
  $script:hospitalFieldIndices=@{}
  $hospitalParagraph=$null
  foreach($candidate in $ps){
   $candidateText=(($candidate.SelectNodes('.//w:t',$n) | ForEach-Object {$_.InnerText}) -join '')
   if($candidateText -match 'Поступает на лечение'){$hospitalParagraph=$candidate;break}
  }
  $hospitalSdtNodes=@()
  if($hospitalParagraph){$hospitalSdtNodes=@($hospitalParagraph.SelectNodes('.//w:sdt',$n))}
  $clinicalBindings=@{}
  if($script:stage -eq 'initial'){$clinicalBindings=Get-InitialExamBindings $x}
  $nodes=$x.SelectNodes('//w:sdt',$n); $i=0
  foreach($s in $nodes) {
   $i++;$pr=$s.SelectSingleNode('./w:sdtPr',$n)
   $hospitalKey=''
   for($hi=0;$hi -lt $hospitalSdtNodes.Count;$hi++){
    if([object]::ReferenceEquals($s,$hospitalSdtNodes[$hi])){
     $hospitalKey=@('count','referred','delivered','order')[$hi]
     $script:hospitalFieldIndices[$hospitalKey]=$i-1
     break
    }
   }

   if(-not $hospitalKey){
    $parentPara=$s.SelectSingleNode('ancestor::w:p[1]',$n)
    if($parentPara){
     $paraText=(($parentPara.SelectNodes('.//w:t',$n) | ForEach-Object {$_.InnerText}) -join '')
     if($paraText -match 'Поступает на лечение'){
      $paraControls=@($parentPara.SelectNodes('.//w:sdt',$n))
      for($hi=0;$hi -lt [Math]::Min(4,$paraControls.Count);$hi++){
       if([object]::ReferenceEquals($s,$paraControls[$hi])){$hospitalKey=@('count','referred','delivered','order')[$hi];break}
      }
     }
    }
   }
   $alias=$pr.SelectSingleNode('./w:alias',$n); $tag=$pr.SelectSingleNode('./w:tag',$n)
   $label=''; if($alias){$label=$alias.GetAttribute('val',$script:ns)}; if(-not $label -and $tag){$label=$tag.GetAttribute('val',$script:ns)}
   $p=$s.SelectSingleNode('ancestor::w:p[1]',$n); $context=''
   if($p){$ts=$p.SelectNodes('.//w:t',$n);$context=($ts | ForEach-Object {$_.InnerText}) -join ''; $context=$context.Replace('Выберите элемент.','___').Trim();if($context.Length -gt 105){$context=$context.Substring(0,105)+'…'}}
   if(-not $label){$label='Поле '+$i}
   $options=@();$items=$pr.SelectNodes('.//w:listItem',$n)
   foreach($it in $items){$v=$it.GetAttribute('displayText',$script:ns);if(-not $v){$v=$it.GetAttribute('value',$script:ns)};if($v -and $v -ne 'Выберите элемент.'){$options+= $v}}
   $t=$s.SelectNodes('.//w:sdtContent//w:t',$n);$current=($t | ForEach-Object {$_.InnerText}) -join ''
   if($current -match '^Выберите элемент\.?$'){$current=''}
   $isAddress=($context -match 'Место регистрации:')
   $stableKey=if($tag){$tag.GetAttribute('val',$script:ns)}else{''}
   if(-not $stableKey -and $alias){$stableKey=$alias.GetAttribute('val',$script:ns)}
   if(-not $stableKey){$stableKey=($context -replace '\s+',' ').Trim()}
   if(-not $stableKey){$stableKey='position:'+ $i}
   $clinicalKey=''
   foreach($bindingKey in $clinicalBindings.Keys){
    if($clinicalBindings[$bindingKey] -eq ($i-1)){$clinicalKey=[string]$bindingKey;break}
   }
   if($clinicalKey){$stableKey='initial-exam:'+ $clinicalKey}
   $script:fields+= [pscustomobject]@{Index=$i;ClinicalKey=$clinicalKey;Key=$stableKey;Label=$label;Context=$context;Options=$options;Value=$current;IsAddress=$isAddress;HospitalKey=$hospitalKey;Section=$(if($script:sectionByIndex.ContainsKey($i)){$script:sectionByIndex[$i]}else{'Прочее'})}
  }
 } finally {$zip.Dispose()}
}
function Set-SdtValue($x,$fieldValues){
 Sync-InitialExamValues $fieldValues
 $preserveIndices=@()
 if($script:stage -eq 'initial'){$preserveIndices=@((Get-InitialExamBindings $x).Values)}
 $n=[System.Xml.XmlNamespaceManager]::new($x.NameTable);$n.AddNamespace('w',$script:ns)
 $nodes=$x.SelectNodes('//w:sdt',$n)
 for($i=0;$i -lt $nodes.Count;$i++){
  $s=$nodes.Item($i);$value=[string]$fieldValues[$i]
  if([string]::IsNullOrWhiteSpace($value)){continue}
  $content=$s.SelectSingleNode('./w:sdtContent',$n);if(-not $content){continue}
  $texts=$content.SelectNodes('.//w:t',$n)
  if($texts.Count -gt 0){
   $texts.Item(0).InnerText=$value
   $texts.Item(0).SetAttribute('xml:space','preserve')
   for($j=1;$j -lt $texts.Count;$j++){$texts.Item($j).InnerText=''}
  } else {
   # For inline controls insert an inline run, not a new paragraph.
   $r=$x.CreateElement('w','r',$script:ns);$t=$x.CreateElement('w','t',$script:ns)
   $t.InnerText=$value;$t.SetAttribute('xml:space','preserve')
   [void]$r.AppendChild($t);[void]$content.AppendChild($r)
  }
  if($preserveIndices -notcontains $i){
  # Placeholder style a3 is visually different from the clinical text.
  # Apply the same Times New Roman 12pt font as the source paragraph.
  foreach($r in $content.SelectNodes('.//w:r',$n)){
   $rPr=$r.SelectSingleNode('./w:rPr',$n)
   if(-not $rPr){$rPr=$x.CreateElement('w','rPr',$script:ns);[void]$r.PrependChild($rPr)}
   $rStyle=$rPr.SelectSingleNode('./w:rStyle',$n)
   if($rStyle){[void]$rPr.RemoveChild($rStyle)}
   $fonts=$rPr.SelectSingleNode('./w:rFonts',$n)
   if(-not $fonts){$fonts=$x.CreateElement('w','rFonts',$script:ns);[void]$rPr.AppendChild($fonts)}
   foreach($a in @('ascii','hAnsi','cs','eastAsia')){$fonts.SetAttribute($a,$script:ns,'Times New Roman')}
   foreach($szName in @('sz','szCs')){
    $sz=$rPr.SelectSingleNode('./w:'+$szName,$n)
    if(-not $sz){$sz=$x.CreateElement('w',$szName,$script:ns);[void]$rPr.AppendChild($sz)}
    $sz.SetAttribute('val',$script:ns,'24')
   }
  }
  } # v48: original run properties are retained for complaints and anamnesis.
  $show=$s.SelectSingleNode('./w:sdtPr/w:showingPlcHdr',$n);if($show){[void]$show.ParentNode.RemoveChild($show)}
 }
 # The four dropdowns are adjacent inside the hospitalization sentence.
 # The second option sometimes ends in whitespace; the third includes a comma,
 # while the template itself already contains a comma. Normalize boundaries.
 foreach($p in $x.SelectNodes('//w:p',$n)){
  $paragraphText=(($p.SelectNodes('.//w:t',$n) | ForEach-Object {$_.InnerText}) -join '')
  if($paragraphText -notmatch 'Поступает на лечение в наркологическое отделение'){continue}
  $h=@($p.SelectNodes('./w:sdt',$n));if($h.Count -lt 4){continue}
  $second=$h[1].SelectSingleNode('./w:sdtContent//w:t',$n)
  $third=$h[2].SelectSingleNode('./w:sdtContent//w:t',$n)
  if($second -and $second.InnerText -ne 'Выберите элемент.'){
   $second.InnerText=$second.InnerText.TrimEnd()+' '
   $second.SetAttribute('xml:space','preserve')
  }
  if($third -and $third.InnerText -ne 'Выберите элемент.'){
   $third.InnerText=$third.InnerText.Trim().TrimEnd(',',';','.')
   $third.SetAttribute('xml:space','preserve')
  }
  # Only the fixed comma between third and fourth is retained.
  break
 }
}
function Set-PatientDetails($x,$name,$birthYear,$address,$examDate){
 $n=[System.Xml.XmlNamespaceManager]::new($x.NameTable);$n.AddNamespace('w',$script:ns)
 # Keep the existing title and logo; only fill the date text in the header.
 $dateParagraph=$x.SelectSingleNode('//w:body/w:p[1]',$n)
 if($dateParagraph -and $examDate){
  $dateTexts=$dateParagraph.SelectNodes('.//w:t',$n)
  if($dateTexts.Count -gt 0){$dateTexts.Item(0).InnerText='Дата: '+$examDate}
  if($dateTexts.Count -gt 1){$dateTexts.Item(1).InnerText='            '}
 }
 foreach($p in $x.SelectNodes('//w:p',$n)){
  $all=(($p.SelectNodes('.//w:t',$n) | ForEach-Object {$_.InnerText}) -join '')
  # Keep the patient's name and date of birth in the original Word paragraphs.
  # The new template already contains the literal suffix "г.р."; do not append it.
  if($all -match 'Ф\.И\.О\s*:' -and $all -notmatch 'Дата рождения:'){
   $nameTexts=$p.SelectNodes('./w:r/w:t',$n)
   if($nameTexts.Count -gt 0){
    $nameTexts.Item(0).InnerText='Ф.И.О.: '+$name
    $nameTexts.Item(0).SetAttribute('xml:space','preserve')
    for($j=1;$j -lt $nameTexts.Count;$j++){$nameTexts.Item($j).InnerText=''}
   }
  }
  if($all -match 'Дата рождения\s*:'){
   $birthTexts=$p.SelectNodes('./w:r/w:t',$n)
   if($birthTexts.Count -gt 0){
    $birthTexts.Item(0).InnerText='Дата рождения: '+$birthYear+' г.р.'
    $birthTexts.Item(0).SetAttribute('xml:space','preserve')
    for($j=1;$j -lt $birthTexts.Count;$j++){$birthTexts.Item($j).InnerText=''}
    # Match the existing template typography for this one paragraph.
    foreach($run in $p.SelectNodes('./w:r',$n)){
     $rPr=$run.SelectSingleNode('./w:rPr',$n)
     if(-not $rPr){$rPr=$x.CreateElement('w','rPr',$script:ns);[void]$run.PrependChild($rPr)}
     $fonts=$rPr.SelectSingleNode('./w:rFonts',$n)
     if(-not $fonts){$fonts=$x.CreateElement('w','rFonts',$script:ns);[void]$rPr.AppendChild($fonts)}
     foreach($attr in @('ascii','hAnsi','cs','eastAsia')){$fonts.SetAttribute($attr,$script:ns,'Times New Roman')}
     foreach($tag in @('sz','szCs')){
      $sz=$rPr.SelectSingleNode('./w:'+$tag,$n)
      if(-not $sz){$sz=$x.CreateElement('w',$tag,$script:ns);[void]$rPr.AppendChild($sz)}
      $sz.SetAttribute('val',$script:ns,'24')
     }
    }
   }
  }
  if($address -and $all -match 'Место регистрации:'){
   $sdt=$p.SelectSingleNode('./w:sdt',$n)
   if($sdt){
    $ts=$sdt.SelectNodes('.//w:sdtContent//w:t',$n)
    if($ts.Count -gt 0){$ts.Item(0).InnerText=$address;for($j=1;$j -lt $ts.Count;$j++){$ts.Item($j).InnerText=''}}
    $show=$sdt.SelectSingleNode('./w:sdtPr/w:showingPlcHdr',$n)
    if($show){[void]$show.ParentNode.RemoveChild($show)}
   }else{
    foreach($t in $p.SelectNodes('./w:r/w:t',$n)){
     if($t.InnerText -match 'Место регистрации:'){$t.InnerText='Место регистрации: '+$address;break}
    }
   }
  }
 }
}
function Save-Document($output,$values){
 $src=[System.IO.Compression.ZipFile]::OpenRead($script:source)
 $dest=[System.IO.Compression.ZipFile]::Open($output,[System.IO.Compression.ZipArchiveMode]::Create)
 try {
  foreach($entry in $src.Entries){
   $new=$dest.CreateEntry($entry.FullName,[System.IO.Compression.CompressionLevel]::Optimal)
   $input=$entry.Open();$outputStream=$new.Open()
   try {
    if($entry.FullName -eq 'word/document.xml'){
     $x=Get-XmlPart $src 'word/document.xml';Set-SdtValue $x $values;Set-PatientDetails $x $script:patientName $script:patientBirthYear $script:patientAddress $script:admissionControl.Value.ToString('dd.MM.yyyy')
     $bytes=[System.Text.UTF8Encoding]::new($false).GetBytes($x.OuterXml)
     $outputStream.Write($bytes,0,$bytes.Length)
    } elseif($entry.FullName -eq '[Content_Types].xml'){
     $r=[System.IO.StreamReader]::new($input);$raw=$r.ReadToEnd()
     $raw=$raw.Replace('application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml','application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml')
     $bytes=[System.Text.UTF8Encoding]::new($false).GetBytes($raw);$outputStream.Write($bytes,0,$bytes.Length)
    } else {$input.CopyTo($outputStream)}
   } finally {$outputStream.Dispose();$input.Dispose()}
  }
 } finally {$dest.Dispose();$src.Dispose()}
}
. (Join-Path $PSScriptRoot 'universal.ps1')
. (Join-Path $PSScriptRoot 'universal-ui.ps1')
. (Join-Path $PSScriptRoot 'document-actions.ps1')
. (Join-Path $PSScriptRoot 'workspace-settings.ps1')
. (Join-Path $PSScriptRoot 'forms-v59.ps1')
. (Join-Path $PSScriptRoot 'template-editor-v59.ps1')
. (Join-Path $PSScriptRoot 'template-editor-operations-v61.ps1')
. (Join-Path $PSScriptRoot 'template-format-v62.ps1')
. (Join-Path $PSScriptRoot 'template-format-ui-v62.ps1')
. (Join-Path $PSScriptRoot 'template-layout-preview-v62.ps1')
. (Join-Path $PSScriptRoot 'word-preview-v62.ps1')
. (Join-Path $PSScriptRoot 'forms-ui-v59.ps1')
$script:universalConfig=Load-UniversalConfig
$form=New-Object System.Windows.Forms.Form
$form.Text='Медицинский конструктор v62 — рабочее место специалиста'
$form.Size=New-Object System.Drawing.Size(1240,860)
$form.StartPosition='CenterScreen';$form.MinimumSize=New-Object System.Drawing.Size(1080,680)
$form.Font=New-Object System.Drawing.Font('Segoe UI',10)
# Compact command toolbar: separate from patient data and scrolling medical form.
$top=New-Object System.Windows.Forms.Panel;$top.Dock='Fill';$top.Height=218;$form.Controls.Add($top)
$brand=New-Object System.Windows.Forms.Label;$brand.Text='✚  Медицинский конструктор';$brand.Font=New-Object System.Drawing.Font('Segoe UI',12,[System.Drawing.FontStyle]::Bold);$brand.SetBounds(20,7,700,26);$top.Controls.Add($brand)
$version=New-Object System.Windows.Forms.Label;$version.Text='v56  •  Рабочее место специалиста';$version.SetBounds(760,10,310,24);$version.Anchor='Top,Right';$version.TextAlign='MiddleRight';$top.Controls.Add($version)
$open=New-Object System.Windows.Forms.Button;$open.Text='Открыть шаблон';$open.SetBounds(20,39,215,38);$top.Controls.Add($open)
$save=New-Object System.Windows.Forms.Button;$save.Text='Сохранить документ .docx';$save.SetBounds(248,39,235,38);$save.Enabled=$false;$top.Controls.Add($save)
$patientsButton=New-Object System.Windows.Forms.Button;$patientsButton.Text='Проводник / База пациентов';$patientsButton.SetBounds(496,39,300,38);$top.Controls.Add($patientsButton)
$script:progressLabel=New-Object System.Windows.Forms.Label;$script:progressLabel.Text='Заполнено: 0 / 0';$script:progressLabel.TextAlign='MiddleRight';$script:progressLabel.SetBounds(760,136,305,26);$script:progressLabel.Anchor='Top,Right';$top.Controls.Add($script:progressLabel)
$info=New-Object System.Windows.Forms.Label;$info.Text='Откройте шаблон, заполните поля и сохраните документ.';$info.Visible=$false;$top.Controls.Add($info)

# A hospitalization is one independent case with three document stages.
$script:stage='initial'
$script:caseFolder=''
$script:caseFile=''
$script:admissionDate=(Get-Date).ToString('yyyy-MM-dd')
$script:stageData=@{}
$script:stageTemplates=@{initial=(Get-UniversalTemplatePath);diary='';discharge=''}
$script:diaryIndex=1
$script:diaryRecords=@()
$script:initialByLabel=@{}
$stageInitial=New-Object System.Windows.Forms.Button;$stageInitial.Text='Первичный осмотр';$stageInitial.SetBounds(20,90,190,42);$top.Controls.Add($stageInitial)
$stageDiary=New-Object System.Windows.Forms.Button;$stageDiary.Text='Дневники наблюдения';$stageDiary.SetBounds(218,90,210,42);$top.Controls.Add($stageDiary)
$stageDischarge=New-Object System.Windows.Forms.Button;$stageDischarge.Text='Выписной эпикриз';$stageDischarge.SetBounds(436,90,205,42);$top.Controls.Add($stageDischarge)
$caseSave=New-Object System.Windows.Forms.Button;$caseSave.Text='Сохранить карту';$caseSave.SetBounds(649,90,150,42);$top.Controls.Add($caseSave)
$newDiary=New-Object System.Windows.Forms.Button;$newDiary.Text='+ Дневник';$newDiary.SetBounds(807,90,125,42);$newDiary.Visible=$false;$top.Controls.Add($newDiary)
$caseOpen=New-Object System.Windows.Forms.Button;$caseOpen.Text='Открыть карту';$caseOpen.SetBounds(940,90,135,42);$top.Controls.Add($caseOpen)

$configure=New-Object System.Windows.Forms.Button;$configure.Text='Настроить форму';$configure.SetBounds(20,137,195,30);$top.Controls.Add($configure)
$configure.Add_Click({Invoke-MedicalFormTemplateEditor})
$openFormButton=New-Object Windows.Forms.Button;$openFormButton.Text='Открыть форму';$openFormButton.Add_Click({Invoke-MedicalOpenForm})
$saveFormButton=New-Object Windows.Forms.Button;$saveFormButton.Text='Сохранить форму';$saveFormButton.Add_Click({Invoke-MedicalSaveForm})
$fieldSettingsButton=New-Object Windows.Forms.Button;$fieldSettingsButton.Text='Настройки полей';$fieldSettingsButton.Add_Click({if(-not $script:medicalWorkspaceReady){Invoke-MedicalNewForm;return};try{Show-UniversalSettings}catch{[void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'Настройки полей')}})
$documentFontButton=New-Object Windows.Forms.Button;$documentFontButton.Text='Шрифт документа';$documentFontButton.Add_Click({Show-DocumentFontSettings})
$newInitial=New-Object System.Windows.Forms.Button;$newInitial.Text='Новый осмотр';$newInitial.SetBounds(226,137,175,30);$top.Controls.Add($newInitial)
$newInitial.Add_Click({Invoke-MedicalNewForm})
$templateStatus=New-Object System.Windows.Forms.Label;$templateStatus.SetBounds(415,142,325,25);$templateStatus.AutoEllipsis=$true;$top.Controls.Add($templateStatus)
$previewButton=New-Object System.Windows.Forms.Button;$previewButton.Text='Предпросмотр документа';$previewButton.SetBounds(20,176,250,32);$top.Controls.Add($previewButton)
$printButton=New-Object System.Windows.Forms.Button;$printButton.Text='Печать документа';$printButton.SetBounds(282,176,205,32);$top.Controls.Add($printButton)
$filePreviewButton=New-Object System.Windows.Forms.Button;$filePreviewButton.Text='Просмотреть файл…';$filePreviewButton.SetBounds(499,176,220,32);$top.Controls.Add($filePreviewButton)
$previewButton.Add_Click({try{Show-CurrentDocumentAction 'Preview'}catch{[void][System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Предпросмотр')}})
$printButton.Add_Click({try{Show-CurrentDocumentAction 'Print'}catch{[void][System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Печать')}})
$filePreviewButton.Add_Click({
 $picker=New-Object System.Windows.Forms.OpenFileDialog;$picker.Filter='Документы Word|*.docx;*.dotx'
 try{if($picker.ShowDialog() -eq 'OK'){Start-WordDocumentAction $picker.FileName 'Preview'}}catch{[void][System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Предпросмотр файла')}finally{$picker.Dispose()}
})
. (Join-Path $PSScriptRoot 'patients.ps1')
$patientsButton.Add_Click({
 try {
  $script:pendingDocument=$null
  Show-Patients
  if($script:pendingDocument){
   $selectedPath=$script:pendingDocument
   $script:pendingDocument=$null
   Open-UniversalDocument $selectedPath
  }
 }catch{[System.Windows.Forms.MessageBox]::Show($_.Exception.ToString(),'Ошибка открытия документа')|Out-Null}
})
Set-DarkTheme $form
# Patient demographics live inside the same scrolling form as clinical fields.
# Only the Windows-style command toolbar is fixed.
$script:admissionControl=New-Object System.Windows.Forms.DateTimePicker
$script:admissionControl.Format=[System.Windows.Forms.DateTimePickerFormat]::Custom
$script:admissionControl.CustomFormat='dd.MM.yyyy  HH:mm'
$script:admissionControl.Value=Get-Date
$script:patientNameControl=New-Object System.Windows.Forms.TextBox
$script:patientBirthControl=New-Object System.Windows.Forms.TextBox
$script:patientBirthControl.MaxLength=10
$script:patientAddressControl=New-Object SafeComboBox
$script:patientAddressControl.DropDownStyle='DropDown'
$script:patientAddressControl.AutoCompleteMode='SuggestAppend'
$script:patientAddressControl.AutoCompleteSource='ListItems'
$script:patientAddressControl.Enabled=$false
# Additional address components, kept in the same scrollable clinical form.
$script:streetControl=New-Object System.Windows.Forms.TextBox
$script:houseControl=New-Object System.Windows.Forms.TextBox
$script:apartmentControl=New-Object System.Windows.Forms.TextBox
$script:addressPreview=New-Object System.Windows.Forms.Label
$script:addressPreview.AutoEllipsis=$true
function Get-FullRegistration {
 if($script:stage -eq 'initial'){return ([string]$script:patientAddressControl.Text).Trim()}
 $base=([string]$script:patientAddressControl.Text).Trim()
 # Remove template placeholders before inserting the supplied components.
 $base=$base -replace '(?i)\s*,?\s*ул\.?\s*[_\s]*', '' -replace '(?i)\s*,?\s*д\.?\s*[_\s]*', '' -replace '(?i)\s*,?\s*кв\.?\s*[_\s]*', ''
 $base=($base -replace '\\,', ',').Trim(' ', ',','.', ';')
 $street=([string]$script:streetControl.Text).Trim()
 $house=([string]$script:houseControl.Text).Trim()
 $apartment=([string]$script:apartmentControl.Text).Trim()
 $parts=New-Object 'System.Collections.Generic.List[string]'
 if($base){$parts.Add($base)}
 if($street){$parts.Add('ул. '+$street)}
 if($house){$parts.Add('д. '+$house)}
 if($apartment){$parts.Add('кв. '+$apartment)}
 return ($parts -join ', ')
}
function Update-AddressPreview { $script:addressPreview.Text='Итоговый адрес: '+(Get-FullRegistration) }
foreach($addressInput in @($script:streetControl,$script:houseControl,$script:apartmentControl)){
 $addressInput.Add_TextChanged({Update-AddressPreview})
}
$script:patientAddressControl.Add_TextChanged({Update-AddressPreview})
$addressToggle=New-Object System.Windows.Forms.Button
$addressToggle.Text='Изменить'
$addressToggle.Add_Click({
 if($script:patientAddressControl.Enabled){
  $script:patientAddressControl.Enabled=$false
  foreach($c in @($script:streetControl,$script:houseControl,$script:apartmentControl)){$c.Enabled=$false}
  $this.Text='Изменить адрес'
 } else {
  $script:patientAddressControl.Enabled=$true
  foreach($c in @($script:streetControl,$script:houseControl,$script:apartmentControl)){$c.Enabled=$true}
  $this.Text='Закрепить';$script:patientAddressControl.Focus()
 }
})
$panel=New-Object System.Windows.Forms.Panel
$panel.AutoScroll=$true
$script:formWheelFilter=New-Object FormWheelFilter($panel)
[Windows.Forms.Application]::AddMessageFilter($script:formWheelFilter)
$form.Add_FormClosed({[Windows.Forms.Application]::RemoveMessageFilter($script:formWheelFilter)})
$panel.Add_Resize({Resize-UniversalForm})
$layout=New-Object System.Windows.Forms.TableLayoutPanel
$layout.Dock='Fill';$layout.ColumnCount=1;$layout.RowCount=2
$layout.Margin=New-Object System.Windows.Forms.Padding(0)
$layout.Padding=New-Object System.Windows.Forms.Padding(0)
[void]$layout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
[void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,218)))
[void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent,100)))
$form.Controls.Remove($top)
$top.Dock='Fill';$top.Margin=New-Object System.Windows.Forms.Padding(0)
$panel.Dock='Fill';$panel.Margin=New-Object System.Windows.Forms.Padding(0)
$layout.Controls.Add($top,0,0)
$layout.Controls.Add($panel,0,1)
$form.Controls.Add($layout)

function Select-ClinicalSection {
 # v36: all medical sections stay visible in one scrollable workspace.
 foreach($entry in $script:sectionElements){$entry.Control.Visible=$true}
}
function Get-QuestionText($field) {
 switch([string]$field.ClinicalKey){
  'alcoholDays' {return 'Количество дней употребления алкоголя'}
  'lastAlcohol' {return 'Последний приём алкоголя'}
  'alcoholOutcome' {return 'Исход употребления алкоголя'}
 }

 $name=([string]$field.Label).Trim()
 if($name -match '^Поле\s*\d+$' -or -not $name){
  $name=([string]$field.Context).Replace('___','').Replace('Выберите элемент.','').Trim()
  $name=$name -replace '\s{2,}',' '
  if($name -match '^(.{1,100}?:)'){$name=$Matches[1]}
 }
 $name=$name -replace '^\s*\d+[.\)]\s*',''
 if(-not $name){$name='Ответ'}
 return $name
}
$script:hospitalControls=@{}
foreach($key in @('count','referred','delivered','order')){
 $combo=New-Object SafeComboBox
 $combo.DropDownStyle=[System.Windows.Forms.ComboBoxStyle]::DropDownList
 $script:hospitalControls[$key]=$combo
}
function Get-HospitalizationValues {
 $result=@{}
 foreach($key in $script:hospitalControls.Keys){$result[$key]=[string]$script:hospitalControls[$key].Text}
 return $result
}
function Show-Fields {
 if($script:stage -eq 'initial'){Show-UniversalInitial;return}
 Remove-MedicalEndAction
 $panel.Controls.Clear();$script:controls=@();$script:sectionElements=New-Object System.Collections.ArrayList;$y=12
 $script:buildingSections=$true
 $script:patientNameControl.Text=$script:patientName
 $script:patientBirthControl.Text=$script:patientBirthYear
 $script:patientAddressControl.Items.Clear()
 $addressField=@($script:fields | Where-Object {$_.IsAddress}) | Select-Object -First 1
 if($addressField){
  foreach($choice in $addressField.Options){[void]$script:patientAddressControl.Items.Add([string]$choice)}
  if(-not $script:openingFreshTemplate -and -not $script:patientAddress -and $addressField.Value){$script:patientAddress=$addressField.Value}
 }
 $script:patientAddressControl.Text=if($script:addressBase){$script:addressBase}else{$script:patientAddress}
 $script:streetControl.Text=$script:addressStreet
 $script:houseControl.Text=$script:addressHouse
 $script:apartmentControl.Text=$script:addressApartment
 foreach($c in @($script:streetControl,$script:houseControl,$script:apartmentControl)){$c.Enabled=$false}
 $script:patientAddressControl.Enabled=$false
 $addressToggle.Text='Изменить адрес'
 # Demographics use the same label / full-width field / action-button rows.
 $heading=New-Object System.Windows.Forms.Label
 $heading.Text='ПЕРВИЧНЫЙ ОСМОТР'
 $heading.Font=New-Object System.Drawing.Font('Segoe UI',12,[System.Drawing.FontStyle]::Bold)
 $heading.SetBounds(25,$y,950,30);$panel.Controls.Add($heading);$y+=48
 $commonRows=@(
  @{Label='Ф.И.О. пациента';Control=$script:patientNameControl;Toggle=$false},
  @{Label='Дата рождения (ДД.ММ.ГГГГ)';Control=$script:patientBirthControl;Toggle=$false},
  @{Label='Место регистрации';Control=$script:patientAddressControl;Toggle=$true}
 )
 $dateLabel=New-Object System.Windows.Forms.Label;$dateLabel.Text='Дата госпитализации';$dateLabel.SetBounds(25,$y,320,24);$panel.Controls.Add($dateLabel);$y+=27
 $script:admissionControl.SetBounds(25,$y,170,34);$panel.Controls.Add($script:admissionControl);$y+=55
 $patientHeading=New-Object System.Windows.Forms.Label
 $patientHeading.Text='СВЕДЕНИЯ О ПАЦИЕНТЕ'
 $patientHeading.Font=New-Object System.Drawing.Font('Segoe UI',12,[System.Drawing.FontStyle]::Bold)
 $patientHeading.SetBounds(25,($y+4),950,34);$panel.Controls.Add($patientHeading);$y+=44
 foreach($row in $commonRows){
  if($row.Control -eq $script:admissionControl){$patientHeading.Top=$patientHeading.Top+0}

  $lbl=New-Object System.Windows.Forms.Label
  $lbl.Text=$row.Label;$lbl.SetBounds(25,$y,980,24);$panel.Controls.Add($lbl);$y+=27
  $ctrl=$row.Control
  if($ctrl -eq $script:admissionControl){$ctrl.SetBounds(25,$y,170,34)}else{$ctrl.SetBounds(25,$y,810,34);$ctrl.Anchor='Top,Left,Right'}
  $panel.Controls.Add($ctrl)
  if($row.Toggle){
   $addressToggle.SetBounds(855,$y,145,34)
   $addressToggle.Anchor='Top,Right'
   $panel.Controls.Add($addressToggle)
  }
  $y+=59
 }
 # Additional street / house / apartment row, followed by a live preview.
 $addressParts=@(
  @{Label='Улица';Control=$script:streetControl;X=25;Width=480},
  @{Label='Дом';Control=$script:houseControl;X=520;Width=145},
  @{Label='Квартира';Control=$script:apartmentControl;X=680;Width=155}
 )
 foreach($item in $addressParts){
  $caption=New-Object System.Windows.Forms.Label
  $caption.Text=$item.Label;$caption.SetBounds($item.X,$y,$item.Width,23)
  $panel.Controls.Add($caption)
  $item.Control.SetBounds($item.X,($y+25),$item.Width,32)
  $panel.Controls.Add($item.Control)
 }
 $y+=66
 $script:addressPreview.SetBounds(25,$y,980,30)
 $panel.Controls.Add($script:addressPreview)
 Update-AddressPreview
 $y+=47
 # v47: Expert history is displayed in the patient details block, not as a clinical section.
 # Keep a reference to the original field so its value is exported to the same Word control.
 $script:expertControlsByIndex=@{}
 for($expertIndex=0;$expertIndex -lt $script:fields.Count;$expertIndex++){
  $expertField=$script:fields[$expertIndex]
  if($expertField.IsAddress -or $expertField.HospitalKey){continue}
  if(([string]$expertField.Context) -notmatch 'Экспертный\s+анамнез\s*:'){continue}
  $expertLabel=New-Object System.Windows.Forms.Label
  $expertLabel.Text='Экспертный анамнез'
  $expertLabel.SetBounds(25,$y,980,24);$panel.Controls.Add($expertLabel);$y+=27
  if($expertField.Options.Count -gt 0){
   $expertInput=New-Object SafeComboBox
   $expertInput.DropDownStyle='DropDownList'
   $expertInput.Items.AddRange([object[]]$expertField.Options)
   if($expertField.Value -and $expertInput.Items.Contains($expertField.Value)){$expertInput.SelectedItem=$expertField.Value}
  }else{
   $expertInput=New-Object System.Windows.Forms.TextBox
   $expertInput.Text=[string]$expertField.Value
  }
  $expertInput.Enabled=$false
  $expertInput.SetBounds(25,$y,810,34);$expertInput.Anchor='Top,Left,Right'
  $panel.Controls.Add($expertInput)
  $expertToggle=New-Object System.Windows.Forms.Button
  $expertToggle.Text='Изменить';$expertToggle.SetBounds(855,$y,145,34)
  $expertToggle.Anchor='Top,Right';$expertToggle.Tag=$expertInput
  $expertToggle.Add_Click({
   $target=$this.Tag
   if($target.Enabled){$target.Enabled=$false;$this.Text='Изменить'}
   else{$target.Enabled=$true;$this.Text='Закрепить';$target.Focus()}
  })
  $panel.Controls.Add($expertToggle)
  if($expertInput -is [System.Windows.Forms.ComboBox]){
   $expertInput.Tag=$expertToggle
   $expertInput.Add_SelectionChangeCommitted({$this.Enabled=$false;$this.Tag.Text='Изменить'})
  }
  $script:expertControlsByIndex[$expertIndex]=$expertInput
  $y+=54
 }
 # Store demographic controls as a separate, self-contained section.
 foreach($control in @($panel.Controls)){
  [void]$script:sectionElements.Add([pscustomobject]@{Control=$control;Section='Данные пациента';RelativeTop=$control.Top-12})
 }
 # Navigation shows one section at a time.
 if($null -eq $script:sectionSelector){
  $script:sectionSelector=New-Object System.Windows.Forms.ComboBox
  $script:sectionSelector.DropDownStyle='DropDownList'
  $script:sectionSelector.SetBounds(20,135,520,27);$script:sectionSelector.Visible=$false
  $script:sectionSelector.Anchor='Top,Left'
  $top.Controls.Add($script:sectionSelector)
  $script:sectionSelector.Add_SelectedIndexChanged({
   if(-not $script:buildingSections){Select-ClinicalSection}
  })
 }
 $script:sectionSelector.Items.Clear()
 $script:sectionPositions=@{'Данные пациента'=0}
 [void]$script:sectionSelector.Items.Add('Данные пациента')
 # Hospitalization information belongs between patient details and expert history.
 $hospitalHeading=New-Object System.Windows.Forms.Label
 $hospitalHeading.Text='СВЕДЕНИЯ О ГОСПИТАЛИЗАЦИИ'
 $hospitalHeading.Font=New-Object System.Drawing.Font('Segoe UI',12,[System.Drawing.FontStyle]::Bold)
 $hospitalHeading.SetBounds(25,$y,950,34);$panel.Controls.Add($hospitalHeading);$y+=44
 $hospitalQuestions=@(
  @{Key='count';Text='В который раз поступает?'},
  @{Key='referred';Text='Кем направлен?'},
  @{Key='delivered';Text='Какой больницей направлен?'},
  @{Key='order';Text='В каком порядке поступает?'}
 )
 foreach($question in $hospitalQuestions){
  $caption=New-Object System.Windows.Forms.Label;$caption.Text=$question.Text
  $caption.SetBounds(25,$y,980,24);$panel.Controls.Add($caption);$y+=27
  $key=[string]$question.Key
  $ctrl=$script:hospitalControls[$key]
  if($ctrl -is [System.Windows.Forms.ComboBox]){
   $previous=[string]$ctrl.Text
   $ctrl.Items.Clear()
   $matching=@($script:fields | Where-Object {$_.HospitalKey -eq $key}) | Select-Object -First 1
   if($matching){foreach($option in $matching.Options){[void]$ctrl.Items.Add([string]$option)}}
   if($previous -and $ctrl.Items.Contains($previous)){$ctrl.SelectedItem=$previous}
   elseif($matching -and $matching.Value -and $ctrl.Items.Contains($matching.Value)){$ctrl.SelectedItem=$matching.Value}
   else{$ctrl.SelectedIndex=-1}
  }
  $ctrl.SetBounds(25,$y,810,34);$ctrl.Anchor='Top,Left,Right'
  $panel.Controls.Add($ctrl);$y+=55
 }
 $clinicalStart=$panel.Controls.Count
 $heading2=New-Object System.Windows.Forms.Label
 $heading2.Text=if($script:stage -eq 'initial'){'ОСМОТР ПАЦИЕНТА'}else{'МЕДИЦИНСКИЕ СВЕДЕНИЯ'}
 $heading2.Font=New-Object System.Drawing.Font('Segoe UI',12,[System.Drawing.FontStyle]::Bold)
 $heading2.SetBounds(25,$y,950,30);$panel.Controls.Add($heading2);$y+=44
 # The only editable complaints list is a compact row, outside nested sections.
 $complaintsInput=$null
 $complaintsField=@($script:fields | Where-Object {$_.ClinicalKey -eq 'complaints'}) | Select-Object -First 1
 if($complaintsField){
  $complaintsLabel=New-Object System.Windows.Forms.Label
  $complaintsLabel.Text='Жалобы:';$complaintsLabel.SetBounds(25,($y+4),105,28)
  $panel.Controls.Add($complaintsLabel)
  $complaintsInput=New-Object SafeComboBox
  $complaintsInput.DropDownStyle='DropDownList'
  $complaintsInput.Items.AddRange([object[]]$complaintsField.Options)
  $complaintsInput.SetBounds(135,$y,865,34);$complaintsInput.Anchor='Top,Left,Right'
  $complaintsInput.DropDownWidth=1000
  if($complaintsField.Value -and $complaintsInput.Items.Contains($complaintsField.Value)){$complaintsInput.SelectedItem=$complaintsField.Value}
  $complaintsInput.Add_TextChanged({Sync-InitialExamValues $null})
  $panel.Controls.Add($complaintsInput);$y+=54
 }
 $previousSection=''
 $sectionStart=0
 $sectionTop=0
 foreach($f in $script:fields){
  $fieldIndex=$script:controls.Count
  if($f.ClinicalKey -eq 'complaints'){$script:controls+=,$complaintsInput;continue}
  if($f.ClinicalKey -eq 'complaintsRepeat'){$script:controls+=,$null;continue}
  if($script:expertControlsByIndex.ContainsKey($fieldIndex)){$script:controls+=,$script:expertControlsByIndex[$fieldIndex];continue}
  if($f.IsAddress -or $f.HospitalKey){$script:controls+=,$null;continue}
  $section=[string]$f.Section
  if(-not $section){$section='Прочее'}
  if($section -ne $previousSection){
   if($previousSection){
    for($k=$sectionStart;$k -lt $panel.Controls.Count;$k++){
     $control=$panel.Controls[$k]
     [void]$script:sectionElements.Add([pscustomobject]@{Control=$control;Section=$previousSection;RelativeTop=$control.Top-$sectionTop})
    }
   }
   $previousSection=$section
   $sectionStart=$panel.Controls.Count
   $sectionTop=$y
   $script:sectionPositions[$section]=$y
   [void]$script:sectionSelector.Items.Add($section)
   $sectionHeading=New-Object System.Windows.Forms.Label
   $sectionHeading.Text='  '+$section
   $sectionHeading.Font=New-Object System.Drawing.Font('Segoe UI',12,[System.Drawing.FontStyle]::Bold)
   $sectionHeading.ForeColor=$script:darkText
   $sectionHeading.SetBounds(25,$y,1040,38);$sectionHeading.BackColor=$script:darkInput
   $panel.Controls.Add($sectionHeading)
   $y+=50
  }
  $label=New-Object System.Windows.Forms.Label;$label.Text=(Get-QuestionText $f);$label.SetBounds(25,$y,980,25);$label.Font=New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold);$panel.Controls.Add($label);$y+=25

  if($f.Options.Count -gt 0){
   $input=New-Object SafeComboBox;$input.DropDownStyle='DropDownList';$input.Items.AddRange([object[]]$f.Options)
   if($f.Value -and $input.Items.Contains($f.Value)){$input.SelectedItem=$f.Value};$input.SetBounds(25,$y,810,34)
  } else {
   $input=New-Object System.Windows.Forms.TextBox;$input.Text=$f.Value;$input.SetBounds(25,$y,810,34)
  }
  $input.Enabled=$false
  $input.Anchor='Top,Left,Right';$panel.Controls.Add($input);$script:controls+=,$input
  $toggle=New-Object System.Windows.Forms.Button;$toggle.Text='Изменить';$toggle.SetBounds(855,$y,145,34);$toggle.Anchor='Top,Right';$panel.Controls.Add($toggle)
  $toggle.Tag=$input
  $toggle.Add_Click({
   $target=$this.Tag
   if($target.Enabled){$target.Enabled=$false;$this.Text='Изменить'}
   else {$target.Enabled=$true;$this.Text='Закрепить';$target.Focus()}
  })
  # On explicit list choice lock the field again.
  if($input -is [System.Windows.Forms.ComboBox]){
   $input.Tag=$toggle
   $input.Add_SelectionChangeCommitted({
    $this.Enabled=$false;$this.Tag.Text='Изменить'
   })
  }
  $y+=54
 }
 if($previousSection){
  for($k=$sectionStart;$k -lt $panel.Controls.Count;$k++){
   $control=$panel.Controls[$k]
   [void]$script:sectionElements.Add([pscustomobject]@{Control=$control;Section=$previousSection;RelativeTop=$control.Top-$sectionTop})
  }
 }
 # Section heading is shown in the selected clinical section, not in demographics.
 $heading2.Visible=$true
 $script:buildingSections=$false
 if($script:sectionSelector.Items.Count -gt 0){$script:sectionSelector.SelectedIndex=0;Select-ClinicalSection}

 Set-DarkTheme $panel
 Set-RoundedTheme $panel
 foreach($c in $panel.Controls){if($c -is [System.Windows.Forms.Label] -and $c.Text.StartsWith('  ')){$c.BackColor=$script:darkInput;$c.ForeColor=$script:darkText}}
 $panel.AutoScrollMinSize=New-Object System.Drawing.Size(0,($y+40))
 $panel.AutoScrollPosition=New-Object System.Drawing.Point(0,0)
 Sync-InitialExamValues $null
 $info.Text="Версия 48. Найдено полей: $($script:fields.Count). Нажмите «Изменить», чтобы разблокировать поле. Колесо мыши прокручивает страницу."
}

function Get-StageKey { if($script:stage -eq 'diary'){return ('diary_'+$script:diaryIndex)};return $script:stage }
function Capture-Stage {
 if($script:stage -eq 'initial'){Capture-Universal;return}
 if(-not $script:fields){return}
 $key=Get-StageKey
 $vals=@()
 for($j=0;$j -lt $script:fields.Count;$j++){
  $ctrl=$script:controls[$j]
  if($script:fields[$j].HospitalKey){$vals+= [string]$script:hospitalControls[$script:fields[$j].HospitalKey].Text}
  elseif($script:fields[$j].IsAddress){$vals+= [string](Get-FullRegistration)}
  elseif($ctrl){$vals+= [string]$ctrl.Text}
  else{$vals+=''}
 }
 Sync-InitialExamValues $vals
 $script:stageData[$key]=@($vals)
 if($script:stage -eq 'initial'){
  $script:initialByLabel=@{}
  for($j=0;$j -lt $script:fields.Count;$j++){
   $name=([string]$script:fields[$j].Label).Trim().ToLowerInvariant()
   if($name -and $vals[$j]){$script:initialByLabel[$name]=[string]$vals[$j]}
  }
 }
}
function Restore-Stage {
 if($script:stage -eq 'initial'){return}
 $key=Get-StageKey
 if($script:stage -eq 'discharge' -and -not $script:stageData.ContainsKey($key)){
  $values=@()
  foreach($field in $script:fields){
   $name=([string]$field.Label).Trim().ToLowerInvariant()
   if($script:initialByLabel.ContainsKey($name)){$values+= [string]$script:initialByLabel[$name]}else{$values+=''}
  }
  $script:stageData[$key]=$values
 }
 if($script:stageData.ContainsKey($key)){
  $saved=@($script:stageData[$key])
  for($j=0;$j -lt [Math]::Min($saved.Count,$script:controls.Count);$j++){
   if($script:fields[$j].HospitalKey){
    $hKey=[string]$script:fields[$j].HospitalKey
    $hControl=$script:hospitalControls[$hKey]
    if($hControl -is [System.Windows.Forms.ComboBox] -and $hControl.Items.Contains([string]$saved[$j])){$hControl.SelectedItem=[string]$saved[$j]}
    continue
   }
   if($script:controls[$j]){
    $ctrl=$script:controls[$j];$ctrl.Enabled=$true
    if($ctrl -is [System.Windows.Forms.ComboBox] -and $ctrl.DropDownStyle -eq 'DropDownList'){
     if($ctrl.Items.Contains([string]$saved[$j])){$ctrl.SelectedItem=[string]$saved[$j]}
    }else{$ctrl.Text=[string]$saved[$j]}
    $ctrl.Enabled=($script:fields[$j].ClinicalKey -eq 'complaints')
   }
  }
 }
}
function Open-Stage {
 Remove-MedicalEndAction
 $path=[string]$script:stageTemplates[$script:stage]
 $newDiary.Visible=($script:stage -eq 'diary')
 Update-MedicalNavigation
 if($script:stage -eq 'initial'){Open-UniversalInitial;return}
 if(-not $path -or -not (Test-Path $path)){
  $panel.Controls.Clear();$script:fields=@();$script:controls=@();$save.Enabled=$false
  $message=New-Object System.Windows.Forms.Label
  $message.Text='Для этого этапа пока не назначен шаблон Word. Нажмите «Открыть шаблон» и выберите .dotx или .docx.'
  $message.SetBounds(25,25,980,100);$message.ForeColor=$script:darkText;$panel.Controls.Add($message)
  Add-MedicalEndAction
  return
 }
 $fio=[string]$script:patientNameControl.Text;$year=[string]$script:patientBirthControl.Text;$address=[string](Get-FullRegistration)
 $script:addressBase=[string]$script:patientAddressControl.Text
 $script:addressStreet=[string]$script:streetControl.Text
 $script:addressHouse=[string]$script:houseControl.Text
 $script:addressApartment=[string]$script:apartmentControl.Text
 Read-Template $path
 # Patient details belong to the case only during normal stage switching.
 if(-not $script:openingFreshTemplate -and $fio){$script:patientName=$fio};if(-not $script:openingFreshTemplate -and $year){$script:patientBirthYear=$year};if(-not $script:openingFreshTemplate -and $address){$script:patientAddress=$address}
 Show-Fields;Restore-Stage;Sync-InitialExamValues $null;$save.Enabled=$true
 $headingText=if($script:stage -eq 'initial'){'Первичный осмотр'}elseif($script:stage -eq 'diary'){"Дневник наблюдения №$($script:diaryIndex)"}else{'Выписной эпикриз'}
 $form.Text='Медицинский конструктор v62 — '+$headingText
 Add-MedicalEndAction
}
# Automatic template adaptation: detect edits made to an assigned Word template.
# Preserve current values by content-control tag/alias/context, not their position.
$script:templateSignatures=@{}
$script:templateRefreshBusy=$false
function Get-TemplateSignature($path) {
 if(-not $path -or -not (Test-Path -LiteralPath $path)){return ''}
 $item=Get-Item -LiteralPath $path
 return ([string]$item.Length + ':' + [string]$item.LastWriteTimeUtc.Ticks)
}
function Refresh-ChangedTemplate {
 if($script:stage -eq 'initial'){
  if($script:universalConfig.AutoTemplate){return}
  $path=Get-UniversalTemplatePath;$signature=Get-TemplateSignature $path
  if(-not $script:templateSignatures.ContainsKey($path)){$script:templateSignatures[$path]=$signature;return}
  if($signature -and $signature -ne $script:templateSignatures[$path]){
   try{Capture-Universal;Open-UniversalInitial;$script:templateSignatures[$path]=$signature}catch{$script:templateSignatures[$path]=$signature;[void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'Изменение шаблона')}
  }
  return
 }
 if($script:templateRefreshBusy){return}
 $path=[string]$script:stageTemplates[$script:stage]
 if(-not $path -or -not (Test-Path -LiteralPath $path)){return}
 $signature=Get-TemplateSignature $path
 if(-not $script:templateSignatures.ContainsKey($path)){$script:templateSignatures[$path]=$signature;return}
 if($script:templateSignatures[$path] -eq $signature){return}
 $script:templateRefreshBusy=$true
 try {
  $old=@{}
  for($j=0;$j -lt $script:fields.Count;$j++){
   $field=$script:fields[$j]
   $key=[string]$field.Key
   if($field.IsAddress){continue}
   if($j -lt $script:controls.Count -and $script:controls[$j] -and $key){
    $old[$key]=[string]$script:controls[$j].Text
   }
  }
  Capture-Stage
  # Existing positional values are obsolete after the template structure changes.
  $stageKey=Get-StageKey
  $script:stageData.Remove($stageKey)
  Open-Stage
  $matched=0
  for($j=0;$j -lt $script:fields.Count;$j++){
   $key=[string]$script:fields[$j].Key
   if($script:fields[$j].IsAddress){continue}
   if($old.ContainsKey($key) -and $j -lt $script:controls.Count){
    $ctrl=$script:controls[$j]
    if($ctrl){
     $ctrl.Enabled=$true
     if($ctrl -is [System.Windows.Forms.ComboBox] -and $ctrl.DropDownStyle -eq 'DropDownList'){
      if($ctrl.Items.Contains($old[$key])){$ctrl.SelectedItem=$old[$key];$matched++}
     }else{$ctrl.Text=$old[$key];$matched++}
     $ctrl.Enabled=($script:fields[$j].ClinicalKey -eq 'complaints')
    }
   }
  }
  Capture-Stage
  $script:templateSignatures[$path]=$signature
  $info.Text="Шаблон обновлён автоматически. Полей: $($script:fields.Count). Сопоставлено значений: $matched."
  if($old.Count -gt $matched){
   [System.Windows.Forms.MessageBox]::Show("Шаблон изменился. Перенесено значений: $matched из $($old.Count). Проверьте поля, которые были удалены или переименованы.",'Автоадаптация шаблона') | Out-Null
  }
 }catch{
  $script:templateSignatures[$path]=$signature
  [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Ошибка автоматической адаптации') | Out-Null
 }finally{$script:templateRefreshBusy=$false}
}
$script:templateTimer=New-Object System.Windows.Forms.Timer
$script:templateTimer.Interval=3000
$script:templateTimer.Add_Tick({Refresh-ChangedTemplate})

function Switch-Stage($target){
 Capture-Stage
 if($target -eq 'initial' -and $script:stage -ne 'initial'){Pull-UniversalDemographics}
 $script:stage=$target
 Open-Stage
}
function Save-Case {
 $script:addressBase=[string]$script:patientAddressControl.Text
 $script:addressStreet=[string]$script:streetControl.Text
 $script:addressHouse=[string]$script:houseControl.Text
 $script:addressApartment=[string]$script:apartmentControl.Text
 Capture-Stage
 if($script:stage -ne 'initial'){Pull-UniversalDemographics}
 if(-not $script:caseFolder){
  $pick=New-Object System.Windows.Forms.FolderBrowserDialog
  $pick.Description='Выберите папку госпитализации'
  if($pick.ShowDialog() -ne 'OK'){return}
  $script:caseFolder=$pick.SelectedPath
 }
 $record=[ordered]@{
  version=49;universal=(Get-UniversalState);admissionDate=$script:admissionControl.Value.ToString('yyyy-MM-dd');patientName=[string]$script:patientNameControl.Text
  birthYear=[string]$script:patientBirthControl.Text
  registration=[string](Get-FullRegistration)
  registrationBase=[string]$script:patientAddressControl.Text
  registrationStreet=[string]$script:streetControl.Text
  registrationHouse=[string]$script:houseControl.Text
  registrationApartment=[string]$script:apartmentControl.Text
  hospitalization=(Get-HospitalizationValues)
  templates=$script:stageTemplates;stages=$script:stageData
  diaryCount=$script:diaryIndex;updated=(Get-Date).ToString('o')
 }
 $json=$record | ConvertTo-Json -Depth 30 -Compress
 $payload=[Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($json))
 $escape=[System.Security.SecurityElement]::Escape
 $fio=[System.Security.SecurityElement]::Escape([string]$record.patientName)
 $birth=[System.Security.SecurityElement]::Escape([string]$record.birthYear)
 $address=[System.Security.SecurityElement]::Escape([string]$record.registration)
 $stamp=[System.Security.SecurityElement]::Escape((Get-Date).ToString('dd.MM.yyyy HH:mm'))
 $body="<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>КАРТА ГОСПИТАЛИЗАЦИИ</w:t></w:r></w:p>"
 foreach($line in @('Ф.И.О.: '+$fio,'Дата рождения: '+$birth,'Место регистрации: '+$address,'Дата и время поступления: '+([System.Security.SecurityElement]::Escape($script:admissionControl.Value.ToString('dd.MM.yyyy HH:mm'))),'Обновлено: '+$stamp)){$body+='<w:p><w:r><w:t xml:space="preserve">'+$line+'</w:t></w:r></w:p>'}
 $body+='<w:p><w:r><w:t>Первичный осмотр, дневники наблюдения и выписной эпикриз сохраняются в карте для продолжения работы в конструкторе.</w:t></w:r></w:p>'
 # The machine-readable state is stored as hidden Word text, not a separate JSON file.
 $body+='<w:p><w:r><w:rPr><w:vanish/></w:rPr><w:t>MC_CASE_V24:'+ $payload +':END_MC_CASE</w:t></w:r></w:p>'
 $document='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'+$body+'<w:sectPr/></w:body></w:document>'
 $types='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>'
 $rels='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>'
 # Suggest patient name and admission date; Windows Save dialog allows editing.
 $safeName=([string]$record.patientName).Trim() -replace '[\\/:*?"<>|]', '_' -replace '\s+', ' '
 if([string]::IsNullOrWhiteSpace($safeName)){$safeName='Пациент'}
 $suggested=$safeName+'_'+$script:admissionControl.Value.ToString('dd.MM.yyyy')+'.docx'
 if(-not $script:caseFile){
  $dlg=New-Object System.Windows.Forms.SaveFileDialog
  $dlg.Title='Сохранить карту госпитализации'
  $dlg.Filter='Документ Word (*.docx)|*.docx'
  $dlg.DefaultExt='docx';$dlg.AddExtension=$true
  $dlg.InitialDirectory=$script:caseFolder
  $dlg.FileName=$suggested
  $dlg.OverwritePrompt=$true
  if($dlg.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){return}
  $script:caseFile=$dlg.FileName
 }
 $path=$script:caseFile
 $script:caseFolder=[System.IO.Path]::GetDirectoryName($path)
 $tmp=Join-Path $script:caseFolder ('case_'+[Guid]::NewGuid().ToString('N')+'.tmp')
 try{
  $zip=[System.IO.Compression.ZipFile]::Open($tmp,[System.IO.Compression.ZipArchiveMode]::Create)
  try{
   foreach($item in @(@('[Content_Types].xml',$types),@('_rels/.rels',$rels),@('word/document.xml',$document))){
    $entry=$zip.CreateEntry([string]$item[0]);$stream=$entry.Open()
    try{$bytes=[System.Text.Encoding]::UTF8.GetBytes([string]$item[1]);$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
   }
  }finally{$zip.Dispose()}
  Move-Item -LiteralPath $tmp -Destination $path -Force
 }finally{if(Test-Path -LiteralPath $tmp){Remove-Item -LiteralPath $tmp -Force}}
 [System.Windows.Forms.MessageBox]::Show('Карта госпитализации сохранена в Word: '+$path,'Готово') | Out-Null
}
function Read-CaseDocument($path){
 $zip=[System.IO.Compression.ZipFile]::OpenRead($path)
 try{
  $xml=Get-XmlPart $zip 'word/document.xml'
  if(-not $xml){throw 'Не найден документ Word.'}
  $n=[System.Xml.XmlNamespaceManager]::new($xml.NameTable);$n.AddNamespace('w',$script:ns)
  $all=(($xml.SelectNodes('//w:t',$n) | ForEach-Object {$_.InnerText}) -join '')
  if($all -notmatch 'MC_CASE_V24:([A-Za-z0-9+/=]+):END_MC_CASE'){throw 'Это не карта госпитализации Медицинского конструктора.'}
  $json=[System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($Matches[1]))
  return ($json | ConvertFrom-Json)
 }finally{$zip.Dispose()}
}
$stageInitial.Add_Click({Switch-Stage 'initial'})
$stageDiary.Add_Click({Switch-Stage 'diary'})
$stageDischarge.Add_Click({Switch-Stage 'discharge'})
$newDiary.Add_Click({
 Capture-Stage
 $script:diaryIndex++
 Open-Stage
})
$caseSave.Add_Click({try{Save-Case}catch{[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Ошибка карты') | Out-Null}})

$caseOpen.Add_Click({
 try{
  $picker=New-Object System.Windows.Forms.OpenFileDialog
  $picker.Filter='Карта госпитализации Word|*.docx'
  if($picker.ShowDialog() -ne 'OK'){return}
  Open-CasePath $picker.FileName
 }catch{[void][System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Ошибка открытия карты')}
})

function Reset-NewPatientCase($config=$null) {
 $script:universalConfig=if($null -ne $config){Copy-MedicalFormSchema $config}elseif($script:universalConfig){Copy-MedicalFormSchema $script:universalConfig}else{Load-UniversalConfig}
 $script:universalValues=@{};$script:universalInputs=@{};$script:universalDetails=@{};$script:universalDetailInputs=@{}
 $script:universalMultiInputs=@{};$script:universalRepeatInputs=@{};$script:universalWordFields=@()
 $script:stageTemplates=@{initial=(Get-UniversalTemplatePath);diary='';discharge=''}
 $script:currentPatient=-1;$script:pendingDocument=$null;$script:source='';$script:fields=@();$script:controls=@()
 # Starting a reusable form clears every patient/case binding, never on stage switches.
 $script:stageData=@{}
 $script:initialByLabel=@{}
 $script:caseFolder='';$script:caseFile=''
 $script:diaryIndex=1;$script:diaryRecords=@();$script:stage='initial'
 $script:patientName='';$script:patientBirthYear='';$script:patientAddress=''
 $script:addressBase='';$script:addressStreet='';$script:addressHouse='';$script:addressApartment=''
 $script:admissionControl.Value=Get-Date
 foreach($ctrl in @($script:patientNameControl,$script:patientBirthControl,$script:patientAddressControl,$script:streetControl,$script:houseControl,$script:apartmentControl)){
  if($null -ne $ctrl){$ctrl.Text=''}
 }
 foreach($ctrl in $script:hospitalControls.Values){
  if($ctrl -is [System.Windows.Forms.ComboBox]){$ctrl.SelectedIndex=-1;$ctrl.Text=''}
  elseif($null -ne $ctrl){$ctrl.Text=''}
 }
}
$open.Add_Click({Invoke-MedicalChooseTemplate})
$save.Add_Click({
 if($script:stage -eq 'initial'){Capture-Universal}
 # The document name is based on patient FIO and the admission date.
 $safeFio=([string]$script:patientNameControl.Text).Trim() -replace '[\\/:*?"<>|]', '_' -replace '\s+', ' '
 if([string]::IsNullOrWhiteSpace($safeFio)){$safeFio='Пациент'}
 $admissionStamp=$script:admissionControl.Value.ToString('dd.MM.yyyy')
 $stageSuffix=if($script:stage -eq 'initial'){'Первичный осмотр'}elseif($script:stage -eq 'diary'){('Дневник '+$script:diaryIndex)}else{'Выписной эпикриз'}
 $suggestedName=$safeFio+'_'+$admissionStamp+'_'+$stageSuffix+'.docx'
 $d=New-Object System.Windows.Forms.SaveFileDialog
 $d.Title='Сохранить документ Word'
 $d.Filter='Документ Word (*.docx)|*.docx'
 $d.DefaultExt='docx';$d.AddExtension=$true;$d.OverwritePrompt=$true
 if($script:caseFolder -and (Test-Path -LiteralPath $script:caseFolder -PathType Container)){$d.InitialDirectory=$script:caseFolder}
 $d.FileName=$suggestedName
 if($d.ShowDialog() -eq 'OK'){
  try {
   Export-CurrentStageDocument $d.FileName
   [System.Windows.Forms.MessageBox]::Show('Документ успешно сохранён: '+$d.FileName,'Готово') | Out-Null
  } catch {[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Ошибка сохранения') | Out-Null}
 }
})
$form.Add_FormClosed({$script:templateTimer.Stop()})
Initialize-MedicalWorkspace
$form.Add_Shown({
 Start-MedicalFormsWorkspace
 Set-DarkTheme $form
 $panel.BackColor=$script:darkBg
 if($script:universalFlow -and -not $script:universalFlow.IsDisposed){$script:universalFlow.BackColor=$script:darkBg}
 Update-UniversalCompletion;Update-MedicalNavigation
 Resize-UniversalForm
 $panel.AutoScrollPosition=New-Object Drawing.Point(0,0)
 $script:templateTimer.Start()
})
$script:progressTimer=New-Object System.Windows.Forms.Timer
$script:progressTimer.Interval=900
$script:progressTimer.Add_Tick({
 if($script:stage -eq 'initial' -and $script:universalCompletionLabel -and -not $script:universalCompletionLabel.IsDisposed){
  $requiredFields=@(Get-UniversalFields $script:universalConfig | Where-Object {Test-UniversalFieldRequired $_})
  $missingFields=@(Get-UniversalMissingFields $script:universalConfig $script:universalValues)
  $script:progressLabel.Text=('Обязательные поля: '+($requiredFields.Count-$missingFields.Count)+' / '+$requiredFields.Count+'  •  Пропущено: '+$missingFields.Count)
 }else{
  $total=0;$filled=0
  foreach($c in $script:controls){if($null -ne $c){$total++;if(-not [string]::IsNullOrWhiteSpace([string]$c.Text) -and [string]$c.Text -ne 'Выберите элемент.'){$filled++}}}
  $script:progressLabel.Text="Заполнено: $filled / $total"
 }
 if($script:uiPatientLabel){$script:uiPatientLabel.Text=Get-MedicalPatientSummary}
 if($script:uiMedicalFormStatus){
  $script:uiMedicalFormStatus.Text=if($script:medicalWorkspaceReady){'Форма: '+$script:activeMedicalFormName}else{'Форма не открыта'}
  if($script:medicalWorkspaceReady -and $script:medicalFormBaseline -and (Get-MedicalFormSignature $script:universalConfig) -ne $script:medicalFormBaseline){$script:uiMedicalFormStatus.Text+=' • есть изменения'}
 }
 Update-MedicalNavigation
})
$script:progressTimer.Start()
$form.Add_FormClosed({$script:progressTimer.Stop();if($script:uiTooltip){$script:uiTooltip.Dispose()};$top.Dispose()})
[void]$form.ShowDialog()
