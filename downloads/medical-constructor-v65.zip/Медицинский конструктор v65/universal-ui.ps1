﻿function Get-UniversalInputValue([string]$id){
 if($script:universalRepeatInputs -and $script:universalRepeatInputs.ContainsKey($id)){return (@($script:universalRepeatInputs[$id].Rows | ForEach-Object {[string]$_.Editor.Text}) -join "`r`n")}
 if($script:universalMultiInputs -and $script:universalMultiInputs.ContainsKey($id)){
  return (@($script:universalMultiInputs[$id] | Where-Object {$_.Checked} | ForEach-Object {[string]$_.Text}) -join "`r`n")
 }
 return [string]$script:universalInputs[$id].Text
}
function Update-UniversalCompletion {
 if(-not $script:universalIndicators){return}
 $missing=0;$required=0
 foreach($field in Get-UniversalFields $script:universalConfig){
  $id=[string]$field.Id;$isRequired=Test-UniversalFieldRequired $field
  $filled=-not [string]::IsNullOrWhiteSpace([string]$script:universalValues[$id])
  if($isRequired){$required++;if(-not $filled){$missing++}}
  $dot=$script:universalIndicators[$id]
  if($dot -and -not $dot.IsDisposed){
   $dot.ForeColor=if($filled){$script:uiSuccess}elseif($isRequired){$script:uiDanger}else{$script:darkMuted}
   $state=if($filled){'заполнено'}elseif($isRequired){'не заполнено'}else{'необязательное поле'}
   $dot.AccessibleName=([string]$field.Label+': '+$state)
  }
 }
 if($script:universalCompletionLabel -and -not $script:universalCompletionLabel.IsDisposed){
  $script:universalCompletionLabel.Text=('Обязательные поля: '+($required-$missing)+' из '+$required+' заполнено. Пропущено: '+$missing+'.')
  $script:universalCompletionLabel.ForeColor=if($missing){$script:uiDanger}else{$script:uiSuccess}
 }
}
function Test-UniversalCompletion {
 $missing=@(Get-UniversalMissingFields $script:universalConfig $script:universalValues)
 if($missing.Count -eq 0){return}
 Update-UniversalCompletion
 $first=$script:universalInputs[[string]$missing[0].Id]
 if($first -and $panel){$panel.ScrollControlIntoView($first);[void]$first.Focus()}
 $list=(@($missing | ForEach-Object {'• '+$_.Section+' — '+$_.Label}) -join "`r`n")
 throw ("Не заполнены обязательные поля:`r`n"+$list+"`r`n`r`nЗаполните их перед сохранением DOCX, предпросмотром или печатью. Незавершённую работу можно сохранить кнопкой сохранения случая. Обязательность меняется в настройках поля.")
}
# v49 WinForms view and configuration editor. Shared patient/document workflows remain in constructor.ps1.
function Set-UniversalDemographics {
 $displayValues=Get-UniversalExportValues $script:universalConfig $script:universalValues $script:universalDetails
 $script:patientName='';$script:patientBirthYear='';$script:patientAddress=''
 $script:patientNameControl.Text='';$script:patientBirthControl.Text='';$script:patientAddressControl.Text=''

 foreach($f in Get-UniversalFields $script:universalConfig){
  $value=[string]$displayValues[[string]$f.Id]
  switch([string]$f.System){
   'name' {$script:patientName=$value;$script:patientNameControl.Text=$value}
   'birth' {$script:patientBirthYear=$value;$script:patientBirthControl.Text=$value}
   'address' {
    $script:patientAddress=$value;$script:patientAddressControl.Text=$value;$script:addressBase=$value
    $script:addressStreet='';$script:addressHouse='';$script:addressApartment=''
    $script:streetControl.Text='';$script:houseControl.Text='';$script:apartmentControl.Text=''
   }
  }
 }
}
function Set-UniversalDemographicValue($field,[string]$value){
 $id=[string]$field.Id
 if($field.Type -eq 'choice_detail'){
  $current=Get-UniversalExportValues $script:universalConfig $script:universalValues $script:universalDetails
  if([string]$current[$id] -ceq $value){return}
  $script:universalDetails[$id]=''
 }
 $script:universalValues[$id]=$value
}
function Pull-UniversalDemographics {
 foreach($f in Get-UniversalFields $script:universalConfig){
  switch([string]$f.System){
   'name' {Set-UniversalDemographicValue $f ([string]$script:patientNameControl.Text)}
   'birth' {Set-UniversalDemographicValue $f ([string]$script:patientBirthControl.Text)}
   'address' {Set-UniversalDemographicValue $f ([string](Get-FullRegistration))}
  }
 }
}
function Capture-Universal {
 foreach($key in $script:universalInputs.Keys){$script:universalValues[$key]=Get-UniversalInputValue ([string]$key)}
 foreach($key in $script:universalDetailInputs.Keys){$script:universalDetails[$key]=[string]$script:universalDetailInputs[$key].Text}
 Set-UniversalDemographics
 $displayValues=Get-UniversalExportValues $script:universalConfig $script:universalValues $script:universalDetails
 $script:initialByLabel=@{}
 foreach($f in Get-UniversalFields $script:universalConfig){$script:initialByLabel[$f.Label.Trim().ToLowerInvariant()]=[string]$displayValues[[string]$f.Id]}
}
function Test-UniversalPatientValues {
 foreach($f in Get-UniversalFields $script:universalConfig){
  if($f.System -eq 'birth' -and $script:universalValues[[string]$f.Id]){
   $date=[datetime]::MinValue
   if(-not [datetime]::TryParseExact([string]$script:universalValues[[string]$f.Id],'dd.MM.yyyy',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$date)){throw 'Дата рождения должна быть в формате ДД.ММ.ГГГГ.'}
  }
 }
}
function Show-UniversalInitial {
 Remove-MedicalEndAction
 $script:universalBuilding=$true
 $panel.SuspendLayout()
 try{
  # Reset scroll coordinates while the old controls are still attached. A late
  # reset would shift the newly built form down by the previous scroll offset.
  $panel.AutoScrollPosition=New-Object Drawing.Point(0,0)
  $panel.AutoScrollMinSize=New-Object Drawing.Size(0,0)
  $script:universalFlow=$null
  $panel.Controls.Clear();$script:universalIndicators=@{};$script:universalMultiInputs=@{};$script:universalRepeatInputs=@{};$script:universalInputs=@{};$script:universalDetailInputs=@{};$script:controls=@();$script:sectionElements=New-Object System.Collections.ArrayList
  $flow=New-Object System.Windows.Forms.TableLayoutPanel
  $flow.Location=New-Object Drawing.Point(20,15);$flow.Width=[Math]::Max(600,($panel.ClientSize.Width-58))
  $flow.ColumnCount=1;$flow.RowCount=0;$flow.AutoSize=$true;$flow.AutoSizeMode='GrowAndShrink';$flow.Anchor='Top,Left'
  $flow.Padding=New-Object Windows.Forms.Padding(10);$flow.Margin=New-Object Windows.Forms.Padding(0)
  [void]$flow.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
  $title=New-Object Windows.Forms.Label;$title.Text='Первичный осмотр';$title.AutoSize=$true
  $title.Font=New-Object Drawing.Font('Segoe UI',18,[Drawing.FontStyle]::Bold);$title.Margin=New-Object Windows.Forms.Padding(0,0,0,16)
  $flow.Controls.Add($title)
  $script:universalCompletionLabel=New-Object Windows.Forms.Label;$script:universalCompletionLabel.AutoSize=$true
  $script:universalCompletionLabel.Margin=New-Object Windows.Forms.Padding(0,0,0,8);$flow.Controls.Add($script:universalCompletionLabel)
  $legend=New-Object Windows.Forms.Label;$legend.AutoSize=$true;$legend.Text='● Пропущено обязательное поле   •   ● Заполнено   •   ● Необязательно'
  $legend.Margin=New-Object Windows.Forms.Padding(0,0,0,16);$flow.Controls.Add($legend)
  $dateLabel=New-Object Windows.Forms.Label;$dateLabel.Text='Дата и время поступления';$dateLabel.AutoSize=$true;$dateLabel.Margin=New-Object Windows.Forms.Padding(0,0,0,7);$flow.Controls.Add($dateLabel)
  $dateRow=New-Object Windows.Forms.FlowLayoutPanel;$dateRow.AutoSize=$true;$dateRow.WrapContents=$false;$dateRow.Margin=New-Object Windows.Forms.Padding(0,0,0,20)
  $script:admissionControl.CustomFormat='dd.MM.yyyy  HH:mm';$script:admissionControl.Width=250;$script:admissionControl.Height=32
  $script:admissionControl.Margin=New-Object Windows.Forms.Padding(0,0,12,0);$dateRow.Controls.Add($script:admissionControl)
  $now=New-Object Windows.Forms.Button;$now.Text='Текущее время';$now.Size=New-Object Drawing.Size(165,32);$now.Add_Click({$script:admissionControl.Value=Get-Date});$dateRow.Controls.Add($now)
  $flow.Controls.Add($dateRow)
  foreach($section in $script:universalConfig.Sections){
   $block=New-Object MedicalOutlineTable;$block.ColumnCount=1;$block.RowCount=0;$block.AutoSize=$true;$block.Dock='Top'
   $block.Padding=New-Object Windows.Forms.Padding(16);$block.Margin=New-Object Windows.Forms.Padding(0,0,0,14)
   [void]$block.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
   $heading=New-Object Windows.Forms.Label;$heading.Text=[string]$section.Title;$heading.AutoSize=$true;$heading.MaximumSize=New-Object Drawing.Size(940,0)
   $heading.Font=New-Object Drawing.Font('Segoe UI',12,[Drawing.FontStyle]::Bold);$heading.Margin=New-Object Windows.Forms.Padding(0,0,0,12);$block.Controls.Add($heading)
   if(@($section.Fields).Count -eq 0){
    $hint=New-Object Windows.Forms.Label;$hint.Text='Раздел пока пуст. Добавьте поле через «Настроить форму».';$hint.AutoSize=$true;$block.Controls.Add($hint)
   }
   foreach($f in $section.Fields){
    if($f.Type -eq 'heading'){
     $sub=New-Object Windows.Forms.Label;$sub.Text=[string]$f.Label;$sub.AutoSize=$true;$sub.Dock='Top'
     $sub.Font=New-Object Drawing.Font('Segoe UI',11,[Drawing.FontStyle]::Bold);$sub.Margin=New-Object Windows.Forms.Padding(0,12,0,8);$block.Controls.Add($sub);continue
    }
    if(@($section.Fields).Count -ne 1 -or $f.Label -ne $section.Title){
     $label=New-Object Windows.Forms.Label;$label.Text=[string]$f.Label;$label.AutoSize=$true;$label.Margin=New-Object Windows.Forms.Padding(0,5,0,6);$block.Controls.Add($label)
    }
    if($f.Type -in @('choice','choice_detail')){
     $ctrl=New-Object SafeComboBox;$ctrl.DropDownStyle='DropDownList';$ctrl.DropDownWidth=900
     $options=@($f.Options)
     if($f.WordId){$bound=@($script:universalWordFields | Where-Object {$_.Id -eq $f.WordId});if($bound.Count -and $bound[0].Options.Count){$options=@($bound[0].Options)}}
     foreach($option in $options){[void]$ctrl.Items.Add([string]$option)}
     $value=[string]$script:universalValues[[string]$f.Id]
     # Keep a saved value visible even after a template author changes its options.
     if($value -and -not $ctrl.Items.Contains($value)){[void]$ctrl.Items.Add($value)}
     if($value){$ctrl.SelectedItem=$value}
     $ctrl.Height=32
    }elseif($f.Type -eq 'repeat'){
     $ctrl=New-UniversalRepeatControl $f
    }elseif($f.Type -eq 'multi'){
     $ctrl=New-Object Windows.Forms.TableLayoutPanel;$ctrl.ColumnCount=1;$ctrl.AutoSize=$true;$ctrl.AutoSizeMode='GrowAndShrink'
     [void]$ctrl.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
     $checks=New-Object System.Collections.ArrayList
     foreach($row in Get-UniversalMultiRows @($f.Options) ([string]$script:universalValues[[string]$f.Id])){
      $check=New-Object Windows.Forms.CheckBox;$check.Text=$row.Text;$check.AutoSize=$true;$check.MaximumSize=New-Object Drawing.Size(([Math]::Max(300,$panel.ClientSize.Width-150)),0);$check.Dock='Top';$check.Checked=$row.Checked
      $check.Margin=New-Object Windows.Forms.Padding(0,4,0,6);$check.Tag=[string]$f.Id
      $check.Add_CheckedChanged({if(-not $script:universalBuilding){$script:universalValues[[string]$this.Tag]=Get-UniversalInputValue ([string]$this.Tag);$script:universalInputs[[string]$this.Tag].Text=$script:universalValues[[string]$this.Tag];Update-UniversalCompletion}})
      [void]$checks.Add($check);$ctrl.Controls.Add($check)
     }
     $script:universalMultiInputs[[string]$f.Id]=$checks
     $ctrl.Text=[string]$script:universalValues[[string]$f.Id]
    }else{
     $ctrl=New-Object Windows.Forms.TextBox
     if($f.Type -eq 'multiline'){$ctrl.Multiline=$true;$ctrl.AcceptsReturn=$true;$ctrl.ScrollBars='Vertical';$ctrl.Height=105}else{$ctrl.Height=30}
     $ctrl.Text=[string]$script:universalValues[[string]$f.Id]
    }
    $ctrl.Dock='Top';$ctrl.Margin=New-Object Windows.Forms.Padding(0,0,0,10);$ctrl.Tag=[string]$f.Id
    if($f.Type -notin @('multi','repeat')){$ctrl.Add_TextChanged({if(-not $script:universalBuilding){$script:universalValues[[string]$this.Tag]=[string]$this.Text;Update-UniversalCompletion}})}
    $script:universalInputs[[string]$f.Id]=$ctrl;$script:controls+=,$ctrl
    $inputRow=New-Object Windows.Forms.TableLayoutPanel;$inputRow.ColumnCount=2;$inputRow.RowCount=1;$inputRow.AutoSize=$true;$inputRow.Dock='Top'
    $inputRow.Margin=New-Object Windows.Forms.Padding(0)
    [void]$inputRow.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
    [void]$inputRow.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute,32)))
    $dot=New-Object Windows.Forms.Label;$dot.Text='●';$dot.Dock='Fill';$dot.TextAlign='TopCenter';$dot.Font=New-Object Drawing.Font('Segoe UI',14)
    $script:universalIndicators[[string]$f.Id]=$dot
    $inputVisual=$ctrl
    if($ctrl -is [Windows.Forms.TextBox]){$inputVisual=New-MedicalInputFrame $ctrl}
    $inputRow.Controls.Add($inputVisual,0,0);$inputRow.Controls.Add($dot,1,0)
    if($f.Type -eq 'choice_detail'){
     $detailLabel=New-Object Windows.Forms.Label;$detailLabel.Text='Уточнение (необязательно)';$detailLabel.AutoSize=$true
     $detailLabel.Margin=New-Object Windows.Forms.Padding(0,0,0,6)
     $detail=New-Object Windows.Forms.TextBox;$detail.Multiline=$true;$detail.AcceptsReturn=$true;$detail.ScrollBars='Vertical';$detail.Height=60
     $detail.Dock='Top';$detail.Margin=New-Object Windows.Forms.Padding(0,0,0,14);$detail.Tag=[string]$f.Id
     $detail.Text=[string]$script:universalDetails[[string]$f.Id]
     $detail.Add_TextChanged({if(-not $script:universalBuilding){$script:universalDetails[[string]$this.Tag]=[string]$this.Text}})
     $script:universalDetailInputs[[string]$f.Id]=$detail
     $detail.AccessibleName=('Уточнение к полю «'+$f.Label+'»')
     $detailHost=New-Object Windows.Forms.TableLayoutPanel;$detailHost.ColumnCount=1;$detailHost.RowCount=0;$detailHost.AutoSize=$true;$detailHost.AutoSizeMode='GrowAndShrink';$detailHost.Dock='Top'
     $detailHost.Margin=New-Object Windows.Forms.Padding(0,0,0,8)
     [void]$detailHost.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
     $detailHost.Controls.Add($detailLabel);$detailHost.Controls.Add((New-MedicalInputFrame $detail))
     switch(Get-UniversalDetailFormPosition $f){
      'above' {$block.Controls.Add($detailHost);$block.Controls.Add($inputRow)}
      'right' {
       $paired=New-Object Windows.Forms.TableLayoutPanel;$paired.ColumnCount=2;$paired.RowCount=1;$paired.AutoSize=$true;$paired.AutoSizeMode='GrowAndShrink';$paired.Dock='Top'
       $paired.Margin=New-Object Windows.Forms.Padding(0,0,0,8)
       [void]$paired.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,50)))
       [void]$paired.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,50)))
       $detailHost.Margin=New-Object Windows.Forms.Padding(14,0,0,0)
       $paired.Controls.Add($inputRow,0,0);$paired.Controls.Add($detailHost,1,0);$block.Controls.Add($paired)
      }
      default {$block.Controls.Add($inputRow);$block.Controls.Add($detailHost)}
     }
     $ctrl.Add_SelectedIndexChanged({if(-not $script:universalBuilding){Clear-UniversalDetail ([string]$this.Tag)}})
    }else{$block.Controls.Add($inputRow)}

   }
   $flow.Controls.Add($block)
  }
  $panel.Controls.Add($flow);$panel.AutoScrollMinSize=New-Object Drawing.Size(0,0)
  Set-DarkTheme $flow
  $flow.BackColor=$script:darkBg
  foreach($c in $flow.Controls){if($c -is [Windows.Forms.TableLayoutPanel]){$c.BackColor=$script:darkPanel}}
  $panel.AutoScrollPosition=New-Object Drawing.Point(0,0)
  $script:universalFlow=$flow
  Resize-UniversalForm
 }finally{$panel.ResumeLayout($true);$script:universalBuilding=$false}
 Update-UniversalCompletion
 $form.Text='Медицинский конструктор v65 — Первичный осмотр'
 $save.Enabled=$true
 Add-MedicalEndAction
}
function Resize-UniversalForm {
 if($script:universalResizing -or $script:stage -ne 'initial' -or -not $script:universalFlow -or $script:universalFlow.IsDisposed){return}
 $width=[Math]::Max(600,($panel.ClientSize.Width-58))
 if($script:universalFlow.Width -eq $width -and $script:universalFlow.MinimumSize.Width -eq $width){return}
 $script:universalResizing=$true
 $script:universalFlow.SuspendLayout()
 try{
  $script:universalFlow.MaximumSize=New-Object Drawing.Size(0,0)
  $script:universalFlow.MinimumSize=New-Object Drawing.Size($width,0)
  $script:universalFlow.MaximumSize=New-Object Drawing.Size($width,0)
  $script:universalFlow.Width=$width
  foreach($checks in $script:universalMultiInputs.Values){foreach($check in $checks){$check.MaximumSize=New-Object Drawing.Size(([Math]::Max(300,$width-92)),0)}}
 }finally{$script:universalFlow.ResumeLayout($true);$script:universalResizing=$false}
}
function Open-UniversalInitial {
 $path=Get-UniversalTemplatePath
 $script:source=$path;$script:stageTemplates.initial=$path;$script:fields=@();$script:universalWordFields=@()
 if(Test-Path -LiteralPath $path){$script:universalWordFields=@(Get-UniversalWordFields $path)}
 elseif(-not $script:universalConfig.AutoTemplate){throw ('Шаблон не найден: '+$path+'. Выберите его заново кнопкой «Открыть шаблон».')}
 Show-UniversalInitial
}
function Show-UniversalTextPrompt($owner,$title,$value){
 $dlg=New-Object Windows.Forms.Form;$dlg.Text=$title;$dlg.Size=New-Object Drawing.Size(560,185);$dlg.StartPosition='CenterParent';$dlg.FormBorderStyle='FixedDialog';$dlg.MaximizeBox=$false;$dlg.MinimizeBox=$false
 $txt=New-Object Windows.Forms.TextBox;$txt.SetBounds(18,20,505,30);$txt.Text=$value;$dlg.Controls.Add($txt)
 $ok=New-Object Windows.Forms.Button;$ok.Text='Применить';$ok.SetBounds(275,70,120,34);$ok.DialogResult='OK';$dlg.Controls.Add($ok)
 $cancel=New-Object Windows.Forms.Button;$cancel.Text='Отмена';$cancel.SetBounds(405,70,118,34);$cancel.DialogResult='Cancel';$dlg.Controls.Add($cancel)
 $dlg.AcceptButton=$ok;$dlg.CancelButton=$cancel;Set-DarkTheme $dlg
 try{if($dlg.ShowDialog($owner) -eq 'OK' -and -not [string]::IsNullOrWhiteSpace($txt.Text)){return $txt.Text.Trim()};return $null}finally{$dlg.Dispose()}
}
function Show-UniversalFieldEditor($owner,$field){
 $draft=Copy-UniversalObject $field
 $dlg=New-Object Windows.Forms.Form;$dlg.Text='Настройка поля';$dlg.Size=New-Object Drawing.Size(760,680);$dlg.StartPosition='CenterParent';$dlg.FormBorderStyle='FixedDialog';$dlg.MaximizeBox=$false;$dlg.MinimizeBox=$false
 $labels=@(@('Название поля',18),@('Маркер Word — латинские буквы, цифры, подчёркивание',83),@('Тип поля',148),@('Привязка к существующему элементу Word (необязательно)',213),@('Варианты списка — каждый на отдельной строке',278))
 foreach($item in $labels){$l=New-Object Windows.Forms.Label;$l.Text=$item[0];$l.SetBounds(18,[int]$item[1],704,24);$dlg.Controls.Add($l)}
 $name=New-Object Windows.Forms.TextBox;$name.SetBounds(18,44,704,30);$name.Text=$draft.Label;$dlg.Controls.Add($name)
 $marker=New-Object Windows.Forms.TextBox;$marker.SetBounds(18,109,704,30);$marker.Text=$draft.Marker;$dlg.Controls.Add($marker)
 $type=New-Object SafeComboBox;$type.DropDownStyle='DropDownList';$type.SetBounds(18,174,300,30);$type.Items.AddRange([object[]]@('Строка','Многострочный текст','Выпадающий список','Список с уточнением','Подзаголовок','Несколько вариантов (галочки)','Повторяемые строки (+)'));$type.SelectedIndex=@('text','multiline','choice','choice_detail','heading','multi','repeat').IndexOf([string]$draft.Type);$dlg.Controls.Add($type)
 $roleLabel=New-Object Windows.Forms.Label;$roleLabel.Text='Связь с карточкой пациента';$roleLabel.SetBounds(335,148,387,24);$dlg.Controls.Add($roleLabel)
 $role=New-Object SafeComboBox;$role.DropDownStyle='DropDownList';$role.SetBounds(335,174,387,30)
 $role.Items.AddRange([object[]]@('Обычное поле','Ф.И.О. пациента','Дата рождения','Адрес регистрации'));$role.SelectedIndex=@('','name','birth','address').IndexOf([string]$draft.System);$dlg.Controls.Add($role)
 $binding=New-Object SafeComboBox;$binding.DropDownStyle='DropDownList';$binding.SetBounds(18,239,704,30);$binding.DropDownWidth=950;[void]$binding.Items.Add('Только маркер {{'+$draft.Marker+'}} / тег Word');$binding.SelectedIndex=0;$bindingIds=@('')
 foreach($wf in $script:universalWordFields){
  [void]$binding.Items.Add(($wf.Label+' | '+$wf.Context+' | ID '+$wf.Id));$bindingIds+=,[string]$wf.Id
  if($draft.WordId -eq $wf.Id){$binding.SelectedIndex=$binding.Items.Count-1}
 }
 if($draft.WordId -and -not ($bindingIds -contains $draft.WordId)){[void]$binding.Items.Add(('Отсутствует в текущем шаблоне: ID '+$draft.WordId));$bindingIds+=,[string]$draft.WordId;$binding.SelectedIndex=$binding.Items.Count-1}
 $dlg.Controls.Add($binding)
 $options=New-Object Windows.Forms.TextBox;$options.Multiline=$true;$options.AcceptsReturn=$true;$options.ScrollBars='Vertical';$options.SetBounds(18,304,704,140);$options.Text=(@($draft.Options) -join "`r`n");$dlg.Controls.Add($options)
 $note=New-Object Windows.Forms.Label;$note.SetBounds(18,454,704,62);$note.Text='Каждый вариант списка — отдельная строка. «Повторяемые строки (+)»: добавляйте строки и выбирайте или редактируйте текст в каждой. В Word весь список вставляется по одному маркеру поля.';$dlg.Controls.Add($note)
 $requiredCheck=New-Object Windows.Forms.CheckBox;$requiredCheck.Text='Обязательное поле';$requiredCheck.SetBounds(18,527,400,30);$requiredCheck.Checked=(Test-UniversalFieldRequired $draft);$dlg.Controls.Add($requiredCheck)
 $ok=New-Object Windows.Forms.Button;$ok.Text='Применить';$ok.SetBounds(456,577,128,36);$dlg.Controls.Add($ok)
 $cancel=New-Object Windows.Forms.Button;$cancel.Text='Отмена';$cancel.SetBounds(594,577,128,36);$cancel.DialogResult='Cancel';$dlg.Controls.Add($cancel);$dlg.CancelButton=$cancel
 $tabs=New-Object Windows.Forms.TabControl;$tabs.Dock='Fill'
 $fieldTab=New-Object Windows.Forms.TabPage;$fieldTab.Text='Поле';$fieldTab.AutoScroll=$true
 $detailTab=New-Object Windows.Forms.TabPage;$detailTab.Text='Расположение уточнения';$detailTab.AutoScroll=$true
 $tabs.TabPages.Add($fieldTab);$tabs.TabPages.Add($detailTab)
 $footer=New-Object Windows.Forms.Panel;$footer.Dock='Fill'
 foreach($control in @($dlg.Controls)){
  if($control -eq $ok -or $control -eq $cancel){$footer.Controls.Add($control)}else{$fieldTab.Controls.Add($control)}
 }
 $ok.SetBounds(456,14,128,36);$cancel.SetBounds(594,14,128,36);$ok.Anchor='Top,Right';$cancel.Anchor='Top,Right'
 $editorLayout=New-Object Windows.Forms.TableLayoutPanel;$editorLayout.Dock='Fill';$editorLayout.ColumnCount=1;$editorLayout.RowCount=2
 $editorLayout.Margin=New-Object Windows.Forms.Padding(0);$editorLayout.Padding=New-Object Windows.Forms.Padding(0)
 [void]$editorLayout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
 [void]$editorLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent,100)))
 [void]$editorLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute,64)))
 $editorLayout.Controls.Add($tabs,0,0);$editorLayout.Controls.Add($footer,0,1);$dlg.Controls.Add($editorLayout)
 $placementHint=New-Object Windows.Forms.Label;$placementHint.Text='Расположение в форме и в Word настраивается независимо. Эти настройки применяются к типу «Список с уточнением».';$placementHint.SetBounds(18,18,690,54);$detailTab.Controls.Add($placementHint)
 $formPositionLabel=New-Object Windows.Forms.Label;$formPositionLabel.Text='Где показывать уточнение в форме';$formPositionLabel.SetBounds(18,90,690,24);$detailTab.Controls.Add($formPositionLabel)
 $formPosition=New-Object SafeComboBox;$formPosition.DropDownStyle='DropDownList';$formPosition.SetBounds(18,121,690,30)
 $formPosition.Items.AddRange([object[]]@('Под списком','Над списком','Справа от списка'));$formPosition.SelectedIndex=@('below','above','right').IndexOf((Get-UniversalDetailFormPosition $draft));$detailTab.Controls.Add($formPosition)
 $wordPositionLabel=New-Object Windows.Forms.Label;$wordPositionLabel.Text='Куда вставлять уточнение в Word';$wordPositionLabel.SetBounds(18,180,690,24);$detailTab.Controls.Add($wordPositionLabel)
 $wordPosition=New-Object SafeComboBox;$wordPosition.DropDownStyle='DropDownList';$wordPosition.SetBounds(18,211,690,30)
 $wordPosition.Items.AddRange([object[]]@('После варианта: вариант: уточнение','Перед вариантом: уточнение: вариант','С новой строки после варианта','По отдельному маркеру в шаблоне'))
 $wordPosition.SelectedIndex=@('after','before','newline','marker').IndexOf((Get-UniversalDetailWordPosition $draft));$detailTab.Controls.Add($wordPosition)
 $detailMarkerLabel=New-Object Windows.Forms.Label;$detailMarkerLabel.Text='Маркер уточнения (без фигурных скобок)';$detailMarkerLabel.SetBounds(18,270,690,24);$detailTab.Controls.Add($detailMarkerLabel)
 $detailMarker=New-Object Windows.Forms.TextBox;$detailMarker.SetBounds(18,301,690,30);$detailMarker.Text=[string]$draft.DetailMarker
 if(-not $detailMarker.Text){$detailMarker.Text=([string]$draft.Marker+'_DETAIL')};$detailTab.Controls.Add($detailMarker)
 $detailHelp=New-Object Windows.Forms.Label;$detailHelp.SetBounds(18,356,690,125)
 $detailHelp.Text='Пример: основной маркер {{TREATMENT}} содержит выбранный вариант, а {{TREATMENT_DETAIL}} — только уточнение. Поставьте маркер уточнения в нужное место своего Word-шаблона: в абзац, таблицу или колонтитул. В режиме Word по структуре формы отдельное уточнение будет следующим абзацем. Для произвольного места используйте собственный шаблон.'
 $detailTab.Controls.Add($detailHelp)
 $ok.Add_Click({
  if([string]::IsNullOrWhiteSpace($name.Text) -or $marker.Text.Trim().ToUpperInvariant() -notmatch '^[A-Z][A-Z0-9_]*$'){
   [void][Windows.Forms.MessageBox]::Show($dlg,'Укажите название и маркер: буквы A–Z, цифры, _, начиная с буквы.','Настройка поля');return
  }
  $draft.Label=$name.Text.Trim();$draft.Marker=$marker.Text.Trim().ToUpperInvariant();$draft.Type=@('text','multiline','choice','choice_detail','heading','multi','repeat')[$type.SelectedIndex]
  if($draft.Type -eq 'choice_detail'){
   $formPlacement=@('below','above','right')[$formPosition.SelectedIndex]
   $wordPlacement=@('after','before','newline','marker')[$wordPosition.SelectedIndex]
   $markerForDetail=$detailMarker.Text.Trim().ToUpperInvariant()
   if($wordPlacement -eq 'marker' -and ($markerForDetail -cnotmatch '^[A-Z][A-Z0-9_]*$' -or $markerForDetail -eq $draft.Marker -or $markerForDetail -in @('ADMISSION_DATE','ADMISSION_TIME','ADMISSION_DATETIME','DIAGNOSIS_CODE','PATIENT_SEX'))){
    [void][Windows.Forms.MessageBox]::Show($dlg,'Укажите уникальный маркер уточнения: буквы A–Z, цифры и _, начиная с буквы. Он должен отличаться от основного и системных маркеров.','Настройка уточнения');$tabs.SelectedTab=$detailTab;return
   }
   $draft | Add-Member -NotePropertyName DetailFormPosition -NotePropertyValue $formPlacement -Force
   $draft | Add-Member -NotePropertyName DetailWordPosition -NotePropertyValue $wordPlacement -Force
   $draft | Add-Member -NotePropertyName DetailMarker -NotePropertyValue $markerForDetail -Force
  }
  $draft | Add-Member -NotePropertyName Required -NotePropertyValue ([bool]$requiredCheck.Checked) -Force
  $draft.System=@('','name','birth','address')[$role.SelectedIndex]
  $draft.WordId=$bindingIds[$binding.SelectedIndex];$draft.Options=@($options.Lines | Where-Object {-not [string]::IsNullOrWhiteSpace($_)})
  if($draft.Type -in @('heading','multi','repeat')){$draft.WordId='';$draft.System=''}
  if($draft.Type -eq 'heading'){$draft.Required=$false;$draft.Options=@()}
  if($draft.Type -in @('multi','repeat') -and $draft.Options.Count -eq 0){[void][Windows.Forms.MessageBox]::Show($dlg,'Добавьте хотя бы один вариант списка.','Настройка поля');return}
  $dlg.DialogResult='OK';$dlg.Close()
 })
 $updateTypeControls={
  $isHeading=$type.SelectedIndex -eq 4;$isMulti=$type.SelectedIndex -in @(5,6)
  $options.Enabled=$type.SelectedIndex -in @(2,3,5,6)
  $binding.Enabled=-not ($isHeading -or $isMulti);$role.Enabled=-not ($isHeading -or $isMulti)
  $requiredCheck.Enabled=-not $isHeading
  $isDetail=$type.SelectedIndex -eq 3
  $formPosition.Enabled=$isDetail;$wordPosition.Enabled=$isDetail
  $detailMarker.Enabled=$isDetail -and $wordPosition.SelectedIndex -eq 3
  $detailMarkerLabel.Enabled=$detailMarker.Enabled
 }
 $type.Add_SelectedIndexChanged($updateTypeControls);$wordPosition.Add_SelectedIndexChanged($updateTypeControls);& $updateTypeControls
 Set-DarkTheme $dlg
 try{if($dlg.ShowDialog($owner) -eq 'OK'){return $draft};return $null}finally{$dlg.Dispose()}
}
function Show-UniversalSettings {
 Capture-Stage
 if($script:stage -ne 'initial'){$script:stage='initial';Pull-UniversalDemographics;Open-Stage}
 $draft=Copy-UniversalObject $script:universalConfig
 $dlg=New-Object Windows.Forms.Form;$dlg.Text='Настроить форму первичного осмотра';$dlg.Size=New-Object Drawing.Size(1030,760);$dlg.MinimumSize=$dlg.Size;$dlg.StartPosition='CenterParent';$dlg.Font=New-Object Drawing.Font('Segoe UI',10)
 $intro=New-Object Windows.Forms.Label;$intro.Text='Разделы и поля можно добавлять, переименовывать и переставлять. Значения сохраняются по идентификаторам полей.';$intro.SetBounds(20,16,965,45);$dlg.Controls.Add($intro)
 $tree=New-Object Windows.Forms.TreeView;$tree.SetBounds(20,72,690,500);$tree.Anchor='Top,Bottom,Left,Right';$tree.HideSelection=$false;$dlg.Controls.Add($tree)
 function Refresh-UniversalTree {
  $tree.Nodes.Clear()
  foreach($section in $draft.Sections){
   $node=New-Object Windows.Forms.TreeNode([string]$section.Title);$node.Tag=[pscustomobject]@{Kind='section';SectionId=$section.Id;FieldId=''}
   foreach($f in $section.Fields){$child=New-Object Windows.Forms.TreeNode(($f.Label+'  {{'+$f.Marker+'}}'));$child.Tag=[pscustomobject]@{Kind='field';SectionId=$section.Id;FieldId=$f.Id};[void]$node.Nodes.Add($child)}
   [void]$tree.Nodes.Add($node)
  }
  $tree.ExpandAll()
 }
 function Get-SelectedUniversalSection {if($tree.SelectedNode){return (@($draft.Sections | Where-Object {$_.Id -eq $tree.SelectedNode.Tag.SectionId}) | Select-Object -First 1)};return $null}
 function Add-SettingsButton($text,$y,$handler){$b=New-Object Windows.Forms.Button;$b.Text=$text;$b.SetBounds(730,$y,255,36);$b.Anchor='Top,Right';$b.Add_Click($handler);$dlg.Controls.Add($b)}
 Add-SettingsButton '+ Раздел' 72 {
  $title=Show-UniversalTextPrompt $dlg 'Название нового раздела' ''
  if($title){$draft.Sections=@($draft.Sections)+@([pscustomobject]@{Id=[guid]::NewGuid().ToString('N');Title=$title;Fields=@()});Refresh-UniversalTree}
 }
 Add-SettingsButton '+ Поле в раздел' 118 {
  $section=Get-SelectedUniversalSection
  if(-not $section){[void][Windows.Forms.MessageBox]::Show($dlg,'Выберите раздел в списке.');return}
  $id=[guid]::NewGuid().ToString('N');$f=New-UniversalField $id 'Новое поле' ('FIELD_'+$id.Substring(0,8).ToUpperInvariant())
  $edited=Show-UniversalFieldEditor $dlg $f
  if($edited){$section.Fields=@($section.Fields)+@($edited);Refresh-UniversalTree}
 }
 Add-SettingsButton 'Изменить выбранное' 164 {
  $section=Get-SelectedUniversalSection;if(-not $section){return}
  if($tree.SelectedNode.Tag.Kind -eq 'section'){
   $title=Show-UniversalTextPrompt $dlg 'Название раздела' $section.Title;if($title){$section.Title=$title}
  }else{
   $id=$tree.SelectedNode.Tag.FieldId;$field=@($section.Fields | Where-Object {$_.Id -eq $id})[0]
   $edited=Show-UniversalFieldEditor $dlg $field
   if($edited){$section.Fields=@(foreach($f in $section.Fields){if($f.Id -eq $id){$edited}else{$f}})}
  }
  Refresh-UniversalTree
 }
 Add-SettingsButton 'Удалить выбранное' 210 {
  $section=Get-SelectedUniversalSection;if(-not $section){return}
  if([Windows.Forms.MessageBox]::Show($dlg,'Убрать выбранный раздел/поле из формы? Изменение вступит в силу после «Сохранить настройки».','Удаление','YesNo','Question') -ne 'Yes'){return}
  if($tree.SelectedNode.Tag.Kind -eq 'section'){$draft.Sections=@($draft.Sections | Where-Object {$_.Id -ne $section.Id})}
  else{$id=$tree.SelectedNode.Tag.FieldId;$section.Fields=@($section.Fields | Where-Object {$_.Id -ne $id})}
  Refresh-UniversalTree
 }
 function Move-UniversalSelection([int]$direction){
  $section=Get-SelectedUniversalSection;if(-not $section){return}
  $tag=$tree.SelectedNode.Tag
  $items=if($tag.Kind -eq 'section'){@($draft.Sections)}else{@($section.Fields)}
  $id=if($tag.Kind -eq 'section'){$tag.SectionId}else{$tag.FieldId}
  $index=-1;for($i=0;$i -lt $items.Count;$i++){if($items[$i].Id -eq $id){$index=$i;break}}
  $target=$index+$direction;if($index -lt 0 -or $target -lt 0 -or $target -ge $items.Count){return}
  $swap=$items[$index];$items[$index]=$items[$target];$items[$target]=$swap
  if($tag.Kind -eq 'section'){$draft.Sections=@($items)}else{$section.Fields=@($items)}
  Refresh-UniversalTree
  foreach($node in $tree.Nodes){if($tag.Kind -eq 'section' -and $node.Tag.SectionId -eq $id){$tree.SelectedNode=$node};foreach($child in $node.Nodes){if($tag.Kind -eq 'field' -and $child.Tag.FieldId -eq $id){$tree.SelectedNode=$child}}}
 }
 Add-SettingsButton 'Выше' 256 {Move-UniversalSelection -1}
 Add-SettingsButton 'Ниже' 302 {Move-UniversalSelection 1}
 Add-SettingsButton 'Перенести поле в раздел' 348 {
  if(-not $tree.SelectedNode -or $tree.SelectedNode.Tag.Kind -ne 'field'){return}
  $section=Get-SelectedUniversalSection;$id=$tree.SelectedNode.Tag.FieldId
  $pick=New-Object Windows.Forms.Form;$pick.Text='Перенести поле';$pick.Size=New-Object Drawing.Size(570,190);$pick.StartPosition='CenterParent'
  $list=New-Object SafeComboBox;$list.DropDownStyle='DropDownList';$list.SetBounds(20,20,510,30)
  foreach($s in $draft.Sections){[void]$list.Items.Add([string]$s.Title)};$list.SelectedIndex=0;$pick.Controls.Add($list)
  $go=New-Object Windows.Forms.Button;$go.Text='Перенести';$go.SetBounds(380,70,150,34);$go.DialogResult='OK';$pick.Controls.Add($go);Set-DarkTheme $pick
  try{if($pick.ShowDialog($dlg) -eq 'OK'){$target=$draft.Sections[$list.SelectedIndex];if($target.Id -ne $section.Id){$f=@($section.Fields | Where-Object {$_.Id -eq $id})[0];$target.Fields=@($target.Fields)+@($f);$section.Fields=@($section.Fields | Where-Object {$_.Id -ne $id});Refresh-UniversalTree}}}finally{$pick.Dispose()}
 }
 Add-SettingsButton 'Сохранить шаблон Word' 408 {
  $picker=New-Object Windows.Forms.SaveFileDialog;$picker.Filter='Шаблон Word (*.docx)|*.docx';$picker.FileName='Мой шаблон первичного осмотра.docx';$picker.InitialDirectory=$script:medicalTemplatesFolder;$picker.OverwritePrompt=$true
  if($picker.ShowDialog($dlg) -ne 'OK'){return}
  $temp=Join-Path ([IO.Path]::GetDirectoryName($picker.FileName)) ('mc49-template-'+[guid]::NewGuid().ToString('N')+'.tmp')
  try{
   New-UniversalTemplate $temp $draft;Move-Item -LiteralPath $temp -Destination $picker.FileName -Force
   [void][Windows.Forms.MessageBox]::Show($dlg,'Шаблон с маркерами сохранён. Его можно отредактировать в Word и загрузить через «Шаблоны».','Готово')
  }catch{[void][Windows.Forms.MessageBox]::Show($dlg,$_.Exception.Message,'Шаблон Word')}
  finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force}}
 }
 $auto=New-Object Windows.Forms.CheckBox;$auto.Text='Формировать Word по текущим разделам и полям';$auto.SetBounds(20,591,940,30);$auto.Anchor='Bottom,Left,Right';$auto.Checked=[bool]$draft.AutoTemplate;$dlg.Controls.Add($auto)
 $templateInfo=New-Object Windows.Forms.Label;$templateInfo.Text='Если выключено, используется выбранный Word-шаблон. Разделы в нём меняются вручную, ответы вставляются по маркерам.';$templateInfo.SetBounds(20,625,940,40);$templateInfo.Anchor='Bottom,Left,Right';$dlg.Controls.Add($templateInfo)
 $apply=New-Object Windows.Forms.Button;$apply.Text='Применить';$apply.SetBounds(380,672,175,36);$apply.Anchor='Bottom,Right';$dlg.Controls.Add($apply)
 $apply.Add_Click({try{$draft.AutoTemplate=$auto.Checked;if($draft.AutoTemplate){Set-MedicalGeneratedTemplateReference $draft};Apply-UniversalSettingsDraft $draft}catch{[void][Windows.Forms.MessageBox]::Show($dlg,$_.Exception.Message,'Настройка формы')}})
 $ok=New-Object Windows.Forms.Button;$ok.Text='Сохранить настройки';$ok.SetBounds(570,672,240,36);$ok.Anchor='Bottom,Right';$dlg.Controls.Add($ok)
 $cancel=New-Object Windows.Forms.Button;$cancel.Text='Отмена';$cancel.SetBounds(825,672,160,36);$cancel.Anchor='Bottom,Right';$cancel.DialogResult='Cancel';$dlg.Controls.Add($cancel);$dlg.CancelButton=$cancel
 $ok.Add_Click({
  try{
   $draft.AutoTemplate=$auto.Checked
   if($draft.AutoTemplate){Set-MedicalGeneratedTemplateReference $draft}
   Apply-UniversalSettingsDraft $draft
   $dlg.DialogResult='OK';$dlg.Close()
  }catch{[void][Windows.Forms.MessageBox]::Show($dlg,$_.Exception.Message,'Настройка формы')}
 })
 Refresh-UniversalTree;Set-DarkTheme $dlg
 try{[void]$dlg.ShowDialog($form)}finally{$dlg.Dispose()}
}
function Import-LegacyInitial($record){
 # Retain old card answers inside the seven new groups, without using old positional data for new cards.
 $script:universalConfig=New-UniversalConfig;$script:universalValues=@{};$script:universalDetails=@{};$script:universalDetailInputs=@{}
 foreach($s in $script:universalConfig.Sections){if($s.Id -ne 'patient'){$s.Fields=@()}}
 $script:universalValues.patient_name=[string]$record.patientName
 $script:universalValues.patient_birth=[string]$record.birthYear
 $script:universalValues.patient_address=[string]$record.registration
 $path=[string]$record.templates.initial
 if(-not $path -or -not (Test-Path -LiteralPath $path)){$path=Join-Path $PSScriptRoot 'Шаблон первичного осмотра.docx'}
 Read-Template $path
 $saved=@($record.stages.initial)
 for($i=0;$i -lt $script:fields.Count;$i++){
  $old=$script:fields[$i];if($old.IsAddress){continue}
  $sectionId=switch([string]$old.Section){
   'Жалобы' {'complaints'}
   'Анамнез настоящего заболевания' {'history'}
   'Эпид. анамнез' {'history'}
   'Диагноз' {'diagnosis'}
   'План обследования' {'plan'}
   'Назначения' {'prescriptions'}
   'Поступление и экспертный анамнез' {'patient'}
   default {'examination'}
  }
  if($old.HospitalKey -or $old.Context -match 'Экспертный\s+анамнез'){$sectionId='patient'}
  $section=@($script:universalConfig.Sections | Where-Object {$_.Id -eq $sectionId})[0]
  $label=Get-QuestionText $old
  if($old.HospitalKey){$label=@{count='В который раз поступает';referred='Кем направлен';delivered='Какой больницей направлен';order='Порядок поступления'}[[string]$old.HospitalKey]}
  $type=if($old.Options.Count){'choice'}else{'multiline'}
  $f=New-UniversalField ('legacy_'+$i) $label ('LEGACY_'+$i) $type
  $f.Options=@($old.Options);$section.Fields=@($section.Fields)+@($f)
  $script:universalValues[[string]$f.Id]=if($i -lt $saved.Count){[string]$saved[$i]}else{[string]$old.Value}
 }
 # An empty old section still gets one editable generic field.
 $defaults=New-UniversalConfig
 foreach($section in $script:universalConfig.Sections){if(@($section.Fields).Count -eq 0){$section.Fields=@(@($defaults.Sections | Where-Object {$_.Id -eq $section.Id})[0].Fields)}}
 $script:universalInputs=@{};Set-UniversalDemographics
}
function Open-CasePath($path){
 $record=Read-CaseDocument $path
 $script:caseLastSavedPatientName=[string]$record.patientName
 $script:medicalWorkspaceReady=$true;$script:activeMedicalFormPath='';$script:activeMedicalFormName='Форма из карты'
 foreach($button in @($stageInitial,$stageDiary,$stageDischarge)){$button.Enabled=$true}
 $script:caseFolder=[IO.Path]::GetDirectoryName($path);$script:caseFile=$path
 $script:stageData=@{}
 foreach($property in $record.stages.PSObject.Properties){$script:stageData[$property.Name]=@($property.Value)}
 foreach($property in $record.templates.PSObject.Properties){$script:stageTemplates[$property.Name]=[string]$property.Value}
 $script:diaryIndex=[Math]::Max(1,[int]$record.diaryCount)
 $script:stage='initial'
 if($record.universal){Restore-UniversalState $record.universal}
 else{
  $date=[datetime]::MinValue
  if([datetime]::TryParseExact([string]$record.admissionDate,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$date)){$script:admissionControl.Value=$date}
  Import-LegacyInitial $record
 }
 Open-Stage
 $script:medicalFormBaseline=Get-MedicalFormSignature $script:universalConfig
 if(-not $record.universal){[void][Windows.Forms.MessageBox]::Show($form,'Карта прежней версии перенесена в семь универсальных разделов. Старые дополнительные поля сохранены внутри них. В старой карте было только число поступления: время установлено 00:00, уточните его.','Карта открыта')}
}
function Open-UniversalDocument($path){
 $state=Read-UniversalDocumentState $path
 if($state){
  # This is a generated examination, not the saved hospitalization card.
  Reset-NewPatientCase;$script:stage='initial';Restore-UniversalState $state;Open-Stage;return
 }
 try{$record=Read-CaseDocument $path}catch{$record=$null}
 if($record){Open-CasePath $path;return}
 if($script:stage -ne 'initial'){
  Read-Template $path;$script:stageTemplates[$script:stage]=$path;Show-Fields;$save.Enabled=$true;return
 }
 Reset-NewPatientCase;$script:stage='initial';Read-Template $path
 if(@($script:fields).Count -gt 0){
  $record=[pscustomobject]@{patientName=$script:patientName;birthYear=$script:patientBirthYear;registration=$script:patientAddress;templates=[pscustomobject]@{initial=$path};stages=[pscustomobject]@{initial=@($script:fields | ForEach-Object {$_.Value})}}
  Import-LegacyInitial $record;Open-Stage
 }else{
  $script:universalConfig.AutoTemplate=$false;$script:universalConfig.Template=$path;Open-Stage
  [void][Windows.Forms.MessageBox]::Show($form,'Документ открыт как шаблон. Для сохранения нужны маркеры полей. Документы v49 сохраняют данные для повторного открытия; для обычного текста используйте Word.','Документ открыт')
 }
}


# v56: each repeated item is an editable dropdown row.
function Sync-UniversalRepeatRows([string]$id){
 $entry=$script:universalRepeatInputs[$id];if(-not $entry -or $script:universalBuilding){return}
 $value=Get-UniversalInputValue $id
 $script:universalValues[$id]=$value;$entry.Container.Text=$value
 Update-UniversalCompletion
}
function Add-UniversalRepeatRow([string]$id,[string]$value=''){
 $entry=$script:universalRepeatInputs[$id]
 $row=New-Object Windows.Forms.TableLayoutPanel;$row.ColumnCount=2;$row.AutoSize=$true;$row.Dock='Top';$row.Margin=New-Object Windows.Forms.Padding(0,3,0,3)
 [void]$row.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
 [void]$row.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute,42)))
 $editor=New-Object SafeComboBox;$editor.DropDownStyle='DropDown';$editor.DropDownWidth=950;$editor.Dock='Top';$editor.Text=$value;$editor.Tag=$id
 foreach($option in $entry.Options){[void]$editor.Items.Add([string]$option)}
 $editor.Text=$value
 $remove=New-Object Windows.Forms.Button;$remove.Text='−';$remove.Width=36;$remove.Height=30
 $item=[pscustomobject]@{Panel=$row;Editor=$editor};$remove.Tag=[pscustomobject]@{Id=$id;Row=$item}
 $remove.Add_Click({
  $id=[string]$this.Tag.Id;$entry=$script:universalRepeatInputs[$id];$item=$this.Tag.Row
  $entry.Host.Controls.Remove($item.Panel);$entry.Rows.Remove($item);$item.Panel.Dispose();Sync-UniversalRepeatRows $id
 })
 $editor.Add_TextChanged({Sync-UniversalRepeatRows ([string]$this.Tag)})
 $row.Controls.Add($editor,0,0);$row.Controls.Add($remove,1,0)
 [void]$entry.Rows.Add($item);$entry.Host.Controls.Add($row);Set-DarkTheme $row
 Sync-UniversalRepeatRows $id
 if(-not $script:universalBuilding){[void]$editor.Focus()}
}
function New-UniversalRepeatControl($field){
 $id=[string]$field.Id
 $container=New-Object Windows.Forms.TableLayoutPanel;$container.ColumnCount=1;$container.AutoSize=$true;$container.AutoSizeMode='GrowAndShrink'
 [void]$container.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
 $add=New-Object Windows.Forms.Button;$add.Text='+ Добавить строку';$add.Width=190;$add.Height=32;$add.Tag=$id
 $add.Add_Click({Add-UniversalRepeatRow ([string]$this.Tag)})
 $container.Controls.Add($add)
 $hostRows=New-Object Windows.Forms.TableLayoutPanel;$hostRows.ColumnCount=1;$hostRows.AutoSize=$true;$hostRows.Dock='Top'
 [void]$hostRows.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
 $container.Controls.Add($hostRows)
 $script:universalRepeatInputs[$id]=@{Container=$container;Host=$hostRows;Rows=(New-Object System.Collections.ArrayList);Options=@($field.Options)}
 $value=[string]$script:universalValues[$id]
 if($value.Length){foreach($line in [regex]::Split($value,'\r\n|\r|\n')){Add-UniversalRepeatRow $id $line}}
 else{Add-UniversalRepeatRow $id}
 $container.Text=$value
 return $container
}

function Apply-UniversalSettingsDraft($draft){
 Assert-UniversalConfig $draft
 if(-not $draft.AutoTemplate){$p=Get-UniversalTemplatePath $draft;if(-not(Test-Path -LiteralPath $p)){throw ('Не найден Word-шаблон: '+$p)};[void]@(Get-UniversalWordFields $p)}
 Capture-Universal
 $kept=@{};$details=@{}
 foreach($field in Get-UniversalFields $draft){
  $id=[string]$field.Id;$kept[$id]=[string]$script:universalValues[$id]
  if($field.Type -eq 'choice_detail'){$details[$id]=[string]$script:universalDetails[$id]}
 }
 Save-UniversalConfig $draft
 if($draft.ProfileCode -and $draft.ProfileSex){
  $profiles=@(Read-ClinicalProfiles);$existing=Get-ClinicalProfile $profiles ([string]$draft.ProfileCode) ([string]$draft.ProfileSex)
  if($existing){$existing.Schema=Copy-UniversalObject $draft;Write-WorkspaceJson $script:profileFile ([pscustomobject]@{Version=1;Profiles=$profiles})}
 }
 $script:universalConfig=Copy-UniversalObject $draft;$script:universalValues=$kept;$script:universalDetails=$details;$script:stage='initial'
 Open-UniversalInitial
 $panel.PerformLayout();$panel.Invalidate($true);$panel.Refresh()
}
