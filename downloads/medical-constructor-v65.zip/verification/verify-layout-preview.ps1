﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v65'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-LayoutCheck([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
function Import-LayoutFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors | Out-String)}
 foreach($node in $ast.FindAll({param($item) $item -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
  if($names.Count -eq 0 -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}
 }
}
function Set-LayoutPart([string]$path,[string]$name,[byte[]]$bytes){
 $zip=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{$entry=$zip.GetEntry($name);if($entry){$entry.Delete()};$entry=$zip.CreateEntry($name);$stream=$entry.Open();try{$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}}finally{$zip.Dispose()}
}
function Set-LayoutXml([string]$path,[string]$name,[string]$text){Set-LayoutPart $path $name ([Text.Encoding]::UTF8.GetBytes($text))}
function Find-LayoutParagraph($model,[string]$text){return @($model.Paragraphs | Where-Object {$_.Text -ceq $text})[0]}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-layout-test-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 Import-LayoutFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
 Import-LayoutFunctions (Join-Path $Project 'universal.ps1')
 Import-LayoutFunctions (Join-Path $Project 'template-editor-v59.ps1')
 Import-LayoutFunctions (Join-Path $Project 'template-format-v62.ps1')
 Import-LayoutFunctions (Join-Path $Project 'template-layout-preview-v62.ps1')
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main';$path=Join-Path $temp 'layout.docx'
 $config=New-UniversalConfig;New-UniversalTemplate $path $config
 $xml='<?xml version="1.0"?><w:document xmlns:w="'+$script:ns+'" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><w:body>'+
 '<w:p><w:pPr><w:pStyle w:val="Title"/><w:jc w:val="center"/><w:spacing w:before="120" w:after="240"/></w:pPr><w:r><w:t>Заголовок</w:t></w:r></w:p>'+
 '<w:p><w:pPr><w:jc w:val="both"/><w:ind w:left="567" w:right="283" w:firstLine="709"/><w:spacing w:line="360" w:lineRule="auto"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="112233"/></w:rPr><w:t>Жирный</w:t></w:r><w:r><w:rPr><w:i/></w:rPr><w:t>Курсив</w:t></w:r><w:r><w:t>Обычный</w:t></w:r></w:p>'+
 '<w:p><w:r><w:t>&lt;script&gt;alert(&quot;x&quot;)&lt;/script&gt; {{PATIENT_NAME}} &amp; &lt;&gt;</w:t><w:tab/><w:t>табуляция</w:t><w:br/><w:t>Новая строка</w:t></w:r></w:p>'+
 '<w:tbl><w:tblPr><w:tblW w:w="8505" w:type="dxa"/></w:tblPr><w:tblGrid><w:gridCol w:w="2835"/><w:gridCol w:w="5670"/></w:tblGrid><w:tr><w:tc><w:tcPr><w:tcW w:w="2835" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>Ячейка 1</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Ячейка 2</w:t></w:r></w:p></w:tc></w:tr><w:tr><w:tc><w:tcPr><w:gridSpan w:val="2"/></w:tcPr><w:p><w:r><w:t>Объединённая ячейка</w:t></w:r></w:p></w:tc></w:tr></w:tbl>'+
 '<w:p><w:r><w:t>До разрыва</w:t><w:br w:type="page"/><w:t>После разрыва</w:t></w:r></w:p>'+
 '<w:p><w:r><w:drawing><a:blip r:embed="rIdPicture"/></w:drawing></w:r></w:p>'+
 '<w:p><w:r><w:drawing><a:blip r:embed="rIdExternal"/></w:drawing></w:r></w:p>'+
 '<w:p><w:hyperlink r:id="rIdLink"><w:r><w:t>Безопасный текст ссылки</w:t></w:r></w:hyperlink></w:p>'+
 '<w:p><w:pPr><w:spacing w:line="320" w:lineRule="exact"/></w:pPr><w:r><w:t>Точная высота</w:t></w:r></w:p>'+
 '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:left="1417" w:right="850" w:top="1134" w:bottom="1134"/></w:sectPr></w:body></w:document>'
 Set-LayoutXml $path 'word/document.xml' $xml
 Set-LayoutXml $path 'word/styles.xml' ('<w:styles xmlns:w="'+$script:ns+'"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial"/><w:sz w:val="24"/></w:rPr></w:rPrDefault></w:docDefaults><w:style w:type="paragraph" w:styleId="Title"><w:rPr><w:b/><w:sz w:val="36"/></w:rPr></w:style></w:styles>')
 Set-LayoutXml $path 'word/header1.xml' ('<w:hdr xmlns:w="'+$script:ns+'"><w:p><w:r><w:t>Верхняя подпись {{HEADER}}</w:t></w:r></w:p></w:hdr>')
 Set-LayoutXml $path 'word/footer1.xml' ('<w:ftr xmlns:w="'+$script:ns+'"><w:p><w:r><w:t>Нижняя подпись</w:t></w:r></w:p></w:ftr>')
 Set-LayoutXml $path 'word/_rels/document.xml.rels' '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdPicture" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image1.png"/><Relationship Id="rIdExternal" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="https://never-load.invalid/patient.png" TargetMode="External"/><Relationship Id="rIdLink" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="javascript:alert(1)" TargetMode="External"/></Relationships>'
 Set-LayoutPart $path 'word/media/image1.png' ([Convert]::FromBase64String('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aL1kAAAAASUVORK5CYII='))
 $model=Read-MedicalTemplateModel $path;$sourceBytes=[Convert]::ToBase64String([IO.File]::ReadAllBytes($path));$before=($model.PartOrder | ForEach-Object {$model.Parts[$_].Xml.OuterXml}) -join ''
 $selected=Find-LayoutParagraph $model 'Заголовок';$html=ConvertTo-MedicalTemplateHtml $model $selected.Id
 Assert-LayoutCheck ($html.StartsWith('<!DOCTYPE html>') -and $html.EndsWith('</html>')) 'Preview is a standalone HTML document'
 Assert-LayoutCheck ($html.Contains('Макет без пагинации Word') -and $html.Contains('Просмотр Word')) 'Approximate rendering is clearly distinguished from Word pagination'
 Assert-LayoutCheck ($html.Contains('Границы таблиц показаны для удобства')) 'Editor table borders are identified as guides'
 Assert-LayoutCheck ($html.Contains('width:21') -and $html.Contains('cm;padding:2') -and $html.Contains('1.499cm')) 'Actual page dimensions and margins determine the sheet geometry'
 Assert-LayoutCheck ($html.Contains('text-align:center') -and $html.Contains('font-size:18pt')) 'Heading style and alignment render from real Word properties'
 Assert-LayoutCheck ($html.Contains('text-align:justify') -and $html.Contains('text-indent:1.251cm')) 'Justified alignment and first-line indent render'
 Assert-LayoutCheck ($html.Contains('margin-left:1cm') -and $html.Contains('line-height:1.5')) 'Paragraph indentation and line spacing render'
 Assert-LayoutCheck ($html.Contains('margin-top:6pt') -and $html.Contains('margin-bottom:12pt')) 'Spacing before and after are reflected'
 Assert-LayoutCheck ($html.Contains('line-height:16pt')) 'Exact line height uses points instead of a multiplier'
 Assert-LayoutCheck ($html.Contains('font-weight:bold') -and $html.Contains('font-style:italic') -and $html.Contains('color:#112233')) 'Mixed explicit run bold, italic and color render'
 Assert-LayoutCheck ($html -match 'font-weight:normal;font-style:normal;[^>]*>Обычный') 'An ordinary run does not inherit the first run bold formatting'
 Assert-LayoutCheck ($html.Contains('font-family:&quot;Arial&quot;')) 'Font inheritance from document defaults renders'
 Assert-LayoutCheck ($html.Contains('&lt;script&gt;alert(&quot;x&quot;)&lt;/script&gt;')) 'User text resembling a script is escaped'
 Assert-LayoutCheck ($html.Contains('{{PATIENT_NAME}}') -and $html.Contains('&amp; &lt;&gt;')) 'Markers stay visible and XML punctuation stays escaped'
 Assert-LayoutCheck (-not ($html -match '<script|javascript:|never-load\.invalid|<a\b|<iframe|<object|<link\b')) 'Preview creates no executable script, links, network image or active object'
 Assert-LayoutCheck ($html.Contains('default-src &#39;none&#39;')) 'Standalone preview also declares a restrictive content policy'
 Assert-LayoutCheck ($html.Contains('<br />') -and $html.Contains('&#9;')) 'Line breaks and tab characters remain in the flow'
 Assert-LayoutCheck ($html.Contains('class="page-break"') -and $html.Contains('После разрыва')) 'Explicit page break is marked while following text remains visible'
 Assert-LayoutCheck ($html.Contains('<table class="word-table" style="width:15cm;">')) 'Word table width and structure are preserved in preview'
 Assert-LayoutCheck ($html.Contains('<colgroup>') -and $html.Contains('colspan="2"')) 'Grid widths and merged columns are represented'
 Assert-LayoutCheck ($html.Contains('Ячейка 1') -and $html.Contains('Ячейка 2') -and $html.Contains('Объединённая ячейка')) 'All table text remains readable'
 Assert-LayoutCheck ($html.Contains('Верхняя подпись {{HEADER}}') -and $html.Contains('Нижняя подпись')) 'Header and footer contents render with clear part labels'
 Assert-LayoutCheck ($html.Contains('src="data:image/png;base64,')) 'Trusted package-local PNG is embedded without disk or network references'
 Assert-LayoutCheck ($html.Contains('[Изображение — точный вид в «Просмотр Word»]')) 'Unsupported or external images have an honest placeholder'
 Assert-LayoutCheck ($html.Contains('Безопасный текст ссылки')) 'Hyperlink display text survives without its target'
 Assert-LayoutCheck (([regex]::Matches($html,'id="selected-paragraph"')).Count -eq 1) 'The selected paragraph has exactly one preview anchor'
 Assert-LayoutCheck ($before -ceq (($model.PartOrder | ForEach-Object {$model.Parts[$_].Xml.OuterXml}) -join '')) 'Rendering leaves all source XML unchanged'
 Assert-LayoutCheck (@($model.Parts.Values | Where-Object {$_.Modified}).Count -eq 0) 'Rendering does not dirty any source part'
 Assert-LayoutCheck ($sourceBytes -ceq [Convert]::ToBase64String([IO.File]::ReadAllBytes($path))) 'Rendering leaves the source file byte for byte unchanged'
 $plain=ConvertTo-MedicalTemplateHtml $model
 Assert-LayoutCheck (-not $plain.Contains('id="selected-paragraph"')) 'Preview works without a selected paragraph'
 Set-MedicalParagraphFormat $model $selected.Id ([pscustomobject]@{Alignment='right';FontName='Times New Roman';FontSize=16;Bold=$false;Italic=$true;Underline=$true;FontColor='#FF3366';FirstLineCm=0.5;LeftIndentCm=0.75;SpaceBeforePt=8;SpaceAfterPt=10;LineSpacing=2})
 $changed=ConvertTo-MedicalTemplateHtml $model $selected.Id
 Assert-LayoutCheck ($changed.Contains('text-align:right') -and $changed.Contains('font-size:16pt')) 'Changed alignment and font size appear immediately'
 Assert-LayoutCheck ($changed.Contains('text-decoration:underline') -and $changed.Contains('color:#FF3366')) 'Changed underline and color appear immediately'
 Assert-LayoutCheck ($changed.Contains('text-indent:0.499cm') -and $changed.Contains('margin-left:0.75cm')) 'Changed indents appear immediately from actual Word units'
 Assert-LayoutCheck ($changed.Contains('margin-top:8pt') -and $changed.Contains('margin-bottom:10pt') -and $changed.Contains('line-height:2')) 'Changed spacing appears immediately'
 $changedPath=Join-Path $temp 'changed.docx';Write-MedicalTemplateModel $changedPath $model;$reloaded=Read-MedicalTemplateModel $changedPath
 Assert-LayoutCheck ((ConvertTo-MedicalTemplateHtml $reloaded $selected.Id) -ceq $changed) 'Saved and reloaded Word template yields identical layout HTML'
 Set-MedicalParagraphFormat $model $selected.Id @{FontName='Evil";background:url(https://font.invalid);/*'}
 $fontAttack=ConvertTo-MedicalTemplateHtml $model $selected.Id
 Assert-LayoutCheck (-not ($fontAttack -match 'background:url|https://font\.invalid|/\*')) 'Font names cannot introduce CSS or network requests'
 foreach($template in @('Шаблон первичного осмотра.docx','Универсальный первичный осмотр.docx','template.dotx')){
  $actual=Read-MedicalTemplateModel (Join-Path $Project $template);$actualXml=$actual.Parts['word/document.xml'].Xml.OuterXml
  $actualHtml=ConvertTo-MedicalTemplateHtml $actual
  Assert-LayoutCheck ($actualHtml.Contains('<div class="sheet"') -and $actualHtml.Length -gt 1000) ('Shipped Word template renders: '+$template)
  foreach($paragraph in @($actual.Paragraphs | Where-Object {$_.Text} | Select-Object -First 3)){
   # Multi-run paragraphs can insert spans between words; check each actual text node.
   $nodes=$paragraph.Node.SelectNodes('.//w:t',(Get-MedicalEditorNamespace $paragraph.Node.OwnerDocument))
   foreach($node in $nodes){Assert-LayoutCheck ($actualHtml.Contains([Net.WebUtility]::HtmlEncode($node.InnerText))) ('Shipped template text node remains visible: '+$template)}
  }
  Assert-LayoutCheck ($actualXml -ceq $actual.Parts['word/document.xml'].Xml.OuterXml) ('Shipped template is untouched: '+$template)
 }
 Write-Output ('Completed '+$script:checks+' layout-preview checks.')
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
