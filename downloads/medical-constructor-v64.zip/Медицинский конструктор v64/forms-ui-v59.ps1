﻿# Reusable forms and template selection. Patient answers belong to saved cases.
$script:medicalWorkspaceReady=$false
$script:activeMedicalFormPath=''
$script:activeMedicalFormName='Новая форма'
$script:medicalFormBaseline=''

function Get-MedicalFormSignature($config){
 return (Get-MedicalBytesSha256 ([Text.Encoding]::UTF8.GetBytes(((Copy-MedicalFormSchema $config)|ConvertTo-Json -Depth 50 -Compress))))
}
function Test-MedicalWorkspaceHasData {
 foreach($map in @($script:universalValues,$script:universalDetails)){
  if($map){foreach($value in $map.Values){if(-not [string]::IsNullOrWhiteSpace([string]$value)){return $true}}}
 }
 if($script:stageData){foreach($entry in $script:stageData.Values){foreach($value in @($entry)){if(-not [string]::IsNullOrWhiteSpace([string]$value)){return $true}}}}
 if($script:medicalFormBaseline -and (Get-MedicalFormSignature $script:universalConfig) -ne $script:medicalFormBaseline){return $true}
 return $false
}
function Confirm-MedicalFormReset {
 if(-not $script:medicalWorkspaceReady){return $true}
 Capture-Stage
 if(-not (Test-MedicalWorkspaceHasData)){return $true}
 return ([Windows.Forms.MessageBox]::Show($form,'Создание или открытие формы начинает новый осмотр. Ответы пациента и текущие дневники будут очищены. Сохраните карту и изменения формы перед продолжением. Продолжить?','Новая форма / открытие формы','YesNo','Question') -eq 'Yes')
}
function Get-MedicalGeneratedSchema($config){
 $candidate=Copy-MedicalFormSchema $config
 $source=Get-UniversalTemplatePath $candidate
 $wordFields=@();if([IO.File]::Exists($source)){$wordFields=@(Get-UniversalWordFields $source)}
 foreach($field in Get-UniversalFields $candidate){
  if($field.Type -in @('choice','choice_detail') -and @($field.Options).Count -eq 0){
   $bound=@($wordFields | Where-Object {$_.Id -eq $field.WordId})
   if($bound.Count){$field.Options=@($bound[0].Options)}
   if(@($field.Options).Count -eq 0){throw ('Добавьте варианты списка для поля «'+$field.Label+'» перед созданием шаблона по структуре.')}
  }
  $field | Add-Member -NotePropertyName WordId -NotePropertyValue '' -Force
 }
 Assert-UniversalConfig $candidate
 return $candidate
}
function Set-MedicalGeneratedTemplateReference($config){
 $candidate=Get-MedicalGeneratedSchema $config
 $template=New-MedicalTemplateFile 'Шаблон по структуре формы.docx' $candidate
 $config.Template=$template.RelativePath
 foreach($field in Get-UniversalFields $config){
  $generated=@(Get-UniversalFields $candidate | Where-Object {$_.Id -eq $field.Id})[0]
  $field.Options=@($generated.Options);$field | Add-Member -NotePropertyName WordId -NotePropertyValue '' -Force
 }
}
function Show-MedicalTemplateChoice($owner,$config,[bool]$newForm=$true){
 [void](Initialize-MedicalTemplateFolder)
 $templates=@(Get-MedicalTemplates)
 $dialog=New-Object Windows.Forms.Form;$dialog.Text='Шаблоны';$dialog.Size=New-Object Drawing.Size(680,455)
 $dialog.StartPosition='CenterParent';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false
 $result=[pscustomobject]@{Schema=$null;Template=$null;Name=''}
 $hint=New-Object Windows.Forms.Label;$hint.SetBounds(20,20,620,68)
 $hint.Text=if($templates.Count){'Выберите Word-шаблон из папки «Шаблоны», создайте новый по структуре формы или загрузите свой файл.'}else{'Папка «Шаблоны» пока пустая. Создайте шаблон по структуре формы или загрузите свой Word-файл.'}
 $dialog.Controls.Add($hint)
 $list=New-Object Windows.Forms.ComboBox;$list.DropDownStyle='DropDownList';$list.SetBounds(20,105,620,30)
 foreach($template in $templates){[void]$list.Items.Add($template.Name)}
 if($templates.Count){$list.SelectedIndex=0};$dialog.Controls.Add($list)
 $select=New-Object Windows.Forms.Button;$select.Text='Выбрать';$select.SetBounds(20,159,190,42);$select.Enabled=$templates.Count -gt 0;$dialog.Controls.Add($select)
 $create=New-Object Windows.Forms.Button;$create.Text='Создать шаблон';$create.SetBounds(220,159,195,42);$dialog.Controls.Add($create)
 $import=New-Object Windows.Forms.Button;$import.Text='Загрузить свой';$import.SetBounds(425,159,215,42);$dialog.Controls.Add($import)
 $help=New-Object Windows.Forms.Label;$help.SetBounds(20,224,620,112)
 $help.Text='Поддерживаются DOCX и DOTX. Загрузка копирует файл в папку «Шаблоны» рядом с программой. Файлы с одинаковым именем не перезаписываются. Поля и маркеры можно редактировать вместе через «Форма и шаблон».';$dialog.Controls.Add($help)
 $cancel=New-Object Windows.Forms.Button;$cancel.Text='Отмена';$cancel.SetBounds(440,351,200,36);$cancel.DialogResult='Cancel';$dialog.Controls.Add($cancel);$dialog.CancelButton=$cancel
 $select.Add_Click({
  try{
   $item=$templates[$list.SelectedIndex]
   Test-MedicalTemplateBytes ([IO.File]::ReadAllBytes($item.Path))
   $candidate=if($newForm){New-MedicalSchemaFromTemplate $item.Path}else{Copy-MedicalFormSchema $config}
   $candidate.Template=$item.RelativePath;$candidate.AutoTemplate=$false
   Assert-UniversalConfig $candidate
   $result.Schema=$candidate;$result.Template=$item;$result.Name=[IO.Path]::GetFileNameWithoutExtension($item.Name)
   $dialog.DialogResult='OK';$dialog.Close()
  }catch{[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Шаблон')}
 })
 $create.Add_Click({
  try{
   $name=Show-UniversalTextPrompt $dialog 'Название нового шаблона DOCX' 'Мой шаблон.docx'
   if(-not $name){return}
   if([IO.Path]::GetExtension($name) -and [IO.Path]::GetExtension($name) -ne '.docx'){throw 'Для нового шаблона используйте .docx. Готовый .dotx можно загрузить отдельной кнопкой.'}
   $candidate=Get-MedicalGeneratedSchema $config
   $item=New-MedicalTemplateFile $name $candidate
   $candidate.Template=$item.RelativePath;$candidate.AutoTemplate=$false
   $result.Schema=$candidate;$result.Template=$item;$result.Name=[IO.Path]::GetFileNameWithoutExtension($item.Name)
   $dialog.DialogResult='OK';$dialog.Close()
  }catch{[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Создание шаблона')}
 })
 $import.Add_Click({
  $picker=New-Object Windows.Forms.OpenFileDialog;$picker.Filter='Шаблоны Word|*.docx;*.dotx';$picker.Title='Загрузить свой Word-шаблон'
  try{
   if($picker.ShowDialog($dialog) -ne 'OK'){return}
   $item=Import-MedicalTemplate $picker.FileName
   $candidate=if($newForm){New-MedicalSchemaFromTemplate $item.Path}else{Copy-MedicalFormSchema $config}
   $candidate.Template=$item.RelativePath;$candidate.AutoTemplate=$false;Assert-UniversalConfig $candidate
   $result.Schema=$candidate;$result.Template=$item;$result.Name=[IO.Path]::GetFileNameWithoutExtension($item.Name)
   $dialog.DialogResult='OK';$dialog.Close()
  }catch{[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Загрузка шаблона')}
  finally{$picker.Dispose()}
 })
 Set-DarkTheme $dialog
 try{if($dialog.ShowDialog($owner) -eq 'OK'){return $result};return $null}finally{$dialog.Dispose()}
}
function Use-MedicalFormSchema($config,[string]$name,[string]$path=''){
 $candidate=Copy-MedicalFormSchema $config
 $templatePath=Get-UniversalTemplatePath $candidate
 Test-MedicalTemplateBytes ([IO.File]::ReadAllBytes($templatePath))
 # Validate and persist the schema before clearing the current patient.
 Save-UniversalConfig $candidate
 Reset-NewPatientCase $candidate
 $script:stage='initial';$script:medicalWorkspaceReady=$true
 $script:activeMedicalFormName=$name;$script:activeMedicalFormPath=$path
 $script:medicalFormBaseline=Get-MedicalFormSignature $candidate
 foreach($button in @($stageInitial,$stageDiary,$stageDischarge)){$button.Enabled=$true}
 Open-Stage
}
function Invoke-MedicalNewForm {
 try{
  $choice=Show-MedicalTemplateChoice $form (New-UniversalConfig) $true
  if(-not $choice){return}
  $result=Show-MedicalFormTemplateEditor $form $choice.Schema
  if(-not $result){return}
  if(-not (Confirm-MedicalFormReset)){return}
  Use-MedicalFormSchema $result.Schema $choice.Name
 }catch{[void][Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,'Создание формы')}
}
function Invoke-MedicalOpenForm {
 $picker=New-Object Windows.Forms.OpenFileDialog;$picker.Filter='Формы конструктора|*.mcform';$picker.Title='Открыть форму'
 try{
  if($picker.ShowDialog($form) -ne 'OK'){return}
  $candidate=Read-MedicalForm $picker.FileName
  if(-not (Confirm-MedicalFormReset)){return}
  Use-MedicalFormSchema $candidate.Schema $candidate.Name $picker.FileName
 }catch{[void][Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,'Открытие формы')}
 finally{$picker.Dispose()}
}
function Invoke-MedicalSaveForm {
 if(-not $script:medicalWorkspaceReady){Invoke-MedicalNewForm;return}
 $picker=New-Object Windows.Forms.SaveFileDialog;$picker.Filter='Форма конструктора|*.mcform';$picker.DefaultExt='mcform';$picker.AddExtension=$true;$picker.OverwritePrompt=$true;$picker.Title='Сохранить форму и связанный Word-шаблон'
 if($script:activeMedicalFormPath){$picker.FileName=$script:activeMedicalFormPath}else{$picker.FileName=($script:activeMedicalFormName -replace '[\\/:*?"<>|]','_')+'.mcform'}
 try{
  if($picker.ShowDialog($form) -ne 'OK'){return}
  if([IO.Path]::GetExtension($picker.FileName) -ne '.mcform'){throw 'Сохраните форму в файле с расширением .mcform.'}
  [void](Write-MedicalForm $picker.FileName $script:universalConfig ([IO.Path]::GetFileNameWithoutExtension($picker.FileName)))
  $script:activeMedicalFormPath=$picker.FileName;$script:activeMedicalFormName=[IO.Path]::GetFileNameWithoutExtension($picker.FileName)
  $script:medicalFormBaseline=Get-MedicalFormSignature $script:universalConfig
  [void][Windows.Forms.MessageBox]::Show($form,'Форма и её Word-шаблон сохранены. Ответы пациента в этот файл не включены.','Форма сохранена')
 }catch{[void][Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,'Сохранение формы')}
 finally{$picker.Dispose()}
}
function Invoke-MedicalChooseTemplate {
 if(-not $script:medicalWorkspaceReady){Invoke-MedicalNewForm;return}
 try{
  Capture-Stage
  $choice=Show-MedicalTemplateChoice $form $script:universalConfig $false
  if(-not $choice){return}
  if($script:stage -eq 'initial'){
   $candidate=Copy-MedicalFormSchema $choice.Schema;$candidate.Template=$choice.Template.RelativePath;$candidate.AutoTemplate=$false
   Save-UniversalConfig $candidate;$script:universalConfig=$candidate;Open-UniversalInitial
  }else{
   if([Windows.Forms.MessageBox]::Show($form,'Заменить Word-шаблон текущего этапа? Поля этого этапа будут загружены заново; другие этапы сохранятся.','Шаблон этапа','YesNo','Question') -ne 'Yes'){return}
   [void]$script:stageData.Remove((Get-StageKey));$script:stageTemplates[$script:stage]=$choice.Template.Path;Open-Stage
  }
 }catch{[void][Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,'Шаблоны')}
}
function Invoke-MedicalFormTemplateEditor {
 try{
  $candidate=if($script:medicalWorkspaceReady){Copy-MedicalFormSchema $script:universalConfig}else{New-UniversalConfig}
  if($candidate.AutoTemplate){$candidate=Get-MedicalGeneratedSchema $candidate}
  $result=Show-MedicalFormTemplateEditor $form $candidate
  if(-not $result){return}
  if($script:medicalWorkspaceReady){
   Capture-Stage
   if($script:stage -ne 'initial'){Pull-UniversalDemographics}
   Apply-UniversalSettingsDraft $result.Schema
  }else{Use-MedicalFormSchema $result.Schema ([IO.Path]::GetFileNameWithoutExtension($result.Template.Name))}
 }catch{[void][Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,'Форма и Word-шаблон')}
}
function Start-MedicalFormsWorkspace {
 try{
  foreach($button in @($stageInitial,$stageDiary,$stageDischarge)){$button.Enabled=$false}
  [void](Initialize-MedicalTemplateFolder)
  $templates=@(Get-MedicalTemplates)
  $currentPath=Get-UniversalTemplatePath $script:universalConfig
  $prefix=[IO.Path]::GetFullPath($script:medicalTemplatesFolder)+[IO.Path]::DirectorySeparatorChar
  if($templates.Count -gt 0 -and [IO.File]::Exists($currentPath) -and [IO.Path]::GetFullPath($currentPath).StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)){
   Use-MedicalFormSchema $script:universalConfig ([IO.Path]::GetFileNameWithoutExtension($currentPath))
   return
  }
  $choice=Show-MedicalTemplateChoice $form (New-UniversalConfig) $true
  if($choice){
   $result=Show-MedicalFormTemplateEditor $form $choice.Schema
   if($result){Use-MedicalFormSchema $result.Schema $choice.Name;return}
  }
  $script:universalConfig=New-UniversalConfig
  $panel.Controls.Clear();$save.Enabled=$false
  $message=New-Object Windows.Forms.Label;$message.Text='Создайте новую форму или откройте сохранённую. Если папка «Шаблоны» пустая, программа предложит создать или загрузить Word-шаблон.'
  $message.SetBounds(25,25,930,100);$panel.Controls.Add($message);Set-DarkTheme $panel
 }catch{[void][Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,'Подготовка форм')}
}
function Remove-MedicalEndAction {
 if($caseSave -and $caseSave.Parent){$caseSave.Parent.Controls.Remove($caseSave)}
 if($script:medicalEndActionHost -and -not $script:medicalEndActionHost.IsDisposed){
  if($script:medicalEndActionHost.Parent){$script:medicalEndActionHost.Parent.Controls.Remove($script:medicalEndActionHost)}
  $script:medicalEndActionHost.Dispose();$script:medicalEndActionHost=$null
 }
}
function Add-MedicalEndAction {
 if(-not $caseSave -or -not $panel -or -not $script:medicalWorkspaceReady){return}
 Remove-MedicalEndAction
 $hostPanel=New-Object Windows.Forms.FlowLayoutPanel;$hostPanel.AutoSize=$true;$hostPanel.FlowDirection='TopDown';$hostPanel.WrapContents=$false
 $hostPanel.Padding=New-Object Windows.Forms.Padding(10);$hostPanel.Margin=New-Object Windows.Forms.Padding(0,20,0,12)
 $hint=New-Object Windows.Forms.Label;$hint.Text='Карта сохранит ответы пациента и все этапы госпитализации.';$hint.AutoSize=$true;$hostPanel.Controls.Add($hint)
 $caseSave.Width=260;$caseSave.Height=44;$caseSave.Dock='None';$caseSave.Anchor='Top,Left';$caseSave.Margin=New-Object Windows.Forms.Padding(0,10,0,0);$hostPanel.Controls.Add($caseSave)
 if($script:stage -eq 'initial' -and $script:universalFlow -and $panel.Controls.Contains($script:universalFlow)){
  $hostPanel.Dock='Top';$script:universalFlow.Controls.Add($hostPanel)
 }else{
  $bottom=0;foreach($control in $panel.Controls){$bottom=[Math]::Max($bottom,$control.Bottom)}
  $hostPanel.SetBounds(25,($bottom+20),[Math]::Max(600,($panel.ClientSize.Width-55)),90);$hostPanel.Anchor='Top,Left,Right';$panel.Controls.Add($hostPanel)
  $panel.AutoScrollMinSize=New-Object Drawing.Size(0,($bottom+$hostPanel.Height+50))
 }
 $script:medicalEndActionHost=$hostPanel
 Set-DarkTheme $hostPanel
}
