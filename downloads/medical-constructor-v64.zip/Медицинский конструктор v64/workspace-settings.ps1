﻿# v56: local diagnosis profiles and document font settings.
$script:profileFile=Join-Path $PSScriptRoot 'diagnosis-templates.json'
$script:fontFile=Join-Path $PSScriptRoot 'document-font.json'
function Write-WorkspaceJson($path,$value){
 $temp=$path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
 try{[IO.File]::WriteAllText($temp,($value | ConvertTo-Json -Depth 50),[Text.UTF8Encoding]::new($true));Move-Item -LiteralPath $temp -Destination $path -Force}
 finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force}}
}
function Read-ClinicalProfiles {
 if(-not (Test-Path -LiteralPath $script:profileFile)){return @()}
 $data=Get-Content -LiteralPath $script:profileFile -Raw -Encoding UTF8 | ConvertFrom-Json
 return @($data.Profiles)
}
function Get-ClinicalProfile($profiles,[string]$code,[string]$sex){
 return (@($profiles | Where-Object {$_.Code -eq $code -and $_.Sex -eq $sex}) | Select-Object -First 1)
}
function New-ClinicalProfile([string]$code,[string]$sex,[string]$name,$config){
 if([string]::IsNullOrWhiteSpace($code) -or $sex -notin @('M','F')){throw 'Укажите шифр и пол.'}
 Assert-UniversalConfig $config
 return [pscustomobject]@{Code=$code.Trim().ToUpperInvariant();Sex=$sex;Name=$name.Trim();Schema=(Copy-UniversalObject $config)}
}
function Get-ProfilePatientValues($oldConfig,$values,$details,$newConfig){
 $display=Get-UniversalExportValues $oldConfig $values $details;$roles=@{};$result=@{}
 foreach($f in Get-UniversalFields $oldConfig){if($f.System){$roles[[string]$f.System]=[string]$display[[string]$f.Id]}}
 foreach($f in Get-UniversalFields $newConfig){if($f.System){$result[[string]$f.Id]=[string]$roles[[string]$f.System]}}
 return $result
}
function Set-ClinicalProfile($profile){
 $newConfig=Copy-UniversalObject $profile.Schema;Assert-UniversalConfig $newConfig
 if(-not $newConfig.AutoTemplate){
  $path=Get-UniversalTemplatePath $newConfig
  if(-not (Test-Path -LiteralPath $path -PathType Leaf)){throw ('Не найден шаблон: '+$path)}
  [void]@(Get-UniversalWordFields $path)
 }
 Capture-Universal
 $hasClinical=$false
 foreach($f in Get-UniversalFields $script:universalConfig){if(-not $f.System -and $f.Type -ne 'heading' -and -not [string]::IsNullOrWhiteSpace([string]$script:universalValues[[string]$f.Id])){$hasClinical=$true;break}}
 if($hasClinical -and [Windows.Forms.MessageBox]::Show($form,'При смене шаблона клинические ответы будут очищены. Ф.И.О., дата рождения, адрес и время поступления сохранятся. Продолжить?','Смена шаблона','YesNo','Question') -ne 'Yes'){return}
 $values=Get-ProfilePatientValues $script:universalConfig $script:universalValues $script:universalDetails $newConfig
 $newConfig | Add-Member -NotePropertyName ProfileCode -NotePropertyValue $profile.Code -Force
 $newConfig | Add-Member -NotePropertyName ProfileSex -NotePropertyValue $profile.Sex -Force
 $script:universalConfig=$newConfig;$script:universalValues=$values;$script:universalDetails=@{}
 $script:stage='initial';Open-UniversalInitial
}
function New-ClinicalSelector {
 $row=New-Object Windows.Forms.FlowLayoutPanel;$row.AutoSize=$true;$row.Dock='Top';$row.WrapContents=$true
 $label=New-Object Windows.Forms.Label;$label.Text='Шифр / шаблон';$label.AutoSize=$true;$row.Controls.Add($label)
 $codes=New-Object SafeComboBox;$codes.DropDownStyle='DropDownList';$codes.AutoCompleteSource='ListItems';$codes.AutoCompleteMode='SuggestAppend';$codes.Width=180
 $profiles=@(Read-ClinicalProfiles);foreach($code in @($profiles | ForEach-Object {$_.Code} | Sort-Object -Unique)){[void]$codes.Items.Add($code)}
 $active=[string]$script:universalConfig.ProfileCode
 if($active){if(-not $codes.Items.Contains($active)){[void]$codes.Items.Add($active)};$codes.SelectedItem=$active}
 $row.Controls.Add($codes)
 $sex=New-Object SafeComboBox;$sex.DropDownStyle='DropDownList';$sex.Width=140;$sex.Items.AddRange([object[]]@('Мужчина','Женщина'))
 if($script:universalConfig.ProfileSex -in @('M','F')){$sex.SelectedIndex=@('M','F').IndexOf([string]$script:universalConfig.ProfileSex)}
 $row.Controls.Add($sex)
 $script:profileCodeControl=$codes;$script:profileSexControl=$sex
 $handler={
  if($script:universalBuilding -or $script:profileSelecting){return}
  if($script:profileCodeControl.SelectedIndex -lt 0 -or $script:profileSexControl.SelectedIndex -lt 0){return}
  $code=[string]$script:profileCodeControl.SelectedItem;$gender=@('M','F')[$script:profileSexControl.SelectedIndex]
  if($code -eq $script:universalConfig.ProfileCode -and $gender -eq $script:universalConfig.ProfileSex){return}
  $script:profileSelecting=$true
  try{
   $p=Get-ClinicalProfile @(Read-ClinicalProfiles) $code $gender
   if(-not $p){throw 'Для этого шифра и пола шаблон ещё не настроен. Откройте «Каталог шаблонов».'}
   Set-ClinicalProfile $p
  }catch{[void][Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,'Шаблон')}
  finally{
   $script:profileCodeControl.SelectedIndex=-1;$script:profileSexControl.SelectedIndex=-1
   if($script:universalConfig.ProfileCode){$script:profileCodeControl.SelectedItem=[string]$script:universalConfig.ProfileCode}
   if($script:universalConfig.ProfileSex -in @('M','F')){$script:profileSexControl.SelectedIndex=@('M','F').IndexOf([string]$script:universalConfig.ProfileSex)}
   $script:profileSelecting=$false
  }
 }
 $codes.Add_SelectedIndexChanged($handler);$sex.Add_SelectedIndexChanged($handler)
 $manage=New-Object Windows.Forms.Button;$manage.Text='Каталог шаблонов';$manage.Width=180;$manage.Height=32
 $manage.Add_Click({try{Show-ClinicalCatalog;Capture-Universal;Open-UniversalInitial}catch{[void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'Каталог шаблонов')}});$row.Controls.Add($manage)
 $font=New-Object Windows.Forms.Button;$font.Text='Шрифт документа';$font.Width=175;$font.Height=32
 $font.Add_Click({Show-DocumentFontSettings});$row.Controls.Add($font)
 return $row
}
function Show-ClinicalCatalog {
 $dlg=New-Object Windows.Forms.Form;$dlg.Text='Каталог шаблонов по шифру и полу';$dlg.Size=New-Object Drawing.Size(820,610);$dlg.StartPosition='CenterParent'
 $hint=New-Object Windows.Forms.Label;$hint.Text='Запишите текущую структуру формы под шифром и полом. Для другого пола создайте отдельную запись. Ответы пациента в каталог не сохраняются.';$hint.SetBounds(15,15,770,52);$dlg.Controls.Add($hint)
 $list=New-Object Windows.Forms.ListBox;$list.SetBounds(15,75,770,350);$list.Anchor='Top,Bottom,Left,Right';$dlg.Controls.Add($list)
 $catalog=New-Object System.Collections.ArrayList;foreach($p in @(Read-ClinicalProfiles)){[void]$catalog.Add($p)}
 function Refresh-ClinicalCatalogList {$list.Items.Clear();foreach($p in $catalog){$sexName=if($p.Sex -eq 'M'){'Мужчина'}else{'Женщина'};[void]$list.Items.Add(($p.Code+' | '+$sexName+' | '+$p.Name))}}
 $save=New-Object Windows.Forms.Button;$save.Text='Записать текущую форму…';$save.SetBounds(15,440,310,36);$save.Anchor='Bottom,Left';$dlg.Controls.Add($save)
 $delete=New-Object Windows.Forms.Button;$delete.Text='Удалить запись';$delete.SetBounds(340,440,190,36);$delete.Anchor='Bottom,Left';$dlg.Controls.Add($delete)
 $close=New-Object Windows.Forms.Button;$close.Text='Закрыть';$close.SetBounds(610,500,170,36);$close.Anchor='Bottom,Right';$close.DialogResult='OK';$dlg.Controls.Add($close)
 $save.Add_Click({
  $edit=New-Object Windows.Forms.Form;$edit.Text='Шифр, пол и Word-шаблон';$edit.Size=New-Object Drawing.Size(720,430);$edit.StartPosition='CenterParent';$edit.FormBorderStyle='FixedDialog';$edit.MaximizeBox=$false
  $fields=@(@('Шифр диагноза',15),@('Название',85),@('Word-шаблон с маркерами',220))
  foreach($x in $fields){$l=New-Object Windows.Forms.Label;$l.Text=$x[0];$l.SetBounds(15,[int]$x[1],630,24);$edit.Controls.Add($l)}
  $code=New-Object Windows.Forms.TextBox;$code.SetBounds(15,42,300,28);$code.Text=[string]$script:universalConfig.ProfileCode;$edit.Controls.Add($code)
  $gender=New-Object SafeComboBox;$gender.DropDownStyle='DropDownList';$gender.SetBounds(340,42,325,28);$gender.Items.AddRange([object[]]@('Мужчина','Женщина'));$gender.SelectedIndex=0;$edit.Controls.Add($gender)
  $name=New-Object Windows.Forms.TextBox;$name.SetBounds(15,112,650,28);$edit.Controls.Add($name)
  $auto=New-Object Windows.Forms.CheckBox;$auto.Text='Формировать Word по структуре формы';$auto.SetBounds(15,165,650,30);$auto.Checked=[bool]$script:universalConfig.AutoTemplate;$edit.Controls.Add($auto)
  $pathBox=New-Object Windows.Forms.TextBox;$pathBox.SetBounds(15,248,510,28);$pathBox.Text=Get-UniversalTemplatePath;$edit.Controls.Add($pathBox)
  $browse=New-Object Windows.Forms.Button;$browse.Text='Выбрать…';$browse.SetBounds(540,246,125,32);$edit.Controls.Add($browse)
  $browse.Add_Click({$pick=New-Object Windows.Forms.OpenFileDialog;$pick.Filter='Word-шаблон|*.docx;*.dotx';try{if($pick.ShowDialog($edit) -eq 'OK'){$pathBox.Text=$pick.FileName;$auto.Checked=$false}}finally{$pick.Dispose()}})
  $ok=New-Object Windows.Forms.Button;$ok.Text='Сохранить';$ok.SetBounds(380,325,135,34);$edit.Controls.Add($ok)
  $cancel=New-Object Windows.Forms.Button;$cancel.Text='Отмена';$cancel.SetBounds(530,325,135,34);$cancel.DialogResult='Cancel';$edit.Controls.Add($cancel)
  $ok.Add_Click({
   try{
    $schema=Copy-UniversalObject $script:universalConfig;$schema.AutoTemplate=$auto.Checked;$schema.Template=$pathBox.Text.Trim()
    if(-not $schema.AutoTemplate){if(-not(Test-Path -LiteralPath $schema.Template -PathType Leaf)){throw 'Выберите существующий Word-шаблон.'};[void]@(Get-UniversalWordFields $schema.Template)}
    $entry=New-ClinicalProfile $code.Text @('M','F')[$gender.SelectedIndex] $name.Text $schema
    $old=Get-ClinicalProfile @($catalog.ToArray()) $entry.Code $entry.Sex
    if($old -and [Windows.Forms.MessageBox]::Show($edit,'Заменить существующую запись этого шифра и пола текущей формой?','Каталог','YesNo') -ne 'Yes'){return}
    $updated=@($catalog.ToArray() | Where-Object {-not ($_.Code -eq $entry.Code -and $_.Sex -eq $entry.Sex)})+@($entry)
    Write-WorkspaceJson $script:profileFile ([pscustomobject]@{Version=1;Profiles=$updated})
    $catalog.Clear();foreach($p in $updated){[void]$catalog.Add($p)}
    $edit.DialogResult='OK';$edit.Close()
   }catch{[void][Windows.Forms.MessageBox]::Show($edit,$_.Exception.Message,'Каталог')}
  })
  Set-DarkTheme $edit;try{[void]$edit.ShowDialog($dlg)}finally{$edit.Dispose()};Refresh-ClinicalCatalogList
 })
 $delete.Add_Click({
  if($list.SelectedIndex -lt 0){return}
  if([Windows.Forms.MessageBox]::Show($dlg,'Удалить запись из каталога? Word-файл останется на диске.','Каталог','YesNo') -ne 'Yes'){return}
  $index=$list.SelectedIndex;$updated=@(for($i=0;$i -lt $catalog.Count;$i++){if($i -ne $index){$catalog[$i]}})
  try{Write-WorkspaceJson $script:profileFile ([pscustomobject]@{Version=1;Profiles=$updated});$catalog.Clear();foreach($p in $updated){[void]$catalog.Add($p)};Refresh-ClinicalCatalogList}catch{[void][Windows.Forms.MessageBox]::Show($_.Exception.Message)}
 })
 Refresh-ClinicalCatalogList;Set-DarkTheme $dlg;try{[void]$dlg.ShowDialog($form)}finally{$dlg.Dispose()}
}
function Load-DocumentFont {
 if(Test-Path -LiteralPath $script:fontFile){return (Get-Content -LiteralPath $script:fontFile -Raw -Encoding UTF8 | ConvertFrom-Json)}
 return [pscustomobject]@{Enabled=$false;Name='Times New Roman';Size=12}
}
function Show-DocumentFontSettings {
 $current=Load-DocumentFont
 $dlg=New-Object Windows.Forms.Form;$dlg.Text='Шрифт всего Word-документа';$dlg.Size=New-Object Drawing.Size(560,280);$dlg.StartPosition='CenterParent';$dlg.FormBorderStyle='FixedDialog';$dlg.MaximizeBox=$false
 $enabled=New-Object Windows.Forms.CheckBox;$enabled.Text='Одинаковый шрифт во всём документе (заменяет шрифт шаблона)';$enabled.SetBounds(15,15,510,30);$enabled.Checked=[bool]$current.Enabled -and -not ($script:stage -eq 'initial' -and [bool]$script:universalConfig.PreserveTemplateFormatting);$dlg.Controls.Add($enabled)
 $name=New-Object Windows.Forms.ComboBox;$name.SetBounds(15,65,365,30);foreach($font in [Drawing.FontFamily]::Families){[void]$name.Items.Add($font.Name)};$name.Text=$current.Name;$dlg.Controls.Add($name)
 $size=New-Object Windows.Forms.NumericUpDown;$size.SetBounds(395,65,125,30);$size.Minimum=6;$size.Maximum=72;$size.DecimalPlaces=1;$size.Increment=0.5;$size.Value=[decimal]$current.Size;$dlg.Controls.Add($size)
 $note=New-Object Windows.Forms.Label;$note.Text='При включении шрифт и размер абзацев заменяются общей настройкой. Снимите галочку, чтобы сохранить оформление из редактора. Жирное и курсив сохраняются.';$note.SetBounds(15,110,510,65);$dlg.Controls.Add($note)
 $ok=New-Object Windows.Forms.Button;$ok.Text='Сохранить';$ok.SetBounds(235,185,135,32);$dlg.Controls.Add($ok)
 $cancel=New-Object Windows.Forms.Button;$cancel.Text='Отмена';$cancel.SetBounds(385,185,135,32);$cancel.DialogResult='Cancel';$dlg.Controls.Add($cancel)
 $ok.Add_Click({try{if([string]::IsNullOrWhiteSpace($name.Text)){throw 'Укажите шрифт.'};if($script:stage -eq 'initial' -and $script:universalConfig){$schema=Copy-MedicalFormSchema $script:universalConfig;$schema | Add-Member -NotePropertyName PreserveTemplateFormatting -NotePropertyValue (-not [bool]$enabled.Checked) -Force;Save-UniversalConfig $schema;$script:universalConfig=$schema};Write-WorkspaceJson $script:fontFile ([pscustomobject]@{Enabled=$enabled.Checked;Name=$name.Text.Trim();Size=[double]$size.Value});$dlg.DialogResult='OK';$dlg.Close()}catch{[void][Windows.Forms.MessageBox]::Show($_.Exception.Message)}})
 Set-DarkTheme $dlg;try{[void]$dlg.ShowDialog($form)}finally{$dlg.Dispose()}
}
function Set-DocumentFontXml($xml,$font){
 $ns=New-Object Xml.XmlNamespaceManager($xml.NameTable);$ns.AddNamespace('w',$script:ns)
 $half=[string][int][Math]::Round(([double]$font.Size*2))
 foreach($run in @($xml.SelectNodes('//w:r',$ns))){if(-not $run.SelectSingleNode('./w:rPr',$ns)){$rp=$xml.CreateElement('w','rPr',$script:ns);[void]$run.PrependChild($rp)}}
 foreach($style in @($xml.SelectNodes('//w:style|//w:rPrDefault',$ns))){if(-not $style.SelectSingleNode('./w:rPr',$ns)){$rp=$xml.CreateElement('w','rPr',$script:ns);$after=$style.SelectSingleNode('./w:tblPr|./w:trPr|./w:tcPr|./w:tblStylePr',$ns);if($after){[void]$style.InsertBefore($rp,$after)}else{[void]$style.AppendChild($rp)}}}
 foreach($rp in @($xml.SelectNodes('//w:rPr',$ns))){
  $fonts=$rp.SelectSingleNode('./w:rFonts',$ns);if(-not $fonts){$fonts=$xml.CreateElement('w','rFonts',$script:ns);[void]$rp.PrependChild($fonts)}
  [void]$rp.RemoveChild($fonts);$runStyle=$rp.SelectSingleNode('./w:rStyle',$ns);if($runStyle){[void]$rp.InsertAfter($fonts,$runStyle)}else{[void]$rp.PrependChild($fonts)}
  foreach($attr in @('asciiTheme','hAnsiTheme','eastAsiaTheme','cstheme','csTheme')){$fonts.RemoveAttribute($attr,$script:ns)}
  foreach($attr in @('ascii','hAnsi','eastAsia','cs')){[void]$fonts.SetAttribute($attr,$script:ns,[string]$font.Name)}
  foreach($tag in @('sz','szCs')){$node=$rp.SelectSingleNode('./w:'+$tag,$ns);if(-not $node){$node=$xml.CreateElement('w',$tag,$script:ns);[void]$rp.AppendChild($node)};[void]$node.SetAttribute('val',$script:ns,$half);[void]$rp.RemoveChild($node);$following=$rp.SelectSingleNode('./w:highlight|./w:u|./w:effect|./w:bdr|./w:shd|./w:fitText|./w:vertAlign|./w:rtl|./w:cs|./w:em|./w:lang|./w:eastAsianLayout|./w:specVanish|./w:oMath|./w:rPrChange',$ns);if($tag -eq 'sz'){$sizeCs=$rp.SelectSingleNode('./w:szCs',$ns);if($sizeCs){$following=$sizeCs}};if($following){[void]$rp.InsertBefore($node,$following)}else{[void]$rp.AppendChild($node)}}
 }
}
function Apply-DocumentFont([string]$path){
 $font=Load-DocumentFont;if(-not $font.Enabled){return}
 if([string]::IsNullOrWhiteSpace([string]$font.Name) -or [double]$font.Size -lt 6 -or [double]$font.Size -gt 72){throw 'Некорректная настройка шрифта документа.'}
 $tmp=$path+'.'+[guid]::NewGuid().ToString('N')+'.font';$src=$null;$dst=$null
 try{
  $src=[IO.Compression.ZipFile]::OpenRead($path);$dst=[IO.Compression.ZipFile]::Open($tmp,[IO.Compression.ZipArchiveMode]::Create)
  foreach($entry in $src.Entries){
   if($entry.FullName -match '^word/(document|header\d*|footer\d*|footnotes|endnotes|comments|styles|numbering)\.xml$'){
    $x=Get-XmlPart $src $entry.FullName;Set-DocumentFontXml $x $font;Write-UniversalZipText $dst $entry.FullName $x.OuterXml
   }else{$new=$dst.CreateEntry($entry.FullName);$inputStream=$entry.Open();$outputStream=$new.Open();try{$inputStream.CopyTo($outputStream)}finally{$inputStream.Dispose();$outputStream.Dispose()}}
  }
  $dst.Dispose();$dst=$null;$src.Dispose();$src=$null;Move-Item -LiteralPath $tmp -Destination $path -Force
 }finally{if($src){$src.Dispose()};if($dst){$dst.Dispose()};if(Test-Path -LiteralPath $tmp){Remove-Item -LiteralPath $tmp -Force}}
}
