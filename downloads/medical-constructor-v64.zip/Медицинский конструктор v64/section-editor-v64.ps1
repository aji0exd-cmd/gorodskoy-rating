﻿# v64: rename the current form section by its stable ID.
# Word text changes only when the user explicitly selects the optional checkbox.

function Get-MedicalFormSectionById($schema,[string]$sectionId){
 if(-not $schema -or [string]::IsNullOrWhiteSpace($sectionId)){throw 'Выберите раздел формы.'}
 $sections=@($schema.Sections | Where-Object {[string]$_.Id -ieq $sectionId})
 if($sections.Count -ne 1){throw 'Раздел не найден или его идентификатор повторяется. Выберите раздел заново.'}
 return $sections[0]
}

function Set-MedicalFormSectionTitle($schema,[string]$sectionId,[string]$title){
 $section=Get-MedicalFormSectionById $schema $sectionId
 if([string]::IsNullOrWhiteSpace($title)){throw 'Укажите название раздела.'}
 $section.Title=$title.Trim()
 return $section
}

function Invoke-MedicalSectionRename($schema,[string]$sectionId,[string]$title,$model=$null,[string]$paragraphId='',[bool]$replaceWord=$false){
 # Validate both targets before changing either one; never act on a stale tree Tag.
 $section=Get-MedicalFormSectionById $schema $sectionId
 if([string]::IsNullOrWhiteSpace($title)){throw 'Укажите название раздела.'}
 $title=$title.Trim();$paragraph=$null;$backup=$null;$oldText='';$oldModified=$false;$oldXml=''
 if($replaceWord){
  if(-not $model -or [string]::IsNullOrWhiteSpace($paragraphId)){throw 'Выберите обычный абзац Word для замены текста.'}
  $matches=@($model.Paragraphs | Where-Object {$_.Id -ceq $paragraphId})
  if($matches.Count -ne 1){throw 'Выбранный абзац Word не найден. Выберите его заново.'}
  $paragraph=$matches[0]
  if(-not $paragraph.Editable){throw 'Этот абзац Word содержит сложные элементы и доступен только для чтения.'}
  if(-not $paragraph.Node -or -not $model.Parts.ContainsKey([string]$paragraph.Part)){throw 'Не удалось прочитать выбранный абзац Word.'}
  $backup=$paragraph.Node.CloneNode($true);$oldXml=$paragraph.Node.OuterXml
  $oldText=[string]$paragraph.Text;$oldModified=[bool]$model.Parts[$paragraph.Part].Modified
 }
 try{
  if($replaceWord){Set-MedicalTemplateParagraph $model $paragraph.Id $title}
  $section=Set-MedicalFormSectionTitle $schema $sectionId $title
  $wordChanged=$replaceWord -and ($paragraph.Node.OuterXml -cne $oldXml)
  return [pscustomobject]@{Section=$section;WordChanged=[bool]$wordChanged;ParagraphId=$(if($replaceWord){[string]$paragraph.Id}else{''})}
 }catch{
  if($backup){
   # Keep the original XML node identity so the editor's selected paragraph remains valid.
   while($paragraph.Node.HasChildNodes){[void]$paragraph.Node.RemoveChild($paragraph.Node.FirstChild)}
   foreach($child in @($backup.ChildNodes)){[void]$paragraph.Node.AppendChild($child.CloneNode($true))}
   $paragraph.Text=$oldText;$model.Parts[$paragraph.Part].Modified=$oldModified
  }
  throw
 }
}

function Show-MedicalSectionRenameDialog($owner,$schema,[string]$sectionId,$model=$null,$paragraph=$null){
 $section=Get-MedicalFormSectionById $schema $sectionId
 $dialog=New-Object Windows.Forms.Form;$dialog.Text='Редактировать раздел'
 $dialog.StartPosition='CenterParent';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false
 $dialog.AutoScaleMode='Font';$dialog.ClientSize=New-Object Drawing.Size(620,324)
 $layout=New-Object Windows.Forms.TableLayoutPanel;$layout.Dock='Fill';$layout.Padding=New-Object Windows.Forms.Padding(12);$layout.ColumnCount=1;$layout.RowCount=6
 foreach($height in @(26,34,42,74,54,42)){[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',$height)))}
 $caption=New-Object Windows.Forms.Label;$caption.Text='Название раздела';$caption.Dock='Fill';$caption.TextAlign='MiddleLeft'
 $titleBox=New-Object Windows.Forms.TextBox;$titleBox.Text=[string]$section.Title;$titleBox.Dock='Fill';$titleBox.Enabled=$true;$titleBox.ReadOnly=$false
 $wordOption=New-Object Windows.Forms.CheckBox;$wordOption.Text='Заменить текст выбранного абзаца Word на это название';$wordOption.Dock='Fill';$wordOption.Checked=$false
 $wordDescription=New-Object Windows.Forms.Label;$wordDescription.Dock='Fill';$wordDescription.AutoEllipsis=$true
 $wordEditable=$null -ne $model -and $null -ne $paragraph -and [bool]$paragraph.Editable
 if($wordEditable){
  $preview=([string]$paragraph.Text -replace '[\r\n\t]+',' ')
  if($preview.Length -gt 180){$preview=$preview.Substring(0,180)+'…'}
  $wordDescription.Text='Выбранный абзац Word: '+$preview
 }elseif($paragraph){$wordDescription.Text='Выбранный абзац содержит сложные элементы Word. Название раздела можно изменить; текст этого абзаца останется прежним.'}
 else{$wordDescription.Text='Абзац Word не выбран. Название раздела можно изменить отдельно от текста шаблона.'}
 $wordOption.Enabled=$wordEditable
 $explanation=New-Object Windows.Forms.Label;$explanation.Dock='Fill';$explanation.Text='Название меняется в структуре формы. Для изменения текста Word включите флажок выше. Поля раздела сохраняются.'
 $buttons=New-Object Windows.Forms.FlowLayoutPanel;$buttons.Dock='Fill';$buttons.FlowDirection='RightToLeft'
 $cancel=New-Object Windows.Forms.Button;$cancel.Text='Отмена';$cancel.Width=100;$cancel.Height=30
 $rename=New-Object Windows.Forms.Button;$rename.Text='Переименовать';$rename.Width=144;$rename.Height=30
 [void]$buttons.Controls.Add($cancel);[void]$buttons.Controls.Add($rename)
 [void]$layout.Controls.Add($caption,0,0);[void]$layout.Controls.Add($titleBox,0,1);[void]$layout.Controls.Add($wordOption,0,2)
 [void]$layout.Controls.Add($wordDescription,0,3);[void]$layout.Controls.Add($explanation,0,4);[void]$layout.Controls.Add($buttons,0,5)
 [void]$dialog.Controls.Add($layout);$dialog.AcceptButton=$rename;$dialog.CancelButton=$cancel
 $renameState=@{Result=$null}
 # WinForms callbacks run in a closure module. Capture the private script function itself.
 $renameCommand=Get-Command Invoke-MedicalSectionRename -CommandType Function -ErrorAction Stop
 $selectedParagraphId=if($paragraph){[string]$paragraph.Id}else{''}
 $rename.Add_Click({
  try{
   $renameState.Result=& $renameCommand $schema $sectionId $titleBox.Text $model $selectedParagraphId ([bool]($wordOption.Enabled -and $wordOption.Checked))
   $dialog.DialogResult='OK';$dialog.Close()
  }catch{[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Редактировать раздел','OK','Warning')}
 }.GetNewClosure())
 $cancel.Add_Click({$dialog.DialogResult='Cancel';$dialog.Close()}.GetNewClosure())
 $dialog.Add_Shown({[void]$titleBox.Focus();$titleBox.SelectAll()}.GetNewClosure())
 try{
  if(Get-Command Set-DarkTheme -ErrorAction SilentlyContinue){Set-DarkTheme $dialog}
  $titleBox.Enabled=$true;$titleBox.ReadOnly=$false
  [void]$dialog.ShowDialog($owner)
  return $renameState.Result
 }finally{$dialog.Dispose()}
}
