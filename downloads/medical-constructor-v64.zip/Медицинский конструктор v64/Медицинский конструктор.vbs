Option Explicit
Dim sh, fs, dir, cmd
Set sh = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
dir = fs.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = dir
cmd = "powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File " & Chr(34) & fs.BuildPath(dir, "launcher.ps1") & Chr(34)
sh.Run cmd, 0, False
