﻿# Word renders a private snapshot; the original template and open user documents
# are never touched. This optional renderer is not needed for editing or saving.
# API: https://learn.microsoft.com/en-us/office/vba/api/word.page.enhmetafilebits
# The official MicrosoftDocs/VBA-Docs source documents an EMF byte array and
# Page.Width/Height in points. Native Word rendering requires Windows + Word.

function New-MedicalPreviewWordApplication {
 if([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT){throw 'Предпросмотр страниц доступен в Windows с установленным Microsoft Word.'}
 if([Threading.Thread]::CurrentThread.GetApartmentState() -ne [Threading.ApartmentState]::STA){throw 'Для предпросмотра Word запустите программу через «Медицинский конструктор.vbs» или START.cmd.'}
 try{return (New-Object -ComObject Word.Application -ErrorAction Stop)}
 catch{throw 'Microsoft Word не удалось запустить. Проверьте, что настольный Word установлен и открывается обычным способом.'}
}

function Release-MedicalPreviewComObject($value){
 if($null -ne $value -and [Runtime.InteropServices.Marshal]::IsComObject($value)){
  try{[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($value)}catch{}
 }
}

function Save-MedicalPreviewPage([byte[]]$bytes,[double]$widthPoints,[double]$heightPoints,[string]$path,[int]$dpi){
 if($bytes.Length -eq 0 -or $bytes.Length -gt 67108864){throw 'Word вернул пустое или слишком большое изображение страницы.'}
 if([double]::IsNaN($widthPoints) -or [double]::IsInfinity($widthPoints) -or [double]::IsNaN($heightPoints) -or [double]::IsInfinity($heightPoints)){throw 'Word вернул некорректный размер страницы.'}
 $width=[int][math]::Ceiling($widthPoints*$dpi/72.0);$height=[int][math]::Ceiling($heightPoints*$dpi/72.0)
 if($width -lt 1 -or $height -lt 1 -or $width -gt 10000 -or $height -gt 10000 -or ([long]$width*$height) -gt 40000000){throw 'Размер страницы слишком велик для встроенного предпросмотра.'}
 $stream=$null;$metafile=$null;$bitmap=$null;$graphics=$null
 try{
  $stream=[IO.MemoryStream]::new($bytes,$false)
  $metafile=[Drawing.Imaging.Metafile]::new($stream)
  $bitmap=[Drawing.Bitmap]::new($width,$height,[Drawing.Imaging.PixelFormat]::Format32bppArgb)
  $bitmap.SetResolution($dpi,$dpi)
  $graphics=[Drawing.Graphics]::FromImage($bitmap)
  $graphics.Clear([Drawing.Color]::White)
  $graphics.SmoothingMode=[Drawing.Drawing2D.SmoothingMode]::HighQuality
  $graphics.InterpolationMode=[Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $graphics.DrawImage($metafile,[Drawing.Rectangle]::new(0,0,$width,$height))
  $bitmap.Save($path,[Drawing.Imaging.ImageFormat]::Png)
 }finally{
  if($graphics){$graphics.Dispose()};if($bitmap){$bitmap.Dispose()}
  if($metafile){$metafile.Dispose()};if($stream){$stream.Dispose()}
 }
}

function Remove-MedicalWordPreview($preview){
 if($null -eq $preview -or -not $preview.TempFolder){return}
 $folder=[IO.Path]::GetFullPath([string]$preview.TempFolder)
 $temp=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar)
 $parent=[IO.Path]::GetDirectoryName($folder).TrimEnd([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar)
 if(-not [string]::Equals($parent,$temp,[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetFileName($folder) -notmatch '^mc-word-preview-[0-9a-f]{32}$'){
  throw 'Папка не принадлежит встроенному предпросмотру Word.'
 }
 if([IO.Directory]::Exists($folder)){[IO.Directory]::Delete($folder,$true)}
}

function New-MedicalWordPreview($model,[ValidateRange(1,100)][int]$maxPages=100,[ValidateRange(72,180)][int]$dpi=120){
 $word=$null;$documents=$null;$document=$null;$window=$null;$view=$null
 $panes=$null;$pane=$null;$pages=$null;$page=$null;$folder=$null;$success=$false
 $stage='word';$wordAvailable=$false
 try{
  # Create a new automation instance. Never attach to an existing user window.
  $word=New-MedicalPreviewWordApplication;$wordAvailable=$true;$stage='render'
  $word.Visible=$false;$word.DisplayAlerts=0;$word.AutomationSecurity=3
  $folder=Join-Path ([IO.Path]::GetTempPath()) ('mc-word-preview-'+[guid]::NewGuid().ToString('N'))
  [void][IO.Directory]::CreateDirectory($folder)
  $extension=[string]$model.TemplateExtension
  if($extension -notin @('.docx','.dotx')){throw 'Предпросмотр поддерживает только обычные DOCX и DOTX без макросов.'}
  $snapshot=Join-Path $folder ('preview'+$extension)
  [void](Write-MedicalTemplateModel $snapshot $model)
  $documents=$word.Documents
  # ConfirmConversions=false, ReadOnly=true, AddToRecentFiles=false.
  $document=$documents.Open($snapshot,$false,$true,$false)
  $window=$document.ActiveWindow;$view=$window.View;$view.Type=3
  [void]$document.Repaginate()
  $panes=$window.Panes;$pane=$panes.Item(1);$pages=$pane.Pages
  $pageCount=[int]$pages.Count
  if($pageCount -lt 1){throw 'Word не вернул страницы документа.'}
  $images=New-Object Collections.ArrayList;$limit=[math]::Min($pageCount,$maxPages)
  for($number=1;$number -le $limit;$number++){
   $page=$pages.Item($number)
   try{
    $path=Join-Path $folder ('page-'+$number.ToString('D3')+'.png')
    $width=[double]$page.Width;$height=[double]$page.Height
    Save-MedicalPreviewPage ([byte[]]$page.EnhMetaFileBits) $width $height $path $dpi
    if(-not [IO.File]::Exists($path)){throw 'Изображение страницы не было создано.'}
    [void]$images.Add([pscustomobject]@{Number=$number;Path=$path;WidthPoints=$width;HeightPoints=$height})
   }finally{Release-MedicalPreviewComObject $page;$page=$null}
  }
  $truncated=$pageCount -gt $limit
  $message=if($truncated){'Предпросмотр Word: показаны первые '+$limit+' из '+$pageCount+' страниц.'}else{'Предпросмотр Word: '+$pageCount+' стр. Это сохранённый вид шаблона; после правок нажмите «Обновить страницы».'}
  $success=$true
  return [pscustomobject]@{Available=$true;WordAvailable=$true;Pages=@($images.ToArray());TempFolder=$folder;PageCount=$pageCount;Truncated=$truncated;Message=$message}
 }catch{
  $message=if($stage -eq 'word'){[string]$_.Exception.Message}else{'Word не смог построить предпросмотр: '+[string]$_.Exception.Message}
  return [pscustomobject]@{Available=$false;WordAvailable=$wordAvailable;Pages=@();TempFolder=$null;PageCount=0;Truncated=$false;Message=$message}
 }finally{
  # Release only COM wrappers acquired by this renderer. Close our private
  # document without saving and quit the newly created automation instance.
  foreach($com in @($page,$pages,$pane,$panes,$view,$window)){Release-MedicalPreviewComObject $com}
  if($document){try{[void]$document.Close(0)}catch{};Release-MedicalPreviewComObject $document}
  Release-MedicalPreviewComObject $documents
  if($word){try{[void]$word.Quit(0)}catch{};Release-MedicalPreviewComObject $word}
  if(-not $success -and $folder){try{Remove-MedicalWordPreview ([pscustomobject]@{TempFolder=$folder})}catch{}}
 }
}
