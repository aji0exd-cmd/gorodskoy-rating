﻿function Initialize-MedicalParagraphFormatControls {
 if('MedicalWordParagraphEditor' -as [type]){return}
 Add-Type -ReferencedAssemblies 'System.Windows.Forms','System.Drawing' -TypeDefinition @'
using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
public static class MedicalWordLayoutMath {
 public static int CmToPixels(double cm, double dpi) { return (int)Math.Round(cm * dpi / 2.54); }
 public static int CmToTwips(double cm) { return (int)Math.Round(cm * 1440.0 / 2.54); }
 public static int PointsToTwips(double points) { return (int)Math.Round(points * 20.0); }
 public static ushort AlignmentCode(string alignment) { switch(alignment) { case "center": return 3; case "right": return 2; case "both": return 4; default: return 1; } }
 public static double Clamp(double value, double low, double high) { return Math.Max(low,Math.Min(high,value)); }
 public static int FitPaperWidth(int viewportWidth) { return Math.Max(1,viewportWidth-16); }
 public static double FitZoom(int paperWidth,int scrollbarWidth,double widthCm,double dpi) {
  double contentPixels=Math.Max(1,paperWidth-12-Math.Max(0,scrollbarWidth));
  double naturalPixels=Math.Max(.01,widthCm)*Math.Max(1,dpi)/2.54;
  // RichTextBox accepts zoom strictly between 1/64 and 64 and quantizes to 1/1000.
  return Clamp(contentPixels/naturalPixels,.016,63.999);
 }
}
public class MedicalWordParagraphEditor : RichTextBox {
 [StructLayout(LayoutKind.Sequential)]
 private struct ParagraphFormat {
  public uint cbSize, dwMask;
  public ushort wNumbering, wEffects;
  public int dxStartIndent, dxRightIndent, dxOffset;
  public ushort wAlignment, cTabCount;
  [MarshalAs(UnmanagedType.ByValArray, SizeConst=32)] public int[] rgxTabs;
  public int dySpaceBefore, dySpaceAfter, dyLineSpacing;
  public short sStyle;
  public byte bLineSpacingRule, bOutlineLevel;
  public ushort wShadingWeight, wShadingStyle, wNumberingStart, wNumberingStyle, wNumberingTab, wBorderSpace, wBorderWidth, wBorders;
 }
 [StructLayout(LayoutKind.Sequential)] private struct TextRectangle { public int Left, Top, Right, Bottom; }
 [DllImport("user32.dll", CharSet=CharSet.Auto)] private static extern IntPtr SendMessage(IntPtr window, int message, IntPtr parameter, ref ParagraphFormat format);
 [DllImport("user32.dll", CharSet=CharSet.Auto)] private static extern IntPtr SendMessage(IntPtr window, int message, IntPtr parameter, ref TextRectangle rectangle);
 public MedicalWordParagraphEditor() {
  BorderStyle=BorderStyle.None; BackColor=Color.White; ForeColor=Color.Black;
  Multiline=true; WordWrap=true; ScrollBars=RichTextBoxScrollBars.ForcedVertical;
  AcceptsTab=true; HideSelection=false; DetectUrls=false; EnableAutoDragDrop=false;
  ShortcutsEnabled=true; ZoomFactor=1; MaxLength=0;
 }
 protected override void OnKeyDown(KeyEventArgs e) {
  if(!ReadOnly && ((e.Control && e.KeyCode==Keys.V) || (e.Shift && e.KeyCode==Keys.Insert))) {
   if(Clipboard.ContainsText(TextDataFormat.UnicodeText)) SelectedText=Clipboard.GetText(TextDataFormat.UnicodeText);
   e.Handled=true;e.SuppressKeyPress=true;return;
  }
  base.OnKeyDown(e);
 }
 protected override void OnHandleCreated(EventArgs e) { base.OnHandleCreated(e); SetTextRectangle(); }
 protected override void OnResize(EventArgs e) { base.OnResize(e); SetTextRectangle(); }
 private void SetTextRectangle() {
  if(!IsHandleCreated) return;
  TextRectangle rectangle=new TextRectangle();rectangle.Left=6;rectangle.Top=4;rectangle.Right=Math.Max(7,ClientSize.Width-6);rectangle.Bottom=Math.Max(5,ClientSize.Height-4);
  SendMessage(Handle,0xB3,IntPtr.Zero,ref rectangle);
 }
 public void SetParagraphLayout(string alignment,string fontName,float fontSize,bool bold,bool italic,bool underline,string color,double left,double right,double first,double before,double after,double line,string lineRule,double linePoints) {
  int start=SelectionStart, length=SelectionLength;
  FontStyle style=FontStyle.Regular;if(bold)style|=FontStyle.Bold;if(italic)style|=FontStyle.Italic;if(underline)style|=FontStyle.Underline;
  using(Font font=new Font(String.IsNullOrEmpty(fontName)?"Times New Roman":fontName,Math.Max(1,fontSize),style,GraphicsUnit.Point)) {
   SelectAll();SelectionFont=font;
   try { SelectionColor=ColorTranslator.FromHtml(String.IsNullOrEmpty(color)?"#000000":color); } catch { SelectionColor=Color.Black; }
   ParagraphFormat format=new ParagraphFormat();format.cbSize=(uint)Marshal.SizeOf(typeof(ParagraphFormat));format.rgxTabs=new int[32];
   format.dwMask=0x000001CF; // start/right/offset/alignment + before/after/line spacing
   format.dxStartIndent=MedicalWordLayoutMath.CmToTwips(left+first);format.dxRightIndent=MedicalWordLayoutMath.CmToTwips(right);format.dxOffset=-MedicalWordLayoutMath.CmToTwips(first);
   format.wAlignment=MedicalWordLayoutMath.AlignmentCode(alignment);format.dySpaceBefore=MedicalWordLayoutMath.PointsToTwips(before);format.dySpaceAfter=MedicalWordLayoutMath.PointsToTwips(after);
   if(lineRule=="exact") {format.bLineSpacingRule=4;format.dyLineSpacing=MedicalWordLayoutMath.PointsToTwips(linePoints);}
   else if(lineRule=="atLeast") {format.bLineSpacingRule=3;format.dyLineSpacing=MedicalWordLayoutMath.PointsToTwips(linePoints);}
   else {format.bLineSpacingRule=5;format.dyLineSpacing=(int)Math.Round(Math.Max(.1,line)*20);}
   SendMessage(Handle,0x447,IntPtr.Zero,ref format);
   SelectionStart=Math.Min(start,TextLength);SelectionLength=Math.Min(length,TextLength-SelectionStart);SetTextRectangle();
  }
 }
}
public class MedicalCentimeterRuler : Control {
 public event EventHandler IndentsChanged;
 public double ContentWidthCm=17, LeftIndentCm, RightIndentCm, FirstLineCm;
 public float RulerDpi=96;
 public const int TextOrigin=6;
 private int dragged;
 public MedicalCentimeterRuler() {Height=32;BackColor=Color.FromArgb(243,243,243);ForeColor=Color.FromArgb(35,35,35);DoubleBuffered=true;Cursor=Cursors.Hand;SetStyle(ControlStyles.ResizeRedraw,true);}
 private float X(double cm) {return TextOrigin+(float)(cm*RulerDpi/2.54);}
 protected override void OnPaint(PaintEventArgs e) {
  base.OnPaint(e);Graphics g=e.Graphics;float end=X(ContentWidthCm);g.DrawLine(Pens.Gray,TextOrigin,18,end,18);
  for(int unit=0;unit<=Math.Ceiling(ContentWidthCm*10);unit++) {
   double cm=unit/10.0;if(cm>ContentWidthCm)break;float x=X(cm);int tick=unit%10==0?9:unit%5==0?6:3;g.DrawLine(Pens.Gray,x,18-tick,x,18);
   if(unit%10==0)g.DrawString((unit/10).ToString(),Font,Brushes.Black,x+2,0);
  }
  g.FillRectangle(Brushes.LightGray,TextOrigin,19,Math.Max(0,X(LeftIndentCm)-TextOrigin),12);
  g.FillRectangle(Brushes.LightGray,X(ContentWidthCm-RightIndentCm),19,Math.Max(0,end-X(ContentWidthCm-RightIndentCm)),12);
  float left=X(LeftIndentCm),first=X(LeftIndentCm+FirstLineCm),right=X(ContentWidthCm-RightIndentCm);
  g.FillPolygon(Brushes.RoyalBlue,new PointF[]{new PointF(first-5,1),new PointF(first+5,1),new PointF(first,9)});
  g.FillPolygon(Brushes.RoyalBlue,new PointF[]{new PointF(left-5,30),new PointF(left+5,30),new PointF(left,21)});
  g.FillPolygon(Brushes.DarkGreen,new PointF[]{new PointF(right-5,30),new PointF(right+5,30),new PointF(right,21)});
 }
 protected override void OnMouseDown(MouseEventArgs e) {
  base.OnMouseDown(e);if(e.Button!=MouseButtons.Left||!Enabled)return;
  if(e.Y<18&&Math.Abs(e.X-X(LeftIndentCm+FirstLineCm))<12)dragged=2;
  else if(Math.Abs(e.X-X(LeftIndentCm))<12)dragged=1;
  else if(Math.Abs(e.X-X(ContentWidthCm-RightIndentCm))<12)dragged=3;
  if(dragged!=0)Capture=true;
 }
 protected override void OnMouseMove(MouseEventArgs e) {
  base.OnMouseMove(e);if(dragged==0)return;double cm=MedicalWordLayoutMath.Clamp((e.X-TextOrigin)*2.54/RulerDpi,0,ContentWidthCm);
  if(dragged==1)LeftIndentCm=Math.Round(MedicalWordLayoutMath.Clamp(cm,0,ContentWidthCm-RightIndentCm-.1),2);
  else if(dragged==2)FirstLineCm=Math.Round(MedicalWordLayoutMath.Clamp(cm-LeftIndentCm,-LeftIndentCm,ContentWidthCm-RightIndentCm-LeftIndentCm-.1),2);
  else RightIndentCm=Math.Round(MedicalWordLayoutMath.Clamp(ContentWidthCm-cm,0,ContentWidthCm-LeftIndentCm-.1),2);
  Invalidate();
 }
 protected override void OnMouseUp(MouseEventArgs e) {base.OnMouseUp(e);if(dragged==0)return;dragged=0;Capture=false;EventHandler callback=IndentsChanged;if(callback!=null)callback(this,EventArgs.Empty);}
}
'@
}

function New-MedicalParagraphFormatEditor($state,$owner){
 Initialize-MedicalParagraphFormatControls
 $commands=@{}
 foreach($name in @('Get-MedicalParagraphFormat','Set-MedicalParagraphFormat','Get-MedicalPageLayout','Set-MedicalPageLayout')){$commands[$name]=Get-Command $name -CommandType Function -ErrorAction Stop}
 $local=@{Loading=$false;Format=$null;Page=$null;Fonts=@();FormatNote=''}
 $root=New-Object Windows.Forms.TableLayoutPanel;$root.Dock='Fill';$root.ColumnCount=1;$root.RowCount=3
 [void]$root.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',108)))
 [void]$root.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)))
 [void]$root.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',22)))
 $tools=New-Object Windows.Forms.TableLayoutPanel;$tools.Dock='Fill';$tools.ColumnCount=1;$tools.RowCount=3
 foreach($height in @(36,36,36)){[void]$tools.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',$height)))}
 $rows=@();for($index=0;$index -lt 3;$index++){$flow=New-Object Windows.Forms.FlowLayoutPanel;$flow.Dock='Fill';$flow.WrapContents=$false;$flow.AutoScroll=$true;$rows+=@($flow);$tools.Controls.Add($flow,0,$index)}
 $makeLabel={param($text)$label=New-Object Windows.Forms.Label;$label.Text=$text;$label.AutoSize=$true;$label.Margin=New-Object Windows.Forms.Padding(3,8,2,0);return $label}
 $makeNumber={param($min,$max,$places,$width)$number=New-Object Windows.Forms.NumericUpDown;$number.Minimum=[decimal]$min;$number.Maximum=[decimal]$max;$number.DecimalPlaces=$places;$number.Increment=if($places){[decimal]0.1}else{[decimal]1};$number.Width=$width;$number.Margin=New-Object Windows.Forms.Padding(0,3,5,0);return $number}
 $alignment=New-Object Windows.Forms.ComboBox;$alignment.DropDownStyle='DropDownList';$alignment.Width=135;$alignment.Items.AddRange([object[]]@('По левому краю','По центру','По правому краю','По ширине'));$alignmentIds=@('left','center','right','both')
 $font=New-Object Windows.Forms.ComboBox;$font.DropDownStyle='DropDown';$font.Width=150
 $fonts=New-Object Drawing.Text.InstalledFontCollection
 try{foreach($family in $fonts.Families){[void]$font.Items.Add($family.Name)}}finally{$fonts.Dispose()}
 $size=& $makeNumber 1 200 1 56
 $bold=New-Object Windows.Forms.CheckBox;$bold.Appearance='Button';$bold.Text='Ж';$bold.Width=30;$bold.Font=New-Object Drawing.Font('Segoe UI',9,[Drawing.FontStyle]::Bold)
 $italic=New-Object Windows.Forms.CheckBox;$italic.Appearance='Button';$italic.Text='К';$italic.Width=30;$italic.Font=New-Object Drawing.Font('Segoe UI',9,[Drawing.FontStyle]::Italic)
 $underline=New-Object Windows.Forms.CheckBox;$underline.Appearance='Button';$underline.Text='Ч';$underline.Width=30;$underline.Font=New-Object Drawing.Font('Segoe UI',9,[Drawing.FontStyle]::Underline)
 $colorButton=New-Object Windows.Forms.Button;$colorButton.Text='Цвет';$colorButton.AutoSize=$true
 $pageButton=New-Object Windows.Forms.Button;$pageButton.Text='Страница';$pageButton.AutoSize=$true
 foreach($control in @($alignment,$font,$size,$bold,$italic,$underline,$colorButton,$pageButton)){$rows[0].Controls.Add($control)}
 $left=& $makeNumber 0 25 2 68;$first=& $makeNumber -25 25 2 68;$right=& $makeNumber 0 25 2 68
 foreach($pair in @(@('Слева, см',$left),@('1-я строка, см',$first),@('Справа, см',$right))){$rows[1].Controls.Add((& $makeLabel $pair[0]));$rows[1].Controls.Add($pair[1])}
 $before=& $makeNumber 0 200 1 60;$after=& $makeNumber 0 200 1 60;$line=& $makeNumber 1 3 2 58
 foreach($pair in @(@('До, пт',$before),@('После, пт',$after),@('Интервал',$line))){$rows[2].Controls.Add((& $makeLabel $pair[0]));$rows[2].Controls.Add($pair[1])}
 $lineHint=& $makeLabel 'между строками';$rows[2].Controls.Add($lineHint)
 $viewport=New-Object Windows.Forms.Panel;$viewport.Dock='Fill';$viewport.AutoScroll=$false;$viewport.BackColor=[Drawing.Color]::FromArgb(85,89,96)
 $paper=New-Object Windows.Forms.Panel;$paper.BackColor=[Drawing.Color]::White;$paper.Location=New-Object Drawing.Point(8,0)
 $ruler=New-Object MedicalCentimeterRuler;$ruler.Dock='Top';$ruler.Height=32
 $editor=New-Object MedicalWordParagraphEditor;$editor.Dock='Fill'
 $paper.Controls.Add($editor);$paper.Controls.Add($ruler);$viewport.Controls.Add($paper)
 $summary=New-Object Windows.Forms.Label;$summary.Dock='Fill';$summary.AutoEllipsis=$true;$summary.TextAlign='MiddleLeft';$summary.Text='Выберите абзац. Линейка: верхний маркер — первая строка, нижние — отступы.'
 $root.Controls.Add($tools,0,0);$root.Controls.Add($viewport,0,1);$root.Controls.Add($summary,0,2)
 $tip=New-Object Windows.Forms.ToolTip
 $tip.SetToolTip($ruler,'Синие маркеры: верхний — первая строка, нижний — левый отступ. Зелёный — правый отступ. Перетащите маркер мышью.')
 $tip.SetToolTip($line,'Множитель межстрочного интервала. Изменение заменит фиксированный интервал на этот множитель.')
 $tip.SetToolTip($font,'Шрифт всего абзаца. Начертание и размер меняются для всего абзаца.')
 $tip.SetToolTip($alignment,'Выравнивание выбранного абзаца в сохранённом файле Word.')
 $controls=@{Alignment=$alignment;FontName=$font;FontSize=$size;Bold=$bold;Italic=$italic;Underline=$underline;LeftIndent=$left;FirstLine=$first;RightIndent=$right;SpaceBefore=$before;SpaceAfter=$after;LineSpacing=$line;FontColor=$colorButton;Page=$pageButton;Ruler=$ruler;Paper=$paper;Summary=$summary;Viewport=$viewport}
 $restore={
  $paper.BackColor=[Drawing.Color]::White;$editor.BackColor=[Drawing.Color]::White
  $ruler.BackColor=[Drawing.Color]::FromArgb(243,243,243);$ruler.ForeColor=[Drawing.Color]::FromArgb(35,35,35)
  $viewport.BackColor=[Drawing.Color]::FromArgb(85,89,96)
 }.GetNewClosure()
 $resize={
  $width=if($local.Format){[double]$local.Format.ContentWidthCm}else{17.0}
  $graphics=$editor.CreateGraphics();try{$dpi=[double]$graphics.DpiX}finally{$graphics.Dispose()}
  # Fill the pane and fit the Word text area by display zoom; saved page and font sizes stay unchanged.
  $paper.Width=[MedicalWordLayoutMath]::FitPaperWidth($viewport.ClientSize.Width)
  $paper.Height=[Math]::Max(1,$viewport.ClientSize.Height)
  # RichEdit excludes its forced vertical scrollbar from ClientSize; reserve it only once.
  $zoom=[single][MedicalWordLayoutMath]::FitZoom($paper.Width,[Windows.Forms.SystemInformation]::VerticalScrollBarWidth,$width,$dpi)
  if([Math]::Abs([double]$editor.ZoomFactor-$zoom) -gt .00001){$editor.ZoomFactor=$zoom}
  $zoom=[single]$editor.ZoomFactor
  $ruler.RulerDpi=[single]($dpi*$zoom);$ruler.ContentWidthCm=$width
  if($local.Format){
   $context=if($local.Format.IsTable){'Ячейка Word'}else{'Область Word'}
   $summary.Text='Масштаб '+([Math]::Round($zoom*100))+'%; '+$context.ToLower()+': '+([Math]::Round($width,2))+' см. '+$local.FormatNote+' Точные переносы — на вкладке «Страницы Word».'
   $tip.SetToolTip($summary,$summary.Text)
  }
  $ruler.Invalidate()
 }.GetNewClosure()
 $load={
  $local.Loading=$true
  try{
   $hasParagraph=[bool]$state.Paragraph;$editable=$hasParagraph -and [bool]$state.Paragraph.Editable
   foreach($key in @('Alignment','FontName','FontSize','Bold','Italic','Underline','LeftIndent','FirstLine','RightIndent','SpaceBefore','SpaceAfter','LineSpacing','FontColor','Ruler')){$controls[$key].Enabled=[bool]$editable}
   $pageButton.Enabled=[bool]$hasParagraph
   if(-not $hasParagraph){$local.Format=$null;$summary.Text='Выберите абзац. Верхний маркер линейки — первая строка, нижние — отступы.';return}
   $format=& $commands['Get-MedicalParagraphFormat'] $state.Model $state.Paragraph.Id;$local.Format=$format
   $alignment.SelectedIndex=[Math]::Max(0,$alignmentIds.IndexOf([string]$format.Alignment));$font.Text=[string]$format.FontName
   foreach($pair in @(@($size,$format.FontSize),@($left,$format.LeftIndentCm),@($first,$format.FirstLineCm),@($right,$format.RightIndentCm),@($before,$format.SpaceBeforePt),@($after,$format.SpaceAfterPt),@($line,$format.LineSpacing))){$pair[0].Value=[decimal][Math]::Max([double]$pair[0].Minimum,[Math]::Min([double]$pair[0].Maximum,[double]$pair[1]))}
   $bold.Checked=[bool]$format.Bold;$italic.Checked=[bool]$format.Italic;$underline.Checked=[bool]$format.Underline
   $lineHint.Text=if($format.LineRule -eq 'exact'){'точно '+$format.LineSpacingPt+' пт'}elseif($format.LineRule -eq 'atLeast'){'не менее '+$format.LineSpacingPt+' пт'}else{'между строками'}
   $ruler.LeftIndentCm=[double]$format.LeftIndentCm;$ruler.RightIndentCm=[double]$format.RightIndentCm;$ruler.FirstLineCm=[double]$format.FirstLineCm
   $editor.SetParagraphLayout([string]$format.Alignment,[string]$format.FontName,[single]$format.FontSize,[bool]$format.Bold,[bool]$format.Italic,[bool]$format.Underline,[string]$format.FontColor,[double]$format.LeftIndentCm,[double]$format.RightIndentCm,[double]$format.FirstLineCm,[double]$format.SpaceBeforePt,[double]$format.SpaceAfterPt,[double]$format.LineSpacing,[string]$format.LineRule,[double]$format.LineSpacingPt)
   $local.FormatNote=if($format.MixedRunFormatting){'Разные стили: здесь показан первый фрагмент.'}else{'Шрифт и размер применяются ко всему абзацу.'}
   & $restore;& $resize
  }finally{$local.Loading=$false}
 }.GetNewClosure()
 $apply={param($delta)
  if($local.Loading -or $state.Loading -or -not $state.Paragraph -or -not $state.Paragraph.Editable){return}
  try{[void](& $commands['Set-MedicalParagraphFormat'] $state.Model $state.Paragraph.Id $delta);& $load}
  catch{[void][Windows.Forms.MessageBox]::Show($owner,$_.Exception.Message,'Оформление абзаца','OK','Warning');& $load}
 }.GetNewClosure()
 $alignment.Add_SelectedIndexChanged({if($alignment.SelectedIndex -ge 0){& $apply @{Alignment=$alignmentIds[$alignment.SelectedIndex]}}}.GetNewClosure())
 $size.Add_ValueChanged({& $apply @{FontSize=[double]$size.Value}}.GetNewClosure())
 $font.Add_Validated({if(-not [string]::IsNullOrWhiteSpace($font.Text) -and $local.Format -and $font.Text.Trim() -cne [string]$local.Format.FontName){& $apply @{FontName=$font.Text.Trim()}}}.GetNewClosure())
 $font.Add_SelectedIndexChanged({if($font.SelectedIndex -ge 0 -and $local.Format -and $font.Text.Trim() -cne [string]$local.Format.FontName){& $apply @{FontName=$font.Text.Trim()}}}.GetNewClosure())
 $bold.Add_CheckedChanged({& $apply @{Bold=[bool]$bold.Checked}}.GetNewClosure())
 $italic.Add_CheckedChanged({& $apply @{Italic=[bool]$italic.Checked}}.GetNewClosure())
 $underline.Add_CheckedChanged({& $apply @{Underline=[bool]$underline.Checked}}.GetNewClosure())
 $left.Add_ValueChanged({& $apply @{LeftIndentCm=[double]$left.Value}}.GetNewClosure())
 $first.Add_ValueChanged({& $apply @{FirstLineCm=[double]$first.Value}}.GetNewClosure())
 $right.Add_ValueChanged({& $apply @{RightIndentCm=[double]$right.Value}}.GetNewClosure())
 $before.Add_ValueChanged({& $apply @{SpaceBeforePt=[double]$before.Value}}.GetNewClosure())
 $after.Add_ValueChanged({& $apply @{SpaceAfterPt=[double]$after.Value}}.GetNewClosure())
 $line.Add_ValueChanged({& $apply @{LineSpacing=[double]$line.Value}}.GetNewClosure())
 $ruler.Add_IndentsChanged({& $apply @{LeftIndentCm=[double]$ruler.LeftIndentCm;RightIndentCm=[double]$ruler.RightIndentCm;FirstLineCm=[double]$ruler.FirstLineCm}}.GetNewClosure())
 $viewport.Add_Resize($resize)
 $colorButton.Add_Click({
  if(-not $state.Paragraph -or -not $state.Paragraph.Editable){return}
  $picker=New-Object Windows.Forms.ColorDialog
  try{$picker.Color=[Drawing.ColorTranslator]::FromHtml([string]$local.Format.FontColor);if($picker.ShowDialog($owner) -eq 'OK'){& $apply @{FontColor=('#{0:X2}{1:X2}{2:X2}' -f $picker.Color.R,$picker.Color.G,$picker.Color.B)}}}
  catch{[void][Windows.Forms.MessageBox]::Show($owner,$_.Exception.Message,'Цвет текста','OK','Warning')}
  finally{$picker.Dispose()}
 }.GetNewClosure())
 $pageButton.Add_Click({
  if(-not $state.Paragraph){return}
  $pageDialog=New-Object Windows.Forms.Form;$pageDialog.Text='Параметры страницы Word';$pageDialog.Size=New-Object Drawing.Size(470,400);$pageDialog.FormBorderStyle='FixedDialog';$pageDialog.MaximizeBox=$false;$pageDialog.MinimizeBox=$false;$pageDialog.StartPosition='CenterParent';$pageDialog.Font=$owner.Font
  try{
   $page=& $commands['Get-MedicalPageLayout'] $state.Model $state.Paragraph.Id
   $pageGrid=New-Object Windows.Forms.TableLayoutPanel;$pageGrid.Dock='Fill';$pageGrid.Padding=New-Object Windows.Forms.Padding(12);$pageGrid.ColumnCount=2;$pageGrid.RowCount=8
   [void]$pageGrid.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',60)));[void]$pageGrid.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',40)))
   $pageNumbers=@{};$pageOriginal=@{};$pageKeys=@('PageWidthCm','PageHeightCm','MarginLeftCm','MarginRightCm','MarginTopCm','MarginBottomCm')
   $pageLabels=@('Ширина страницы, см','Высота страницы, см','Поле слева, см','Поле справа, см','Поле сверху, см','Поле снизу, см')
   for($i=0;$i -lt $pageKeys.Count;$i++){
    $label=New-Object Windows.Forms.Label;$label.Text=$pageLabels[$i];$label.Dock='Fill';$label.TextAlign='MiddleLeft'
    $number=New-Object Windows.Forms.NumericUpDown;$number.Minimum=if($i -lt 2){5}else{0};$number.Maximum=if($i -lt 2){55}else{20};$number.DecimalPlaces=2;$number.Increment=[decimal].1;$number.Dock='Fill';$number.Value=[decimal][Math]::Min([double]$number.Maximum,[Math]::Max([double]$number.Minimum,[double]$page.($pageKeys[$i])))
    $pageNumbers[$pageKeys[$i]]=$number;$pageOriginal[$pageKeys[$i]]=[double]$number.Value;[void]$pageGrid.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',36)));$pageGrid.Controls.Add($label,0,$i);$pageGrid.Controls.Add($number,1,$i)
   }
   $pageHint=New-Object Windows.Forms.Label;$pageHint.Text='Для альбомной страницы задайте ширину больше высоты. Параметры применяются к разделу выбранного абзаца.';$pageHint.Dock='Fill';$pageGrid.SetColumnSpan($pageHint,2);$pageGrid.Controls.Add($pageHint,0,6);[void]$pageGrid.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)))
   $actions=New-Object Windows.Forms.FlowLayoutPanel;$actions.Dock='Fill';$actions.FlowDirection='RightToLeft';$pageGrid.Controls.Add($actions,0,7);$pageGrid.SetColumnSpan($actions,2);[void]$pageGrid.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',42)))
   $pageCancel=New-Object Windows.Forms.Button;$pageCancel.Text='Отмена';$pageCancel.DialogResult='Cancel';$pageSave=New-Object Windows.Forms.Button;$pageSave.Text='Применить';$pageSave.AutoSize=$true
   $actions.Controls.Add($pageCancel);$actions.Controls.Add($pageSave);$pageDialog.Controls.Add($pageGrid);$pageDialog.CancelButton=$pageCancel;$pageDialog.AcceptButton=$pageSave
   $pageSave.Add_Click({
    try{$delta=@{};foreach($key in $pageKeys){if([double]$pageNumbers[$key].Value -ne $pageOriginal[$key]){$delta[$key]=[double]$pageNumbers[$key].Value}};[void](& $commands['Set-MedicalPageLayout'] $state.Model $delta $state.Paragraph.Id);$pageDialog.DialogResult='OK';$pageDialog.Close()}
    catch{[void][Windows.Forms.MessageBox]::Show($pageDialog,$_.Exception.Message,'Параметры страницы','OK','Warning')}
   }.GetNewClosure())
   [void]$pageDialog.ShowDialog($owner);& $load
  }catch{[void][Windows.Forms.MessageBox]::Show($owner,$_.Exception.Message,'Параметры страницы','OK','Warning')}
  finally{$pageDialog.Dispose()}
 }.GetNewClosure())
 $root.Add_Disposed({$tip.Dispose()}.GetNewClosure())
 & $load
 return [pscustomobject]@{Root=$root;Editor=$editor;Load=$load;RestorePaperColors=$restore;Controls=$controls;Commit={}.GetNewClosure()}
}
