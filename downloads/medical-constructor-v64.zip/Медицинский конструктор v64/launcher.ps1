﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $root
$log = Join-Path $root 'startup_error.txt'
try {
    if (Test-Path -LiteralPath $log) { Remove-Item -LiteralPath $log -Force }
    $Error.Clear()
    & (Join-Path $root 'constructor.ps1') 2>&1 | ForEach-Object {
        if ($_ -is [System.Management.Automation.ErrorRecord]) { throw $_ }
    }
    if (-not $?) { throw 'constructor.ps1 finished with an error.' }
} catch {
    $details = ($_ | Out-String) + [Environment]::NewLine + $_.ScriptStackTrace
    [System.IO.File]::WriteAllText($log, $details, [System.Text.Encoding]::UTF8)
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("Program could not start. Details saved to startup_error.txt in the program folder.", "Medical Constructor - Startup Error", 'OK', 'Error') | Out-Null
}
