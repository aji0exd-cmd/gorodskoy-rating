﻿param(
 [Parameter(Mandatory=$true)][string]$DocumentPath,
 [ValidateSet('Preview','Print')][string]$Action='Preview',
 [switch]$Temporary
)
# Separate STA process: native Word dialogs never block the constructor's UI.
$ErrorActionPreference='Stop'
$word=$null;$document=$null;$documents=$null;$dialogs=$null;$dialog=$null;$handedOff=$false
$fullPath=[IO.Path]::GetFullPath($DocumentPath)
function Release-WordObject($object){
 if($null -ne $object -and [Runtime.InteropServices.Marshal]::IsComObject($object)){
  try{[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($object)}catch{}
 }
}
function Test-DisposablePreviewPath([string]$path){
 $folder=[IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'MedicalConstructor\Preview'))
 $parent=[IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($path))
 return ([string]::Equals($parent,$folder,[StringComparison]::OrdinalIgnoreCase) -and [IO.Path]::GetFileName($path) -match '^mc-preview-[a-f0-9]{32}\.docx$')
}
try{
 if(-not [IO.File]::Exists($fullPath)){throw 'Документ не найден.'}
 try{$word=New-Object -ComObject Word.Application}catch{throw 'Для предпросмотра и печати нужен установленный настольный Microsoft Word. Не удалось запустить Word.'}
 $word.AutomationSecurity=3 # msoAutomationSecurityForceDisable, for this new instance only.
 $documents=$word.Documents
 # ConfirmConversions=False, ReadOnly=True, AddToRecentFiles=False.
 $document=$documents.Open($fullPath,$false,$true,$false)
 $word.Visible=$true;$document.Activate();$word.Activate()
 if($Action -eq 'Preview'){
  $document.PrintPreview()
 }else{
  # wdDialogFilePrint = 88. No PrintOut call: the user chooses a printer and confirms.
  $dialogs=$word.Dialogs;$dialog=$dialogs.Item(88)
  [void]$dialog.Show()
 }
 $handedOff=$true
 # Keep the temporary preview available until its Word window is closed by the user.
 while($true){
  $stillOpen=$false
  try{
   for($i=1;$i -le $documents.Count;$i++){
    $current=$null
    try{$current=$documents.Item($i);if([string]::Equals([string]$current.FullName,$fullPath,[StringComparison]::OrdinalIgnoreCase)){$stillOpen=$true}}
    finally{Release-WordObject $current}
   }
  }catch{break}
  if(-not $stillOpen){break}
  Start-Sleep -Milliseconds 700
 }
}catch{
 Add-Type -AssemblyName System.Windows.Forms
 [void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'Предпросмотр и печать','OK','Error')
}finally{
 if(-not $handedOff -and $null -ne $document){try{$document.Close(0)}catch{}}
 # Never quit an instance while it contains any other document opened by the user.
 if($null -ne $word){try{if($documents.Count -eq 0){$word.Quit(0)}}catch{}}
 Release-WordObject $dialog;Release-WordObject $dialogs;Release-WordObject $document;Release-WordObject $documents;Release-WordObject $word
 if($Temporary -and (Test-DisposablePreviewPath $fullPath)){
  Remove-Item -LiteralPath $fullPath -Force -ErrorAction SilentlyContinue
 }
}
