﻿# v62: paragraph formatting and section page layout, written to real Word OOXML.
# Each setter accepts a partial property bag and validates it before changing XML.

function Get-MedicalFormatMember($value,[string]$name,$fallback=$null){
 if($value -is [Collections.IDictionary]){if($value.Contains($name)){return $value[$name]}}
 elseif($null -ne $value -and $value.PSObject.Properties[$name]){return $value.$name}
 return $fallback
}

function Test-MedicalFormatMember($value,[string]$name){
 if($value -is [Collections.IDictionary]){return $value.Contains($name)}
 return ($null -ne $value -and $null -ne $value.PSObject.Properties[$name])
}

function Get-MedicalFormatParagraph($model,[string]$id){
 $records=@($model.Paragraphs | Where-Object {$_.Id -ceq $id})
 if($records.Count -ne 1){throw 'Абзац шаблона не найден.'}
 return $records[0]
}

function Get-MedicalFormatAttribute($node,[string]$name,[string]$fallback=''){
 if($null -eq $node){return $fallback}
 if($node.HasAttribute($name,'http://schemas.openxmlformats.org/wordprocessingml/2006/main')){return $node.GetAttribute($name,'http://schemas.openxmlformats.org/wordprocessingml/2006/main')}
 return $fallback
}

function Set-MedicalFormatAttribute($node,[string]$name,[string]$value){
 [void]$node.SetAttribute($name,'http://schemas.openxmlformats.org/wordprocessingml/2006/main',$value)
}

function Get-MedicalFormatChild($parent,[string]$name,[bool]$create=$false){
 $ns=Get-MedicalEditorNamespace $parent.OwnerDocument
 $child=$parent.SelectSingleNode('./w:'+$name,$ns)
 if($child -or -not $create){return ,$child}
 $child=$parent.OwnerDocument.CreateElement('w',$name,'http://schemas.openxmlformats.org/wordprocessingml/2006/main')
 $order=switch($parent.LocalName){
  'pPr'{@('pStyle','keepNext','keepLines','pageBreakBefore','framePr','widowControl','numPr','suppressLineNumbers','pBdr','shd','tabs','suppressAutoHyphens','kinsoku','wordWrap','overflowPunct','topLinePunct','autoSpaceDE','autoSpaceDN','bidi','adjustRightInd','snapToGrid','spacing','ind','contextualSpacing','mirrorIndents','suppressOverlap','jc','textDirection','textAlignment','textboxTightWrap','outlineLvl','divId','cnfStyle','rPr','sectPr','pPrChange')}
  'rPr'{@('rStyle','rFonts','b','bCs','i','iCs','caps','smallCaps','strike','dstrike','outline','shadow','emboss','imprint','noProof','snapToGrid','vanish','webHidden','color','spacing','w','kern','position','sz','szCs','highlight','u','effect','bdr','shd','fitText','vertAlign','rtl','cs','em','lang','eastAsianLayout','specVanish','oMath','rPrChange')}
  'sectPr'{@('headerReference','footerReference','footnotePr','endnotePr','type','pgSz','pgMar','paperSrc','pgBorders','lnNumType','pgNumType','cols','formProt','vAlign','noEndnote','titlePg','textDirection','bidi','rtlGutter','docGrid','printerSettings','sectPrChange')}
  'p'{@('pPr','r')}
  'r'{@('rPr','t','br','cr','tab')}
  default{@()}
 }
 $rank=[array]::IndexOf($order,$name);$before=$null
 foreach($existing in $parent.ChildNodes){
  if($existing -isnot [Xml.XmlElement] -or $existing.NamespaceURI -cne $child.NamespaceURI){continue}
  $existingRank=[array]::IndexOf($order,$existing.LocalName)
  if($rank -ge 0 -and $existingRank -gt $rank){$before=$existing;break}
 }
 if($before){[void]$parent.InsertBefore($child,$before)}else{[void]$parent.AppendChild($child)}
 return ,$child
}

function Get-MedicalFormatResourceXml($model,[string]$name){
 $entry=@($model.Entries | Where-Object {$_.Name -ceq $name})
 if($entry.Count -eq 1){return ,(Read-MedicalEditorXml $entry[0].Bytes)}
 return $null
}

function Get-MedicalFormatStyleChain($styles,[string]$id){
 if($null -eq $styles -or -not $id){return @()}
 $ns=Get-MedicalEditorNamespace $styles;$lookup=@{}
 foreach($style in $styles.SelectNodes('/w:styles/w:style',$ns)){$lookup[(Get-MedicalFormatAttribute $style 'styleId')]=$style}
 $result=New-Object Collections.ArrayList;$seen=@{};$current=$id
 while($current -and $lookup.ContainsKey($current) -and -not $seen.ContainsKey($current)){
  $seen[$current]=$true;$style=$lookup[$current];$result.Insert(0,$style)
  if($seen.Count -gt 128){break}
  $current=Get-MedicalFormatAttribute ($style.SelectSingleNode('./w:basedOn',$ns)) 'val'
 }
 return @($result)
}

function Get-MedicalFormatToggle($node){
 if($null -eq $node){return $null}
 $value=Get-MedicalFormatAttribute $node 'val' '1'
 return ($value -notin @('0','false','off'))
}

function Get-MedicalFormatNumber($node,[string]$attribute,$fallback){
 $text=Get-MedicalFormatAttribute $node $attribute
 $number=0.0
 if($text -and [double]::TryParse($text,[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$number) -and -not [double]::IsNaN($number) -and -not [double]::IsInfinity($number)){return $number}
 return $fallback
}

function Update-MedicalEffectiveRunFormat($format,$properties,[bool]$styleToggle=$false,$theme=$null){
 if($null -eq $properties){return}
 $ns=Get-MedicalEditorNamespace $properties.OwnerDocument
 $fonts=$properties.SelectSingleNode('./w:rFonts',$ns)
 if($fonts){
  $name=''
  if($theme){
   $themeFonts=New-Object Xml.XmlNamespaceManager($theme.NameTable);$themeFonts.AddNamespace('a','http://schemas.openxmlformats.org/drawingml/2006/main')
   $themeName=Get-MedicalFormatAttribute $fonts 'asciiTheme';if(-not $themeName){$themeName=Get-MedicalFormatAttribute $fonts 'hAnsiTheme'}
   if($themeName){$kind=if($themeName -match '^major'){'majorFont'}else{'minorFont'};$latin=$theme.SelectSingleNode('/a:theme/a:themeElements/a:fontScheme/a:'+$kind+'/a:latin',$themeFonts);if($latin){$name=$latin.GetAttribute('typeface')}}
  }
  if(-not $name){foreach($attribute in @('ascii','hAnsi','cs','eastAsia')){if(-not $name){$name=Get-MedicalFormatAttribute $fonts $attribute}}}
  if($name){$format.FontName=$name}
 }
 $size=$properties.SelectSingleNode('./w:sz',$ns);if(-not $size){$size=$properties.SelectSingleNode('./w:szCs',$ns)}
 if($size){$format.FontSize=(Get-MedicalFormatNumber $size 'val' ($format.FontSize*2))/2}
 foreach($property in @(@('b','Bold'),@('i','Italic'))){
  $node=$properties.SelectSingleNode('./w:'+$property[0],$ns);$enabled=Get-MedicalFormatToggle $node
  if($null -ne $enabled){if($styleToggle){if($enabled){$format[$property[1]]=-not $format[$property[1]]}}else{$format[$property[1]]=[bool]$enabled}}
 }
 $underline=$properties.SelectSingleNode('./w:u',$ns);if($underline){$format.Underline=((Get-MedicalFormatAttribute $underline 'val' 'single') -notin @('none','0','false','off'))}
 $color=$properties.SelectSingleNode('./w:color',$ns);if($color){$hex=Get-MedicalFormatAttribute $color 'val';if($hex -match '^[a-fA-F0-9]{6}$'){$format.FontColor='#'+$hex.ToUpperInvariant()}elseif($hex -eq 'auto'){$format.FontColor='#000000'}}
}

function Update-MedicalEffectiveParagraphFormat($format,$properties){
 if($null -eq $properties){return}
 $ns=Get-MedicalEditorNamespace $properties.OwnerDocument
 $alignment=$properties.SelectSingleNode('./w:jc',$ns)
 if($alignment){$value=Get-MedicalFormatAttribute $alignment 'val';$format.Alignment=switch($value){'start'{'left'} 'end'{'right'} 'distribute'{'both'} default{$value}}}
 $indent=$properties.SelectSingleNode('./w:ind',$ns)
 if($indent){
  foreach($record in @(@('left','LeftIndentCm'),@('right','RightIndentCm'),@('start','LeftIndentCm'),@('end','RightIndentCm'))){if($indent.HasAttribute($record[0],$indent.NamespaceURI)){$format[$record[1]]=(Get-MedicalFormatNumber $indent $record[0] 0)*2.54/1440}}
  if($indent.HasAttribute('firstLine',$indent.NamespaceURI)){$format.FirstLineCm=(Get-MedicalFormatNumber $indent 'firstLine' 0)*2.54/1440}
  if($indent.HasAttribute('hanging',$indent.NamespaceURI)){$format.FirstLineCm=-(Get-MedicalFormatNumber $indent 'hanging' 0)*2.54/1440}
 }
 $spacing=$properties.SelectSingleNode('./w:spacing',$ns)
 if($spacing){
  foreach($record in @(@('before','SpaceBeforePt'),@('after','SpaceAfterPt'))){if($spacing.HasAttribute($record[0],$spacing.NamespaceURI)){$format[$record[1]]=(Get-MedicalFormatNumber $spacing $record[0] 0)/20}}
  if($spacing.HasAttribute('lineRule',$spacing.NamespaceURI)){$format.LineRule=Get-MedicalFormatAttribute $spacing 'lineRule' 'auto'}
  if($spacing.HasAttribute('line',$spacing.NamespaceURI)){$format.RawLineSpacing=Get-MedicalFormatNumber $spacing 'line' 240}
 }
}

function Get-MedicalSectionProperties($model,[string]$id=''){
 $xml=$model.Parts['word/document.xml'].Xml;$ns=Get-MedicalEditorNamespace $xml
 $sections=@($xml.SelectNodes('/w:document/w:body/w:p/w:pPr/w:sectPr|/w:document/w:body/w:sectPr',$ns));$selected=$null
 if($id){
  $paragraph=Get-MedicalFormatParagraph $model $id
  if($paragraph.Part -ceq 'word/document.xml'){
   $selected=$paragraph.Node.SelectSingleNode('./w:pPr/w:sectPr|following::w:sectPr[parent::w:pPr[parent::w:p[parent::w:body]] or parent::w:body]',$ns)
  }else{
   $rels=Get-MedicalFormatResourceXml $model 'word/_rels/document.xml.rels';$relationshipId=''
   if($rels){foreach($relationship in $rels.DocumentElement.ChildNodes){if($relationship -is [Xml.XmlElement] -and ('word/'+$relationship.GetAttribute('Target').TrimStart('/')) -ceq $paragraph.Part){$relationshipId=$relationship.GetAttribute('Id');break}}}
   if($relationshipId){foreach($section in $sections){foreach($reference in $section.SelectNodes('./w:headerReference|./w:footerReference',$ns)){if($reference.GetAttribute('id','http://schemas.openxmlformats.org/officeDocument/2006/relationships') -ceq $relationshipId){$selected=$section;break}};if($selected){break}}}
  }
 }
 if(-not $selected -and $sections.Count){$selected=$sections[$sections.Count-1]}
 $index=if($selected){[array]::IndexOf($sections,$selected)+1}else{1}
 return [pscustomobject]@{Node=$selected;Xml=$xml;SectionIndex=$index;SectionCount=[Math]::Max(1,$sections.Count)}
}

function Get-MedicalPageLayout($model,[string]$id=''){
 $section=Get-MedicalSectionProperties $model $id;$ns=Get-MedicalEditorNamespace $section.Xml
 $size=$null;$margins=$null
 if($section.Node){$size=$section.Node.SelectSingleNode('./w:pgSz',$ns);$margins=$section.Node.SelectSingleNode('./w:pgMar',$ns)}
 $factor=2.54/1440
 $width=(Get-MedicalFormatNumber $size 'w' 11906)*$factor;$height=(Get-MedicalFormatNumber $size 'h' 16838)*$factor
 $left=(Get-MedicalFormatNumber $margins 'left' 1134)*$factor;$right=(Get-MedicalFormatNumber $margins 'right' 1134)*$factor
 $top=(Get-MedicalFormatNumber $margins 'top' 1134)*$factor;$bottom=(Get-MedicalFormatNumber $margins 'bottom' 1134)*$factor
 $table=$false;$content=[Math]::Max(0.1,$width-$left-$right);$columns=1;$columnGap=0.0
 if($section.Node){$cols=$section.Node.SelectSingleNode('./w:cols',$ns);if($cols){$columns=[int](Get-MedicalFormatNumber $cols 'num' 1);$columnGap=(Get-MedicalFormatNumber $cols 'space' 720)*$factor;if($columns -gt 1){$content=[Math]::Max(0.1,($content-($columns-1)*$columnGap)/$columns)}}}
 if($id){
  $paragraph=Get-MedicalFormatParagraph $model $id;$cell=$paragraph.Node.SelectSingleNode('ancestor::w:tc[1]',(Get-MedicalEditorNamespace $paragraph.Node.OwnerDocument))
  if($cell){
   $table=$true;$cellNs=Get-MedicalEditorNamespace $cell.OwnerDocument;$cellWidth=$cell.SelectSingleNode('./w:tcPr/w:tcW',$cellNs)
   if($cellWidth){$kind=Get-MedicalFormatAttribute $cellWidth 'type' 'dxa';$raw=Get-MedicalFormatNumber $cellWidth 'w' 0;if($raw -gt 0){if($kind -eq 'dxa'){$content=[Math]::Min($content,$raw*$factor)}elseif($kind -eq 'pct'){$content=$content*$raw/5000}}}
   $cellMargins=$cell.SelectSingleNode('./w:tcPr/w:tcMar',$cellNs);$tableMargins=$cell.SelectSingleNode('ancestor::w:tbl[1]/w:tblPr/w:tblCellMar',$cellNs)
   foreach($side in @('left','right')){$margin=$null;if($cellMargins){$margin=$cellMargins.SelectSingleNode('./w:'+$side,$cellNs)};if(-not $margin -and $tableMargins){$margin=$tableMargins.SelectSingleNode('./w:'+$side,$cellNs)};if($margin -and (Get-MedicalFormatAttribute $margin 'type' 'dxa') -eq 'dxa'){$content-=(Get-MedicalFormatNumber $margin 'w' 0)*$factor}}
  }
 }
 return [pscustomobject]@{PageWidthCm=[Math]::Round($width,4);PageHeightCm=[Math]::Round($height,4);MarginLeftCm=[Math]::Round($left,4);MarginRightCm=[Math]::Round($right,4);MarginTopCm=[Math]::Round($top,4);MarginBottomCm=[Math]::Round($bottom,4);Orientation=$(if($width -gt $height){'landscape'}else{'portrait'});ContentWidthCm=[Math]::Round([Math]::Max(0.1,$content),4);IsTable=$table;SectionIndex=$section.SectionIndex;SectionCount=$section.SectionCount;Columns=$columns}
}

function Get-MedicalParagraphFormat($model,[string]$id){
 $paragraph=Get-MedicalFormatParagraph $model $id;$ns=Get-MedicalEditorNamespace $paragraph.Node.OwnerDocument
 $styles=Get-MedicalFormatResourceXml $model 'word/styles.xml';$theme=Get-MedicalFormatResourceXml $model 'word/theme/theme1.xml'
 $format=@{Alignment='left';FontName='Times New Roman';FontSize=12.0;Bold=$false;Italic=$false;Underline=$false;FontColor='#000000';LeftIndentCm=0.0;RightIndentCm=0.0;FirstLineCm=0.0;SpaceBeforePt=0.0;SpaceAfterPt=0.0;LineSpacing=1.0;LineRule='auto';RawLineSpacing=240.0;LineSpacingPt=0.0}
 $styleId=Get-MedicalFormatAttribute ($paragraph.Node.SelectSingleNode('./w:pPr/w:pStyle',$ns)) 'val'
 if($styles){
  $styleNs=Get-MedicalEditorNamespace $styles
  Update-MedicalEffectiveParagraphFormat $format ($styles.SelectSingleNode('/w:styles/w:docDefaults/w:pPrDefault/w:pPr',$styleNs))
  Update-MedicalEffectiveRunFormat $format ($styles.SelectSingleNode('/w:styles/w:docDefaults/w:rPrDefault/w:rPr',$styleNs)) $false $theme
  if(-not $styleId){$styleId=Get-MedicalFormatAttribute ($styles.SelectSingleNode('/w:styles/w:style[@w:type="paragraph" and (@w:default="1" or @w:default="true")]',$styleNs)) 'styleId'}
  foreach($style in Get-MedicalFormatStyleChain $styles $styleId){Update-MedicalEffectiveParagraphFormat $format ($style.SelectSingleNode('./w:pPr',$styleNs));Update-MedicalEffectiveRunFormat $format ($style.SelectSingleNode('./w:rPr',$styleNs)) $true $theme}
 }
 Update-MedicalEffectiveParagraphFormat $format ($paragraph.Node.SelectSingleNode('./w:pPr',$ns))
 $base=@{};foreach($key in $format.Keys){$base[$key]=$format[$key]}
 $runs=@($paragraph.Node.SelectNodes('./w:r',$ns));$runFormats=New-Object Collections.ArrayList
 if(-not $runs.Count){Update-MedicalEffectiveRunFormat $format ($paragraph.Node.SelectSingleNode('./w:pPr/w:rPr',$ns)) $false $theme}
 foreach($run in $runs){
  $current=@{};foreach($key in $base.Keys){$current[$key]=$base[$key]}
  $runStyleId=Get-MedicalFormatAttribute ($run.SelectSingleNode('./w:rPr/w:rStyle',$ns)) 'val'
  if($styles -and $runStyleId){foreach($style in Get-MedicalFormatStyleChain $styles $runStyleId){Update-MedicalEffectiveRunFormat $current ($style.SelectSingleNode('./w:rPr',(Get-MedicalEditorNamespace $styles))) $true $theme}}
  Update-MedicalEffectiveRunFormat $current ($run.SelectSingleNode('./w:rPr',$ns)) $false $theme
  [void]$runFormats.Add($current)
 }
 $mixed=$false
 if($runFormats.Count){$format=$runFormats[0];foreach($runFormat in $runFormats){foreach($key in @('FontName','FontSize','Bold','Italic','Underline','FontColor')){if($runFormat[$key] -cne $format[$key]){$mixed=$true}}}}
 if($format.LineRule -eq 'auto'){$format.LineSpacing=$format.RawLineSpacing/240;$format.LineSpacingPt=$format.FontSize*$format.LineSpacing}else{$format.LineSpacingPt=$format.RawLineSpacing/20;$format.LineSpacing=$format.LineSpacingPt/[Math]::Max(1,$format.FontSize)}
 $format.Remove('RawLineSpacing')
 foreach($key in @('LeftIndentCm','RightIndentCm','FirstLineCm','SpaceBeforePt','SpaceAfterPt','LineSpacing','LineSpacingPt')){$format[$key]=[Math]::Round([double]$format[$key],4)}
 $layout=Get-MedicalPageLayout $model $id;$format.StyleId=$styleId;$format.MixedRunFormatting=$mixed;$format.IsTable=$layout.IsTable;$format.ContentWidthCm=$layout.ContentWidthCm
 return [pscustomobject]$format
}

function Get-MedicalValidatedFormatNumber($value,[string]$name,[double]$minimum,[double]$maximum){
 $raw=Get-MedicalFormatMember $value $name
 if($null -eq $raw -or $raw -is [bool] -or $raw -is [Collections.IEnumerable] -and $raw -isnot [string]){throw ('Некорректное значение: '+$name)}
 $number=0.0
 if(-not [double]::TryParse([string]([Convert]::ToString($raw,[Globalization.CultureInfo]::InvariantCulture)),[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$number) -or [double]::IsNaN($number) -or [double]::IsInfinity($number) -or $number -lt $minimum -or $number -gt $maximum){throw ('Значение '+$name+' должно быть от '+$minimum+' до '+$maximum+'.')}
 return $number
}

function Set-MedicalParagraphFormat($model,[string]$id,$format){
 $paragraph=Get-MedicalFormatParagraph $model $id
 if(-not $paragraph.Editable){throw $paragraph.Reason}
 if($null -eq $format){throw 'Не заданы параметры абзаца.'}
 $updates=@{}
 if(Test-MedicalFormatMember $format 'Alignment'){$alignment=[string](Get-MedicalFormatMember $format 'Alignment');if($alignment -cnotin @('left','center','right','both')){throw 'Выберите выравнивание: слева, по центру, справа или по ширине.'};$updates.Alignment=$alignment}
 if(Test-MedicalFormatMember $format 'FontName'){$name=[string](Get-MedicalFormatMember $format 'FontName');if([string]::IsNullOrWhiteSpace($name) -or $name.Length -gt 128 -or $name -match '[\x00-\x1f]'){throw 'Укажите корректное название шрифта.'};$updates.FontName=$name.Trim()}
 if(Test-MedicalFormatMember $format 'FontColor'){$color=[string](Get-MedicalFormatMember $format 'FontColor');if($color -cnotmatch '^#[A-Fa-f0-9]{6}$'){throw 'Цвет текста должен иметь вид #RRGGBB.'};$updates.FontColor=$color.Substring(1).ToUpperInvariant()}
 foreach($name in @('Bold','Italic','Underline')){if(Test-MedicalFormatMember $format $name){$value=Get-MedicalFormatMember $format $name;if($value -isnot [bool]){throw ('Параметр '+$name+' должен быть логическим значением.')};$updates[$name]=$value}}
 foreach($rule in @(@('FontSize',1,200),@('LeftIndentCm',0,25),@('RightIndentCm',0,25),@('FirstLineCm',-25,25),@('SpaceBeforePt',0,200),@('SpaceAfterPt',0,200),@('LineSpacing',1,3))){if(Test-MedicalFormatMember $format $rule[0]){$updates[$rule[0]]=Get-MedicalValidatedFormatNumber $format $rule[0] $rule[1] $rule[2]}}
 if(-not $updates.Count){return}
 if($updates.ContainsKey('LeftIndentCm') -or $updates.ContainsKey('RightIndentCm') -or $updates.ContainsKey('FirstLineCm')){
  $effective=Get-MedicalParagraphFormat $model $id;$left=Get-MedicalFormatMember $updates 'LeftIndentCm' $effective.LeftIndentCm;$right=Get-MedicalFormatMember $updates 'RightIndentCm' $effective.RightIndentCm;$first=Get-MedicalFormatMember $updates 'FirstLineCm' $effective.FirstLineCm
  if($left+$right+[Math]::Max(0,$first) -gt $effective.ContentWidthCm-0.1){throw 'Отступы оставляют слишком мало места для текста. Уменьшите отступы или измените поля страницы.'}
 }
 $node=$paragraph.Node;$xml=$node.OwnerDocument;$ns=Get-MedicalEditorNamespace $xml;$clone=$node.CloneNode($true)
 $paragraphKeys=@('Alignment','LeftIndentCm','RightIndentCm','FirstLineCm','SpaceBeforePt','SpaceAfterPt','LineSpacing')
 $runKeys=@('FontName','FontSize','Bold','Italic','Underline','FontColor')
 if(@($paragraphKeys | Where-Object {$updates.ContainsKey($_)}).Count){
  $pPr=Get-MedicalFormatChild $clone 'pPr' $true
  if($updates.ContainsKey('Alignment')){Set-MedicalFormatAttribute (Get-MedicalFormatChild $pPr 'jc' $true) 'val' $updates.Alignment}
  if(@(@('LeftIndentCm','RightIndentCm','FirstLineCm') | Where-Object {$updates.ContainsKey($_)}).Count){
   $ind=Get-MedicalFormatChild $pPr 'ind' $true
   foreach($record in @(@('LeftIndentCm','left','start'),@('RightIndentCm','right','end'))){if($updates.ContainsKey($record[0])){Set-MedicalFormatAttribute $ind $record[1] ([string][int][Math]::Round($updates[$record[0]]*1440/2.54));$ind.RemoveAttribute($record[2],$ind.NamespaceURI);$ind.RemoveAttribute($record[1]+'Chars',$ind.NamespaceURI)}}
   if($updates.ContainsKey('FirstLineCm')){foreach($attribute in @('firstLine','hanging','firstLineChars','hangingChars')){$ind.RemoveAttribute($attribute,$ind.NamespaceURI)};$name=if($updates.FirstLineCm -lt 0){'hanging'}else{'firstLine'};Set-MedicalFormatAttribute $ind $name ([string][int][Math]::Round([Math]::Abs($updates.FirstLineCm)*1440/2.54))}
  }
  if(@(@('SpaceBeforePt','SpaceAfterPt','LineSpacing') | Where-Object {$updates.ContainsKey($_)}).Count){
   $spacing=Get-MedicalFormatChild $pPr 'spacing' $true
   foreach($record in @(@('SpaceBeforePt','before'),@('SpaceAfterPt','after'))){if($updates.ContainsKey($record[0])){Set-MedicalFormatAttribute $spacing $record[1] ([string][int][Math]::Round($updates[$record[0]]*20));$spacing.RemoveAttribute($record[1]+'Lines',$spacing.NamespaceURI);$spacing.RemoveAttribute($record[1]+'Autospacing',$spacing.NamespaceURI)}}
   if($updates.ContainsKey('LineSpacing')){Set-MedicalFormatAttribute $spacing 'line' ([string][int][Math]::Round($updates.LineSpacing*240));Set-MedicalFormatAttribute $spacing 'lineRule' 'auto'}
  }
 }
 if(@($runKeys | Where-Object {$updates.ContainsKey($_)}).Count){
  $pPr=Get-MedicalFormatChild $clone 'pPr' $true;$properties=New-Object Collections.ArrayList;[void]$properties.Add((Get-MedicalFormatChild $pPr 'rPr' $true))
  foreach($run in $clone.SelectNodes('./w:r',$ns)){[void]$properties.Add((Get-MedicalFormatChild $run 'rPr' $true))}
  foreach($rPr in $properties){
   if($updates.ContainsKey('FontName')){$fonts=Get-MedicalFormatChild $rPr 'rFonts' $true;foreach($attribute in @('ascii','hAnsi','cs','eastAsia')){Set-MedicalFormatAttribute $fonts $attribute $updates.FontName;$fonts.RemoveAttribute($attribute+'Theme',$fonts.NamespaceURI)};$fonts.RemoveAttribute('cstheme',$fonts.NamespaceURI)}
   if($updates.ContainsKey('FontSize')){foreach($name in @('sz','szCs')){Set-MedicalFormatAttribute (Get-MedicalFormatChild $rPr $name $true) 'val' ([string][int][Math]::Round($updates.FontSize*2))}}
   foreach($record in @(@('Bold','b','bCs'),@('Italic','i','iCs'))){if($updates.ContainsKey($record[0])){foreach($name in @($record[1],$record[2])){Set-MedicalFormatAttribute (Get-MedicalFormatChild $rPr $name $true) 'val' $(if($updates[$record[0]]){'1'}else{'0'})}}}
   if($updates.ContainsKey('Underline')){Set-MedicalFormatAttribute (Get-MedicalFormatChild $rPr 'u' $true) 'val' $(if($updates.Underline){'single'}else{'none'})}
   if($updates.ContainsKey('FontColor')){$color=Get-MedicalFormatChild $rPr 'color' $true;Set-MedicalFormatAttribute $color 'val' $updates.FontColor;foreach($name in @('themeColor','themeTint','themeShade')){$color.RemoveAttribute($name,$color.NamespaceURI)}}
  }
 }
 if($clone.OuterXml -ceq $node.OuterXml){return}
 # Commit one validated clone. Preserve the paragraph node identity used by the editor.
 foreach($child in @($node.ChildNodes)){[void]$node.RemoveChild($child)}
 foreach($child in @($clone.ChildNodes)){[void]$node.AppendChild($child)}
 $model.Parts[$paragraph.Part].Modified=$true
}

function Set-MedicalPageLayout($model,$layout,[string]$id=''){
 if($null -eq $layout){throw 'Не заданы параметры страницы.'}
 $updates=@{}
 foreach($name in @('PageWidthCm','PageHeightCm')){if(Test-MedicalFormatMember $layout $name){$updates[$name]=Get-MedicalValidatedFormatNumber $layout $name 5 55}}
 foreach($name in @('MarginLeftCm','MarginRightCm','MarginTopCm','MarginBottomCm')){if(Test-MedicalFormatMember $layout $name){$updates[$name]=Get-MedicalValidatedFormatNumber $layout $name 0 20}}
 if(-not $updates.Count){return}
 $current=Get-MedicalPageLayout $model $id;$effective=@{}
 foreach($name in @('PageWidthCm','PageHeightCm','MarginLeftCm','MarginRightCm','MarginTopCm','MarginBottomCm')){$effective[$name]=Get-MedicalFormatMember $updates $name $current.$name}
 if($effective.MarginLeftCm+$effective.MarginRightCm -gt $effective.PageWidthCm-1 -or $effective.MarginTopCm+$effective.MarginBottomCm -gt $effective.PageHeightCm-1){throw 'Поля страницы должны оставлять не менее 1 см для текста.'}
 $section=Get-MedicalSectionProperties $model $id;$ns=Get-MedicalEditorNamespace $section.Xml
 $clone=if($section.Node){$section.Node.CloneNode($true)}else{$section.Xml.CreateElement('w','sectPr','http://schemas.openxmlformats.org/wordprocessingml/2006/main')}
 if($updates.ContainsKey('PageWidthCm') -or $updates.ContainsKey('PageHeightCm') -or $null -eq $clone.SelectSingleNode('./w:pgSz',$ns)){
  $size=Get-MedicalFormatChild $clone 'pgSz' $true
  foreach($record in @(@('PageWidthCm','w'),@('PageHeightCm','h'))){Set-MedicalFormatAttribute $size $record[1] ([string][int][Math]::Round($effective[$record[0]]*1440/2.54))}
  Set-MedicalFormatAttribute $size 'orient' $(if($effective.PageWidthCm -gt $effective.PageHeightCm){'landscape'}else{'portrait'})
 }
 if(@(@('MarginLeftCm','MarginRightCm','MarginTopCm','MarginBottomCm') | Where-Object {$updates.ContainsKey($_)}).Count){
  $margins=Get-MedicalFormatChild $clone 'pgMar' $true
  foreach($record in @(@('MarginLeftCm','left'),@('MarginRightCm','right'),@('MarginTopCm','top'),@('MarginBottomCm','bottom'))){if($updates.ContainsKey($record[0])){Set-MedicalFormatAttribute $margins $record[1] ([string][int][Math]::Round($updates[$record[0]]*1440/2.54))}}
  # CT_PageMar requires all seven attributes; defaults only fill missing attributes.
  foreach($record in @(@('left','MarginLeftCm'),@('right','MarginRightCm'),@('top','MarginTopCm'),@('bottom','MarginBottomCm'))){if(-not $margins.HasAttribute($record[0],$margins.NamespaceURI)){Set-MedicalFormatAttribute $margins $record[0] ([string][int][Math]::Round($effective[$record[1]]*1440/2.54))}}
  foreach($record in @(@('header','567'),@('footer','567'),@('gutter','0'))){if(-not $margins.HasAttribute($record[0],$margins.NamespaceURI)){Set-MedicalFormatAttribute $margins $record[0] $record[1]}}
 }
 if($section.Node -and $clone.OuterXml -ceq $section.Node.OuterXml){return}
 if($section.Node){[void]$section.Node.ParentNode.ReplaceChild($clone,$section.Node)}else{[void]$section.Xml.SelectSingleNode('/w:document/w:body',$ns).AppendChild($clone)}
 $model.Parts['word/document.xml'].Modified=$true
}
