﻿# v61: delete ordinary Word paragraphs while preserving required document blocks.

function Remove-MedicalTemplateParagraph($model,[string]$id){
 $matches=@($model.Paragraphs | Where-Object {$_.Id -ceq $id})
 if($matches.Count -ne 1){throw 'Абзац шаблона не найден.'}
 $paragraph=$matches[0]
 if(-not $model.Parts.ContainsKey([string]$paragraph.Part)){throw 'Часть Word не найдена.'}
 $part=$model.Parts[[string]$paragraph.Part];$node=$paragraph.Node
 if(-not $node.ParentNode -or -not [object]::ReferenceEquals($node.OwnerDocument,$part.Xml)){throw 'Абзац шаблона больше не существует.'}
 $namespaces=Get-MedicalEditorNamespace $part.Xml
 $reason=Get-MedicalEditorParagraphRestriction $node $namespaces
 if(-not $paragraph.Editable -or $reason){
  if(-not $reason){$reason=[string]$paragraph.Reason}
  if(-not $reason){$reason='Этот абзац доступен только для чтения.'}
  throw ('Удаление недоступно. '+$reason)
 }
 $container=$node.ParentNode
 if($container.NamespaceURI -cne $node.NamespaceURI -or $container.LocalName -notin @('body','tc','hdr','ftr')){
  throw 'Удалять можно обычные абзацы основного текста, таблицы или колонтитула. Выберите другое место.'
 }
 # Word requires a paragraph in an empty text container and after a nested
 # table in a cell. A paragraph section break also owns document settings:
 # remove its text, but keep that paragraph and its complete properties.
 $keepEmpty=$null -ne $node.SelectSingleNode('./w:pPr/w:sectPr',$namespaces)
 if(@($container.SelectNodes('./w:p',$namespaces)).Count -le 1){$keepEmpty=$true}
 if($container.LocalName -ceq 'tc'){
  $blocks=@($container.ChildNodes | Where-Object {$_ -is [Xml.XmlElement] -and $_.LocalName -cne 'tcPr'})
  if($blocks.Count -ge 2 -and [object]::ReferenceEquals($blocks[-1],$node) -and $blocks[-2].LocalName -cne 'p'){$keepEmpty=$true}
 }
 $selectedNode=$node
 if($keepEmpty){
  foreach($run in @($node.SelectNodes('./w:r',$namespaces))){[void]$node.RemoveChild($run)}
 }else{
  $neighbors=@($model.Paragraphs | Where-Object {$_.Part -ceq $paragraph.Part})
  $position=-1
  for($index=0;$index -lt $neighbors.Count;$index++){
   if([object]::ReferenceEquals($neighbors[$index].Node,$node)){$position=$index;break}
  }
  if($position -lt 0){throw 'Абзац шаблона больше не существует.'}
  if($position+1 -lt $neighbors.Count){$selectedNode=$neighbors[$position+1].Node}
  elseif($position -gt 0){$selectedNode=$neighbors[$position-1].Node}
  else{throw 'В части Word должен оставаться хотя бы один абзац.'}
  [void]$container.RemoveChild($node)
 }
 $part.Modified=$true
 Update-MedicalEditorParagraphs $model
 $selected=@($model.Paragraphs | Where-Object {$_.Part -ceq $paragraph.Part -and [object]::ReferenceEquals($_.Node,$selectedNode)})
 if($selected.Count -ne 1){throw 'Не удалось выбрать оставшийся абзац шаблона.'}
 return $selected[0]
}
