﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v64'))
$ErrorActionPreference='Stop'
$script:checks=0
function Assert-Check([bool]$condition,[string]$message){
 if(-not $condition){throw $message}
 $script:checks++;Write-Output ('PASS '+$message)
}
function Assert-Rejected([scriptblock]$operation,[string]$message){
 $rejected=$false
 try{& $operation}catch{$rejected=$true}
 Assert-Check $rejected $message
}
function Import-TestFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null
 $ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors | Out-String)}
 foreach($node in $ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
  if($names.Count -eq 0 -or $node.Name -in $names){
   . ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))
  }
 }
}
function Set-TestProperty($object,[string]$name,$value){$object | Add-Member -NotePropertyName $name -NotePropertyValue $value -Force}
function New-TestLegacyConfig {
 # Deliberately omit all new optional properties, as in a saved v49 schema.
 $field=[pscustomobject]@{Id='choice';Label='Выбор';Marker='CHOICE';Type='choice_detail';System='';WordId='';Options=@('Основной выбор','Другой выбор');Required=$true}
 return [pscustomobject]@{Version=49;AutoTemplate=$true;Template=(Join-Path $Project 'test-template.docx');Sections=@([pscustomobject]@{Id='test';Title='Проверочный раздел';Fields=@($field)})}
}
function New-TestConfig([string]$wordPosition='after',[string]$formPosition='below'){
 $config=New-TestLegacyConfig;$field=$config.Sections[0].Fields[0]
 Set-TestProperty $field 'DetailFormPosition' $formPosition
 Set-TestProperty $field 'DetailWordPosition' $wordPosition
 Set-TestProperty $field 'DetailMarker' $(if($wordPosition -eq 'marker'){'DETAIL_TEXT'}else{''})
 return $config
}
function Set-TestZipPart([string]$path,[string]$name,[string]$content){
 $zip=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{
  $entry=$zip.GetEntry($name);if($entry){$entry.Delete()}
  Write-UniversalZipText $zip $name $content
 }finally{$zip.Dispose()}
}
function Get-TestZipPart([string]$path,[string]$name){
 $zip=[IO.Compression.ZipFile]::OpenRead($path)
 try{return (Get-XmlPart $zip $name)}finally{$zip.Dispose()}
}
function Get-TestNamespace($xml){
 $manager=[Xml.XmlNamespaceManager]::new($xml.NameTable);$manager.AddNamespace('w',$script:ns);return ,$manager
}
function Get-TestText($node,$manager){return (($node.SelectNodes('.//w:t',$manager) | ForEach-Object {$_.InnerText}) -join '')}
function New-TestCustomTemplate([string]$path,$config){
 New-UniversalTemplate $path $config
 $document='<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="'+$script:ns+'" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><w:body>'+
  '<w:p><w:r><w:t>{{ADMISSION_DATETIME}}</w:t></w:r></w:p>'+
  '<w:p><w:r><w:t xml:space="preserve">До: {{DETAIL_</w:t></w:r><w:r><w:rPr><w:b/></w:rPr><w:t xml:space="preserve">TEXT}} / Ответ: {{CHO</w:t></w:r><w:r><w:t>ICE}}</w:t></w:r></w:p>'+
  '<w:tbl><w:tblPr/><w:tblGrid><w:gridCol w:w="5000"/></w:tblGrid><w:tr><w:tc><w:tcPr><w:tcW w:w="5000" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>{{DETAIL_TEXT}}</w:t></w:r></w:p></w:tc></w:tr></w:tbl>'+
  '<w:p><w:sdt><w:sdtPr><w:id w:val="765432"/><w:tag w:val="DETAIL_TEXT"/><w:dropDownList><w:listItem w:displayText="Основной выбор" w:value="Основной выбор"/></w:dropDownList></w:sdtPr><w:sdtContent><w:r><w:t>Исходный список</w:t></w:r></w:sdtContent></w:sdt></w:p>'+
  '<w:p><w:sdt><w:sdtPr><w:id w:val="987654"/><w:tag w:val="DETAIL_TEXT"/></w:sdtPr><w:sdtContent><w:r><w:t>Исходное уточнение</w:t></w:r></w:sdtContent></w:sdt></w:p>'+
  '<w:sectPr><w:headerReference w:type="default" r:id="rIdDetailHeader"/><w:pgSz w:w="11906" w:h="16838"/></w:sectPr></w:body></w:document>'
 Set-TestZipPart $path 'word/document.xml' $document
 $header='<?xml version="1.0" encoding="UTF-8"?><w:hdr xmlns:w="'+$script:ns+'"><w:p><w:r><w:t xml:space="preserve">Колонтитул: {{DETAIL_</w:t></w:r><w:r><w:t>TEXT}}</w:t></w:r></w:p></w:hdr>'
 Set-TestZipPart $path 'word/header1.xml' $header
 $rels=Get-TestZipPart $path 'word/_rels/document.xml.rels'
 $rel=$rels.CreateElement('Relationship','http://schemas.openxmlformats.org/package/2006/relationships')
 $rel.SetAttribute('Id','rIdDetailHeader');$rel.SetAttribute('Type','http://schemas.openxmlformats.org/officeDocument/2006/relationships/header');$rel.SetAttribute('Target','header1.xml');[void]$rels.DocumentElement.AppendChild($rel)
 Set-TestZipPart $path 'word/_rels/document.xml.rels' $rels.OuterXml
 $types=Get-TestZipPart $path '[Content_Types].xml'
 $override=$types.CreateElement('Override','http://schemas.openxmlformats.org/package/2006/content-types');$override.SetAttribute('PartName','/word/header1.xml');$override.SetAttribute('ContentType','application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml');[void]$types.DocumentElement.AppendChild($override)
 Set-TestZipPart $path '[Content_Types].xml' $types.OuterXml
}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-v58-details-test-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
try{
 Import-TestFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
 Import-TestFunctions (Join-Path $Project 'universal.ps1')
 Import-TestFunctions (Join-Path $Project 'workspace-settings.ps1') @('Load-DocumentFont','Set-DocumentFontXml','Apply-DocumentFont','Get-ProfilePatientValues')
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 $script:fontFile=Join-Path $Project 'document-font.json';$script:universalDetails=@{}
 $date=[datetime]'2026-10-13T12:30:00'
 $values=@{choice='Основной выбор'};$details=@{choice='  25 мг  '}
 $legacy=New-TestLegacyConfig;$legacyField=$legacy.Sections[0].Fields[0]
 Assert-UniversalConfig $legacy
 Assert-Check ((Get-UniversalDetailFormPosition $legacyField) -eq 'below') 'Legacy form detail defaults to below'
 Assert-Check ((Get-UniversalDetailWordPosition $legacyField) -eq 'after') 'Legacy Word detail defaults to after'
 Assert-Check ((Get-UniversalExportValues $legacy $values $details)['choice'] -ceq 'Основной выбор: 25 мг') 'Legacy display combines selection and trimmed detail'
 Assert-Check ((Get-UniversalExportValues $legacy $values $details $true $true)['choice'] -ceq 'Основной выбор: 25 мг') 'Legacy Word output remains compatible'
 foreach($formPosition in @('below','above','right')){
  $config=New-TestConfig 'after' $formPosition;Assert-UniversalConfig $config
  Assert-Check ((Get-UniversalDetailFormPosition $config.Sections[0].Fields[0]) -eq $formPosition) ('Valid form position: '+$formPosition)
  Assert-Check ((Get-UniversalExportValues $config $values $details $true $true)['choice'] -ceq 'Основной выбор: 25 мг') ('Form position does not alter Word: '+$formPosition)
 }
 $expected=@{after='Основной выбор: 25 мг';before='25 мг: Основной выбор';newline="Основной выбор`r`n25 мг";marker='Основной выбор'}
 foreach($wordPosition in @('after','before','newline','marker')){
  $config=New-TestConfig $wordPosition 'right';Assert-UniversalConfig $config
  Assert-Check ((Get-UniversalDetailWordPosition $config.Sections[0].Fields[0]) -eq $wordPosition) ('Valid Word position: '+$wordPosition)
  Assert-Check ((Get-UniversalExportValues $config $values $details $true $true)['choice'] -ceq $expected[$wordPosition]) ('Word composition: '+$wordPosition)
  Assert-Check ((Get-UniversalExportValues $config $values $details)['choice'] -ceq 'Основной выбор: 25 мг') ('Display remains complete: '+$wordPosition)
  Assert-Rejected {Get-UniversalExportValues $config @{choice=''} $details $true $true} ('Detail without selection rejected: '+$wordPosition)
  foreach($emptyDetail in @(''," `r`n`t ")){
   Assert-Check ((Get-UniversalExportValues $config $values @{choice=$emptyDetail} $true $true)['choice'] -ceq 'Основной выбор') ('Empty detail has no separator: '+$wordPosition+': '+$emptyDetail.Length)
  }
  $out=Join-Path $temp ($wordPosition+'.docx')
  Save-UniversalDocument $out $config $values $date $details
  $state=Read-UniversalDocumentState $out
  Assert-Check ($state.Version -eq 49 -and $state.Schema.Version -eq 49 -and $state.Values.choice -ceq $values.choice -and $state.Details.choice -ceq $details.choice) ('Raw data and schema49 round trip: '+$wordPosition)
  $savedField=$state.Schema.Sections[0].Fields[0]
  Assert-Check ($savedField.DetailFormPosition -eq 'right' -and $savedField.DetailWordPosition -eq $wordPosition -and $savedField.DetailMarker -eq $config.Sections[0].Fields[0].DetailMarker) ('Placement settings round trip: '+$wordPosition)
  $xml=Get-TestZipPart $out 'word/document.xml';$n=Get-TestNamespace $xml
  $text=Get-TestText $xml $n
  Assert-Check ($text.Contains('Основной выбор') -and $text.Contains('25 мг') -and -not $text.Contains('{{DETAIL_TEXT}}')) ('Auto-template exports every detail: '+$wordPosition)
  if($wordPosition -eq 'newline'){
   Assert-Check (@($xml.SelectNodes('//w:br',$n)).Count -gt 0) 'Newline output uses Word breaks'
   Assert-Check (@($xml.SelectNodes('//w:t',$n) | Where-Object {$_.InnerText -match '[\r\n]'}).Count -eq 0) 'Newline output has no raw newlines inside Word text nodes'
  }
 }
 $markerConfig=New-TestConfig 'marker';$wordValues=Get-UniversalExportValues $markerConfig $values $details $true $true
 $markers=Get-UniversalMarkerValues $markerConfig $wordValues $date $details
 Assert-Check ($markers.CHOICE -ceq 'Основной выбор' -and $markers.DETAIL_TEXT.Trim() -ceq '25 мг') 'Marker map keeps main value separate from detail'
 foreach($badPosition in @('left','diagonal','sideways')){
  $config=New-TestConfig;Set-TestProperty $config.Sections[0].Fields[0] 'DetailFormPosition' $badPosition
  Assert-Rejected {Assert-UniversalConfig $config} ('Reject invalid form position: '+$badPosition)
 }
 foreach($badPosition in @('right','horizontal','other')){
  $config=New-TestConfig;Set-TestProperty $config.Sections[0].Fields[0] 'DetailWordPosition' $badPosition
  Assert-Rejected {Assert-UniversalConfig $config} ('Reject invalid Word position: '+$badPosition)
 }
 foreach($badMarker in @('','detail_text','1DETAIL','BAD-MARKER','{{DETAIL_TEXT}}','ADMISSION_DATE','ADMISSION_TIME','ADMISSION_DATETIME','DIAGNOSIS_CODE','PATIENT_SEX','CHOICE')){
  $config=New-TestConfig 'marker';$config.Sections[0].Fields[0].DetailMarker=$badMarker
  Assert-Rejected {Assert-UniversalConfig $config} ('Reject invalid/reserved/conflicting detail marker: '+$badMarker)
 }
 $config=New-TestConfig 'marker'
 $later=[pscustomobject]@{Id='later';Label='Позднее поле';Marker='DETAIL_TEXT';Type='text';System='';WordId='';Options=@();Required=$false}
 $config.Sections[0].Fields+=@($later)
 Assert-Rejected {Assert-UniversalConfig $config} 'Reject detail marker collision with later main marker'
 $config=New-TestConfig 'marker'
 $later=Copy-UniversalObject $config.Sections[0].Fields[0];$later.Id='second';$later.Marker='SECOND';$config.Sections[0].Fields+=@($later)
 Assert-Rejected {Assert-UniversalConfig $config} 'Reject detail marker collision with later detail marker'
 $legacyOutput=Join-Path $temp 'legacy.docx';Save-UniversalDocument $legacyOutput $legacy $values $date $details
 $legacyState=Read-UniversalDocumentState $legacyOutput
 Assert-Check ($legacyState.Schema.Version -eq 49 -and $legacyState.Values.choice -ceq $values.choice -and $legacyState.Details.choice -ceq $details.choice) 'Legacy document preserves raw selection and details'
 # Exercise state restoration without loading or emulating WinForms.
 function script:Set-UniversalDemographics {}
 $script:admissionControl=[pscustomobject]@{Value=$date.AddDays(-1)}
 Restore-UniversalState $legacyState
 Assert-Check ($script:universalValues.choice -ceq $values.choice -and $script:universalDetails.choice -ceq $details.choice -and $script:admissionControl.Value -eq $date) 'Legacy state restores raw data and admission time'
 $legacyStringState=Copy-UniversalObject $legacyState
 $legacyStringState.AdmissionDateTime='2026-10-13T12:30:00'
 $script:admissionControl.Value=$date.AddDays(-2)
 Restore-UniversalState $legacyStringState
 Assert-Check ($legacyStringState.AdmissionDateTime -is [string] -and $script:admissionControl.Value -eq $date -and $script:universalValues.choice -ceq $values.choice -and $script:universalDetails.choice -ceq $details.choice) 'Legacy ISO string restores admission time and raw data'
 $config=New-TestConfig 'marker' 'above';$config.AutoTemplate=$false;$config.Template=Join-Path $temp 'custom.docx';$config.Sections[0].Fields[0].WordId='765432'
 New-TestCustomTemplate $config.Template $config
 $special="уточнение & <значение>`r`n{{CHOICE}}";$specialDetails=@{choice=$special}
 $customOutput=Join-Path $temp 'custom-output.docx';Save-UniversalDocument $customOutput $config $values $date $specialDetails
 $xml=Get-TestZipPart $customOutput 'word/document.xml';$n=Get-TestNamespace $xml
 $firstParagraph=$xml.SelectSingleNode('/w:document/w:body/w:p[2]',$n)
 Assert-Check ((Get-TestText $firstParagraph $n) -ceq ('До: '+$special.Replace("`r`n",'')+' / Ответ: Основной выбор')) 'Custom template places split-run detail before selection'
 Assert-Check ((Get-TestText $xml.SelectSingleNode('//w:tc/w:p',$n) $n) -ceq $special.Replace("`r`n",'')) 'Custom template places detail in table cell'
 $mainControl=$xml.SelectSingleNode('//w:sdt[w:sdtPr/w:id[@w:val="765432"]]',$n)
 Assert-Check ((Get-TestText $mainControl $n) -ceq 'Основной выбор') 'Explicit WordId takes priority over detail tag'
 $detailControl=$xml.SelectSingleNode('//w:sdt[w:sdtPr/w:id[@w:val="987654"]]',$n)
 Assert-Check ((Get-TestText $detailControl $n) -ceq $special.Replace("`r`n",'')) 'Separate Word tag receives detail without selection'
 Assert-Check (@($firstParagraph.SelectNodes('.//w:br',$n)).Count -eq 1) 'Multiline detail uses break and retains XML-special characters'
 Assert-Check ((Get-TestText $firstParagraph $n).Contains('{{CHOICE}}')) 'Marker-like user text is not recursively replaced'
 $header=Get-TestZipPart $customOutput 'word/header1.xml';$hn=Get-TestNamespace $header
 Assert-Check ((Get-TestText $header $hn) -ceq ('Колонтитул: '+$special.Replace("`r`n",''))) 'Split detail marker in header is replaced'
 $state=Read-UniversalDocumentState $customOutput;Restore-UniversalState $state
 Assert-Check ($script:universalValues.choice -ceq $values.choice -and $script:universalDetails.choice -ceq $special -and $script:universalConfig.Sections[0].Fields[0].DetailFormPosition -eq 'above' -and $script:universalConfig.Sections[0].Fields[0].WordId -eq '765432') 'Custom document restores raw details, layout and Word binding'
 # A literal detail marker inside a primary bound SDT would be erased by the primary value.
 $conflict=Copy-UniversalObject $config;$conflict.Template=Join-Path $temp 'conflicting-detail.docx'
 Copy-Item -LiteralPath $config.Template -Destination $conflict.Template
 $xml=Get-TestZipPart $conflict.Template 'word/document.xml';$n=Get-TestNamespace $xml
 $conflictingText=$xml.SelectSingleNode('//w:sdt[w:sdtPr/w:id[@w:val="765432"]]/w:sdtContent//w:t',$n)
 $conflictingText.InnerText='{{DETAIL_TEXT}}'
 Set-TestZipPart $conflict.Template 'word/document.xml' $xml.OuterXml
 $conflictHash=(Get-FileHash $customOutput -Algorithm SHA256).Hash
 Assert-Rejected {Save-UniversalDocument $customOutput $conflict $values $date $specialDetails} 'Detail marker inside primary WordId control rejects export'
 Assert-Check ((Get-FileHash $customOutput -Algorithm SHA256).Hash -eq $conflictHash) 'Conflicting bound detail marker leaves existing DOCX unchanged'
 # Missing detail placement must fail atomically; whitespace-only details remain optional.
 $missing=New-TestConfig 'marker';$missing.AutoTemplate=$false;$missing.Template=Join-Path $temp 'missing-detail.docx'
 New-UniversalTemplate $missing.Template $missing
 $xml=Get-TestZipPart $missing.Template 'word/document.xml'
 Set-TestZipPart $missing.Template 'word/document.xml' ($xml.OuterXml.Replace('{{DETAIL_TEXT}}','Без уточнения'))
 $preservedHash=(Get-FileHash $customOutput -Algorithm SHA256).Hash
 Assert-Rejected {Save-UniversalDocument $customOutput $missing $values $date $details} 'Missing detail marker rejects custom export'
 Assert-Check ((Get-FileHash $customOutput -Algorithm SHA256).Hash -eq $preservedHash) 'Missing detail marker leaves existing DOCX unchanged'
 $whitespace=" `r`n`t ";$emptyOutput=Join-Path $temp 'empty-detail.docx'
 Save-UniversalDocument $emptyOutput $missing $values $date @{choice=$whitespace}
 $emptyState=Read-UniversalDocumentState $emptyOutput
 Assert-Check ($emptyState.Details.choice -ceq $whitespace -and $emptyState.Values.choice -ceq $values.choice) 'Whitespace-only unplaced detail is optional and stored without normalization'
 $nullOutput=Join-Path $temp 'null-detail.docx';Save-UniversalDocument $nullOutput $missing $values $date $null
 Assert-Check (Test-Path -LiteralPath $nullOutput) 'Null details work with custom marker template'
 # Existing data field types keep their output rules.
 $plainConfig=New-TestLegacyConfig;$plainConfig.Sections[0].Fields=@()
 $plainValues=@{};$plainExpected=@{}
 foreach($type in @('text','multiline','choice','multi','repeat','heading')){
  $field=New-UniversalField $type ('Поле '+$type) $type.ToUpperInvariant() $type
  if($type -in @('choice','multi','repeat')){$field.Options=@('Один','Два')}
  $plainConfig.Sections[0].Fields+=@($field)
  $plainValues[$type]=switch($type){'multiline'{"Строка 1`r`nСтрока 2"};'multi'{"Один`r`nДва"};'repeat'{"Один`r`nОдин"};'heading'{''};default{'Один'}}
  $plainExpected[$type]=switch($type){'multi'{"- Один`r`n- Два"};'repeat'{"- Один`r`n- Один"};'heading'{$field.Label};default{$plainValues[$type]}}
 }
 Assert-UniversalConfig $plainConfig;$plain=Get-UniversalExportValues $plainConfig $plainValues @{} $true $true
 foreach($type in $plainExpected.Keys){Assert-Check ($plain[$type] -ceq $plainExpected[$type]) ('Existing field output stays unchanged: '+$type)}
 Assert-Check (@(Get-ChildItem -LiteralPath $temp -Filter '*.tmp').Count -eq 0) 'Failed and successful exports remove temporary files'
 Write-Output ('COMPLETED: '+$script:checks+' detail checks passed. WinForms placement and Windows printing require manual validation.')
}finally{Remove-Item -LiteralPath $temp -Recurse -Force}
