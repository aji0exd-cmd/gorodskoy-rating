﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $root
$log = Join-Path $root 'startup_error.txt'
# The native host reads this result instead of mistaking handled errors for failure.
$global:MedicalConstructorStartupFailureV72=$false
try {
    if (Test-Path -LiteralPath $log) { Remove-Item -LiteralPath $log -Force }
    $Error.Clear()
    . (Join-Path $root 'startup-diagnostics-v72.ps1')
    & (Join-Path $root 'constructor.ps1') 2>&1 | ForEach-Object {
        if ($_ -is [System.Management.Automation.ErrorRecord]) { throw $_ }
    }
    if (-not $?) { throw 'constructor.ps1 finished with an error.' }
} catch {
    $startupError=$_
    $global:MedicalConstructorStartupFailureV72=$true
    $safeCode=[guid]::NewGuid().ToString('N')
    try{
        . (Join-Path $root 'core-guard-v71.ps1')
        [void](Initialize-MedicalCoreGuard $root)
        $incident=Write-MedicalCoreIncident $startupError 'startup'
        $safeCode=$incident.Incident.Id
    }catch{}
    try{
        if(-not (Get-Command Write-MedicalStartupDiagnostic -CommandType Function -ErrorAction SilentlyContinue)){. (Join-Path $root 'startup-diagnostics-v72.ps1')}
        $null=Write-MedicalStartupDiagnostic $startupError $root $safeCode
    }catch{
        $details='Startup failed. Incident code: '+$safeCode+'. No passwords or document contents are included in this log.'
        try{[System.IO.File]::WriteAllText($log, $details, [System.Text.UTF8Encoding]::new($true))}catch{}
    }
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("Не удалось запустить программу. Сведения об ошибке сохранены в startup_error.txt в папке программы.`r`n`r`nКод события: "+$safeCode, "Медицинский конструктор — ошибка запуска", 'OK', 'Error') | Out-Null
}
