﻿# One rendered hospitalization is shared by Preview, Print and Save Card.
# Only private rendered snapshots open in Word; reusable templates stay closed.
function Get-MedicalHospitalizationContexts {
 if(-not $script:medicalClinicalForms){throw 'Сначала откройте или создайте форму госпитализации.'}
 # Explicit exports must re-read authored source bytes before building contexts;
 # UI refreshes may use the cheaper file-metadata signature between exports.
 if(Get-Command Sync-MedicalDischargeSchemaFromInitial -CommandType Function -ErrorAction SilentlyContinue){Sync-MedicalDischargeSchemaFromInitial $true}
 $initial=Get-UniversalState
 $admission=[datetime]::ParseExact([string]$initial.AdmissionDateTime,'yyyy-MM-ddTHH:mm:ss',[Globalization.CultureInfo]::InvariantCulture)
 [pscustomobject]@{Stage='initial';Id='initial';Title='Первичный осмотр';Schema=$initial.Schema;Values=$initial.Values;Details=$initial.Details;DateTime=$admission}
 foreach($entry in @(Get-MedicalClinicalDiaryContexts)){
  # A reusable form can contain more empty diary slots than this patient's
  # selected date range. Keep the structure; export scheduled or authored notes.
  if((Get-Command Test-MedicalClinicalDiaryUnscheduled -ErrorAction SilentlyContinue) -and (Test-MedicalClinicalDiaryUnscheduled $entry)){continue}
  [pscustomobject]@{Stage='diary';Id=$entry.Id;Title=$entry.Title;Schema=$entry.Schema;Values=$entry.Values;Details=$entry.Details;DateTime=$entry.DateTime;DateCount=$(if($entry.DateCount){[int]$entry.DateCount}else{1});EndDateTime=$(if($entry.EndDateTime){[datetime]$entry.EndDateTime}else{[datetime]$entry.DateTime})}
 }
 # A newly created discharge keeps unmodified fields linked to the initial
 # examination. Explicit patient overrides belong to the discharge itself.
 Sync-MedicalDischargeFromInitial
 $discharge=Get-MedicalClinicalContext 'discharge'
 [pscustomobject]@{Stage='discharge';Id='discharge';Title='Выписной эпикриз';Schema=$discharge.Schema;Values=$discharge.Values;Details=$discharge.Details;DateTime=$discharge.DateTime}
}
function Set-MedicalHospitalizationDocumentState([string]$path,$contexts){
 # Filled multi-stage exports cannot be reopened as reusable Word templates.
 # Save Card adds the complete restorable mc-case envelope after this step.
 $stages=@(foreach($context in $contexts){[pscustomobject]@{Stage=$context.Stage;Id=$context.Id;Title=$context.Title;Schema=$context.Schema;Values=$context.Values;Details=$context.Details;DateTime=$context.DateTime.ToString('yyyy-MM-ddTHH:mm:ss');DateCount=$(if($context.Stage -eq 'diary' -and $context.DateCount){[int]$context.DateCount}else{1});EndDateTime=$(if($context.Stage -eq 'diary' -and $context.EndDateTime){([datetime]$context.EndDateTime).ToString('yyyy-MM-ddTHH:mm:ss')}else{$context.DateTime.ToString('yyyy-MM-ddTHH:mm:ss')})}})
 $payload=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(([pscustomobject]@{Version=68;Stage='hospitalization';NoTemplate=$true;Stages=$stages} | ConvertTo-Json -Depth 50 -Compress)))
 $archive=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{
  if(-not $archive.GetEntry('word/document.xml')){throw 'Word не создал документ госпитализации.'}
  $types=Get-MedicalDiaryXml $archive '[Content_Types].xml';if(-not $types){throw 'Word не создал список частей документа госпитализации.'}
  $rels=Get-MedicalDiaryXml $archive 'word/_rels/document.xml.rels';$r='http://schemas.openxmlformats.org/package/2006/relationships';$c='http://schemas.openxmlformats.org/package/2006/content-types'
  if(-not $rels){$rels=[xml]('<Relationships xmlns="'+$r+'"/>')}
  foreach($item in @($rels.DocumentElement.ChildNodes)){if($item -is [Xml.XmlElement] -and $item.GetAttribute('Target') -in @('../customXml/mc49.xml','/customXml/mc49.xml')){[void]$rels.DocumentElement.RemoveChild($item)}}
  $rel=$rels.CreateElement('Relationship',$r);[void]$rel.SetAttribute('Id',('rIdMCHospitalization'+[guid]::NewGuid().ToString('N')));[void]$rel.SetAttribute('Type','http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXml');[void]$rel.SetAttribute('Target','../customXml/mc49.xml');[void]$rels.DocumentElement.AppendChild($rel)
  foreach($item in @($types.DocumentElement.ChildNodes)){if($item -is [Xml.XmlElement] -and $item.GetAttribute('PartName') -ieq '/customXml/mc49.xml'){[void]$types.DocumentElement.RemoveChild($item)}}
  $override=$types.CreateElement('Override',$c);[void]$override.SetAttribute('PartName','/customXml/mc49.xml');[void]$override.SetAttribute('ContentType','application/xml');[void]$types.DocumentElement.AppendChild($override)
  Set-MedicalDiaryXml $archive '[Content_Types].xml' $types;Set-MedicalDiaryXml $archive 'word/_rels/document.xml.rels' $rels
  Set-MedicalDiaryXml $archive 'customXml/mc49.xml' ([xml]('<mc:state xmlns:mc="urn:medical-constructor:v49">'+$payload+'</mc:state>'))
 }finally{$archive.Dispose()}
}
# One private completed render is retained for repeated Preview / Save / Print.
# Cache files are never opened by the user and never receive the mc-case envelope.
function ConvertTo-MedicalHospitalizationCanonicalValue($value){
 if($null -eq $value){return $null}
 if($value -is [datetime]){return $value.ToString('o',[Globalization.CultureInfo]::InvariantCulture)}
 if($value -is [string] -or $value -is [ValueType]){return $value}
 if($value -is [Collections.IDictionary]){
  $result=[ordered]@{};[string[]]$keys=@($value.Keys | ForEach-Object {[string]$_});[Array]::Sort($keys,[StringComparer]::Ordinal)
  foreach($key in $keys){$result[$key]=ConvertTo-MedicalHospitalizationCanonicalValue $value[$key]}
  return [pscustomobject]$result
 }
 if($value -is [Collections.IEnumerable]){
  $items=New-Object Collections.ArrayList
  foreach($item in $value){[void]$items.Add((ConvertTo-MedicalHospitalizationCanonicalValue $item))}
  return ,($items.ToArray())
 }
 $result=[ordered]@{};[string[]]$names=@($value.PSObject.Properties.Name);[Array]::Sort($names,[StringComparer]::Ordinal)
 foreach($name in $names){$result[$name]=ConvertTo-MedicalHospitalizationCanonicalValue $value.$name}
 return [pscustomobject]$result
}
function Get-MedicalHospitalizationFileHash([string]$path){
 $stream=[IO.File]::OpenRead($path);$sha=[Security.Cryptography.SHA256]::Create()
 try{return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose();$stream.Dispose()}
}
function Test-MedicalHospitalizationTemplateCacheable([string]$path){
 # Native Word can resolve these from the clock, output name or files outside
 # the DOCX. Re-render such templates instead of guessing their dependencies.
 $archive=[IO.Compression.ZipFile]::OpenRead($path)
 try{
  foreach($entry in $archive.Entries){
   if($entry.FullName -match '(^|/)_rels/[^/]*\.rels$'){
    $xml=Get-MedicalDiaryXml $archive $entry.FullName
    foreach($relation in $xml.DocumentElement.ChildNodes){
     if($relation -is [Xml.XmlElement] -and $relation.GetAttribute('TargetMode') -ieq 'External' -and $relation.GetAttribute('Type') -notmatch '/hyperlink$'){return $false}
    }
   }
   if($entry.FullName -notmatch '^word/(document|header[0-9]*|footer[0-9]*|footnotes|endnotes|comments)\.xml$'){continue}
   $xml=Get-MedicalDiaryXml $archive $entry.FullName;$n=New-Object Xml.XmlNamespaceManager($xml.NameTable);$n.AddNamespace('w','http://schemas.openxmlformats.org/wordprocessingml/2006/main')
   foreach($instruction in $xml.SelectNodes('//w:fldSimple/@w:instr|//w:instrText',$n)){
    $code=[regex]::Match([string]$instruction.get_InnerText(),'^\s*([A-Za-z]+)').Groups[1].Value.ToUpperInvariant()
    # Page fields and internal references depend on this completed document.
    # Hyperlinks are clickable destinations, not rendered external resources.
    if($code -notin @('PAGE','NUMPAGES','SECTION','SECTIONPAGES','REF','PAGEREF','STYLEREF','SEQ','LISTNUM','HYPERLINK')){return $false}
   }
  }
  return $true
 }finally{$archive.Dispose()}
}
function Get-MedicalHospitalizationRenderKey($contexts,$allSchemas){
 $sources=New-Object Collections.ArrayList;$hashes=New-Object 'Collections.Generic.Dictionary[string,string]' ([StringComparer]::OrdinalIgnoreCase);$cacheable=$true
 foreach($schema in $allSchemas){
  if($schema.AutoTemplate){[void]$sources.Add([pscustomobject]@{Automatic=$true});continue}
  $source=Get-UniversalTemplatePath $schema;$full=[IO.Path]::GetFullPath($source)
  if(-not $hashes.ContainsKey($full)){
   # Read full package bytes on every request: size and timestamp alone miss
   # external edits to headers, pictures, styles and same-time Word saves.
   $hashes[$full]=if([IO.File]::Exists($full)){Get-MedicalHospitalizationFileHash $full}else{'missing'}
   if($hashes[$full] -cne 'missing' -and -not (Test-MedicalHospitalizationTemplateCacheable $full)){$cacheable=$false}
  }
  [void]$sources.Add([pscustomobject]@{Automatic=$false;Path=$full;SHA256=$hashes[$full]})
 }
 if(-not $cacheable){return ''}
 $period=if(Get-Command Get-MedicalTreatmentPeriod -CommandType Function -ErrorAction SilentlyContinue){Get-MedicalTreatmentPeriod}else{$null}
 $font=if(Get-Command Load-DocumentFont -CommandType Function -ErrorAction SilentlyContinue){Load-DocumentFont}else{$null}
 $inputValue=[pscustomobject]@{Version=69;Contexts=@($contexts);Schemas=@($allSchemas);Sources=$sources.ToArray();TreatmentPeriod=$period;DocumentFont=$font}
 $json=ConvertTo-Json -InputObject (ConvertTo-MedicalHospitalizationCanonicalValue $inputValue) -Depth 100 -Compress
 $sha=[Security.Cryptography.SHA256]::Create()
 try{return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($json)))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
}
function Clear-MedicalHospitalizationRenderCache {
 $cache=$script:medicalHospitalizationRenderCache;$script:medicalHospitalizationRenderCache=$null
 if($cache -and [IO.Directory]::Exists([string]$cache.Folder)){try{[IO.Directory]::Delete([string]$cache.Folder,$true)}catch{}}
}
function Copy-MedicalHospitalizationCachedRender([string]$key,[string]$temporary){
 $cache=$script:medicalHospitalizationRenderCache
 if([string]::IsNullOrEmpty($key) -or -not $cache -or [string]$cache.Key -cne $key){return $false}
 try{
  if(-not [IO.File]::Exists([string]$cache.Path) -or (Get-MedicalHospitalizationFileHash ([string]$cache.Path)) -cne [string]$cache.SHA256){Clear-MedicalHospitalizationRenderCache;return $false}
 }catch{Clear-MedicalHospitalizationRenderCache;return $false}
 # Destination failures must still fail atomically instead of discarding a good
 # render and retrying native Word. The completed private file is never exposed.
 [IO.File]::Copy([string]$cache.Path,$temporary,$false)
 if((Get-MedicalHospitalizationFileHash $temporary) -cne [string]$cache.SHA256){[IO.File]::Delete($temporary);Clear-MedicalHospitalizationRenderCache;return $false}
 return $true
}
function Save-MedicalHospitalizationCachedRender([string]$key,[string]$completed){
 if([string]::IsNullOrEmpty($key)){return}
 $cache=$script:medicalHospitalizationRenderCache;$folder='';$pending=''
 try{
  $folder=if($cache -and [IO.Directory]::Exists([string]$cache.Folder)){[string]$cache.Folder}else{Join-Path ([IO.Path]::GetTempPath()) ('mc-hospitalization-cache-'+[guid]::NewGuid().ToString('N'))}
  [void][IO.Directory]::CreateDirectory($folder);$pending=Join-Path $folder ('pending-'+[guid]::NewGuid().ToString('N')+'.docx');$destination=Join-Path $folder 'completed.docx'
  [IO.File]::Copy($completed,$pending,$false);$hash=Get-MedicalHospitalizationFileHash $pending
  if([IO.File]::Exists($destination)){[IO.File]::Replace($pending,$destination,[NullString]::Value)}else{[IO.File]::Move($pending,$destination)}
  $script:medicalHospitalizationRenderCache=[pscustomobject]@{Key=$key;Folder=$folder;Path=$destination;SHA256=$hash}
 }catch{
  # The export remains successful when private temporary storage is unavailable.
  if($folder -and (-not $cache -or $folder -cne [string]$cache.Folder) -and [IO.Directory]::Exists($folder)){try{[IO.Directory]::Delete($folder,$true)}catch{}}
 }finally{if($pending -and [IO.File]::Exists($pending)){try{[IO.File]::Delete($pending)}catch{}}}
}
function Export-MedicalHospitalizationDocument([string]$path,[bool]$allowIncomplete=$false){
 $target=[IO.Path]::GetFullPath($path)
 if([IO.Path]::GetExtension($target) -ine '.docx'){throw 'Карта госпитализации сохраняется в формате DOCX.'}
 $contexts=@(Get-MedicalHospitalizationContexts)
 # Empty reusable diary slots can be omitted from this patient's document,
 # but their source templates are still part of the form and stay protected.
 $allSchemas=@($script:universalConfig)
 foreach($definition in @($script:medicalClinicalForms.Diaries)){$allSchemas+=@($definition.Schema)}
 if($script:medicalClinicalForms.PSObject.Properties['DiaryForm'] -and $script:medicalClinicalForms.DiaryForm){$allSchemas+=@($script:medicalClinicalForms.DiaryForm.Schema)}
 if($script:medicalClinicalForms.Discharge){$allSchemas+=@($script:medicalClinicalForms.Discharge.Schema)}
 foreach($schema in $allSchemas){
  $source=Get-UniversalTemplatePath $schema
  if($source -and [string]::Equals($target,[IO.Path]::GetFullPath($source),[StringComparison]::OrdinalIgnoreCase)){throw 'Нельзя сохранять карту поверх исходного Word-шаблона формы.'}
 }
 foreach($context in $contexts){
  if(-not $allowIncomplete){
   $missing=@(Get-UniversalMissingFields $context.Schema $context.Values)
   if($missing.Count){throw ('Заполните обязательные поля этапа «'+$context.Title+'»: '+(($missing | ForEach-Object {$_.Label}) -join ', ')+'.')}
   foreach($field in Get-UniversalFields $context.Schema){
    if($field.System -eq 'birth' -and -not [string]::IsNullOrWhiteSpace([string]$context.Values[[string]$field.Id])){
     $birth=[datetime]::MinValue
     if(-not [datetime]::TryParseExact([string]$context.Values[[string]$field.Id],'dd.MM.yyyy',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$birth)){throw ('Дата рождения в этапе «'+$context.Title+'» должна быть в формате ДД.ММ.ГГГГ.')}
    }
   }
  }
  [void](Get-UniversalExportValues $context.Schema $context.Values $context.Details (-not $allowIncomplete) $true)
  $source=Get-UniversalTemplatePath $context.Schema
  if($source -and [string]::Equals($target,[IO.Path]::GetFullPath($source),[StringComparison]::OrdinalIgnoreCase)){throw ('Нельзя сохранять карту поверх исходного Word-шаблона: '+$context.Title+'.')}
  if(-not $context.Schema.AutoTemplate -and -not [IO.File]::Exists($source)){throw ('Не найден Word-шаблон «'+$context.Title+'». Откройте форму со всеми шаблонами или выберите шаблон в редакторе этого этапа.')}
 }
 $renderKey=Get-MedicalHospitalizationRenderKey $contexts $allSchemas
 $folder=Join-Path ([IO.Path]::GetTempPath()) ('mc-hospitalization-export-'+[guid]::NewGuid().ToString('N'))
 $temporary=Join-Path ([IO.Path]::GetDirectoryName($target)) ('mc-hospitalization-'+[guid]::NewGuid().ToString('N')+'.docx')
 try{
  if(Copy-MedicalHospitalizationCachedRender $renderKey $temporary){
   if([IO.File]::Exists($target)){[IO.File]::Replace($temporary,$target,[NullString]::Value)}else{[IO.File]::Move($temporary,$target)}
   return
  }
  [void][IO.Directory]::CreateDirectory($folder);$snapshots=@();$index=0
  foreach($context in $contexts){
   $index++;$snapshot=Join-Path $folder ($index.ToString('D4')+'-'+$context.Stage+'.docx')
   $documentStage=if($context.Stage -eq 'initial'){''}else{$context.Stage}
   Save-UniversalDocument $snapshot $context.Schema $context.Values $context.DateTime $context.Details $allowIncomplete $documentStage
   if($context.Stage -eq 'diary' -and (Get-Command Set-MedicalDiaryPeriodDocument -ErrorAction SilentlyContinue)){Set-MedicalDiaryPeriodDocument $snapshot $context}
   if($context.Stage -eq 'discharge' -and (Get-Command Set-MedicalDischargePeriodDocument -ErrorAction SilentlyContinue)){Set-MedicalDischargePeriodDocument $snapshot $context.Schema}
   Protect-MedicalDiarySnapshotFormatting $snapshot ('MC67_'+[guid]::NewGuid().ToString('N')+'_')
   Remove-MedicalDiarySnapshotState $snapshot;$snapshots+=@($snapshot)
  }
  # Initial examination and discharge are present even without diary records.
  # Word preserves individual section layouts, headers, styles and resources.
  Merge-MedicalDiaryWordSnapshots $snapshots $temporary
  Set-MedicalHospitalizationDocumentState $temporary $contexts
  # This function returns before callers can add card data or open the export.
  if([IO.File]::Exists($target)){[IO.File]::Replace($temporary,$target,[NullString]::Value)}else{[IO.File]::Move($temporary,$target)}
  Save-MedicalHospitalizationCachedRender $renderKey $target
 }finally{
  if([IO.File]::Exists($temporary)){[IO.File]::Delete($temporary)}
  if([IO.Directory]::Exists($folder)){[IO.Directory]::Delete($folder,$true)}
 }
}
