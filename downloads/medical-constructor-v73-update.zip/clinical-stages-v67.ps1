﻿# Clinical schemas belong to reusable forms. Patient values belong to cases only.
$script:medicalClinicalForms=$null
$script:medicalClinicalState=$null
$script:medicalClinicalFieldIndexes=@{}
$script:medicalClinicalBindingIndex=$null
$script:medicalClinicalInitialSignatureCache=$null

function ConvertTo-MedicalClinicalMap($source){
 $result=@{}
 if($source -is [Collections.IDictionary]){foreach($key in $source.Keys){$result[[string]$key]=$source[$key]}}
 elseif($source){foreach($property in $source.PSObject.Properties){$result[$property.Name]=$property.Value}}
 return $result
}
function Copy-MedicalClinicalValues($source,$schema,[bool]$details=$false){
 $map=ConvertTo-MedicalClinicalMap $source;$result=@{}
 foreach($field in Get-UniversalFields $schema){
  $id=[string]$field.Id
  if($map.ContainsKey($id) -and (-not $details -or $field.Type -eq 'choice_detail')){$result[$id]=[string]$map[$id]}
 }
 return $result
}
function Get-MedicalInitialState {return (Get-UniversalState)}
function New-MedicalDiarySchema($initial=$script:universalConfig){
 $patientFields=@(foreach($source in Get-UniversalFields $initial){
  if($source.System){
   $field=New-UniversalField ([string]$source.Id) ([string]$source.Label) ([string]$source.Marker) 'text' ([string]$source.System)
   $field.Required=$false;$field
  }
 })
 $sections=@();$usedIds=@{};$usedMarkers=@{}
 foreach($field in $patientFields){$usedIds[[string]$field.Id]=$true;$usedMarkers[[string]$field.Marker]=$true}
 if($patientFields.Count){$sections+=@([pscustomobject]@{Id='diary_patient';Title='Сведения о пациенте';Fields=$patientFields})}
 foreach($definition in @(
  @('diary_complaints','Жалобы','DIARY_COMPLAINTS'),
  @('diary_examination','Объективное состояние','DIARY_EXAMINATION'),
  @('diary_progress','Динамика состояния','DIARY_PROGRESS'),
  @('diary_treatment','Лечение и назначения','DIARY_TREATMENT')
 )){
  $id=$definition[0];$marker=$definition[2];$suffix=1
  while($usedIds.ContainsKey($id)){$id=$definition[0]+'_'+$suffix;$suffix++}
  $suffix=1;while($usedMarkers.ContainsKey($marker)){$marker=$definition[2]+'_'+$suffix;$suffix++}
  $usedIds[$id]=$true;$usedMarkers[$marker]=$true
  $field=New-UniversalField $id $definition[1] $marker;$field.Required=$false
  $sections+=@([pscustomobject]@{Id=$id;Title=$definition[1];Fields=@($field)})
 }
 $schema=[pscustomobject]@{Version=49;AutoTemplate=$true;Template='Дневник наблюдения.docx';DocumentTitle='Дневник наблюдения';DateTimeLabel='Дата и время записи';PreserveTemplateFormatting=$true;Sections=$sections}
 Assert-UniversalConfig $schema;return $schema
}
function New-MedicalDischargeSchema($initial=$script:universalConfig){
 $schema=Copy-MedicalFormSchema $initial
 # An automatic stage template contains markers, so copied Word dropdown IDs
 # must become ordinary options rather than dangling bindings to another file.
 $wordFields=@()
 $initialPath=Get-UniversalTemplatePath $initial
 if([IO.File]::Exists($initialPath)){$wordFields=@(Get-UniversalWordFields $initialPath)}
 foreach($field in Get-UniversalFields $schema){
  if($field.Type -in @('choice','choice_detail') -and @($field.Options).Count -eq 0){
   $bound=@($wordFields | Where-Object {[string]$_.Id -eq [string]$field.WordId})
   if($bound.Count){$field.Options=@($bound[0].Options)}
   if(@($field.Options).Count -eq 0){throw ('Для эпикриза добавьте варианты списка «'+$field.Label+'» в первичную форму.')}
  }
  $field.WordId=''
 }
 $existingIds=@{};$existingMarkers=@{}
 foreach($field in Get-UniversalFields $schema){$existingIds[[string]$field.Id]=$true;$existingMarkers[[string]$field.Marker]=$true;if($field.DetailMarker){$existingMarkers[[string]$field.DetailMarker]=$true}}
 foreach($definition in @(
  @('final_diagnosis','Заключительный диагноз','FINAL_DIAGNOSIS'),
  @('examination_results','Результаты обследования','EXAMINATION_RESULTS'),
  @('treatment_results','Результаты лечения','TREATMENT_RESULTS'),
  @('recommendations','Рекомендации','RECOMMENDATIONS')
 )){
  $id=$definition[0];$marker=$definition[2];$suffix=1
  while($existingIds.ContainsKey($id)){$id=$definition[0]+'_'+$suffix;$suffix++}
  $suffix=1;while($existingMarkers.ContainsKey($marker)){$marker=$definition[2]+'_'+$suffix;$suffix++}
  $existingIds[$id]=$true;$existingMarkers[$marker]=$true
  $sectionId='discharge_'+$id
  while(@($schema.Sections | Where-Object {[string]$_.Id -eq $sectionId}).Count){$sectionId+='x'}
  $field=New-UniversalField $id $definition[1] $marker;$field.Required=$false
  $schema.Sections+=@([pscustomobject]@{Id=$sectionId;Title=$definition[1];Fields=@($field)})
 }
 $schema.AutoTemplate=$true;$schema.Template='Выписной эпикриз.docx'
 $schema | Add-Member -NotePropertyName DocumentTitle -NotePropertyValue 'Выписной эпикриз' -Force
 $schema | Add-Member -NotePropertyName DateTimeLabel -NotePropertyValue 'Дата и время поступления' -Force
 $schema | Add-Member -NotePropertyName PreserveTemplateFormatting -NotePropertyValue $true -Force
 Assert-UniversalConfig $schema;return $schema
}
function Get-MedicalClinicalDefaultLinks($schema,$initial=$script:universalConfig,[bool]$diagnosis=$false){
 $sources=@(Get-UniversalFields $initial);$result=@{}
 foreach($field in Get-UniversalFields $schema){
  $match=@($sources | Where-Object {[string]$_.Id -eq [string]$field.Id})
  if(-not $match.Count -and $field.System){$match=@($sources | Where-Object {[string]$_.System -eq [string]$field.System})}
  if($match.Count){$result[[string]$field.Id]=[string]$match[0].Id}
  elseif($diagnosis -and [string]$field.Marker -match '^FINAL_DIAGNOSIS(?:_[0-9]+)?$'){
   $match=@($sources | Where-Object {[string]$_.Marker -eq 'PRELIMINARY_DIAGNOSIS'})
   if($match.Count){$result[[string]$field.Id]=[string]$match[0].Id}
  }
 }
 return $result
}
function Get-MedicalClinicalDiaryDateCount($definition){
 if(-not $definition.PSObject.Properties['DateCount']){return 1}
 $count=$definition.DateCount
 if(($count -isnot [int] -and $count -isnot [long]) -or $count -notin @(1,2)){throw 'Для дневника выберите одну дату или период из двух дат.'}
 return [int]$count
}
# A reusable diary definition contains structure and links, never patient values.
function Copy-MedicalSharedDiaryDefinition($source){
 if(-not $source -or -not $source.Schema){throw 'В общей форме дневников отсутствует структура.'}
 $schema=Copy-MedicalFormSchema $source.Schema;$links=ConvertTo-MedicalClinicalMap $source.Links;$allowed=@{}
 foreach($field in Get-UniversalFields $schema){
  $id=[string]$field.Id
  if($links.ContainsKey($id) -and -not [string]::IsNullOrWhiteSpace([string]$links[$id])){$allowed[$id]=[string]$links[$id]}
 }
 return [pscustomobject]@{Schema=$schema;Links=$allowed}
}
function Copy-MedicalArchivedDiaryFields($source){
 if($null -eq $source){return}
 $entries=@($source);if($entries.Count -gt 10000){throw 'Слишком много сохранённых полей прежней структуры дневника.'}
 foreach($entry in $entries){
  if(-not $entry -or $entry.FieldId -isnot [string] -or [string]::IsNullOrWhiteSpace($entry.FieldId)){throw 'Некорректный идентификатор сохранённого поля дневника.'}
  foreach($name in @('Marker','Label','Value','Detail')){if($entry.$name -isnot [string]){throw 'Некорректный текст сохранённого поля дневника.'}}
  if([string]::IsNullOrWhiteSpace($entry.Label) -or $entry.Override -isnot [bool]){throw 'Некорректное сохранённое поле прежней структуры дневника.'}
  [pscustomobject]@{FieldId=[string]$entry.FieldId;Marker=[string]$entry.Marker;Label=[string]$entry.Label;Value=[string]$entry.Value;Detail=[string]$entry.Detail;Override=[bool]$entry.Override}
 }
}
function Get-MedicalSharedDiarySchema {
 if(-not $script:medicalClinicalForms){[void](Initialize-MedicalClinicalWorkspace)}
 if(-not $script:medicalClinicalForms.DiaryForm){
  $copy=Copy-MedicalClinicalFormData $script:medicalClinicalForms
  $script:medicalClinicalForms | Add-Member -NotePropertyName DiaryForm -NotePropertyValue $copy.DiaryForm -Force
 }
 return (Copy-MedicalFormSchema $script:medicalClinicalForms.DiaryForm.Schema)
}
function ConvertTo-MedicalSharedDiaryPatient($oldDefinition,$oldPatient,$newSchema){
 $oldFields=@(Get-UniversalFields $oldDefinition.Schema);$newFields=@(Get-UniversalFields $newSchema)
 $oldById=@{};$oldByMarker=@{};$newMarkerCounts=@{};$used=@{};$mapping=@{}
 foreach($field in $oldFields){
  $oldById[[string]$field.Id]=$field;$marker=[string]$field.Marker
  if($marker){if(-not $oldByMarker.ContainsKey($marker)){$oldByMarker[$marker]=@()};$oldByMarker[$marker]+=@($field)}
 }
 foreach($field in $newFields){$marker=[string]$field.Marker;if($marker){if(-not $newMarkerCounts.ContainsKey($marker)){$newMarkerCounts[$marker]=0};$newMarkerCounts[$marker]++}}
 # Reserve all stable-ID matches first; marker matching cannot steal a field
 # that still has its own identifier in the new common form.
 foreach($field in $newFields){$id=[string]$field.Id;if($oldById.ContainsKey($id)){$mapping[$id]=$oldById[$id];$used[$id]=$true}}
 foreach($field in $newFields){
  $id=[string]$field.Id;$marker=[string]$field.Marker
  if(-not $mapping.ContainsKey($id) -and $marker -and $newMarkerCounts[$marker] -eq 1 -and $oldByMarker.ContainsKey($marker) -and @($oldByMarker[$marker]).Count -eq 1){
   $old=$oldByMarker[$marker][0];if(-not $used.ContainsKey([string]$old.Id)){$mapping[$id]=$old;$used[[string]$old.Id]=$true}
  }
 }
 $values=ConvertTo-MedicalClinicalMap $oldPatient.Values;$details=ConvertTo-MedicalClinicalMap $oldPatient.Details;$overrides=ConvertTo-MedicalClinicalMap $oldPatient.Overrides
 $newValues=@{};$newDetails=@{};$newOverrides=@{};$archive=@(Copy-MedicalArchivedDiaryFields $oldPatient.ArchivedFields)
 foreach($field in $newFields){
  $id=[string]$field.Id;if(-not $mapping.ContainsKey($id)){continue};$old=$mapping[$id];$oldId=[string]$old.Id
  if($values.ContainsKey($oldId)){$newValues[$id]=[string]$values[$oldId]}
  if($field.Type -eq 'choice_detail' -and $details.ContainsKey($oldId)){$newDetails[$id]=[string]$details[$oldId]}
  if($overrides[$oldId] -eq $true){$newOverrides[$id]=$true}
 }
 foreach($field in $oldFields){
  $id=[string]$field.Id;$value=[string]$values[$id];$detail=[string]$details[$id];$manual=($overrides[$id] -eq $true)
  $lost=(-not $used.ContainsKey($id))
  if(-not $lost -and -not [string]::IsNullOrWhiteSpace($detail)){
   $target=@($newFields | Where-Object {$mapping.ContainsKey([string]$_.Id) -and [string]$mapping[[string]$_.Id].Id -eq $id})
   $lost=($target.Count -ne 1 -or $target[0].Type -ne 'choice_detail')
  }
  if($lost -and (-not [string]::IsNullOrWhiteSpace($value) -or -not [string]::IsNullOrWhiteSpace($detail) -or $manual)){
   $archive+=@([pscustomobject]@{FieldId=$id;Marker=[string]$field.Marker;Label=[string]$field.Label;Value=$value;Detail=$detail;Override=$manual})
  }
 }
 $patient=Copy-UniversalObject $oldPatient
 $patient.Values=$newValues;$patient.Details=$newDetails;$patient.Overrides=$newOverrides
 $patient | Add-Member -NotePropertyName ArchivedFields -NotePropertyValue @($archive) -Force
 return $patient
}
function Get-MedicalSharedDiaryLinks($schema,$links,$initial=$script:universalConfig){
 # Reusable diaries start with fresh clinical answers. Only patient identity
 # may follow the primary examination automatically; an old matching clinical
 # field ID is structure, not permission to copy that patient's prior answer.
 $sourceLinks=ConvertTo-MedicalClinicalMap $links;$allowed=@{}
 foreach($field in Get-UniversalFields $schema){
  $id=[string]$field.Id
  if(-not $sourceLinks.ContainsKey($id)){continue}
  $source=Get-MedicalClinicalField $initial ([string]$sourceLinks[$id])
  if($source -and [string]$source.System -in @('name','birth','address')){$allowed[$id]=[string]$source.Id}
 }
 return $allowed
}
function Set-MedicalSharedDiaryFormData($forms,$schema,$initial=$script:universalConfig){
 $copy=Copy-MedicalClinicalFormData $forms;$candidate=Copy-MedicalFormSchema $schema
 $links=Get-MedicalClinicalDefaultLinks $candidate $initial
 $oldCommon=ConvertTo-MedicalClinicalMap $copy.DiaryForm.Links
 foreach($field in Get-UniversalFields $candidate){$id=[string]$field.Id;if($oldCommon.ContainsKey($id)){$links[$id]=[string]$oldCommon[$id]}}
 $links=Get-MedicalSharedDiaryLinks $candidate $links $initial
 $copy.DiaryForm=[pscustomobject]@{Schema=(Copy-MedicalFormSchema $candidate);Links=$links}
 foreach($definition in @($copy.Diaries)){$definition.Schema=Copy-MedicalFormSchema $candidate;$definition.Links=ConvertTo-MedicalClinicalMap $links}
 return (Copy-MedicalClinicalFormData $copy)
}
function Set-MedicalSharedDiarySchema($schema){
 # Build and validate both candidates before publishing either. Every patient
 # diary keeps its own identity, period, answers and manual link overrides.
 $candidateSchema=Copy-MedicalFormSchema $schema
 if(-not $script:medicalClinicalForms){[void](Initialize-MedicalClinicalWorkspace)}
 $forms=Copy-MedicalClinicalFormData $script:medicalClinicalForms
 $state=Copy-MedicalClinicalPatientState $script:medicalClinicalState $forms
 $oldForms=$forms
 $forms=Set-MedicalSharedDiaryFormData $forms $candidateSchema
 $oldDefinitions=@{};$statePositions=@{}
 foreach($entry in @($oldForms.Diaries)){$oldDefinitions[[string]$entry.Id]=$entry}
 for($i=0;$i -lt $state.Diaries.Count;$i++){$statePositions[[string]$state.Diaries[$i].Id]=$i}
 for($i=0;$i -lt $forms.Diaries.Count;$i++){
  $definition=$forms.Diaries[$i];$id=[string]$definition.Id
  if(-not $statePositions.ContainsKey($id) -or -not $oldDefinitions.ContainsKey($id)){throw 'Ответы дневника не соответствуют общей форме.'}
  $position=[int]$statePositions[$id];$oldDefinition=$oldDefinitions[$id]
  $migrated=ConvertTo-MedicalSharedDiaryPatient $oldDefinition $state.Diaries[$position] $candidateSchema
  # A newly introduced automatic link must not overwrite an existing answer
  # from a legacy standalone diary merely because its field now has a link.
  foreach($field in Get-UniversalFields $candidateSchema){
   $fieldId=[string]$field.Id
   if($definition.Links.ContainsKey($fieldId) -and $migrated.Values.ContainsKey($fieldId) -and (-not $oldDefinition.Links.ContainsKey($fieldId) -or [string]$oldDefinition.Links[$fieldId] -cne [string]$definition.Links[$fieldId])){$migrated.Overrides[$fieldId]=$true}
  }
  $state.Diaries[$position]=$migrated
 }
 $forms=Copy-MedicalClinicalFormData $forms;$state=Copy-MedicalClinicalPatientState $state $forms
 $script:medicalClinicalForms=$forms;$script:medicalClinicalState=$state
 $script:medicalClinicalFieldIndexes=@{};$script:medicalClinicalBindingIndex=$null
 return (Get-MedicalSharedDiarySchema)
}
function Copy-MedicalClinicalFormData($source){
 if(-not $source -or [int]$source.Version -ne 1){throw 'Неизвестный формат структуры дневников и эпикриза.'}
 $result=[pscustomobject]@{Version=1;DiaryForm=$null;Diaries=@();Discharge=$null};$ids=@{}
 foreach($entry in @($source.Diaries)){
  if(-not $entry){continue}
  $id=[string]$entry.Id
  if($entry.Id -isnot [string] -or [string]::IsNullOrWhiteSpace($id) -or $id.Length -gt 200 -or $ids.ContainsKey($id)){throw 'Повтор или отсутствие строкового идентификатора дневника.'}
  $ids[$id]=$true;$schema=Copy-MedicalFormSchema $entry.Schema
  $title=([string]$entry.Title).Trim();if(-not $title){throw 'Укажите название дневника.'}
  $links=ConvertTo-MedicalClinicalMap $entry.Links;$allowed=@{}
  foreach($field in Get-UniversalFields $schema){
   $fieldId=[string]$field.Id
   if($links.ContainsKey($fieldId) -and -not [string]::IsNullOrWhiteSpace([string]$links[$fieldId])){$allowed[$fieldId]=[string]$links[$fieldId]}
  }
  $result.Diaries+=@([pscustomobject]@{Id=$id;Title=$title;Schema=$schema;Links=$allowed;DateCount=(Get-MedicalClinicalDiaryDateCount $entry)})
 }
 # Old Version 1 forms kept a schema on every diary. Seed only the reusable
 # default from the last entry; retain heterogeneous legacy entries until an
 # explicit edit of the common form migrates them together.
 $common=$source.DiaryForm
 if(-not $common -and $result.Diaries.Count){$common=$result.Diaries[-1]}
 if($common){$result.DiaryForm=Copy-MedicalSharedDiaryDefinition $common}
 else{$schema=New-MedicalDiarySchema;$result.DiaryForm=[pscustomobject]@{Schema=$schema;Links=(Get-MedicalClinicalDefaultLinks $schema)}}
 if($source.Discharge){
  $schema=Copy-MedicalFormSchema $source.Discharge.Schema;$links=ConvertTo-MedicalClinicalMap $source.Discharge.Links;$allowed=@{}
  foreach($field in Get-UniversalFields $schema){
   $id=[string]$field.Id
   if($links.ContainsKey($id) -and -not [string]::IsNullOrWhiteSpace([string]$links[$id])){$allowed[$id]=[string]$links[$id]}
  }
  $result.Discharge=[pscustomobject]@{Schema=$schema;Links=$allowed}
  if($source.Discharge.FollowInitialSchema -eq $true){
   if($source.Discharge.FollowInitialSchema -isnot [bool] -or [string]$source.Discharge.InitialSchemaSignature -cnotmatch '^[a-f0-9]{64}$'){throw 'Некорректная связь структуры эпикриза с первичным осмотром.'}
   $generated=ConvertTo-MedicalClinicalMap $source.Discharge.GeneratedFieldIds;$fieldIds=@{};foreach($field in Get-UniversalFields $schema){$fieldIds[[string]$field.Id]=$true}
   $safeGenerated=@{};foreach($category in @('final_diagnosis','examination_results','treatment_results','recommendations')){if($generated[$category] -isnot [string] -or -not $fieldIds.ContainsKey([string]$generated[$category])){throw 'Некорректный идентификатор итогового поля эпикриза.'};$safeGenerated[$category]=[string]$generated[$category]}
   $result.Discharge | Add-Member -NotePropertyName FollowInitialSchema -NotePropertyValue $true
   $result.Discharge | Add-Member -NotePropertyName InitialSchemaSignature -NotePropertyValue ([string]$source.Discharge.InitialSchemaSignature)
   $result.Discharge | Add-Member -NotePropertyName GeneratedFieldIds -NotePropertyValue $safeGenerated
  }
 }
 return $result
}
function New-MedicalClinicalPatientState($forms){
 $state=[pscustomobject]@{Version=1;Diaries=@();Discharge=[pscustomobject]@{Values=@{};Details=@{};Overrides=@{}};TreatmentPeriod=(New-MedicalTreatmentPeriod)}
 foreach($entry in @($forms.Diaries)){
  $stamp=[datetime]::Now.ToString('yyyy-MM-ddTHH:mm:ss')
  $state.Diaries+=@([pscustomobject]@{Id=[string]$entry.Id;DateTime=$stamp;EndDateTime=$stamp;DateIsAutomatic=$true;Values=@{};Details=@{};Overrides=@{};ArchivedFields=@()})
 }
 return $state
}
function New-MedicalClinicalFormData($initial=$script:universalConfig){
 $discharge=New-MedicalDischargeSchema $initial
 $diary=New-MedicalDiarySchema $initial
 $candidate=[pscustomobject]@{Version=1;DiaryForm=[pscustomobject]@{Schema=$diary;Links=(Get-MedicalClinicalDefaultLinks $diary $initial)};Diaries=@();Discharge=[pscustomobject]@{Schema=$discharge;Links=(Get-MedicalClinicalDefaultLinks $discharge $initial $true);FollowInitialSchema=$true;InitialSchemaSignature=(Get-MedicalClinicalInitialSignature $initial);GeneratedFieldIds=(Get-MedicalDischargeGeneratedFieldIds $discharge)}}
 return (Copy-MedicalClinicalFormData $candidate)
}
function Initialize-MedicalClinicalWorkspace($stageForms=$null){
 if($null -ne $stageForms){$candidate=Resolve-MedicalClinicalPortableForms $stageForms}
 else{$candidate=New-MedicalClinicalFormData $script:universalConfig}
 $script:medicalClinicalForms=Copy-MedicalClinicalFormData $candidate
 $script:medicalClinicalState=New-MedicalClinicalPatientState $script:medicalClinicalForms
 return $script:medicalClinicalForms
}
function Get-MedicalClinicalFormData {
 if(-not $script:medicalClinicalForms){[void](Initialize-MedicalClinicalWorkspace)}
 Sync-MedicalDischargeSchemaFromInitial $true
 return (Copy-MedicalClinicalFormData $script:medicalClinicalForms)
}
function Restore-MedicalClinicalFormData($forms){
 $candidate=Resolve-MedicalClinicalPortableForms $forms
 $script:medicalClinicalForms=Copy-MedicalClinicalFormData $candidate
 $script:medicalClinicalState=New-MedicalClinicalPatientState $script:medicalClinicalForms
}
function Get-MedicalClinicalState {
 if(-not $script:medicalClinicalForms){[void](Initialize-MedicalClinicalWorkspace)}
 foreach($entry in @($script:medicalClinicalForms.Diaries)){
  $binding=Get-MedicalClinicalBinding 'diary' ([string]$entry.Id);Sync-MedicalClinicalLinks $binding.Definition $binding.State
 }
 Sync-MedicalDischargeFromInitial
 [void](Get-MedicalTreatmentPeriod)
 return (Copy-UniversalObject $script:medicalClinicalState)
}
function Copy-MedicalClinicalPatientState($source,$forms){
 if(-not $source){return (New-MedicalClinicalPatientState $forms)}
 if([int]$source.Version -ne 1){throw 'Неизвестная версия ответов дневников и эпикриза.'}
 $forms=Copy-MedicalClinicalFormData $forms;$candidate=New-MedicalClinicalPatientState $forms;$seen=@{}
 $candidate.TreatmentPeriod=Copy-MedicalTreatmentPeriod $source.TreatmentPeriod
 foreach($entry in @($source.Diaries)){
  if(-not $entry){continue}
  $id=[string]$entry.Id
  if($entry.Id -isnot [string] -or -not $id -or $seen.ContainsKey($id)){throw 'Повтор или отсутствие строкового идентификатора ответов дневника.'};$seen[$id]=$true
  $definition=@($forms.Diaries | Where-Object {[string]$_.Id -eq $id})
  if(-not $definition.Count){throw 'Ответы дневника не соответствуют структуре текущей формы.'}
  $target=@($candidate.Diaries | Where-Object {[string]$_.Id -eq $id})[0]
  $date=[datetime]::MinValue
  if($entry.DateTime -is [datetime]){$date=[datetime]$entry.DateTime}
  elseif(-not [datetime]::TryParseExact([string]$entry.DateTime,'yyyy-MM-ddTHH:mm:ss',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$date)){throw 'Некорректная дата дневника.'}
  if($date -lt [datetime]'1753-01-01' -or $date -gt [datetime]'9998-12-31'){throw 'Дата дневника находится вне допустимого диапазона календаря.'}
  $target.DateTime=$date.ToString('yyyy-MM-ddTHH:mm:ss')
  $end=$date
  if($entry.PSObject.Properties['EndDateTime']){
   if($entry.EndDateTime -is [datetime]){$end=[datetime]$entry.EndDateTime}
   elseif(-not [datetime]::TryParseExact([string]$entry.EndDateTime,'yyyy-MM-ddTHH:mm:ss',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$end)){throw 'Некорректная дата окончания дневника.'}
   if($end -lt $date -or $end -gt [datetime]'9998-12-31'){throw 'Дата окончания дневника должна быть не раньше даты начала и находиться в допустимом диапазоне.'}
  }
  $target.EndDateTime=$end.ToString('yyyy-MM-ddTHH:mm:ss')
  $automatic=$false
  if($entry.PSObject.Properties['DateIsAutomatic']){if($entry.DateIsAutomatic -isnot [bool]){throw 'Некорректный признак автоматической даты дневника.'};$automatic=[bool]$entry.DateIsAutomatic}
  $target.DateIsAutomatic=$automatic
  $target.ArchivedFields=@(Copy-MedicalArchivedDiaryFields $entry.ArchivedFields)
  $target.Values=Copy-MedicalClinicalValues $entry.Values $definition[0].Schema
  $target.Details=Copy-MedicalClinicalValues $entry.Details $definition[0].Schema $true
  $overrides=ConvertTo-MedicalClinicalMap $entry.Overrides;$target.Overrides=@{}
  foreach($field in Get-UniversalFields $definition[0].Schema){if($overrides[[string]$field.Id] -eq $true){$target.Overrides[[string]$field.Id]=$true}}
 }
 if($forms.Discharge -and $source.Discharge){
  $candidate.Discharge.Values=Copy-MedicalClinicalValues $source.Discharge.Values $forms.Discharge.Schema
  $candidate.Discharge.Details=Copy-MedicalClinicalValues $source.Discharge.Details $forms.Discharge.Schema $true
  $overrides=ConvertTo-MedicalClinicalMap $source.Discharge.Overrides
  foreach($field in Get-UniversalFields $forms.Discharge.Schema){if($overrides[[string]$field.Id] -eq $true){$candidate.Discharge.Overrides[[string]$field.Id]=$true}}
 }
 return $candidate
}
function Test-MedicalClinicalState($source,$forms){
 [void](Copy-MedicalClinicalPatientState $source $forms)
}
function Restore-MedicalClinicalState($source){
 if(-not $source){return}
 $candidate=Copy-MedicalClinicalPatientState $source (Get-MedicalClinicalFormData)
 $script:medicalClinicalState=$candidate
 Sync-MedicalDischargeFromInitial
}
# These lookups are used for every keystroke. They deliberately do not copy
# schemas, inspect Word files or synchronize unrelated clinical stages.
function Get-MedicalClinicalField($schema,[string]$id){
 if(-not $schema){return $null}
 if(-not $script:medicalClinicalFieldIndexes){$script:medicalClinicalFieldIndexes=@{}}
 $key=[Runtime.CompilerServices.RuntimeHelpers]::GetHashCode($schema)
 $index=$script:medicalClinicalFieldIndexes[$key]
 if($index -and [object]::ReferenceEquals($index.Schema,$schema) -and $index.Fields.ContainsKey($id)){
  $slot=$index.Fields[$id]
  if($slot.SectionIndex -lt $schema.Sections.Count -and [object]::ReferenceEquals($schema.Sections[$slot.SectionIndex],$slot.Section) -and $slot.FieldIndex -lt $slot.Section.Fields.Count -and [object]::ReferenceEquals($slot.Section.Fields[$slot.FieldIndex],$slot.Field) -and [string]$slot.Field.Id -ceq $id){return $slot.Field}
 }
 if($script:medicalClinicalFieldIndexes.Count -gt 255){$script:medicalClinicalFieldIndexes=@{}}
 $fields=@{};$sectionIndex=0
 foreach($section in $schema.Sections){
  $fieldIndex=0
  foreach($field in $section.Fields){
   $fieldId=[string]$field.Id
   if($fields.ContainsKey($fieldId)){throw 'Повтор идентификатора поля в текущем этапе.'}
   $fields[$fieldId]=[pscustomobject]@{SectionIndex=$sectionIndex;Section=$section;FieldIndex=$fieldIndex;Field=$field}
   $fieldIndex++
  }
  $sectionIndex++
 }
 $script:medicalClinicalFieldIndexes[$key]=[pscustomobject]@{Schema=$schema;Fields=$fields}
 if($fields.ContainsKey($id)){return $fields[$id].Field}
 return $null
}
function Get-MedicalClinicalBinding([string]$stage,[string]$id=''){
 if(-not $script:medicalClinicalForms){[void](Initialize-MedicalClinicalWorkspace)}
 if($stage -eq 'diary'){
  $definitions=$script:medicalClinicalForms.Diaries;$states=$script:medicalClinicalState.Diaries;$index=$script:medicalClinicalBindingIndex
  if($index -and [object]::ReferenceEquals($index.Definitions,$definitions) -and [object]::ReferenceEquals($index.States,$states) -and $index.DefinitionCount -eq $definitions.Count -and $index.StateCount -eq $states.Count -and $index.Bindings.ContainsKey($id)){
   $slot=$index.Bindings[$id]
   if([object]::ReferenceEquals($definitions[$slot.DefinitionIndex],$slot.Binding.Definition) -and [object]::ReferenceEquals($states[$slot.StateIndex],$slot.Binding.State) -and [string]$slot.Binding.Definition.Id -eq $id -and [string]$slot.Binding.State.Id -eq $id){return $slot.Binding}
  }
  $definitionMap=@{};$stateMap=@{};$position=0
  foreach($entry in $definitions){$entryId=[string]$entry.Id;if($definitionMap.ContainsKey($entryId)){throw 'Повтор идентификатора дневника в текущей форме.'};$definitionMap[$entryId]=[pscustomobject]@{Entry=$entry;Position=$position};$position++}
  $position=0;foreach($entry in $states){$entryId=[string]$entry.Id;if($stateMap.ContainsKey($entryId)){throw 'Повтор идентификатора ответов дневника в текущей карте.'};$stateMap[$entryId]=[pscustomobject]@{Entry=$entry;Position=$position};$position++}
  $bindings=@{}
  foreach($entryId in $definitionMap.Keys){
   if($stateMap.ContainsKey($entryId)){$bindings[$entryId]=[pscustomobject]@{DefinitionIndex=$definitionMap[$entryId].Position;StateIndex=$stateMap[$entryId].Position;Binding=[pscustomobject]@{Definition=$definitionMap[$entryId].Entry;State=$stateMap[$entryId].Entry}}}
  }
  $script:medicalClinicalBindingIndex=[pscustomobject]@{Definitions=$definitions;States=$states;DefinitionCount=$definitions.Count;StateCount=$states.Count;Bindings=$bindings}
  if(-not $bindings.ContainsKey($id)){throw 'Дневник не найден в текущей форме.'}
  return $bindings[$id].Binding
 }
 if($stage -eq 'discharge' -and $script:medicalClinicalForms.Discharge){return [pscustomobject]@{Definition=$script:medicalClinicalForms.Discharge;State=$script:medicalClinicalState.Discharge}}
 throw 'Выберите дневник или выписной эпикриз.'
}
function Sync-MedicalClinicalLinks($definition,$state){
 $values=$script:universalValues;$details=$script:universalDetails;$displayValues=$null
 foreach($targetId in @($definition.Links.Keys)){
  if($state.Overrides.ContainsKey([string]$targetId)){continue}
  $sourceId=[string]$definition.Links[$targetId]
  $source=Get-MedicalClinicalField $script:universalConfig $sourceId
  if(-not $source){continue}
  $target=Get-MedicalClinicalField $definition.Schema ([string]$targetId)
  if($target -and $target.Type -ne $source.Type){
   if($null -eq $displayValues){$displayValues=Get-UniversalExportValues $script:universalConfig $values $details}
   $state.Values[[string]$targetId]=[string]$displayValues[$sourceId]
  }else{$state.Values[[string]$targetId]=[string]$values[$sourceId]}
  if($target -and $target.Type -eq 'choice_detail'){$state.Details[[string]$targetId]=[string]$details[$sourceId]}
 }
}
function Sync-MedicalDischargeFromInitial {
 Sync-MedicalDischargeSchemaFromInitial
 if($script:medicalClinicalForms -and $script:medicalClinicalForms.Discharge){Sync-MedicalClinicalLinks $script:medicalClinicalForms.Discharge $script:medicalClinicalState.Discharge}
}
function Get-MedicalClinicalContext([string]$stage,[string]$id=''){
 if($stage -eq 'discharge'){Sync-MedicalDischargeSchemaFromInitial}
 $binding=Get-MedicalClinicalBinding $stage $id
 Sync-MedicalClinicalLinks $binding.Definition $binding.State
 $date=[datetime]::Now
 if($stage -eq 'diary'){$date=[datetime]::ParseExact([string]$binding.State.DateTime,'yyyy-MM-ddTHH:mm:ss',[Globalization.CultureInfo]::InvariantCulture)}
 elseif($script:admissionControl){$date=$script:admissionControl.Value}
 $title=if($stage -eq 'diary'){[string]$binding.Definition.Title}else{'Выписной эпикриз'}
 $dateCount=1;$end=$date
 if($stage -eq 'diary'){
  $dateCount=Get-MedicalClinicalDiaryDateCount $binding.Definition
  if($binding.State.PSObject.Properties['EndDateTime']){$end=[datetime]::ParseExact([string]$binding.State.EndDateTime,'yyyy-MM-ddTHH:mm:ss',[Globalization.CultureInfo]::InvariantCulture)}
 }
 return [pscustomobject]@{Id=$id;Title=$title;Schema=$binding.Definition.Schema;Values=$binding.State.Values;Details=$binding.State.Details;DateTime=$date;DateCount=$dateCount;EndDateTime=$end;DateIsAutomatic=($binding.State.DateIsAutomatic -eq $true);Links=$binding.Definition.Links;Overrides=$binding.State.Overrides;ArchivedFields=@(Copy-MedicalArchivedDiaryFields $binding.State.ArchivedFields)}
}
function Get-MedicalClinicalDiaryContexts {
 if(-not $script:medicalClinicalForms){[void](Initialize-MedicalClinicalWorkspace)}
 foreach($entry in @($script:medicalClinicalForms.Diaries)){Get-MedicalClinicalContext 'diary' ([string]$entry.Id)}
}
function Add-MedicalClinicalDiary($schema=$null,[string]$title=''){
 if(-not $script:medicalClinicalForms){[void](Initialize-MedicalClinicalWorkspace)}
 $usesCommon=($null -eq $schema)
 if($usesCommon){$schema=Get-MedicalSharedDiarySchema}
 $schema=Copy-MedicalFormSchema $schema;$id=[guid]::NewGuid().ToString('N')
 if([string]::IsNullOrWhiteSpace($title)){$title='Дневник наблюдения №'+(@($script:medicalClinicalForms.Diaries).Count+1)}
 $dateCount=1;if(@($script:medicalClinicalForms.Diaries).Count){$dateCount=Get-MedicalClinicalDiaryDateCount $script:medicalClinicalForms.Diaries[-1]}
 $links=Get-MedicalClinicalDefaultLinks $schema
 if($usesCommon){$links=Get-MedicalSharedDiaryLinks $schema $script:medicalClinicalForms.DiaryForm.Links}
 $definition=[pscustomobject]@{Id=$id;Title=$title.Trim();Schema=$schema;Links=$links;DateCount=$dateCount}
 $script:medicalClinicalForms.Diaries+=@($definition)
 $stamp=[datetime]::Now.ToString('yyyy-MM-ddTHH:mm:ss')
 $script:medicalClinicalState.Diaries+=@([pscustomobject]@{Id=$id;DateTime=$stamp;EndDateTime=$stamp;DateIsAutomatic=$true;Values=@{};Details=@{};Overrides=@{};ArchivedFields=@()})
 return (Get-MedicalClinicalContext 'diary' $id)
}
function Remove-MedicalClinicalDiary([string]$id){
 [void](Get-MedicalClinicalBinding 'diary' $id)
 $script:medicalClinicalForms.Diaries=@($script:medicalClinicalForms.Diaries | Where-Object {[string]$_.Id -ne $id})
 $script:medicalClinicalState.Diaries=@($script:medicalClinicalState.Diaries | Where-Object {[string]$_.Id -ne $id})
 for($i=0;$i -lt $script:medicalClinicalForms.Diaries.Count;$i++){if([string]$script:medicalClinicalForms.Diaries[$i].Title -cmatch '^Дневник наблюдения №[0-9]+$'){$script:medicalClinicalForms.Diaries[$i].Title='Дневник наблюдения №'+($i+1)}}
 $script:medicalClinicalBindingIndex=$null;$script:medicalClinicalFieldIndexes=@{}
}
function Set-MedicalClinicalDate([string]$id,[datetime]$date){
 $binding=Get-MedicalClinicalBinding 'diary' $id;$stamp=$date.ToString('yyyy-MM-ddTHH:mm:ss')
 if([string]$binding.State.DateTime -cne $stamp){
  $old=[string]$binding.State.DateTime;$end=$old
  if($binding.State.PSObject.Properties['EndDateTime']){$end=[string]$binding.State.EndDateTime}
  if($end -ceq $old -or [datetime]::ParseExact($end,'yyyy-MM-ddTHH:mm:ss',[Globalization.CultureInfo]::InvariantCulture) -lt $date){$end=$stamp}
  $binding.State.DateTime=$stamp;$binding.State | Add-Member -NotePropertyName EndDateTime -NotePropertyValue $end -Force
  $binding.State | Add-Member -NotePropertyName DateIsAutomatic -NotePropertyValue $false -Force
 }
}
function Set-MedicalClinicalValue([string]$stage,[string]$id,[string]$fieldId,[string]$value,$detailValue=$null){
 $binding=Get-MedicalClinicalBinding $stage $id
 $field=Get-MedicalClinicalField $binding.Definition.Schema $fieldId
 if(-not $field){throw 'Поле не найдено в текущем этапе.'}
 $newDetail=if($null -eq $detailValue){[string]$binding.State.Details[$fieldId]}else{[string]$detailValue}
 if($binding.Definition.Links.ContainsKey($fieldId)){
  $sourceId=[string]$binding.Definition.Links[$fieldId]
  $sourceField=Get-MedicalClinicalField $script:universalConfig $sourceId
  $sourceValue=[string]$script:universalValues[$sourceId]
  if($sourceField -and $field.Type -ne $sourceField.Type){$sourceValues=Get-UniversalExportValues $script:universalConfig $script:universalValues $script:universalDetails;$sourceValue=[string]$sourceValues[$sourceId]}
  if($value -cne $sourceValue -or ($field.Type -eq 'choice_detail' -and $newDetail -cne [string]$script:universalDetails[$sourceId])){$binding.State.Overrides[$fieldId]=$true}
 }
 $binding.State.Values[$fieldId]=$value
 if($field.Type -eq 'choice_detail'){$binding.State.Details[$fieldId]=$newDetail}
}
function Reset-MedicalClinicalLink([string]$stage,[string]$id,[string]$fieldId){
 $binding=Get-MedicalClinicalBinding $stage $id
 if(-not $binding.Definition.Links.ContainsKey($fieldId)){throw 'Это поле не связано с первичным осмотром.'}
 $binding.State.Overrides.Remove($fieldId);Sync-MedicalClinicalLinks $binding.Definition $binding.State
}
function Set-MedicalClinicalSchema([string]$stage,[string]$id,$schema,[string]$title=''){
 $candidate=Copy-MedicalFormSchema $schema;$binding=Get-MedicalClinicalBinding $stage $id
 $values=Copy-MedicalClinicalValues $binding.State.Values $candidate
 $details=Copy-MedicalClinicalValues $binding.State.Details $candidate $true
 $links=Get-MedicalClinicalDefaultLinks $candidate $script:universalConfig ($stage -eq 'discharge')
 foreach($field in Get-UniversalFields $candidate){
  $fieldId=[string]$field.Id
  if($binding.Definition.Links.ContainsKey($fieldId)){$links[$fieldId]=[string]$binding.Definition.Links[$fieldId]}
 }
 $binding.Definition.Schema=$candidate;$binding.Definition.Links=$links
 if($stage -eq 'discharge'){$binding.Definition | Add-Member -NotePropertyName FollowInitialSchema -NotePropertyValue $false -Force}
 if($stage -eq 'diary' -and -not [string]::IsNullOrWhiteSpace($title)){$binding.Definition.Title=$title.Trim()}
 $binding.State.Values=$values;$binding.State.Details=$details
 $overrides=@{};foreach($field in Get-UniversalFields $candidate){if($binding.State.Overrides.ContainsKey([string]$field.Id)){$overrides[[string]$field.Id]=$true}}
 $binding.State.Overrides=$overrides
 Sync-MedicalClinicalLinks $binding.Definition $binding.State
 return (Get-MedicalClinicalContext $stage $id)
}
function Get-MedicalClinicalExportValues([string]$stage,[string]$id=''){
 if($stage -eq 'discharge'){Sync-MedicalDischargeSchemaFromInitial $true}
 $context=Get-MedicalClinicalContext $stage $id
 return (Get-UniversalExportValues $context.Schema $context.Values $context.Details)
}

# Portable structure snapshots use the same checked template envelope as .mcform.
# Missing Word files may be retained in a recovery snapshot without blocking data.
function Get-MedicalClinicalPortableForms([bool]$allowMissing=$false,$forms=$null){
 if($null -eq $forms){$forms=Get-MedicalClinicalFormData}
 $copy=Copy-MedicalClinicalFormData $forms
 $definitions=@($copy.DiaryForm)+@($copy.Diaries);if($copy.Discharge){$definitions+=@($copy.Discharge)}
 foreach($definition in $definitions){
  try{
   $asset=Get-MedicalFormTemplateAsset $definition.Schema
   foreach($property in @('TemplateName','TemplateSha256','TemplateBase64')){$definition | Add-Member -NotePropertyName $property -NotePropertyValue $asset.$property -Force}
   $definition.Schema.Template='Шаблоны/'+$asset.TemplateName
  }catch{if(-not $allowMissing){throw};$definition | Add-Member -NotePropertyName TemplateMissing -NotePropertyValue $true -Force}
 }
 return $copy
}
function Resolve-MedicalClinicalPortableForms($forms){
 $copy=Copy-MedicalClinicalFormData $forms
 $commonSource=$forms.DiaryForm
 if(-not $commonSource -and @($forms.Diaries).Count){$commonSource=@($forms.Diaries)[-1]}
 $original=@($commonSource)+@($forms.Diaries);$definitions=@($copy.DiaryForm)+@($copy.Diaries)
 if($forms.Discharge){$original+=@($forms.Discharge);$definitions+=@($copy.Discharge)}
 $assets=@()
 for($i=0;$i -lt $original.Count;$i++){
  $source=$original[$i]
  if($source -and $source.PSObject.Properties['TemplateBase64']){$assets+=@(Test-MedicalFormTemplateAsset $source)}else{$assets+=@($null)}
 }
 # Validate every schema and every hash before importing even the first template.
 for($i=0;$i -lt $definitions.Count;$i++){
  if($assets[$i]){
   $template=Import-MedicalTemplateBytes $assets[$i].Bytes $assets[$i].TemplateName
   $definitions[$i].Schema.Template=$template.RelativePath
  }
 }
 return $copy
}

function Test-MedicalClinicalPortableForms($forms,[bool]$requireAssets=$false){
 [void](Copy-MedicalClinicalFormData $forms)
 $definitions=@($forms.Diaries);if($forms.DiaryForm){$definitions=@($forms.DiaryForm)+$definitions};if($forms.Discharge){$definitions+=@($forms.Discharge)}
 foreach($definition in $definitions){
  if($definition.PSObject.Properties['TemplateBase64']){[void](Test-MedicalFormTemplateAsset $definition)}
  elseif($requireAssets){throw 'В сохранённой форме отсутствует Word-шаблон дневника или эпикриза.'}
 }
}

# Legacy stages stored positional arrays. Read every main-document SDT in its
# original XML order; aliases/IDs are metadata, never hints for clinical meaning.
function Get-MedicalLegacyClinicalProperty($source,[string]$name){
 if($source -is [Collections.IDictionary]){return $source[$name]}
 if($null -ne $source){return $source.$name}
 return $null
}
function New-MedicalLegacyClinicalStage([string]$templatePath,$saved,[string]$title,[string]$prefix,$baseSchema=$null){
 $saved=@($saved);$fields=@();$values=@{};$sourceBytes=$null;$xml=$null;$n=$null;$controls=@()
 if(-not [string]::IsNullOrWhiteSpace($templatePath)){
  $path=$templatePath.Replace('\',[IO.Path]::DirectorySeparatorChar)
  if(-not [IO.Path]::IsPathRooted($path)){$path=Join-Path $script:medicalProgramRoot $path}
  if([IO.File]::Exists($path)){
   try{
    $sourceBytes=[IO.File]::ReadAllBytes($path);Test-MedicalTemplateBytes $sourceBytes
    $archive=[IO.Compression.ZipFile]::OpenRead($path)
    try{$xml=Get-XmlPart $archive 'word/document.xml'}finally{$archive.Dispose()}
    $n=[Xml.XmlNamespaceManager]::new($xml.NameTable);$n.AddNamespace('w',$script:ns)
    $controls=@($xml.SelectNodes('//w:sdt',$n))
   }catch{$sourceBytes=$null;$xml=$null;$n=$null;$controls=@()}
  }
 }
 $schema=if($null -eq $baseSchema){[pscustomobject]@{Version=49;AutoTemplate=$true;Template=($title+'.docx');DocumentTitle=$title;DateTimeLabel='Дата и время записи';PreserveTemplateFormatting=$true;Sections=@()}}else{Copy-MedicalFormSchema $baseSchema}
 $ids=@{};$markers=@{};$wordIds=@{}
 foreach($field in Get-UniversalFields $schema){$ids[[string]$field.Id]=$true;$markers[[string]$field.Marker]=$true;if($field.DetailMarker){$markers[[string]$field.DetailMarker]=$true};if($field.WordId){$wordIds[[string]$field.WordId]=$true}}
 $count=[Math]::Max($saved.Count,$controls.Count)
 for($i=0;$i -lt $count;$i++){
  $number=$i+1;$fieldId=$prefix+'_'+$number;$marker=($prefix.ToUpperInvariant()+'_'+$number)
  while($ids.ContainsKey($fieldId)){$fieldId+='x'};while($markers.ContainsKey($marker)){$marker+='_X'}
  $ids[$fieldId]=$true;$markers[$marker]=$true
  $label='Поле прежней карты '+$number;$options=@();$wordId=''
  if($i -lt $controls.Count){
   $control=$controls[$i];$properties=$control.SelectSingleNode('./w:sdtPr',$n)
   if(-not $properties){$properties=$xml.CreateElement('w','sdtPr',$script:ns);[void]$control.PrependChild($properties)}
   $alias=$properties.SelectSingleNode('./w:alias',$n);$tag=$properties.SelectSingleNode('./w:tag',$n)
   if($alias -and -not [string]::IsNullOrWhiteSpace($alias.GetAttribute('val',$script:ns))){$label=$alias.GetAttribute('val',$script:ns)}
   elseif($tag -and -not [string]::IsNullOrWhiteSpace($tag.GetAttribute('val',$script:ns))){$label=$tag.GetAttribute('val',$script:ns)}
   foreach($option in $properties.SelectNodes('.//w:listItem',$n)){$text=$option.GetAttribute('displayText',$script:ns);if(-not $text){$text=$option.GetAttribute('value',$script:ns)};if($text -and $text -ne 'Выберите элемент.'){$options+=@($text)}}
   $idNode=$properties.SelectSingleNode('./w:id',$n)
   if($idNode){$wordId=$idNode.GetAttribute('val',$script:ns)}
   if(-not $wordId -or $wordIds.ContainsKey($wordId)){
    $sequence=1000000000+$number;while($wordIds.ContainsKey([string]$sequence)){$sequence++};$wordId=[string]$sequence
    if(-not $idNode){$idNode=$xml.CreateElement('w','id',$script:ns);[void]$properties.AppendChild($idNode)}
    [void]$idNode.SetAttribute('val',$script:ns,$wordId)
   }
   $wordIds[$wordId]=$true
   # The portable form contains an unfilled source, not the saved answers.
   Set-UniversalControlValue $control '' $n
  }
  $type=if($options.Count){'choice'}else{'multiline'}
  $field=New-UniversalField $fieldId $label $marker $type;$field.Required=$false;$field.Options=$options;$field.WordId=$wordId
  $fields+=@($field)
  if($i -lt $saved.Count){$values[$fieldId]=[string]$saved[$i]}else{$values[$fieldId]=''}
 }
 if($fields.Count){
  $sectionId=$prefix;while(@($schema.Sections | Where-Object {[string]$_.Id -eq $sectionId}).Count){$sectionId+='x'}
  $schema.Sections+=@([pscustomobject]@{Id=$sectionId;Title='Поля прежней карты';Fields=$fields})
 }
 if($xml){
  $body=$xml.SelectSingleNode('/w:document/w:body',$n);$sectionProperties=$body.SelectSingleNode('./w:sectPr',$n)
  $allText=(($xml.SelectNodes('//w:t',$n) | ForEach-Object {$_.InnerText}) -join '')
  if($allText -notmatch '\{\{ADMISSION_DATETIME\}\}' -and -not ($allText -match '\{\{ADMISSION_DATE\}\}' -and $allText -match '\{\{ADMISSION_TIME\}\}')){
   $paragraph=$xml.CreateElement('w','p',$script:ns);$run=$xml.CreateElement('w','r',$script:ns);$text=$xml.CreateElement('w','t',$script:ns);$text.InnerText=([string]$schema.DateTimeLabel+': {{ADMISSION_DATETIME}}');[void]$run.AppendChild($text);[void]$paragraph.AppendChild($run)
   if($sectionProperties){[void]$body.InsertBefore($paragraph,$sectionProperties)}else{[void]$body.AppendChild($paragraph)}
  }
  # Additional saved array positions and new linked discharge sections need
  # real markers in the portable Word source, beyond the original SDT fields.
  foreach($section in $schema.Sections){
   $unbound=@($section.Fields | Where-Object {-not $_.WordId})
   if(-not $unbound.Count){continue}
   $paragraph=$xml.CreateElement('w','p',$script:ns);$run=$xml.CreateElement('w','r',$script:ns);$text=$xml.CreateElement('w','t',$script:ns);$text.InnerText=[string]$section.Title;[void]$run.AppendChild($text);[void]$paragraph.AppendChild($run)
   if($sectionProperties){[void]$body.InsertBefore($paragraph,$sectionProperties)}else{[void]$body.AppendChild($paragraph)}
   foreach($field in $unbound){
    $paragraph=$xml.CreateElement('w','p',$script:ns);$run=$xml.CreateElement('w','r',$script:ns);$text=$xml.CreateElement('w','t',$script:ns);$text.InnerText=([string]$field.Label+': {{'+[string]$field.Marker+'}}')
    if($field.Type -eq 'choice_detail' -and (Get-UniversalDetailWordPosition $field) -eq 'marker'){$text.InnerText+=' {{'+[string]$field.DetailMarker+'}}'}
    [void]$run.AppendChild($text);[void]$paragraph.AppendChild($run)
    if($sectionProperties){[void]$body.InsertBefore($paragraph,$sectionProperties)}else{[void]$body.AppendChild($paragraph)}
   }
  }
  $memory=[IO.MemoryStream]::new();$archive=$null;$input=$null;$output=$null
  try{
   $memory.Write($sourceBytes,0,$sourceBytes.Length);$memory.Position=0
   $archive=[IO.Compression.ZipArchive]::new($memory,[IO.Compression.ZipArchiveMode]::Update,$true)
   $entry=$archive.GetEntry('word/document.xml');$entry.Delete();$entry=$archive.CreateEntry('word/document.xml')
   $output=$entry.Open();$writer=[IO.StreamWriter]::new($output,[Text.UTF8Encoding]::new($false));try{$writer.Write($xml.OuterXml)}finally{$writer.Dispose();$output=$null}
   $archive.Dispose();$archive=$null
   $template=Import-MedicalTemplateBytes $memory.ToArray() ('Восстановленный '+$title+'.docx')
   $schema.Template=$template.RelativePath;$schema.AutoTemplate=$false
  }finally{if($output){$output.Dispose()};if($archive){$archive.Dispose()};$memory.Dispose()}
 }
 Assert-UniversalConfig $schema
 return [pscustomobject]@{Schema=(Copy-MedicalFormSchema $schema);Values=$values}
}
function Import-MedicalLegacyClinicalStages($record){
 $stages=ConvertTo-MedicalClinicalMap (Get-MedicalLegacyClinicalProperty $record 'stages')
 if(-not $stages.Count){$stages=ConvertTo-MedicalClinicalMap (Get-MedicalLegacyClinicalProperty $record 'stageData')}
 $templates=ConvertTo-MedicalClinicalMap (Get-MedicalLegacyClinicalProperty $record 'templates')
 $numbers=@{};$count=0;$diaryCount=Get-MedicalLegacyClinicalProperty $record 'diaryCount'
 if($diaryCount -and [int]::TryParse([string]$diaryCount,[ref]$count)){if($count -gt 1000 -or $count -lt 0){throw 'Некорректное число дневников прежней карты.'};for($i=1;$i -le $count;$i++){$numbers[$i]=$true}}
 foreach($key in @($stages.Keys)){if([string]$key -match '^diary_([1-9][0-9]*)$'){$number=[int]$Matches[1];if($number -gt 1000){throw 'Некорректный номер дневника прежней карты.'};$numbers[$number]=$true}}
 $forms=Get-MedicalClinicalFormData;$forms.Diaries=@();$state=New-MedicalClinicalPatientState $forms
 $date=[datetime]::Now;$dateSource=Get-MedicalLegacyClinicalProperty $record 'admissionDate';$parsed=[datetime]::MinValue
 if($dateSource -is [datetime]){$date=[datetime]$dateSource}
 elseif([datetime]::TryParseExact([string]$dateSource,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$parsed)){$date=$parsed}
 foreach($number in @($numbers.Keys | Sort-Object {[int]$_})){
  $id='legacy_diary_'+$number;$title='Дневник наблюдения №'+$number
  $migration=New-MedicalLegacyClinicalStage ([string]$templates['diary']) @($stages['diary_'+$number]) $title ('legacy_diary'+$number)
  if(@(Get-UniversalFields $migration.Schema).Count -eq 0){$migration.Schema=New-MedicalDiarySchema}
  $forms.Diaries+=@([pscustomobject]@{Id=$id;Title=$title;Schema=$migration.Schema;Links=@{}})
  $overrides=@{};foreach($key in @($migration.Values.Keys)){$overrides[$key]=$true}
  $state.Diaries+=@([pscustomobject]@{Id=$id;DateTime=$date.ToString('yyyy-MM-ddTHH:mm:ss');Values=$migration.Values;Details=@{};Overrides=$overrides})
 }
 if(@($forms.Diaries).Count){$forms.DiaryForm=Copy-MedicalSharedDiaryDefinition $forms.Diaries[-1]}
 if($stages.ContainsKey('discharge')){
  $migration=New-MedicalLegacyClinicalStage ([string]$templates['discharge']) @($stages['discharge']) 'Выписной эпикриз' 'legacy_discharge' $forms.Discharge.Schema
  $forms.Discharge.Schema=$migration.Schema
  $forms.Discharge | Add-Member -NotePropertyName FollowInitialSchema -NotePropertyValue $false -Force
  $state.Discharge.Values=$migration.Values;$state.Discharge.Overrides=@{}
  foreach($key in @($migration.Values.Keys)){$state.Discharge.Overrides[$key]=$true}
 }
 # Validate candidates before replacing any live structures or patient values.
 $forms=Copy-MedicalClinicalFormData $forms;$state=Copy-MedicalClinicalPatientState $state $forms
 $script:medicalClinicalForms=$forms;$script:medicalClinicalState=$state
 Sync-MedicalDischargeFromInitial
 return $forms
}

function Get-MedicalClinicalInitialSignature($initial,[bool]$force=$false){
 # In-place schema edits remain observable. A normal refresh checks file metadata;
 # explicit form snapshots/export can force a fresh byte fingerprint.
 $shape=$initial|ConvertTo-Json -Depth 40 -Compress
 $path='';$fileStamp=''
 if(-not $initial.AutoTemplate){
  $path=Get-UniversalTemplatePath $initial
  if([IO.File]::Exists($path)){$info=New-Object IO.FileInfo($path);$fileStamp=$info.Length.ToString()+':'+$info.LastWriteTimeUtc.Ticks.ToString()+':'+$info.CreationTimeUtc.Ticks.ToString()}
 }
 $cached=$script:medicalClinicalInitialSignatureCache
 if(-not $force -and $cached -and $cached.Shape -ceq $shape -and $cached.Path -ceq $path -and $cached.FileStamp -ceq $fileStamp){return $cached.Signature}
 $schema=Copy-MedicalFormSchema $initial
 $text=$schema|ConvertTo-Json -Depth 40 -Compress
 if($path -and [IO.File]::Exists($path)){$text+='|'+(Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($path)))}
 $signature=Get-MedicalBytesSha256 ([Text.Encoding]::UTF8.GetBytes($text))
 $script:medicalClinicalInitialSignatureCache=[pscustomobject]@{Shape=$shape;Path=$path;FileStamp=$fileStamp;Signature=$signature}
 return $signature
}
function Get-MedicalDischargeGeneratedFieldIds($schema){
 $categories=@('final_diagnosis','examination_results','treatment_results','recommendations');$result=@{}
 if(@($schema.Sections).Count -lt 4){throw 'В эпикризе отсутствуют итоговые разделы.'}
 for($i=0;$i -lt 4;$i++){$section=@($schema.Sections)[@($schema.Sections).Count-4+$i];$result[$categories[$i]]=[string]@($section.Fields)[0].Id}
 return $result
}
function Sync-MedicalDischargeSchemaFromInitial([bool]$force=$false){
 if(-not $script:medicalClinicalForms -or -not $script:medicalClinicalForms.Discharge -or -not $script:medicalClinicalState){return}
 $definition=$script:medicalClinicalForms.Discharge
 if($definition.FollowInitialSchema -ne $true){return}
 $signature=Get-MedicalClinicalInitialSignature $script:universalConfig $force
 if([string]$definition.InitialSchemaSignature -ceq $signature){return}
 if(-not $script:universalConfig.AutoTemplate -and -not [IO.File]::Exists((Get-UniversalTemplatePath $script:universalConfig))){return}
 $schema=New-MedicalDischargeSchema $script:universalConfig;$generated=Get-MedicalDischargeGeneratedFieldIds $schema
 $oldGenerated=ConvertTo-MedicalClinicalMap $definition.GeneratedFieldIds;$mapping=@{}
 $sourceIds=@{};foreach($field in Get-UniversalFields $script:universalConfig){$sourceIds[[string]$field.Id]=$true}
 foreach($field in Get-UniversalFields $definition.Schema){if($sourceIds.ContainsKey([string]$field.Id)){$mapping[[string]$field.Id]=[string]$field.Id}}
 foreach($category in @($generated.Keys)){if($oldGenerated.ContainsKey($category)){$mapping[[string]$oldGenerated[$category]]=[string]$generated[$category]}}
 $patient=$script:medicalClinicalState.Discharge;$values=@{};$details=@{};$overrides=@{}
 foreach($oldId in @($mapping.Keys)){
  $newId=[string]$mapping[$oldId]
  if($patient.Values.ContainsKey($oldId)){$values[$newId]=[string]$patient.Values[$oldId]}
  if($patient.Details.ContainsKey($oldId)){$details[$newId]=[string]$patient.Details[$oldId]}
  if($patient.Overrides.ContainsKey($oldId)){$overrides[$newId]=$true}
 }
 # Compute and validate everything before changing the live schema or answers.
 $links=Get-MedicalClinicalDefaultLinks $schema $script:universalConfig $true
 $values=Copy-MedicalClinicalValues $values $schema;$details=Copy-MedicalClinicalValues $details $schema $true
 $definition.Schema=$schema;$definition.Links=$links;$definition.GeneratedFieldIds=$generated;$definition.InitialSchemaSignature=$signature
 $patient.Values=$values;$patient.Details=$details;$patient.Overrides=$overrides
}


# Treatment dates are patient data. They are deliberately absent from StageForms.
function ConvertTo-MedicalTreatmentDate($value,[string]$label){
 $date=[datetime]::MinValue
 if($value -is [datetime]){$date=([datetime]$value).Date}
 elseif(-not [datetime]::TryParseExact([string]$value,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$date)){throw ('Укажите корректную дату '+$label+'.')}
 if($date -lt [datetime]'1753-01-01' -or $date -gt [datetime]'9998-12-31'){throw ('Дата '+$label+' находится вне допустимого диапазона календаря.')}
 return $date.Date
}
function New-MedicalTreatmentPeriod {
 $start=[datetime]::Today
 if($script:admissionControl){$start=([datetime]$script:admissionControl.Value).Date}
 $end=[datetime]::Today;if($end -lt $start){$end=$start}
 return [pscustomobject]@{StartDate=$start.ToString('yyyy-MM-dd');EndDate=$end.ToString('yyyy-MM-dd');StartOverride=$false;EndOverride=$false}
}
function Copy-MedicalTreatmentPeriod($source){
 if($null -eq $source){return (New-MedicalTreatmentPeriod)}
 $start=ConvertTo-MedicalTreatmentDate $source.StartDate 'начала лечения'
 $end=ConvertTo-MedicalTreatmentDate $source.EndDate 'окончания лечения'
 if($end -lt $start){throw 'Дата окончания лечения не может быть раньше даты начала.'}
 foreach($name in @('StartOverride','EndOverride')){if($source.$name -isnot [bool]){throw 'Некорректный признак ручного изменения периода лечения.'}}
 return [pscustomobject]@{StartDate=$start.ToString('yyyy-MM-dd');EndDate=$end.ToString('yyyy-MM-dd');StartOverride=[bool]$source.StartOverride;EndOverride=[bool]$source.EndOverride}
}
function Get-MedicalTreatmentPeriod {
 if(-not $script:medicalClinicalState){[void](Initialize-MedicalClinicalWorkspace)}
 $period=Copy-MedicalTreatmentPeriod $script:medicalClinicalState.TreatmentPeriod
 # Until a user explicitly adjusts the range, it follows the corrected admission
 # date and today's date. Once edited, both selected dates remain authoritative.
 if(-not $period.StartOverride -and -not $period.EndOverride){
  $defaults=New-MedicalTreatmentPeriod;$period.StartDate=$defaults.StartDate;$period.EndDate=$defaults.EndDate
 }
 $script:medicalClinicalState | Add-Member -NotePropertyName TreatmentPeriod -NotePropertyValue $period -Force
 return (Copy-UniversalObject $period)
}
function Set-MedicalTreatmentPeriod($start,$end){
 $from=ConvertTo-MedicalTreatmentDate $start 'начала лечения';$until=ConvertTo-MedicalTreatmentDate $end 'окончания лечения'
 if($until -lt $from){throw 'Дата окончания лечения не может быть раньше даты начала.'}
 if(-not $script:medicalClinicalState){[void](Initialize-MedicalClinicalWorkspace)}
 $period=[pscustomobject]@{StartDate=$from.ToString('yyyy-MM-dd');EndDate=$until.ToString('yyyy-MM-dd');StartOverride=$true;EndOverride=$true}
 $script:medicalClinicalState | Add-Member -NotePropertyName TreatmentPeriod -NotePropertyValue $period -Force
 return (Copy-UniversalObject $period)
}
function Get-MedicalDiaryPeriodDates($start,$end){
 $from=ConvertTo-MedicalTreatmentDate $start 'начала лечения';$until=ConvertTo-MedicalTreatmentDate $end 'окончания лечения'
 if($until -lt $from){throw 'Дата окончания лечения не может быть раньше даты начала.'}
 if(($until-$from).TotalDays -gt 3660){throw 'За один раз можно добавить дневники не более чем за 3660 дней.'}
 for($date=$from.AddDays(1);$date -le $until;$date=$date.AddDays(1)){$date}
}
function Test-MedicalClinicalDiaryPlaceholder($definition,$patient){
 if($patient.DateIsAutomatic -ne $true){return $false}
 foreach($field in @(Copy-MedicalArchivedDiaryFields $patient.ArchivedFields)){if(-not [string]::IsNullOrWhiteSpace($field.Value) -or -not [string]::IsNullOrWhiteSpace($field.Detail) -or $field.Override){return $false}}
 $overrides=ConvertTo-MedicalClinicalMap $patient.Overrides
 foreach($key in @($overrides.Keys)){if($overrides[$key] -eq $true){return $false}}
 $details=ConvertTo-MedicalClinicalMap $patient.Details
 foreach($key in @($details.Keys)){if(-not [string]::IsNullOrWhiteSpace([string]$details[$key])){return $false}}
 $links=ConvertTo-MedicalClinicalMap $definition.Links;$values=ConvertTo-MedicalClinicalMap $patient.Values
 foreach($key in @($values.Keys)){
  # Automatically linked demographics are not an independently completed diary.
  if(-not $links.ContainsKey([string]$key) -and -not [string]::IsNullOrWhiteSpace([string]$values[$key])){return $false}
 }
 return $true
}
function Test-MedicalClinicalDiaryUnscheduled($context){
 # A pure export predicate: reusable spare slots remain in the form, while only
 # blank placeholders left after choosing a patient period are omitted in Word.
 $period=$script:medicalClinicalState.TreatmentPeriod
 if(-not $period -or ($period.StartOverride -ne $true -and $period.EndOverride -ne $true)){return $false}
 if(-not $context -or $context.DateIsAutomatic -ne $true){return $false}
 return (Test-MedicalClinicalDiaryPlaceholder $context $context)
}
function Add-MedicalClinicalDiaryPeriod($start,$end){
 # Validate the entire range and every copied structure before changing live data.
 $dates=@(Get-MedicalDiaryPeriodDates $start $end)
 if(-not $script:medicalClinicalForms){[void](Initialize-MedicalClinicalWorkspace)}
 $existing=@{};$placeholders=@()
 foreach($definition in @($script:medicalClinicalForms.Diaries)){
  $entry=@($script:medicalClinicalState.Diaries|Where-Object {[string]$_.Id -eq [string]$definition.Id})
  if($entry.Count -ne 1){throw 'Дневник не найден в текущей карте.'}
  $entry=$entry[0]
  if(Test-MedicalClinicalDiaryPlaceholder $definition $entry){$placeholders+=@($entry);continue}
  $date=[datetime]::ParseExact([string]$entry.DateTime,'yyyy-MM-ddTHH:mm:ss',[Globalization.CultureInfo]::InvariantCulture)
  $existing[$date.ToString('yyyy-MM-dd')]=$true
 }
 $schema=Get-MedicalSharedDiarySchema
 $definitions=@();$records=@();$ids=@();$skipped=0;$time=[timespan]::Zero;$assignments=@();$slotIndex=0
 if($script:admissionControl){$time=([datetime]$script:admissionControl.Value).TimeOfDay}
 foreach($date in $dates){
  $key=$date.ToString('yyyy-MM-dd');if($existing.ContainsKey($key)){$skipped++;continue}
  $stamp=$date.Add($time).ToString('yyyy-MM-ddTHH:mm:ss')
  if($slotIndex -lt $placeholders.Count){
   $patient=$placeholders[$slotIndex];$slotIndex++
   $assignments+=@([pscustomobject]@{Patient=$patient;DateTime=$stamp});$ids+=@([string]$patient.Id)
  }else{
   $copy=Copy-MedicalFormSchema $schema;$id=[guid]::NewGuid().ToString('N')
   $number=@($script:medicalClinicalForms.Diaries).Count+$definitions.Count+1
   $dateCount=1;if(@($script:medicalClinicalForms.Diaries).Count){$dateCount=Get-MedicalClinicalDiaryDateCount $script:medicalClinicalForms.Diaries[-1]}
   $definitions+=@([pscustomobject]@{Id=$id;Title=('Дневник наблюдения №'+$number);Schema=$copy;Links=(Get-MedicalSharedDiaryLinks $copy $script:medicalClinicalForms.DiaryForm.Links);DateCount=$dateCount})
   $records+=@([pscustomobject]@{Id=$id;DateTime=$stamp;EndDateTime=$stamp;DateIsAutomatic=$false;Values=@{};Details=@{};Overrides=@{};ArchivedFields=@()})
   $ids+=@($id)
  }
  $existing[$key]=$true
 }
 [void](Set-MedicalTreatmentPeriod $start $end)
 foreach($assignment in $assignments){
  $assignment.Patient.DateTime=[string]$assignment.DateTime
  $assignment.Patient | Add-Member -NotePropertyName EndDateTime -NotePropertyValue ([string]$assignment.DateTime) -Force
  # The chosen period confirms these dates. A subsequent capture or repeat
  # generation must not reschedule an already confirmed diary automatically.
  $assignment.Patient | Add-Member -NotePropertyName DateIsAutomatic -NotePropertyValue $false -Force
 }
 $script:medicalClinicalForms.Diaries+=@($definitions);$script:medicalClinicalState.Diaries+=@($records)
 return [pscustomobject]@{AddedCount=$records.Count;ReusedCount=$assignments.Count;SkippedCount=$skipped;RemainingBlankCount=($placeholders.Count-$slotIndex);DiaryIds=$ids}
}

function Test-MedicalTreatmentMarkersInTemplate($schema){
 if(-not $schema -or $schema.AutoTemplate){return $false}
 $path=Get-UniversalTemplatePath $schema;if(-not [IO.File]::Exists($path)){return $false}
 $archive=[IO.Compression.ZipFile]::OpenRead($path);$found=@{}
 try{
  foreach($entry in $archive.Entries){
   if($entry.FullName -notmatch '^word/(document|header[0-9]*|footer[0-9]*)\.xml$'){continue}
   $x=Get-XmlPart $archive $entry.FullName;$n=[Xml.XmlNamespaceManager]::new($x.NameTable);$n.AddNamespace('w',$script:ns)
   foreach($p in $x.SelectNodes('//w:p',$n)){
    $text=($p.SelectNodes('.//w:t',$n) | ForEach-Object {$_.InnerText}) -join ''
    foreach($marker in @('TREATMENT_START_DATE','TREATMENT_END_DATE')){if($text.Contains('{{'+$marker+'}}')){$found[$marker]=$true}}
   }
   foreach($tag in $x.SelectNodes('//w:sdtPr/w:tag|//w:sdtPr/w:alias',$n)){
    $key=$tag.GetAttribute('val',$script:ns);if($key -in @('TREATMENT_START_DATE','TREATMENT_END_DATE')){$found[$key]=$true}
   }
  }
 }finally{$archive.Dispose()}
 return ($found.ContainsKey('TREATMENT_START_DATE') -and $found.ContainsKey('TREATMENT_END_DATE'))
}
function Set-MedicalDischargePeriodDocument([string]$path,$schema=$null){
 $period=Get-MedicalTreatmentPeriod;$from=ConvertTo-MedicalTreatmentDate $period.StartDate 'начала лечения';$until=ConvertTo-MedicalTreatmentDate $period.EndDate 'окончания лечения'
 $text='Период лечения: '+$from.ToString('dd.MM.yyyy')+' — '+$until.ToString('dd.MM.yyyy')
 if($null -eq $schema){$saved=Read-UniversalDocumentState $path;if($saved){$schema=$saved.Schema}}
 if($schema -and -not $schema.AutoTemplate){$source=Get-UniversalTemplatePath $schema;if([IO.Path]::GetFullPath($source) -eq [IO.Path]::GetFullPath($path)){throw 'Период лечения можно добавлять только в копию документа, а не в исходный шаблон.'}}
 # Literal/system markers are replaced during the normal renderer. An authored
 # template with both markers defines its own placement, so add no extra line.
 if(Test-MedicalTreatmentMarkersInTemplate $schema){return}
 $temp=Join-Path ([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($path))) ('mc-period-'+[guid]::NewGuid().ToString('N')+'.tmp')
 $archive=$null
 try{
  [IO.File]::Copy($path,$temp,$false);$archive=[IO.Compression.ZipFile]::Open($temp,[IO.Compression.ZipArchiveMode]::Update)
  $x=Get-XmlPart $archive 'word/document.xml';$n=[Xml.XmlNamespaceManager]::new($x.NameTable);$n.AddNamespace('w',$script:ns)
  $body=$x.SelectSingleNode('/w:document/w:body',$n);if(-not $body){throw 'В эпикризе отсутствует основной текст документа.'}
  $bookmark=$x.SelectSingleNode('//w:bookmarkStart[@w:name="MedicalTreatmentPeriod"]',$n)
  if($bookmark){
   $paragraph=$bookmark.SelectSingleNode('ancestor::w:p[1]',$n)
   if(-not $paragraph){throw 'Некорректная строка периода лечения.'}
   $texts=@($paragraph.SelectNodes('.//w:t',$n));if(-not $texts.Count){throw 'В строке периода лечения отсутствует текст.'}
   $texts[0].InnerText=$text;for($i=1;$i -lt $texts.Count;$i++){$texts[$i].InnerText=''}
  }else{
   $paragraph=$x.CreateElement('w','p',$script:ns)
   $first=$body.SelectSingleNode('./w:p',$n)
   if($first){$format=$first.SelectSingleNode('./w:pPr',$n);if($format){$format=$format.CloneNode($true);foreach($node in @($format.SelectNodes('./w:pStyle|./w:outlineLvl|./w:pageBreakBefore|./w:keepNext|./w:sectPr',$n))){[void]$format.RemoveChild($node)};[void]$paragraph.AppendChild($format)}}
   $ids=@($x.SelectNodes('//w:bookmarkStart/@w:id',$n)|ForEach-Object {[long]$_.Value});$id=if($ids.Count){([long]($ids|Measure-Object -Maximum).Maximum+1).ToString()}else{'1'}
   $start=$x.CreateElement('w','bookmarkStart',$script:ns);[void]$start.SetAttribute('id',$script:ns,$id);[void]$start.SetAttribute('name',$script:ns,'MedicalTreatmentPeriod');[void]$paragraph.AppendChild($start)
   $run=$x.CreateElement('w','r',$script:ns);$node=$x.CreateElement('w','t',$script:ns);$node.InnerText=$text;[void]$run.AppendChild($node);[void]$paragraph.AppendChild($run)
   $end=$x.CreateElement('w','bookmarkEnd',$script:ns);[void]$end.SetAttribute('id',$script:ns,$id);[void]$paragraph.AppendChild($end)
   if($first){[void]$body.InsertAfter($paragraph,$first)}else{$section=$body.SelectSingleNode('./w:sectPr',$n);if($section){[void]$body.InsertBefore($paragraph,$section)}else{[void]$body.AppendChild($paragraph)}}
  }
  $entry=$archive.GetEntry('word/document.xml');$entry.Delete();Write-UniversalZipText $archive 'word/document.xml' $x.OuterXml
  $archive.Dispose();$archive=$null
  [IO.File]::Replace($temp,$path,[NullString]::Value)
 }finally{if($archive){$archive.Dispose()};if([IO.File]::Exists($temp)){[IO.File]::Delete($temp)}}
}
