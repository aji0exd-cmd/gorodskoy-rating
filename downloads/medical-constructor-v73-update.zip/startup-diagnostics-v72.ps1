﻿# Fixed-schema startup diagnostics: no source text, paths, messages or document data.
function Get-MedicalStartupDiagnostic($ErrorRecord,[string]$ProgramRoot,[string]$IncidentId=''){
 if($IncidentId -cnotmatch '^[a-f0-9]{32}$'){$IncidentId=[guid]::NewGuid().ToString('N')}
 $knownComponents=@(
  'account-workspace-v71.ps1'
  'accounts-ui-v71.ps1'
  'accounts-v71.ps1'
  'backup-ui-v67.ps1'
  'backup-v67.ps1'
  'card-document-v65.ps1'
  'clinical-stages-v67.ps1'
  'clinical-ui-v67.ps1'
  'constructor.ps1'
  'core-guard-v71.ps1'
  'diary-document-v67.ps1'
  'diary-period-v69.ps1'
  'document-actions.ps1'
  'editor-layout-v70.ps1'
  'forms-ui-v59.ps1'
  'forms-v59.ps1'
  'hospitalization-document-v68.ps1'
  'launcher.ps1'
  'local-ai-ui-v72.ps1'
  'local-ai-v72.ps1'
  'model-acquisition-v72.ps1'
  'offline-import-v71.ps1'
  'open-document-v72.ps1'
  'patients.ps1'
  'portable-paths-v69.ps1'
  'section-editor-v64.ps1'
  'template-editor-operations-v61.ps1'
  'template-editor-v59.ps1'
  'template-format-ui-v62.ps1'
  'template-format-v62.ps1'
  'template-layout-preview-v62.ps1'
  'template-recognition-ui-v71.ps1'
  'template-recognition-v71.ps1'
  'template-recovery-v66.ps1'
  'top-menu-v72.ps1'
  'ui-v57.ps1'
  'universal-ui.ps1'
  'universal.ps1'
  'word-actions.ps1'
  'word-preview-v62.ps1'
  'workspace-settings.ps1'
  'startup-diagnostics-v72.ps1'
 )
 $knownErrorIds=@(
  'NamedParameterNotFound','PositionalParameterNotFound','AmbiguousParameter','ParameterArgumentValidationError','ParameterArgumentTransformationError','ParameterBindingException','ParameterBindingValidationException',
  'CommandNotFoundException','CouldNotAutoloadMatchingModule','Modules_ModuleNotFound','TypeNotFound','UnableToFindType','AddTypeCompilerError','CompilerErrors','SOURCE_CODE_ERROR',
  'MethodInvocationException','PropertyAssignmentException','PropertyNotFound','PropertyNotFoundStrict','MethodNotFound','InvalidOperation','InvalidArgument','InvalidCastFromNull',
  'FileNotFoundException','DirectoryNotFoundException','UnauthorizedAccessException','IOException','PathNotFound','ItemNotFound','ParserError','ParseException','UnexpectedToken','MissingEndCurlyBrace','MissingEndParenthesisInExpression','TerminatorExpectedAtEndOfString','RuntimeException'
 )
 $result=[ordered]@{Incident=$IncidentId;Utc=[datetime]::UtcNow.ToString('o');Version='73.0.0';Component='unknown';Line=0;ErrorId='Other';ExceptionType='System.Exception';Category='NotSpecified'}
 $records=New-Object Collections.ArrayList
 $cursor=$ErrorRecord
 # RuntimeException.ErrorRecord can wrap the original error at a pipeline boundary.
 # Traverse a bounded number of records and stop self-references.
 for($depth=0;$depth -lt 8 -and $cursor -is [Management.Automation.ErrorRecord];$depth++){
  if(@($records|Where-Object{[object]::ReferenceEquals($_,$cursor)}).Count -gt 0){break}
  [void]$records.Add($cursor)
  $next=$null;$exception=$cursor.Exception
  for($inner=0;$inner -lt 8 -and $exception -is [Exception];$inner++){
   if($exception -is [Management.Automation.RuntimeException] -and $exception.ErrorRecord -and -not [object]::ReferenceEquals($exception.ErrorRecord,$cursor)){$next=$exception.ErrorRecord;break}
   $exception=$exception.InnerException
  }
  $cursor=$next
 }
 foreach($record in $records){
  $candidateType=$record.Exception.GetType().FullName
  if($candidateType -cne 'System.Management.Automation.ParentContainsErrorRecordException' -and $candidateType -cmatch '^System\.[A-Za-z0-9_.+`]{1,150}$'){$result.ExceptionType=$candidateType}
  $category=$record.CategoryInfo.Category
  if($category -is [Management.Automation.ErrorCategory] -and [Enum]::IsDefined([Management.Automation.ErrorCategory],$category)){$result.Category=$category.ToString()}
  $candidateId=([string]$record.FullyQualifiedErrorId -split ',',2)[0]
  if($knownErrorIds -ccontains $candidateId){$result.ErrorId=$candidateId}
  $invocation=$record.InvocationInfo
  if(-not $invocation -or [string]::IsNullOrWhiteSpace($invocation.ScriptName)){continue}
  try{
   $full=[IO.Path]::GetFullPath([string]$invocation.ScriptName);$name=[IO.Path]::GetFileName($full)
   if($knownComponents -cnotcontains $name){continue}
   $expected=[IO.Path]::GetFullPath((Join-Path $ProgramRoot $name))
   if(-not $full.Equals($expected,[StringComparison]::OrdinalIgnoreCase)){continue}
   $line=[int]$invocation.ScriptLineNumber
   if($line -lt 1 -or $line -gt 1000000){continue}
   $result.Component=$name;$result.Line=$line
  }catch{}
 }
 return [pscustomobject]$result
}
function Write-MedicalStartupDiagnostic($ErrorRecord,[string]$ProgramRoot,[string]$IncidentId=''){
 $diagnostic=Get-MedicalStartupDiagnostic $ErrorRecord $ProgramRoot $IncidentId
 $path=Join-Path $ProgramRoot 'startup_error.txt'
 $temporary=Join-Path $ProgramRoot ('.startup-'+[guid]::NewGuid().ToString('N')+'.tmp')
 try{
  $text=$diagnostic|ConvertTo-Json -Depth 3
  if($text.Length -gt 4096){throw 'Startup diagnostic exceeded its fixed limit.'}
  [IO.File]::WriteAllText($temporary,$text,[Text.UTF8Encoding]::new($true))
  if([IO.File]::Exists($path)){[IO.File]::Replace($temporary,$path,[Management.Automation.Language.NullString]::Value)}else{[IO.File]::Move($temporary,$path)}
 }finally{if([IO.File]::Exists($temporary)){[IO.File]::Delete($temporary)}}
 return $diagnostic
}
