﻿# v49: data-driven initial examination and lossless Word marker engine.
$script:universalConfigPath=Join-Path $PSScriptRoot 'form-settings.json'
$script:universalValues=@{}
$script:universalInputs=@{}
$script:universalMultiInputs=@{}
$script:universalRepeatInputs=@{}
$script:universalDetails=@{}
$script:universalDetailInputs=@{}
$script:universalWordFields=@()
$script:universalBuilding=$false
function New-UniversalField($id,$label,$marker,$type='multiline',$system=''){
 return [pscustomobject]@{Id=$id;Label=$label;Marker=$marker;Type=$type;System=$system;WordId='';Options=@();Required=$true}
}
function New-UniversalConfig {
 $sections=@(
  [pscustomobject]@{Id='patient';Title='Сведения о пациенте';Fields=@(
   (New-UniversalField 'patient_name' 'Ф.И.О.' 'PATIENT_NAME' 'text' 'name'),
   (New-UniversalField 'patient_birth' 'Дата рождения (ДД.ММ.ГГГГ)' 'PATIENT_BIRTH' 'text' 'birth'),
   (New-UniversalField 'patient_address' 'Адрес регистрации' 'PATIENT_ADDRESS' 'text' 'address')
  )},
  [pscustomobject]@{Id='complaints';Title='Жалобы';Fields=@((New-UniversalField 'complaints' 'Жалобы' 'COMPLAINTS'))},
  [pscustomobject]@{Id='history';Title='Анамнез настоящего заболевания';Fields=@((New-UniversalField 'history' 'Анамнез настоящего заболевания' 'DISEASE_HISTORY'))},
  [pscustomobject]@{Id='examination';Title='Осмотр пациента на момент поступления';Fields=@((New-UniversalField 'examination' 'Осмотр пациента на момент поступления' 'EXAMINATION'))},
  [pscustomobject]@{Id='diagnosis';Title='Предварительный диагноз';Fields=@((New-UniversalField 'diagnosis' 'Предварительный диагноз' 'PRELIMINARY_DIAGNOSIS'))},
  [pscustomobject]@{Id='plan';Title='План обследования';Fields=@((New-UniversalField 'plan' 'План обследования' 'EXAMINATION_PLAN'))},
  [pscustomobject]@{Id='prescriptions';Title='Назначения';Fields=@((New-UniversalField 'prescriptions' 'Назначения' 'PRESCRIPTIONS'))}
 )
 return [pscustomobject]@{Version=49;AutoTemplate=$true;Template='Универсальный первичный осмотр.docx';Sections=$sections}
}
function Copy-UniversalObject($object){return ($object | ConvertTo-Json -Depth 40 | ConvertFrom-Json)}
function Get-UniversalFields($config){foreach($section in $config.Sections){foreach($field in $section.Fields){$field}}}
function Get-UniversalDetailFormPosition($field){
 $position=[string]$field.DetailFormPosition
 if([string]::IsNullOrWhiteSpace($position)){return 'below'}
 return $position
}
function Get-UniversalDetailWordPosition($field){
 $position=[string]$field.DetailWordPosition
 if([string]::IsNullOrWhiteSpace($position)){return 'after'}
 return $position
}
function Assert-UniversalConfig($config){
 if(-not $config -or [int]$config.Version -ne 49){throw 'Неизвестный формат настройки формы.'}
 foreach($property in @('DocumentTitle','DateTimeLabel')){
  if($null -ne $config.PSObject.Properties[$property] -and ($config.$property -isnot [string] -or [string]::IsNullOrWhiteSpace([string]$config.$property) -or ([string]$config.$property).Length -gt 250)){throw 'Название документа и подпись даты должны быть непустым текстом не длиннее 250 символов.'}
 }
 if($null -ne $config.PSObject.Properties['PreserveTemplateFormatting'] -and $config.PreserveTemplateFormatting -isnot [bool]){throw 'Признак сохранения оформления шаблона должен быть логическим значением.'}
 $ids=@{};$markers=@{};$systems=@{};$wordIds=@{};$sectionIds=@{}
 foreach($section in $config.Sections){
  if(-not $section.Id -or $sectionIds.ContainsKey([string]$section.Id)){throw 'Повтор или отсутствие идентификатора раздела.'}
  $sectionIds[[string]$section.Id]=$true
  if([string]::IsNullOrWhiteSpace([string]$section.Title)){throw 'Укажите название каждого раздела.'}
  foreach($f in $section.Fields){
   if(-not $f.Id -or $ids.ContainsKey([string]$f.Id)){throw 'Повтор или отсутствие идентификатора поля.'};$ids[[string]$f.Id]=$true
   if([string]::IsNullOrWhiteSpace([string]$f.Label)){throw 'Укажите подпись каждого поля.'}
   if([string]$f.Marker -cnotmatch '^[A-Z][A-Z0-9_]*$'){throw ('Маркер поля «'+$f.Label+'»: используйте A–Z, цифры и _, начиная с буквы.')}
   if($f.Marker -in @('ADMISSION_DATE','ADMISSION_TIME','ADMISSION_DATETIME','DIAGNOSIS_CODE','PATIENT_SEX','TREATMENT_START_DATE','TREATMENT_END_DATE')){throw 'Этот маркер зарезервирован для системных данных.'}
   if($markers.ContainsKey([string]$f.Marker)){throw ('Маркер '+$f.Marker+' назначен двум полям. Для повторения ответа повторите маркер в Word.')};$markers[[string]$f.Marker]=$true
   if($null -ne $f.PSObject.Properties['Required'] -and $f.Required -isnot [bool]){throw 'Признак обязательного поля должен быть логическим значением.'}
   if($f.Type -notin @('text','multiline','choice','choice_detail','heading','multi','repeat')){throw 'Неизвестный тип поля.'}
   if($f.Type -in @('choice','choice_detail') -and @($f.Options).Count -eq 0 -and -not $f.WordId){throw ('Для списка «'+$f.Label+'» добавьте варианты или выберите список Word.')}
   if($f.Type -in @('multi','repeat') -and @($f.Options).Count -eq 0){throw 'Добавьте варианты для списка с галочками.'}
   if($f.Type -in @('heading','multi','repeat') -and ($f.System -or $f.WordId)){throw 'Подзаголовки и списки с галочками вставляются по маркеру, без роли пациента и привязки к списку Word.'}
   if($f.Type -in @('multi','repeat')){foreach($option in $f.Options){if([string]::IsNullOrWhiteSpace([string]$option) -or [string]$option -match '[\r\n]'){throw 'Каждый вариант списка с галочками должен занимать одну непустую строку.'}}}
   if($f.System){
    if($f.System -notin @('name','birth','address') -or $systems.ContainsKey([string]$f.System)){throw 'Роль поля пациента должна быть уникальной.'}
    $systems[[string]$f.System]=$true
   }
   if($f.WordId){if($wordIds.ContainsKey([string]$f.WordId)){throw 'Один элемент Word назначен двум полям.'};$wordIds[[string]$f.WordId]=$true}
   if($f.Type -eq 'choice_detail'){
    if((Get-UniversalDetailFormPosition $f) -notin @('below','above','right')){throw 'Неизвестное расположение уточнения в форме.'}
    $detailWordPosition=Get-UniversalDetailWordPosition $f
    if($detailWordPosition -notin @('after','before','newline','marker')){throw 'Неизвестное расположение уточнения в Word.'}
    if($detailWordPosition -eq 'marker'){
     $detailMarker=[string]$f.DetailMarker
     if($detailMarker -cnotmatch '^[A-Z][A-Z0-9_]*$'){throw ('Укажите отдельный маркер уточнения поля «'+$f.Label+'»: буквы A–Z, цифры, _, начиная с буквы.')}
     if($detailMarker -in @('ADMISSION_DATE','ADMISSION_TIME','ADMISSION_DATETIME','DIAGNOSIS_CODE','PATIENT_SEX','TREATMENT_START_DATE','TREATMENT_END_DATE')){throw 'Маркер уточнения зарезервирован для системных данных.'}
     if($markers.ContainsKey($detailMarker)){throw ('Маркер '+$detailMarker+' назначен нескольким полям или уточнениям.')}
     $markers[$detailMarker]=$true
    }
   }
  }
 }
}
function Save-UniversalConfig($config){
 Assert-UniversalConfig $config
 $temp=$script:universalConfigPath+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
 try{
  [IO.File]::WriteAllText($temp,($config | ConvertTo-Json -Depth 40),[Text.UTF8Encoding]::new($true))
  if(Test-Path -LiteralPath $script:universalConfigPath){Copy-Item -LiteralPath $script:universalConfigPath -Destination ($script:universalConfigPath+'.bak') -Force}
  Move-Item -LiteralPath $temp -Destination $script:universalConfigPath -Force
 }finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force}}
}
function Load-UniversalConfig {
 if(Test-Path -LiteralPath $script:universalConfigPath){
  $c=Get-Content -LiteralPath $script:universalConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
  Assert-UniversalConfig $c;return $c
 }
 return (New-UniversalConfig)
}
function Get-UniversalTemplatePath($config=$script:universalConfig) {
 $p=[string]$config.Template
 if([IO.Path]::IsPathRooted($p)){return $p}
 $root=if(-not [string]::IsNullOrWhiteSpace([string]$script:medicalProgramRoot)){[string]$script:medicalProgramRoot}else{$PSScriptRoot}
 return (Join-Path $root ($p.Replace('\',[IO.Path]::DirectorySeparatorChar)))
}
function Get-UniversalWordFields($path){
 $z=[IO.Compression.ZipFile]::OpenRead($path)
 try{
  $x=Get-XmlPart $z 'word/document.xml';$n=[Xml.XmlNamespaceManager]::new($x.NameTable);$n.AddNamespace('w',$script:ns)
  foreach($s in $x.SelectNodes('//w:sdt',$n)){
   $id=$s.SelectSingleNode('./w:sdtPr/w:id',$n);if(-not $id){continue}
   $tag=$s.SelectSingleNode('./w:sdtPr/w:tag',$n);$alias=$s.SelectSingleNode('./w:sdtPr/w:alias',$n)
   $label=if($alias){$alias.GetAttribute('val',$script:ns)}elseif($tag){$tag.GetAttribute('val',$script:ns)}else{'Элемент Word'}
   $p=$s.SelectSingleNode('ancestor::w:p[1]',$n)
   if($p){$context=(($p.SelectNodes('.//w:t',$n)|ForEach-Object {$_.InnerText}) -join '').Trim();if($context.Length -gt 90){$context=$context.Substring(0,90)+'…'}}else{$context=''}
   $options=@(foreach($item in $s.SelectNodes('./w:sdtPr/*/w:listItem',$n)){
    $v=$item.GetAttribute('displayText',$script:ns);if(-not $v){$v=$item.GetAttribute('value',$script:ns)}
    if($v -and $v -ne 'Выберите элемент.'){$v}
   })
   [pscustomobject]@{Id=$id.GetAttribute('val',$script:ns);Label=$label;Context=$context;Options=$options;Value=(($s.SelectNodes('./w:sdtContent//w:t',$n)|ForEach-Object {$_.InnerText}) -join '')}
  }
 }finally{$z.Dispose()}
}
function Get-UniversalMarkerValues($config,$values,[datetime]$admission,$details=$null){
 $result=@{DIAGNOSIS_CODE=[string]$config.ProfileCode;PATIENT_SEX=$(if($config.ProfileSex -eq 'M'){'мужчина'}elseif($config.ProfileSex -eq 'F'){'женщина'}else{''});ADMISSION_DATE=$admission.ToString('dd.MM.yyyy');ADMISSION_TIME=$admission.ToString('HH:mm');ADMISSION_DATETIME=$admission.ToString('dd.MM.yyyy HH:mm')}
 # Date-only reserved markers may be placed anywhere in a custom discharge
 # template. Resolve the same patient period used by the on-screen controls.
 $result.TREATMENT_START_DATE=$admission.ToString('dd.MM.yyyy');$result.TREATMENT_END_DATE=[datetime]::Today.ToString('dd.MM.yyyy')
 if(Get-Command Get-MedicalTreatmentPeriod -CommandType Function -ErrorAction SilentlyContinue){
  $period=if($script:medicalClinicalState){Get-MedicalTreatmentPeriod}else{New-MedicalTreatmentPeriod}
  $result.TREATMENT_START_DATE=([datetime]::ParseExact([string]$period.StartDate,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture)).ToString('dd.MM.yyyy')
  $result.TREATMENT_END_DATE=([datetime]::ParseExact([string]$period.EndDate,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture)).ToString('dd.MM.yyyy')
 }
 foreach($f in Get-UniversalFields $config){
  $result[[string]$f.Marker]=[string]$values[[string]$f.Id]
  if($f.Type -eq 'choice_detail' -and (Get-UniversalDetailWordPosition $f) -eq 'marker'){
   $detailValue='';if($null -ne $details){$detailValue=([string]$details[[string]$f.Id]).Trim()}
   $result[[string]$f.DetailMarker]=$detailValue
  }
 }
 return $result
}
function Set-UniversalTextNode($node,[string]$value){
 # Retain run properties; Word requires w:br for multiline text, not raw newlines.
 $x=$node.OwnerDocument;$parts=[regex]::Split($value,"\r\n|\r|\n")
 $node.InnerText=$parts[0];[void]$node.SetAttribute('xml:space','preserve')
 $anchor=$node
 for($i=1;$i -lt $parts.Count;$i++){
  $br=$x.CreateElement('w','br',$script:ns);[void]$anchor.ParentNode.InsertAfter($br,$anchor)
  $t=$x.CreateElement('w','t',$script:ns);$t.InnerText=$parts[$i];[void]$t.SetAttribute('xml:space','preserve')
  [void]$br.ParentNode.InsertAfter($t,$br);$anchor=$t
 }
}
function Set-UniversalControlValue($s,[string]$value,$n){
 $content=$s.SelectSingleNode('./w:sdtContent',$n);if(-not $content){return}
 $texts=@($content.SelectNodes('.//w:t',$n))
 foreach($break in @($content.SelectNodes('.//w:br|.//w:cr',$n))){[void]$break.ParentNode.RemoveChild($break)}
 if($texts.Count -eq 0){
  $x=$s.OwnerDocument;$r=$x.CreateElement('w','r',$script:ns);$t=$x.CreateElement('w','t',$script:ns);[void]$r.AppendChild($t)
  $p=$content.SelectSingleNode('./w:p',$n);if($p){[void]$p.AppendChild($r)}else{[void]$content.AppendChild($r)};$texts=@($t)
 }
 for($i=1;$i -lt $texts.Count;$i++){$texts[$i].InnerText=''}
 Set-UniversalTextNode $texts[0] $value
 $placeholder=$s.SelectSingleNode('./w:sdtPr/w:showingPlcHdr',$n);if($placeholder){[void]$placeholder.ParentNode.RemoveChild($placeholder)}
}
function Get-UniversalWordControlMarker($control,$config,$markers,$n){
 $idNode=$control.SelectSingleNode('./w:sdtPr/w:id',$n);$id=if($idNode){$idNode.GetAttribute('val',$script:ns)}else{''}
 $tagNode=$control.SelectSingleNode('./w:sdtPr/w:tag',$n);$tag=if($tagNode){$tagNode.GetAttribute('val',$script:ns)}else{''}
 $aliasNode=$control.SelectSingleNode('./w:sdtPr/w:alias',$n);$alias=if($aliasNode){$aliasNode.GetAttribute('val',$script:ns)}else{''}
 $bound=@(Get-UniversalFields $config | Where-Object {$_.WordId -and $_.WordId -eq $id})
 if($bound.Count){return [string]$bound[0].Marker}
 if($markers.ContainsKey($tag)){return $tag}
 if($markers.ContainsKey($alias)){return $alias}
 return ''
}
function Set-UniversalXml($x,$config,$values,[datetime]$admission,$hits,$details=$null){
 $n=[Xml.XmlNamespaceManager]::new($x.NameTable);$n.AddNamespace('w',$script:ns)
 $markers=Get-UniversalMarkerValues $config $values $admission $details
 # A separate clarification cannot be placed inside another filled Word control:
 # filling its parent would erase the clarification after a literal marker hit.
 $separateDetails=@(Get-UniversalFields $config | Where-Object {$_.Type -eq 'choice_detail' -and (Get-UniversalDetailWordPosition $_) -eq 'marker'})
 if($separateDetails.Count){
  foreach($control in $x.SelectNodes('//w:sdt',$n)){
   $controlKey=Get-UniversalWordControlMarker $control $config $markers $n
   if(-not $controlKey){continue}
   $originalText=(($control.SelectNodes('.//w:t',$n) | ForEach-Object {$_.InnerText}) -join '')
   foreach($field in $separateDetails){
    $detailKey=[string]$field.DetailMarker
    if($controlKey -eq $detailKey){continue}
    $inside=$originalText.Contains('{{'+$detailKey+'}}')
    if(-not $inside){foreach($child in $control.SelectNodes('.//w:sdt',$n)){if((Get-UniversalWordControlMarker $child $config $markers $n) -eq $detailKey){$inside=$true;break}}}
    if($inside){throw ('Маркер уточнения {{'+$detailKey+'}} находится внутри элемента Word {{'+$controlKey+'}}, содержимое которого заменяется. Вынесите уточнение в отдельный абзац или элемент Word.')}
   }
  }
 }
 # First fill literal markers. Only matches present in the ORIGINAL paragraph are replaced.
 # This also works when Word has split {{MARKER}} into multiple runs.
 foreach($p in $x.SelectNodes('//w:p',$n)){
  # Normal paragraphs, including table cells. Nested text-box paragraphs are handled themselves.
  $texts=@($p.SelectNodes('.//w:t',$n) | Where-Object {[object]::ReferenceEquals($_.SelectSingleNode('ancestor::w:p[1]',$n),$p)})
  $starts=@();$full='';foreach($t in $texts){$starts+=,$full.Length;$full+=$t.InnerText}
  $matches=[regex]::Matches($full,'\{\{([A-Z][A-Z0-9_]*)\}\}')
  for($mi=$matches.Count-1;$mi -ge 0;$mi--){
   $m=$matches[$mi];$key=$m.Groups[1].Value
   if(-not $markers.ContainsKey($key)){throw ('В шаблоне найден неизвестный маркер {{'+$key+'}}. Добавьте поле или исправьте шаблон.')}
   $hits[$key]=$true;$start=$m.Index;$end=$start+$m.Length
   $first=-1;$last=-1
   for($ti=0;$ti -lt $texts.Count;$ti++){
    if($starts[$ti] -le $start -and ($starts[$ti]+$texts[$ti].InnerText.Length) -gt $start){$first=$ti}
    if($starts[$ti] -lt $end -and ($starts[$ti]+$texts[$ti].InnerText.Length) -ge $end){$last=$ti;break}
   }
   if($first -lt 0 -or $last -lt 0){throw 'Не удалось определить границы маркера Word.'}
   $prefix=$texts[$first].InnerText.Substring(0,($start-$starts[$first]))
   $suffix=$texts[$last].InnerText.Substring($end-$starts[$last])
   if($first -eq $last){Set-UniversalTextNode $texts[$first] ($prefix+[string]$markers[$key]+$suffix)}
   else{
    $texts[$last].InnerText=$suffix
    for($ti=$first+1;$ti -lt $last;$ti++){$texts[$ti].InnerText=''}
    Set-UniversalTextNode $texts[$first] ($prefix+[string]$markers[$key])
   }
  }
 }
 foreach($s in $x.SelectNodes('//w:sdt',$n)){
  $key=Get-UniversalWordControlMarker $s $config $markers $n
  if($key){Set-UniversalControlValue $s ([string]$markers[$key]) $n;$hits[$key]=$true}
 }
}
function New-UniversalParagraph([string]$text,[string]$style=''){
 $safe=[Security.SecurityElement]::Escape($text)
 $ppr=if($style){'<w:pPr><w:pStyle w:val="'+$style+'"/></w:pPr>'}else{''}
 return ('<w:p>'+$ppr+'<w:r><w:t xml:space="preserve">'+$safe+'</w:t></w:r></w:p>')
}
function Write-UniversalZipText($zip,$name,[string]$text){
 $entry=$zip.CreateEntry($name,[IO.Compression.CompressionLevel]::Optimal);$stream=$entry.Open()
 try{$bytes=[Text.UTF8Encoding]::new($false).GetBytes($text);$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
}
function New-UniversalTemplate($path,$config){
 Assert-UniversalConfig $config
 $title=if($config.DocumentTitle){[string]$config.DocumentTitle}else{'Первичный осмотр'}
 $dateLabel=if($config.DateTimeLabel){[string]$config.DateTimeLabel}else{'Дата и время поступления'}
 $body=New-UniversalParagraph $title 'Title'
 $body+=New-UniversalParagraph ($dateLabel+': {{ADMISSION_DATETIME}}')
 foreach($section in $config.Sections){
  $body+=New-UniversalParagraph ([string]$section.Title) 'Heading1'
  foreach($f in $section.Fields){
   if($f.Type -eq 'heading'){$body+=New-UniversalParagraph ('{{'+$f.Marker+'}}') 'Heading1';continue}
   $text=if(@($section.Fields).Count -eq 1 -and $f.Label -eq $section.Title){'{{'+$f.Marker+'}}'}else{$f.Label+': {{'+$f.Marker+'}}'}
   $body+=New-UniversalParagraph $text
   if($f.Type -eq 'choice_detail' -and (Get-UniversalDetailWordPosition $f) -eq 'marker'){
    $body+=New-UniversalParagraph ('{{'+$f.DetailMarker+'}}')
   }
  }
 }
 $body+='<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1417" w:header="0" w:footer="0" w:gutter="0"/></w:sectPr>'
 $doc='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="'+$script:ns+'"><w:body>'+$body+'</w:body></w:document>'
 $styles='<?xml version="1.0" encoding="UTF-8"?><w:styles xmlns:w="'+$script:ns+'"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/><w:sz w:val="24"/><w:color w:val="000000"/><w:lang w:val="ru-RU"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style><w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:after="220"/><w:jc w:val="center"/></w:pPr><w:rPr><w:b/><w:sz w:val="28"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:before="200" w:after="80"/><w:outlineLvl w:val="0"/></w:pPr><w:rPr><w:b/></w:rPr></w:style></w:styles>'
 $types='<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>'
 $rels='<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>'
 $docrels='<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'
 $z=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Create)
 try{
  Write-UniversalZipText $z '[Content_Types].xml' $types;Write-UniversalZipText $z '_rels/.rels' $rels
  Write-UniversalZipText $z 'word/document.xml' $doc;Write-UniversalZipText $z 'word/styles.xml' $styles
  Write-UniversalZipText $z 'word/_rels/document.xml.rels' $docrels
 }finally{$z.Dispose()}
}
# v50: store selection and free clarification separately, combine only for output.
function Get-UniversalExportValues($config,$values,$details,[bool]$requireChoice=$false,[bool]$forWord=$false){
 $result=@{}
 foreach($f in Get-UniversalFields $config){
  $value=[string]$values[[string]$f.Id]
  if($f.Type -eq 'heading'){$value=[string]$f.Label}
  if($f.Type -in @('multi','repeat')){$value=(@([regex]::Split($value,'\r\n|\r|\n') | Where-Object {-not [string]::IsNullOrWhiteSpace($_)} | ForEach-Object {if($_ -match '^\s*[-•]\s'){$_}else{'- '+$_}}) -join "`r`n")}
  if($f.Type -eq 'choice_detail' -and $null -ne $details){
   $extra=([string]$details[[string]$f.Id]).Trim()
   $position='after';if($forWord){$position=Get-UniversalDetailWordPosition $f}
   if($extra){
    if([string]::IsNullOrWhiteSpace($value)){
     if($requireChoice){throw ('Для поля «'+$f.Label+'» сначала выберите вариант из списка.')}
     if($position -ne 'marker'){$value=$extra}
    }else{
     switch($position){
      'before' {$value=$extra.TrimEnd(':')+': '+$value.Trim()}
      'newline' {$value=$value.TrimEnd()+"`r`n"+$extra}
      'marker' { }
      default {$value=$value.TrimEnd().TrimEnd(':')+': '+$extra}
     }
    }
   }
  }
  $result[[string]$f.Id]=$value
 }
 return $result
}
function Clear-UniversalDetail([string]$id){
 $script:universalDetails[$id]=''
 if($script:universalDetailInputs.ContainsKey($id)){$script:universalDetailInputs[$id].Text=''}
}
function Get-UniversalState {
 return [pscustomobject]@{Version=49;Schema=(Copy-UniversalObject $script:universalConfig);Values=$script:universalValues;Details=$script:universalDetails;AdmissionDateTime=$script:admissionControl.Value.ToString('yyyy-MM-ddTHH:mm:ss')}
}
function Read-UniversalDocumentState($path){
 $z=[IO.Compression.ZipFile]::OpenRead($path)
 try{
  $x=Get-XmlPart $z 'customXml/mc49.xml';if(-not $x){return $null}
  return ([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($x.DocumentElement.InnerText)) | ConvertFrom-Json)
 }finally{$z.Dispose()}
}
function Restore-UniversalState($state){
 Assert-UniversalConfig $state.Schema
 $script:universalConfig=Copy-UniversalObject $state.Schema;$script:universalValues=@{}
 if($state.Values -is [System.Collections.IDictionary]){foreach($key in $state.Values.Keys){$script:universalValues[[string]$key]=[string]$state.Values[$key]}}
 elseif($state.Values){foreach($p in $state.Values.PSObject.Properties){$script:universalValues[$p.Name]=[string]$p.Value}}
 $script:universalDetails=@{};$script:universalDetailInputs=@{}
 if($state.Details -is [System.Collections.IDictionary]){foreach($key in $state.Details.Keys){$script:universalDetails[[string]$key]=[string]$state.Details[$key]}}
 elseif($state.Details){foreach($p in $state.Details.PSObject.Properties){$script:universalDetails[$p.Name]=[string]$p.Value}}
 $date=[datetime]::MinValue
 if($state.AdmissionDateTime -is [datetime]){$script:admissionControl.Value=[datetime]$state.AdmissionDateTime}
 elseif([datetime]::TryParseExact([string]$state.AdmissionDateTime,'yyyy-MM-ddTHH:mm:ss',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$date)){$script:admissionControl.Value=$date}
 $script:universalInputs=@{}
$script:universalMultiInputs=@{}
$script:universalRepeatInputs=@{}
 Set-UniversalDemographics
}
function Save-UniversalDocument($output,$config,$values,[datetime]$admission,$details=$script:universalDetails,[bool]$allowIncomplete=$false,[string]$documentStage=''){
 Assert-UniversalConfig $config
 if($documentStage -and $documentStage -notin @('diary','discharge')){throw 'Неизвестный этап документа.'}
 $exportValues=Get-UniversalExportValues $config $values $details (-not $allowIncomplete) $true
 $source=Get-UniversalTemplatePath $config
 if([IO.Path]::GetFullPath($source) -eq [IO.Path]::GetFullPath($output)){throw 'Нельзя перезаписать исходный шаблон.'}
 $tempSource=Join-Path ([IO.Path]::GetTempPath()) ('mc49-template-'+[guid]::NewGuid().ToString('N')+'.docx')
 $tempOut=Join-Path ([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($output))) ('mc49-'+[guid]::NewGuid().ToString('N')+'.tmp')
 $src=$null;$dst=$null;$hits=@{}
 try{
  if($config.AutoTemplate){New-UniversalTemplate $tempSource $config;$source=$tempSource}
  $src=[IO.Compression.ZipFile]::OpenRead($source);$dst=[IO.Compression.ZipFile]::Open($tempOut,[IO.Compression.ZipArchiveMode]::Create)
  $relNs='http://schemas.openxmlformats.org/package/2006/relationships'
  $rels=Get-XmlPart $src 'word/_rels/document.xml.rels'
  if(-not $rels){$rels=[xml]('<?xml version="1.0"?><Relationships xmlns="'+$relNs+'"/>')}
  foreach($r in @($rels.DocumentElement.ChildNodes)){if($r -is [Xml.XmlElement] -and $r.GetAttribute('Target') -eq '../customXml/mc49.xml'){[void]$rels.DocumentElement.RemoveChild($r)}}
  $rel=$rels.CreateElement('Relationship',$relNs);$rel.SetAttribute('Id',('rIdMC49'+[guid]::NewGuid().ToString('N')));$rel.SetAttribute('Type','http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXml');$rel.SetAttribute('Target','../customXml/mc49.xml');[void]$rels.DocumentElement.AppendChild($rel)
  foreach($entry in $src.Entries){
   if($entry.FullName -in @('customXml/mc49.xml','word/_rels/document.xml.rels')){continue}
   if($entry.FullName -match '^word/(document|header\d*|footer\d*)\.xml$'){
    $x=Get-XmlPart $src $entry.FullName;Set-UniversalXml $x $config $exportValues $admission $hits $details
    Write-UniversalZipText $dst $entry.FullName $x.OuterXml
   }elseif($entry.FullName -eq '[Content_Types].xml'){
    $x=Get-XmlPart $src $entry.FullName
    foreach($el in $x.DocumentElement.ChildNodes){if($el -is [Xml.XmlElement] -and $el.GetAttribute('ContentType') -eq 'application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml'){$el.SetAttribute('ContentType','application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml')}}
    $ctns='http://schemas.openxmlformats.org/package/2006/content-types'
    $has=$false;foreach($el in $x.DocumentElement.ChildNodes){if($el -is [Xml.XmlElement] -and $el.GetAttribute('PartName') -eq '/customXml/mc49.xml'){$has=$true}}
    if(-not $has){$el=$x.CreateElement('Override',$ctns);$el.SetAttribute('PartName','/customXml/mc49.xml');$el.SetAttribute('ContentType','application/xml');[void]$x.DocumentElement.AppendChild($el)}
    Write-UniversalZipText $dst $entry.FullName $x.OuterXml
   }else{
    $new=$dst.CreateEntry($entry.FullName,[IO.Compression.CompressionLevel]::Optimal);$inputStream=$entry.Open();$outStream=$new.Open()
    try{$inputStream.CopyTo($outStream)}finally{$inputStream.Dispose();$outStream.Dispose()}
   }
  }
  $missing=@(foreach($f in Get-UniversalFields $config){
   if(-not [string]::IsNullOrWhiteSpace([string]$exportValues[[string]$f.Id]) -and -not $hits.ContainsKey([string]$f.Marker)){$f.Label+' — {{'+$f.Marker+'}}'}
   if($f.Type -eq 'choice_detail' -and (Get-UniversalDetailWordPosition $f) -eq 'marker' -and $null -ne $details -and -not [string]::IsNullOrWhiteSpace([string]$details[[string]$f.Id]) -and -not $hits.ContainsKey([string]$f.DetailMarker)){
    $f.Label+' — уточнение {{'+$f.DetailMarker+'}}'
   }
  })
  if($missing.Count){throw ("Заполненные поля не привязаны к шаблону Word:`r`n"+($missing -join "`r`n")+"`r`nУкажите маркер/элемент Word в настройке или включите шаблон по структуре формы.")}
  if(-not ($hits.ContainsKey('ADMISSION_DATETIME') -or ($hits.ContainsKey('ADMISSION_DATE') -and $hits.ContainsKey('ADMISSION_TIME')))){throw 'В шаблоне нужен маркер {{ADMISSION_DATETIME}} либо оба маркера {{ADMISSION_DATE}} и {{ADMISSION_TIME}}.'}
  $state=[pscustomobject]@{Version=49;Schema=$config;Values=$values;Details=$details;AdmissionDateTime=$admission.ToString('yyyy-MM-ddTHH:mm:ss')}
  if($documentStage){$state | Add-Member -NotePropertyName Stage -NotePropertyValue $documentStage}
  $payload=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($state | ConvertTo-Json -Depth 40 -Compress)))
  Write-UniversalZipText $dst 'customXml/mc49.xml' ('<mc:state xmlns:mc="urn:medical-constructor:v49">'+$payload+'</mc:state>')
  Write-UniversalZipText $dst 'word/_rels/document.xml.rels' $rels.OuterXml
  $dst.Dispose();$dst=$null;$src.Dispose();$src=$null
  # Authored templates retain their own paragraph fonts unless the user explicitly chooses a common font.
  if(-not $config.PreserveTemplateFormatting){Apply-DocumentFont $tempOut}
  Move-Item -LiteralPath $tempOut -Destination $output -Force
 }finally{
  if($dst){$dst.Dispose()};if($src){$src.Dispose()}
  foreach($p in @($tempSource,$tempOut)){if(Test-Path -LiteralPath $p){Remove-Item -LiteralPath $p -Force}}
 }
}

# v53: pure completeness rules; old configurations require all main fields by default.
function Test-UniversalFieldRequired($field){
 if($field.Type -eq 'heading'){return $false}
 if($null -eq $field.PSObject.Properties['Required']){return $true}
 return [bool]$field.Required
}
function Get-UniversalMissingFields($config,$values){
 foreach($section in $config.Sections){
  foreach($field in $section.Fields){
   if((Test-UniversalFieldRequired $field) -and [string]::IsNullOrWhiteSpace([string]$values[[string]$field.Id])){
    [pscustomobject]@{Id=[string]$field.Id;Label=[string]$field.Label;Section=[string]$section.Title}
   }
  }
 }
}

# Retain repeated rows and saved options removed from the configuration.
function Get-UniversalMultiRows($options,[string]$value){
 $selected=@([regex]::Split($value,'\r\n|\r|\n') | Where-Object {-not [string]::IsNullOrWhiteSpace($_)})
 $used=New-Object 'bool[]' $selected.Count
 foreach($option in $options){
  $match=-1
  for($i=0;$i -lt $selected.Count;$i++){if(-not $used[$i] -and [string]$option -ceq $selected[$i]){$match=$i;break}}
  if($match -ge 0){$used[$match]=$true}
  [pscustomobject]@{Text=[string]$option;Checked=($match -ge 0)}
 }
 for($i=0;$i -lt $selected.Count;$i++){if(-not $used[$i]){[pscustomobject]@{Text=$selected[$i];Checked=$true}}}
}

# v55: ordered repeated choices. Duplicate entries are intentionally retained.
function Edit-UniversalRepeatItems($items,[string]$action,[int]$index=-1,[string]$text=''){
 $list=New-Object System.Collections.ArrayList
 foreach($item in $items){[void]$list.Add([string]$item)}
 switch($action){
  'Add' {if(-not [string]::IsNullOrWhiteSpace($text)){[void]$list.Add($text);$index=$list.Count-1}}
  'Remove' {if($index -ge 0 -and $index -lt $list.Count){$list.RemoveAt($index);$index=[Math]::Min($index,$list.Count-1)}}
  'Up' {if($index -gt 0 -and $index -lt $list.Count){$other=$list[$index-1];$list[$index-1]=$list[$index];$list[$index]=$other;$index--}}
  'Down' {if($index -ge 0 -and $index -lt $list.Count-1){$other=$list[$index+1];$list[$index+1]=$list[$index];$list[$index]=$other;$index++}}
  default {throw 'Неизвестное действие со списком.'}
 }
 return [pscustomobject]@{Items=@($list.ToArray());SelectedIndex=$index}
}
