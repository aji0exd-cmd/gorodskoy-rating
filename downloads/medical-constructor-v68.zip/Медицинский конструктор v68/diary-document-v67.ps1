﻿# Every diary is rendered from its own schema and answers. Word joins private
# snapshots; source templates, user Word windows and the clipboard are untouched.
function New-MedicalDiaryWordApplication {
 if([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT){throw 'Для сохранения всех дневников одним документом нужен Microsoft Word в Windows.'}
 if([Threading.Thread]::CurrentThread.GetApartmentState() -ne [Threading.ApartmentState]::STA){throw 'Запустите программу через «Медицинский конструктор.vbs» или START.cmd для объединения дневников в Word.'}
 try{return (New-Object -ComObject Word.Application -ErrorAction Stop)}catch{throw 'Не удалось запустить Microsoft Word для объединения дневников. Проверьте, что настольный Word открывается обычным способом.'}
}
function Release-MedicalDiaryComObject($value){
 if($null -ne $value -and [Runtime.InteropServices.Marshal]::IsComObject($value)){try{[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($value)}catch{}}
}
function Get-MedicalDiaryXml($archive,[string]$name){
 $entry=$archive.GetEntry($name);if(-not $entry){return $null}
 $stream=$entry.Open();$reader=$null
 try{
  $settings=New-Object Xml.XmlReaderSettings;$settings.DtdProcessing=[Xml.DtdProcessing]::Prohibit;$settings.XmlResolver=$null;$settings.MaxCharactersInDocument=67108864
  $reader=[Xml.XmlReader]::Create($stream,$settings);$xml=New-Object Xml.XmlDocument;$xml.XmlResolver=$null;$xml.Load($reader);return ,$xml
 }finally{if($reader){$reader.Dispose()};$stream.Dispose()}
}
function Set-MedicalDiaryXml($archive,[string]$name,$xml){
 $entry=$archive.GetEntry($name);if($entry){$entry.Delete()}
 $entry=$archive.CreateEntry($name,[IO.Compression.CompressionLevel]::Optimal);$stream=$entry.Open();$writer=$null
 try{$writer=[IO.StreamWriter]::new($stream,[Text.UTF8Encoding]::new($false));$writer.Write($xml.OuterXml)}finally{if($writer){$writer.Dispose()}else{$stream.Dispose()}}
}
function Remove-MedicalDiarySnapshotState([string]$path){
 $archive=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{
  $names=@('customXml/mc49.xml','customXml/mc-case.xml')
  foreach($name in $names){$entry=$archive.GetEntry($name);if($entry){$entry.Delete()}}
  $types=Get-MedicalDiaryXml $archive '[Content_Types].xml'
  if($types){
   foreach($item in @($types.DocumentElement.ChildNodes)){if($item -is [Xml.XmlElement] -and $item.GetAttribute('PartName') -in @('/customXml/mc49.xml','/customXml/mc-case.xml')){[void]$types.DocumentElement.RemoveChild($item)}}
   Set-MedicalDiaryXml $archive '[Content_Types].xml' $types
  }
  $rels=Get-MedicalDiaryXml $archive 'word/_rels/document.xml.rels'
  if($rels){
   foreach($item in @($rels.DocumentElement.ChildNodes)){if($item -is [Xml.XmlElement] -and $item.GetAttribute('Target') -in @('../customXml/mc49.xml','/customXml/mc49.xml','../customXml/mc-case.xml','/customXml/mc-case.xml')){[void]$rels.DocumentElement.RemoveChild($item)}}
   Set-MedicalDiaryXml $archive 'word/_rels/document.xml.rels' $rels
  }
 }finally{$archive.Dispose()}
}
function Get-MedicalDiaryThemeColor([string]$name,$colors){
 $aliases=@{text1='dk1';text2='dk2';background1='lt1';background2='lt2';tx1='dk1';tx2='dk2';bg1='lt1';bg2='lt2'}
 if($aliases.ContainsKey($name)){$name=$aliases[$name]}
 if($colors.ContainsKey($name)){return [string]$colors[$name]};return ''
}
function Convert-MedicalDiaryTheme($xml,$fonts,$colors){
 $w='http://schemas.openxmlformats.org/wordprocessingml/2006/main';$a='http://schemas.openxmlformats.org/drawingml/2006/main'
 foreach($node in @($xml.GetElementsByTagName('rFonts',$w))){
  foreach($entry in @(@('asciiTheme','ascii'),@('hAnsiTheme','hAnsi'),@('eastAsiaTheme','eastAsia'),@('cstheme','cs'),@('csTheme','cs'))){
   $theme=$node.GetAttribute($entry[0],$w);if(-not $theme){continue}
   $family=if($theme.StartsWith('major')){'major'}else{'minor'};$scriptType=if($theme.EndsWith('EastAsia')){'ea'}elseif($theme.EndsWith('Bidi')){'cs'}else{'latin'}
   $font=[string]$fonts[$family+':'+$scriptType];if(-not $font){$font=[string]$fonts[$family+':latin']}
   if($font){[void]$node.SetAttribute($entry[1],$w,$font);$node.RemoveAttribute($entry[0],$w)}
  }
 }
 foreach($node in @($xml.SelectNodes('//*'))){
  if($node.NamespaceURI -ne $w){continue}
  foreach($entry in @(@('themeColor','val','themeTint','themeShade'),@('themeFill','fill','themeFillTint','themeFillShade'))){
   $theme=$node.GetAttribute($entry[0],$w);if(-not $theme){continue};$color=Get-MedicalDiaryThemeColor $theme $colors;if(-not $color){continue}
   $rgb=@();for($offset=0;$offset -lt 6;$offset+=2){$rgb+=@([Convert]::ToInt32($color.Substring($offset,2),16))}
   $tint=$node.GetAttribute($entry[2],$w);$shade=$node.GetAttribute($entry[3],$w)
   if($shade){$factor=[Convert]::ToInt32($shade,16)/255.0;for($index=0;$index -lt 3;$index++){$rgb[$index]=[int][math]::Round($rgb[$index]*$factor)}}
   if($tint){$factor=[Convert]::ToInt32($tint,16)/255.0;for($index=0;$index -lt 3;$index++){$rgb[$index]=[int][math]::Round(255-(255-$rgb[$index])*$factor)}}
   $attribute=if($entry[0] -eq 'themeColor' -and $node.LocalName -ne 'color'){'color'}else{$entry[1]}
   [void]$node.SetAttribute($attribute,$w,(($rgb | ForEach-Object {$_.ToString('X2')}) -join ''));foreach($name in @($entry[0],$entry[2],$entry[3])){$node.RemoveAttribute($name,$w)}
  }
 }
 foreach($kind in @('latin','ea','cs')){foreach($node in @($xml.GetElementsByTagName($kind,$a))){
  $typeface=$node.GetAttribute('typeface')
  if($typeface -notmatch '^\+(mj|mn)-(lt|ea|cs)$'){continue}
  $family=if($matches[1] -eq 'mj'){'major'}else{'minor'};$scriptType=if($matches[2] -eq 'lt'){'latin'}else{$matches[2]}
  $font=[string]$fonts[$family+':'+$scriptType];if(-not $font){$font=[string]$fonts[$family+':latin']};if($font){[void]$node.SetAttribute('typeface',$font)}
 }}
 foreach($node in @($xml.GetElementsByTagName('schemeClr',$a))){
  $color=Get-MedicalDiaryThemeColor ($node.GetAttribute('val')) $colors;if(-not $color){continue}
  $replacement=$xml.CreateElement('a','srgbClr',$a);[void]$replacement.SetAttribute('val',$color)
  foreach($child in @($node.ChildNodes)){[void]$replacement.AppendChild($child.CloneNode($true))};[void]$node.ParentNode.ReplaceChild($replacement,$node)
 }
}
function Protect-MedicalDiarySnapshotFormatting([string]$path,[string]$prefix){
 # Imported paragraphs use unique custom styles, including their implicit
 # default paragraph style. Resolve theme colors/fonts before Word combines
 # the snapshots, so another diary's same-named style/theme cannot replace them.
 if($prefix -notmatch '^MC67_[0-9a-f]{32}_$'){throw 'Некорректный идентификатор оформления дневника.'}
 $archive=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{
  $w='http://schemas.openxmlformats.org/wordprocessingml/2006/main';$a='http://schemas.openxmlformats.org/drawingml/2006/main'
  $theme=Get-MedicalDiaryXml $archive 'word/theme/theme1.xml';$fonts=@{};$colors=@{}
  if($theme){
   $n=[Xml.XmlNamespaceManager]::new($theme.NameTable);$n.AddNamespace('a',$a)
   foreach($family in @('major','minor')){foreach($kind in @('latin','ea','cs')){$node=$theme.SelectSingleNode('//a:fontScheme/a:'+($family+'Font')+'/a:'+$kind,$n);if($node){$fonts[$family+':'+$kind]=$node.GetAttribute('typeface')}}}
   foreach($node in @($theme.SelectNodes('//a:clrScheme/*',$n))){$value=$node.FirstChild;if($value){$color=if($value.LocalName -eq 'sysClr'){$value.GetAttribute('lastClr')}else{$value.GetAttribute('val')};if($color -match '^[0-9A-Fa-f]{6}$'){$colors[$node.LocalName]=$color}}}
  }
  $styles=Get-MedicalDiaryXml $archive 'word/styles.xml';$styleMap=@{};$defaultParagraph='';$defaultCharacter='';$defaultTable=''
  if($styles){
   $n=[Xml.XmlNamespaceManager]::new($styles.NameTable);$n.AddNamespace('w',$w)
   foreach($style in @($styles.SelectNodes('/w:styles/w:style',$n))){
    $id=$style.GetAttribute('styleId',$w);$styleMap[$id]=$prefix+$id
    if($style.GetAttribute('default',$w) -in @('1','true','on')){switch($style.GetAttribute('type',$w)){'paragraph'{$defaultParagraph=$id};'character'{$defaultCharacter=$id};'table'{$defaultTable=$id}}}
   }
   if(-not $defaultParagraph -and $styleMap.ContainsKey('Normal')){$defaultParagraph='Normal'}
   if(-not $defaultCharacter -and $styleMap.ContainsKey('DefaultParagraphFont')){$defaultCharacter='DefaultParagraphFont'}
   if(-not $defaultTable -and $styleMap.ContainsKey('TableNormal')){$defaultTable='TableNormal'}
   $defaults=$styles.SelectSingleNode('/w:styles/w:docDefaults',$n)
   if($defaults){
    $base=$styles.CreateElement('w','style',$w);[void]$base.SetAttribute('type',$w,'paragraph');[void]$base.SetAttribute('customStyle',$w,'1');[void]$base.SetAttribute('styleId',$w,$prefix+'Base')
    $name=$styles.CreateElement('w','name',$w);[void]$name.SetAttribute('val',$w,$prefix+'Base');[void]$base.AppendChild($name)
    foreach($source in @($defaults.SelectSingleNode('w:pPrDefault/w:pPr',$n),$defaults.SelectSingleNode('w:rPrDefault/w:rPr',$n))){if($source){[void]$base.AppendChild($source.CloneNode($true))}}
    foreach($style in @($styles.SelectNodes('/w:styles/w:style[@w:type="paragraph"]',$n))){if(-not $style.SelectSingleNode('w:basedOn',$n)){$basedOn=$styles.CreateElement('w','basedOn',$w);[void]$basedOn.SetAttribute('val',$w,$prefix+'Base');$before=$style.SelectSingleNode('w:next|w:link|w:autoRedefine|w:hidden|w:uiPriority|w:semiHidden|w:unhideWhenUsed|w:qFormat|w:locked|w:personal|w:personalCompose|w:personalReply|w:rsid|w:pPr|w:rPr|w:tblPr|w:trPr|w:tcPr|w:tblStylePr',$n);if($before){[void]$style.InsertBefore($basedOn,$before)}else{[void]$style.AppendChild($basedOn)}}}
    [void]$styles.DocumentElement.AppendChild($base)
   }
   foreach($style in @($styles.SelectNodes('/w:styles/w:style',$n))){
    $id=$style.GetAttribute('styleId',$w);if($styleMap.ContainsKey($id)){[void]$style.SetAttribute('styleId',$w,$styleMap[$id]);[void]$style.SetAttribute('customStyle',$w,'1');$name=$style.SelectSingleNode('w:name',$n);if($name){[void]$name.SetAttribute('val',$w,$prefix+$name.GetAttribute('val',$w))};$aliases=$style.SelectSingleNode('w:aliases',$n);if($aliases){[void]$aliases.SetAttribute('val',$w,((@($aliases.GetAttribute('val',$w).Split(',') | ForEach-Object {$prefix+$_.Trim()}) -join ',')))};$style.RemoveAttribute('default',$w)}
   }
   # Keep the default declaration on the uniquely named paragraph style. Word
   # can then render an isolated snapshot identically before combination.
   foreach($defaultId in @($defaultParagraph,$defaultCharacter,$defaultTable)){if($defaultId){$style=$styles.SelectSingleNode('/w:styles/w:style[@w:styleId="'+$styleMap[$defaultId]+'"]',$n);[void]$style.SetAttribute('default',$w,'1')}}
  }
  $names=@($archive.Entries | Where-Object {$_.FullName -match '^word/.+\.xml$' -and $_.FullName -notmatch '^word/theme/'} | ForEach-Object {$_.FullName})
  foreach($name in $names){
   $xml=if($name -eq 'word/styles.xml'){$styles}else{Get-MedicalDiaryXml $archive $name};if(-not $xml){continue}
   foreach($node in @($xml.SelectNodes('//*'))){
    if($node.NamespaceURI -ne $w -or $node.LocalName -notin @('pStyle','rStyle','tblStyle','basedOn','next','link','styleLink','numStyleLink')){continue}
    $value=$node.GetAttribute('val',$w);if($styleMap.ContainsKey($value)){[void]$node.SetAttribute('val',$w,$styleMap[$value])}
   }
   if($defaultParagraph){foreach($paragraph in @($xml.GetElementsByTagName('p',$w))){
    $properties=@($paragraph.ChildNodes | Where-Object {$_ -is [Xml.XmlElement] -and $_.NamespaceURI -eq $w -and $_.LocalName -eq 'pPr'}) | Select-Object -First 1
    if(-not $properties){$properties=$xml.CreateElement('w','pPr',$w);[void]$paragraph.PrependChild($properties)}
    if(-not @($properties.ChildNodes | Where-Object {$_ -is [Xml.XmlElement] -and $_.NamespaceURI -eq $w -and $_.LocalName -eq 'pStyle'}).Count){$style=$xml.CreateElement('w','pStyle',$w);[void]$style.SetAttribute('val',$w,$styleMap[$defaultParagraph]);[void]$properties.PrependChild($style)}
   }}
   foreach($entry in @(@($defaultCharacter,'r','rPr','rStyle'),@($defaultTable,'tbl','tblPr','tblStyle'))){
    if(-not $entry[0]){continue}
    foreach($element in @($xml.GetElementsByTagName($entry[1],$w))){
     $properties=@($element.ChildNodes | Where-Object {$_ -is [Xml.XmlElement] -and $_.NamespaceURI -eq $w -and $_.LocalName -eq $entry[2]}) | Select-Object -First 1
     if(-not $properties){$properties=$xml.CreateElement('w',$entry[2],$w);[void]$element.PrependChild($properties)}
     if(-not @($properties.ChildNodes | Where-Object {$_ -is [Xml.XmlElement] -and $_.NamespaceURI -eq $w -and $_.LocalName -eq $entry[3]}).Count){$style=$xml.CreateElement('w',$entry[3],$w);[void]$style.SetAttribute('val',$w,$styleMap[$entry[0]]);[void]$properties.PrependChild($style)}
    }
   }
   if($name -eq 'word/numbering.xml'){
    $n=[Xml.XmlNamespaceManager]::new($xml.NameTable);$n.AddNamespace('w',$w)
    foreach($abstract in @($xml.SelectNodes('/w:numbering/w:abstractNum',$n))){
     foreach($identity in @('nsid','tmpl')){
      $node=$abstract.SelectSingleNode('w:'+$identity,$n)
      if(-not $node){$node=$xml.CreateElement('w',$identity,$w);if($identity -eq 'nsid'){[void]$abstract.PrependChild($node)}else{$before=$abstract.SelectSingleNode('w:name|w:styleLink|w:numStyleLink|w:lvl',$n);if($before){[void]$abstract.InsertBefore($node,$before)}else{[void]$abstract.AppendChild($node)}}}
      [void]$node.SetAttribute('val',$w,[guid]::NewGuid().ToString('N').Substring(0,8).ToUpperInvariant())
     }
    }
    $runDefaults=$null
    if($styles){$sn=[Xml.XmlNamespaceManager]::new($styles.NameTable);$sn.AddNamespace('w',$w);$runDefaults=$styles.SelectSingleNode('/w:styles/w:docDefaults/w:rPrDefault/w:rPr',$sn)}
    if($runDefaults){foreach($level in @($xml.SelectNodes('//w:lvl',$n))){
     $properties=$level.SelectSingleNode('w:rPr',$n)
     if(-not $properties){$properties=$xml.CreateElement('w','rPr',$w);[void]$level.AppendChild($properties)}
     foreach($property in @($runDefaults.ChildNodes)){
      if($property -isnot [Xml.XmlElement]){continue}
      $existing=$properties.SelectSingleNode('w:'+$property.LocalName,$n)
      if(-not $existing){[void]$properties.AppendChild($xml.ImportNode($property,$true))}
      elseif($property.LocalName -eq 'rFonts'){foreach($attribute in @($property.Attributes)){if(-not $existing.HasAttribute($attribute.LocalName,$attribute.NamespaceURI)){[void]$existing.SetAttribute($attribute.LocalName,$attribute.NamespaceURI,$attribute.Value)}}}
     }
    }}
   }
   Convert-MedicalDiaryTheme $xml $fonts $colors;Set-MedicalDiaryXml $archive $name $xml
  }
 }finally{$archive.Dispose()}
}
function Copy-MedicalDiaryWordSection($source,$destination){
 $sourceSetup=$null;$targetSetup=$null;$sourceColumns=$null;$targetColumns=$null;$sourceHeaders=$null;$targetHeaders=$null;$sourceFooters=$null;$targetFooters=$null
 try{
  $sourceSetup=$source.PageSetup;$targetSetup=$destination.PageSetup
  foreach($name in @('Orientation','PageWidth','PageHeight','TopMargin','BottomMargin','LeftMargin','RightMargin','Gutter','GutterPos','HeaderDistance','FooterDistance','DifferentFirstPageHeaderFooter','OddAndEvenPagesHeaderFooter','MirrorMargins','VerticalAlignment','SectionStart','SuppressEndnotes')){$targetSetup.$name=$sourceSetup.$name}
  $sourceColumns=$sourceSetup.TextColumns;$targetColumns=$targetSetup.TextColumns
  [void]$targetColumns.SetCount([int]$sourceColumns.Count);$targetColumns.EvenlySpaced=$sourceColumns.EvenlySpaced;$targetColumns.LineBetween=$sourceColumns.LineBetween
  for($index=1;$index -le [int]$sourceColumns.Count;$index++){$from=$null;$to=$null;try{$from=$sourceColumns.Item($index);$to=$targetColumns.Item($index);$to.Width=$from.Width;$to.SpaceAfter=$from.SpaceAfter}finally{Release-MedicalDiaryComObject $from;Release-MedicalDiaryComObject $to}}
  $sourceHeaders=$source.Headers;$targetHeaders=$destination.Headers;$sourceFooters=$source.Footers;$targetFooters=$destination.Footers
  foreach($pair in @(@($sourceHeaders,$targetHeaders),@($sourceFooters,$targetFooters))){
   for($index=1;$index -le 3;$index++){
    $from=$null;$to=$null;$fromRange=$null;$toRange=$null;$fromNumbers=$null;$toNumbers=$null
    try{
     $from=$pair[0].Item($index);$to=$pair[1].Item($index)
     if($from.Exists){
      $to.Exists=$true;$to.LinkToPrevious=$false;$toRange=$to.Range
      $fromRange=$from.Range;$toRange.FormattedText=$fromRange.FormattedText
      $fromNumbers=$from.PageNumbers
      if([int]$fromNumbers.Count -gt 0){$toNumbers=$to.PageNumbers;foreach($setting in @('RestartNumberingAtSection','StartingNumber','NumberStyle')){$toNumbers.$setting=$fromNumbers.$setting}}
     }else{
      # Accessing Range on an absent first/even header can fail in Word.
      # Explicitly remove it without opening or inheriting its predecessor.
      $to.LinkToPrevious=$false
      if($to.Exists){$toRange=$to.Range;$toRange.Text=''}
      $to.Exists=$false
     }
    }finally{Release-MedicalDiaryComObject $fromNumbers;Release-MedicalDiaryComObject $toNumbers;Release-MedicalDiaryComObject $fromRange;Release-MedicalDiaryComObject $toRange;Release-MedicalDiaryComObject $from;Release-MedicalDiaryComObject $to}
   }
  }
 }finally{foreach($value in @($sourceSetup,$targetSetup,$sourceColumns,$targetColumns,$sourceHeaders,$targetHeaders,$sourceFooters,$targetFooters)){Release-MedicalDiaryComObject $value}}
}
function Merge-MedicalDiaryWordSnapshots([string[]]$snapshots,[string]$output){
 if($snapshots.Count -eq 0){throw 'Добавьте хотя бы один дневник.'}
 $word=$null;$documents=$null;$destination=$null;$source=$null;$targetSections=$null;$sourceSections=$null;$range=$null
 try{
  $word=New-MedicalDiaryWordApplication;$word.Visible=$false;$word.DisplayAlerts=0;$word.AutomationSecurity=3;$documents=$word.Documents
  # The destination is a private writable snapshot. No original template opens
  # in Word, and incoming snapshots are read-only and absent from recent files.
  $destination=$documents.Open($snapshots[0],$false,$false,$false)
  $destination.UpdateStylesOnOpen=$false
  for($index=1;$index -lt $snapshots.Count;$index++){
   try{
    $source=$documents.Open($snapshots[$index],$false,$true,$false);$sourceSections=$source.Sections;$targetSections=$destination.Sections;$before=[int]$targetSections.Count
    $content=$null;try{$content=$destination.Content;$position=[int]$content.End-1}finally{Release-MedicalDiaryComObject $content}
    $range=$destination.Range($position,$position);[void]$range.InsertBreak(2);Release-MedicalDiaryComObject $range;$range=$null
    $content=$null;try{$content=$destination.Content;$position=[int]$content.End-1}finally{Release-MedicalDiaryComObject $content}
    $range=$destination.Range($position,$position);[void]$range.InsertFile($snapshots[$index],[Type]::Missing,$false,$false,$false);Release-MedicalDiaryComObject $range;$range=$null
    if([int]$targetSections.Count -ne ($before+[int]$sourceSections.Count)){throw 'Word не сохранил структуру разделов дневника при объединении. Документ не заменён.'}
    for($number=1;$number -le [int]$sourceSections.Count;$number++){
     $from=$null;$to=$null;try{$from=$sourceSections.Item($number);$to=$targetSections.Item($before+$number);Copy-MedicalDiaryWordSection $from $to}finally{Release-MedicalDiaryComObject $from;Release-MedicalDiaryComObject $to}
    }
   }finally{
    Release-MedicalDiaryComObject $range;$range=$null;Release-MedicalDiaryComObject $sourceSections;$sourceSections=$null;Release-MedicalDiaryComObject $targetSections;$targetSections=$null
    if($source){try{[void]$source.Close(0)}catch{};Release-MedicalDiaryComObject $source;$source=$null}
   }
  }
  [void]$destination.Repaginate();[void]$destination.SaveAs2($output,12)
 }finally{
  foreach($value in @($range,$sourceSections,$targetSections)){Release-MedicalDiaryComObject $value}
  if($source){try{[void]$source.Close(0)}catch{};Release-MedicalDiaryComObject $source}
  if($destination){try{[void]$destination.Close(0)}catch{};Release-MedicalDiaryComObject $destination}
  Release-MedicalDiaryComObject $documents
  if($word){try{[void]$word.Quit(0)}catch{};Release-MedicalDiaryComObject $word}
 }
}
function Set-MedicalDiariesDocumentState([string]$path,$contexts){
 # Replace the first diary's single-form state with a collection marker. This
 # filled patient document must never be accepted as an empty form/template.
 # Save Card separately adds the complete hospitalization state afterwards.
 $payload=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(([pscustomobject]@{Version=67;Stage='diaries';Diaries=@($contexts | ForEach-Object {[pscustomobject]@{Id=$_.Id;Title=$_.Title;Schema=$_.Schema;Values=$_.Values;Details=$_.Details;DateTime=$_.DateTime.ToString('yyyy-MM-ddTHH:mm:ss')}})} | ConvertTo-Json -Depth 40 -Compress)))
 $archive=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{
  if(-not $archive.GetEntry('word/document.xml')){throw 'Word не создал документ дневников.'}
  $types=Get-MedicalDiaryXml $archive '[Content_Types].xml';if(-not $types){throw 'Word не создал список частей документа дневников.'}
  $rels=Get-MedicalDiaryXml $archive 'word/_rels/document.xml.rels';$r='http://schemas.openxmlformats.org/package/2006/relationships';$c='http://schemas.openxmlformats.org/package/2006/content-types'
  if(-not $rels){$rels=[xml]('<Relationships xmlns="'+$r+'"/>')}
  foreach($item in @($rels.DocumentElement.ChildNodes)){if($item -is [Xml.XmlElement] -and $item.GetAttribute('Target') -in @('../customXml/mc49.xml','/customXml/mc49.xml')){[void]$rels.DocumentElement.RemoveChild($item)}}
  $rel=$rels.CreateElement('Relationship',$r);[void]$rel.SetAttribute('Id',('rIdMCDiary'+[guid]::NewGuid().ToString('N')));[void]$rel.SetAttribute('Type','http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXml');[void]$rel.SetAttribute('Target','../customXml/mc49.xml');[void]$rels.DocumentElement.AppendChild($rel)
  foreach($item in @($types.DocumentElement.ChildNodes)){if($item -is [Xml.XmlElement] -and $item.GetAttribute('PartName') -ieq '/customXml/mc49.xml'){[void]$types.DocumentElement.RemoveChild($item)}}
  $override=$types.CreateElement('Override',$c);[void]$override.SetAttribute('PartName','/customXml/mc49.xml');[void]$override.SetAttribute('ContentType','application/xml');[void]$types.DocumentElement.AppendChild($override)
  Set-MedicalDiaryXml $archive '[Content_Types].xml' $types;Set-MedicalDiaryXml $archive 'word/_rels/document.xml.rels' $rels
  Set-MedicalDiaryXml $archive 'customXml/mc49.xml' ([xml]('<mc:state xmlns:mc="urn:medical-constructor:v49">'+$payload+'</mc:state>'))
 }finally{$archive.Dispose()}
}
function Export-MedicalDiariesDocument([string]$path,[bool]$allowIncomplete=$false){
 $target=[IO.Path]::GetFullPath($path);$contexts=@(Get-MedicalClinicalDiaryContexts)
 if($contexts.Count -eq 0){throw 'Добавьте хотя бы один дневник перед сохранением документа.'}
 if([IO.Path]::GetExtension($target) -ine '.docx'){throw 'Документ дневников сохраняется в формате DOCX.'}
 foreach($context in $contexts){
  [void](Get-UniversalExportValues $context.Schema $context.Values $context.Details (-not $allowIncomplete) $true)
  if(-not $context.Schema.AutoTemplate){$template=[IO.Path]::GetFullPath((Get-UniversalTemplatePath $context.Schema));if([string]::Equals($target,$template,[StringComparison]::OrdinalIgnoreCase)){throw 'Нельзя сохранять дневники поверх исходного Word-шаблона.'}}
 }
 $folder=Join-Path ([IO.Path]::GetTempPath()) ('mc-diary-export-'+[guid]::NewGuid().ToString('N'));$temporary=Join-Path ([IO.Path]::GetDirectoryName($target)) ('mc-diary-'+[guid]::NewGuid().ToString('N')+'.docx')
 try{
  [void][IO.Directory]::CreateDirectory($folder);$snapshots=@();$index=0
  foreach($context in $contexts){
   $index++;$snapshot=Join-Path $folder ('diary-'+$index.ToString('D4')+'.docx')
   Save-UniversalDocument $snapshot $context.Schema $context.Values $context.DateTime $context.Details $allowIncomplete
   Protect-MedicalDiarySnapshotFormatting $snapshot ('MC67_'+[guid]::NewGuid().ToString('N')+'_');Remove-MedicalDiarySnapshotState $snapshot;$snapshots+=@($snapshot)
  }
  if($snapshots.Count -eq 1){[IO.File]::Copy($snapshots[0],$temporary,$false)}else{Merge-MedicalDiaryWordSnapshots $snapshots $temporary}
  Set-MedicalDiariesDocumentState $temporary $contexts
  if([IO.File]::Exists($target)){[IO.File]::Replace($temporary,$target,[NullString]::Value)}else{[IO.File]::Move($temporary,$target)}
 }finally{
  if([IO.File]::Exists($temporary)){[IO.File]::Delete($temporary)}
  if([IO.Directory]::Exists($folder)){[IO.Directory]::Delete($folder,$true)}
 }
}
