﻿# One rendered hospitalization is shared by Preview, Print and Save Card.
# Only private rendered snapshots open in Word; reusable templates stay closed.
function Get-MedicalHospitalizationContexts {
 if(-not $script:medicalClinicalForms){throw 'Сначала откройте или создайте форму госпитализации.'}
 $initial=Get-UniversalState
 $admission=[datetime]::ParseExact([string]$initial.AdmissionDateTime,'yyyy-MM-ddTHH:mm:ss',[Globalization.CultureInfo]::InvariantCulture)
 [pscustomobject]@{Stage='initial';Id='initial';Title='Первичный осмотр';Schema=$initial.Schema;Values=$initial.Values;Details=$initial.Details;DateTime=$admission}
 foreach($entry in @(Get-MedicalClinicalDiaryContexts)){
  # A reusable form can contain more empty diary slots than this patient's
  # selected date range. Keep the structure; export scheduled or authored notes.
  if((Get-Command Test-MedicalClinicalDiaryUnscheduled -ErrorAction SilentlyContinue) -and (Test-MedicalClinicalDiaryUnscheduled $entry)){continue}
  [pscustomobject]@{Stage='diary';Id=$entry.Id;Title=$entry.Title;Schema=$entry.Schema;Values=$entry.Values;Details=$entry.Details;DateTime=$entry.DateTime}
 }
 # A newly created discharge keeps unmodified fields linked to the initial
 # examination. Explicit patient overrides belong to the discharge itself.
 Sync-MedicalDischargeFromInitial
 $discharge=Get-MedicalClinicalContext 'discharge'
 [pscustomobject]@{Stage='discharge';Id='discharge';Title='Выписной эпикриз';Schema=$discharge.Schema;Values=$discharge.Values;Details=$discharge.Details;DateTime=$discharge.DateTime}
}
function Set-MedicalHospitalizationDocumentState([string]$path,$contexts){
 # Filled multi-stage exports cannot be reopened as reusable Word templates.
 # Save Card adds the complete restorable mc-case envelope after this step.
 $stages=@(foreach($context in $contexts){[pscustomobject]@{Stage=$context.Stage;Id=$context.Id;Title=$context.Title;Schema=$context.Schema;Values=$context.Values;Details=$context.Details;DateTime=$context.DateTime.ToString('yyyy-MM-ddTHH:mm:ss')}})
 $payload=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(([pscustomobject]@{Version=68;Stage='hospitalization';NoTemplate=$true;Stages=$stages} | ConvertTo-Json -Depth 50 -Compress)))
 $archive=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{
  if(-not $archive.GetEntry('word/document.xml')){throw 'Word не создал документ госпитализации.'}
  $types=Get-MedicalDiaryXml $archive '[Content_Types].xml';if(-not $types){throw 'Word не создал список частей документа госпитализации.'}
  $rels=Get-MedicalDiaryXml $archive 'word/_rels/document.xml.rels';$r='http://schemas.openxmlformats.org/package/2006/relationships';$c='http://schemas.openxmlformats.org/package/2006/content-types'
  if(-not $rels){$rels=[xml]('<Relationships xmlns="'+$r+'"/>')}
  foreach($item in @($rels.DocumentElement.ChildNodes)){if($item -is [Xml.XmlElement] -and $item.GetAttribute('Target') -in @('../customXml/mc49.xml','/customXml/mc49.xml')){[void]$rels.DocumentElement.RemoveChild($item)}}
  $rel=$rels.CreateElement('Relationship',$r);[void]$rel.SetAttribute('Id',('rIdMCHospitalization'+[guid]::NewGuid().ToString('N')));[void]$rel.SetAttribute('Type','http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXml');[void]$rel.SetAttribute('Target','../customXml/mc49.xml');[void]$rels.DocumentElement.AppendChild($rel)
  foreach($item in @($types.DocumentElement.ChildNodes)){if($item -is [Xml.XmlElement] -and $item.GetAttribute('PartName') -ieq '/customXml/mc49.xml'){[void]$types.DocumentElement.RemoveChild($item)}}
  $override=$types.CreateElement('Override',$c);[void]$override.SetAttribute('PartName','/customXml/mc49.xml');[void]$override.SetAttribute('ContentType','application/xml');[void]$types.DocumentElement.AppendChild($override)
  Set-MedicalDiaryXml $archive '[Content_Types].xml' $types;Set-MedicalDiaryXml $archive 'word/_rels/document.xml.rels' $rels
  Set-MedicalDiaryXml $archive 'customXml/mc49.xml' ([xml]('<mc:state xmlns:mc="urn:medical-constructor:v49">'+$payload+'</mc:state>'))
 }finally{$archive.Dispose()}
}
function Export-MedicalHospitalizationDocument([string]$path,[bool]$allowIncomplete=$false){
 $target=[IO.Path]::GetFullPath($path)
 if([IO.Path]::GetExtension($target) -ine '.docx'){throw 'Карта госпитализации сохраняется в формате DOCX.'}
 $contexts=@(Get-MedicalHospitalizationContexts)
 # Empty reusable diary slots can be omitted from this patient's document,
 # but their source templates are still part of the form and stay protected.
 $allSchemas=@($script:universalConfig)
 foreach($definition in @($script:medicalClinicalForms.Diaries)){$allSchemas+=@($definition.Schema)}
 if($script:medicalClinicalForms.Discharge){$allSchemas+=@($script:medicalClinicalForms.Discharge.Schema)}
 foreach($schema in $allSchemas){
  $source=Get-UniversalTemplatePath $schema
  if($source -and [string]::Equals($target,[IO.Path]::GetFullPath($source),[StringComparison]::OrdinalIgnoreCase)){throw 'Нельзя сохранять карту поверх исходного Word-шаблона формы.'}
 }
 foreach($context in $contexts){
  if(-not $allowIncomplete){
   $missing=@(Get-UniversalMissingFields $context.Schema $context.Values)
   if($missing.Count){throw ('Заполните обязательные поля этапа «'+$context.Title+'»: '+(($missing | ForEach-Object {$_.Label}) -join ', ')+'.')}
   foreach($field in Get-UniversalFields $context.Schema){
    if($field.System -eq 'birth' -and -not [string]::IsNullOrWhiteSpace([string]$context.Values[[string]$field.Id])){
     $birth=[datetime]::MinValue
     if(-not [datetime]::TryParseExact([string]$context.Values[[string]$field.Id],'dd.MM.yyyy',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$birth)){throw ('Дата рождения в этапе «'+$context.Title+'» должна быть в формате ДД.ММ.ГГГГ.')}
    }
   }
  }
  [void](Get-UniversalExportValues $context.Schema $context.Values $context.Details (-not $allowIncomplete) $true)
  $source=Get-UniversalTemplatePath $context.Schema
  if($source -and [string]::Equals($target,[IO.Path]::GetFullPath($source),[StringComparison]::OrdinalIgnoreCase)){throw ('Нельзя сохранять карту поверх исходного Word-шаблона: '+$context.Title+'.')}
  if(-not $context.Schema.AutoTemplate -and -not [IO.File]::Exists($source)){throw ('Не найден Word-шаблон «'+$context.Title+'». Откройте форму со всеми шаблонами или выберите шаблон в редакторе этого этапа.')}
 }
 $folder=Join-Path ([IO.Path]::GetTempPath()) ('mc-hospitalization-export-'+[guid]::NewGuid().ToString('N'))
 $temporary=Join-Path ([IO.Path]::GetDirectoryName($target)) ('mc-hospitalization-'+[guid]::NewGuid().ToString('N')+'.docx')
 try{
  [void][IO.Directory]::CreateDirectory($folder);$snapshots=@();$index=0
  foreach($context in $contexts){
   $index++;$snapshot=Join-Path $folder ($index.ToString('D4')+'-'+$context.Stage+'.docx')
   $documentStage=if($context.Stage -eq 'initial'){''}else{$context.Stage}
   Save-UniversalDocument $snapshot $context.Schema $context.Values $context.DateTime $context.Details $allowIncomplete $documentStage
   if($context.Stage -eq 'discharge' -and (Get-Command Set-MedicalDischargePeriodDocument -ErrorAction SilentlyContinue)){Set-MedicalDischargePeriodDocument $snapshot $context.Schema}
   Protect-MedicalDiarySnapshotFormatting $snapshot ('MC67_'+[guid]::NewGuid().ToString('N')+'_')
   Remove-MedicalDiarySnapshotState $snapshot;$snapshots+=@($snapshot)
  }
  # Initial examination and discharge are present even without diary records.
  # Word preserves individual section layouts, headers, styles and resources.
  Merge-MedicalDiaryWordSnapshots $snapshots $temporary
  Set-MedicalHospitalizationDocumentState $temporary $contexts
  if([IO.File]::Exists($target)){[IO.File]::Replace($temporary,$target,[NullString]::Value)}else{[IO.File]::Move($temporary,$target)}
 }finally{
  if([IO.File]::Exists($temporary)){[IO.File]::Delete($temporary)}
  if([IO.Directory]::Exists($folder)){[IO.Directory]::Delete($folder,$true)}
 }
}
