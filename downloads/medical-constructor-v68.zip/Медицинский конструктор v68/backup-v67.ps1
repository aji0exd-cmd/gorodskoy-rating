﻿# Durable session checkpoints. Reusable forms still contain no patient answers.
$script:medicalBackupPath=''
$script:medicalBackupBusy=$false
$script:medicalBackupLastError=''
$script:medicalBackupFormSavedSignature=''
$script:medicalBackupCaseSavedSignature=''
$script:medicalBackupEditorDraft=$null
$script:medicalBackupRetainedDraft=$null
$script:medicalBackupPendingDeferred=$false

function Get-MedicalBackupProperty($value,[string]$name){
 if($null -eq $value){return $null}
 if($value -is [Collections.IDictionary]){return $value[$name]}
 return $value.$name
}
function Copy-MedicalBackupValue($value){
 if($null -eq $value){return $null}
 return ($value | ConvertTo-Json -Depth 100 -Compress | ConvertFrom-Json)
}
function ConvertTo-MedicalBackupCanonicalValue($value){
 if($null -eq $value){return $null}
 if($value -is [string] -or $value -is [ValueType]){return $value}
 if($value -is [Collections.IDictionary]){
  $result=[ordered]@{}
  foreach($key in @($value.Keys | ForEach-Object {[string]$_} | Sort-Object -CaseSensitive)){$result[$key]=ConvertTo-MedicalBackupCanonicalValue $value[$key]}
  return [pscustomobject]$result
 }
 if($value -is [Collections.IEnumerable]){
  $items=@(foreach($item in $value){ConvertTo-MedicalBackupCanonicalValue $item})
  return ,$items
 }
 $result=[ordered]@{}
 foreach($property in @($value.PSObject.Properties | Sort-Object Name -CaseSensitive)){$result[$property.Name]=ConvertTo-MedicalBackupCanonicalValue $property.Value}
 return [pscustomobject]$result
}
function Get-MedicalBackupHash($value){
 $json=ConvertTo-Json -InputObject (ConvertTo-MedicalBackupCanonicalValue $value) -Depth 100 -Compress
 $bytes=[Text.Encoding]::UTF8.GetBytes($json);$hash=[Security.Cryptography.SHA256]::Create()
 try{return ([BitConverter]::ToString($hash.ComputeHash($bytes))).Replace('-','').ToLowerInvariant()}finally{$hash.Dispose()}
}
function Get-MedicalBackupBytesHash([byte[]]$bytes){
 $hash=[Security.Cryptography.SHA256]::Create()
 try{return ([BitConverter]::ToString($hash.ComputeHash($bytes))).Replace('-','').ToLowerInvariant()}finally{$hash.Dispose()}
}
function Initialize-MedicalSessionBackup([string]$programRoot=$script:medicalProgramRoot){
 $candidates=New-Object Collections.ArrayList
 if($programRoot){[void]$candidates.Add((Join-Path $programRoot 'Резервные копии'))}
 $local=[Environment]::GetFolderPath('LocalApplicationData')
 if($local){[void]$candidates.Add((Join-Path $local 'MedicalConstructor/Резервные копии'))}
 $errors=New-Object Collections.ArrayList
 foreach($folder in $candidates){
  $probe=Join-Path $folder ('.mc-write-'+[guid]::NewGuid().ToString('N')+'.tmp')
  try{
   [void][IO.Directory]::CreateDirectory($folder)
   [IO.File]::WriteAllText($probe,'checkpoint',[Text.UTF8Encoding]::new($false));[IO.File]::Delete($probe)
   $script:medicalBackupPath=Join-Path $folder 'working-session.mcbak'
   return $script:medicalBackupPath
  }catch{[void]$errors.Add($_.Exception.Message)}
  finally{if([IO.File]::Exists($probe)){[IO.File]::Delete($probe)}}
 }
 throw ('Не удалось подготовить папку резервных копий: '+($errors -join '; '))
}
function Register-MedicalEditorDraft($schema,$model,$state,$commit=$null,$controls=$null,[string]$purpose='edit'){
 if($purpose -notin @('edit','new')){throw 'Неизвестное назначение редактора формы.'}
 $token=[guid]::NewGuid().ToString('N')
 $script:medicalBackupEditorDraft=[pscustomobject]@{Token=$token;Schema=$schema;Model=$model;State=$state;Commit=$commit;Controls=$controls;Purpose=$purpose;Stage=$(if($purpose -eq 'new'){'initial'}else{[string]$script:stage});ClinicalId=$(if($purpose -eq 'new'){''}else{[string]$script:medicalActiveDiaryId})}
 $script:medicalBackupRetainedDraft=$null
 return $token
}
function Get-MedicalBackupEditorDraft {
 $draft=$script:medicalBackupEditorDraft
 if(-not $draft){return $script:medicalBackupRetainedDraft}
 $commitError=''
 if($draft.Commit){try{& $draft.Commit | Out-Null}catch{$commitError=$_.Exception.Message}}
 $state=$draft.State
 $schema=if($state -and (Get-MedicalBackupProperty $state 'Schema')){$state.Schema}else{$draft.Schema}
 $model=if($state -and (Get-MedicalBackupProperty $state 'Model')){$state.Model}else{$draft.Model}
 $controls=$null;if($draft.Controls){$controls=Copy-MedicalBackupValue (& $draft.Controls)}
 $folder=Join-Path ([IO.Path]::GetTempPath()) ('mc-draft-backup-'+[guid]::NewGuid().ToString('N'))
 [void][IO.Directory]::CreateDirectory($folder)
 $extension=if($model.TemplateExtension){[string]$model.TemplateExtension}else{'.docx'}
 $path=Join-Path $folder ('draft'+$extension)
 try{
  Write-MedicalTemplateModel $path $model
  $bytes=[IO.File]::ReadAllBytes($path)
  Test-MedicalBackupDraftSchema $schema
  $complete=$true;$validationError='';try{Assert-UniversalConfig $schema}catch{$complete=$false;$validationError=$_.Exception.Message}
  return [pscustomobject]@{Schema=(Copy-MedicalBackupValue $schema);SchemaIsComplete=$complete;SchemaValidationError=$validationError;Name=('Незавершённый шаблон'+$extension);BytesBase64=[Convert]::ToBase64String($bytes);Sha256=(Get-MedicalBackupBytesHash $bytes);Controls=$controls;CommitError=$commitError;Stage=[string]$draft.Stage;ClinicalId=[string]$draft.ClinicalId;Purpose=[string]$draft.Purpose}
 }finally{if([IO.Directory]::Exists($folder)){[IO.Directory]::Delete($folder,$true)}}
}
function Unregister-MedicalEditorDraft([string]$token,[bool]$applied=$false,[bool]$preserveDraftClose=$false){
 if(-not $script:medicalBackupEditorDraft -or $script:medicalBackupEditorDraft.Token -cne $token){return}
 if(-not $applied -and $preserveDraftClose){
  # Windows may close a modal editor before the parent closing event fires.
  # Keep its committed Word model and raw controls outside disposed widgets.
  $retained=Get-MedicalBackupEditorDraft
  $script:medicalBackupEditorDraft=$null;$script:medicalBackupRetainedDraft=$retained
  $script:medicalEditorRecoveryDraft=$retained
  [void](Write-MedicalSessionBackup)
  return
 }
 if(-not $applied){
  # Explicit Cancel discards the live draft. Its separate archive remains
  # available without automatically replacing the active form next startup.
  $saved=Write-MedicalSessionBackup
  if($saved){
   $archive=Join-Path ([IO.Path]::GetDirectoryName($saved.Path)) ('editor-draft-'+[datetime]::UtcNow.ToString('yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N')+'.mcbak')
   [IO.File]::Copy($saved.Path,$archive,$false)
  }
 }
 $script:medicalBackupRetainedDraft=$null;$script:medicalBackupEditorDraft=$null;$script:medicalEditorRecoveryDraft=$null
 if(-not $applied){
  if($script:medicalWorkspaceReady){[void](Write-MedicalSessionBackup)}else{Archive-MedicalPendingBackup}
 }
}
function Get-MedicalBackupSessionData {
 Capture-Stage
 $record=[ordered]@{
  version=49;universal=(Copy-MedicalBackupValue (Get-UniversalState));patientName=[string]$script:patientName
  birthYear=[string]$script:patientBirthControl.Text;registration=[string](Get-FullRegistration)
  registrationBase=[string]$script:patientAddressControl.Text;registrationStreet=[string]$script:streetControl.Text
  registrationHouse=[string]$script:houseControl.Text;registrationApartment=[string]$script:apartmentControl.Text
  admissionDate=$script:admissionControl.Value.ToString('yyyy-MM-dd');hospitalization=(Copy-MedicalBackupValue (Get-HospitalizationValues))
  templates=(Copy-MedicalBackupValue $script:stageTemplates);stages=(Copy-MedicalBackupValue $script:stageData)
  diaryCount=[int]$script:diaryIndex;TemplateSnapshots=(Get-MedicalCardTemplateSnapshots)
 }
 $clinical=$null;$clinicalForms=$null
 $clinicalGetter=Get-Command Get-MedicalClinicalState -CommandType Function -ErrorAction SilentlyContinue
 if($clinicalGetter){$clinical=Copy-MedicalBackupValue (& $clinicalGetter)}
 $formsGetter=Get-Command Get-MedicalClinicalPortableForms -CommandType Function -ErrorAction SilentlyContinue
 if($formsGetter){$clinicalForms=Copy-MedicalBackupValue (& $formsGetter $true)}
 return [pscustomobject]@{
  WorkspaceReady=[bool]$script:medicalWorkspaceReady;Record=[pscustomobject]$record;Clinical=$clinical;ClinicalForms=$clinicalForms;EditorDraft=(Get-MedicalBackupEditorDraft)
  Form=[pscustomobject]@{Path=[string]$script:activeMedicalFormPath;Name=[string]$script:activeMedicalFormName}
  Case=[pscustomobject]@{Path=[string]$script:caseFile;Folder=[string]$script:caseFolder;LastPatientName=$script:caseLastSavedPatientName}
  View=[pscustomobject]@{Stage=[string]$script:stage;DiaryIndex=[int]$script:diaryIndex;ActiveDiaryId=[string]$script:medicalActiveDiaryId}
 }
}
function Get-MedicalBackupFormSignature($data){
 $templates=[ordered]@{}
 foreach($stage in @('initial','diary','discharge')){
  $snapshot=Get-MedicalBackupProperty $data.Record.TemplateSnapshots $stage
  if($snapshot){$templates[$stage]=Get-MedicalBackupWordFingerprint ([Convert]::FromBase64String([string]$snapshot.BytesBase64))}
 }
 $clinicalForms=Copy-MedicalBackupValue $data.ClinicalForms
 if($clinicalForms){
  $definitions=@($clinicalForms.Diaries);if($clinicalForms.Discharge){$definitions+=@($clinicalForms.Discharge)}
  foreach($definition in $definitions){
   if($definition.TemplateBase64){
    $definition | Add-Member -NotePropertyName WordContentHash -NotePropertyValue (Get-MedicalBackupWordFingerprint ([Convert]::FromBase64String([string]$definition.TemplateBase64))) -Force
    foreach($name in @('TemplateBase64','TemplateSha256','TemplateName')){$definition.PSObject.Properties.Remove($name)}
   }
  }
 }
 return Get-MedicalBackupHash ([pscustomobject]@{Schema=$data.Record.universal.Schema;Templates=[pscustomobject]$templates;ClinicalForms=$clinicalForms})
}
function Get-MedicalBackupWordFingerprint([byte[]]$bytes){
 # ZIP timestamps vary when a generated template is rebuilt. Only actual Word
 # contents determine whether its design was changed.
 $memory=[IO.MemoryStream]::new($bytes,$false);$zip=$null;$entries=[ordered]@{}
 try{
  $zip=[IO.Compression.ZipArchive]::new($memory,[IO.Compression.ZipArchiveMode]::Read,$true)
  foreach($entry in @($zip.Entries | Sort-Object FullName -CaseSensitive)){
   $content=[IO.MemoryStream]::new();$stream=$entry.Open()
   try{$stream.CopyTo($content);$entries[$entry.FullName]=Get-MedicalBackupBytesHash $content.ToArray()}finally{$stream.Dispose();$content.Dispose()}
  }
  return Get-MedicalBackupHash ([pscustomobject]$entries)
 }finally{if($zip){$zip.Dispose()};$memory.Dispose()}
}
function Get-MedicalBackupCaseSignature($data){
 # Templates and form paths are form state. Viewing another tab is not an answer edit.
 return Get-MedicalBackupHash ([pscustomobject]@{Universal=$data.Record.universal;Stages=$data.Record.stages;Hospitalization=$data.Record.hospitalization;Clinical=$data.Clinical;PatientName=$data.Record.patientName;Registration=$data.Record.registration;BirthYear=$data.Record.birthYear})
}
function Mark-MedicalFormSaved {
 if(-not $script:medicalWorkspaceReady){return}
 $data=Get-MedicalBackupSessionData
 $script:medicalBackupFormSavedSignature=Get-MedicalBackupFormSignature $data
}
function Mark-MedicalCaseSaved {
 if(-not $script:medicalWorkspaceReady){return}
 $data=Get-MedicalBackupSessionData
 $script:medicalBackupCaseSavedSignature=Get-MedicalBackupCaseSignature $data
}
function Reset-MedicalBackupSaveBaselines([bool]$formWasLoaded=$false,[bool]$caseWasLoaded=$false){
 $script:medicalBackupFormSavedSignature='';$script:medicalBackupCaseSavedSignature='';$script:medicalBackupRetainedDraft=$null
 if($formWasLoaded){Mark-MedicalFormSaved}
 # A new empty patient's state provides a comparison baseline, but no existing card.
 Mark-MedicalCaseSaved
}
function Test-MedicalBackupDraftSchema($schema){
 # The editor may contain unfinished names or duplicate provisional markers.
 # Validate its data shape, without silently installing it as an active form.
 if(-not $schema -or [int]$schema.Version -ne 49 -or $schema.AutoTemplate -isnot [bool] -or $null -eq $schema.Sections){throw 'Повреждена структура незавершённой формы.'}
 $sections=@{};$fields=@{}
 foreach($section in @($schema.Sections)){
  $id=[string]$section.Id
  if(-not $id -or $id.Length -gt 200 -or $sections.ContainsKey($id)){throw 'Повреждены идентификаторы разделов незавершённой формы.'};$sections[$id]=$true
  if($section.Title -isnot [string] -or $null -eq $section.Fields){throw 'Повреждён раздел незавершённой формы.'}
  foreach($field in @($section.Fields)){
   $id=[string]$field.Id
   if(-not $id -or $id.Length -gt 200 -or $fields.ContainsKey($id)){throw 'Повреждены идентификаторы полей незавершённой формы.'};$fields[$id]=$true
   if($field.Label -isnot [string] -or $field.Marker -isnot [string] -or $field.Type -notin @('text','multiline','choice','choice_detail','heading','multi','repeat')){throw 'Повреждено поле незавершённой формы.'}
   if($field.System -and $field.System -notin @('name','birth','address')){throw 'Повреждена роль пациента незавершённой формы.'}
   if($null -ne $field.PSObject.Properties['Required'] -and $field.Required -isnot [bool]){throw 'Повреждён признак обязательного поля незавершённой формы.'}
  }
 }
}
function Test-MedicalBackupDate($value,[string]$format,[string]$label){
 $date=[datetime]::MinValue
 if($value -is [datetime]){$text=$value.ToString($format)}else{$text=[string]$value}
 if(-not [datetime]::TryParseExact($text,$format,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$date)){throw ('Некорректная дата в резервной копии: '+$label)}
 if($date -lt [datetime]'1753-01-01' -or $date -gt [datetime]'9998-12-31T23:59:59'){throw ('Дата вне диапазона редактора: '+$label)}
 return $date
}
function Get-MedicalBackupEnvelopeHash($envelope){
 # Include close state and timestamp: a damaged flag must never hide recovery.
 $created=if($envelope.CreatedUtc -is [datetime]){$envelope.CreatedUtc.ToUniversalTime().ToString('o')}else{[string]$envelope.CreatedUtc}
 return Get-MedicalBackupHash ([pscustomobject]@{Format=$envelope.Format;Version=$envelope.Version;CreatedUtc=$created;Closed=$envelope.Closed;PayloadJson=$envelope.PayloadJson})
}
function Read-MedicalSessionBackup([string]$path){
 if(-not [IO.File]::Exists($path)){throw 'Резервная копия не найдена.'}
 if(([IO.FileInfo]$path).Length -gt 268435456){throw 'Резервная копия превышает допустимый размер.'}
 $envelope=[IO.File]::ReadAllText($path,[Text.Encoding]::UTF8) | ConvertFrom-Json
 if($envelope.Format -cne 'MedicalConstructorSession' -or $envelope.Version -is [string] -or [int]$envelope.Version -ne 1 -or $envelope.Closed -isnot [bool] -or $envelope.PayloadJson -isnot [string]){throw 'Неизвестный формат резервной копии.'}
 $created=[datetimeoffset]::MinValue
 $createdText=if($envelope.CreatedUtc -is [datetime]){$envelope.CreatedUtc.ToUniversalTime().ToString('o')}else{[string]$envelope.CreatedUtc}
 if(-not [datetimeoffset]::TryParseExact($createdText,'o',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$created) -or $created.Offset -ne [timespan]::Zero){throw 'Некорректная дата резервной копии.'}
 if((Get-MedicalBackupEnvelopeHash $envelope) -cne [string]$envelope.Sha256){throw 'Повреждена резервная копия: контрольная сумма не совпадает.'}
 $payload=$envelope.PayloadJson | ConvertFrom-Json;$data=$payload.Data;$record=$data.Record
 if(-not $record.universal -or [int]$record.version -ne 49 -or [int]$record.universal.Version -ne 49){throw 'В резервной копии отсутствует форма или неверная версия карты.'}
 Assert-UniversalConfig $record.universal.Schema
 if($null -eq $record.templates -or $null -eq $record.stages -or $null -eq $data.Form -or $null -eq $data.Case -or $null -eq $data.View){throw 'Неполное состояние резервной копии.'}
 [void](Test-MedicalBackupDate $record.universal.AdmissionDateTime 'yyyy-MM-ddTHH:mm:ss' 'поступление')
 [void](Test-MedicalBackupDate $record.admissionDate 'yyyy-MM-dd' 'карта')
 [void](Get-MedicalValidatedCardTemplateSnapshots $record.TemplateSnapshots)
 if($data.ClinicalForms){
  [void](Copy-MedicalClinicalFormData $data.ClinicalForms)
  $definitions=@($data.ClinicalForms.Diaries);if($data.ClinicalForms.Discharge){$definitions+=@($data.ClinicalForms.Discharge)}
  foreach($definition in $definitions){if($definition.PSObject.Properties['TemplateBase64']){[void](Test-MedicalFormTemplateAsset $definition)}}
 }
 if($data.Clinical){
  [void](Test-MedicalClinicalState $data.Clinical $data.ClinicalForms)
  foreach($entry in @($data.Clinical.Diaries)){[void](Test-MedicalBackupDate $entry.DateTime 'yyyy-MM-ddTHH:mm:ss' 'дневник')}
 }
 if($data.EditorDraft){
  $draft=$data.EditorDraft
  Test-MedicalBackupDraftSchema $draft.Schema
  if([string]$draft.Name -notmatch '\.(docx|dotx)$' -or $draft.BytesBase64 -isnot [string] -or $draft.BytesBase64.Length -gt 89478488){throw 'Некорректный формат незавершённого Word-шаблона.'}
  $draftBytes=[Convert]::FromBase64String([string]$draft.BytesBase64)
  if((Get-MedicalBackupBytesHash $draftBytes) -cne [string]$draft.Sha256){throw 'Повреждён незавершённый Word-шаблон.'}
  [void](Test-MedicalTemplateBytes $draftBytes)
 }
 foreach($signature in @($payload.FormSavedSignature,$payload.CaseSavedSignature)){
  if($signature -isnot [string] -or ($signature -and $signature -cnotmatch '^[a-f0-9]{64}$')){throw 'Повреждены отметки сохранения резервной копии.'}
 }
 if([string]$payload.FormSignature -cne (Get-MedicalBackupFormSignature $data) -or [string]$payload.CaseSignature -cne (Get-MedicalBackupCaseSignature $data)){throw 'Состав резервной копии не соответствует контрольным отметкам.'}
 if($data.View.Stage -notin @('initial','diary','discharge') -or [int]$data.View.DiaryIndex -lt 1){throw 'Некорректное состояние вкладок резервной копии.'}
 if($data.View.ActiveDiaryId -and @($data.ClinicalForms.Diaries | Where-Object {[string]$_.Id -ceq [string]$data.View.ActiveDiaryId}).Count -ne 1){throw 'Текущий дневник отсутствует в резервной копии.'}
 if($null -ne $data.PSObject.Properties['WorkspaceReady'] -and $data.WorkspaceReady -isnot [bool]){throw 'Некорректный признак активной формы резервной копии.'}
 if($data.EditorDraft -and $data.EditorDraft.Purpose -and $data.EditorDraft.Purpose -notin @('edit','new')){throw 'Неизвестное назначение незавершённого редактора.'}
 if($data.EditorDraft -and $data.EditorDraft.Purpose -eq 'new' -and ($data.EditorDraft.Stage -ne 'initial' -or $data.EditorDraft.ClinicalId)){throw 'Новая форма ошибочно привязана к клиническому этапу.'}
 if($data.EditorDraft -and $data.EditorDraft.Stage -and $data.EditorDraft.Stage -notin @('initial','diary','discharge')){throw 'Неизвестный этап незавершённого редактора.'}
 if($data.EditorDraft -and $data.EditorDraft.Stage -eq 'diary' -and @($data.ClinicalForms.Diaries | Where-Object {[string]$_.Id -ceq [string]$data.EditorDraft.ClinicalId}).Count -ne 1){throw 'Дневник незавершённого редактора отсутствует в резервной копии.'}
 return [pscustomobject]@{Path=$path;CreatedUtc=$createdText;Closed=[bool]$envelope.Closed;Payload=$payload}
}
function Write-MedicalSessionBackup([bool]$closed=$false){
 if(-not $script:medicalWorkspaceReady -and -not $script:medicalBackupEditorDraft -and -not $script:medicalBackupRetainedDraft){return $null}
 if($script:medicalBackupBusy){throw 'Резервное сохранение уже выполняется.'}
 $script:medicalBackupBusy=$true;$temp=''
 try{
  if(-not $script:medicalBackupPath){[void](Initialize-MedicalSessionBackup)}
  $data=Get-MedicalBackupSessionData
  $payload=[pscustomobject]@{Data=$data;FormSavedSignature=$script:medicalBackupFormSavedSignature;CaseSavedSignature=$script:medicalBackupCaseSavedSignature;FormSignature=(Get-MedicalBackupFormSignature $data);CaseSignature=(Get-MedicalBackupCaseSignature $data)}
  $json=$payload | ConvertTo-Json -Depth 100 -Compress
  $envelope=[pscustomobject]@{Format='MedicalConstructorSession';Version=1;CreatedUtc=[datetime]::UtcNow.ToString('o');Closed=$closed;PayloadJson=$json;Sha256=''}
  $envelope.Sha256=Get-MedicalBackupEnvelopeHash $envelope
  $temp=Join-Path ([IO.Path]::GetDirectoryName($script:medicalBackupPath)) ('.mc-backup-'+[guid]::NewGuid().ToString('N')+'.tmp')
  $encoded=[Text.UTF8Encoding]::new($false).GetBytes(($envelope | ConvertTo-Json -Depth 5 -Compress))
  $stream=[IO.File]::Open($temp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
  try{$stream.Write($encoded,0,$encoded.Length);$stream.Flush($true)}finally{$stream.Dispose()}
  [void](Read-MedicalSessionBackup $temp)
  if($script:medicalBackupPendingDeferred){Archive-MedicalPendingBackup;$script:medicalBackupPendingDeferred=$false}
  if([IO.File]::Exists($script:medicalBackupPath)){
   $validCurrent=$false;try{[void](Read-MedicalSessionBackup $script:medicalBackupPath);$validCurrent=$true}catch{}
   $previous=if($validCurrent){$script:medicalBackupPath+'.bak'}else{$null}
   if($validCurrent){[IO.File]::Replace($temp,$script:medicalBackupPath,$previous)}else{[IO.File]::Replace($temp,$script:medicalBackupPath,[Management.Automation.Language.NullString]::Value)}
  }else{[IO.File]::Move($temp,$script:medicalBackupPath)}
  $temp='';$script:medicalBackupLastError=''
  return (Read-MedicalSessionBackup $script:medicalBackupPath)
 }catch{$script:medicalBackupLastError=$_.Exception.Message;throw}
 finally{if($temp -and [IO.File]::Exists($temp)){[IO.File]::Delete($temp)};$script:medicalBackupBusy=$false}
}
function Get-MedicalPendingBackup {
 if(-not $script:medicalBackupPath){[void](Initialize-MedicalSessionBackup)}
 $valid=New-Object Collections.ArrayList
 foreach($path in @($script:medicalBackupPath,($script:medicalBackupPath+'.bak'))){
  if(-not [IO.File]::Exists($path)){continue}
  try{[void]$valid.Add((Read-MedicalSessionBackup $path))}catch{$script:medicalBackupLastError=$_.Exception.Message}
 }
 $latest=@($valid | Sort-Object CreatedUtc -Descending | Select-Object -First 1)
 if($latest.Count -and -not $latest[0].Closed){return $latest[0]}
 return $null
}
function Archive-MedicalPendingBackup {
 if(-not $script:medicalBackupPath){return}
 foreach($path in @($script:medicalBackupPath,($script:medicalBackupPath+'.bak'))){
  if(-not [IO.File]::Exists($path)){continue}
  $destination=Join-Path ([IO.Path]::GetDirectoryName($path)) ('session-'+[datetime]::UtcNow.ToString('yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N')+'.mcbak')
  [IO.File]::Move($path,$destination)
 }
}
function Restore-MedicalSessionBackup($backup){
 # Validate again from disk, before importing files or changing live patient state.
 if($backup -is [string]){$verified=Read-MedicalSessionBackup $backup}else{$verified=Read-MedicalSessionBackup ([string]$backup.Path)}
 $data=Copy-MedicalBackupValue $verified.Payload.Data
 $record=$data.Record
 $validated=Get-MedicalValidatedCardTemplateSnapshots $record.TemplateSnapshots
 $imports=@{}
 foreach($stage in @($validated.Keys)){
  $snapshot=$validated[$stage]
  $imports[$stage]=Import-MedicalTemplateBytes $snapshot.Bytes ('Восстановленный '+$stage+[IO.Path]::GetExtension($snapshot.Name)) $false
 }
 foreach($stage in @($imports.Keys)){
  $record.templates | Add-Member -NotePropertyName $stage -NotePropertyValue $imports[$stage].Path -Force
  if($stage -eq 'initial' -and -not $record.universal.Schema.AutoTemplate){$record.universal.Schema.Template=$imports[$stage].RelativePath}
 }
 $savedVariables=@{}
 foreach($name in @('universalConfig','universalValues','universalDetails','universalDetailInputs','universalInputs','universalMultiInputs','universalRepeatInputs','medicalClinicalForms','medicalClinicalState','stageData','stageTemplates','medicalWorkspaceReady','activeMedicalFormPath','activeMedicalFormName','caseFile','caseFolder','caseLastSavedPatientName','diaryIndex','stage','medicalActiveDiaryId','medicalEditorRecoveryDraft','medicalBackupRetainedDraft','medicalBackupFormSavedSignature','medicalBackupCaseSavedSignature','patientName','patientBirthYear','patientAddress','addressBase','addressStreet','addressHouse','addressApartment')){
  $variable=Get-Variable -Name $name -Scope Script -ErrorAction SilentlyContinue
  $savedVariables[$name]=[pscustomobject]@{Exists=($null -ne $variable);Value=if($variable){$variable.Value}else{$null}}
 }
 $savedControls=New-Object Collections.ArrayList
 foreach($control in @($script:patientNameControl,$script:patientBirthControl,$script:patientAddressControl,$script:streetControl,$script:houseControl,$script:apartmentControl)){if($control){[void]$savedControls.Add([pscustomobject]@{Control=$control;Text=[string]$control.Text})}}
 foreach($control in @($script:hospitalControls.Values)){if($control){[void]$savedControls.Add([pscustomobject]@{Control=$control;Text=[string]$control.Text})}}
 $savedAdmission=$script:admissionControl.Value
 try{
 $clinicalFormsRestore=Get-Command Restore-MedicalClinicalFormData -CommandType Function -ErrorAction SilentlyContinue
 if($clinicalFormsRestore -and $data.ClinicalForms){& $clinicalFormsRestore $data.ClinicalForms}
 Restore-UniversalState $record.universal
 foreach($key in @($script:hospitalControls.Keys)){
  $value=Get-MedicalBackupProperty $record.hospitalization ([string]$key)
  $script:hospitalControls[$key].Text=[string]$value
 }
 $script:stageData=@{};foreach($p in $record.stages.PSObject.Properties){$script:stageData[$p.Name]=$p.Value}
 $script:stageTemplates=@{};foreach($p in $record.templates.PSObject.Properties){$script:stageTemplates[$p.Name]=[string]$p.Value}
 $clinicalRestore=Get-Command Restore-MedicalClinicalState -CommandType Function -ErrorAction SilentlyContinue
 if($clinicalRestore -and $data.Clinical){& $clinicalRestore $data.Clinical}
 $script:medicalWorkspaceReady=if($null -ne $data.PSObject.Properties['WorkspaceReady']){[bool]$data.WorkspaceReady}else{$true}
 $script:activeMedicalFormPath=[string]$data.Form.Path;$script:activeMedicalFormName=[string]$data.Form.Name
 $script:caseFile=[string]$data.Case.Path;$script:caseFolder=[string]$data.Case.Folder;$script:caseLastSavedPatientName=$data.Case.LastPatientName
 $script:diaryIndex=[Math]::Max(1,[int]$data.View.DiaryIndex)
 $script:medicalActiveDiaryId=[string]$data.View.ActiveDiaryId
 $script:stage=if($data.View.Stage -in @('initial','diary','discharge')){[string]$data.View.Stage}else{'initial'}
 $script:medicalEditorRecoveryDraft=$data.EditorDraft
 $script:medicalBackupRetainedDraft=$data.EditorDraft
 # Restored source names may change. Keep pending edits conservatively dirty.
 $script:medicalBackupFormSavedSignature=[string]$verified.Payload.FormSavedSignature
 $script:medicalBackupCaseSavedSignature=[string]$verified.Payload.CaseSavedSignature
 return $data
 }catch{
  $restoreError=$_
  foreach($name in @($savedVariables.Keys)){
   if($savedVariables[$name].Exists){Set-Variable -Name $name -Scope Script -Value $savedVariables[$name].Value}else{Remove-Variable -Name $name -Scope Script -ErrorAction SilentlyContinue}
  }
  foreach($entry in $savedControls){try{$entry.Control.Text=$entry.Text}catch{}}
  try{$script:admissionControl.Value=$savedAdmission}catch{}
  throw $restoreError
 }
}

function Get-MedicalRecoveredEditorDraft {
 $draft=$script:medicalEditorRecoveryDraft
 if(-not $draft){return $null}
 Test-MedicalBackupDraftSchema $draft.Schema
 $bytes=[Convert]::FromBase64String([string]$draft.BytesBase64)
 if((Get-MedicalBackupBytesHash $bytes) -cne [string]$draft.Sha256){throw 'Повреждён незавершённый Word-шаблон.'}
 [void](Test-MedicalTemplateBytes $bytes)
 $folder=Join-Path ([IO.Path]::GetTempPath()) ('mc-recover-editor-'+[guid]::NewGuid().ToString('N'))
 [void][IO.Directory]::CreateDirectory($folder);$path=Join-Path $folder ([string]$draft.Name)
 try{
  [IO.File]::WriteAllBytes($path,$bytes);$model=Read-MedicalTemplateModel $path
  $model.SourcePath=Join-Path $script:medicalProgramRoot ([string]$draft.Name)
  return [pscustomobject]@{Schema=(Copy-MedicalBackupValue $draft.Schema);Model=$model;Controls=(Copy-MedicalBackupValue $draft.Controls);CommitError=[string]$draft.CommitError;Stage=[string]$draft.Stage;ClinicalId=[string]$draft.ClinicalId;Purpose=$(if($draft.Purpose){[string]$draft.Purpose}else{'edit'})}
 }finally{[IO.Directory]::Delete($folder,$true)}
}
