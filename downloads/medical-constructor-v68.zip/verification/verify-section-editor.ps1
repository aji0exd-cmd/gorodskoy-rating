﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v68'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Section([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
function Assert-SectionRejected([scriptblock]$operation,[string]$message){$failed=$false;try{& $operation}catch{$failed=$true};Assert-Section $failed $message}
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @'
using System;
public sealed class MedicalSectionTestWidget {
 public string Text {get;set;} public bool Checked {get;set;} public bool Enabled {get;set;}
 public string DialogResult {get;set;} public bool Closed {get;private set;} public bool Focused {get;private set;} public bool SelectedAll {get;private set;}
 public MedicalSectionTestWidget(){Enabled=true;Text="";DialogResult="";}
 public bool Focus(){Focused=true;return true;} public void SelectAll(){SelectedAll=true;} public void Close(){Closed=true;}
}
namespace Windows.Forms {
 public static class MessageBox {public static int Calls=0;public static string Show(params object[] args){Calls++;return "OK";}}
}
'@
$tokens=$null;$parseErrors=$null
$constructor=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'constructor.ps1'),[ref]$tokens,[ref]$parseErrors)
if($parseErrors.Count){throw ($parseErrors | Out-String)}
$getXml=$constructor.Find({param($node)$node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Get-XmlPart'},$false)
. ([scriptblock]::Create($getXml.Extent.Text))
. (Join-Path $Project 'universal.ps1')
. (Join-Path $Project 'forms-v59.ps1')
. (Join-Path $Project 'template-editor-v59.ps1')
. (Join-Path $Project 'section-editor-v64.ps1')
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-section-tests-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
try{
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 $script:medicalProgramRoot=Join-Path $temp 'program';$script:medicalTemplatesFolder=Join-Path $script:medicalProgramRoot 'Шаблоны'
 [void][IO.Directory]::CreateDirectory($script:medicalProgramRoot)
 $script:universalValues=@{name='Patient secret'};$script:universalDetails=@{choice='Patient clarification'}
 $schema=New-UniversalConfig;$schema.AutoTemplate=$false;$source=Join-Path $temp 'source.docx';$schema.Template=$source
 New-UniversalTemplate $source $schema
 $sourceHash=Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($source))
 $model=Read-MedicalTemplateModel $source;$wordBefore=$model.Parts['word/document.xml'].Xml.OuterXml
 $actual=$schema.Sections[0];$originalTitle=$actual.Title;$before=$schema | ConvertTo-Json -Depth 40
 $result=Set-MedicalFormSectionTitle $schema $actual.Id '  Пациент и сведения  '
 Assert-Section ([object]::ReferenceEquals($actual,$result)) 'Rename returns the actual current schema section'
 Assert-Section ($actual.Title -ceq 'Пациент и сведения') 'Section title is trimmed and assigned'
 $actual.Title=$originalTitle
 Assert-Section (($schema | ConvertTo-Json -Depth 40) -ceq $before) 'The title is the only changed schema property'
 $stale=Copy-MedicalFormSchema $schema;$stale.Sections[0].Title='Stale tree object'
 $result=Set-MedicalFormSectionTitle $schema $stale.Sections[0].Id 'Актуальный раздел'
 Assert-Section ([object]::ReferenceEquals($result,$actual) -and $actual.Title -ceq 'Актуальный раздел' -and $stale.Sections[0].Title -ceq 'Stale tree object') 'Stable ID renames the live section instead of a stale tree Tag'
 foreach($title in @($null,'','   ',"`t`r`n")){Assert-SectionRejected {Set-MedicalFormSectionTitle $schema $actual.Id $title} 'Empty title is rejected without discarding the previous title'}
 Assert-Section ($actual.Title -ceq 'Актуальный раздел') 'Rejected blank titles preserve the previous title'
 foreach($id in @($null,'','unknown')){Assert-SectionRejected {Set-MedicalFormSectionTitle $schema $id 'Wrong'} 'Missing or unknown section ID is rejected'}
 Assert-SectionRejected {Set-MedicalFormSectionTitle $null 'patient' 'Wrong'} 'Missing schema is rejected'
 $duplicate=Copy-MedicalFormSchema $schema;$duplicate.Sections+=@([pscustomobject]@{Id='PATIENT';Title='Duplicate';Fields=@()})
 $duplicateBefore=$duplicate | ConvertTo-Json -Depth 40
 Assert-SectionRejected {Set-MedicalFormSectionTitle $duplicate 'patient' 'Wrong'} 'Ambiguous section IDs are rejected case-insensitively'
 Assert-Section (($duplicate | ConvertTo-Json -Depth 40) -ceq $duplicateBefore) 'Ambiguous rename leaves every section untouched'
 Assert-Section ($model.Parts['word/document.xml'].Xml.OuterXml -ceq $wordBefore -and -not $model.Parts['word/document.xml'].Modified) 'A form-only title change leaves the Word model clean'
 $form=Join-Path $temp 'section.mcform';[void](Write-MedicalForm $form $schema 'Секция');$reopened=Read-MedicalForm $form
 Assert-Section ($reopened.Schema.Sections[0].Title -ceq 'Актуальный раздел') 'Renamed section round trips through Save Form and Open Form'
 Assert-Section ((Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes((Join-Path $script:medicalProgramRoot $reopened.Schema.Template)))) -ceq $sourceHash) 'Form-only rename keeps the exact linked Word bytes'
 Assert-UniversalConfig $reopened.Schema;Assert-Section $true 'Renamed form remains valid for Apply'
 $paragraph=@($model.Paragraphs | Where-Object {$_.Text -ceq $originalTitle})[0]
 $paragraphXml=$paragraph.Node.OuterXml;$paragraphNode=$paragraph.Node
 $style=$paragraph.Node.SelectSingleNode('./w:pPr',(Get-MedicalEditorNamespace $paragraph.Node.OwnerDocument)).OuterXml
 $result=Invoke-MedicalSectionRename $schema $actual.Id ' Новый заголовок ' $model $paragraph.Id $true
 Assert-Section ($result.WordChanged -and $result.ParagraphId -ceq $paragraph.Id -and [object]::ReferenceEquals($result.Section,$actual)) 'Explicit optional Word rename reports both targets'
 Assert-Section ($paragraph.Text -ceq 'Новый заголовок' -and $actual.Title -ceq 'Новый заголовок') 'Explicit Word option changes only the selected paragraph and section title'
 Assert-Section ($paragraph.Node.SelectSingleNode('./w:pPr',(Get-MedicalEditorNamespace $paragraph.Node.OwnerDocument)).OuterXml -ceq $style) 'Optional Word replacement preserves the paragraph style'
 Assert-Section ([object]::ReferenceEquals($paragraph.Node,$paragraphNode)) 'Optional Word replacement preserves the paragraph node identity'
 $same=Invoke-MedicalSectionRename $schema $actual.Id 'Новый заголовок' $model $paragraph.Id $true
 Assert-Section (-not $same.WordChanged) 'Matching Word title is reported as unchanged'
 $edited=Join-Path $temp 'edited.docx';Write-MedicalTemplateModel $edited $model;$reread=Read-MedicalTemplateModel $edited
 Assert-Section (@($reread.Paragraphs | Where-Object {$_.Text -ceq 'Новый заголовок'}).Count -eq 1) 'Word title survives writing and reopening the edited DOCX'
 $model=Read-MedicalTemplateModel $source;$paragraph=@($model.Paragraphs | Where-Object {$_.Text -ceq $originalTitle})[0]
 $cleanXml=$model.Parts['word/document.xml'].Xml.OuterXml;$cleanTitle=$actual.Title
 Assert-SectionRejected {Invoke-MedicalSectionRename $schema $actual.Id '' $model $paragraph.Id $true} 'Blank form title is validated before Word mutation'
 Assert-SectionRejected {Invoke-MedicalSectionRename $schema 'unknown' 'Wrong' $model $paragraph.Id $true} 'Unknown section is validated before Word mutation'
 Assert-SectionRejected {Invoke-MedicalSectionRename $schema $actual.Id 'Wrong' $model 'unknown' $true} 'Unknown Word paragraph is rejected before section mutation'
 $paragraph.Editable=$false
 Assert-SectionRejected {Invoke-MedicalSectionRename $schema $actual.Id 'Wrong' $model $paragraph.Id $true} 'Read-only Word paragraph is rejected before section mutation'
 $paragraph.Editable=$true
 Assert-Section ($model.Parts['word/document.xml'].Xml.OuterXml -ceq $cleanXml -and $actual.Title -ceq $cleanTitle) 'All rejected combined edits preserve the complete Word model and title'
 $readOnlySection=[pscustomobject]@{Id='readonly';Fields=@()};$readOnlySection | Add-Member ScriptProperty Title {'Read-only title'}
 $readOnlySchema=[pscustomobject]@{Sections=@($readOnlySection)};$nodeBefore=$paragraph.Node
 Assert-SectionRejected {Invoke-MedicalSectionRename $readOnlySchema 'readonly' 'Would change Word' $model $paragraph.Id $true} 'Unexpected section setter failure is surfaced'
 Assert-Section ($model.Parts['word/document.xml'].Xml.OuterXml -ceq $cleanXml -and -not $model.Parts['word/document.xml'].Modified -and [object]::ReferenceEquals($paragraph.Node,$nodeBefore) -and $paragraph.Text -ceq $originalTitle) 'Failed combined rename rolls Word XML, text and dirty flag back without replacing its node'

 # Run the exact production callbacks against fake widgets, with private helpers.
 $sectionSource=Join-Path $Project 'section-editor-v64.ps1';$sectionAst=[Management.Automation.Language.Parser]::ParseFile($sectionSource,[ref]$tokens,[ref]$parseErrors)
 if($parseErrors.Count){throw ($parseErrors | Out-String)}
 $dialogFunction=$sectionAst.Find({param($node)$node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Show-MedicalSectionRenameDialog'},$false)
 $handlers=@{}
 foreach($pair in @(@('rename','Add_Click'),@('cancel','Add_Click'),@('dialog','Add_Shown'))){
  $control=$pair[0];$event=$pair[1]
  $nodes=@($dialogFunction.FindAll({param($node)$node -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $node.Expression -is [Management.Automation.Language.VariableExpressionAst] -and $node.Expression.VariablePath.UserPath -eq $control -and $node.Member.Value -eq $event},$true))
  if($nodes.Count -ne 1){throw ('Expected production handler '+$control)}
  $handlers[$control]=$nodes[0].Arguments[0].Extent.Text
 }
 Assert-Section (-not (Get-Item Function:global:Invoke-MedicalSectionRename -ErrorAction SilentlyContinue)) 'The combined rename helper remains private to the application script'
 function New-SectionTestCallbacks($schema,$model,$paragraph,[string]$title,[bool]$checked=$false,[bool]$enabled=$true){
  $titleBox=New-Object MedicalSectionTestWidget;$titleBox.Text=$title
  $wordOption=New-Object MedicalSectionTestWidget;$wordOption.Checked=$checked;$wordOption.Enabled=$enabled
  $dialog=New-Object MedicalSectionTestWidget;$renameState=@{Result=$null}
  $sectionId=[string]$schema.Sections[0].Id;$selectedParagraphId=if($paragraph){[string]$paragraph.Id}else{''}
  $renameCommand=Get-Command Invoke-MedicalSectionRename -CommandType Function -ErrorAction Stop
  . ([scriptblock]::Create('$saveHandler='+$handlers.rename));. ([scriptblock]::Create('$cancelHandler='+$handlers.cancel));. ([scriptblock]::Create('$shownHandler='+$handlers.dialog))
  return [pscustomobject]@{Save=$saveHandler;Cancel=$cancelHandler;Shown=$shownHandler;Dialog=$dialog;TitleBox=$titleBox;State=$renameState;Command=$renameCommand}
 }
 $fixture=New-SectionTestCallbacks $schema $model $paragraph 'Переименовано через кнопку' $false
 & $fixture.Shown
 Assert-Section ($fixture.TitleBox.Focused -and $fixture.TitleBox.SelectedAll) 'Dialog opening focuses the title and selects the old name'
 & $fixture.Save
 Assert-Section ($fixture.Command -is [Management.Automation.FunctionInfo] -and $fixture.Dialog.Closed -and $fixture.Dialog.DialogResult -eq 'OK' -and $actual.Title -ceq 'Переименовано через кнопку') 'Production save callback invokes the captured private helper and closes after a successful rename'
 Assert-Section ($null -ne $fixture.State.Result -and -not $fixture.State.Result.WordChanged -and $model.Parts['word/document.xml'].Xml.OuterXml -ceq $cleanXml) 'Default unchecked callback keeps Word unchanged'
 $beforeCancel=$schema | ConvertTo-Json -Depth 40;$fixture=New-SectionTestCallbacks $schema $model $paragraph 'Cancelled title' $true
 & $fixture.Cancel
 Assert-Section ($fixture.Dialog.Closed -and $fixture.Dialog.DialogResult -eq 'Cancel' -and $null -eq $fixture.State.Result) 'Production Cancel callback closes without returning an edit'
 Assert-Section (($schema | ConvertTo-Json -Depth 40) -ceq $beforeCancel -and $model.Parts['word/document.xml'].Xml.OuterXml -ceq $cleanXml) 'Cancel preserves both the schema and Word text'
 $calls=[Windows.Forms.MessageBox]::Calls;$fixture=New-SectionTestCallbacks $schema $model $paragraph '  ' $true
 & $fixture.Save
 Assert-Section (-not $fixture.Dialog.Closed -and $null -eq $fixture.State.Result -and [Windows.Forms.MessageBox]::Calls -eq ($calls+1)) 'Invalid title shows a validation message while keeping the dialog open'
 Assert-Section (($schema | ConvertTo-Json -Depth 40) -ceq $beforeCancel -and $model.Parts['word/document.xml'].Xml.OuterXml -ceq $cleanXml) 'Invalid callback preserves both targets'
 $fixture=New-SectionTestCallbacks $schema $model $paragraph 'Только форма' $true $false
 & $fixture.Save
 Assert-Section ($actual.Title -ceq 'Только форма' -and -not $fixture.State.Result.WordChanged -and $paragraph.Text -ceq $originalTitle) 'Disabled Word option cannot change a paragraph even if its Checked flag is stale'
 $fixture=New-SectionTestCallbacks $schema $model $paragraph 'Новый раздел Word' $true
 & $fixture.Save
 Assert-Section ($fixture.State.Result.WordChanged -and $actual.Title -ceq 'Новый раздел Word' -and $paragraph.Text -ceq 'Новый раздел Word') 'Production checked callback applies the explicitly selected Word title'
 Assert-Section ($script:universalValues.name -ceq 'Patient secret' -and $script:universalDetails.choice -ceq 'Patient clarification') 'Section editing never changes patient answers or clarification values'
 Assert-Section ((Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($source))) -ceq $sourceHash) 'All section edits preserve the original template file'
 Write-Output ('TOTAL '+$script:checks+' checks passed; native Windows dialog is not run by this harness.')
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
