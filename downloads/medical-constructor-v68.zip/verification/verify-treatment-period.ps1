﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v68'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Check([bool]$test,[string]$label){if(-not $test){throw $label};$script:checks++;Write-Output ('PASS '+$label)}
function Assert-Reject([scriptblock]$operation,[string]$label){$threw=$false;try{& $operation | Out-Null}catch{$threw=$true};Assert-Check $threw $label}
function Import-TestFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors|Out-String)}
 foreach($node in $ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
  if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}
 }
}
function Get-TestWordXml($path){$zip=[IO.Compression.ZipFile]::OpenRead($path);try{return (Get-XmlPart $zip 'word/document.xml')}finally{$zip.Dispose()}}
function Get-TestWordText($path){$x=Get-TestWordXml $path;$n=[Xml.XmlNamespaceManager]::new($x.NameTable);$n.AddNamespace('w',$script:ns);return (($x.SelectNodes('//w:t',$n)|ForEach-Object {$_.InnerText}) -join "`n")}
function Add-TestPeriodMarkers($path,[bool]$both=$true){
 $zip=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{
  $x=Get-XmlPart $zip 'word/document.xml';$n=[Xml.XmlNamespaceManager]::new($x.NameTable);$n.AddNamespace('w',$script:ns)
  $p=$x.CreateElement('w','p',$script:ns)
  $fragments=@('С {{TREATMENT_START_','DATE}}');if($both){$fragments+=@(' по {{TREATMENT_END_','DATE}}')}
  foreach($fragment in $fragments){$r=$x.CreateElement('w','r',$script:ns);$t=$x.CreateElement('w','t',$script:ns);$t.InnerText=$fragment;[void]$r.AppendChild($t);[void]$p.AppendChild($r)}
  $body=$x.SelectSingleNode('/w:document/w:body',$n);[void]$body.InsertAfter($p,$body.FirstChild)
  $entry=$zip.GetEntry('word/document.xml');$entry.Delete();Write-UniversalZipText $zip 'word/document.xml' $x.OuterXml
 }finally{$zip.Dispose()}
}
function Apply-DocumentFont($path){}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-period-v68-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 Add-Type -AssemblyName System.IO.Compression.FileSystem
 Import-TestFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
 foreach($module in @('universal.ps1','forms-v59.ps1','clinical-stages-v67.ps1','clinical-ui-v67.ps1')){Import-TestFunctions (Join-Path $Project $module)}
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 $script:medicalProgramRoot=$temp;$script:medicalTemplatesFolder=Join-Path $temp 'Шаблоны'
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-01T09:15:17'}
 $script:universalConfig=New-UniversalConfig;$script:universalValues=@{};$script:universalDetails=@{}
 $script:medicalClinicalForms=$null;$script:medicalClinicalState=$null
 [void](Initialize-MedicalClinicalWorkspace)
 $period=Get-MedicalTreatmentPeriod
 Assert-Check ($period.StartDate -ceq '2026-10-01') 'Default period starts on admission date without time'
 Assert-Check (-not $period.StartOverride -and -not $period.EndOverride) 'Default period remains linked until explicitly edited'
 $script:admissionControl.Value=[datetime]'2026-10-02T18:30:42'
 Assert-Check ((Get-MedicalTreatmentPeriod).StartDate -ceq '2026-10-02') 'Corrected admission date updates untouched period'
 [void](Set-MedicalTreatmentPeriod '2026-10-01' '2026-10-10')
 $script:admissionControl.Value=[datetime]'2026-10-03T20:30:49'
 $period=Get-MedicalTreatmentPeriod
 Assert-Check ($period.StartDate -ceq '2026-10-01' -and $period.EndDate -ceq '2026-10-10') 'Manually selected period survives later admission edits'
 Assert-Check ($period.StartOverride -and $period.EndOverride) 'Explicit period edit retains manual flags'
 $dates=@(Get-MedicalDiaryPeriodDates '2026-10-01' '2026-10-10')
 Assert-Check ($dates.Count -eq 9) 'Period 1 through 10 creates nine diary dates'
 Assert-Check ($dates[0] -eq [datetime]'2026-10-02' -and $dates[-1] -eq [datetime]'2026-10-10') 'First diary is next day and last date is included'
 Assert-Check (@($dates|Where-Object {$_.TimeOfDay -ne [timespan]::Zero}).Count -eq 0) 'Range calculation uses dates without time'
 Assert-Check (@(Get-MedicalDiaryPeriodDates '2026-10-01' '2026-10-01').Count -eq 0) 'Same-day stay has no following-day diaries'
 $leap=@(Get-MedicalDiaryPeriodDates '2024-02-28' '2024-03-01')
 Assert-Check ($leap.Count -eq 2 -and $leap[0] -eq [datetime]'2024-02-29') 'Calendar generation includes leap day'
 Assert-Reject {Get-MedicalDiaryPeriodDates '2026-10-10' '2026-10-01'} 'Reversed range is rejected'
 Assert-Reject {Get-MedicalDiaryPeriodDates '' '2026-10-01'} 'Empty beginning is rejected'
 Assert-Reject {Get-MedicalDiaryPeriodDates '2026-02-30' '2026-03-01'} 'Invalid calendar date is rejected'
 Assert-Reject {Get-MedicalDiaryPeriodDates '2026-10-01T10:30:00' '2026-10-10'} 'Timestamp strings cannot masquerade as treatment date strings'
 Assert-Reject {Get-MedicalDiaryPeriodDates '1740-10-01' '2026-10-10'} 'Out-of-calendar dates are rejected'
 Assert-Reject {Get-MedicalDiaryPeriodDates '2000-01-01' '2040-01-01'} 'Oversized generation is rejected before allocating diary records'
 $first=Add-MedicalClinicalDiary;Set-MedicalClinicalDate $first.Id ([datetime]'2026-10-05T18:25:11');Set-MedicalClinicalValue 'diary' $first.Id 'diary_progress' 'РУЧНАЯ ДИНАМИКА'
 $schemaSignature=$first.Schema|ConvertTo-Json -Depth 70 -Compress
 $script:admissionControl.Value=[datetime]'2026-10-01T09:15:17'
 $result=Add-MedicalClinicalDiaryPeriod '2026-10-01' '2026-10-10';$contexts=@(Get-MedicalClinicalDiaryContexts)
 Assert-Check ($result.AddedCount -eq 8 -and $result.SkippedCount -eq 1) 'Existing date is skipped rather than duplicated'
 Assert-Check ($contexts.Count -eq 9) 'Only missing diary dates are created'
 Assert-Check ($contexts[0].Id -ceq $first.Id) 'Existing diary position and stable ID are preserved'
 Assert-Check ($contexts[0].DateTime -eq [datetime]'2026-10-05T18:25:11') 'Existing manually selected timestamp is preserved'
 Assert-Check ($contexts[0].Values.diary_progress -ceq 'РУЧНАЯ ДИНАМИКА') 'Existing patient answers survive period generation'
 Assert-Check (($contexts[0].Schema|ConvertTo-Json -Depth 70 -Compress) -ceq $schemaSignature) 'Existing diary structure is untouched'
 Assert-Check ((@($contexts|ForEach-Object {$_.DateTime.ToString('yyyy-MM-dd')}|Sort-Object) -join ',') -ceq ((2..10|ForEach-Object {'2026-10-'+$_.ToString('00')}) -join ',')) 'Every required day appears once'
 foreach($context in $contexts|Where-Object {$_.Id -ne $first.Id}){Assert-Check ($context.DateTime.TimeOfDay -eq [timespan]'09:15:17') 'Generated diary default time comes from corrected admission time'}
 $before=Get-MedicalClinicalState|ConvertTo-Json -Depth 80 -Compress
 $again=Add-MedicalClinicalDiaryPeriod '2026-10-01' '2026-10-10'
 Assert-Check ($again.AddedCount -eq 0 -and $again.SkippedCount -eq 9) 'Repeating generation is idempotent'
 Assert-Check ((Get-MedicalClinicalState|ConvertTo-Json -Depth 80 -Compress) -ceq $before) 'Repeated generation leaves existing patient records byte-equivalent'
 Assert-Reject {Add-MedicalClinicalDiaryPeriod '2026-10-20' '2026-10-10'} 'Reversed generation cannot change current period or records'
 Assert-Check ((Get-MedicalClinicalState|ConvertTo-Json -Depth 80 -Compress) -ceq $before) 'Rejected generation keeps all clinical state intact'
 $forms=Get-MedicalClinicalFormData;$state=Get-MedicalClinicalState;$json=$state|ConvertTo-Json -Depth 80
 [void](Initialize-MedicalClinicalWorkspace $forms);Restore-MedicalClinicalState ($json|ConvertFrom-Json)
 $restored=Get-MedicalClinicalState
 Assert-Check ($restored.TreatmentPeriod.StartDate -ceq '2026-10-01' -and $restored.TreatmentPeriod.EndDate -ceq '2026-10-10') 'Patient state roundtrip retains both chosen dates'
 Assert-Check ($restored.TreatmentPeriod.StartOverride -and $restored.TreatmentPeriod.EndOverride) 'Patient state roundtrip retains manual period flags'
 Assert-Check ((Get-MedicalClinicalContext 'diary' $first.Id).DateTime -eq [datetime]'2026-10-05T18:25:11') 'Patient state roundtrip retains independently edited diary time'
 $before=Get-MedicalClinicalState|ConvertTo-Json -Depth 80 -Compress
 foreach($kind in @('invalid','reversed','stringflag')){
  $bad=$json|ConvertFrom-Json
  if($kind -eq 'invalid'){$bad.TreatmentPeriod.StartDate='not a date'}elseif($kind -eq 'reversed'){$bad.TreatmentPeriod.EndDate='2020-01-01'}else{$bad.TreatmentPeriod.StartOverride='true'}
  Assert-Reject {Restore-MedicalClinicalState $bad} ('Tampered period '+$kind+' is rejected')
  Assert-Check ((Get-MedicalClinicalState|ConvertTo-Json -Depth 80 -Compress) -ceq $before) ('Rejected period '+$kind+' does not mutate patient state')
 }
 $legacy=$json|ConvertFrom-Json;$legacy.PSObject.Properties.Remove('TreatmentPeriod');Restore-MedicalClinicalState $legacy
 Assert-Check ((Get-MedicalTreatmentPeriod).StartDate -ceq '2026-10-01') 'Old cards without period receive a backward-compatible admission-date default'
 [void](Set-MedicalTreatmentPeriod '2026-10-01' '2026-10-10')
 $path=Join-Path $temp 'all.mcform';$envelope=Write-MedicalForm $path $script:universalConfig 'ПЕРИОД НЕ ХРАНИТ ОТВЕТЫ'
 Assert-Check ($null -eq $envelope.StageForms.PSObject.Properties['TreatmentPeriod']) 'Reusable form contains no patient treatment period'
 Assert-Check (-not [IO.File]::ReadAllText($path).Contains('2026-10-10')) 'Reusable form does not leak selected discharge date'
 $discharge=Get-MedicalClinicalContext 'discharge';$path=Join-Path $temp 'discharge.docx'
 Save-UniversalDocument $path $discharge.Schema $discharge.Values $discharge.DateTime $discharge.Details $true 'discharge'
 Set-MedicalDischargePeriodDocument $path $discharge.Schema
 $text=Get-TestWordText $path
 Assert-Check ($text.Contains('Период лечения: 01.10.2026 — 10.10.2026')) 'Generated discharge includes selected date-only treatment period'
 Assert-Check (-not (($text -split "`n"|Where-Object {$_ -like 'Период лечения:*'}) -match '[0-9]{2}:[0-9]{2}')) 'Treatment period never includes time'
 Set-MedicalDischargePeriodDocument $path $discharge.Schema
 Assert-Check ([regex]::Matches((Get-TestWordText $path),'Период лечения:').Count -eq 1) 'Repeated period annotation cannot duplicate the line'
 [void](Set-MedicalTreatmentPeriod '2026-09-28' '2026-10-11');Set-MedicalDischargePeriodDocument $path $discharge.Schema
 Assert-Check ((Get-TestWordText $path).Contains('Период лечения: 28.09.2026 — 11.10.2026')) 'Existing generated period annotation can update in place'
 $custom=Copy-MedicalFormSchema $discharge.Schema;$customPath=Join-Path $temp 'authored-discharge.docx';New-UniversalTemplate $customPath $custom;Add-TestPeriodMarkers $customPath
 $custom.AutoTemplate=$false;$custom.Template='authored-discharge.docx';$sourceHash=(Get-FileHash -LiteralPath $customPath).Hash
 Assert-Check (Test-MedicalTreatmentMarkersInTemplate $custom) 'Both date markers are recognized across split Word runs'
 $out=Join-Path $temp 'custom-filled.docx';Save-UniversalDocument $out $custom $discharge.Values $discharge.DateTime $discharge.Details $true 'discharge';Set-MedicalDischargePeriodDocument $out $custom
 $text=Get-TestWordText $out
 Assert-Check ($text.Contains('С 28.09.2026') -and $text.Contains(' по 11.10.2026')) 'Custom period markers render the selected date-only values'
 Assert-Check (-not $text.Contains('Период лечения:')) 'Authored placement with both markers adds no fallback line'
 Assert-Check (-not $text.Contains('{{TREATMENT_')) 'All reserved period markers are replaced'
 Assert-Check ((Get-FileHash -LiteralPath $customPath).Hash -ceq $sourceHash) 'Discharge export never changes the Word source template'
 Assert-Reject {Set-MedicalDischargePeriodDocument $customPath $custom} 'Period annotation refuses to alter the source Word template itself'
 Assert-Check ((Get-FileHash -LiteralPath $customPath).Hash -ceq $sourceHash) 'Rejected annotation leaves authored source byte-identical'
 $imported=New-MedicalSchemaFromTemplate $customPath
 Assert-Check (@(Get-UniversalFields $imported|Where-Object {$_.Marker -in @('TREATMENT_START_DATE','TREATMENT_END_DATE')}).Count -eq 0) 'Importing a Word template skips reserved period markers as form fields'
 $badConfig=Copy-MedicalFormSchema $script:universalConfig;$badConfig.Sections[0].Fields[0].Marker='TREATMENT_START_DATE'
 Assert-Reject {Assert-UniversalConfig $badConfig} 'Reserved period markers cannot be claimed by patient form fields'
 $uiStatus=[pscustomobject]@{Text='';ForeColor=''};$script:darkMuted='Muted';$script:uiDanger='Danger';$script:stage='discharge';$script:medicalClinicalBuilding=$false
 $ui=[pscustomobject]@{Stage='discharge';Start=[pscustomobject]@{Value=[datetime]'2026-10-01';IsDisposed=$false};End=[pscustomobject]@{Value=[datetime]'2026-10-10';IsDisposed=$false};Status=$uiStatus}
 $script:medicalTreatmentPeriodControls=$ui
 Assert-Check (Save-MedicalTreatmentPeriodControls $ui) 'Actual period callback commits valid selected dates'
 $ui.End.Value=[datetime]'2026-09-01'
 Assert-Check (-not (Save-MedicalTreatmentPeriodControls $ui)) 'Actual period callback reports reversed selection without committing it'
 Assert-Check ($ui.Status.Text -like '*раньше*') 'Invalid range has an explicit inline explanation'
 Assert-Reject {Capture-MedicalTreatmentPeriodControls} 'Card capture rejects an invalid range visible in period controls'
 Assert-Check ((Get-MedicalTreatmentPeriod).EndDate -ceq '2026-10-10') 'Invalid UI selection cannot overwrite the last valid saved range'
 $ui.End.Value=[datetime]'2026-10-12';Capture-MedicalTreatmentPeriodControls
 Assert-Check ((Get-MedicalTreatmentPeriod).EndDate -ceq '2026-10-12') 'Corrected period is captured before card persistence'
 $script:medicalClinicalState.TreatmentPeriod=New-MedicalTreatmentPeriod;$ui.Start.Value=$script:admissionControl.Value.Date;$ui.End.Value=[datetime]::Today
 Capture-MedicalTreatmentPeriodControls
 Assert-Check (-not (Get-MedicalTreatmentPeriod).StartOverride) 'Capturing untouched visible controls does not detach admission-date defaults'
 $typed=[pscustomobject]@{Value=[datetime]'2026-10-02T08:00:00';Text='04.10.2026 17:45'}
 Assert-Check ((Sync-MedicalClinicalDateControl $typed $false 'дневника') -eq [datetime]'2026-10-04T17:45:00') 'Typed diary date and time commit before capture without focus change'
 $typed=[pscustomobject]@{Value=[datetime]'2026-10-01';Text='03.10.2026'}
 Assert-Check ((Sync-MedicalClinicalDateControl $typed $true 'начала лечения') -eq [datetime]'2026-10-03') 'Typed treatment date commits without focus change'
 $typed.Text='03.10.2026 14:20'
 Assert-Reject {Sync-MedicalClinicalDateControl $typed $true 'начала лечения'} 'Date-only period control rejects a typed time'
 # A reusable .mcform carries diary structures, never the previous patient's dates.
 # On a new patient, scheduling must reuse these blank slots before appending.
 $blueprintPath=Join-Path $temp 'nine-diary-blueprints.mcform'
 [void](Write-MedicalForm $blueprintPath $script:universalConfig 'ДЕВЯТЬ ДНЕВНИКОВ')
 $opened=Read-MedicalForm $blueprintPath
 [void](Initialize-MedicalClinicalWorkspace $opened.StageForms)
 $slots=@(Get-MedicalClinicalDiaryContexts);$slotIds=@($slots|ForEach-Object {$_.Id});$schemas=@($slots|ForEach-Object {$_.Schema|ConvertTo-Json -Depth 70 -Compress})
 Assert-Check ($slots.Count -eq 9) 'Opening saved nine-diary form restores exactly nine blank structures'
 Assert-Check (@($slots|Where-Object {$_.DateIsAutomatic}).Count -eq 9) 'Fresh reusable diary slots carry automatic default dates in patient state only'
 Assert-Check (@($slots|Where-Object {Test-MedicalClinicalDiaryUnscheduled $_}).Count -eq 0) 'No diary is hidden before the user selects a treatment period'
 Set-MedicalClinicalDate $slotIds[0] $slots[0].DateTime
 Assert-Check ((Get-MedicalClinicalContext 'diary' $slotIds[0]).DateIsAutomatic) 'Capturing an unchanged diary timestamp keeps placeholder eligibility'
 Set-MedicalClinicalDate $slotIds[0] ([datetime]'2026-10-06T15:40:22')
 Assert-Check (-not (Get-MedicalClinicalContext 'diary' $slotIds[0]).DateIsAutomatic) 'An actual manual timestamp edit confirms that diary date'
 [void](Initialize-MedicalClinicalWorkspace $opened.StageForms)
 # Include today's default date in the selected range: it must still assign the
 # FIRST empty slot to day two rather than reserving an arbitrary Today slot.
 $result=Add-MedicalClinicalDiaryPeriod '2026-10-01' '2026-10-10';$slots=@(Get-MedicalClinicalDiaryContexts)
 Assert-Check ($result.ReusedCount -eq 9 -and $result.AddedCount -eq 0 -and $result.RemainingBlankCount -eq 0) 'Nine saved template slots receive nine period dates without nine extra diaries'
 Assert-Check ($slots.Count -eq 9) 'Nine blueprint structures remain nine diary records after scheduling'
 Assert-Check ((@($slots|ForEach-Object {$_.Id}) -join ',') -ceq ($slotIds -join ',')) 'Reusing blueprint slots preserves every stable ID and its order'
 for($i=0;$i -lt $slots.Count;$i++){
  Assert-Check ($slots[$i].DateTime.Date -eq ([datetime]'2026-10-02').AddDays($i)) ('Reused diary slot '+($i+1)+' receives its sequential treatment date')
  Assert-Check (($slots[$i].Schema|ConvertTo-Json -Depth 70 -Compress) -ceq $schemas[$i]) ('Reused diary slot '+($i+1)+' retains its exact schema')
 }
 Assert-Check (@($slots|Where-Object {$_.DateIsAutomatic}).Count -eq 0) 'Explicit selected-period dates are confirmed patient dates'
 $before=Get-MedicalClinicalState|ConvertTo-Json -Depth 80 -Compress
 $again=Add-MedicalClinicalDiaryPeriod '2026-10-01' '2026-10-10'
 Assert-Check ($again.AddedCount -eq 0 -and $again.ReusedCount -eq 0 -and $again.SkippedCount -eq 9) 'Repeating a scheduled reusable form adds no duplicate diaries'
 Assert-Check ((Get-MedicalClinicalState|ConvertTo-Json -Depth 80 -Compress) -ceq $before) 'Repeat scheduling leaves confirmed diary state unchanged'
 [void](Initialize-MedicalClinicalWorkspace $opened.StageForms)
 $result=Add-MedicalClinicalDiaryPeriod '2026-10-01' '2026-10-04';$slots=@(Get-MedicalClinicalDiaryContexts)
 Assert-Check ($result.ReusedCount -eq 3 -and $result.RemainingBlankCount -eq 6 -and $slots.Count -eq 9) 'Shorter period keeps six spare structures without deleting them'
 Assert-Check (@($slots|Where-Object {Test-MedicalClinicalDiaryUnscheduled $_}).Count -eq 6) 'Only unused blank automatic placeholders are omitted from Word'
 Assert-Check (@($slots|Where-Object {-not (Test-MedicalClinicalDiaryUnscheduled $_)}).Count -eq 3) 'A three-day diary period exports exactly three diary records'
 $untouched=Get-MedicalClinicalState|ConvertTo-Json -Depth 80 -Compress
 foreach($context in $slots){[void](Test-MedicalClinicalDiaryUnscheduled $context)}
 Assert-Check ((Get-MedicalClinicalState|ConvertTo-Json -Depth 80 -Compress) -ceq $untouched) 'Unscheduled export predicate is pure and cannot change patient state'
 $filledId=$slotIds[3];$originalDate=(Get-MedicalClinicalContext 'diary' $filledId).DateTime
 Set-MedicalClinicalValue 'diary' $filledId 'diary_progress' 'ВНЕ ПЕРИОДА РУЧНАЯ ЗАПИСЬ'
 Assert-Check (-not (Test-MedicalClinicalDiaryUnscheduled (Get-MedicalClinicalContext 'diary' $filledId))) 'Filling a spare placeholder immediately includes it in Word'
 $manualId=$slotIds[4];Set-MedicalClinicalDate $manualId ([datetime]'2026-10-20T17:00:00')
 Assert-Check (-not (Test-MedicalClinicalDiaryUnscheduled (Get-MedicalClinicalContext 'diary' $manualId))) 'Manually dated empty diary is never hidden as a spare placeholder'
 $overrideId=$slotIds[5];Set-MedicalClinicalValue 'diary' $overrideId 'patient_name' 'РУЧНОЕ ИМЯ ДНЕВНИКА'
 Assert-Check (-not (Test-MedicalClinicalDiaryUnscheduled (Get-MedicalClinicalContext 'diary' $overrideId))) 'A manual linked-field override protects even a nominally blank diary'
 $result=Add-MedicalClinicalDiaryPeriod '2026-10-01' '2026-10-05'
 Assert-Check ($result.ReusedCount -eq 1 -and $result.AddedCount -eq 0) 'Extending a period reuses another available blank structure'
 Assert-Check ((Get-MedicalClinicalContext 'diary' $filledId).Values.diary_progress -ceq 'ВНЕ ПЕРИОДА РУЧНАЯ ЗАПИСЬ') 'Generation cannot overwrite independently completed diary text'
 Assert-Check ((Get-MedicalClinicalContext 'diary' $filledId).DateTime -eq $originalDate) 'Completed diary timestamp stays unchanged during later scheduling'
 Assert-Check ((Get-MedicalClinicalContext 'diary' $manualId).DateTime -eq [datetime]'2026-10-20T17:00:00') 'Later scheduling preserves manually dated records outside the range'
 Assert-Check ((Get-MedicalClinicalContext 'diary' $overrideId).Values.patient_name -ceq 'РУЧНОЕ ИМЯ ДНЕВНИКА') 'Later scheduling preserves manual overrides'
 $state=Get-MedicalClinicalState;$forms=Get-MedicalClinicalFormData
 $legacy=$state|ConvertTo-Json -Depth 80|ConvertFrom-Json
 foreach($entry in $legacy.Diaries){$entry.PSObject.Properties.Remove('DateIsAutomatic')}
 Restore-MedicalClinicalState $legacy
 Assert-Check (@(Get-MedicalClinicalDiaryContexts|Where-Object {$_.DateIsAutomatic}).Count -eq 0) 'Old cards without automatic-date flags retain every existing diary as confirmed'
 $before=Get-MedicalClinicalState|ConvertTo-Json -Depth 80 -Compress
 $bad=Get-MedicalClinicalState;$bad.Diaries[0].DateIsAutomatic='true'
 Assert-Reject {Restore-MedicalClinicalState $bad} 'A malformed automatic-date flag is rejected before patient mutation'
 Assert-Check ((Get-MedicalClinicalState|ConvertTo-Json -Depth 80 -Compress) -ceq $before) 'Rejected scheduling metadata keeps existing clinical state intact'
 $path=Join-Path $temp 'blueprints-no-state.mcform';$envelope=Write-MedicalForm $path $script:universalConfig 'ЗАГОТОВКИ БЕЗ ДАТ'
 Assert-Check (-not [IO.File]::ReadAllText($path).Contains('DateIsAutomatic')) 'Reusable form never stores patient scheduling flags'

 [void](Initialize-MedicalClinicalWorkspace)
 $old=[pscustomobject]@{diaryCount=1;admissionDate='2026-10-01';templates=[pscustomobject]@{diary='absent-old.docx'};stages=[pscustomobject]@{diary_1=@('')}}
 [void](Import-MedicalLegacyClinicalStages $old);[void](Set-MedicalTreatmentPeriod '2026-10-01' '2026-10-04')
 $oldDiary=@(Get-MedicalClinicalDiaryContexts)[0]
 Assert-Check (-not $oldDiary.DateIsAutomatic -and $oldDiary.DateTime.Date -eq [datetime]'2026-10-01') 'Legacy import confirms even an empty saved diary date'
 Assert-Check (-not (Test-MedicalClinicalDiaryUnscheduled $oldDiary)) 'An empty legacy diary is never omitted as a reusable blank slot'
 $result=Add-MedicalClinicalDiaryPeriod '2026-10-01' '2026-10-04'
 Assert-Check ($result.ReusedCount -eq 0 -and $result.AddedCount -eq 3) 'Period generation cannot reuse an empty diary from an old saved card'
 Assert-Check ((Get-MedicalClinicalContext 'diary' $oldDiary.Id).DateTime -eq $oldDiary.DateTime) 'Legacy timestamp stays unchanged during period generation'
 Write-Output ('CHECKS '+$script:checks)
}finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Recurse -Force}}
