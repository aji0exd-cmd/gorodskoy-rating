﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v68'))
$ErrorActionPreference='Stop'
$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'template-editor-v59.ps1'),[ref]$tokens,[ref]$errors)
if($errors.Count){throw ($errors|Out-String)}
$editor=$ast.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Show-MedicalFormTemplateEditor'},$false)
$spec=@{Assignments=@{};Handlers=@{}}
foreach($name in @('commitProperties','commitParagraph','getEditorPending','getEditorSignature','persistEditor')){
 $matches=@($editor.FindAll({param($n)$n -is [Management.Automation.Language.AssignmentStatementAst] -and $n.Left -is [Management.Automation.Language.VariableExpressionAst] -and $n.Left.VariablePath.UserPath -eq $name},$true))
 if($matches.Count -ne 1){throw ('Missing unique callback '+$name)};$spec.Assignments[$name]=$matches[0].Extent.Text
}
foreach($event in @(@('saveForm','Add_Click'),@('save','Add_Click'),@('cancel','Add_Click'),@('dialog','Add_KeyDown'),@('dialog','Add_FormClosing'))){
 $variable=$event[0];$member=$event[1]
 $matches=@($editor.FindAll({param($n)$n -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $n.Expression -is [Management.Automation.Language.VariableExpressionAst] -and $n.Expression.VariablePath.UserPath -eq $variable -and $n.Member.Value -eq $member},$true))
 if($matches.Count -ne 1){throw ('Missing unique handler '+$variable+'.'+$member)};$spec.Handlers[$variable+'.'+$member]=$matches[0].Arguments[0].Extent.Text
}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-editor-save-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
$child=Join-Path $temp 'private-editor-save.ps1'
$childSource=@'
param([string]$Project,[string]$Root,$Spec)
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Check([bool]$test,[string]$label){if(-not $test){throw $label};$script:checks++;Write-Output ('PASS '+$label)}
function Import-Functions([string]$path,[string[]]$names=@()){
 $t=$null;$e=$null;$a=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$t,[ref]$e);if($e.Count){throw ($e|Out-String)}
 foreach($node in $a.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}}
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @"
using System;
public sealed class EditorCloseArgs:EventArgs {public string CloseReason="UserClosing"; public bool Cancel;}
public sealed class EditorKeyArgs:EventArgs {public bool Control; public string KeyCode; public bool Handled; public bool SuppressKeyPress;}
public sealed class EditorSaveWidget {
 public string Text=""; public bool Checked; public int SelectedIndex; public bool Closed; public object SelectedTab; public string DialogResult="None";
 public string[] Lines {get{return Text.Replace("\r\n","\n").Split('\n');}}
 public event EventHandler Click; public event EventHandler<EditorCloseArgs> FormClosing; public event EventHandler<EditorKeyArgs> KeyDown;
 public void RaiseClick(){if(Click!=null)Click(this,EventArgs.Empty);} public bool Focus(){return true;}
 public EditorCloseArgs LastClose;
 public void Close(){LastClose=new EditorCloseArgs();if(FormClosing!=null)FormClosing(this,LastClose);Closed=!LastClose.Cancel;}
 public void Shutdown(){LastClose=new EditorCloseArgs();LastClose.CloseReason="WindowsShutDown";if(FormClosing!=null)FormClosing(this,LastClose);Closed=!LastClose.Cancel;}
 public EditorKeyArgs PressSave(){EditorKeyArgs a=new EditorKeyArgs();a.Control=true;a.KeyCode="S";if(KeyDown!=null)KeyDown(this,a);return a;}
}
namespace Windows.Forms {
 public sealed class SaveFileDialog:IDisposable {
  public static string Choice="Cancel";public static string Destination="";public static int Calls;
  public string Filter;public string DefaultExt;public bool AddExtension;public bool OverwritePrompt;public string Title;public string InitialDirectory;public string FileName;
  public string ShowDialog(object owner){Calls++;if(Choice=="OK")FileName=Destination;return Choice;} public void Dispose(){}
 }
 public static class MessageBox {public static string Choice="Cancel";public static int Calls;public static string Show(params object[] values){Calls++;return Choice;}}
}
"@
Import-Functions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
foreach($file in @('universal.ps1','forms-v59.ps1','clinical-stages-v67.ps1','template-editor-v59.ps1')){Import-Functions (Join-Path $Project $file)}
$script:medicalProgramRoot=$Root;$script:medicalTemplatesFolder=Join-Path $Root 'Шаблоны';$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
$script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-15T12:00:00'}
$script:universalConfig=New-UniversalConfig;$script:universalValues=@{patient_name='PATIENT ANSWER SECRET';complaints='CLINICAL ANSWER SECRET'};$script:universalDetails=@{complaints='DETAIL ANSWER SECRET'}
$script:stage='initial';$script:activeMedicalFormName='Тестовая форма';$script:activeMedicalFormPath=''
[void](Initialize-MedicalClinicalWorkspace)
$first=Add-MedicalClinicalDiary;$second=Add-MedicalClinicalDiary
Set-MedicalClinicalValue 'diary' $first.Id 'diary_complaints' 'DIARY ANSWER SECRET'
Set-MedicalClinicalValue 'discharge' '' 'recommendations' 'DISCHARGE ANSWER SECRET'
$script:source=Join-Path $Root 'initial-source.docx';New-UniversalTemplate $script:source $script:universalConfig
$script:sourceHash=Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($script:source))
function New-TestSession([string]$purpose='edit',[string]$stage='initial',[string]$clinicalId=''){
 $schema=if($stage -eq 'initial'){Copy-MedicalFormSchema $script:universalConfig}else{Copy-MedicalFormSchema (Get-MedicalClinicalContext $stage $clinicalId).Schema}
 $path=Join-Path $Root ('session-'+[guid]::NewGuid().ToString('N')+'.docx');New-UniversalTemplate $path $schema
 $model=Read-MedicalTemplateModel $path
 $state=@{Schema=$schema;Model=$model;Loading=$false;PropertiesSelection=[pscustomobject]@{Kind='field';Field=$schema.Sections[0].Fields[0]};PropertiesNode=$null;Paragraph=$model.Paragraphs[0];SavedResult=$null;Result=$null;AllowClose=$false;SavedContentSignature='';InitialContentSignature='';ClosingReason='UserClosing'}
 $saveContext=New-MedicalEditorSaveContext $schema $purpose $stage $clinicalId
 $widgets=@{}
 foreach($name in @('saveForm','save','cancel','dialog','saveStatus','templateName','fieldName','fieldMarker','fieldOptions','fieldType','fieldRole','fieldRequired','fieldWordId','sectionFieldName','detailForm','detailWord','detailMarker','paragraphText','tabs','fieldTab')){$widget=New-Object EditorSaveWidget;Set-Variable -Name $name -Value $widget;$widgets[$name]=$widget}
 $typeIds=@('text','multiline','choice','choice_detail','heading','multi','repeat');$roleIds=@('','name','birth','address')
 $fieldName.Text=$state.PropertiesSelection.Field.Label;$fieldMarker.Text=$state.PropertiesSelection.Field.Marker;$fieldOptions.Text='';$fieldType.SelectedIndex=0;$fieldRole.SelectedIndex=1;$fieldRequired.Checked=$true;$paragraphText.Text=$model.Paragraphs[0].Text;$templateName.Text='Редактируемый шаблон.docx'
 $editorCommands=@{}
 foreach($name in @('Set-MedicalTemplateParagraph','Get-MedicalEditorContentSignature','Save-MedicalEditorFormSnapshot','Show-MedicalEditorCloseChoice','Save-MedicalEditorResult')){$editorCommands[$name]=Get-Command $name -CommandType Function}
 $testErrors=@{Last=$null};$showError={param($e)$testErrors.Last=$e}.GetNewClosure()
 foreach($name in @('commitProperties','commitParagraph','getEditorPending','getEditorSignature','persistEditor')){Invoke-Expression $Spec.Assignments[$name]}
 $state.InitialContentSignature=& $getEditorSignature
 foreach($binding in @(@('saveForm','Add_Click'),@('save','Add_Click'),@('cancel','Add_Click'),@('dialog','Add_KeyDown'),@('dialog','Add_FormClosing'))){$handler=Invoke-Expression $Spec.Handlers[$binding[0]+'.'+$binding[1]];$widgets[$binding[0]].($binding[1])($handler)}
 return [pscustomobject]@{State=$state;Context=$saveContext;Widgets=$widgets;Errors=$testErrors;Signature=$getEditorSignature}
}
# Actual production callbacks, not a duplicate close/save implementation.
$session=New-TestSession
$session.Widgets.fieldName.Text='Отредактированное Ф.И.О.'
$session.Widgets.saveForm.RaiseClick()
Assert-Check (-not $session.Widgets.dialog.Closed -and -not $session.State.SavedResult) 'Cancelled Save picker keeps editor and current draft open'
$destination=Join-Path $Root 'EditorSaved.mcform';[Windows.Forms.SaveFileDialog]::Destination=$destination;[Windows.Forms.SaveFileDialog]::Choice='OK'
$session.Widgets.saveForm.RaiseClick()
Assert-Check ($null -eq $session.Errors.Last -and [IO.File]::Exists($destination)) 'Explicit Save button writes actual mcform'
Assert-Check (-not $session.Widgets.dialog.Closed -and $session.State.SavedResult.SavedSnapshotMatches) 'Explicit Save leaves editor open and retains saved result'
$saved=Read-MedicalForm $destination
Assert-Check ($saved.Schema.Sections[0].Fields[0].Label -ceq 'Отредактированное Ф.И.О.') 'Saved file contains edited schema'
Assert-Check (@($saved.StageForms.Diaries).Count -eq 2 -and $saved.StageForms.Discharge) 'Save contains every diary and discharge structure'
$text=[IO.File]::ReadAllText($destination)
foreach($secret in @('PATIENT ANSWER SECRET','CLINICAL ANSWER SECRET','DETAIL ANSWER SECRET','DIARY ANSWER SECRET','DISCHARGE ANSWER SECRET')){Assert-Check (-not $text.Contains($secret)) ('Reusable form excludes '+$secret)}
Assert-Check ($script:universalValues.patient_name -ceq 'PATIENT ANSWER SECRET') 'Saving modal editor does not mutate patient answers'
Assert-Check ($script:sourceHash -ceq (Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($script:source)))) 'Editor saves preserve original Word source'
$session.Widgets.fieldName.Text='Несохранённое изменение';[Windows.Forms.MessageBox]::Choice='Cancel';$session.Widgets.cancel.RaiseClick()
Assert-Check ($session.Widgets.dialog.LastClose.Cancel -and -not $session.Widgets.dialog.Closed) 'Escape/Close handler offers Continue when dirty'
[Windows.Forms.MessageBox]::Choice='No';$session.Widgets.cancel.RaiseClick()
Assert-Check ($session.Widgets.dialog.Closed -and $session.State.Result.Schema.Sections[0].Fields[0].Label -ceq 'Отредактированное Ф.И.О.') 'Discard later edits returns earlier saved snapshot to main window'
Assert-Check ((Read-MedicalForm $destination).Schema.Sections[0].Fields[0].Label -ceq 'Отредактированное Ф.И.О.') 'Discard does not overwrite explicit save'
$session=New-TestSession;$session.Widgets.fieldName.Text='';[Windows.Forms.MessageBox]::Choice='Yes';$session.Widgets.cancel.RaiseClick()
Assert-Check ($session.Widgets.dialog.LastClose.Cancel -and $session.Errors.Last.Exception.Message.Contains('Введите название')) 'Blank raw name is dirty and failed Save keeps editor open'
$session=New-TestSession;$session.Widgets.fieldMarker.Text='BAD MARKER';[Windows.Forms.MessageBox]::Choice='Yes';$session.Widgets.cancel.RaiseClick()
Assert-Check ($session.Widgets.dialog.LastClose.Cancel -and $session.Errors.Last) 'Invalid raw marker cannot bypass guarded close'
$session=New-TestSession;$session.Widgets.paragraphText.Text='Изменённый заголовок';$session.Context.Path=Join-Path $Root 'missing-parent/Fail.mcform';[Windows.Forms.MessageBox]::Choice='Yes';$session.Widgets.cancel.RaiseClick()
Assert-Check ($session.Widgets.dialog.LastClose.Cancel -and -not $session.State.SavedResult -and $session.Errors.Last) 'Atomic save failure keeps draft open without publishing saved result'
$session=New-TestSession;$session.Widgets.paragraphText.Text='Изменённый заголовок';[Windows.Forms.MessageBox]::Choice='Cancel';$session.Widgets.cancel.RaiseClick()
Assert-Check ($session.Widgets.dialog.LastClose.Cancel) 'Word text edits count as unsaved independently of sticky flags'
$session=New-TestSession;$paragraph=$session.State.Model.Paragraphs[0];$n=Get-MedicalEditorNamespace $paragraph.Node.OwnerDocument;$rPr=$paragraph.Node.OwnerDocument.CreateElement('w','pPr',$paragraph.Node.NamespaceURI);[void]$paragraph.Node.PrependChild($rPr);$session.Widgets.cancel.RaiseClick()
Assert-Check ($session.Widgets.dialog.LastClose.Cancel) 'Word XML formatting edits count as unsaved'
$session=New-TestSession;$calls=[Windows.Forms.MessageBox]::Calls;$session.State.Model.Parts['word/document.xml'].Modified=$true;$session.State.Dirty=$true;$session.Widgets.cancel.RaiseClick()
Assert-Check ($session.Widgets.dialog.Closed -and [Windows.Forms.MessageBox]::Calls -eq $calls) 'Unchanged logical content closes despite stale dirty and Modified flags'
$session=New-TestSession;$session.Widgets.fieldName.Text='Ctrl S';[Windows.Forms.SaveFileDialog]::Destination=Join-Path $Root 'CtrlS.mcform';$key=$session.Widgets.dialog.PressSave()
Assert-Check ($key.Handled -and $key.SuppressKeyPress -and [IO.File]::Exists([Windows.Forms.SaveFileDialog]::Destination) -and -not $session.Widgets.dialog.Closed) 'Ctrl+S invokes persistent Save without closing editor'
$session=New-TestSession;$session.Widgets.fieldName.Text='При завершении Windows';$calls=[Windows.Forms.MessageBox]::Calls;$session.Widgets.dialog.Shutdown()
Assert-Check ($session.Widgets.dialog.Closed -and $session.State.ClosingReason -eq 'WindowsShutDown' -and [Windows.Forms.MessageBox]::Calls -eq $calls) 'System shutdown keeps nonblocking v67 draft recovery path'
$session=New-TestSession;[Windows.Forms.SaveFileDialog]::Destination=Join-Path $Root 'SavedBeforeShutdown.mcform';$session.Widgets.saveForm.RaiseClick();$session.Widgets.fieldName.Text='После сохранения перед выключением';$session.Widgets.dialog.Shutdown()
Assert-Check ($session.State.SavedResult -and -not $session.State.Result -and $session.Widgets.fieldName.Text -ceq 'После сохранения перед выключением') 'Save then edit then shutdown retains draft instead of applying stale saved result'
$session=New-TestSession;$session.Context.Path=Join-Path $Root 'CloseSave.mcform';$session.Widgets.fieldName.Text='Сохранено при закрытии';[Windows.Forms.MessageBox]::Choice='Yes';$session.Widgets.cancel.RaiseClick()
Assert-Check ($session.Widgets.dialog.Closed -and $session.State.Result.SavedSnapshotMatches -and (Read-MedicalForm $session.Context.Path).Schema.Sections[0].Fields[0].Label -ceq 'Сохранено при закрытии') 'Save from guarded close persists before closing and returns saved snapshot'
$session=New-TestSession;$session.Context.Path='';$session.Widgets.fieldName.Text='Ожидает путь';[Windows.Forms.SaveFileDialog]::Choice='Cancel';$session.Widgets.cancel.RaiseClick()
Assert-Check ($session.Widgets.dialog.LastClose.Cancel -and $session.Widgets.dialog.DialogResult -eq 'None') 'Cancel destination picker during guarded close resets modal result and stays open'
[Windows.Forms.SaveFileDialog]::Choice='OK'
$session=New-TestSession;[Windows.Forms.SaveFileDialog]::Destination=Join-Path $Root 'AppliedAfterSave.mcform';$session.Widgets.saveForm.RaiseClick();$session.Widgets.fieldName.Text='Применено после сохранения';$session.Widgets.save.RaiseClick()
Assert-Check ($session.Widgets.dialog.Closed -and $session.State.Result.SavedFormPath -and -not $session.State.Result.SavedSnapshotMatches -and $session.State.Result.Schema.Sections[0].Fields[0].Label -ceq 'Применено после сохранения') 'Apply after later edits retains save path but does not falsely mark new changes as saved'
Assert-Check ((Read-MedicalForm ([Windows.Forms.SaveFileDialog]::Destination)).Schema.Sections[0].Fields[0].Label -cne 'Применено после сохранения') 'Apply-and-close keeps previous persistent snapshot intact until next explicit Save'
# New form must not inherit old path, old diary structure, or old case answers.
$script:activeMedicalFormPath=$destination;$script:activeMedicalFormName='Старая карта';$session=New-TestSession 'new'
Assert-Check (-not $session.Context.Path -and @($session.Context.StageForms.Diaries).Count -eq 0) 'New-form save context is independent of old active form and diaries'
[Windows.Forms.SaveFileDialog]::Destination=Join-Path $Root 'NewForm.mcform';$session.Widgets.saveForm.RaiseClick();$new=Read-MedicalForm ([Windows.Forms.SaveFileDialog]::Destination)
Assert-Check (@($new.StageForms.Diaries).Count -eq 0 -and (Read-MedicalForm $destination).StageForms.Diaries.Count -eq 2) 'Saving new form preserves old file and excludes old diary structures'
$session=New-TestSession 'edit' 'diary' $second.Id;$session.Context.Path=Join-Path $Root 'DiaryEdited.mcform';$session.Widgets.fieldName.Text='Ф.И.О. во втором дневнике';$session.Widgets.saveForm.RaiseClick();$diarySaved=Read-MedicalForm $session.Context.Path
Assert-Check ($diarySaved.Schema.Sections[0].Fields[0].Label -ceq $script:universalConfig.Sections[0].Fields[0].Label) 'Diary editor Save keeps canonical initial schema'
Assert-Check ($diarySaved.StageForms.Diaries[1].Schema.Sections[0].Fields[0].Label -ceq 'Ф.И.О. во втором дневнике') 'Diary editor Save targets selected stable diary ID'
Assert-Check ($diarySaved.StageForms.Diaries[0].Schema.Sections[0].Fields[0].Label -cne 'Ф.И.О. во втором дневнике') 'Diary editor Save preserves other diary definitions'
$session=New-TestSession 'edit' 'discharge';$session.Context.Path=Join-Path $Root 'DischargeEdited.mcform';$session.Widgets.fieldName.Text='Ф.И.О. в эпикризе';$session.Widgets.saveForm.RaiseClick();$dischargeSaved=Read-MedicalForm $session.Context.Path
Assert-Check ($dischargeSaved.StageForms.Discharge.Schema.Sections[0].Fields[0].Label -ceq 'Ф.И.О. в эпикризе' -and -not $dischargeSaved.StageForms.Discharge.FollowInitialSchema) 'Discharge editor Save preserves custom schema instead of auto-follow reset'
# Exercise the real main-window handoff: a saved snapshot returned after
# Discard must be applied, and only a matching disk snapshot is marked saved.
Import-Functions (Join-Path $Project 'forms-ui-v59.ps1') @('Invoke-MedicalFormTemplateEditor','Set-MedicalEditorSavedFormMetadata','Get-MedicalFormSignature','Get-MedicalGeneratedSchema')
function Capture-Stage {}
function Ensure-MedicalCurrentTemplate {return $true}
function Apply-UniversalSettingsDraft($schema){$script:appliedSchema=$schema;$script:universalConfig=Copy-MedicalFormSchema $schema}
function Show-MedicalFormTemplateEditor {return $script:handoffResult}
function Request-MedicalClinicalCheckpoint {$script:checkpointCalls++}
function Mark-MedicalFormSaved {$script:markedFormCalls++}
$script:medicalWorkspaceReady=$true;$script:stage='initial';$script:markedFormCalls=0;$script:checkpointCalls=0
$script:handoffResult=Save-MedicalEditorFormSnapshot (Copy-MedicalFormSchema $script:universalConfig) (Read-MedicalTemplateModel $script:source) 'Handoff.docx' (New-MedicalEditorSaveContext $script:universalConfig 'edit' 'initial') $null
Invoke-MedicalFormTemplateEditor
Assert-Check ($script:activeMedicalFormPath -ceq $script:handoffResult.SavedFormPath -and $script:markedFormCalls -eq 1 -and $script:appliedSchema) 'Main editor handoff applies retained saved snapshot and records actual persistent form path'
$baseline=$script:medicalFormBaseline;$script:handoffResult.SavedSnapshotMatches=$false;$script:handoffResult.Schema.Sections[0].Fields[0].Label='Применено, но не сохранено в форму'
Invoke-MedicalFormTemplateEditor
Assert-Check ($script:universalConfig.Sections[0].Fields[0].Label -ceq 'Применено, но не сохранено в форму' -and $script:markedFormCalls -eq 1 -and $script:medicalFormBaseline -ceq $baseline) 'Main handoff applies later changes while keeping persistent baseline dirty'
Assert-Check ($script:universalValues.patient_name -ceq 'PATIENT ANSWER SECRET') 'Saved editor handoff retains patient answers'
Write-Output ('All '+$script:checks+' editor persistent-save checks passed.')
'@
try{
 [IO.File]::WriteAllText($child,$childSource,[Text.UTF8Encoding]::new($true))
 & $child $Project $temp $spec
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
