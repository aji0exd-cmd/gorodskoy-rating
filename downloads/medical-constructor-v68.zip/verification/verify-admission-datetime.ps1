﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v68'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Time([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
function Import-TimeFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors|Out-String)}
 foreach($node in $ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
  if($names.Count -eq 0 -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}
 }
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
Import-TimeFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
. (Join-Path $Project 'universal.ps1')
. (Join-Path $Project 'universal-ui.ps1')
$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
$temp=Join-Path ([IO.Path]::GetTempPath()) ('mc68-admission-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 $script:medicalProgramRoot=$temp
 $field=New-UniversalField 'name' 'Ф.И.О.' 'PATIENT_NAME' 'text' 'name'
 $config=[pscustomobject]@{Version=49;AutoTemplate=$false;PreserveTemplateFormatting=$true;Template=(Join-Path $temp 'original.docx');Sections=@([pscustomobject]@{Id='patient';Title='Пациент';Fields=@($field)})}
 New-UniversalTemplate $config.Template $config
 $zip=[IO.Compression.ZipFile]::Open($config.Template,[IO.Compression.ZipArchiveMode]::Update)
 try{
  $xml=Get-XmlPart $zip 'word/document.xml';$n=[Xml.XmlNamespaceManager]::new($xml.NameTable);$n.AddNamespace('w',$script:ns)
  $texts=@($xml.SelectNodes('//w:t',$n));$dateText=@($texts | Where-Object {$_.InnerText.Contains('{{ADMISSION_DATETIME}}')})[0]
  $dateText.InnerText='Исправленный осмотр: {{ADMISSION_DATE}} в {{ADMISSION_TIME}}'
  $zip.GetEntry('word/document.xml').Delete();Write-UniversalZipText $zip 'word/document.xml' $xml.OuterXml
 }finally{$zip.Dispose()}
 $sourceHash=(Get-FileHash $config.Template -Algorithm SHA256).Hash
 $script:universalConfig=$config;$script:universalValues=@{name='Тестовый Пациент'};$script:universalDetails=@{}
 $script:universalInputs=@{};$script:universalDetailInputs=@{}
 foreach($name in @('patientNameControl','patientBirthControl','patientAddressControl','streetControl','houseControl','apartmentControl')){Set-Variable -Scope Script -Name $name -Value ([pscustomobject]@{Text=''})}
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-01T08:15:42';Text=''}
 Assert-Time ((Sync-MedicalAdmissionDateTime).ToString('s') -ceq '2026-10-01T08:15:42') 'Controls without pending text retain exact selected time'
 $script:admissionControl.Text='01.10.2026  08:15'
 Assert-Time ((Sync-MedicalAdmissionDateTime).Second -eq 42) 'Unchanged visible minute does not erase saved seconds'
 foreach($entry in @(@('03.10.2026  21:47','2026-10-03T21:47:00'),@('05.10.2026 06:03','2026-10-05T06:03:00'),@('06.10.2026 04:05:17','2026-10-06T04:05:17'))){
  $script:admissionControl.Text=$entry[0]
  Capture-Universal
  $expected=[datetime]::ParseExact($entry[1],"yyyy-MM-dd'T'HH:mm:ss",[Globalization.CultureInfo]::InvariantCulture)
  Assert-Time ($script:admissionControl.Value -eq $expected) ('Capture commits corrected date/time '+$entry[1])
  $state=Get-UniversalState
  Assert-Time ($state.AdmissionDateTime -ceq $entry[1]) 'Patient state contains corrected full timestamp'
  $path=Join-Path $temp ('exam-'+$script:checks+'.docx')
  Save-UniversalDocument $path $config $script:universalValues $script:admissionControl.Value $script:universalDetails $true
  $z=[IO.Compression.ZipFile]::OpenRead($path)
  try{$document=Get-XmlPart $z 'word/document.xml';$text=($document.GetElementsByTagName('t',$script:ns)|ForEach-Object {$_.InnerText}) -join ''}finally{$z.Dispose()}
  Assert-Time ($text.Contains('Исправленный осмотр: '+$expected.ToString('dd.MM.yyyy')+' в '+$expected.ToString('HH:mm'))) 'Existing custom template renders corrected date and time markers'
  Assert-Time (-not $text.Contains('{{ADMISSION_')) 'Filled Word date/time contains no unresolved system markers'
  $round=Read-UniversalDocumentState $path
  $stamp=if($round.AdmissionDateTime -is [datetime]){$round.AdmissionDateTime.ToString('s')}else{[string]$round.AdmissionDateTime}
  Assert-Time ($stamp -ceq $entry[1]) 'Saved Word metadata contains same corrected timestamp as visible text'
  $script:admissionControl.Value=[datetime]'2001-01-01T00:00:00';$script:admissionControl.Text=''
  Restore-UniversalState $round
  Assert-Time ($script:admissionControl.Value -eq $expected) 'Reopening persisted patient state restores corrected time'
 }
 foreach($bad in @('31.02.2026 12:10','05.10.2026 25:00','05.10.2026 10:99','не дата')){
  $before=$script:admissionControl.Value;$script:admissionControl.Text=$bad;$failed=$false
  try{[void](Sync-MedicalAdmissionDateTime)}catch{$failed=$true}
  Assert-Time ($failed -and $script:admissionControl.Value -eq $before) ('Invalid pending timestamp rejected without changing previous value: '+$bad)
 }
 Assert-Time ((Get-FileHash $config.Template -Algorithm SHA256).Hash -ceq $sourceHash) 'Date/time correction never changes source Word template'
 Write-Output ('CHECKS '+$script:checks)
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
