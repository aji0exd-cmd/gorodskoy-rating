﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v73'))
$ErrorActionPreference='Stop'
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-clinical-ui-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
$child=Join-Path $temp 'private-clinical-ui.ps1'
$childSource=@'
param([string]$Project,[string]$TestRoot)
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Clinical([bool]$condition,[string]$message){if(-not $condition){throw ($message+'; last UI message: '+[Windows.Forms.MessageBox]::LastMessage)};$script:checks++;Write-Output ('PASS '+$message)}
function Import-ClinicalFunctions([string]$path,[string[]]$names){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors | Out-String)}
 foreach($name in $names){$n=$ast.Find({param($node)$node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $name},$false);if(-not $n){throw ('Missing production function '+$name)};. ([scriptblock]::Create(($n.Extent.Text -replace '^function\s+','function script:')))}
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @"
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
public class ClinicalWidget {
 private string text="";
 public virtual string Text {get{return text;}set{string next=value ?? "";if(next==text)return;text=next;if(TextChanged!=null)TextChanged(this,EventArgs.Empty);}}
 public string[] Lines {get{return Text.Split(new string[]{"\r\n","\r","\n"},StringSplitOptions.None);}set{Text=String.Join("\r\n",value ?? new string[0]);}}
 public string Name {get;set;} public object Tag {get;set;} public object Font {get;set;} public object BackColor {get;set;} public object ForeColor {get;set;}
 public ClinicalWidget Parent {get;set;} public ClinicalControls Controls {get;private set;} public Point Location {get;set;} public int Top {get{return Location.Y;}set{Location=new Point(Location.X,value);}} public int Left {get{return Location.X;}set{Location=new Point(value,Location.Y);}}
 public int Width {get;set;} private int height=30;
 public int Height {get{
  if(!AutoSize)return height;int size=0;foreach(ClinicalWidget child in Controls){int h=child.Height+child.Margin.Top+child.Margin.Bottom;if(RowCount==1 || (this is Windows.Forms.FlowLayoutPanel && FlowDirection!="TopDown"))size=Math.Max(size,h);else size+=h;}return Math.Max(22,size+Padding.Top+Padding.Bottom);
 }set{height=value;}}
 public int Bottom {get{return Top+Height;}} public Size Size {get{return new Size(Width,Height);}set{Width=value.Width;Height=value.Height;}} public Size ClientSize {get;set;} public Size MinimumSize {get;set;} public Size MaximumSize {get;set;} public Size AutoScrollMinSize {get;set;}
 public Windows.Forms.Padding Padding {get;set;} public Windows.Forms.Padding Margin {get;set;} public ArrayList ColumnStyles {get;private set;} public ArrayList RowStyles {get;private set;} public int ColumnCount {get;set;} public int RowCount {get;set;}
 public bool AutoSize {get;set;} public string AutoSizeMode {get;set;} public string Anchor {get;set;} public string Dock {get;set;} public bool AutoScroll {get;set;} public string FlowDirection {get;set;} public bool WrapContents {get;set;}
 public bool Enabled {get;set;} public bool Visible {get;set;} public bool ReadOnly {get;set;} public bool IsDisposed {get;private set;} public bool Focused {get;private set;} public int SuspendCount {get;private set;} public int ResumeCount {get;private set;}
 public bool Multiline {get;set;} public bool AcceptsReturn {get;set;} public bool AcceptsTab {get;set;} public string ScrollBars {get;set;} public string AccessibleName {get;set;} public string TextAlign {get;set;} public string BorderStyle {get;set;} public string FlatStyle {get;set;} public object FlatAppearance {get;set;} public string DialogResult {get;set;} public string DropDownStyle {get;set;} public int DropDownWidth {get;set;} public string CustomFormat {get;set;} public string Format {get;set;} public bool ShowUpDown {get;set;}
 public ArrayList Items {get;private set;} private int selectedIndex=-1;
 public int SelectedIndex {get{return selectedIndex;}set{if(selectedIndex==value)return;selectedIndex=value;if(value>=0 && value<Items.Count)Text=Convert.ToString(Items[value]);if(SelectedIndexChanged!=null)SelectedIndexChanged(this,EventArgs.Empty);}}
 public object SelectedItem {get{return SelectedIndex>=0 && SelectedIndex<Items.Count?Items[SelectedIndex]:null;}set{SelectedIndex=Items.IndexOf(value);}}
 private bool check;public bool Checked {get{return check;}set{if(check==value)return;check=value;if(CheckedChanged!=null)CheckedChanged(this,EventArgs.Empty);}}
 private DateTime date=DateTime.Now;public DateTime Value {get{return date;}set{if(date==value)return;date=value;if(ValueChanged!=null)ValueChanged(this,EventArgs.Empty);}}
 private Point scroll=Point.Empty;public Point AutoScrollPosition {get{return scroll;}set{Point next=new Point(-Math.Max(0,value.X),-Math.Max(0,value.Y));int dx=next.X-scroll.X,dy=next.Y-scroll.Y;foreach(ClinicalWidget c in Controls)c.Location=new Point(c.Left+dx,c.Top+dy);scroll=next;}}
 public int ContentHeight {get{int bottom=AutoScrollMinSize.Height;foreach(ClinicalWidget child in Controls)bottom=Math.Max(bottom,child.Bottom-scroll.Y);return bottom;}}
 public ClinicalWidget(){Controls=new ClinicalControls(this);Items=new ArrayList();ColumnStyles=new ArrayList();RowStyles=new ArrayList();Padding=new Windows.Forms.Padding(0);Margin=new Windows.Forms.Padding(0);Width=200;Enabled=true;Visible=true;ClientSize=new Size(1100,600);FlatAppearance=new ClinicalFlatAppearance();}
 public event EventHandler Click;public event EventHandler TextChanged;public event EventHandler CheckedChanged;public event EventHandler SelectedIndexChanged;public event EventHandler ValueChanged;public event EventHandler Enter;public event EventHandler Leave;
 public void RaiseClick(){if(Click!=null)Click(this,EventArgs.Empty);}public void PerformClick(){RaiseClick();}public void RaiseEnter(){if(Enter!=null)Enter(this,EventArgs.Empty);}public void RaiseLeave(){if(Leave!=null)Leave(this,EventArgs.Empty);} public bool Focus(){Focused=true;RaiseEnter();return true;} public void SelectAll(){} public void Refresh(){} public void Invalidate(){} public void Invalidate(bool children){}
 public void SuspendLayout(){SuspendCount++;}public void ResumeLayout(bool layout){ResumeCount++;}public void PerformLayout(){}public void Dispose(){IsDisposed=true;foreach(ClinicalWidget child in Controls)child.Dispose();} public void SetBounds(int x,int y,int w,int h){Location=new Point(x,y);Width=w;Height=h;}public void ScrollControlIntoView(ClinicalWidget control){} public void Close(){}
}
public class ClinicalFlatAppearance {public int BorderSize {get;set;}public object BorderColor {get;set;}}
public class ClinicalControls:IEnumerable {
 private List<ClinicalWidget> items=new List<ClinicalWidget>();private ClinicalWidget owner;
 public ClinicalControls(ClinicalWidget parent){owner=parent;}public int Count {get{return items.Count;}}public ClinicalWidget this[int index]{get{return items[index];}}
 public void Add(ClinicalWidget child){if(child.Parent!=null)child.Parent.Controls.Remove(child);items.Add(child);child.Parent=owner;}public void Add(ClinicalWidget child,int column,int row){Add(child);}public void Remove(ClinicalWidget child){if(items.Remove(child))child.Parent=null;}public bool Contains(ClinicalWidget child){return items.Contains(child);}public int IndexOf(ClinicalWidget child){return items.IndexOf(child);}public void SetChildIndex(ClinicalWidget child,int index){if(!items.Remove(child))throw new InvalidOperationException();items.Insert(Math.Max(0,Math.Min(index,items.Count)),child);}public void Clear(){foreach(ClinicalWidget child in items)child.Parent=null;items.Clear();}public IEnumerator GetEnumerator(){return items.GetEnumerator();}
}
namespace Windows.Forms {
 public enum DialogResult {None,OK,Cancel}
 public class SaveFileDialog:ClinicalWidget {
  public static string NextFileName="";public static string NextResult="OK";public static string LastInitialDirectory="";public static string LastSuggestedName="";public static int Calls=0;
  public string Filter {get;set;}public string Title {get;set;}public string DefaultExt {get;set;}public bool AddExtension {get;set;}public bool OverwritePrompt {get;set;}public string InitialDirectory {get;set;}public string FileName {get;set;}
  public object ShowDialog(){return ShowDialog(null);}public object ShowDialog(object owner){Calls++;LastInitialDirectory=InitialDirectory;LastSuggestedName=FileName;if(NextFileName.Length>0)FileName=NextFileName;else FileName=System.IO.Path.Combine(InitialDirectory,FileName);return NextResult;}
 }
 public class FolderBrowserDialog:ClinicalWidget {public string Description {get;set;}public string SelectedPath {get;set;}public string ShowDialog(){return "Cancel";}}
 public enum SizeType {Absolute,Percent,AutoSize}
 public class Padding {public int Left {get;set;}public int Right {get;set;}public int Top {get;set;}public int Bottom {get;set;}public Padding(int a){Left=Right=Top=Bottom=a;}public Padding(int l,int t,int r,int b){Left=l;Top=t;Right=r;Bottom=b;}}
 public class ColumnStyle {public ColumnStyle(SizeType t,float n){}}public class RowStyle {public int Height {get;set;}public RowStyle(SizeType t,float n){Height=(int)n;}}
 public class TableLayoutPanel:ClinicalWidget{}public class FlowLayoutPanel:ClinicalWidget{}public class TextBox:ClinicalWidget{}public class Label:ClinicalWidget{}public class Button:ClinicalWidget{}public class CheckBox:ClinicalWidget{}public class ComboBox:ClinicalWidget{}public class DateTimePicker:ClinicalWidget{}public class Panel:ClinicalWidget{}
 public static class MessageBox {public static string Response="Yes";public static string LastMessage="";public static string Show(params object[] args){LastMessage=args.Length>1 ? Convert.ToString(args[1]) : "";return Response;}}
}
namespace System.Windows.Forms {public enum DialogResult {None,OK,Cancel}public class SaveFileDialog:global::Windows.Forms.SaveFileDialog{}public class FolderBrowserDialog:global::Windows.Forms.FolderBrowserDialog{}public static class MessageBox {public static string Show(params object[] args){return global::Windows.Forms.MessageBox.Show(args);}}public class TableLayoutPanel:global::Windows.Forms.TableLayoutPanel{}public class FlowLayoutPanel:global::Windows.Forms.FlowLayoutPanel{}public class TextBox:global::Windows.Forms.TextBox{}public class Label:global::Windows.Forms.Label{}public class Button:global::Windows.Forms.Button{}public class CheckBox:global::Windows.Forms.CheckBox{}public class DateTimePicker:global::Windows.Forms.DateTimePicker{}}
public class SafeComboBox:Windows.Forms.ComboBox{}public class MedicalOutlineTable:Windows.Forms.TableLayoutPanel{}
"@
function New-Object {
 [CmdletBinding()]param([Parameter(Position=0,Mandatory=$true)][string]$TypeName,[Parameter(Position=1)][object[]]$ArgumentList)
 if($TypeName -eq 'Drawing.Font'){return [pscustomobject]@{Name=$ArgumentList[0];Size=$ArgumentList[1]}}
 if($PSBoundParameters.ContainsKey('ArgumentList')){return ,(Microsoft.PowerShell.Utility\New-Object -TypeName $TypeName -ArgumentList $ArgumentList)}
 return ,(Microsoft.PowerShell.Utility\New-Object -TypeName $TypeName)
}
function Set-DarkTheme($root){}
function New-MedicalInputFrame($control){return $control}
function Get-ClinicalDescendants($control){foreach($childControl in $control.Controls){$childControl;Get-ClinicalDescendants $childControl}}
# Core/UI functions are private to this child script. Actual delegates cross the
# GetNewClosure boundary without promoting app commands to global scope.
Import-ClinicalFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
. (Join-Path $Project 'universal.ps1')
. (Join-Path $Project 'forms-v59.ps1')
. (Join-Path $Project 'template-editor-v59.ps1')
. (Join-Path $Project 'template-editor-operations-v61.ps1')
. (Join-Path $Project 'template-format-v62.ps1')
. (Join-Path $Project 'universal-ui.ps1')
. (Join-Path $Project 'clinical-stages-v67.ps1')
. (Join-Path $Project 'clinical-ui-v67.ps1')
. (Join-Path $Project 'forms-ui-v59.ps1')
. (Join-Path $Project 'workspace-settings.ps1')
$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
$script:medicalProgramRoot=Join-Path $TestRoot 'program';$script:medicalTemplatesFolder=Join-Path $script:medicalProgramRoot 'Шаблоны'
$script:universalConfigPath=Join-Path $script:medicalProgramRoot 'form-settings.json'
[void][IO.Directory]::CreateDirectory($script:medicalProgramRoot)
$script:darkBg='Background';$script:darkPanel='Panel';$script:darkMuted='Muted';$script:uiSuccess='Success';$script:uiDanger='Danger'
$panel=New-Object ClinicalWidget;$panel.AutoScroll=$true;$panel.ClientSize=New-Object Drawing.Size(1100,600)
$form=New-Object ClinicalWidget;$save=New-Object ClinicalWidget;$caseSave=New-Object Windows.Forms.Button
function Update-MedicalNavigation(){}
function Capture-Stage(){if($script:stage -eq 'initial'){Capture-Universal}else{Capture-MedicalClinicalStage}}
function Set-ClinicalPart([string]$path,[string]$name,[string]$xml){$z=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update);try{$e=$z.GetEntry($name);if($e){$e.Delete()};Write-UniversalZipText $z $name $xml}finally{$z.Dispose()}}
function Get-ClinicalXml([string]$path,[string]$name='word/document.xml'){$z=[IO.Compression.ZipFile]::OpenRead($path);try{return (Get-XmlPart $z $name)}finally{$z.Dispose()}}
function Get-ClinicalText([string]$path){$x=Get-ClinicalXml $path;$n=[Xml.XmlNamespaceManager]::new($x.NameTable);$n.AddNamespace('w',$script:ns);return (($x.SelectNodes('//w:t',$n) | ForEach-Object {$_.InnerText}) -join '')}
function ConvertTo-ClinicalComparable($value){
 if($null -eq $value){return $null}
 if($value -is [Collections.IDictionary]){$ordered=[ordered]@{};foreach($key in @($value.Keys | Sort-Object)){$ordered[[string]$key]=ConvertTo-ClinicalComparable $value[$key]};return $ordered}
 if($value -is [array]){$items=@();foreach($item in $value){$items+=@(ConvertTo-ClinicalComparable $item)};return ,$items}
 if($value -is [pscustomobject]){$ordered=[ordered]@{};foreach($property in @($value.PSObject.Properties | Sort-Object Name)){$ordered[$property.Name]=ConvertTo-ClinicalComparable $property.Value};return $ordered}
 return $value
}
function Get-ClinicalFingerprint($value){return ((ConvertTo-ClinicalComparable $value) | ConvertTo-Json -Depth 80 -Compress)}
$script:fontFile=Join-Path $Project 'document-font.json'
$script:medicalWorkspaceReady=$true;$script:medicalEndActionHost=$null;$script:stage='diary';$script:progressLabel=New-Object Windows.Forms.Label
$newDiary=New-Object Windows.Forms.Button;$newDiary.Text='Добавить дневник';$newDiary.Add_Click({Invoke-MedicalAddDiary})
$sidebar=New-Object Windows.Forms.Panel;$sidebar.Controls.Add($newDiary)
$script:admissionControl=New-Object Windows.Forms.DateTimePicker;$script:admissionControl.Value=[datetime]'2026-10-14T10:30:00'
foreach($name in @('patientNameControl','patientBirthControl','patientAddressControl','streetControl','houseControl','apartmentControl')){Set-Variable -Scope Script -Name $name -Value (New-Object Windows.Forms.TextBox)}
$initialFields=@()
foreach($spec in @(@('name','Ф.И.О.','PATIENT_NAME','text','name'),@('birth','Дата рождения','PATIENT_BIRTH','text','birth'),@('address','Адрес','PATIENT_ADDRESS','text','address'),@('complaints','Жалобы','COMPLAINTS','multiline',''),@('history','Анамнез','DISEASE_HISTORY','multiline',''),@('examination','Осмотр','EXAMINATION','multiline',''),@('diagnosis','Первоначальный диагноз','PRELIMINARY_DIAGNOSIS','multiline',''),@('choice','Выбор с уточнением','CLINICAL_CHOICE','choice_detail',''),@('multi','Несколько ответов','CLINICAL_MULTI','multi',''),@('repeat','Повторяющиеся строки','CLINICAL_REPEAT','repeat',''),@('subheading','Информация','CLINICAL_HEADING','heading',''))){
 $f=New-UniversalField $spec[0] $spec[1] $spec[2] $spec[3] $spec[4];$f.Required=$false
 if($f.Type -in @('choice_detail','multi','repeat')){$f.Options=@('Первый','Второй','Третий')}
 if($f.Type -eq 'choice_detail'){$f | Add-Member -NotePropertyName DetailFormPosition -NotePropertyValue 'right';$f | Add-Member -NotePropertyName DetailWordPosition -NotePropertyValue 'marker';$f | Add-Member -NotePropertyName DetailMarker -NotePropertyValue 'CLINICAL_DETAIL'}
 $initialFields+=@($f)
}
$script:universalConfig=[pscustomobject]@{Version=49;AutoTemplate=$true;Template='initial.docx';PreserveTemplateFormatting=$true;Sections=@([pscustomobject]@{Id='initial';Title='Первичный осмотр';Fields=$initialFields})}
$script:universalValues=@{name='Первичный пациент';birth='14.01.1985';address='Первичный адрес';complaints='Первичные жалобы';history='Первичный анамнез';examination='Первичный осмотр';diagnosis='Исходный диагноз';choice='Первый';multi='Первый';repeat='Начальная строка'}
$script:universalDetails=@{choice='Первичное уточнение'};$script:universalInputs=@{};$script:universalDetailInputs=@{};$script:universalRepeatInputs=@{};$script:universalMultiInputs=@{};$script:universalIndicators=@{};$script:initialByLabel=@{};$script:universalWordFields=@()
$initialFingerprint=Get-ClinicalFingerprint (Get-UniversalState)
[void](Initialize-MedicalClinicalWorkspace)
$diarySchema=Copy-MedicalFormSchema $script:universalConfig
$first=Add-MedicalClinicalDiary $diarySchema 'Первый дневник';$second=Add-MedicalClinicalDiary $diarySchema 'Второй дневник'
# Explicit-schema imports retain legacy support; this fixture now opts into the common authored form.
[void](Set-MedicalSharedDiarySchema $diarySchema)
$script:medicalActiveDiaryId=$first.Id
Assert-Clinical ($first.Id -ne $second.Id) 'Independent diaries have stable distinct identifiers'
Assert-Clinical (-not [object]::ReferenceEquals($first.Schema,$second.Schema) -and -not [object]::ReferenceEquals($first.Values,$second.Values) -and -not [object]::ReferenceEquals($first.Details,$second.Details)) 'Diary schema, value and clarification maps are separate actual objects'
Open-MedicalClinicalStage
Assert-Clinical ($script:medicalClinicalBindings.Count -eq 2 -and $panel.Controls.Count -eq 1) 'Production builder renders all diary entries simultaneously in one work area'
Assert-Clinical ($newDiary.Parent -eq $script:medicalClinicalFlow -and -not $sidebar.Controls.Contains($newDiary)) 'Add Diary moves out of the sidebar into the work area'
Assert-Clinical ($newDiary.Anchor -ceq 'Top,Left' -and $newDiary.Dock -ceq 'None' -and $newDiary.TextAlign -ceq 'MiddleLeft') 'Add Diary remains aligned to the left of its work-area row'
$workChildren=@($script:medicalClinicalFlow.Controls);$newIndex=$script:medicalClinicalFlow.Controls.IndexOf($newDiary)
Assert-Clinical ($newIndex -gt [Array]::FindLastIndex($workChildren,[Predicate[object]]{param($n)$n -is [MedicalOutlineTable]})) 'Add Diary occupies the row after the last diary record'
Assert-Clinical ($script:medicalEndActionHost.Parent -eq $script:medicalClinicalFlow -and $caseSave.Parent -eq $script:medicalEndActionHost) 'Save Card remains in the final clinical-work-area row'
$a=$script:medicalClinicalBindings[$first.Id];$b=$script:medicalClinicalBindings[$second.Id]
Assert-Clinical ($a.Inputs.Count -eq 10 -and $b.Inputs.Count -eq 10 -and -not $a.Inputs.ContainsKey('subheading')) 'Every editable field type has one bound control and headings do not become patient inputs'
Assert-Clinical (-not [object]::ReferenceEquals($a.Inputs.complaints,$b.Inputs.complaints)) 'Same field identifiers in different diaries never reuse widget objects'
Assert-Clinical ($a.Inputs.name.Enabled -and -not $a.Inputs.name.ReadOnly -and $a.Inputs.birth.Enabled -and $a.Inputs.address.Enabled) 'Linked patient-name, birth and address fields remain editable in diaries'
$a.Inputs.complaints.Text='Жалобы первого дневника';$b.Inputs.complaints.Text='Жалобы второго дневника'
Assert-Clinical ((Get-MedicalClinicalContext 'diary' $first.Id).Values.complaints -ceq 'Жалобы первого дневника' -and (Get-MedicalClinicalContext 'diary' $second.Id).Values.complaints -ceq 'Жалобы второго дневника') 'Native TextChanged events write directly into the matching diary state'
Assert-Clinical ($script:universalValues.complaints -ceq 'Первичные жалобы') 'Diary input events never overwrite canonical primary-examination values'
$a.Inputs.choice.SelectedItem='Второй';$a.DetailInputs.choice.Text='Уточнение первого';$b.DetailInputs.choice.Text='Уточнение второго'
Assert-Clinical ((Get-MedicalClinicalContext 'diary' $first.Id).Details.choice -ceq 'Уточнение первого' -and (Get-MedicalClinicalContext 'diary' $second.Id).Details.choice -ceq 'Уточнение второго') 'Native detail text events bind each clarification to its own diary'
$a.Inputs.choice.SelectedItem='Третий'
Assert-Clinical ((Get-MedicalClinicalContext 'diary' $first.Id).Details.choice -ceq '' -and (Get-MedicalClinicalContext 'diary' $second.Id).Details.choice -ceq 'Уточнение второго') 'Changing a choice clears only that diary clarification'
$a.DetailInputs.choice.Text='Новое уточнение первого'
$a.MultiInputs.multi[1].Checked=$true;$b.MultiInputs.multi[0].Checked=$false;$b.MultiInputs.multi[2].Checked=$true
Assert-Clinical ((Get-MedicalClinicalContext 'diary' $first.Id).Values.multi -ceq "Первый`r`nВторой" -and (Get-MedicalClinicalContext 'diary' $second.Id).Values.multi -ceq 'Третий') 'Native checkbox events preserve independent multi-select values'
$repeatAdd=@(Get-ClinicalDescendants $a.RepeatInputs.repeat.Host | Where-Object {$_.Text -ceq '+ Строка'})[0]
$repeatAdd.RaiseClick();$a.RepeatInputs.repeat.Rows[1].Editor.Text='Добавленная строка первого'
$b.RepeatInputs.repeat.Rows[0].Editor.Text='Строка второго'
Assert-Clinical ((Get-MedicalClinicalContext 'diary' $first.Id).Values.repeat -ceq "Начальная строка`r`nДобавленная строка первого" -and (Get-MedicalClinicalContext 'diary' $second.Id).Values.repeat -ceq 'Строка второго') 'Real Add Row and TextChanged callbacks save separate repeated-row values'
$removedEditor=$a.RepeatInputs.repeat.Rows[0].Editor;$remove=@(Get-ClinicalDescendants $a.RepeatInputs.repeat.Rows[0].Panel | Where-Object {$_.Text -ceq 'Удалить'})[0];$remove.RaiseClick()
Assert-Clinical ($a.RepeatInputs.repeat.Rows.Count -eq 1 -and (Get-MedicalClinicalContext 'diary' $first.Id).Values.repeat -ceq 'Добавленная строка первого' -and $b.RepeatInputs.repeat.Rows.Count -eq 1) 'Removing a repeated row changes only its owning diary and resulting saved text'
$a.DateControl.Value=[datetime]'2026-10-14T13:45:00';$b.DateControl.Value=[datetime]'2026-10-15T08:10:00'
Assert-Clinical ((Get-MedicalClinicalContext 'diary' $first.Id).DateTime -eq [datetime]'2026-10-14T13:45:00' -and (Get-MedicalClinicalContext 'diary' $second.Id).DateTime -eq [datetime]'2026-10-15T08:10:00') 'Native ValueChanged updates each diary date and time independently'
Capture-MedicalClinicalStage
Assert-Clinical ((Get-ClinicalFingerprint (Get-UniversalState)) -ceq $initialFingerprint) 'Capturing every visible diary leaves the canonical initial schema and patient maps value-equivalent'
$firstState=Get-ClinicalFingerprint (Get-MedicalClinicalState)
$baselineHeight=$panel.ContentHeight;$baselineChildren=$script:medicalClinicalFlow.Controls.Count
for($round=1;$round -le 6;$round++){
 $panel.AutoScrollPosition=New-Object Drawing.Point(($round*7),($round*83));Open-MedicalClinicalStage
 Assert-Clinical ($script:medicalClinicalFlow.Left -eq 20 -and $script:medicalClinicalFlow.Top -eq 15 -and $panel.AutoScrollPosition.Y -eq 0) ('Diary rebuild '+$round+' resets native scroll coordinates before replacing controls')
 Assert-Clinical ($panel.ContentHeight -eq $baselineHeight -and $script:medicalClinicalFlow.Controls.Count -eq $baselineChildren -and $script:medicalClinicalBindings.Count -eq 2) ('Diary rebuild '+$round+' does not duplicate widgets, add buttons or vertical space')
 Assert-Clinical ((Get-ClinicalFingerprint (Get-MedicalClinicalState)) -ceq $firstState) ('Diary rebuild '+$round+' retains all saved entries without cross-contamination')
}
$oldFlow=$script:medicalClinicalFlow;$oldBindings=$script:medicalClinicalBindings
$newDiary.RaiseClick()
Assert-Clinical (@($script:medicalClinicalForms.Diaries).Count -eq 3 -and $script:medicalClinicalBindings.Count -eq 3 -and $newDiary.Parent -eq $script:medicalClinicalFlow -and -not [object]::ReferenceEquals($oldFlow,$script:medicalClinicalFlow)) 'The production work-area Add Diary event captures old answers and builds exactly one additional record'
Assert-Clinical ($script:medicalClinicalFlow.Controls.IndexOf($newDiary) -eq ($newIndex+1) -and $panel.ContentHeight -gt $baselineHeight) 'Add Diary moves down one record after adding a new diary'
Assert-Clinical ((Get-MedicalClinicalContext 'diary' $first.Id).Values.complaints -ceq 'Жалобы первого дневника' -and (Get-MedicalClinicalContext 'diary' $second.Id).Values.complaints -ceq 'Жалобы второго дневника') 'Adding a third diary preserves unsaved patient values in both previous diaries'
$thirdId=$script:medicalActiveDiaryId
Assert-Clinical ([string](Get-MedicalClinicalContext 'diary' $thirdId).Values.complaints -ceq '' -and [string](Get-MedicalClinicalContext 'diary' $thirdId).Details.choice -ceq '') 'A new diary starts with blank clinical answers and clarifications rather than copying initial or earlier diary answers'
foreach($patientRoleId in @('name','birth','address')){Assert-Clinical ((Get-MedicalClinicalContext 'diary' $thirdId).Values[$patientRoleId] -ceq $script:universalValues[$patientRoleId]) ('A new diary retains linked patient identity '+$patientRoleId)}
$script:medicalClinicalBindings[$thirdId].Inputs.complaints.Text='Жалобы третьего дневника'
Assert-Clinical ((Get-MedicalClinicalContext 'diary' $thirdId).Values.complaints -ceq 'Жалобы третьего дневника' -and (Get-MedicalClinicalContext 'diary' $first.Id).Values.complaints -ceq 'Жалобы первого дневника' -and (Get-MedicalClinicalContext 'diary' $second.Id).Values.complaints -ceq 'Жалобы второго дневника') 'Filling the new third diary retains a separate response in the shared structure'
$script:stage='discharge';Open-MedicalClinicalStage
$c=$script:medicalClinicalBindings.discharge
Assert-Clinical ($script:medicalClinicalBindings.Count -eq 1 -and -not $newDiary.Visible -and -not $newDiary.Parent) 'Discharge shows one complete independent form and hides the diary add action'
foreach($id in @('name','birth','address','complaints','history','examination')){
 Assert-Clinical ($c.Inputs[$id].Enabled -and -not $c.Inputs[$id].ReadOnly -and $c.Inputs[$id].Text -ceq $script:universalValues[$id]) ('Discharge auto-fills editable primary-examination field '+$id)
}
foreach($marker in @('FINAL_DIAGNOSIS','EXAMINATION_RESULTS','TREATMENT_RESULTS','RECOMMENDATIONS')){
 $f=@(Get-UniversalFields $c.Context.Schema | Where-Object {$_.Marker -ceq $marker})[0]
 Assert-Clinical ($null -ne $f -and $c.Inputs.ContainsKey($f.Id) -and -not $c.Inputs[$f.Id].ReadOnly) ('Discharge includes an editable section for '+$marker)
}
$c.Inputs.complaints.Text='Уточнённые жалобы эпикриза';$c.Inputs.name.Text='Имя только для эпикриза';$c.Inputs.examination.Text='';$c.DetailInputs.choice.Text='Уточнение эпикриза'
$c.Inputs.recommendations.Text='Оставаться под наблюдением'
Capture-MedicalClinicalStage
$script:universalValues.complaints='Позже изменённые первичные жалобы';$script:universalValues.history='Позже изменённый анамнез';$script:universalValues.examination='Позже изменённый первичный осмотр';$script:universalValues.name='Новое первичное имя';$script:universalDetails.choice='Позже изменённое первичное уточнение'
Sync-MedicalDischargeFromInitial;Open-MedicalClinicalStage;$c=$script:medicalClinicalBindings.discharge
Assert-Clinical ($c.Inputs.complaints.Text -ceq 'Уточнённые жалобы эпикриза' -and $c.Inputs.name.Text -ceq 'Имя только для эпикриза' -and $c.Inputs.examination.Text -ceq '' -and $c.DetailInputs.choice.Text -ceq 'Уточнение эпикриза') 'Manual discharge changes, including intentionally blank fields, survive later primary-examination edits'
Assert-Clinical ($c.Inputs.history.Text -ceq 'Позже изменённый анамнез') 'An untouched discharge field continues to follow its primary-examination source'
Assert-Clinical ($script:universalValues.name -ceq 'Новое первичное имя' -and $script:universalValues.examination -ceq 'Позже изменённый первичный осмотр') 'Editing discharge patient roles or blanking clinical fields never edits the primary examination'
$script:stage='diary';Open-MedicalClinicalStage
Assert-Clinical ($script:medicalClinicalBindings[$first.Id].Inputs.complaints.Text -ceq 'Жалобы первого дневника' -and $script:medicalClinicalBindings[$second.Id].Inputs.complaints.Text -ceq 'Жалобы второго дневника') 'Returning to Diaries after discharge preserves each editable entry'
$panel.ClientSize=New-Object Drawing.Size(850,600);Resize-MedicalClinicalForm
Assert-Clinical ($script:medicalClinicalFlow.Width -eq 792 -and $script:medicalClinicalFlow.Left -eq 20 -and $script:medicalClinicalFlow.Top -eq 15) 'Clinical resize adjusts the available width without shifting the form origin'
Assert-Clinical (-not $script:medicalClinicalBuilding -and $panel.SuspendCount -eq $panel.ResumeCount) 'Production rendering always resets building guards and balances suspended layouts'
# The actual unified-editor command must bind the selected clinical record.
$canonicalBeforeEdit=Get-ClinicalFingerprint (Get-UniversalState)
$secondValuesBeforeEdit=Get-ClinicalFingerprint ([pscustomobject]@{Values=(Get-MedicalClinicalContext 'diary' $second.Id).Values;Details=(Get-MedicalClinicalContext 'diary' $second.Id).Details})
$script:medicalActiveDiaryId=$first.Id
function Show-MedicalFormTemplateEditor($owner,$schema){
 $script:clinicalEditorReceived=Copy-MedicalFormSchema $schema
 $draft=Copy-MedicalFormSchema $schema
 $draft.Sections[0].Title='РАЗДЕЛ ПЕРВОГО ДНЕВНИКА'
 $draft.Sections[0].Fields[3].Label='ЖАЛОБЫ ПЕРВОГО ДНЕВНИКА'
 return [pscustomobject]@{Schema=$draft;Template=[pscustomobject]@{Name='Дневник.docx'}}
}
Invoke-MedicalFormTemplateEditor
Assert-Clinical ($script:clinicalEditorReceived.Sections[0].Fields[3].Id -ceq 'complaints' -and (Get-MedicalClinicalContext 'diary' $first.Id).Schema.Sections[0].Fields[3].Label -ceq 'ЖАЛОБЫ ПЕРВОГО ДНЕВНИКА') 'Actual unified editor updates the shared diary schema and preserves stable field IDs'
Assert-Clinical ((Get-MedicalClinicalContext 'diary' $second.Id).Schema.Sections[0].Fields[3].Label -ceq 'ЖАЛОБЫ ПЕРВОГО ДНЕВНИКА' -and (Get-ClinicalFingerprint ([pscustomobject]@{Values=(Get-MedicalClinicalContext 'diary' $second.Id).Values;Details=(Get-MedicalClinicalContext 'diary' $second.Id).Details})) -ceq $secondValuesBeforeEdit -and (Get-ClinicalFingerprint (Get-UniversalState)) -ceq $canonicalBeforeEdit) 'Editing the shared diary structure updates every diary while preserving independent patient answers and the canonical initial form'
Assert-Clinical ((Get-MedicalClinicalContext 'diary' $first.Id).Values.complaints -ceq 'Жалобы первого дневника' -and (Get-MedicalClinicalContext 'diary' $first.Id).Details.choice -ceq 'Новое уточнение первого') 'Real editor apply retains existing diary answers and clarifications'
# Save Form is invoked from the diary page; it saves reusable layouts for all stages.
$patientBeforeFormSave=Get-ClinicalFingerprint (Get-MedicalClinicalState)
$script:activeMedicalFormPath='';$script:activeMedicalFormName='Форма с дневниками';$script:medicalWorkspaceReady=$true
[Windows.Forms.SaveFileDialog]::NextFileName=Join-Path $script:medicalProgramRoot 'Форма с дневниками.mcform'
Invoke-MedicalSaveForm
$mcformPath=[Windows.Forms.SaveFileDialog]::NextFileName
Assert-Clinical ([IO.File]::Exists($mcformPath) -and [Windows.Forms.SaveFileDialog]::LastInitialDirectory -ceq $script:medicalProgramRoot) 'Actual Save Form uses the program directory and produces a reusable MCFORM from the diary page'
$reusableJson=[IO.File]::ReadAllText($mcformPath);$reusable=$reusableJson | ConvertFrom-Json
Assert-Clinical (@($reusable.StageForms.Diaries).Count -eq 3 -and $null -ne $reusable.StageForms.DiaryForm -and $null -ne $reusable.StageForms.Discharge) 'The UI Save Form action stores the common diary form, diary records and discharge layout'
Assert-Clinical ($reusable.StageForms.DiaryForm.Schema.Sections[0].Title -ceq 'РАЗДЕЛ ПЕРВОГО ДНЕВНИКА' -and $reusable.StageForms.DiaryForm.Schema.Sections[0].Fields[3].Label -ceq 'ЖАЛОБЫ ПЕРВОГО ДНЕВНИКА' -and @($reusable.StageForms.Diaries | Where-Object {$_.Schema.Sections[0].Fields[3].Label -cne 'ЖАЛОБЫ ПЕРВОГО ДНЕВНИКА'}).Count -eq 0) 'The UI saves edited section and field names in the common form and every diary record'
foreach($secret in @('Жалобы первого дневника','Жалобы второго дневника','Новое уточнение первого','Имя только для эпикриза','Оставаться под наблюдением','2026-10-14T13:45:00','2026-10-15T08:10:00')){
 Assert-Clinical (-not $reusableJson.Contains($secret)) ('Actual reusable form save excludes patient data '+$secret)
}
foreach($definition in @($reusable.StageForms.DiaryForm)+@($reusable.StageForms.Diaries)+@($reusable.StageForms.Discharge)){
 Assert-Clinical ([Convert]::FromBase64String($definition.TemplateBase64).Length -gt 100 -and $definition.TemplateSha256 -cmatch '^[a-f0-9]{64}$') 'The UI saves a valid portable Word asset for each clinical layout'
}
Assert-Clinical ((Get-ClinicalFingerprint (Get-MedicalClinicalState)) -ceq $patientBeforeFormSave) 'Saving reusable layouts leaves every current patient answer, date and override intact'
$beforeCancel=[Convert]::ToBase64String([IO.File]::ReadAllBytes($mcformPath));$beforePath=$script:activeMedicalFormPath;$beforeBaseline=$script:medicalFormBaseline
[Windows.Forms.SaveFileDialog]::NextResult='Cancel';Invoke-MedicalSaveForm;[Windows.Forms.SaveFileDialog]::NextResult='OK'
Assert-Clinical ([Convert]::ToBase64String([IO.File]::ReadAllBytes($mcformPath)) -ceq $beforeCancel -and $script:activeMedicalFormPath -ceq $beforePath -and $script:medicalFormBaseline -ceq $beforeBaseline) 'Canceling actual Save Form preserves file bytes and saved-form metadata'
# Direct diary export must use the same all-record pipeline as Preview and Save Card.
function Export-MedicalDiariesDocument([string]$path,[bool]$allowIncomplete=$false){
 $script:allDiaryExport=[pscustomobject]@{Path=$path;AllowIncomplete=$allowIncomplete;Contexts=@(Get-MedicalClinicalDiaryContexts)}
}
Export-MedicalClinicalDocument (Join-Path $TestRoot 'all-diaries.docx') $true
Assert-Clinical ($script:allDiaryExport.Contexts.Count -eq 3 -and $script:allDiaryExport.AllowIncomplete -and $script:allDiaryExport.Contexts[0].Values.complaints -ceq 'Жалобы первого дневника' -and $script:allDiaryExport.Contexts[1].Values.complaints -ceq 'Жалобы второго дневника') 'Direct clinical diary export routes every current diary to the combined-document composer'
# Settings uses the active diary/discharge rather than switching to Initial.
$unifiedCommand=Get-Command Invoke-MedicalFormTemplateEditor -CommandType Function
function Invoke-MedicalFormTemplateEditor {$script:routedSettingsStage=$script:stage;$script:routedSettingsId=$script:medicalActiveDiaryId}
Show-UniversalSettings
Assert-Clinical ($script:routedSettingsStage -ceq 'diary' -and $script:routedSettingsId -ceq $first.Id -and $script:stage -ceq 'diary') 'Field Settings on Diaries routes to the selected diary editor without switching stages'
$script:stage='discharge';Show-UniversalSettings
Assert-Clinical ($script:routedSettingsStage -ceq 'discharge' -and $script:stage -ceq 'discharge') 'Field Settings on Discharge routes to the discharge editor without switching stages'
Set-Item Function:script:Invoke-MedicalFormTemplateEditor $unifiedCommand.ScriptBlock
# The real Save Card pipeline produces a readable discharge Word and complete state.
Import-ClinicalFunctions (Join-Path $Project 'constructor.ps1') @('Get-FullRegistration','Get-HospitalizationValues','Capture-Stage','Save-Case','Read-CaseDocument','Reset-NewPatientCase')
. (Join-Path $Project 'document-actions.ps1')
. (Join-Path $Project 'card-document-v65.ps1')
. (Join-Path $Project 'template-recovery-v66.ps1')
. (Join-Path $Project 'diary-document-v67.ps1')
. (Join-Path $Project 'hospitalization-document-v68.ps1')
# Only the native Word automation boundary is replaced. Each snapshot is rendered
# by the shipped exporter. The adapter combines visible bodies deterministically;
# section/style/resource preservation is exercised by diary-document tests.
function Merge-MedicalDiaryWordSnapshots([string[]]$snapshots,[string]$output){
 $script:clinicalMergeCalls++
 if($script:failClinicalDiaryMerge){throw 'Native merger fixture failed'}
 $script:clinicalMergedSnapshots=@($snapshots);$script:clinicalMergedBodies=@($snapshots | ForEach-Object {Get-ClinicalText $_})
 [IO.File]::Copy($snapshots[0],$output,$false)
 $combined=Get-ClinicalXml $output;$combinedNs=[Xml.XmlNamespaceManager]::new($combined.NameTable);$combinedNs.AddNamespace('w',$script:ns)
 $combinedBody=$combined.SelectSingleNode('/w:document/w:body',$combinedNs);$combinedBody.RemoveAll();$lastSection=$null
 foreach($snapshot in $snapshots){
  $part=Get-ClinicalXml $snapshot;$partNs=[Xml.XmlNamespaceManager]::new($part.NameTable);$partNs.AddNamespace('w',$script:ns)
  foreach($node in @($part.SelectSingleNode('/w:document/w:body',$partNs).ChildNodes)){
   if($node.LocalName -eq 'sectPr'){$lastSection=$node;continue}
   [void]$combinedBody.AppendChild($combined.ImportNode($node,$true))
  }
 }
 if($lastSection){[void]$combinedBody.AppendChild($combined.ImportNode($lastSection,$true))}
 Set-ClinicalPart $output 'word/document.xml' $combined.OuterXml
}
function Get-ClinicalVisibleXml([string]$path){return ((Get-ClinicalXml $path).OuterXml -replace 'MC6[78]_[a-f0-9]{32}_','MC_STYLE_')}
$script:stageTemplates=@{initial='';diary='';discharge=''};$script:stageData=@{};$script:hospitalControls=@{};$script:diaryIndex=3
$script:admissionControl.Value=[datetime]'2026-10-13T06:47:29'
[void](Set-MedicalTreatmentPeriod ([datetime]'2026-10-13') ([datetime]'2026-10-16'))
$script:patientNameControl.Text='Старая скрытая копия';$script:caseFolder=$script:medicalProgramRoot;$script:caseFile='';$script:caseLastSavedPatientName=$null
$script:stage='discharge';Open-MedicalClinicalStage
[Windows.Forms.SaveFileDialog]::NextFileName=Join-Path $script:medicalProgramRoot 'Полная карта.docx'
$fullDischargePreview=Join-Path $TestRoot 'full-preview-from-discharge.docx'
Export-CurrentStageDocument $fullDischargePreview $true
Save-Case
$casePath=$script:caseFile;$record=Read-CaseDocument $casePath;$cardBody=Get-ClinicalText $casePath
Assert-Clinical ($record.patientName -ceq 'Новое первичное имя' -and $record.universal.Values.name -ceq 'Новое первичное имя' -and [Windows.Forms.SaveFileDialog]::LastSuggestedName -ceq 'Новое первичное имя_13.10.2026.docx') 'Actual Save Card uses canonical initial patient identity even after a discharge-only name edit'
Assert-Clinical ($cardBody.Contains('Имя только для эпикриза') -and $cardBody.Contains('Уточнённые жалобы эпикриза') -and $cardBody.Contains('Оставаться под наблюдением')) 'Full hospitalization visible Word includes the edited discharge identity, complaints and recommendations'
Assert-Clinical (@($record.ClinicalForms.Diaries).Count -eq 3 -and @($record.ClinicalState.Diaries).Count -eq 3) 'Actual Save Card embeds all reusable diary structures and all patient diary records'
Assert-Clinical ($record.ClinicalForms.Diaries[0].Schema.Sections[0].Fields[3].Label -ceq 'ЖАЛОБЫ ПЕРВОГО ДНЕВНИКА') 'Actual Save Card retains the edited diary schema'
Assert-Clinical ($record.ClinicalState.Diaries[0].Values.complaints -ceq 'Жалобы первого дневника' -and $record.ClinicalState.Diaries[1].Values.complaints -ceq 'Жалобы второго дневника' -and $record.ClinicalState.Diaries[0].Details.choice -ceq 'Новое уточнение первого') 'Actual card patient state embeds independent diary answers and clarifications'
Assert-Clinical ((Get-ClinicalVisibleXml $fullDischargePreview) -ceq (Get-ClinicalVisibleXml $casePath)) 'Save Card from Discharge preserves exactly the preview body text and formatting attributes'
Assert-Clinical ($script:clinicalMergedBodies.Count -eq 5 -and $script:clinicalMergedBodies[0].Contains('Новое первичное имя') -and $script:clinicalMergedBodies[1].Contains('Жалобы первого дневника') -and $script:clinicalMergedBodies[2].Contains('Жалобы второго дневника') -and $script:clinicalMergedBodies[4].Contains('Оставаться под наблюдением')) 'Save Card from Discharge renders Initial then all three Diaries then Discharge in one document'
Assert-Clinical (([datetime]$record.universal.AdmissionDateTime) -eq [datetime]'2026-10-13T06:47:29' -and $script:clinicalMergedBodies[0].Contains('13.10.2026 06:47')) 'Saving from Discharge retains the corrected initial admission time in card state and visible initial Word'
Assert-Clinical ($record.ClinicalState.TreatmentPeriod.StartDate -ceq '2026-10-13' -and $record.ClinicalState.TreatmentPeriod.EndDate -ceq '2026-10-16' -and $record.ClinicalState.TreatmentPeriod.StartOverride -and $record.ClinicalState.TreatmentPeriod.EndOverride) 'Actual Save Card stores the manually selected treatment period without time components'
Assert-Clinical ($script:clinicalMergedBodies[4].Contains('Период лечения: 13.10.2026 — 16.10.2026')) 'Full visible Word contains a date-only discharge treatment period'
$fullDischargeMarker=Read-UniversalDocumentState $casePath
Assert-Clinical ($fullDischargeMarker.Stage -ceq 'hospitalization' -and @($fullDischargeMarker.Stages).Count -eq 5 -and $fullDischargeMarker.Stages[0].Stage -ceq 'initial' -and $fullDischargeMarker.Stages[4].Stage -ceq 'discharge') 'Full card carries a hospitalization marker rather than claiming to be a reusable stage template'
$firstSavedDate=[datetime]$record.ClinicalState.Diaries[0].DateTime;$secondSavedDate=[datetime]$record.ClinicalState.Diaries[1].DateTime
Assert-Clinical ($firstSavedDate -eq [datetime]'2026-10-14T13:45:00' -and $secondSavedDate -eq [datetime]'2026-10-15T08:10:00') 'Actual card retains each diary date and time'
Assert-Clinical ($record.ClinicalState.Discharge.Values.name -ceq 'Имя только для эпикриза' -and $record.ClinicalState.Discharge.Values.examination -ceq '' -and $record.ClinicalState.Discharge.Overrides.examination) 'Actual card retains discharge manual edits, including deliberately blank linked values'
# Saving from Diaries uses the same full hospitalization export as Discharge.
$script:stage='diary';Open-MedicalClinicalStage
$script:caseFile='';$script:caseLastSavedPatientName=$null
[Windows.Forms.SaveFileDialog]::NextFileName=Join-Path $script:medicalProgramRoot 'Карта со всеми дневниками.docx'
$fullDiaryPreview=Join-Path $TestRoot 'full-preview-from-diaries.docx'
Export-CurrentStageDocument $fullDiaryPreview $true
Save-Case
$diaryCasePath=$script:caseFile;$diaryCard=Read-CaseDocument $diaryCasePath;$diaryCollection=Read-UniversalDocumentState $diaryCasePath
Assert-Clinical ([IO.File]::Exists($diaryCasePath) -and $script:clinicalMergedBodies.Count -eq 5 -and $script:clinicalMergedBodies[0].Contains('Новое первичное имя') -and $script:clinicalMergedBodies[1].Contains('Жалобы первого дневника') -and $script:clinicalMergedBodies[2].Contains('Жалобы второго дневника') -and $script:clinicalMergedBodies[4].Contains('Оставаться под наблюдением')) 'Actual diary Save Card renders Initial, every Diary and Discharge in the required order'
Assert-Clinical ($diaryCollection.Stage -ceq 'hospitalization' -and @($diaryCollection.Stages).Count -eq 5 -and @($diaryCard.ClinicalState.Diaries).Count -eq 3) 'Actual diary Save Card creates both the full-document marker and complete hospitalization state'
Assert-Clinical ($diaryCard.ClinicalState.Discharge.Values.recommendations -ceq 'Оставаться под наблюдением' -and $diaryCard.universal.Values.name -ceq 'Новое первичное имя') 'Saving a card from Diaries keeps discharge answers and canonical patient identity'
Assert-Clinical (@($script:clinicalMergedSnapshots | Where-Object {[IO.File]::Exists($_)}).Count -eq 0 -and @(Get-ChildItem -LiteralPath $script:medicalProgramRoot -Filter 'case_*.docx').Count -eq 0) 'Actual diary Save Card cleans private diary snapshots and its atomic Word temporary file'
Assert-Clinical ((Get-ClinicalVisibleXml $fullDiaryPreview) -ceq (Get-ClinicalVisibleXml $diaryCasePath)) 'Save Card from Diaries preserves exactly its full preview body text and formatting attributes'
$diaryCardBytes=[Convert]::ToBase64String([IO.File]::ReadAllBytes($diaryCasePath));Clear-MedicalHospitalizationRenderCache;$script:failClinicalDiaryMerge=$true;$mergeRejected=$false
try{Save-Case}catch{$mergeRejected=$_.Exception.Message -eq 'Native merger fixture failed'}
$script:failClinicalDiaryMerge=$false
Assert-Clinical ($mergeRejected -and $script:caseFile -ceq $diaryCasePath -and [Convert]::ToBase64String([IO.File]::ReadAllBytes($diaryCasePath)) -ceq $diaryCardBytes) 'A native merge failure during actual diary Save Card preserves the existing complete card and chosen path'
# Opening the complete card restores clinical state through the shipped Open Card command.
function Open-Stage {$script:universalInputs=@{};$script:universalDetailInputs=@{};$script:medicalClinicalBindings=@{};foreach($f in Get-UniversalFields $script:universalConfig){if($f.Type -ne 'heading'){$script:universalInputs[$f.Id]=[pscustomobject]@{Text=[string]$script:universalValues[$f.Id]}}}}
$stageInitial=New-Object Windows.Forms.Button;$stageDiary=New-Object Windows.Forms.Button;$stageDischarge=New-Object Windows.Forms.Button
$script:universalValues=@{name='Другой пациент'};$script:medicalClinicalForms=$null;$script:medicalClinicalState=$null
Open-CasePath $casePath
Assert-Clinical ($script:universalValues.name -ceq 'Новое первичное имя' -and $script:patientNameControl.Text -ceq 'Новое первичное имя') 'Actual Open Card restores canonical initial identity instead of the discharge override'
Assert-Clinical ($script:admissionControl.Value -eq [datetime]'2026-10-13T06:47:29' -and (Get-MedicalTreatmentPeriod).StartDate -ceq '2026-10-13' -and (Get-MedicalTreatmentPeriod).EndDate -ceq '2026-10-16') 'Actual Open Card restores corrected admission time and the manually selected date-only treatment period'
$script:stage='diary';Open-MedicalClinicalStage
Assert-Clinical ($script:medicalClinicalBindings.Count -eq 3 -and $script:medicalClinicalBindings[$first.Id].Inputs.complaints.Text -ceq 'Жалобы первого дневника' -and $script:medicalClinicalBindings[$second.Id].Inputs.complaints.Text -ceq 'Жалобы второго дневника') 'Actual Open Card rebuilds every independent diary from saved structures and patient data'
Assert-Clinical ($script:medicalClinicalBindings[$first.Id].DateControl.Value -eq [datetime]'2026-10-14T13:45:00') 'Actual Open Card restores diary timestamps to the date widget'
$script:stage='discharge';Open-MedicalClinicalStage
Assert-Clinical ($script:medicalClinicalBindings.discharge.Inputs.name.Text -ceq 'Имя только для эпикриза' -and $script:medicalClinicalBindings.discharge.Inputs.examination.Text -ceq '' -and $script:medicalClinicalBindings.discharge.Inputs.recommendations.Text -ceq 'Оставаться под наблюдением') 'Actual Open Card rebuilds editable discharge overrides and treatment recommendations'
# Initial has the identical complete-document contract and preserves later stages.
$script:stage='initial';Open-Stage
$initialFullPreview=Join-Path $TestRoot 'full-preview-from-initial.docx'
Export-CurrentStageDocument $initialFullPreview $true;Save-Case
Assert-Clinical ((Get-ClinicalVisibleXml $initialFullPreview) -ceq (Get-ClinicalVisibleXml $script:caseFile)) 'Save Card from Initial preserves exactly its full preview body text and formatting attributes'
Assert-Clinical ($script:clinicalMergedBodies.Count -eq 5 -and $script:clinicalMergedBodies[1].Contains('Жалобы первого дневника') -and $script:clinicalMergedBodies[4].Contains('Оставаться под наблюдением')) 'Saving from Initial retains every Diary and the edited Discharge in the same Word file'
# Run the actual Preview/Print commands, replacing only the native process launch.
# Draft preview and draft card must accept the same incomplete choice/detail state.
$savedChoice=$script:universalValues.choice;$savedDetail=$script:universalDetails.choice
$script:universalInputs.choice.Text='';$script:universalValues.choice='';$script:universalDetails.choice='Черновое уточнение без выбора'
$strictRejected=$false;try{Export-CurrentStageDocument (Join-Path $TestRoot 'strict-incomplete.docx')}catch{$strictRejected=$_.Exception.Message.Contains('выберите вариант')}
Assert-Clinical $strictRejected 'Explicit strict full-document export still rejects a clarification without its required selected choice'
Save-Case;$draftFullCard=$script:caseFile
$env:LOCALAPPDATA=Join-Path $TestRoot 'local-app-data'
function Start-WordDocumentAction([string]$path,[string]$action,[bool]$temporary){$script:nativeWordAction=[pscustomobject]@{Path=$path;Action=$action;Temporary=$temporary}}
foreach($nativeAction in @('Preview','Print')){
 Show-CurrentDocumentAction $nativeAction
 Assert-Clinical ($script:nativeWordAction.Action -ceq $nativeAction -and $script:nativeWordAction.Temporary -and [IO.File]::Exists($script:nativeWordAction.Path)) ('Actual '+$nativeAction+' prepares a temporary complete Word document for native Word')
 Assert-Clinical ((Get-ClinicalVisibleXml $script:nativeWordAction.Path) -ceq (Get-ClinicalVisibleXml $draftFullCard)) ('Actual '+$nativeAction+' accepts the same incomplete answers as Save Card and preserves its visible text and formatting attributes')
}
$script:universalValues.choice=$savedChoice;$script:universalInputs.choice.Text=$savedChoice;$script:universalDetails.choice=$savedDetail
# The real Save Card path guard must protect inactive clinical templates, even
# though the compositor itself receives a private case_*.docx destination.
$protectedCasePath=$script:caseFile;$protectedCaseBytes=[Convert]::ToBase64String([IO.File]::ReadAllBytes($protectedCasePath))
foreach($protectedSpec in @(@('diary',$first.Id,'inactive-diary-template.docx'),@('discharge','','inactive-discharge-template.docx'))){
 $protectedSchema=Copy-MedicalFormSchema (Get-MedicalClinicalContext $protectedSpec[0] $protectedSpec[1]).Schema
 $protectedSource=Join-Path $TestRoot $protectedSpec[2];New-UniversalTemplate $protectedSource $protectedSchema
 $protectedSchema.Template=$protectedSource;$protectedSchema.AutoTemplate=$false
 [void](Set-MedicalClinicalSchema $protectedSpec[0] $protectedSpec[1] $protectedSchema)
 $protectedHash=(Get-FileHash -LiteralPath $protectedSource).Hash;$beforeProtectedMerge=$script:clinicalMergeCalls
 $script:caseLastSavedPatientName='Force a new destination suggestion'
 [Windows.Forms.SaveFileDialog]::NextFileName=$protectedSource
 $protectedRejected=$false;try{Save-Case}catch{$protectedRejected=$_.Exception.Message.Contains('поверх исходного Word-шаблона')}
 Assert-Clinical ($protectedRejected -and $script:clinicalMergeCalls -eq $beforeProtectedMerge) ('Actual Save Card rejects an inactive '+$protectedSpec[0]+' Word template destination before the native merger starts')
 Assert-Clinical ((Get-FileHash -LiteralPath $protectedSource).Hash -ceq $protectedHash -and $script:caseFile -ceq $protectedCasePath -and [Convert]::ToBase64String([IO.File]::ReadAllBytes($protectedCasePath)) -ceq $protectedCaseBytes) ('Protecting inactive '+$protectedSpec[0]+' template leaves its original bytes and the last complete card unchanged')
}
$script:caseLastSavedPatientName='Новое первичное имя';[Windows.Forms.SaveFileDialog]::NextFileName=$protectedCasePath
# Cards contain visible-stage MC49 state too; opening through the document
# entry point must choose full card state before interpreting a single stage.
Open-UniversalDocument $diaryCasePath
Assert-Clinical (@($script:medicalClinicalForms.Diaries).Count -eq 3 -and (Get-MedicalClinicalContext 'diary' $first.Id).Values.complaints -ceq 'Жалобы первого дневника' -and (Get-MedicalClinicalContext 'discharge').Values.recommendations -ceq 'Оставаться под наблюдением') 'Open Document restores a complete diary card before its standalone MC49 collection marker'
$protectedBeforeImport=Get-ClinicalFingerprint ([pscustomobject]@{Initial=(Get-UniversalState);Forms=(Get-MedicalClinicalFormData);Patient=(Get-MedicalClinicalState);Case=$script:caseFile})
$standaloneDischarge=Join-Path $TestRoot 'standalone-discharge.docx'
$dischargeContext=Get-MedicalClinicalContext 'discharge'
Save-UniversalDocument $standaloneDischarge $dischargeContext.Schema $dischargeContext.Values $dischargeContext.DateTime $dischargeContext.Details $true 'discharge'
$importRejected=$false;try{Open-UniversalDocument $standaloneDischarge}catch{$importRejected=$_.Exception.Message.Contains('отдельный документ')}
Assert-Clinical ($importRejected -and (Get-ClinicalFingerprint ([pscustomobject]@{Initial=(Get-UniversalState);Forms=(Get-MedicalClinicalFormData);Patient=(Get-MedicalClinicalState);Case=$script:caseFile})) -ceq $protectedBeforeImport) 'Opening standalone discharge rejects stage state before clearing the current complete patient'
$standaloneDiaries=Join-Path $TestRoot 'standalone-diaries.docx'
Export-MedicalDiariesDocument $standaloneDiaries $true
$importRejected=$false;try{Open-UniversalDocument $standaloneDiaries}catch{$importRejected=$_.Exception.Message.Contains('отдельный документ')}
Assert-Clinical ($importRejected -and (Get-ClinicalFingerprint ([pscustomobject]@{Initial=(Get-UniversalState);Forms=(Get-MedicalClinicalFormData);Patient=(Get-MedicalClinicalState);Case=$script:caseFile})) -ceq $protectedBeforeImport) 'Opening standalone all-diary Word rejects collection state before changing the current case'
# A legacy standalone discharge has no explicit Stage flag; title still identifies it.
$legacyStandalone=Join-Path $TestRoot 'legacy-standalone-discharge.docx'
Save-UniversalDocument $legacyStandalone $dischargeContext.Schema $dischargeContext.Values $dischargeContext.DateTime $dischargeContext.Details $true
$legacyState=Read-UniversalDocumentState $legacyStandalone
if($legacyState.PSObject.Properties['Stage']){$legacyState.PSObject.Properties.Remove('Stage')}
$z=[IO.Compression.ZipFile]::Open($legacyStandalone,[IO.Compression.ZipArchiveMode]::Update)
try{$z.GetEntry('customXml/mc49.xml').Delete();$payload=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($legacyState | ConvertTo-Json -Depth 60 -Compress)));Write-UniversalZipText $z 'customXml/mc49.xml' ('<mc:state xmlns:mc="urn:medical-constructor:v49">'+$payload+'</mc:state>')}finally{$z.Dispose()}
$importRejected=$false;try{Open-UniversalDocument $legacyStandalone}catch{$importRejected=$_.Exception.Message.Contains('отдельный документ')}
Assert-Clinical ($importRejected -and (Get-ClinicalFingerprint ([pscustomobject]@{Initial=(Get-UniversalState);Forms=(Get-MedicalClinicalFormData);Patient=(Get-MedicalClinicalState);Case=$script:caseFile})) -ceq $protectedBeforeImport) 'Opening an old standalone discharge without a Stage flag preserves the full patient by inspecting its document title'
# A malformed primary-document schema must be rejected before reset as well.
$badPrimaryPath=Join-Path $TestRoot 'bad-primary-state.docx'
Save-UniversalDocument $badPrimaryPath $script:universalConfig $script:universalValues $script:admissionControl.Value $script:universalDetails $true
$badPrimary=Read-UniversalDocumentState $badPrimaryPath;$badPrimary.Schema.Sections[0].Title=''
$z=[IO.Compression.ZipFile]::Open($badPrimaryPath,[IO.Compression.ZipArchiveMode]::Update)
try{$z.GetEntry('customXml/mc49.xml').Delete();$payload=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($badPrimary | ConvertTo-Json -Depth 60 -Compress)));Write-UniversalZipText $z 'customXml/mc49.xml' ('<mc:state xmlns:mc="urn:medical-constructor:v49">'+$payload+'</mc:state>')}finally{$z.Dispose()}
$importRejected=$false;try{Open-UniversalDocument $badPrimaryPath}catch{$importRejected=$true}
Assert-Clinical ($importRejected -and (Get-ClinicalFingerprint ([pscustomobject]@{Initial=(Get-UniversalState);Forms=(Get-MedicalClinicalFormData);Patient=(Get-MedicalClinicalState);Case=$script:caseFile})) -ceq $protectedBeforeImport) 'A malformed primary Word document is rejected before any existing patient maps, layouts or case bindings are cleared'
# Opening the reusable form creates the same layouts with no previous patient's values.
$opened=Read-MedicalForm $mcformPath
Reset-NewPatientCase $opened.Schema
[void](Initialize-MedicalClinicalWorkspace $opened.StageForms)
$script:stage='diary';Open-MedicalClinicalStage
Assert-Clinical ($script:medicalClinicalBindings.Count -eq 3 -and $script:medicalClinicalBindings[$first.Id].Inputs.complaints.Text -ceq '' -and $script:medicalClinicalBindings[$first.Id].Inputs.name.Text -ceq '' -and $script:medicalClinicalBindings[$first.Id].DetailInputs.choice.Text -ceq '') 'Opening the reusable form retains all diary layouts while clearing patient answers and clarifications'
Assert-Clinical ((Get-MedicalClinicalContext 'diary' $first.Id).Schema.Sections[0].Fields[3].Label -ceq 'ЖАЛОБЫ ПЕРВОГО ДНЕВНИКА' -and (Get-MedicalClinicalContext 'discharge').Schema.DocumentTitle -ceq 'Выписной эпикриз') 'Opening the reusable form retains edited diary fields and the discharge document layout'
# Building Initial must disable inactive clinical capture widgets.
$previousClinicalFlow=$script:medicalClinicalFlow
$script:stage='initial';Open-UniversalInitial
Assert-Clinical ($script:medicalClinicalBindings.Count -eq 0 -and -not $script:medicalClinicalFlow -and $null -ne $script:universalFlow -and $previousClinicalFlow.IsDisposed) 'Actual Initial builder clears inactive clinical bindings and disposes the old clinical work area'
Assert-Clinical (-not $script:admissionControl.IsDisposed -and -not $newDiary.IsDisposed -and -not $caseSave.IsDisposed -and -not $newDiary.Parent -and -not $newDiary.Visible) 'Initial rendering preserves reusable admission and action controls while hiding the diary action'
Import-ClinicalFunctions (Join-Path $Project 'constructor.ps1') @('Open-Stage','Switch-Stage')
$script:universalInputs.complaints.Text='Новые жалобы после открытия формы'
for($iteration=1;$iteration -le 3;$iteration++){
 Switch-Stage 'diary'
 Assert-Clinical ($script:medicalClinicalBindings.Count -eq 3 -and $script:universalInputs.Count -eq 0 -and $newDiary.Parent -eq $script:medicalClinicalFlow) ('Actual stage switch cycle '+$iteration+' restores diary widgets and action in the work area')
 Switch-Stage 'discharge'
 Assert-Clinical ($script:medicalClinicalBindings.Count -eq 1 -and $script:medicalClinicalBindings.discharge.Inputs.complaints.Text -ceq 'Новые жалобы после открытия формы') ('Actual stage switch cycle '+$iteration+' links untouched discharge fields to current Initial values')
 Switch-Stage 'initial'
 Assert-Clinical ($script:medicalClinicalBindings.Count -eq 0 -and $script:universalInputs.complaints.Text -ceq 'Новые жалобы после открытия формы' -and $script:universalFlow.Top -eq 15 -and $script:universalFlow.Left -eq 20) ('Actual stage switch cycle '+$iteration+' restores Initial values at the unchanged work-area origin')
}
# A standalone primary examination can be opened with explicit consent.
$primaryDoc=Join-Path $TestRoot 'standalone-initial.docx'
$primaryValues=@{name='Пациент из документа';birth='12.02.1980';address='Адрес из документа';complaints='Жалобы из документа'}
Save-UniversalDocument $primaryDoc $script:universalConfig $primaryValues ([datetime]'2026-10-10T09:35:00') @{} $true
$script:importBaselineData=$null
function Reset-MedicalBackupSaveBaselines([bool]$formWasLoaded=$false,[bool]$caseWasLoaded=$false){$script:importBaselineData=[pscustomobject]@{Form=$formWasLoaded;Case=$caseWasLoaded;Values=(Copy-UniversalObject $script:universalValues);ValueKeys=@($script:universalValues.Keys).Count;Path=$script:caseFile}}
[Windows.Forms.MessageBox]::Response='No';$beforeCancelledImport=Get-ClinicalFingerprint (Get-UniversalState);Open-UniversalDocument $primaryDoc
Assert-Clinical ((Get-ClinicalFingerprint (Get-UniversalState)) -ceq $beforeCancelledImport -and $null -eq $script:importBaselineData) 'Declining standalone primary-document import preserves the current patient and does not reset backup baselines'
[Windows.Forms.MessageBox]::Response='Yes';Open-UniversalDocument $primaryDoc
Assert-Clinical ($script:universalValues.name -ceq 'Пациент из документа' -and $script:universalValues.complaints -ceq 'Жалобы из документа' -and $script:admissionControl.Value -eq [datetime]'2026-10-10T09:35:00') 'Approved primary-document import restores its identity, answers and admission timestamp'
Assert-Clinical ($script:medicalWorkspaceReady -and @($script:medicalClinicalForms.Diaries).Count -eq 0 -and $null -ne $script:medicalClinicalForms.Discharge -and $stageInitial.Enabled -and $stageDiary.Enabled -and $stageDischarge.Enabled) 'Approved primary-document import creates a fresh clinical workspace and enables all stage controls'
Assert-Clinical ($script:caseFile -ceq '' -and -not $script:importBaselineData.Form -and -not $script:importBaselineData.Case -and $script:importBaselineData.ValueKeys -eq 0 -and $script:importBaselineData.Path -ceq '') 'Primary-document import resets backup baselines while still blank so restored patient answers remain unsaved work'
Remove-Item Function:script:Reset-MedicalBackupSaveBaselines
# Patient stage maps require their matching reusable schemas; malformed cards
# must not replace a currently edited patient before this relationship validates.
$unboundCard=Join-Path $TestRoot 'unbound-clinical-state.docx'
[IO.File]::Copy($casePath,$unboundCard,$true)
$unboundRecord=Read-CaseDocument $casePath;$unboundRecord.PSObject.Properties.Remove('ClinicalForms')
Set-MedicalCardDocumentState $unboundCard $unboundRecord
$beforeUnbound=Get-ClinicalFingerprint ([pscustomobject]@{Initial=(Get-UniversalState);Forms=(Get-MedicalClinicalFormData);Patient=(Get-MedicalClinicalState);Case=$script:caseFile})
$unboundRejected=$false;try{Open-CasePath $unboundCard}catch{$unboundRejected=$_.Exception.Message.Contains('отсутствует структура')}
Assert-Clinical ($unboundRejected -and (Get-ClinicalFingerprint ([pscustomobject]@{Initial=(Get-UniversalState);Forms=(Get-MedicalClinicalFormData);Patient=(Get-MedicalClinicalState);Case=$script:caseFile})) -ceq $beforeUnbound) 'A card with clinical patient answers but no schemas is rejected before changing the current patient or case bindings'
# A modern card may intentionally carry custom layouts without answer maps.
$schemaOnlyDiary=Add-MedicalClinicalDiary $null 'МОЙ ДНЕВНИК БЕЗ ОТВЕТОВ'
$schemaOnlyCard=Join-Path $TestRoot 'schema-only-clinical-card.docx'
[IO.File]::Copy($casePath,$schemaOnlyCard,$true)
$schemaOnlyRecord=[ordered]@{version=49;universal=(Get-UniversalState);patientName='Пациент из документа';admissionDate='2026-10-10';diaryCount=1;templates=@{initial='';diary='';discharge=''};stages=@{diary_1=@('НЕ ИМПОРТИРОВАТЬ УСТАРЕВШИЙ МАССИВ')};ClinicalForms=(Get-MedicalClinicalPortableForms $true)}
Set-MedicalCardDocumentState $schemaOnlyCard $schemaOnlyRecord
Open-CasePath $schemaOnlyCard
$schemaOnlyContext=Get-MedicalClinicalContext 'diary' $schemaOnlyDiary.Id
Assert-Clinical (@($script:medicalClinicalForms.Diaries).Count -eq 1 -and $schemaOnlyContext.Title -ceq 'МОЙ ДНЕВНИК БЕЗ ОТВЕТОВ' -and $schemaOnlyContext.Overrides.Count -eq 0 -and $schemaOnlyContext.Values.Values -notcontains 'НЕ ИМПОРТИРОВАТЬ УСТАРЕВШИЙ МАССИВ') 'A modern schema-only card preserves its custom diary layout and initializes state without importing old positional arrays'
# Old v66 records contain positional stage arrays, with no ClinicalForms/State.
# The actual Open Card route must migrate them before rendering these new pages.
$script:universalValues.name='Пациент старой карты';$script:universalValues.complaints='Первичные жалобы старой карты'
$oldRecord=[ordered]@{
 version=49;universal=(Get-UniversalState);patientName='Пациент старой карты';admissionDate='2026-10-11';diaryCount=2
 templates=@{initial='';diary='старый-дневник-отсутствует.docx';discharge='старый-эпикриз-отсутствует.docx'}
 stages=@{diary_1=@('Первая старая запись','Первое старое уточнение');diary_2=@('Вторая старая запись');discharge=@('Старый итог лечения')}
}
$oldCardPath=Join-Path $TestRoot 'old-v66-card.docx';[IO.File]::Copy($casePath,$oldCardPath,$true);Set-MedicalCardDocumentState $oldCardPath $oldRecord
Open-CasePath $oldCardPath
Assert-Clinical (@($script:medicalClinicalForms.Diaries).Count -eq 2 -and $script:universalValues.name -ceq 'Пациент старой карты') 'Actual Open Card migrates all diary records from an old card without clinical schemas'
Switch-Stage 'diary'
$legacyFirst=Get-MedicalClinicalContext 'diary' 'legacy_diary_1';$legacySecond=Get-MedicalClinicalContext 'diary' 'legacy_diary_2'
Assert-Clinical ($script:medicalClinicalBindings.Count -eq 2 -and $legacyFirst.Values.Values -contains 'Первая старая запись' -and $legacyFirst.Values.Values -contains 'Первое старое уточнение' -and $legacySecond.Values.Values -contains 'Вторая старая запись') 'Migrated missing-template diaries render every old positional answer without losing records'
Assert-Clinical ($script:medicalClinicalBindings.legacy_diary_1.DateControl.Value -eq [datetime]'2026-10-11T00:00:00') 'An old card diary uses its saved admission date when no per-record timestamp existed'
Switch-Stage 'discharge'
$legacyDischarge=Get-MedicalClinicalContext 'discharge'
Assert-Clinical ($legacyDischarge.Values.Values -contains 'Старый итог лечения' -and $script:medicalClinicalBindings.discharge.Inputs.Values.Text -contains 'Старый итог лечения') 'Actual old-card migration preserves discharge text in editable widgets when original Word files are missing'
# Deferred events from disposed diary widgets must not rebind to another page.
Switch-Stage 'diary';$staleBinding=$script:medicalClinicalBindings.legacy_diary_1;$staleInput=@($staleBinding.Inputs.Values)[0]
Switch-Stage 'initial';$beforeDeferred=Get-ClinicalFingerprint (Get-MedicalClinicalState)
$staleInput.Text='НЕ ПРИМЕНЯТЬ ПОСЛЕ СМЕНЫ ВКЛАДКИ';$staleBinding.DateControl.Value=[datetime]'2026-10-20T11:15:00'
Assert-Clinical ($staleInput.IsDisposed -and $staleBinding.DateControl.IsDisposed -and (Get-ClinicalFingerprint (Get-MedicalClinicalState)) -ceq $beforeDeferred) 'Deferred text and date events from disposed diary controls cannot modify the patient after switching to Initial'
$script:medicalClinicalBindings=@{legacy_stale=$staleBinding};Capture-MedicalClinicalStage;$script:medicalClinicalBindings=@{}
Assert-Clinical ((Get-ClinicalFingerprint (Get-MedicalClinicalState)) -ceq $beforeDeferred) 'Clinical capture on Initial ignores any stale clinical widgets instead of saving their deferred values'
# New-form dialogs and recovered new-form drafts retain their creation intent
# even when opened over a patient diary, and apply only after explicit reset consent.
Switch-Stage 'diary'
$beforeNewIntent=Get-ClinicalFingerprint ([pscustomobject]@{Initial=(Get-UniversalState);Forms=(Get-MedicalClinicalFormData);Patient=(Get-MedicalClinicalState);Case=$script:caseFile})
$newIntentSchema=New-UniversalConfig;$newIntentSchema.Sections[0].Title='НОВАЯ ФОРМА ИЗ РЕЗЕРВНОГО РЕДАКТОРА'
function Show-MedicalTemplateChoice($owner,$schema,[bool]$newForm=$true){return [pscustomobject]@{Schema=$newIntentSchema;Name='Новая форма из редактора'}}
function Show-MedicalFormTemplateEditor($owner,$schema,$recovery=$null,[string]$purpose='edit'){
 $script:receivedEditorPurpose=$purpose;$script:receivedRecoveryDraft=$recovery;$script:receivedNewSchema=Copy-MedicalFormSchema $schema
 if($script:cancelNewIntentEditor){return $null}
 return [pscustomobject]@{Schema=(Copy-MedicalFormSchema $schema);Template=[pscustomobject]@{Name='Новая форма.docx'}}
}
$script:cancelNewIntentEditor=$true;Invoke-MedicalNewForm
Assert-Clinical ($script:receivedEditorPurpose -ceq 'new' -and (Get-ClinicalFingerprint ([pscustomobject]@{Initial=(Get-UniversalState);Forms=(Get-MedicalClinicalFormData);Patient=(Get-MedicalClinicalState);Case=$script:caseFile})) -ceq $beforeNewIntent) 'Creating a new form from Diaries passes creation purpose and Cancel preserves the current complete patient'
$script:recoveredNewIntent=[pscustomobject]@{Purpose='new';Stage='diary';ClinicalId='legacy_diary_1';Schema=$newIntentSchema}
function Get-MedicalRecoveredEditorDraft {return $script:recoveredNewIntent}
$script:cancelNewIntentEditor=$false;[Windows.Forms.MessageBox]::Response='No';Invoke-MedicalRestoreEditorDraft
Assert-Clinical ($script:receivedEditorPurpose -ceq 'new' -and $script:receivedNewSchema.Sections[0].Title -ceq 'НОВАЯ ФОРМА ИЗ РЕЗЕРВНОГО РЕДАКТОРА' -and (Get-ClinicalFingerprint ([pscustomobject]@{Initial=(Get-UniversalState);Forms=(Get-MedicalClinicalFormData);Patient=(Get-MedicalClinicalState);Case=$script:caseFile})) -ceq $beforeNewIntent) 'Restoring a new-form draft uses its own schema and preserves the current patient when reset consent is declined'
[Windows.Forms.MessageBox]::Response='Yes';Invoke-MedicalRestoreEditorDraft
Assert-Clinical ($script:stage -ceq 'initial' -and $script:universalConfig.Sections[0].Title -ceq 'НОВАЯ ФОРМА ИЗ РЕЗЕРВНОГО РЕДАКТОРА' -and @($script:medicalClinicalForms.Diaries).Count -eq 0 -and $script:universalValues.Values -notcontains 'Пациент старой карты' -and $script:caseFile -ceq '') 'Applying a recovered new-form draft starts a new primary form instead of replacing a current diary schema'
# Rendering multiple records that share one Word source parses its controls
# once for this build, then discards the lookup before the next user action.
$sharedChoice=New-UniversalField 'shared_choice' 'Общий список Word' 'SHARED_CHOICE' 'choice';$sharedChoice.Required=$false;$sharedChoice.WordId='501';$sharedChoice.Options=@('Запасной вариант')
$sharedSchema=[pscustomobject]@{Version=49;AutoTemplate=$true;Template='shared-choices.docx';Sections=@([pscustomobject]@{Id='shared';Title='Общий Word';Fields=@($sharedChoice)})}
$sharedPath=Join-Path $TestRoot 'shared-word-choices.docx';New-UniversalTemplate $sharedPath $sharedSchema
$sharedXml=Get-ClinicalXml $sharedPath;$sharedNs=New-Object Xml.XmlNamespaceManager($sharedXml.NameTable);$sharedNs.AddNamespace('w',$script:ns)
$fragment=$sharedXml.CreateDocumentFragment();$fragment.InnerXml='<w:sdt xmlns:w="'+$script:ns+'"><w:sdtPr><w:id w:val="501"/><w:dropDownList><w:listItem w:displayText="Вариант из Word" w:value="one"/></w:dropDownList></w:sdtPr><w:sdtContent><w:p><w:r><w:t>Выберите элемент.</w:t></w:r></w:p></w:sdtContent></w:sdt>'
$sharedBody=$sharedXml.SelectSingleNode('/w:document/w:body',$sharedNs);[void]$sharedBody.InsertBefore($fragment,$sharedBody.SelectSingleNode('w:sectPr',$sharedNs));Set-ClinicalPart $sharedPath 'word/document.xml' $sharedXml.OuterXml
$sharedSchema.Template=$sharedPath;$sharedSchema.AutoTemplate=$false
$sharedFirst=Add-MedicalClinicalDiary $sharedSchema 'Общий шаблон 1';$sharedSecond=Add-MedicalClinicalDiary $sharedSchema 'Общий шаблон 2'
$script:realWordFieldReader=(Get-Command Get-UniversalWordFields -CommandType Function).ScriptBlock;$script:wordFieldReadCalls=0
function Get-UniversalWordFields($path){$script:wordFieldReadCalls++;return (& $script:realWordFieldReader $path)}
try{
 $script:stage='diary';Open-MedicalClinicalStage
 Assert-Clinical ($script:wordFieldReadCalls -eq 1 -and $script:medicalClinicalBindings.Count -eq 2) 'Two diaries with one authored Word source parse its dropdown definitions once per actual UI build'
 Assert-Clinical ($script:medicalClinicalBindings[$sharedFirst.Id].Inputs.shared_choice.Items.Contains('Вариант из Word') -and $script:medicalClinicalBindings[$sharedSecond.Id].Inputs.shared_choice.Items.Contains('Вариант из Word')) 'Both independent diary dropdowns receive the actual shared Word options'
 Assert-Clinical ($null -eq $script:medicalClinicalWordFieldCache) 'Temporary Word control lookup is released after the clinical builder returns'
 $sharedXml=Get-ClinicalXml $sharedPath;$sharedNs=New-Object Xml.XmlNamespaceManager($sharedXml.NameTable);$sharedNs.AddNamespace('w',$script:ns);[void]$sharedXml.SelectSingleNode('//w:listItem',$sharedNs).SetAttribute('displayText',$script:ns,'Обновлённый вариант из Word');Set-ClinicalPart $sharedPath 'word/document.xml' $sharedXml.OuterXml
 Open-MedicalClinicalStage
 Assert-Clinical ($script:wordFieldReadCalls -eq 2 -and $script:medicalClinicalBindings[$sharedFirst.Id].Inputs.shared_choice.Items.Contains('Обновлённый вариант из Word') -and -not $script:medicalClinicalBindings[$sharedSecond.Id].Inputs.shared_choice.Items.Contains('Вариант из Word')) 'Next actual UI rebuild reparses the shared source and shows externally edited Word options without stale cache data'
}finally{Set-Item Function:script:Get-UniversalWordFields $script:realWordFieldReader}
Assert-Clinical (-not (Get-Item Function:global:Export-MedicalDiariesDocument -ErrorAction SilentlyContinue)) 'Combined export helper stays private to the child application script' 

Clear-MedicalHospitalizationRenderCache
Write-Output ('CHECKS '+$script:checks)
'@
try{
 [IO.File]::WriteAllText($child,$childSource,[Text.UTF8Encoding]::new($true))
 & $child $Project $temp
 if(Get-Item Function:global:Show-MedicalClinicalStage -ErrorAction SilentlyContinue){throw 'Clinical helpers leaked to global scope'}
}finally{Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue}
