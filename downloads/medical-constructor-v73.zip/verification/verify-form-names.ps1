﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v73'))
$ErrorActionPreference='Stop'
$script:checks=0
function Assert-Check([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
function Import-TestFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors | Out-String)}
 foreach($node in $ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
  if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}
 }
}
function Get-TestTree([string]$root){return (@(Get-ChildItem -LiteralPath $root -File -Recurse | Sort-Object FullName | ForEach-Object {$_.FullName+' '+(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash}) -join "`n")}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-v65-form-names-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
try{
 Import-TestFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
 Import-TestFunctions (Join-Path $Project 'universal.ps1')
 Import-TestFunctions (Join-Path $Project 'forms-v59.ps1')
 Import-TestFunctions (Join-Path $Project 'template-editor-v59.ps1')
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 $script:medicalProgramRoot=Join-Path $temp 'program';$script:medicalTemplatesFolder=Join-Path $script:medicalProgramRoot 'Шаблоны'
 $guid='d853ae38-8c9e-4a51-b708-84075f87b763';$guidN='d853ae388c9e4a51b70884075f87b763'
 $legacy='01-b92192ba816b-9dff67722061-0ea467e5a8f9-3c129c65f0fc-6e85b5f77cc7-776ba4abfd46-d509696d6f1b-020b7a3a752e-3cf22a1012ea-9e647c1a2b89-47ad6c683aab-2079d42d11f4-14fbebbe3beb-2bffe353c11c-c11c1dd5ed75'
 $cases=@(
  @('F10-Ж.docx','F10-Ж'),@('Осмотр при поступлении.mcform','Осмотр при поступлении'),
  @('C:\Программа\Формы\F10-Ж.mcform','F10-Ж'),@('/tmp/Формы/Осмотр.json','Осмотр'),
  @('F10-Ж-b92192ba816b-9dff67722061.docx','F10-Ж'),@(($legacy+'.docx'),'01'),
  @('01.docx','01'),@('F10-DEADBEEFCAFЕ.docx','F10-DEADBEEFCAFЕ'),@('F10-DEADBEEFCAFE.docx','F10-DEADBEEFCAFE'),
  @('F10-deadbeef.docx','F10-deadbeef'),@('Осмотр-ABCDEF.docx','Осмотр-ABCDEF'),
  @('Анамнез-123.docx','Анамнез-123'),@('Осмотр 1.2','Осмотр 1.2'),
  @('Доктор Иванов — осмотр № 2.dotx','Доктор Иванов — осмотр № 2'),
  @(($guid+'-F10-Ж.docx'),'F10-Ж'),@(($guidN+'_Осмотр.docx'),'Осмотр'),
  @(($guid+'.docx'),'Новая форма'),@(($guidN+'.docx'),'Новая форма'),
  @(($guid+'-'+$guidN+'.docx'),'Новая форма'),@(('mc-editor-source-'+$guidN+'.docx'),'Новая форма'),@(('mc-editor-rebuild-'+$guidN+'.docx'),'Новая форма'),
  @('01234567-89ab-cdef-0123-456789abcdef-abcdefabcdef-123456789abc.docx','Новая форма'),
  @('abcdefabcdef.docx','abcdefabcdef'),
  @('Осмотр-b92192ba816b-2.docx','Осмотр'),@('Осмотр-b92192ba816b-12.docx','Осмотр'),
  @(('Осмотр-'+('a'*64)+'.docx'),'Осмотр'),@('','Новая форма')
 )
 foreach($case in $cases){Assert-Check ((Get-MedicalFormDisplayName $case[0]) -ceq $case[1]) ('Human form name: '+$case[0])}
 Assert-Check ((Get-MedicalFormDisplayName ($guid+'.docx') 'Шаблон формы') -ceq 'Шаблон формы') 'All-GUID template uses the supplied human fallback'
 Assert-Check ((Get-MedicalFormDisplayName '' '') -ceq 'Новая форма') 'An empty fallback still produces a human name'
 Assert-Check ((Get-MedicalManagedTemplateName ($legacy+'.docx')) -ceq '01.docx') 'Legacy hash chains retain the explicitly authored 01 basename'
 Assert-Check ((Get-MedicalManagedTemplateName ($guid+'.dotx')) -ceq 'Шаблон формы.dotx') 'Generic template names preserve the real DOTX extension'
 $private=New-Module -ArgumentList (Get-Command 'Get-MedicalFormDisplayName' -CommandType Function) -ScriptBlock {
  param($command)
  $script:callback={param($name) & $command $name 'Шаблон формы'}.GetNewClosure()
 }
 $privateCallback=& $private {$script:callback}
 Assert-Check ((& $privateCallback ('F10-Ж-b92192ba816b-9dff67722061.docx')) -ceq 'F10-Ж') 'A private-module closure calls the actual captured display helper'
 $script:medicalProgramRoot=Join-Path $temp 'program';$script:medicalTemplatesFolder=Join-Path $script:medicalProgramRoot 'Шаблоны'

 $config=[pscustomobject]@{Version=49;AutoTemplate=$false;Template='';Sections=@([pscustomobject]@{Id='exam';Title='Первичный осмотр';Fields=@([pscustomobject]@{Id='name';Label='Ф.И.О.';Marker='PATIENT_NAME';Type='text';System='name';WordId='';Options=@();Required=$true})})}
 $source=Join-Path $temp 'F10-Ж.docx';$config.Template=$source;New-UniversalTemplate $source $config
 $sourceHash=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
 $original=Import-MedicalTemplate $source
 $originalHash=(Get-FileHash -LiteralPath $original.Path -Algorithm SHA256).Hash
 $config.Template=$original.RelativePath
 $model=Read-MedicalTemplateModel $original.Path
 $legacyResult=Save-MedicalEditorResult $config $model '01.docx'
 $legacyForm=Join-Path $temp 'Старый осмотр.mcform'
 $legacyEnvelope=Write-MedicalForm $legacyForm $legacyResult.Schema $legacy
 Assert-Check ($legacyEnvelope.Name -ceq '01' -and $legacyEnvelope.TemplateName -ceq '01.docx') 'Legacy service suffixes are removed from the saved form envelope'
 $legacyRead=Read-MedicalForm $legacyForm
 Assert-Check ($legacyRead.Name -ceq '01') 'Reading a legacy-named form returns its human basename'
 $formPath=Join-Path $temp 'Наркологический осмотр.mcform'
 $previousFiles=@{}
 for($iteration=1;$iteration -le 12;$iteration++){
  $paragraph=@($model.Paragraphs | Where-Object {$_.Text -ceq 'Первичный осмотр' -or $_.Text -like 'Индивидуальный осмотр*'})[0]
  Set-MedicalTemplateParagraph $model $paragraph.Id ('Индивидуальный осмотр — редакция '+$iteration)
  $managedName=(Get-MedicalFormDisplayName $config.Template 'Шаблон формы')+$model.TemplateExtension
  $result=Save-MedicalEditorResult $config $model $managedName
  foreach($existing in $previousFiles.Keys){Assert-Check ((Get-FileHash -LiteralPath $existing -Algorithm SHA256).Hash -ceq $previousFiles[$existing]) ('Editing revision '+$iteration+' preserves previous template '+[IO.Path]::GetFileName($existing))}
  $previousFiles[$result.Template.Path]=(Get-FileHash -LiteralPath $result.Template.Path -Algorithm SHA256).Hash
  Assert-Check ($result.Template.Name -cmatch '^F10-Ж(?:-[a-f0-9]{12}(?:-[2-9][0-9]*|-[1-9][0-9]+)?)?\.docx$') ('Editing revision '+$iteration+' uses one bounded storage suffix')
  $envelope=Write-MedicalForm $formPath $result.Schema 'Наркологический осмотр'
  Assert-Check ($envelope.Name -ceq 'Наркологический осмотр' -and $envelope.TemplateName -ceq 'F10-Ж.docx') ('Saving revision '+$iteration+' retains the human form and template names')
  $before=Get-TestTree $script:medicalTemplatesFolder
  $opened=Read-MedicalForm $formPath
  Assert-Check ($opened.Name -ceq 'Наркологический осмотр' -and (Get-TestTree $script:medicalTemplatesFolder) -ceq $before) ('Opening revision '+$iteration+' deduplicates the exact Word bytes')
  $config=$opened.Schema;$model=Read-MedicalTemplateModel (Join-Path $script:medicalProgramRoot $config.Template)
  Assert-Check (@($model.Paragraphs | Where-Object {$_.Text -ceq ('Индивидуальный осмотр — редакция '+$iteration)}).Count -eq 1) ('Opening revision '+$iteration+' restores the exact edited Word text')
 }
 Assert-Check ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ceq $sourceHash -and (Get-FileHash -LiteralPath $original.Path -Algorithm SHA256).Hash -ceq $originalHash) 'Every editor/open cycle leaves the external source and first managed copy intact'
 $unchanged=Save-MedicalEditorResult $config $model ((Get-MedicalFormDisplayName $config.Template)+$model.TemplateExtension)
 $before=Get-TestTree $script:medicalTemplatesFolder
 $same=Save-MedicalEditorResult $unchanged.Schema (Read-MedicalTemplateModel $unchanged.Template.Path) 'F10-Ж.docx'
 Assert-Check ($same.Template.Path -ceq $unchanged.Template.Path -and (Get-TestTree $script:medicalTemplatesFolder) -ceq $before) 'An unchanged editor apply does not create another managed version'
 $explicit='Мой протокол-deadbeefcafe.docx'
 $named=Save-MedicalEditorResult $config $model $explicit
 Assert-Check ($named.Template.Name -ceq $explicit) 'An explicitly entered editor filename is respected'
 $created=New-MedicalTemplateFile '01.docx' $config
 Assert-Check ($created.Name -like '01*.docx') 'An explicitly entered numeric template basename is respected'
 $written=Write-MedicalForm $formPath $config 'Наркологический осмотр'
 $json=[IO.File]::ReadAllText($formPath,[Text.Encoding]::UTF8)
 Assert-Check ($json -notmatch 'universalValues|AdmissionDateTime|patientName|PropertiesSelection|WordPreview') 'Human-name handling does not add patient values or editor state to a reusable form'
 $legacyEnvelope.Name=$guid
 [IO.File]::WriteAllText($legacyForm,($legacyEnvelope|ConvertTo-Json -Depth 50),[Text.UTF8Encoding]::new($true))
 Assert-Check ((Read-MedicalForm $legacyForm).Name -ceq 'Старый осмотр') 'A legacy all-GUID envelope uses the form filename as a readable fallback'
 $editorAst=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'template-editor-v59.ps1'),[ref]$null,[ref]$null)
 $editor=$editorAst.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Show-MedicalFormTemplateEditor'},$false)
 Assert-Check ($editor.Extent.Text -match "'Show-MedicalSectionRenameDialog','Get-MedicalFormDisplayName'") 'The editor captures the name helper for private callback scope'
 $initializer=$editor.Find({param($n) $n -is [Management.Automation.Language.AssignmentStatementAst] -and $n.Extent.Text.StartsWith('$templateName.Text=if(')},$true)
 $schema=[pscustomobject]@{AutoTemplate=$false};$source=Join-Path $temp 'F10-Ж-b92192ba816b-9dff67722061.dotx';$model=[pscustomobject]@{TemplateExtension='.dotx'}
 Assert-Check ((& ([scriptblock]::Create($initializer.Right.Extent.Text))) -ceq 'F10-Ж.dotx') 'The actual editor initializer uses a human name with the real DOTX extension'
 $source=Join-Path $temp ($guid+'.docx');$model.TemplateExtension='.docx'
 Assert-Check ((& ([scriptblock]::Create($initializer.Right.Extent.Text))) -ceq 'Шаблон формы.docx') 'The actual editor initializer gives GUID templates a readable filename'
 $schema.AutoTemplate=$true
 Assert-Check ((& ([scriptblock]::Create($initializer.Right.Extent.Text))) -ceq 'Мой шаблон.docx') 'The actual editor initializer keeps the new template name'
 Write-Output ('ALL PASSED: '+$script:checks+' form-name checks. Native Windows controls were not exercised.')
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
