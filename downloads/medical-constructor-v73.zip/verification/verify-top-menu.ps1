﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v73'))
$ErrorActionPreference='Stop'
$tally=@{Checks=0}
function Assert-Menu([bool]$condition,[string]$message){if(-not $condition){throw $message};$tally.Checks++;Write-Output ('PASS '+$message)}
$source=[IO.File]::ReadAllText((Join-Path $Project 'top-menu-v72.ps1'))
$uiSource=[IO.File]::ReadAllText((Join-Path $Project 'ui-v57.ps1'))
foreach($name in @('top-menu-v72.ps1','ui-v57.ps1')){
 $errors=$null;$tokens=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project $name),[ref]$tokens,[ref]$errors)
 Assert-Menu ($errors.Count -eq 0) ($name+' parses without errors')
 $bytes=[IO.File]::ReadAllBytes((Join-Path $Project $name));Assert-Menu ($bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191) ($name+' retains UTF-8 BOM for Windows PowerShell')
}
$cpp=[regex]::Match($source,"(?s)-TypeDefinition @'\r?\n(.*?)\r?\n'@").Groups[1].Value
Assert-Menu ([bool]$cpp) 'Native hidden-command dispatcher and menu colors are present'
$work=Join-Path ([IO.Path]::GetTempPath()) ('medical-menu-tests-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($work)
try{
 if($env:OS -ne 'Windows_NT'){
  $references=@(Get-ChildItem (Join-Path $PSHOME 'ref/*.dll')|ForEach-Object FullName)+@(Get-ChildItem '/tmp/windowsdesktop-ref/ref/net8.0/*.dll'|ForEach-Object FullName)
  $assembly=Join-Path $work 'native-menu.dll';Add-Type -TypeDefinition $cpp -ReferencedAssemblies $references -OutputAssembly $assembly -ErrorAction Stop
  Assert-Menu ((Get-Item $assembly).Length -gt 0) 'Native command bridge and theme renderer compile against official WindowsDesktop references'
  $fakeSource=@'
using System;
using System.Collections.ObjectModel;
using System.Drawing;
namespace System.Windows.Forms {
 [Flags] public enum Keys {None=0,O=1,N=2,S=4,P=8,F1=16,Control=256,Shift=512}
 public enum SizeType {Absolute,AutoSize,Percent}
 public class Padding {public int Left,Top,Right,Bottom;public Padding(int n){Left=Top=Right=Bottom=n;}public Padding(int l,int t,int r,int b){Left=l;Top=t;Right=r;Bottom=b;}}
 public class ControlCollection : Collection<Control> {Control owner;public ControlCollection(Control c){owner=c;}protected override void InsertItem(int index,Control item){if(item.Parent!=null)item.Parent.Controls.Remove(item);base.InsertItem(index,item);item.Parent=owner;}protected override void RemoveItem(int i){Control c=this[i];base.RemoveItem(i);c.Parent=null;}public void Add(Control c,int column,int row){c.Column=column;c.Row=row;Add(c);}}
 public class StyleCollection : Collection<object> {public new int Add(object value){base.Add(value);return Count-1;}}
 public class ColumnStyle {public SizeType SizeType;public float Width;public ColumnStyle(SizeType t,float w){SizeType=t;Width=w;}}
 public class RowStyle {public SizeType SizeType;public float Height;public RowStyle(SizeType t){SizeType=t;}public RowStyle(SizeType t,float h){SizeType=t;Height=h;}}
 public class Control {public string Name,Text,AccessibleName,Dock,Anchor,TextAlign,FlowDirection;public bool AutoSize,AutoScroll,WrapContents,TabStop=true,UseMnemonic=true,AutoEllipsis,IsDisposed;bool visible=true,enabled=true;public bool Visible{get{return visible&&(Parent==null||Parent.Visible);}set{visible=value;}}public bool Enabled{get{return enabled&&(Parent==null||Parent.Enabled);}set{enabled=value;}}public object Margin,Padding,Font,BackColor,ForeColor,Size,MinimumSize,AutoScaleDimensions;public int Width,Height,Row,Column;public Control Parent;public ControlCollection Controls;public Control(){Controls=new ControlCollection(this);}public virtual void Dispose(){IsDisposed=true;foreach(Control c in Controls)c.Dispose();}public void SuspendLayout(){}public void ResumeLayout(bool perform){}}
 public class ContainerControl:Control{public Control ActiveControl;}
 public class Form:ContainerControl{public string AutoScaleMode;public bool KeyPreview;public MenuStrip MainMenuStrip;public int CloseCalls;public void Close(){CloseCalls++;}}
 public class Panel:Control{}
 public class FlowLayoutPanel:Panel{}
 public class TableLayoutPanel:Panel{public int RowCount,ColumnCount;public StyleCollection RowStyles=new StyleCollection(),ColumnStyles=new StyleCollection();}
 public class Label:Control{}
 public class Button:Control{public object FlatAppearance=new object();public event EventHandler Click;protected virtual void OnClick(EventArgs e){if(Click!=null)Click(this,e);}public void PerformClick(){if(Visible&&Enabled)OnClick(EventArgs.Empty);}}
 public class TextBoxBase:Control{public bool ReadOnly,CanUndo;public int SelectionLength;public int UndoCalls,CutCalls,CopyCalls,PasteCalls,SelectAllCalls;public void Undo(){UndoCalls++;}public void Cut(){CutCalls++;}public void Copy(){CopyCalls++;}public void Paste(){PasteCalls++;}public void SelectAll(){SelectAllCalls++;}}
 public class TextBox:TextBoxBase{}
 public class ObjectCollection:Collection<object>{public void AddRange(object[] values){foreach(object value in values)Add(value);}}
 public class ComboBox:Control{int index=-1;public string DropDownStyle;public ObjectCollection Items=new ObjectCollection();public int SelectedIndex{get{return index;}set{if(value!=index){index=value;if(SelectedIndexChanged!=null)SelectedIndexChanged(this,EventArgs.Empty);}}}public event EventHandler SelectedIndexChanged;}
 public class ToolTip{public void SetToolTip(Control c,string text){}}
 public class ToolStripItem{public string Name,Text,ToolTipText;public bool Enabled=true,IsDisposed;public object BackColor,ForeColor;public event EventHandler Click;public void PerformClick(){if(Enabled&&Click!=null)Click(this,EventArgs.Empty);}}
 public class ItemCollection:Collection<ToolStripItem>{public new int Add(ToolStripItem item){base.Add(item);return Count-1;}}
 public class ToolStripMenuItem:ToolStripItem{public bool Checked,CheckOnClick;public Keys ShortcutKeys;public string ShortcutKeyDisplayString;public ItemCollection DropDownItems=new ItemCollection();public event EventHandler DropDownOpening;public void Open(){if(DropDownOpening!=null)DropDownOpening(this,EventArgs.Empty);}}
 public class ToolStripSeparator:ToolStripItem{}
 public class MenuStrip:Control{public string GripStyle;public bool CanOverflow,Stretch;public object Renderer;public ItemCollection Items=new ItemCollection();public event EventHandler MenuActivate;public void Activate(){if(MenuActivate!=null)MenuActivate(this,EventArgs.Empty);}}
 public class ProfessionalColorTable {public bool UseSystemColors;public virtual Color ToolStripDropDownBackground{get{return Color.White;}}public virtual Color ImageMarginGradientBegin{get{return Color.White;}}public virtual Color ImageMarginGradientMiddle{get{return Color.White;}}public virtual Color ImageMarginGradientEnd{get{return Color.White;}}public virtual Color MenuItemSelected{get{return Color.White;}}public virtual Color MenuItemSelectedGradientBegin{get{return Color.White;}}public virtual Color MenuItemSelectedGradientEnd{get{return Color.White;}}public virtual Color MenuItemPressedGradientBegin{get{return Color.White;}}public virtual Color MenuItemPressedGradientMiddle{get{return Color.White;}}public virtual Color MenuItemPressedGradientEnd{get{return Color.White;}}public virtual Color MenuItemBorder{get{return Color.White;}}public virtual Color MenuBorder{get{return Color.White;}}}
 public class ToolStripProfessionalRenderer{public ProfessionalColorTable ColorTable;public ToolStripProfessionalRenderer(ProfessionalColorTable colors){ColorTable=colors;}}
 public static class MessageBox {public static object Show(object owner,string text,string caption){return null;}public static object Show(string text,string caption){return null;}}
}
'@
  Add-Type -TypeDefinition ('using System.Collections.ObjectModel;'+$cpp+([regex]::Replace($fakeSource,'(?m)^using [^;]+;\r?\n',''))) -ErrorAction Stop
 }else{
  Add-Type -AssemblyName System.Windows.Forms,System.Drawing;Add-Type -TypeDefinition $cpp -ReferencedAssemblies 'System.Windows.Forms','System.Drawing'
  Assert-Menu ($null -ne ('MedicalMenuCommandBridgeV72' -as [type])) 'Native Windows hidden-command dispatcher compiles'
  $nativeOwner=New-Object Windows.Forms.Form;$nativeHost=New-Object Windows.Forms.Panel;$nativeHost.Visible=$false;$nativeOwner.Controls.Add($nativeHost)
  $nativeButton=New-Object Windows.Forms.Button;$nativeHost.Controls.Add($nativeButton);$nativeState=@{Calls=0}
  $nativeButton.Add_Click({$nativeState.Calls++}.GetNewClosure())
  $nativeButton.PerformClick();Assert-Menu ($nativeState.Calls -eq 0) 'Native hidden button ignores PerformClick'
  Assert-Menu ([MedicalMenuCommandBridgeV72]::Invoke($nativeButton) -and $nativeState.Calls -eq 1) 'Native dispatcher invokes one existing hidden callback'
  $nativeButton.Enabled=$false;Assert-Menu (-not [MedicalMenuCommandBridgeV72]::Invoke($nativeButton) -and $nativeState.Calls -eq 1) 'Native dispatcher respects disabled command'
  $nativeButton.Enabled=$true;$nativeButton.Dispose();Assert-Menu (-not [MedicalMenuCommandBridgeV72]::Invoke($nativeButton)) 'Native dispatcher refuses disposed command'
  $nativeOwner.Dispose()
  Write-Output ('TOTAL '+$tally.Checks+' native Windows checks passed. Full menu construction harness runs on Linux; visual UI needs manual verification.')
  return
 }
 . (Join-Path $Project 'top-menu-v72.ps1')
 $script:darkPanel=[Drawing.Color]::FromArgb(28,40,54);$script:uiSoft=[Drawing.Color]::FromArgb(34,63,61);$script:uiBorder=[Drawing.Color]::SlateGray;$script:darkText=[Drawing.Color]::White
 $script:uiTheme='dark';$script:stage='initial';$script:medicalAuthSession=[pscustomobject]@{DisplayName='Administrator';Role='Administrator'}
 $owner=New-Object Windows.Forms.Form
 $hostPanel=New-Object Windows.Forms.Panel;$hostPanel.Visible=$false;$owner.Controls.Add($hostPanel)
 $calls=@{};$buttons=@{}
 foreach($key in @('OpenCard','NewForm','OpenForm','SaveForm','SaveCard','Export','Preview','Print','PreviewFile','TemplateEditor','FieldSettings','Templates','Font','initial','diary','discharge')){
  $button=New-Object Windows.Forms.Button;$buttons[$key]=$button;$calls[$key]=0;$capturedKey=$key
  $button.Add_Click({$calls[$capturedKey]++}.GetNewClosure());$hostPanel.Controls.Add($button)
 }
 $special=@{Assistant=0;AiSettings=0;Password=0;Accounts=0;Lock=0}
 function Invoke-MedicalLocalAssistant($owner){$special.Assistant++}
 function Show-MedicalAiSettings($owner){$special.AiSettings++}
 function Invoke-MedicalPasswordChangeAction($owner){$special.Password++}
 function Invoke-MedicalAccountsManagerAction($owner){$special.Accounts++}
 function Invoke-MedicalAccountLock($owner){$special.Lock++}
 $theme=New-Object Windows.Forms.ComboBox;$theme.SelectedIndex=1
 $theme.Add_SelectedIndexChanged({$script:uiTheme=@('light','dark','contrast')[$this.SelectedIndex]})
 $menu=New-MedicalMainMenu $owner $buttons $theme
 Assert-Menu (($menu.Items|ForEach-Object Text)-join '|' -eq 'Файл|Правка|Текст|Настройки|Вид|Сервис|Справка') 'Main menu presents real horizontal categories without inactive placeholder menus'
 Assert-Menu ($menu.CanOverflow -and $menu.Stretch -and $menu.AutoSize) 'Menu can overflow on narrow displays and uses native auto sizing'
 foreach($key in $buttons.Keys){Assert-Menu ($script:medicalMenuItems.ContainsKey($key)) ('Top menu exposes inherited command '+$key)}
 $buttons.OpenCard.PerformClick();Assert-Menu ($calls.OpenCard -eq 0) 'Native-like hidden button demonstrates PerformClick cannot activate hidden handlers'
 foreach($key in $buttons.Keys){
  $script:medicalMenuItems[$key].PerformClick()
  Assert-Menu ($calls[$key] -eq 1) ('Real menu closure invokes exactly the existing hidden callback: '+$key)
 }
 $buttons.Export.Enabled=$false;$menu.Activate()
 Assert-Menu (-not $script:medicalMenuItems.Export.Enabled) 'Menu opening reflects disabled export command'
 $script:medicalMenuItems.Export.PerformClick();Assert-Menu ($calls.Export -eq 1) 'Disabled menu cannot invoke its command'
 Assert-Menu (-not (Invoke-MedicalMenuButton $buttons.Export)) 'Native bridge independently refuses disabled commands'
 $buttons.Export.Enabled=$true;$menu.Activate();$script:medicalMenuItems.Export.PerformClick();Assert-Menu ($calls.Export -eq 2) 'Enabled command is restored without rebinding or duplicate events'
 $buttons.Preview.Dispose();$menu.Activate();Assert-Menu (-not $script:medicalMenuItems.Preview.Enabled) 'Disposed command cannot remain clickable'
 $thrower=New-Object Windows.Forms.Button;$thrower.Add_Click({throw 'menu-test-sentinel'})
 try{$null=Invoke-MedicalMenuButton $thrower;throw 'Missing expected command exception'}catch{Assert-Menu ($_.Exception.ToString().Contains('menu-test-sentinel')) 'Hidden command exceptions preserve their actual reason for the UI error guard'}
 foreach($key in @('Assistant','AiSettings','Password','Accounts','Lock')){$script:medicalMenuItems[$key].PerformClick();Assert-Menu ($special[$key] -eq 1) ('Actual '+$key+' callback resolves captured private helper after factory returns')}
 foreach($index in @(0,2,1)){
  $script:medicalMenuItems['theme'+$index].PerformClick()
  Assert-Menu ($theme.SelectedIndex -eq $index -and $script:uiTheme -eq @('light','dark','contrast')[$index]) ('Theme menu drives existing persisted selector: '+$index)
  for($i=0;$i -lt 3;$i++){Assert-Menu ($script:medicalMenuItems['theme'+$i].Checked -eq ($i -eq $index)) ('Theme check state '+$i+' after '+$index)}
 }
 foreach($stage in @('initial','diary','discharge')){$script:stage=$stage;Update-MedicalMainMenu;foreach($key in @('initial','diary','discharge')){Assert-Menu ($script:medicalMenuItems[$key].Checked -eq ($key -eq $stage)) ('Current stage '+$stage+' check '+$key)}}
 foreach($case in @(@('OpenCard','Control, O'),@('OpenForm','Control, Shift, O'),@('SaveCard','Control, S'),@('SaveForm','Control, Shift, S'),@('Print','Control, P'),@('Help','F1'))){Assert-Menu ($script:medicalMenuItems[$case[0]].ShortcutKeys -eq [Windows.Forms.Keys]$case[1]) ('Native shortcut belongs to real menu action '+$case[0])}
 $text=New-Object Windows.Forms.TextBox;$text.SelectionLength=4;$text.CanUndo=$true;$container=New-Object Windows.Forms.ContainerControl;$container.ActiveControl=$text;$owner.ActiveControl=$container
 Assert-Menu ((Get-MedicalFocusedEditTarget $owner) -eq $text) 'Focused text editor is found inside nested container'
 $edit=@($menu.Items|Where-Object Text -eq 'Правка')[0];$edit.Open()
 foreach($action in @('Undo','Cut','Copy','Paste','SelectAll')){$script:medicalMenuItems[$action].PerformClick();Assert-Menu ($text.($action+'Calls') -eq 1) ('Edit menu invokes focused native text operation '+$action);Assert-Menu ($script:medicalMenuItems[$action].ShortcutKeys -eq [Windows.Forms.Keys]::None) ('Edit menu leaves native keyboard shortcut handling intact: '+$action)}
 $text.ReadOnly=$true;$edit.Open()
 foreach($action in @('Undo','Cut','Paste')){Assert-Menu (-not $script:medicalMenuItems[$action].Enabled) ('Read-only text disables mutation '+$action);$script:medicalMenuItems[$action].PerformClick();Assert-Menu ($text.($action+'Calls') -eq 1) ('Read-only text remains unchanged by '+$action)}
 Assert-Menu ($script:medicalMenuItems.Copy.Enabled -and $script:medicalMenuItems.SelectAll.Enabled) 'Read-only text retains copy and select-all'
 $text.ReadOnly=$false;$text.SelectionLength=0;$text.CanUndo=$false;$edit.Open()
 foreach($action in @('Undo','Cut','Copy')){Assert-Menu (-not $script:medicalMenuItems[$action].Enabled) ('Empty selection or history disables '+$action)}
 $owner.ActiveControl=New-Object Windows.Forms.Button;$edit.Open()
 foreach($action in @('Undo','Cut','Copy','Paste','SelectAll')){Assert-Menu (-not $script:medicalMenuItems[$action].Enabled) ('Non-text focus disables edit action '+$action)}
 $script:medicalMenuItems.Exit.PerformClick();Assert-Menu ($owner.CloseCalls -eq 1) 'Exit routes to normal Form.Close and preserves existing close confirmation'
 $script:medicalAuthSession=[pscustomobject]@{DisplayName='Employee';Role='User'}
 $employeeMenu=New-MedicalMainMenu $owner $buttons $theme
 Assert-Menu (-not $script:medicalMenuItems.ContainsKey('Accounts')) 'Ordinary employee does not receive administrator command'
 Assert-Menu ($script:medicalMenuItems.ContainsKey('Password') -and $script:medicalMenuItems.ContainsKey('Lock')) 'Employee retains own password and lock actions'
 Assert-Menu ($employeeMenu.Renderer.ColorTable.MenuItemSelected -eq $script:uiSoft -and $employeeMenu.Renderer.ColorTable.ToolStripDropDownBackground -eq $script:darkPanel) 'Dropdown and selected menu use current theme colors'
 foreach($item in $employeeMenu.Items){Assert-Menu ($item.ForeColor -eq $script:darkText -and $item.BackColor -eq $script:darkPanel) ('Top category has readable palette: '+$item.Text);foreach($child in $item.DropDownItems){Assert-Menu ($child.ForeColor -eq $script:darkText) ('Dropdown item has readable text: '+$child.Text)}}
 # Execute the production full-width workspace constructor with native-like
 # control collections. Font creation is the only Drawing-dependent stub.
 $uiAst=[Management.Automation.Language.Parser]::ParseInput($uiSource,[ref]$null,[ref]$null)
 $initializer=$uiAst.Find({param($a)$a -is [Management.Automation.Language.FunctionDefinitionAst] -and $a.Name -eq 'Initialize-MedicalWorkspace'},$true)
 Invoke-Expression $initializer.Extent.Text
 function New-Object {param([Parameter(Position=0)][string]$TypeName,[Parameter(Position=1)][object[]]$ArgumentList,[hashtable]$Property)
  if($TypeName -eq 'Drawing.Font'){return [pscustomobject]@{FontStub=$true}}
  $arguments=@{TypeName=$TypeName};if($PSBoundParameters.ContainsKey('ArgumentList')){$arguments.ArgumentList=$ArgumentList};if($PSBoundParameters.ContainsKey('Property')){$arguments.Property=$Property}
  Microsoft.PowerShell.Utility\New-Object @arguments
 }
 function Set-DarkTheme($root){}
 function Update-MedicalNavigation {Update-MedicalMainMenu}
 $form=New-Object Windows.Forms.Form;$top=New-Object Windows.Forms.Panel;$panel=New-Object Windows.Forms.Panel;$layout=New-Object Windows.Forms.TableLayoutPanel
 $layout.Controls.Add($top);$layout.Controls.Add($panel);$form.Controls.Add($layout)
 $brand=New-Object Windows.Forms.Label;$version=New-Object Windows.Forms.Label;$top.Controls.Add($brand);$top.Controls.Add($version)
 $script:progressLabel=New-Object Windows.Forms.Label
 $caseOpen=$buttons.OpenCard;$newInitial=$buttons.NewForm;$openFormButton=$buttons.OpenForm;$saveFormButton=$buttons.SaveForm;$caseSave=$buttons.SaveCard;$save=$buttons.Export
 $previewButton=New-Object Windows.Forms.Button;$printButton=$buttons.Print;$filePreviewButton=$buttons.PreviewFile;$configure=$buttons.TemplateEditor;$fieldSettingsButton=$buttons.FieldSettings;$open=$buttons.Templates;$documentFontButton=$buttons.Font
 $stageInitial=$buttons.initial;$stageDiary=$buttons.diary;$stageDischarge=$buttons.discharge
 if($env:OS -ne 'Windows_NT'){$themeItemsType=$null}
 Initialize-MedicalWorkspace
 Assert-Menu ($script:uiRoot.ColumnCount -eq 1 -and $script:uiRoot.RowCount -eq 5) 'Production workspace uses one full-width column with separate top menu row'
 Assert-Menu ($panel.Parent -eq $script:uiRoot -and $panel.Column -eq 0 -and $panel.Row -eq 3 -and $panel.Dock -eq 'Fill') 'Patient form fills main work area without a left sidebar'
 Assert-Menu ($form.MainMenuStrip -eq $script:medicalMainMenu -and $script:medicalMainMenu.Parent -eq $script:uiRoot) 'Native form owns the actual visible menu strip'
 Assert-Menu ($script:uiRoot.RowStyles[0].SizeType -eq [Windows.Forms.SizeType]::AutoSize) 'Menu row grows with native font and DPI instead of clipping a fixed height'
 Assert-Menu ($top.Parent -eq $form -and -not $top.Visible -and -not $top.IsDisposed) 'Legacy handlers survive in hidden command host after old layout disposal'
 foreach($key in @('OpenCard','NewForm','OpenForm','SaveForm','Export','Print','PreviewFile','TemplateEditor','FieldSettings','Templates','Font','initial','diary','discharge')){Assert-Menu ($buttons[$key].Parent -eq $top -and -not $buttons[$key].Visible -and -not $buttons[$key].IsDisposed) ('Inherited toolbar control is hidden and alive: '+$key)}
 Assert-Menu ($script:uiPatientLabel.Parent -eq $script:uiRoot -and $script:uiPatientLabel.Row -eq 2) 'Compact patient identity remains visible above full-width form'
 Assert-Menu ($script:uiMedicalFormStatus.Parent.Parent -eq $script:uiRoot) 'Saved-form status remains accessible in the footer'
 Assert-Menu ($form.KeyPreview -and $form.MinimumSize.Width -eq 1100) 'Main form retains keyboard input and supports narrower full-width workspace'
 $before=$calls.OpenCard;$script:medicalMenuItems.OpenCard.PerformClick();Assert-Menu ($calls.OpenCard -eq $before+1) 'Constructed workspace menu still invokes original card-opening callback'
 Write-Output ('TOTAL '+$tally.Checks+' checks passed; native Windows display remains to be tested.')
}finally{if(Test-Path -LiteralPath $work){Remove-Item -LiteralPath $work -Recurse -Force}}
