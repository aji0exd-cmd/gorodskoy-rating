﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v73'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Check([bool]$test,[string]$label){if(-not $test){throw $label};$script:checks++;Write-Output ('PASS '+$label)}
function Assert-Reject([scriptblock]$operation,[string]$label){$threw=$false;try{& $operation | Out-Null}catch{$threw=$true};Assert-Check $threw $label}
function Import-TestFunctions([string]$path,[string[]]$names=@()){
 $t=$null;$e=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$t,[ref]$e)
 if($e.Count){throw ($e|Out-String)}
 foreach($node in $ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
  if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}
 }
}
function Capture-Stage {$script:captureCount++;if($script:stage -eq 'initial'){Set-UniversalDemographics}}
function Invoke-MedicalSaveForm {
 $script:formSaveCalls++
 if($script:formSaveMode -eq 'Throw'){throw 'TEST form storage unavailable'}
 if($script:formSaveMode -ne 'Success'){return}
 $script:activeMedicalFormPath=Join-Path $script:medicalProgramRoot 'Saved.mcform'
 [IO.File]::WriteAllText($script:activeMedicalFormPath,'saved form')
 Mark-MedicalFormSaved
}
function Save-Case {
 $script:caseSaveCalls++
 if($script:caseSaveMode -eq 'Throw'){throw 'TEST card storage unavailable'}
 if($script:caseSaveMode -ne 'Success'){return}
 $script:caseFile=Join-Path $script:medicalProgramRoot 'Saved.docx'
 [IO.File]::WriteAllText($script:caseFile,'saved card')
 Mark-MedicalCaseSaved
}
function Show-MedicalSessionCloseChoice($owner,$formDirty,$caseDirty,$backupPath){$script:closeChoiceCalls++;$script:closeFlags=@($formDirty,$caseDirty);return $script:closeChoice}
function Show-MedicalBackupRecoveryChoice($owner,$backup){$script:recoveryChoiceCalls++;return $script:recoveryChoice}
function Read-TestEnvelope($path){return ([IO.File]::ReadAllText($path)|ConvertFrom-Json)}
function Write-TestEnvelope($path,$envelope){$envelope.Sha256=Get-MedicalBackupEnvelopeHash $envelope;[IO.File]::WriteAllText($path,($envelope|ConvertTo-Json -Depth 10 -Compress),[Text.UTF8Encoding]::new($false))}
function Write-TestPayload($path,$envelope,$data){
 $payload=$envelope.PayloadJson|ConvertFrom-Json;$payload.Data=$data
 $payload.FormSignature=Get-MedicalBackupFormSignature $data;$payload.CaseSignature=Get-MedicalBackupCaseSignature $data
 $envelope.PayloadJson=$payload|ConvertTo-Json -Depth 100 -Compress;Write-TestEnvelope $path $envelope
}
function Get-TestTree($path){if(-not [IO.Directory]::Exists($path)){return ""};return ((Get-ChildItem -LiteralPath $path -File -Recurse | Sort-Object FullName | ForEach-Object {$_.FullName+':'+(Get-FileHash -LiteralPath $_.FullName).Hash}) -join ';')}
if(-not ('Windows.Forms.MessageBox' -as [type])){Add-Type -TypeDefinition 'namespace Windows.Forms { public static class MessageBox { public static int Calls=0; public static int Show(params object[] items){ Calls++; return 0;} } }'}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-v67-backup-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
try{
 Import-TestFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart','Get-HospitalizationValues','Get-FullRegistration')
 foreach($module in @('universal.ps1','forms-v59.ps1','template-recovery-v66.ps1','template-editor-v59.ps1','template-editor-operations-v61.ps1','clinical-stages-v67.ps1','backup-v67.ps1')){Import-TestFunctions (Join-Path $Project $module)}
 Import-TestFunctions (Join-Path $Project 'universal-ui.ps1') @('Set-UniversalDemographics')
 Import-TestFunctions (Join-Path $Project 'backup-ui-v67.ps1') @('Confirm-MedicalSessionClose','Start-MedicalBackupRecovery')
 $script:medicalProgramRoot=$temp;$script:medicalTemplatesFolder=Join-Path $temp 'Шаблоны'
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 foreach($name in @('patientNameControl','patientBirthControl','patientAddressControl','streetControl','houseControl','apartmentControl')){Set-Variable -Scope Script -Name $name -Value ([pscustomobject]@{Text=''})}
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-14T10:20:30'}
 $script:hospitalControls=@{count=[pscustomobject]@{Text='Повторно'};referred=[pscustomobject]@{Text='ТЕСТ направление'}}
 $script:universalConfig=New-UniversalConfig;$script:universalValues=@{patient_name='ТЕСТ ПАЦИЕНТ';patient_birth='01.01.2000';patient_address='ТЕСТ АДРЕС';complaints='ЖАЛОБЫ'};$script:universalDetails=@{}
 $script:stage='initial';$script:diaryIndex=1;$script:stageTemplates=@{initial='';diary='';discharge=''};$script:stageData=@{initial=@('Ответ первичного осмотра');diary_1=@('Старый дневник')}
 $script:activeMedicalFormPath='';$script:activeMedicalFormName='ТЕСТ ФОРМА';$script:caseFile='';$script:caseFolder='';$script:caseLastSavedPatientName=$null
 $script:medicalWorkspaceReady=$true;$script:medicalBackupPath='';$script:medicalBackupBusy=$false;$script:medicalBackupLastError=''
 $script:medicalBackupFormSavedSignature='';$script:medicalBackupCaseSavedSignature='';$script:medicalBackupEditorDraft=$null;$script:medicalBackupRetainedDraft=$null;$script:medicalEditorRecoveryDraft=$null;$script:medicalBackupPendingDeferred=$false
 $script:captureCount=0;$script:formSaveCalls=0;$script:caseSaveCalls=0;$script:closeChoiceCalls=0;$script:recoveryChoiceCalls=0
 $script:closeChoice='Cancel';$script:recoveryChoice='Later';$script:formSaveMode='Cancel';$script:caseSaveMode='Cancel'
 [void](Initialize-MedicalClinicalWorkspace)
 $first=Add-MedicalClinicalDiary;$second=Add-MedicalClinicalDiary
 Set-MedicalClinicalValue 'diary' $first.Id 'diary_complaints' 'ПЕРВЫЙ ДНЕВНИК'
 Set-MedicalClinicalValue 'diary' $second.Id 'diary_complaints' 'ВТОРОЙ ДНЕВНИК'
 Set-MedicalClinicalDate $second.Id ([datetime]'2026-10-15T13:30:00')
 Set-MedicalClinicalValue 'discharge' '' 'complaints' 'РЕДАКТИРОВАННЫЕ ЖАЛОБЫ ЭПИКРИЗА'
 Set-MedicalClinicalValue 'discharge' '' 'recommendations' 'РЕКОМЕНДАЦИИ'
 [void](Set-MedicalTreatmentPeriod ([datetime]'2026-10-01') ([datetime]'2026-10-10'))
 $script:medicalActiveDiaryId=$second.Id
 [void](Initialize-MedicalSessionBackup $temp)
 Assert-Check ($script:medicalBackupPath -ceq (Join-Path $temp 'Резервные копии/working-session.mcbak')) 'Checkpoints default to program backup directory'
 $checkpoint=Write-MedicalSessionBackup
 Assert-Check ([IO.File]::Exists($checkpoint.Path)) 'Actual session checkpoint written'
 Assert-Check ($script:captureCount -gt 0) 'Live stage captured before checkpoint'
 Assert-Check (-not $checkpoint.Closed) 'Working checkpoint is recoverable'
 Assert-Check ($checkpoint.Payload.Data.Record.universal.Values.patient_name -ceq 'ТЕСТ ПАЦИЕНТ') 'Initial patient values included'
 Assert-Check ($checkpoint.Payload.Data.Record.stages.diary_1[0] -ceq 'Старый дневник') 'Legacy stages retained'
 Assert-Check ($checkpoint.Payload.Data.Record.hospitalization.referred -ceq 'ТЕСТ направление') 'Hospitalization answers retained'
 Assert-Check (@($checkpoint.Payload.Data.ClinicalForms.Diaries).Count -eq 2) 'All diary layouts embedded'
 Assert-Check ($checkpoint.Payload.Data.Clinical.Diaries[1].Values.diary_complaints -ceq 'ВТОРОЙ ДНЕВНИК') 'Second diary patient answers embedded'
 Assert-Check ($checkpoint.Payload.Data.Clinical.Discharge.Values.complaints -ceq 'РЕДАКТИРОВАННЫЕ ЖАЛОБЫ ЭПИКРИЗА') 'Discharge override retained'
 Assert-Check ($checkpoint.Payload.Data.View.ActiveDiaryId -ceq $second.Id) 'Active diary stable ID retained'
 Assert-Check ($checkpoint.Payload.Data.Clinical.TreatmentPeriod.StartDate -ceq '2026-10-01' -and $checkpoint.Payload.Data.Clinical.TreatmentPeriod.EndDate -ceq '2026-10-10' -and $checkpoint.Payload.Data.Clinical.TreatmentPeriod.StartOverride) 'Treatment period with manual override is included in the patient checkpoint'
 foreach($stageDefinition in @($checkpoint.Payload.Data.ClinicalForms.Diaries)+@($checkpoint.Payload.Data.ClinicalForms.Discharge)){
  Assert-Check ([Convert]::FromBase64String($stageDefinition.TemplateBase64).Length -gt 500) 'Stage Word source is portable'
 }
 $formHash=Get-MedicalBackupFormSignature $checkpoint.Payload.Data;$caseHash=Get-MedicalBackupCaseSignature $checkpoint.Payload.Data
 $next=Write-MedicalSessionBackup
 Assert-Check ($formHash -ceq (Get-MedicalBackupFormSignature $next.Payload.Data)) 'Generated ZIP timestamps do not dirty form'
 Assert-Check ($caseHash -ceq (Get-MedicalBackupCaseSignature $next.Payload.Data)) 'Repeated capture has stable case signature'
 Assert-Check ([IO.File]::Exists($checkpoint.Path+'.bak')) 'Atomic replacement retains previous valid checkpoint'
 $reordered=[ordered]@{z=@([pscustomobject]@{b=2;a=1});a='abc'};$ordered=[ordered]@{a='abc';z=@([pscustomobject]@{a=1;b=2})}
 Assert-Check ((Get-MedicalBackupHash $reordered) -ceq (Get-MedicalBackupHash $ordered)) 'Canonical hash ignores dictionary/property ordering'
 Assert-Check ((Get-MedicalBackupHash @{x=@('a','b')}) -cne (Get-MedicalBackupHash @{x=@('b','a')})) 'Canonical hash retains list order'
 $envelope=Read-TestEnvelope $checkpoint.Path;$broken=Join-Path $temp 'broken.mcbak'
 $meta=Copy-MedicalBackupValue $envelope;$meta.Closed=$true;[IO.File]::WriteAllText($broken,($meta|ConvertTo-Json -Depth 10))
 Assert-Reject {Read-MedicalSessionBackup $broken} 'Changed close flag rejects checksum'
 $meta=Copy-MedicalBackupValue $envelope;$meta.CreatedUtc=[datetime]'2030-01-01T00:00:00Z';[IO.File]::WriteAllText($broken,($meta|ConvertTo-Json -Depth 10))
 Assert-Reject {Read-MedicalSessionBackup $broken} 'Changed timestamp rejects checksum'
 $meta=Copy-MedicalBackupValue $envelope;$meta.PayloadJson=$meta.PayloadJson+' ';[IO.File]::WriteAllText($broken,($meta|ConvertTo-Json -Depth 10))
 Assert-Reject {Read-MedicalSessionBackup $broken} 'Changed payload rejects checksum'
 $data=Copy-MedicalBackupValue $checkpoint.Payload.Data;$data.Clinical.TreatmentPeriod.EndDate='2026-09-01'
 Write-TestPayload $broken (Copy-MedicalBackupValue $envelope) $data
 $periodInitialBefore=Get-UniversalState|ConvertTo-Json -Depth 100 -Compress;$periodClinicalBefore=Get-MedicalClinicalState|ConvertTo-Json -Depth 100 -Compress;$periodTreeBefore=Get-TestTree $script:medicalTemplatesFolder
 Assert-Reject {Restore-MedicalSessionBackup $broken} 'Invalid recovered treatment period rejects before any patient or portable-template mutation'
 Assert-Check ((Get-UniversalState|ConvertTo-Json -Depth 100 -Compress) -ceq $periodInitialBefore -and (Get-MedicalClinicalState|ConvertTo-Json -Depth 100 -Compress) -ceq $periodClinicalBefore -and (Get-TestTree $script:medicalTemplatesFolder) -ceq $periodTreeBefore) 'Rejected treatment period leaves the current complete patient and managed Word templates intact'
 $data=Copy-MedicalBackupValue $checkpoint.Payload.Data;$data.Clinical.Diaries[1].DateTime='not-a-date'
 Write-TestPayload $broken (Copy-MedicalBackupValue $envelope) $data
 $before=Get-TestTree $script:medicalTemplatesFolder;$oldInitial=Get-UniversalState|ConvertTo-Json -Depth 100 -Compress;$oldClinical=Get-MedicalClinicalState|ConvertTo-Json -Depth 100 -Compress
 Assert-Reject {Restore-MedicalSessionBackup $broken} 'Invalid diary date rejects recovery'
 Assert-Check ((Get-TestTree $script:medicalTemplatesFolder) -ceq $before) 'Date validation precedes all template imports'
 Assert-Check ((Get-UniversalState|ConvertTo-Json -Depth 100 -Compress) -ceq $oldInitial) 'Rejected recovery leaves initial patient state intact'
 Assert-Check ((Get-MedicalClinicalState|ConvertTo-Json -Depth 100 -Compress) -ceq $oldClinical) 'Rejected recovery leaves all clinical state intact'
 $data=Copy-MedicalBackupValue $checkpoint.Payload.Data;$data.Clinical.Version=99;Write-TestPayload $broken (Copy-MedicalBackupValue $envelope) $data
 Assert-Reject {Restore-MedicalSessionBackup $broken} 'Unknown clinical state version rejects before imports'
 $data=Copy-MedicalBackupValue $checkpoint.Payload.Data;$data.Clinical.Diaries[1].Id='unknown';Write-TestPayload $broken (Copy-MedicalBackupValue $envelope) $data
 Assert-Reject {Restore-MedicalSessionBackup $broken} 'Unknown clinical diary rejects before imports'
 $data=Copy-MedicalBackupValue $checkpoint.Payload.Data;$data.ClinicalForms.Diaries[1].TemplateSha256='0'*64;Write-TestPayload $broken (Copy-MedicalBackupValue $envelope) $data
 Assert-Reject {Restore-MedicalSessionBackup $broken} 'Invalid stage Word checksum rejects before imports'
 $data=Copy-MedicalBackupValue $checkpoint.Payload.Data;$data.Record.universal.AdmissionDateTime='1700-01-01T00:00:00';Write-TestPayload $broken (Copy-MedicalBackupValue $envelope) $data
 Assert-Reject {Restore-MedicalSessionBackup $broken} 'Date outside native control range rejects before mutation'
 $data=Copy-MedicalBackupValue $checkpoint.Payload.Data;$data.Record.universal.Schema.Sections[1].Id=$data.Record.universal.Schema.Sections[0].Id;Write-TestPayload $broken (Copy-MedicalBackupValue $envelope) $data
 Assert-Reject {Restore-MedicalSessionBackup $broken} 'Invalid active schema rejects before mutation'
 $data=Copy-MedicalBackupValue $checkpoint.Payload.Data;$data.View.ActiveDiaryId='unknown';Write-TestPayload $broken (Copy-MedicalBackupValue $envelope) $data
 Assert-Reject {Restore-MedicalSessionBackup $broken} 'Invalid current diary ID rejects recovery'
 $priorHash=Get-MedicalBackupBytesHash ([IO.File]::ReadAllBytes($script:medicalBackupPath))
 $badDateEntry=@($script:medicalClinicalState.Diaries)[1];$validDate=$badDateEntry.DateTime;$badDateEntry.DateTime='invalid-current-date'
 Assert-Reject {Write-MedicalSessionBackup} 'Invalid live state prevents checkpoint replacement'
 Assert-Check ((Get-MedicalBackupBytesHash ([IO.File]::ReadAllBytes($script:medicalBackupPath))) -ceq $priorHash) 'Failed checkpoint leaves previous valid bytes untouched'
 Assert-Check (-not $script:medicalBackupBusy) 'Failed checkpoint always releases busy guard'
 Assert-Check (@(Get-ChildItem -LiteralPath (Split-Path -Parent $script:medicalBackupPath) -Filter '.mc-backup-*.tmp').Count -eq 0) 'Failed checkpoint removes temporary partial files'
 $badDateEntry.DateTime=$validDate
 $sourceCheckpoint=Join-Path $temp 'portable-session.mcbak';[IO.File]::Copy($checkpoint.Path,$sourceCheckpoint)
 $script:universalValues.patient_name='НОВЫЙ ДРУГОЙ ПАЦИЕНТ';$script:hospitalControls.referred.Text='ДРУГОЕ НАПРАВЛЕНИЕ';$script:stageData=@{}
 Set-MedicalClinicalValue 'diary' $second.Id 'diary_complaints' 'ДРУГОЙ ДНЕВНИК'
 $other=Join-Path $temp 'new program';[void][IO.Directory]::CreateDirectory($other)
 $script:medicalProgramRoot=$other;$script:medicalTemplatesFolder=Join-Path $other 'Шаблоны'
 [void](Restore-MedicalSessionBackup $sourceCheckpoint)
 Assert-Check ($script:universalValues.patient_name -ceq 'ТЕСТ ПАЦИЕНТ') 'Portable recovery restores canonical initial patient'
 Assert-Check ($script:patientNameControl.Text -ceq 'ТЕСТ ПАЦИЕНТ') 'Portable recovery restores patient display control'
 Assert-Check ($script:hospitalControls.referred.Text -ceq 'ТЕСТ направление') 'Portable recovery restores hospitalization controls'
 Assert-Check ($script:stageData.diary_1[0] -ceq 'Старый дневник') 'Portable recovery restores legacy stages'
 Assert-Check ((Get-MedicalClinicalContext 'diary' $second.Id).Values.diary_complaints -ceq 'ВТОРОЙ ДНЕВНИК') 'Portable recovery restores second diary'
 Assert-Check ((Get-MedicalClinicalContext 'discharge').Values.complaints -ceq 'РЕДАКТИРОВАННЫЕ ЖАЛОБЫ ЭПИКРИЗА') 'Portable recovery restores discharge override'
 Assert-Check ((Get-MedicalTreatmentPeriod).StartDate -ceq '2026-10-01' -and (Get-MedicalTreatmentPeriod).EndDate -ceq '2026-10-10' -and (Get-MedicalTreatmentPeriod).EndOverride) 'Portable recovery restores both treatment dates and their manual override flags'
 Assert-Check ($script:medicalActiveDiaryId -ceq $second.Id) 'Portable recovery selects correct diary by ID'
 foreach($definition in @($script:medicalClinicalForms.Diaries)+@($script:medicalClinicalForms.Discharge)){Assert-Check ([IO.File]::Exists((Join-Path $other $definition.Schema.Template))) 'Recovered clinical Word exists in new program directory'}
 $originalRestore=(Get-Command Restore-MedicalClinicalState).ScriptBlock
 function script:Restore-MedicalClinicalState($source){$script:medicalClinicalState=[pscustomobject]@{Version=999};throw 'TEST native restore failure'}
 $script:universalValues.patient_name='СОХРАНИТЬ ТЕКУЩЕГО';$script:patientNameControl.Text='СОХРАНИТЬ ТЕКУЩЕГО';$script:hospitalControls.referred.Text='СОХРАНИТЬ НАПРАВЛЕНИЕ';$script:admissionControl.Value=[datetime]'2026-10-20T15:00:00'
 $beforeState=Get-MedicalBackupHash ([pscustomobject]@{Schema=$script:universalConfig;Values=$script:universalValues;Clinical=$script:medicalClinicalState;Stage=$script:stageData;Templates=$script:stageTemplates;Form=$script:activeMedicalFormName})
 Assert-Reject {Restore-MedicalSessionBackup $sourceCheckpoint} 'Unexpected native recovery failure rejects operation'
 $afterState=Get-MedicalBackupHash ([pscustomobject]@{Schema=$script:universalConfig;Values=$script:universalValues;Clinical=$script:medicalClinicalState;Stage=$script:stageData;Templates=$script:stageTemplates;Form=$script:activeMedicalFormName})
 Assert-Check ($beforeState -ceq $afterState) 'Unexpected recovery error rolls back all live application state'
 Assert-Check ($script:patientNameControl.Text -ceq 'СОХРАНИТЬ ТЕКУЩЕГО' -and $script:hospitalControls.referred.Text -ceq 'СОХРАНИТЬ НАПРАВЛЕНИЕ') 'Unexpected recovery error rolls back widget text'
 Assert-Check ($script:admissionControl.Value -eq [datetime]'2026-10-20T15:00:00') 'Unexpected recovery error rolls back admission date'
 Set-Item Function:script:Restore-MedicalClinicalState $originalRestore
 [void](Restore-MedicalSessionBackup $sourceCheckpoint)
 # Persist an actual modified in-memory Word document plus provisional raw editor inputs.
 $draftPath=Join-Path $other 'editor-original.docx';New-UniversalTemplate $draftPath $script:universalConfig
 $draftSchema=Copy-UniversalObject $script:universalConfig;$model=Read-MedicalTemplateModel $draftPath
 $paragraph=@($model.Paragraphs|Where-Object {$_.Editable})[0]
 Set-MedicalTemplateParagraph $model $paragraph.Id 'НЕЗАВЕРШЁННЫЙ ТЕКСТ {{PATIENT_NAME}}'
 $draftSchema.Sections[0].Fields[1].Marker=$draftSchema.Sections[0].Fields[0].Marker
 $draftState=[pscustomobject]@{Schema=$draftSchema;Model=$model}
 $raw=[pscustomobject]@{FieldName='ЧАСТИЧНОЕ ИМЯ';FieldMarker='bad marker';ParagraphText='НЕЗАВЕРШЁННЫЙ ТЕКСТ {{PATIENT_NAME}}';SelectionStart=4;SelectedFieldId='patient_birth'}
 $script:stage='diary';$script:medicalActiveDiaryId=$second.Id
 function New-TestPrivateEditorDelegate {
  function Invoke-PrivateEditorCommit {$script:privateCommitCount++;return 'noise ignored'}
  $commands=@{Commit=Get-Command Invoke-PrivateEditorCommit -CommandType Function}
  return {$null=& $commands.Commit}.GetNewClosure()
 }
 $script:privateCommitCount=0;$commit=New-TestPrivateEditorDelegate;$captureControls={return $raw}.GetNewClosure()
 $token=Register-MedicalEditorDraft $draftSchema $model $draftState $commit $captureControls
 $draftCheckpoint=Write-MedicalSessionBackup
 Assert-Check ($script:privateCommitCount -gt 0) 'Private editor FunctionInfo delegate commits during checkpoint'
 Assert-Check ($null -eq (Get-Command Invoke-PrivateEditorCommit -ErrorAction SilentlyContinue)) 'Editor commit helper does not leak globally'
 $draft=$draftCheckpoint.Payload.Data.EditorDraft
 Assert-Check (-not $draft.SchemaIsComplete) 'Incomplete provisional schema retained as draft'
 Assert-Check ($draft.Controls.FieldMarker -ceq 'bad marker') 'Raw invalid marker input retained'
 Assert-Check ($draft.Controls.SelectionStart -eq 4) 'Caret state retained'
 Assert-Check ($draft.Stage -ceq 'diary' -and $draft.ClinicalId -ceq $second.Id) 'Draft binds correct clinical stage and diary'
 Assert-Check ($draft.Schema.Sections[0].Fields[1].Marker -ceq 'PATIENT_NAME') 'Provisional schema is not silently replaced'
 Assert-Check ($script:universalConfig.Sections[0].Fields[1].Marker -ceq 'PATIENT_BIRTH') 'Draft never mutates active schema'
 $script:medicalEditorRecoveryDraft=$draft
 $recovered=Get-MedicalRecoveredEditorDraft
 Assert-Check ($recovered.Controls.FieldMarker -ceq 'bad marker') 'Recovery returns raw unfinished controls'
 Assert-Check (@($recovered.Model.Paragraphs|Where-Object {$_.Text -ceq 'НЕЗАВЕРШЁННЫЙ ТЕКСТ {{PATIENT_NAME}}'}).Count -eq 1) 'Recovery returns actual modified Word XML'
 Assert-Check ($recovered.Schema.Sections[0].Fields[1].Marker -ceq 'PATIENT_NAME') 'Incomplete schema reopens only in editor'
 Assert-Check ($recovered.ClinicalId -ceq $second.Id) 'Draft recovery returns clinical identity'
 $data=Copy-MedicalBackupValue $draftCheckpoint.Payload.Data;$data.EditorDraft.Schema.Sections[1].Id=$data.EditorDraft.Schema.Sections[0].Id;Write-TestPayload $broken (Read-TestEnvelope $draftCheckpoint.Path) $data
 Assert-Reject {Restore-MedicalSessionBackup $broken} 'Structurally corrupted draft rejects before imports'
 $data=Copy-MedicalBackupValue $draftCheckpoint.Payload.Data;$data.EditorDraft.Sha256='0'*64;Write-TestPayload $broken (Read-TestEnvelope $draftCheckpoint.Path) $data
 Assert-Reject {Restore-MedicalSessionBackup $broken} 'Corrupted draft Word rejects before imports'
 Unregister-MedicalEditorDraft $token $false
 $cancelCheckpoint=Read-MedicalSessionBackup $script:medicalBackupPath
 Assert-Check ($null -eq $cancelCheckpoint.Payload.Data.EditorDraft) 'Cancel rewrites working checkpoint without canceled draft'
 $archives=@(Get-ChildItem -LiteralPath (Split-Path -Parent $script:medicalBackupPath) -Filter 'editor-draft-*.mcbak')
 Assert-Check ($archives.Count -eq 1) 'Cancel retains separate draft archive'
 Assert-Check ((Read-MedicalSessionBackup $archives[0].FullName).Payload.Data.EditorDraft.Controls.FieldMarker -ceq 'bad marker') 'Canceled draft archive preserves raw unfinished input'
 Assert-Check ($null -eq $script:medicalEditorRecoveryDraft) 'Canceled draft will not reopen automatically'
 $token=Register-MedicalEditorDraft $draftSchema $model $draftState $commit $captureControls
 Unregister-MedicalEditorDraft $token $true
 Assert-Check (@(Get-ChildItem -LiteralPath (Split-Path -Parent $script:medicalBackupPath) -Filter 'editor-draft-*.mcbak').Count -eq 1) 'Applied editor does not create canceled-draft archive'
 # Damaged current checkpoint uses previous valid copy; repairing preserves fallback.
 [IO.File]::WriteAllText($script:medicalBackupPath,'broken current checkpoint')
 $pending=Get-MedicalPendingBackup
 Assert-Check ($pending.Path -ceq ($script:medicalBackupPath+'.bak')) 'Recovery falls back to previous valid checkpoint'
 $oldBak=[IO.File]::ReadAllBytes($script:medicalBackupPath+'.bak')
 [void](Write-MedicalSessionBackup)
 Assert-Check ((Get-MedicalBackupBytesHash ([IO.File]::ReadAllBytes($script:medicalBackupPath+'.bak'))) -ceq (Get-MedicalBackupBytesHash $oldBak)) 'Repair damaged current does not overwrite valid fallback'
 Assert-Check ((Read-MedicalSessionBackup $script:medicalBackupPath).Closed -eq $false) 'NullString atomic replacement repairs damaged current'
 # Missing Word never stops patient answer checkpoints.
 $savedConfig=Copy-UniversalObject $script:universalConfig
 $script:universalConfig.AutoTemplate=$false;$script:universalConfig.Template='missing-source.docx'
 $definition=@($script:medicalClinicalForms.Diaries)[0];$definition.Schema.AutoTemplate=$false;$definition.Schema.Template='missing-diary.docx'
 $missing=Write-MedicalSessionBackup
 Assert-Check ($missing.Payload.Data.Record.universal.Values.patient_name -ceq 'ТЕСТ ПАЦИЕНТ') 'Missing Word source still checkpoints patient answers'
 Assert-Check ($missing.Payload.Data.ClinicalForms.Diaries[0].TemplateMissing -eq $true) 'Missing clinical source is explicitly recorded'
 Assert-Check ($missing.Payload.Data.Clinical.Diaries[0].Values.diary_complaints -ceq 'ПЕРВЫЙ ДНЕВНИК') 'Missing clinical Word still checkpoints diary answers'
 $script:universalConfig=$savedConfig;[void](Restore-MedicalSessionBackup $sourceCheckpoint)
 # Close actions operate on successful save marks, never merely a returned dialog.
 $script:stage='initial';$script:medicalActiveDiaryId=''
 Reset-MedicalBackupSaveBaselines $true $true
 $script:universalConfig.Sections[1].Title='НЕСОХРАНЁННЫЙ РАЗДЕЛ';$script:universalValues.complaints='НЕСОХРАНЁННЫЙ ОТВЕТ'
 $script:closeChoice='Cancel';Assert-Check (-not (Confirm-MedicalSessionClose $null)) 'Continue work cancels close'
 Assert-Check ($script:closeFlags[0] -and $script:closeFlags[1]) 'Close detects form and case independently'
 $script:closeChoice='Save';$script:formSaveMode='Cancel';$script:caseSaveMode='Success'
 Assert-Check (-not (Confirm-MedicalSessionClose $null)) 'Canceled form save prevents close'
 Assert-Check ($script:caseSaveCalls -eq 0) 'Canceled form save does not invoke card save'
 $script:formSaveMode='Throw';Assert-Check (-not (Confirm-MedicalSessionClose $null)) 'Failed form write prevents close'
 Assert-Check (-not (Read-MedicalSessionBackup $script:medicalBackupPath).Closed) 'Failed normal form write retains recovery checkpoint'
 $script:formSaveMode='Success';$script:caseSaveMode='Cancel'
 Assert-Check (-not (Confirm-MedicalSessionClose $null)) 'Canceled card save prevents close'
 Assert-Check ([IO.File]::Exists($script:activeMedicalFormPath)) 'Successful form save remains available after canceled card save'
 $script:caseSaveMode='Throw';Assert-Check (-not (Confirm-MedicalSessionClose $null)) 'Failed card write prevents close'
 Assert-Check (-not (Read-MedicalSessionBackup $script:medicalBackupPath).Closed) 'Failed normal card write retains recovery checkpoint'
 $script:caseSaveMode='Success'
 Assert-Check (Confirm-MedicalSessionClose $null) 'Successful form and card saves permit close'
 Assert-Check ((Read-MedicalSessionBackup $script:medicalBackupPath).Closed) 'Successful normal close marks checkpoint completed'
 Assert-Check ($null -eq (Get-MedicalPendingBackup)) 'Completed close does not offer stale recovery'
 $beforeCloseChoices=$script:closeChoiceCalls
 Assert-Check (Confirm-MedicalSessionClose $null) 'Clean state closes normally'
 Assert-Check ($script:closeChoiceCalls -eq $beforeCloseChoices) 'Clean state does not ask redundant save question'
 $script:universalValues.complaints='ПЕРЕД ВЫКЛЮЧЕНИЕМ'
 $beforeCloseChoices=$script:closeChoiceCalls
 Assert-Check (Confirm-MedicalSessionClose $null 'WindowsShutDown') 'System shutdown writes checkpoint without blocking shutdown'
 Assert-Check ($script:closeChoiceCalls -eq $beforeCloseChoices) 'System shutdown uses no interactive save dialog'
 Assert-Check (-not (Read-MedicalSessionBackup $script:medicalBackupPath).Closed) 'Shutdown checkpoint stays recoverable'
 $script:medicalBackupRetainedDraft=$draft;$script:closeChoice='Save';$beforeFormCalls=$script:formSaveCalls
 Assert-Check (-not (Confirm-MedicalSessionClose $null)) 'Unapplied recovered editor draft prevents ordinary-save close'
 Assert-Check ($script:formSaveCalls -eq $beforeFormCalls) 'Unapplied draft is never marked saved by active-form save'
 Assert-Check ((Read-MedicalSessionBackup $script:medicalBackupPath).Payload.Data.EditorDraft.Controls.FieldMarker -ceq 'bad marker') 'Unapplied recovered draft remains durably recoverable'
 $script:medicalBackupRetainedDraft=$null
 $script:closeChoice='Backup';Assert-Check (Confirm-MedicalSessionClose $null) 'Explicit close with backup permits close'
 Assert-Check ($null -ne (Get-MedicalPendingBackup)) 'Explicit backup close offers recovery next launch'
 $script:medicalBackupBusy=$true;$script:closeChoice='Save';Assert-Check (-not (Confirm-MedicalSessionClose $null)) 'Failed checkpoint prevents ordinary close'
 $script:medicalBackupBusy=$false
 [void](Initialize-MedicalSessionBackup $script:medicalProgramRoot);[void](Write-MedicalSessionBackup)
 $script:recoveryChoice='Later';Assert-Check ((Start-MedicalBackupRecovery $null) -ceq 'Later') 'Startup recovery can be deferred'
 Assert-Check ($script:medicalBackupPendingDeferred) 'Deferred pending work is protected'
 $pendingOriginal=Get-MedicalPendingBackup;$originalPayloadHash=Get-MedicalBackupHash $pendingOriginal.Payload
 $script:universalValues.complaints='НОВАЯ РАБОТА'
 [void](Write-MedicalSessionBackup)
 $deferredArchives=@(Get-ChildItem -LiteralPath (Split-Path -Parent $script:medicalBackupPath) -Filter 'session-*.mcbak')
 Assert-Check ($deferredArchives.Count -ge 1) 'New work archives deferred previous session'
 Assert-Check (@($deferredArchives|Where-Object {(Get-MedicalBackupHash (Read-MedicalSessionBackup $_.FullName).Payload) -ceq $originalPayloadHash}).Count -eq 1) 'Deferred previous session retains exact patient payload'
 Assert-Check (-not $script:medicalBackupPendingDeferred) 'Deferred archive flag clears after durable new checkpoint'
 $script:recoveryChoice='Restore';Assert-Check ((Start-MedicalBackupRecovery $null) -ceq 'Restored') 'Startup restores verified working session'
 Assert-Check ($script:universalValues.complaints -ceq 'НОВАЯ РАБОТА') 'Startup recovery returns current checkpoint patient answers'
 $script:recoveryChoice='New';Assert-Check ((Start-MedicalBackupRecovery $null) -ceq 'New') 'Startup can begin new work while retaining archives'
 Assert-Check (-not [IO.File]::Exists($script:medicalBackupPath)) 'Start new archives previous active recovery file'
 Assert-Check ((Start-MedicalBackupRecovery $null) -ceq 'New') 'No pending checkpoint returns normal form chooser'
 $script:medicalWorkspaceReady=$false;$beforeCapture=$script:captureCount
 Assert-Check ($null -eq (Write-MedicalSessionBackup)) 'No active workspace writes no empty checkpoint'
 Assert-Check ($script:captureCount -eq $beforeCapture) 'No workspace leaves data untouched'
 Assert-Check (Confirm-MedicalSessionClose $null) 'No workspace closes without save prompt'
 # New-form creation has no active workspace, but its modal editor is real work.
 $script:medicalWorkspaceReady=$true;$script:stage='diary';$script:medicalActiveDiaryId=$second.Id
 $token=Register-MedicalEditorDraft $draftSchema $model $draftState $commit $captureControls 'new'
 $creation=Write-MedicalSessionBackup
 Assert-Check ($creation.Payload.Data.EditorDraft.Purpose -ceq 'new') 'New-form draft records creation purpose'
 Assert-Check ($creation.Payload.Data.EditorDraft.Stage -ceq 'initial' -and -not $creation.Payload.Data.EditorDraft.ClinicalId) 'New form never inherits previously active diary binding'
 Assert-Check ($creation.Payload.Data.View.Stage -ceq 'diary' -and $creation.Payload.Data.View.ActiveDiaryId -ceq $second.Id) 'Creating new form preserves prior active patient context separately'
 $script:medicalEditorRecoveryDraft=$creation.Payload.Data.EditorDraft
 Assert-Check ((Get-MedicalRecoveredEditorDraft).Purpose -ceq 'new') 'Recovered new-form draft retains creation purpose'
 Unregister-MedicalEditorDraft $token $false
 Assert-Check ($script:medicalActiveDiaryId -ceq $second.Id -and $script:medicalWorkspaceReady) 'Canceling new form preserves existing active diary workspace'
 $script:medicalWorkspaceReady=$false;$script:stage='initial';$script:medicalActiveDiaryId=''
 $script:universalConfig=New-UniversalConfig;$script:universalValues=@{};$script:universalDetails=@{}
 $script:medicalClinicalForms=$null;$script:medicalClinicalState=$null;$script:stageData=@{};$script:stageTemplates=@{initial='';diary='';discharge=''}
 $script:activeMedicalFormPath='';$script:activeMedicalFormName='Новая форма';$script:caseFile='';$script:caseFolder='';$script:caseLastSavedPatientName=$null
 $script:medicalBackupFormSavedSignature='';$script:medicalBackupCaseSavedSignature=''
 $token=Register-MedicalEditorDraft $draftSchema $model $draftState $commit $captureControls 'new'
 $creation=Write-MedicalSessionBackup
 Assert-Check ($null -ne $creation -and [IO.File]::Exists($creation.Path)) 'Unapplied first form checkpoints without active workspace'
 Assert-Check (-not $creation.Payload.Data.WorkspaceReady) 'Creation checkpoint records no selected active form'
 Assert-Check ($creation.Payload.Data.EditorDraft.Controls.FieldMarker -ceq 'bad marker') 'First form checkpoint preserves unfinished raw editor inputs'
 Assert-Check (-not $creation.Payload.Data.Record.universal.Values.patient_name) 'First-form checkpoint contains no stale patient answer'
 $creationPath=Join-Path $temp 'creation-session.mcbak';[IO.File]::Copy($creation.Path,$creationPath)
 $script:closeChoice='Cancel';$script:closeChoiceCalls=0
 Assert-Check (-not (Confirm-MedicalSessionClose $null)) 'Unapplied first form receives closing confirmation'
 Assert-Check ($script:closeFlags[0] -and -not $script:closeFlags[1]) 'First-form close prompts only for form and template draft'
 $beforeCloseChoices=$script:closeChoiceCalls
 Assert-Check (Confirm-MedicalSessionClose $null 'WindowsShutDown') 'Shutdown checkpoints first-form creation without interactive dialog'
 Assert-Check ($script:closeChoiceCalls -eq $beforeCloseChoices) 'Shutdown of first-form editor uses no close-choice dialog'
 Unregister-MedicalEditorDraft $token $false $true
 Assert-Check ($null -eq $script:medicalBackupEditorDraft -and $null -ne $script:medicalBackupRetainedDraft) 'Shutdown retains editor model independently of disposed controls'
 $shutdownCreation=Get-MedicalPendingBackup
 Assert-Check ($shutdownCreation.Payload.Data.EditorDraft.Purpose -ceq 'new') 'Shutdown preserves first-form creation for automatic recovery'
 Assert-Check ($shutdownCreation.Payload.Data.EditorDraft.Controls.FieldMarker -ceq 'bad marker') 'Shutdown-retained draft preserves provisional input'
 [void](Restore-MedicalSessionBackup $shutdownCreation)
 Assert-Check (-not $script:medicalWorkspaceReady) 'Recovering first form does not install unfinished active form'
 $firstRecovered=Get-MedicalRecoveredEditorDraft
 Assert-Check ($firstRecovered.Purpose -ceq 'new' -and $firstRecovered.Stage -ceq 'initial') 'Recovering first form reopens primary form creation editor'
 Assert-Check (@($firstRecovered.Model.Paragraphs|Where-Object {$_.Text -ceq 'НЕЗАВЕРШЁННЫЙ ТЕКСТ {{PATIENT_NAME}}'}).Count -eq 1) 'First-form recovery restores complete modified Word model'
 $token=Register-MedicalEditorDraft $firstRecovered.Schema $firstRecovered.Model ([pscustomobject]@{Schema=$firstRecovered.Schema;Model=$firstRecovered.Model}) $commit $captureControls 'new'
 Unregister-MedicalEditorDraft $token $false
 Assert-Check ($null -eq (Get-MedicalPendingBackup)) 'Explicit cancel of first form removes automatic pending draft'
 Assert-Check (-not [IO.File]::Exists($script:medicalBackupPath) -and -not [IO.File]::Exists($script:medicalBackupPath+'.bak')) 'Canceled first-form working checkpoints archived instead of reopening'
 Assert-Check ($null -eq $script:medicalEditorRecoveryDraft -and $null -eq $script:medicalBackupRetainedDraft) 'Explicit first-form cancel clears retained recovery state'
 $creationArchives=@(Get-ChildItem -LiteralPath (Split-Path -Parent $script:medicalBackupPath) -Filter 'editor-draft-*.mcbak')
 Assert-Check (@($creationArchives|Where-Object {(Read-MedicalSessionBackup $_.FullName).Payload.Data.EditorDraft.Purpose -ceq 'new'}).Count -ge 2) 'Canceled first-form work remains available in separate draft archives'
 Assert-Check ($null -eq (Write-MedicalSessionBackup)) 'Empty workspace after canceled creation writes no empty replacement'
 Assert-Check (Confirm-MedicalSessionClose $null) 'Empty workspace after canceled creation closes without prompting'

 # Execute the actual constructor event registrations against event-capable widgets.
 # Native rendering is unavailable here; handlers and their command calls are real.
 Add-Type -CompilerOptions /langversion:5 -TypeDefinition @'
using System;
public sealed class BackupClosingEventArgs:EventArgs {public string CloseReason{get;set;}public bool Cancel{get;set;}}
public sealed class BackupTestOwner {
 public event EventHandler<BackupClosingEventArgs> FormClosing;
 public event EventHandler FormClosed;
 public event EventHandler Shown;
 public BackupClosingEventArgs RaiseClosing(string reason){var e=new BackupClosingEventArgs{CloseReason=reason};if(FormClosing!=null)FormClosing(this,e);return e;}
 public void RaiseClosed(){if(FormClosed!=null)FormClosed(this,EventArgs.Empty);}
 public void RaiseShown(){if(Shown!=null)Shown(this,EventArgs.Empty);}
}
namespace System.Windows.Forms {
 public sealed class Timer {
  public int Interval{get;set;}public int Starts{get;private set;}public int Stops{get;private set;}public bool Disposed{get;private set;}
  public event EventHandler Tick;
  public void Start(){Starts++;}public void Stop(){Stops++;}public void Dispose(){Disposed=true;}
  public void RaiseTick(){if(Tick!=null)Tick(this,EventArgs.Empty);}
 }
}
'@
 function Get-TestConstructorCall($ast,[string]$variable,[string]$member,[string]$containsVariable=''){
  $found=@($ast.FindAll({param($node)
   if($node -isnot [Management.Automation.Language.InvokeMemberExpressionAst] -or $node.Expression.Extent.Text -cne $variable -or $node.Member.Value -cne $member){return $false}
   if(-not $containsVariable){return $true}
   return ($null -ne $node.Find({param($inner)$inner -is [Management.Automation.Language.VariableExpressionAst] -and $inner.Extent.Text -ceq $containsVariable},$true))
  },$false))
  if($found.Count -ne 1){throw ('Expected one actual constructor registration: '+$variable+'.'+$member)}
  return $found[0]
 }
 $tokens=$null;$errors=$null;$constructorAst=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'constructor.ps1'),[ref]$tokens,[ref]$errors)
 Assert-Check ($errors.Count -eq 0) 'Constructor with backup hooks parses'
 $timerAssignment=@($constructorAst.FindAll({param($node)$node -is [Management.Automation.Language.AssignmentStatementAst] -and $node.Left.Extent.Text -ceq '$script:medicalBackupTimer'},$false))
 $intervalAssignment=@($constructorAst.FindAll({param($node)$node -is [Management.Automation.Language.AssignmentStatementAst] -and $node.Left.Extent.Text -ceq '$script:medicalBackupTimer.Interval'},$false))
 if($timerAssignment.Count -ne 1 -or $intervalAssignment.Count -ne 1){throw 'Missing concrete backup timer construction'}
 . ([scriptblock]::Create($timerAssignment[0].Extent.Text))
 . ([scriptblock]::Create($intervalAssignment[0].Extent.Text))
 $form=New-Object BackupTestOwner
 foreach($registration in @(
  (Get-TestConstructorCall $constructorAst '$script:medicalBackupTimer' 'Add_Tick'),
  (Get-TestConstructorCall $constructorAst '$form' 'Add_FormClosing'),
  (Get-TestConstructorCall $constructorAst '$form' 'Add_FormClosed' '$script:medicalBackupTimer'),
  (Get-TestConstructorCall $constructorAst '$form' 'Add_Shown')
 )){. ([scriptblock]::Create($registration.Extent.Text))}
 Assert-Check ($script:medicalBackupTimer.Interval -eq 25000) 'Actual backup timer checkpoints every 25 seconds'
 $script:hookTrace=New-Object Collections.ArrayList;$script:hookWrites=0;$script:hookWriteThrows=$false;$script:hookClosePermit=$false
 function script:Write-MedicalSessionBackup([bool]$closed=$false){$script:hookWrites++;if($script:hookWriteThrows){throw 'TEST periodic write failure'}}
 function script:Confirm-MedicalSessionClose($owner,[string]$reason){$script:hookCloseOwner=$owner;$script:hookCloseReason=$reason;return $script:hookClosePermit}
 function script:Start-MedicalBackupRecovery($owner){
  [void]$script:hookTrace.Add('Recovery');$script:hookRecoveryOwner=$owner
  if($script:hookRecoveryChoice -eq 'Restored'){
   $script:medicalWorkspaceReady=(-not $script:hookRecoverCreation);$script:stage=if($script:hookRecoverCreation){'initial'}else{'diary'};$script:medicalActiveDiaryId=if($script:hookRecoverCreation){''}else{$script:hookRecoveredDiaryId}
   $script:medicalEditorRecoveryDraft=if($script:hookRecoverEditor){[pscustomobject]@{Stage='diary';ClinicalId=$script:hookRecoveredDiaryId}}else{$null}
  }
  return $script:hookRecoveryChoice
 }
 function script:Open-Stage {[void]$script:hookTrace.Add('OpenStage');$script:hookOpenedStage=$script:stage;$script:hookOpenedDiaryId=$script:medicalActiveDiaryId}
 function script:Invoke-MedicalRestoreEditorDraft {[void]$script:hookTrace.Add('EditorDraft');$script:hookEditorDiaryId=$script:medicalActiveDiaryId}
 function script:Start-MedicalFormsWorkspace {[void]$script:hookTrace.Add('FormChooser');$script:medicalWorkspaceReady=$true;$script:stage='initial';$script:medicalActiveDiaryId=''}
 function script:Clear-MedicalFormsWorkspace {[void]$script:hookTrace.Add('ClearWorkspace');$script:medicalWorkspaceReady=$false;$script:medicalActiveDiaryId=''}
 function script:Set-DarkTheme($owner){[void]$script:hookTrace.Add('Theme')}
 function script:Update-UniversalCompletion {[void]$script:hookTrace.Add('Completion')}
 function script:Update-MedicalNavigation {[void]$script:hookTrace.Add('Navigation')}
 function script:Resize-UniversalForm {[void]$script:hookTrace.Add('Resize')}
 function script:Request-MedicalClinicalCheckpoint {[void]$script:hookTrace.Add('ClinicalCheckpoint')}
 $script:medicalWorkspaceReady=$true;$script:medicalBackupBusy=$false;$script:uiMedicalFormStatus=[pscustomobject]@{Text='Форма: ТЕСТ'}
 $script:medicalBackupTimer.RaiseTick()
 Assert-Check ($script:hookWrites -eq 1) 'Actual timer handler checkpoints ready workspace'
 $script:medicalBackupBusy=$true;$script:medicalBackupTimer.RaiseTick()
 Assert-Check ($script:hookWrites -eq 1) 'Actual timer handler skips concurrent backup'
 $script:medicalBackupBusy=$false;$script:medicalWorkspaceReady=$false;$script:medicalBackupTimer.RaiseTick()
 Assert-Check ($script:hookWrites -eq 1) 'Actual timer handler skips unopened workspace'
 $script:medicalBackupEditorDraft=[pscustomobject]@{Purpose='new'};$script:medicalBackupTimer.RaiseTick()
 Assert-Check ($script:hookWrites -eq 2) 'Actual timer checkpoints first-form creation without selected workspace'
 $script:medicalBackupEditorDraft=$null;$script:medicalBackupRetainedDraft=[pscustomobject]@{Purpose='new'};$script:medicalBackupTimer.RaiseTick()
 Assert-Check ($script:hookWrites -eq 3) 'Actual timer checkpoints retained shutdown draft without selected workspace'
 $script:medicalBackupRetainedDraft=$null
 $script:medicalWorkspaceReady=$true;$script:hookWriteThrows=$true;$script:medicalBackupTimer.RaiseTick()
 Assert-Check ($script:hookWrites -eq 4) 'Actual timer attempts periodic save after previous capture'
 Assert-Check ($script:uiMedicalFormStatus.Text.Contains('TEST periodic write failure')) 'Actual periodic save failure appears in form status'
 $script:uiMedicalFormStatus=$null;$script:medicalBackupTimer.RaiseTick()
 Assert-Check ($script:hookWrites -eq 5) 'Periodic failure without status control does not crash event'
 $script:hookWriteThrows=$false;$script:medicalBackupTimer.RaiseTick()
 Assert-Check ($script:hookWrites -eq 6) 'Actual periodic handler continues after a failed backup'
 $closing=$form.RaiseClosing('UserClosing')
 Assert-Check ($closing.Cancel) 'Actual FormClosing honors canceled close decision'
 Assert-Check ([object]::ReferenceEquals($script:hookCloseOwner,$form)) 'Actual FormClosing passes window owner to save flow'
 Assert-Check ($script:hookCloseReason -ceq 'UserClosing') 'Actual FormClosing passes exact user close reason'
 $script:hookClosePermit=$true;$closing=$form.RaiseClosing('WindowsShutDown')
 Assert-Check (-not $closing.Cancel) 'Actual FormClosing honors successful shutdown checkpoint'
 Assert-Check ($script:hookCloseReason -ceq 'WindowsShutDown') 'Actual FormClosing passes Windows shutdown reason'
 $closing=$form.RaiseClosing('TaskManagerClosing')
 Assert-Check ($script:hookCloseReason -ceq 'TaskManagerClosing') 'Actual FormClosing passes task-manager close reason'
 $stageInitial=[pscustomobject]@{Enabled=$false};$stageDiary=[pscustomobject]@{Enabled=$false};$stageDischarge=[pscustomobject]@{Enabled=$false}
 $panel=[pscustomobject]@{BackColor=$null;AutoScrollPosition=$null};$script:darkBg='TEST DARK';$script:universalFlow=[pscustomobject]@{IsDisposed=$false;BackColor=$null}
 $script:templateTimer=New-Object System.Windows.Forms.Timer
 $script:hookRecoverCreation=$false
 $script:hookRecoveryChoice='Restored';$script:hookRecoveredDiaryId='second-stable-diary';$script:hookRecoverEditor=$true
 $script:medicalWorkspaceReady=$false;$script:medicalEditorRecoveryDraft=$null;$script:hookTrace.Clear()
 $form.RaiseShown()
 Assert-Check ($script:medicalBackupTimer.Starts -eq 1) 'Actual Shown handler starts backup timer'
 Assert-Check ([object]::ReferenceEquals($script:hookRecoveryOwner,$form)) 'Actual Shown handler passes owner to recovery dialog'
 Assert-Check ($script:hookOpenedStage -ceq 'diary' -and $script:hookOpenedDiaryId -ceq 'second-stable-diary') 'Actual recovery displays saved diary stage and identity'
 Assert-Check ($stageInitial.Enabled -and $stageDiary.Enabled -and $stageDischarge.Enabled) 'Actual recovery enables all stage navigation'
 Assert-Check ($script:hookEditorDiaryId -ceq 'second-stable-diary') 'Actual recovery reopens draft in correct diary context'
 Assert-Check ($script:hookTrace.IndexOf('OpenStage') -lt $script:hookTrace.IndexOf('EditorDraft')) 'Actual draft recovery occurs after stage UI restoration'
 Assert-Check (-not $script:hookTrace.Contains('FormChooser') -and -not $script:hookTrace.Contains('ClearWorkspace')) 'Restored startup keeps recovered workspace'
 Assert-Check ($script:hookTrace.Contains('ClinicalCheckpoint')) 'Restored startup takes checkpoint after workspace is ready'
 Assert-Check ($panel.BackColor -ceq 'TEST DARK' -and $script:universalFlow.BackColor -ceq 'TEST DARK') 'Actual startup restores stage background colors'
 Assert-Check ($panel.AutoScrollPosition.X -eq 0 -and $panel.AutoScrollPosition.Y -eq 0) 'Actual startup scroll begins at top of restored form'
 Assert-Check ($script:templateTimer.Starts -eq 1) 'Actual startup retains document template timer'
 $script:hookRecoverEditor=$false;$script:hookTrace.Clear();$form.RaiseShown()
 Assert-Check (-not $script:hookTrace.Contains('EditorDraft')) 'Actual recovery without unfinished editor opens no draft'
 $script:hookRecoverCreation=$true;$script:hookRecoverEditor=$true;$script:hookTrace.Clear();$form.RaiseShown()
 Assert-Check ($script:hookTrace.Contains('ClearWorkspace') -and -not $script:hookTrace.Contains('OpenStage')) 'Actual first-form recovery keeps active workspace empty'
 Assert-Check ($script:hookTrace.Contains('EditorDraft')) 'Actual first-form recovery reopens creation draft after clearing workspace'
 Assert-Check ($script:hookTrace.IndexOf('ClearWorkspace') -lt $script:hookTrace.IndexOf('EditorDraft')) 'Actual first-form recovery establishes empty UI before opening draft'
 Assert-Check (-not $script:hookTrace.Contains('ClinicalCheckpoint')) 'Actual first-form recovery does not checkpoint an unapplied active form'
 $script:hookRecoverCreation=$false
 $script:hookRecoveryChoice='New';$script:medicalEditorRecoveryDraft=$null;$script:hookTrace.Clear();$form.RaiseShown()
 Assert-Check ($script:hookTrace.Contains('FormChooser')) 'Actual new startup opens form chooser'
 Assert-Check (-not $script:hookTrace.Contains('OpenStage') -and -not $script:hookTrace.Contains('EditorDraft')) 'Actual new startup does not reopen old stage or draft'
 Assert-Check ($script:hookTrace.Contains('ClinicalCheckpoint')) 'New chosen form receives its initial checkpoint'
 $script:hookRecoveryChoice='Later';$script:hookTrace.Clear();$form.RaiseShown()
 Assert-Check ($script:hookTrace.Contains('ClearWorkspace')) 'Actual defer recovery leaves workspace empty'
 Assert-Check (-not $script:medicalWorkspaceReady) 'Actual defer recovery prevents data-entry before form selection'
 Assert-Check (-not $script:hookTrace.Contains('FormChooser') -and -not $script:hookTrace.Contains('OpenStage')) 'Actual defer choice preserves pending session without opening form'
 Assert-Check (-not $script:hookTrace.Contains('ClinicalCheckpoint')) 'Actual defer startup never overwrites pending recovery'
 $form.RaiseClosed()
 Assert-Check ($script:medicalBackupTimer.Stops -eq 1 -and $script:medicalBackupTimer.Disposed) 'Actual FormClosed stops and disposes backup timer'

 Write-Output ('CHECKS '+$script:checks)
}finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Recurse -Force}}
