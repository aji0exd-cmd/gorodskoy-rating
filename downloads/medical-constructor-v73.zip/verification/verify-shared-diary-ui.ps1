﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v73'))
$ErrorActionPreference='Stop'
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-shared-diary-ui-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
$child=Join-Path $temp 'private-shared-diary-ui.ps1'
try{
 # Reuse the WinForms event/layout adapters from the broad clinical UI suite.
 # The appended scenarios invoke production builders and their actual delegates.
 $tokens=$null;$errors=$null
 $ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot 'verify-clinical-ui.ps1'),[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors|Out-String)}
 $assignment=$ast.Find({param($n)$n -is [Management.Automation.Language.AssignmentStatementAst] -and $n.Left.Extent.Text -eq '$childSource'},$true)
 $source=[string]$assignment.Right.Expression.Value
 $stop=$source.IndexOf('$initialFingerprint=')
 if($stop -lt 0){throw 'Clinical UI adapter boundary was not found.'}
 $source=$source.Substring(0,$stop)
 $source=[regex]::Replace($source,'public static class MessageBox \{public static string Response="Yes";[^\r\n]*\}','public static class MessageBox {public static string Response="Yes";public static string LastMessage="";public static object[] LastArguments;public static int Calls;public static string Show(params object[] args){LastArguments=args;LastMessage=args.Length>1 ? Convert.ToString(args[1]) : "";Calls++;return Response;}}')
 $source+=@'
. (Join-Path $Project 'diary-period-v69.ps1')
$script:checkpointCount=0;$script:renderCacheClears=0;$script:sharedEditorCalls=0
function Request-MedicalClinicalCheckpoint {$script:checkpointCount++}
function Clear-MedicalHospitalizationRenderCache {$script:renderCacheClears++}
function Invoke-MedicalFormTemplateEditor {$script:sharedEditorCalls++;$script:receivedSharedSchema=Get-MedicalActiveSchemaForEditor}
# Distinct clinical field IDs model a reusable diary independent from the initial
# examination. Patient identity roles intentionally link to the same patient.
$diarySchema=Copy-MedicalFormSchema $script:universalConfig
foreach($field in Get-UniversalFields $script:universalConfig){if(-not $field.System){$old=[string]$field.Id;$field.Id='initial_'+$old;if($script:universalValues.ContainsKey($old)){$script:universalValues[[string]$field.Id]=$script:universalValues[$old];$script:universalValues.Remove($old)};if($script:universalDetails.ContainsKey($old)){$script:universalDetails[[string]$field.Id]=$script:universalDetails[$old];$script:universalDetails.Remove($old)}}}
function Get-SharedClinicalAnswerCount($context){return @($context.Values.GetEnumerator()|Where-Object {$_.Key -notin @('name','birth','address') -and -not [string]::IsNullOrWhiteSpace([string]$_.Value)}).Count}
[void](Initialize-MedicalClinicalWorkspace)
[void](Set-MedicalSharedDiarySchema $diarySchema)
$sharedInitial=Get-ClinicalFingerprint (Get-MedicalSharedDiarySchema)
$initialValues=Get-ClinicalFingerprint $script:universalValues
Assert-Clinical (@($script:medicalClinicalForms.Diaries).Count -eq 0) 'A shared diary form exists independently from patient records'
Assert-Clinical ((Get-ClinicalFingerprint (Get-MedicalActiveSchemaForEditor)) -ceq $sharedInitial) 'Common editor schema is available on the empty diary page'
Open-MedicalClinicalStage
$commands=@(Get-ClinicalDescendants $script:medicalClinicalFlow | Where-Object {$_.Text -ceq 'Форма дневников'})
Assert-Clinical ($commands.Count -eq 1 -and $script:medicalClinicalBindings.Count -eq 0) 'Empty Diary page renders exactly one shared form command'
Assert-Clinical (@(Get-ClinicalDescendants $script:medicalClinicalFlow | Where-Object {$_.Text -ceq 'Форма этого дневника' -or $_.Text -ceq 'Удалить дневник'}).Count -eq 0) 'Empty diary page has no record editor or delete buttons'
$commands[0].RaiseClick()
Assert-Clinical ($script:sharedEditorCalls -eq 1 -and (Get-ClinicalFingerprint $script:receivedSharedSchema) -ceq $sharedInitial) 'Actual shared form button opens the common editor before adding a diary'
Assert-Clinical ($newDiary.Parent -eq $script:medicalClinicalFlow -and $script:medicalClinicalFlow.Controls.IndexOf($newDiary) -gt $script:medicalClinicalFlow.Controls.IndexOf($commands[0])) 'Add button sits below shared form settings on the empty page'
$newDiary.RaiseClick();$firstId=$script:medicalActiveDiaryId;$first=Get-MedicalClinicalContext 'diary' $firstId
Assert-Clinical ($script:medicalClinicalBindings.Count -eq 1 -and @($script:medicalClinicalForms.Diaries).Count -eq 1) 'Actual Add button creates exactly one diary structure'
Assert-Clinical ((Get-ClinicalFingerprint $first.Schema) -ceq $sharedInitial) 'First new diary uses the reusable common schema'
Assert-Clinical ($first.Values.name -ceq $script:universalValues.name -and $first.Values.birth -ceq $script:universalValues.birth -and $first.Values.address -ceq $script:universalValues.address) 'New diary retains editable identity links for the current patient'
Assert-Clinical ((Get-SharedClinicalAnswerCount $first) -eq 0 -and @($first.Details.Values | Where-Object {-not [string]::IsNullOrWhiteSpace([string]$_)}).Count -eq 0) 'First diary clinical answers and clarifications start blank despite filled initial examination'
$a=$script:medicalClinicalBindings[$firstId];$a.Inputs.complaints.Text='Ответы первого дневника';$a.Inputs.choice.SelectedItem='Первый';$a.DetailInputs.choice.Text='Уточнение первого';$a.Inputs.name.Text='Только первый'
$a.DiaryModeControl.SelectedIndex=1;$a.DateControl.Value=[datetime]'2026-10-15T09:30:00';$a.DiaryEndControl.Value=[datetime]'2026-10-17T10:45:00'
$newDiary.RaiseClick();$secondId=$script:medicalActiveDiaryId;$second=Get-MedicalClinicalContext 'diary' $secondId
Assert-Clinical ($firstId -cne $secondId -and $script:medicalClinicalBindings.Count -eq 2) 'Each Add event appends one record with a distinct stable ID'
Assert-Clinical ((Get-ClinicalFingerprint $second.Schema) -ceq $sharedInitial -and (Get-SharedClinicalAnswerCount $second) -eq 0) 'Second diary reuses the common structure with blank independent answers'
Assert-Clinical ((Get-MedicalClinicalContext 'diary' $firstId).Values.complaints -ceq 'Ответы первого дневника' -and (Get-MedicalClinicalContext 'diary' $firstId).Details.choice -ceq 'Уточнение первого') 'Adding a new blank diary preserves filled earlier answers and clarifications'
Assert-Clinical ((Get-MedicalClinicalContext 'diary' $firstId).DateCount -eq 2 -and (Get-MedicalClinicalContext 'diary' $firstId).EndDateTime -eq [datetime]'2026-10-17T10:45:00') 'Shared structure keeps the existing diary inspection period independently'
$all=@(Get-ClinicalDescendants $script:medicalClinicalFlow);$shared=@($all|Where-Object {$_.Name -ceq 'sharedDiaryEditor'});$deletes=@($all|Where-Object {$_.Name -ceq 'removeDiary'})
Assert-Clinical ($shared.Count -eq 1 -and $deletes.Count -eq 2 -and @($all|Where-Object {$_.Text -ceq 'Форма этого дневника'}).Count -eq 0) 'Two diaries expose one common editor and one Delete button per record'
$workChildren=@($script:medicalClinicalFlow.Controls);$lastRecord=[Array]::FindLastIndex($workChildren,[Predicate[object]]{param($n)$n -is [MedicalOutlineTable]})
Assert-Clinical ($script:medicalClinicalFlow.Controls.IndexOf($newDiary) -gt $lastRecord) 'Add Diary moves below the final visible record'
$b=$script:medicalClinicalBindings[$secondId];$b.DiaryModeControl.SelectedIndex=0;$b.Inputs.complaints.Text='Ответы второго дневника';$b.DetailInputs.choice.Text='Уточнение второго'
$b.DateControl.Text='неверная дата'
$checksBefore=$script:checkpointCount;$clearBeforeError=$script:renderCacheClears
$failedDelete=@($deletes|Where-Object {$_.Tag.Id -ceq $firstId})[0];$failedDelete.RaiseClick()
Assert-Clinical (@($script:medicalClinicalForms.Diaries).Count -eq 2 -and $script:checkpointCount -eq $checksBefore -and $script:renderCacheClears -eq $clearBeforeError -and [Windows.Forms.MessageBox]::LastArguments[2] -ceq 'Удаление дневника') 'Invalid uncommitted date aborts deletion safely and reports the capture error'
$b.DateControl.Text='20.10.2026 12:34'
$oldFlow=$script:medicalClinicalFlow;$checkpointBefore=$script:checkpointCount;$clearBefore=$script:renderCacheClears
[Windows.Forms.MessageBox]::Response='No'
$firstDelete=@($deletes|Where-Object {$_.Tag.Id -ceq $firstId})[0];$firstDelete.RaiseClick()
Assert-Clinical (@($script:medicalClinicalForms.Diaries).Count -eq 2 -and [object]::ReferenceEquals($oldFlow,$script:medicalClinicalFlow)) 'Cancelling Delete retains every record and does not rebuild controls'
Assert-Clinical ((Get-MedicalClinicalContext 'diary' $secondId).DateTime -eq [datetime]'2026-10-20T12:34:00' -and (Get-MedicalClinicalContext 'diary' $secondId).Values.complaints -ceq 'Ответы второго дневника') 'Delete captures unsaved date text and answers in all records before asking'
Assert-Clinical ($script:checkpointCount -eq $checkpointBefore -and $script:renderCacheClears -eq $clearBefore) 'Cancelled deletion does not checkpoint or invalidate the current render'
$prompt=[string][Windows.Forms.MessageBox]::LastArguments[1]
Assert-Clinical ($prompt.Contains('№1') -and $prompt.Contains('В нём есть заполненные ответы') -and [Windows.Forms.MessageBox]::LastArguments[5] -ceq 'Button2') 'Deletion prompt identifies the chosen record, warns about filled answers and defaults to No'
[Windows.Forms.MessageBox]::Response='Yes';$firstDelete.RaiseClick()
Assert-Clinical (@($script:medicalClinicalForms.Diaries).Count -eq 1 -and [string]$script:medicalClinicalForms.Diaries[0].Id -ceq $secondId -and -not $script:medicalClinicalBindings.ContainsKey($firstId)) 'Confirmed Delete removes only its owning diary state and rendered record'
Assert-Clinical ($script:medicalActiveDiaryId -ceq $secondId -and $script:medicalClinicalBindings[$secondId].Inputs.complaints.Text -ceq 'Ответы второго дневника' -and $script:medicalClinicalBindings[$secondId].DetailInputs.choice.Text -ceq 'Уточнение второго') 'Deletion selects the nearest surviving diary and preserves its answers'
Assert-Clinical ($script:checkpointCount -eq ($checkpointBefore+1) -and $script:renderCacheClears -eq ($clearBefore+1)) 'Confirmed deletion invalidates combined Word output and requests a backup checkpoint'
$firstDelete.RaiseClick()
Assert-Clinical (@($script:medicalClinicalForms.Diaries).Count -eq 1 -and $script:checkpointCount -eq ($checkpointBefore+1)) 'A disposed stale Delete button cannot remove another entry'
$secondDelete=@(Get-ClinicalDescendants $script:medicalClinicalFlow|Where-Object {$_.Name -ceq 'removeDiary'})[0];$secondDelete.RaiseClick()
Assert-Clinical (@($script:medicalClinicalForms.Diaries).Count -eq 0 -and $script:medicalClinicalBindings.Count -eq 0 -and $script:medicalActiveDiaryId -ceq '') 'Deleting the last diary leaves an empty page with no stale active record'
Assert-Clinical ((Get-ClinicalFingerprint (Get-MedicalSharedDiarySchema)) -ceq $sharedInitial -and @(Get-ClinicalDescendants $script:medicalClinicalFlow|Where-Object {$_.Name -ceq 'sharedDiaryEditor'}).Count -eq 1) 'Deleting the final record retains the common diary form and its editor'
$newDiary.RaiseClick();$replacementId=$script:medicalActiveDiaryId
Assert-Clinical ($replacementId -cne $firstId -and $replacementId -cne $secondId -and $script:medicalClinicalBindings.Count -eq 1 -and (Get-ClinicalFingerprint (Get-MedicalClinicalContext 'diary' $replacementId).Schema) -ceq $sharedInitial) 'Adding after last deletion restores the saved common structure with a new stable ID'
Assert-Clinical ((Get-SharedClinicalAnswerCount (Get-MedicalClinicalContext 'diary' $replacementId)) -eq 0) 'Recreated diary never resurrects deleted patient answers'
# Legacy answers outside the new common form remain visible and copyable.
$legacy=Get-MedicalClinicalContext 'diary' $replacementId
$legacy | Add-Member -NotePropertyName ArchivedFields -NotePropertyValue @([pscustomobject]@{FieldId='old';Label='Старое поле';Value='Сохранённый ответ';Detail='Сохранённое уточнение'}) -Force
$legacyPanel=New-MedicalClinicalRecordPanel $legacy 'diary'
$archive=@(Get-ClinicalDescendants $legacyPanel|Where-Object {$_.Name -ceq 'archivedDiaryFields'})
Assert-Clinical ($archive.Count -eq 1 -and $archive[0].ReadOnly -and $archive[0].Enabled -and $archive[0].Text.Contains('Сохранённый ответ') -and $archive[0].Text.Contains('Сохранённое уточнение')) 'Unmatched legacy answers are displayed read-only with copyable values and details'
Assert-Clinical (-not $script:medicalClinicalBindings[$replacementId].Inputs.ContainsKey('old')) 'Legacy archive controls never become editable current-form bindings'
Open-MedicalClinicalStage
$baselineHeight=$panel.ContentHeight;$baselineCount=$script:medicalClinicalFlow.Controls.Count
for($i=0;$i -lt 4;$i++){Open-MedicalClinicalStage;Assert-Clinical ($panel.ContentHeight -eq $baselineHeight -and $script:medicalClinicalFlow.Controls.Count -eq $baselineCount -and @(Get-ClinicalDescendants $script:medicalClinicalFlow|Where-Object {$_.Name -ceq 'sharedDiaryEditor'}).Count -eq 1) ('Rebuild '+($i+1)+' keeps stable geometry and exactly one common editor')}
$script:stage='discharge';Open-MedicalClinicalStage
Assert-Clinical (@(Get-ClinicalDescendants $script:medicalClinicalFlow|Where-Object {$_.Text -ceq 'Форма эпикриза'}).Count -eq 1 -and @(Get-ClinicalDescendants $script:medicalClinicalFlow|Where-Object {$_.Name -ceq 'sharedDiaryEditor' -or $_.Name -ceq 'removeDiary'}).Count -eq 0) 'Discharge retains its own editor without diary-only commands'
$editorCalls=$script:sharedEditorCalls;Invoke-MedicalSharedDiaryEditor;Invoke-MedicalRemoveDiary $replacementId
Assert-Clinical ($script:sharedEditorCalls -eq $editorCalls -and @($script:medicalClinicalForms.Diaries).Count -eq 1) 'Diary-only editor and deletion commands do nothing outside the diary stage'
$script:stage='diary';$script:medicalWorkspaceReady=$false;Invoke-MedicalSharedDiaryEditor;Invoke-MedicalRemoveDiary $replacementId
Assert-Clinical ($script:sharedEditorCalls -eq $editorCalls -and @($script:medicalClinicalForms.Diaries).Count -eq 1) 'Shared editor and deletion guard an unavailable workspace'
$script:medicalWorkspaceReady=$true
Assert-Clinical ((Get-ClinicalFingerprint $script:universalValues) -ceq $initialValues) 'Common diary operations leave primary examination patient answers unchanged'
Write-Output ('SHARED DIARY UI CHECKS PASSED: '+$script:checks)
'@
 [IO.File]::WriteAllText($child,$source,(New-Object Text.UTF8Encoding($true)))
 & (Join-Path $PSHOME $(if($env:OS -eq 'Windows_NT'){'powershell.exe'}else{'pwsh'})) -NoLogo -NoProfile -File $child -Project $Project -TestRoot $temp
 if($LASTEXITCODE -ne 0){throw 'Shared diary UI verification failed.'}
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
