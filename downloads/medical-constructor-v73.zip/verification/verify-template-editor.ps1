﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v73'))
$ErrorActionPreference='Stop'
$script:checks=0
function Assert-EditorCheck([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
function Assert-EditorRejected([scriptblock]$operation,[string]$message){$rejected=$false;try{& $operation}catch{$rejected=$true};Assert-EditorCheck $rejected $message}
function Import-EditorTestFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors | Out-String)}
 foreach($node in $ast.FindAll({param($item) $item -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
  if($names.Count -eq 0 -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}
 }
}
function Set-EditorTestPart([string]$path,[string]$name,[byte[]]$bytes){
 $zip=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{$entry=$zip.GetEntry($name);if($entry){$entry.Delete()};$entry=$zip.CreateEntry($name);$stream=$entry.Open();try{$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}}
 finally{$zip.Dispose()}
}
function Set-EditorTestXml([string]$path,[string]$name,[string]$text){Set-EditorTestPart $path $name ([Text.Encoding]::UTF8.GetBytes($text))}
function Get-EditorPartHash($model,[string]$name){$entry=@($model.Entries | Where-Object {$_.Name -ceq $name})[0];return (Get-MedicalBytesSha256 $entry.Bytes)}
function Find-EditorParagraph($model,[string]$text,[string]$part='word/document.xml'){
 $matches=@($model.Paragraphs | Where-Object {$_.Part -ceq $part -and $_.Text -ceq $text})
 if($matches.Count -ne 1){throw ('Expected one paragraph: '+$text)};return $matches[0]
}
function New-EditorTestConfig {
 $choice=New-UniversalField 'choice' 'Выбор' 'CHOICE' 'choice_detail'
 $choice.Options=@('Первый','Второй');$choice.WordId='42'
 $choice | Add-Member -NotePropertyName DetailFormPosition -NotePropertyValue 'right'
 $choice | Add-Member -NotePropertyName DetailWordPosition -NotePropertyValue 'marker'
 $choice | Add-Member -NotePropertyName DetailMarker -NotePropertyValue 'CHOICE_DETAIL'
 return [pscustomobject]@{Version=49;AutoTemplate=$false;Template='';Sections=@([pscustomobject]@{Id='test';Title='Раздел';Fields=@((New-UniversalField 'text' 'Текст' 'TEXT'),$choice)})}
}
function New-EditorTestTemplate([string]$path,$config){
 New-UniversalTemplate $path $config
 $ns=$script:ns
 $document='<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="'+$ns+'" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><w:body>'+
 '<w:p><w:r><w:t>{{ADMISSION_DATETIME}}</w:t></w:r></w:p>'+
 '<w:p w:rsidR="12345678"><w:pPr><w:pStyle w:val="Heading1"/><w:spacing w:after="240"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="123456"/><w:rFonts w:ascii="Times New Roman"/></w:rPr><w:t>{{TE</w:t></w:r><w:r><w:rPr><w:i/></w:rPr><w:t>XT}}</w:t></w:r></w:p>'+
 '<w:tbl><w:tblPr><w:tblW w:w="9000" w:type="dxa"/></w:tblPr><w:tblGrid><w:gridCol w:w="4500"/><w:gridCol w:w="4500"/></w:tblGrid><w:tr><w:tc><w:tcPr><w:tcW w:w="4500" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>{{CHOICE_DETAIL}}</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Таблица 2</w:t></w:r></w:p></w:tc></w:tr></w:tbl>'+
 '<w:p><w:sdt><w:sdtPr><w:id w:val="42"/><w:dropDownList><w:listItem w:displayText="Первый" w:value="Первый"/></w:dropDownList></w:sdtPr><w:sdtContent><w:r><w:t>Список Word</w:t></w:r></w:sdtContent></w:sdt></w:p>'+
 '<w:p><w:r><w:fldChar w:fldCharType="begin"/><w:instrText>PAGE</w:instrText><w:fldChar w:fldCharType="end"/></w:r></w:p>'+
 '<w:p><w:r><w:drawing><a:blip r:embed="rIdPicture"/></w:drawing></w:r></w:p>'+
 '<w:p><w:hyperlink r:id="rIdLink"><w:r><w:t>Ссылка</w:t></w:r></w:hyperlink></w:p>'+
 '<w:p><w:bookmarkStart w:id="1" w:name="Keep"/><w:r><w:t>Закладка</w:t></w:r><w:bookmarkEnd w:id="1"/></w:p>'+
 '<w:sdt><w:sdtPr><w:id w:val="123"/></w:sdtPr><w:sdtContent><w:p><w:r><w:t>Блок Word</w:t></w:r></w:p></w:sdtContent></w:sdt>'+
 '<w:p><w:r><w:t>Обычный абзац</w:t></w:r></w:p>'+
 '<w:sectPr><w:headerReference w:type="default" r:id="rIdHeader"/><w:footerReference w:type="default" r:id="rIdFooter"/><w:pgSz w:w="11906" w:h="16838"/></w:sectPr></w:body></w:document>'
 Set-EditorTestXml $path 'word/document.xml' $document
 Set-EditorTestXml $path 'word/header1.xml' ('<?xml version="1.0"?><w:hdr xmlns:w="'+$ns+'"><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:t>Колонтитул</w:t></w:r></w:p></w:hdr>')
 Set-EditorTestXml $path 'word/footer1.xml' ('<?xml version="1.0"?><w:ftr xmlns:w="'+$ns+'"><w:p><w:r><w:t>Низ страницы</w:t></w:r></w:p></w:ftr>')
 $zip=[IO.Compression.ZipFile]::OpenRead($path)
 try{$rels=Get-XmlPart $zip 'word/_rels/document.xml.rels';$types=Get-XmlPart $zip '[Content_Types].xml'}finally{$zip.Dispose()}
 $relationshipNs='http://schemas.openxmlformats.org/package/2006/relationships'
 foreach($record in @(@('rIdHeader','header','header1.xml'),@('rIdFooter','footer','footer1.xml'),@('rIdPicture','image','media/image1.png'),@('rIdLink','hyperlink','https://example.org/'))){
  $item=$rels.CreateElement('Relationship',$relationshipNs);$item.SetAttribute('Id',$record[0]);$item.SetAttribute('Type',('http://schemas.openxmlformats.org/officeDocument/2006/relationships/'+$record[1]));$item.SetAttribute('Target',$record[2]);if($record[1] -eq 'hyperlink'){$item.SetAttribute('TargetMode','External')};[void]$rels.DocumentElement.AppendChild($item)
 }
 foreach($record in @(@('/word/header1.xml','header'),@('/word/footer1.xml','footer'))){$item=$types.CreateElement('Override',$types.DocumentElement.NamespaceURI);$item.SetAttribute('PartName',$record[0]);$item.SetAttribute('ContentType',('application/vnd.openxmlformats-officedocument.wordprocessingml.'+$record[1]+'+xml'));[void]$types.DocumentElement.AppendChild($item)}
 $imageType=$types.CreateElement('Default',$types.DocumentElement.NamespaceURI);$imageType.SetAttribute('Extension','png');$imageType.SetAttribute('ContentType','image/png');[void]$types.DocumentElement.AppendChild($imageType)
 Set-EditorTestXml $path 'word/_rels/document.xml.rels' $rels.OuterXml;Set-EditorTestXml $path '[Content_Types].xml' $types.OuterXml
 $png=[Convert]::FromBase64String('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aL1kAAAAASUVORK5CYII=')
 Set-EditorTestPart $path 'word/media/image1.png' $png
}

$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-editor-test-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 Import-EditorTestFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
 Import-EditorTestFunctions (Join-Path $Project 'universal.ps1')
 Import-EditorTestFunctions (Join-Path $Project 'forms-v59.ps1')
 Import-EditorTestFunctions (Join-Path $Project 'template-editor-v59.ps1')
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main';$script:medicalProgramRoot=Join-Path $temp 'program';$script:medicalTemplatesFolder=Join-Path $script:medicalProgramRoot 'Шаблоны'
 [void][IO.Directory]::CreateDirectory($script:medicalProgramRoot)
 $config=New-EditorTestConfig;$source=Join-Path $temp 'source.docx';$config.Template=$source;New-EditorTestTemplate $source $config
 $sourceHash=Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($source));$model=Read-MedicalTemplateModel $source
 Assert-EditorCheck ($model.PartOrder.Count -eq 3 -and $model.PartOrder[0] -ceq 'word/document.xml') 'Body, header and footer loaded in stable order'
 Assert-EditorCheck ($model.Paragraphs.Count -eq 13) 'All ordinary, table and complex paragraphs mapped'
 $table=Find-EditorParagraph $model '{{CHOICE_DETAIL}}';Assert-EditorCheck ($table.Editable -and $table.Location.StartsWith('Таблица')) 'Table paragraph is editable and labelled'
 $styled=Find-EditorParagraph $model '{{TEXT}}';Assert-EditorCheck $styled.Editable 'Split-run text paragraph is editable'
 $bodyBefore=$model.Parts['word/document.xml'].Xml.OuterXml;Assert-MedicalEditorTemplateCoverage $config $model
 Assert-EditorCheck ($bodyBefore -ceq $model.Parts['word/document.xml'].Xml.OuterXml) 'Coverage uses a private XML copy'
 Assert-EditorCheck (-not $model.Parts['word/document.xml'].Modified) 'Coverage does not dirty the template'
 foreach($paragraph in @($model.Paragraphs | Where-Object {-not $_.Editable})){
  Assert-EditorCheck (-not [string]::IsNullOrWhiteSpace($paragraph.Reason)) ('Complex paragraph has an explanation: '+$paragraph.Id)
  Assert-EditorRejected {Set-MedicalTemplateParagraph $model $paragraph.Id 'Dangerous replacement'} ('Complex paragraph modification refused: '+$paragraph.Id)
 }
 Assert-EditorCheck (@($model.Paragraphs | Where-Object {-not $_.Editable}).Count -eq 6) 'Word fields, drawing, hyperlink, bookmark and controls remain read-only'
 Assert-EditorCheck ($bodyBefore -ceq $model.Parts['word/document.xml'].Xml.OuterXml) 'Rejected edits leave complex XML untouched'
 $unchangedPath=Join-Path $temp 'unchanged.docx';Write-MedicalTemplateModel $unchangedPath $model;$unchanged=Read-MedicalTemplateModel $unchangedPath
 foreach($entry in $model.Entries){Assert-EditorCheck ((Get-EditorPartHash $model $entry.Name) -ceq (Get-EditorPartHash $unchanged $entry.Name)) ('Unmodified ZIP entry bytes preserved: '+$entry.Name)}
 Assert-EditorRejected {Write-MedicalTemplateModel $source $model} 'Source template cannot be overwritten'
 $paragraphStyle=$styled.Node.SelectSingleNode('./w:pPr',(Get-MedicalEditorNamespace $styled.Node.OwnerDocument)).OuterXml
 Set-MedicalTemplateParagraph $model $styled.Id ("До {{TEXT}}`r`nВторая строка`t<&> / {{CHOICE}}")
 $namespaces=Get-MedicalEditorNamespace $styled.Node.OwnerDocument
 Assert-EditorCheck ($styled.Node.SelectSingleNode('./w:pPr',$namespaces).OuterXml -ceq $paragraphStyle) 'Edited paragraph keeps its complete paragraph style'
 Assert-EditorCheck ($styled.Node.GetAttribute('rsidR',$script:ns) -ceq '12345678') 'Edited paragraph keeps paragraph attributes'
 Assert-EditorCheck ($null -ne $styled.Node.SelectSingleNode('./w:r/w:rPr/w:b',$namespaces) -and $styled.Node.SelectSingleNode('./w:r/w:rPr/w:color',$namespaces).GetAttribute('val',$script:ns) -ceq '123456') 'Edited paragraph keeps its base run properties'
 Assert-EditorCheck (@($styled.Node.SelectNodes('./w:r/w:br',$namespaces)).Count -eq 1 -and @($styled.Node.SelectNodes('./w:r/w:tab',$namespaces)).Count -eq 1) 'Multiline text uses real Word breaks and tabs'
 Assert-EditorCheck (@($styled.Node.SelectNodes('./w:r/w:t',$namespaces) | Where-Object {$_.InnerText -match '[\r\n\t]'}).Count -eq 0) 'Word text nodes contain no raw breaks or tabs'
 Assert-EditorCheck ($styled.Node.OuterXml.Contains('&lt;&amp;&gt;')) 'User XML characters are escaped safely'
 $lineEndingModel=Read-MedicalTemplateModel $source;$lineEndingParagraph=Find-EditorParagraph $lineEndingModel '{{TEXT}}'
 Set-MedicalTemplateParagraph $lineEndingModel $lineEndingParagraph.Id "Первая`r`nВторая"
 $lineEndingModel.Parts['word/document.xml'].Modified=$false;$lineEndingXml=$lineEndingParagraph.Node.OuterXml
 Set-MedicalTemplateParagraph $lineEndingModel $lineEndingParagraph.Id "Первая`nВторая"
 Assert-EditorCheck (-not $lineEndingModel.Parts['word/document.xml'].Modified -and $lineEndingXml -ceq $lineEndingParagraph.Node.OuterXml) 'RichTextBox LF normalization does not rewrite an unchanged paragraph'
 Set-MedicalTemplateParagraph $model $table.Id 'Деталь: {{CHOICE_DETAIL}}';$tableCountBefore=$model.Parts['word/document.xml'].Xml.SelectNodes('//w:tbl',$namespaces).Count
 $newTable=Add-MedicalTemplateParagraph $model 'word/document.xml' $table.Id 'Добавленная строка таблицы'
 Assert-EditorCheck ($newTable.Location.StartsWith('Таблица') -and $newTable.Node.ParentNode.LocalName -ceq 'tc') 'Added table paragraph stays within its cell'
 $newBody=Add-MedicalTemplateParagraph $model 'word/document.xml' '' 'Конец документа'
 Assert-EditorCheck ($newBody.Node.NextSibling.LocalName -ceq 'sectPr') 'Body paragraph added before section properties'
 $newHeader=Add-MedicalTemplateParagraph $model 'word/header1.xml' '' 'Новый верхний абзац'
 Assert-EditorCheck ($newHeader.Node.ParentNode.LocalName -ceq 'hdr') 'Added header paragraph stays inside header'
 $header=Find-EditorParagraph $model 'Колонтитул' 'word/header1.xml';Set-MedicalTemplateParagraph $model $header.Id 'Заголовок {{TEXT}}'
 $footer=Find-EditorParagraph $model 'Низ страницы' 'word/footer1.xml';Set-MedicalTemplateParagraph $model $footer.Id 'Нижний колонтитул {{CHOICE_DETAIL}}'
 $block=Find-EditorParagraph $model 'Блок Word';Assert-EditorRejected {Add-MedicalTemplateParagraph $model 'word/document.xml' $block.Id 'Нельзя'} 'Adding inside a Word content control is refused'
 $editedPath=Join-Path $temp 'edited.docx';Write-MedicalTemplateModel $editedPath $model;$edited=Read-MedicalTemplateModel $editedPath
 Assert-MedicalEditorTemplateCoverage $config $edited
 Assert-EditorCheck ($edited.Parts['word/document.xml'].Xml.SelectNodes('//w:tbl',$namespaces).Count -eq $tableCountBefore) 'Table structure survives editing and reloading'
 foreach($name in @('word/media/image1.png','word/_rels/document.xml.rels','_rels/.rels','[Content_Types].xml','word/styles.xml')){Assert-EditorCheck ((Get-EditorPartHash $unchanged $name) -ceq (Get-EditorPartHash $edited $name)) ('Resources and relationships preserved byte for byte: '+$name)}
 Assert-EditorCheck ((Find-EditorParagraph $edited 'Заголовок {{TEXT}}' 'word/header1.xml').Editable) 'Header text edits survive reload'
 Assert-EditorCheck ((Find-EditorParagraph $edited 'Нижний колонтитул {{CHOICE_DETAIL}}' 'word/footer1.xml').Editable) 'Footer detail marker survives reload'
 Assert-EditorCheck ((Find-EditorParagraph $edited ("До {{TEXT}}`r`nВторая строка`t<&> / {{CHOICE}}")).Editable) 'Multiline escaped text round trips correctly'
 Assert-EditorCheck ((Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($source))) -ceq $sourceHash) 'All editing leaves the original file unchanged'
 $outputExisting=Join-Path $temp 'existing.docx';[IO.File]::WriteAllText($outputExisting,'Existing target must survive')
 $badModel=Read-MedicalTemplateModel $source;$badModel.Parts['word/document.xml'].Modified=$true;$badModel.Parts['word/document.xml'].Xml=[pscustomobject]@{OuterXml='<broken>'}
 Assert-EditorRejected {Write-MedicalTemplateModel $outputExisting $badModel} 'Malformed model rejected before replacing a target'
 Assert-EditorCheck ([IO.File]::ReadAllText($outputExisting) -ceq 'Existing target must survive') 'Atomic write failure preserves an existing target'
 Assert-EditorCheck (@(Get-ChildItem -LiteralPath $temp -Filter '.mc-editor-*.tmp').Count -eq 0) 'Failed atomic write removes its temporary archive'
 Write-MedicalTemplateModel $outputExisting $model;[void](Read-MedicalTemplateModel $outputExisting)
 Assert-EditorCheck (([IO.File]::ReadAllBytes($outputExisting))[0] -eq 80) 'Valid model atomically replaces an existing target'
 $missing=Read-MedicalTemplateModel $source;Set-MedicalTemplateParagraph $missing (Find-EditorParagraph $missing '{{ADMISSION_DATETIME}}').Id 'Без даты'
 Assert-EditorRejected {Assert-MedicalEditorTemplateCoverage $config $missing} 'Missing admission date and time rejected'
 $missing=Read-MedicalTemplateModel $source;Set-MedicalTemplateParagraph $missing (Find-EditorParagraph $missing '{{TEXT}}').Id 'Нет маркера'
 Assert-EditorRejected {Assert-MedicalEditorTemplateCoverage $config $missing} 'Missing field marker rejected even without patient answers'
 $missing=Read-MedicalTemplateModel $source;Set-MedicalTemplateParagraph $missing (Find-EditorParagraph $missing '{{CHOICE_DETAIL}}').Id 'Нет уточнения'
 Assert-EditorRejected {Assert-MedicalEditorTemplateCoverage $config $missing} 'Missing separate clarification marker rejected'
 $missing=Read-MedicalTemplateModel $source;Set-MedicalTemplateParagraph $missing (Find-EditorParagraph $missing '{{TEXT}}').Id '{{UNKNOWN}}'
 Assert-EditorRejected {Assert-MedicalEditorTemplateCoverage $config $missing} 'Unknown template markers rejected by actual export engine'
 Assert-EditorRejected {Save-MedicalEditorResult $config $missing 'Wrong.docx'} 'Invalid schema/template result rejected before import'
 Assert-EditorCheck (-not [IO.Directory]::Exists($script:medicalTemplatesFolder)) 'Failed result validation creates no template directory'
 $private=Copy-MedicalFormSchema $config;$private.Sections[0].Fields[0].Label='Изменение';Assert-EditorCheck ($config.Sections[0].Fields[0].Label -ceq 'Текст') 'Working schema is a deep copy'
 $script:universalValues=@{text='Patient secret'};$script:universalDetails=@{choice='Patient detail'}
 $config | Add-Member -NotePropertyName Values -NotePropertyValue $script:universalValues
 $config | Add-Member -NotePropertyName Details -NotePropertyValue $script:universalDetails
 $config | Add-Member -NotePropertyName AdmissionDateTime -NotePropertyValue 'Patient date'
 $result=Save-MedicalEditorResult $config $model 'Редактированный шаблон.docx'
 Assert-EditorCheck ($result.Schema.AutoTemplate -eq $false -and $result.Schema.Template -ceq ('Шаблоны/'+$result.Template.Name)) 'Result selects its edited portable template'
 Assert-EditorCheck ([IO.File]::Exists($result.Template.Path)) 'Edited template imported into the program template folder'
 Assert-EditorCheck (($result.Schema | ConvertTo-Json -Depth 40) -notmatch 'Patient secret|Patient detail|Patient date|"Values"|"Details"|"AdmissionDateTime"') 'Reusable result excludes patient state'
 Assert-EditorCheck ($script:universalValues.text -ceq 'Patient secret' -and $script:universalDetails.choice -ceq 'Patient detail') 'Editor never mutates active patient answers'
 Assert-EditorCheck ($config.Template -ceq $source -and $config.AutoTemplate -eq $false) 'Save returns a result without mutating caller configuration'
 $savedHash=Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($result.Template.Path));$again=Save-MedicalEditorResult $config $model 'Редактированный шаблон.docx'
 Assert-EditorCheck ($again.Template.Path -ceq $result.Template.Path) 'Identical template save is deduplicated'
 $ordinary=Find-EditorParagraph $model 'Обычный абзац';Set-MedicalTemplateParagraph $model $ordinary.Id 'Новая редакция'
 $changed=Save-MedicalEditorResult $config $model 'Редактированный шаблон.docx'
 Assert-EditorCheck ($changed.Template.Path -cne $result.Template.Path) 'Changed same-name template gets a separate path'
 Assert-EditorCheck ((Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($result.Template.Path))) -ceq $savedHash) 'Existing user template is preserved during save'
 $onlyDates=Read-MedicalTemplateModel $source;Set-MedicalTemplateParagraph $onlyDates (Find-EditorParagraph $onlyDates '{{ADMISSION_DATETIME}}').Id '{{ADMISSION_DATE}} {{ADMISSION_TIME}}'
 Assert-MedicalEditorTemplateCoverage $config $onlyDates;Assert-EditorCheck $true 'Separate admission date and time markers accepted'
 $auto=New-UniversalConfig;$autoPath=Join-Path $temp 'auto.docx';New-UniversalTemplate $autoPath $auto;Assert-MedicalEditorTemplateCoverage $auto (Read-MedicalTemplateModel $autoPath)
 Assert-EditorCheck $true 'Default generated form template passes coverage'
 $nonRecursive=Copy-MedicalFormSchema $config;$nonRecursive.Sections[0].Fields[0].Id='{{UNKNOWN}}'
 Assert-MedicalEditorTemplateCoverage $nonRecursive (Read-MedicalTemplateModel $source)
 Assert-EditorCheck $true 'Coverage does not recursively replace marker-looking generated values'
 Assert-EditorRejected {Save-MedicalEditorResult $config $model 'Mismatched.dotx'} 'Save rejects extension and content-type mismatch'
 $dotx=Join-Path $temp 'template.dotx';[IO.File]::Copy($source,$dotx)
 $types=@($model.Entries | Where-Object {$_.Name -ceq '[Content_Types].xml'})[0].Bytes
 $typeText=[Text.Encoding]::UTF8.GetString($types).Replace('application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml','application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml')
 Set-EditorTestXml $dotx '[Content_Types].xml' $typeText;$dotxModel=Read-MedicalTemplateModel $dotx
 Assert-EditorCheck ($dotxModel.TemplateExtension -ceq '.dotx') 'DOTX package type is detected independently of filenames'
 $dotxResult=Save-MedicalEditorResult $config $dotxModel 'Мой DOTX'
 Assert-EditorCheck ($dotxResult.Template.Name.EndsWith('.dotx')) 'DOTX save preserves template type and extension'
 $pageBreak=Join-Path $temp 'page-break.docx';[IO.File]::Copy($source,$pageBreak)
 $pageModel=Read-MedicalTemplateModel $source;$ordinaryPage=Find-EditorParagraph $pageModel 'Обычный абзац';$pageRun=$ordinaryPage.Node.FirstChild
 $break=$ordinaryPage.Node.OwnerDocument.CreateElement('w','br',$script:ns);$breakType=$ordinaryPage.Node.OwnerDocument.CreateAttribute('w','type',$script:ns);$breakType.Value='page';[void]$break.Attributes.Append($breakType);[void]$pageRun.AppendChild($break)
 $pageModel.Parts['word/document.xml'].Modified=$true;Write-MedicalTemplateModel $pageBreak $pageModel;$pageModel=Read-MedicalTemplateModel $pageBreak
 $pageParagraph=@($pageModel.Paragraphs | Where-Object {$_.Text.StartsWith('Обычный абзац')})[0]
 Assert-EditorCheck (-not $pageParagraph.Editable) 'Page break paragraph is protected against layout loss'
 Assert-EditorRejected {Set-MedicalTemplateParagraph $pageModel $pageParagraph.Id 'New text'} 'Editing cannot turn a page break into a line break'
 $patient=Join-Path $temp 'patient-card.docx';[IO.File]::Copy($source,$patient);Set-EditorTestXml $patient 'customXml/mc49.xml' '<state>Patient data</state>'
 Assert-EditorRejected {Read-MedicalTemplateModel $patient} 'Patient-card custom XML cannot enter a reusable template'
 $legacyPatient=Join-Path $temp 'legacy-patient-card.docx';[IO.File]::Copy($source,$legacyPatient);$legacyModel=Read-MedicalTemplateModel $source
 Set-MedicalTemplateParagraph $legacyModel (Find-EditorParagraph $legacyModel 'Обычный абзац').Id 'MC_CASE_V24:c2VjcmV0:END_MC_CASE'
 $legacyPart=$legacyModel.Parts['word/document.xml'].Xml.OuterXml;Set-EditorTestXml $legacyPatient 'word/document.xml' $legacyPart
 Assert-EditorRejected {Read-MedicalTemplateModel $legacyPatient} 'Legacy patient-card hidden state cannot enter a reusable template'
 $dtd=Join-Path $temp 'dtd.docx';[IO.File]::Copy($source,$dtd);Set-EditorTestXml $dtd 'word/header1.xml' ('<!DOCTYPE hdr [<!ENTITY x SYSTEM "file:///etc/passwd">]><w:hdr xmlns:w="'+$script:ns+'"><w:p><w:r><w:t>&x;</w:t></w:r></w:p></w:hdr>')
 Assert-EditorRejected {Read-MedicalTemplateModel $dtd} 'DTD and external XML entities refused in template parts'
 $editorSource=[IO.File]::ReadAllText((Join-Path $Project 'template-editor-v59.ps1'))
 Assert-EditorCheck ($editorSource -notmatch 'Show-UniversalFieldEditor|COMObject|Word\.Application') 'Unified editor never opens Word or a separate field editor'
 Assert-EditorCheck ($editorSource -notmatch '\$script:universalValues|\$script:universalDetails|Capture-Stage|Restore-UniversalState') 'Editor source has no access to patient answer globals'
 Write-Output ('TOTAL '+$script:checks+' template editor checks')
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
