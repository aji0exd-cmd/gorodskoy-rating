﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v73'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Check([bool]$test,[string]$label){if(-not $test){throw $label};$script:checks++;Write-Output ('PASS '+$label)}
function Assert-Rejected([scriptblock]$action,[string]$label){$rejected=$false;try{$null=& $action}catch{$rejected=$true};Assert-Check $rejected $label}
function Read-TestDatabase($context){$lock=Enter-MedicalAccountsLock $context;try{return Read-MedicalAccountsDatabase $context}finally{$lock.Dispose()}}
function Set-TestThrottle($context,[int]$failures,$until){$lock=Enter-MedicalAccountsLock $context;try{$db=Read-MedicalAccountsDatabase $context;$db.LoginFailures=$failures;$db.LoginLockedUntilUtc=$until;Write-MedicalAccountsDatabase $context $db}finally{$lock.Dispose()}}
function Get-TestSha([string]$path){return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}
. (Join-Path $Project 'accounts-v71.ps1')
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-v71-accounts-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 # The PBKDF function is the real production C# function, tested against the RFC SHA256 vector.
 $tokens=$null;$errors=$null;$securityAst=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'accounts-v71.ps1'),[ref]$tokens,[ref]$errors)
 if($errors.Count){throw 'Account module parse error.'}
 $csharp=$securityAst.Find({param($n)$n -is [Management.Automation.Language.StringConstantExpressionAst] -and $n.Value.Contains('public static class Security')},$true).Value
 # Exercise the actual legacy .NET Framework branch even on a modern test runtime.
 $legacySource=$csharp.Replace('namespace MedicalAccountsV71 {','namespace MedicalAccountsV71LegacyVerification {').Replace('Type algorithm=typeof(Rfc2898DeriveBytes).Assembly.GetType("System.Security.Cryptography.HashAlgorithmName");','Type algorithm=null;').Replace('if(algorithm==null) algorithm=Type.GetType("System.Security.Cryptography.HashAlgorithmName, System.Security.Cryptography.Primitives");','// Force legacy SHA256 fallback for verification.')
 if(-not ('MedicalAccountsV71LegacyVerification.Security' -as [type])){Add-Type -TypeDefinition $legacySource}
 foreach($vector in @(@(1,'120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b'),@(4096,'c5e478d59288c841aa530db6845c4c8d962893a001ce4e11a4963873aa98134a'))){
  $legacy=[MedicalAccountsV71LegacyVerification.Security]::Derive('password',[Text.Encoding]::UTF8.GetBytes('salt'),$vector[0]);$native=[MedicalAccountsV71.Security]::Derive('password',[Text.Encoding]::UTF8.GetBytes('salt'),$vector[0])
  Assert-Check ([BitConverter]::ToString($legacy).Replace('-','').ToLowerInvariant() -ceq $vector[1]) ('Legacy PBKDF2 fallback matches reference vector at '+$vector[0]+' iterations')
  Assert-Check ([MedicalAccountsV71.Security]::Equal($native,$legacy)) ('Legacy and modern PBKDF2 agree at '+$vector[0]+' iterations')
 }
 $legacy=[MedicalAccountsV71LegacyVerification.Security]::Derive('Пароль с пробелами ' + [char]0xD83D + [char]0xDE00,[byte[]](0..31),10000)
 $native=[MedicalAccountsV71.Security]::Derive('Пароль с пробелами ' + [char]0xD83D + [char]0xDE00,[byte[]](0..31),10000)
 Assert-Check ([MedicalAccountsV71.Security]::Equal($native,$legacy)) 'Legacy fallback preserves UTF8 Cyrillic supplementary Unicode and spaces'
 $salt=[Text.Encoding]::UTF8.GetBytes('salt')
 $hash=[MedicalAccountsV71.Security]::Derive('password',$salt,1)
 Assert-Check (([BitConverter]::ToString($hash).Replace('-','').ToLowerInvariant()) -ceq '120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b') 'PBKDF2-SHA256 matches independently published test vector'
 Assert-Check ([MedicalAccountsV71.Security]::Equal([byte[]](1,2,3),[byte[]](1,2,3))) 'Constant-time comparator accepts equal bytes'
 Assert-Check (-not [MedicalAccountsV71.Security]::Equal([byte[]](1,2,3),[byte[]](1,2,4))) 'Constant-time comparator rejects changed final byte'
 Assert-Check (-not [MedicalAccountsV71.Security]::Equal([byte[]](1,2,3),[byte[]](1,2,3,0))) 'Constant-time comparator rejects differing length'
 $root=Join-Path $temp 'Программа на флешке';[void][IO.Directory]::CreateDirectory($root);$context=Initialize-MedicalAccounts $root
 Assert-Check ((Get-MedicalAccountsState $context).IsInitialized -eq $false) 'Fresh installation requires first administrator'
 Assert-Check (-not [IO.File]::Exists($context.DatabasePath)) 'Initialization creates no default account or password'
 foreach($password in @('','abc','          ',('x'*1025))){Assert-Rejected {New-MedicalFirstAdministrator $context 'admin' 'Администратор' $password} 'First administrator rejects invalid password'}
 foreach($name in @('a','../../root','first user',('x'*65))){Assert-Rejected {New-MedicalFirstAdministrator $context $name 'Администратор' 'AdminPass_123'} 'First administrator rejects unsafe username'}
 $admin=New-MedicalFirstAdministrator $context 'Admin' 'Первый администратор' 'AdminPass_123'
 Assert-Check ([IO.File]::Exists($context.DatabasePath) -and [IO.File]::Exists($context.BackupPath)) 'First setup persists primary and verified last-good copy'
 Assert-Check ($admin.Role -ceq 'Administrator' -and $admin.UserId -match '^[a-f0-9-]{36}$') 'First account is administrator with random GUID'
 Assert-Check ($admin.DataRoot -ceq [IO.Path]::Combine($root,'Данные',$admin.UserId)) 'Data root is independent private GUID workspace'
 Assert-Check (Test-MedicalSession $admin) 'Fresh admin session validates without password re-derivation'
 Assert-Check ((Assert-MedicalAccountSession $admin).UserId -ceq $admin.UserId) 'Throwing session guard returns validated session'
 Assert-Check (Assert-MedicalAdministrator $admin) 'Administrator guard accepts valid admin'
 Assert-Rejected {New-MedicalFirstAdministrator $context 'second' 'Второй' 'AdminPass_123'} 'First-admin creation cannot repeat'
 $db=Read-TestDatabase $context;$record=$db.Accounts[0]
 Assert-Check ($record.Password.Iterations -eq 600000 -and $record.Password.Algorithm -ceq 'PBKDF2-SHA256') 'New passwords use 600000 PBKDF2-SHA256 iterations'
 Assert-Check ([Convert]::FromBase64String($record.Password.Salt).Length -eq 32 -and [Convert]::FromBase64String($record.Password.Hash).Length -eq 32) 'Salt and verifier are 256-bit values'
 $raw=[IO.File]::ReadAllText($context.DatabasePath)
 Assert-Check (-not $raw.Contains('AdminPass_123')) 'Password is absent from persisted account database'
 Assert-Check (-not ([IO.File]::ReadAllText($context.BackupPath)).Contains('AdminPass_123')) 'Password is absent from last-good backup'
 Assert-Rejected {Invoke-MedicalAccountLogin $context 'admin' 'wrong-password'} 'Incorrect password fails closed'
 $admin2=Invoke-MedicalAccountLogin $context 'aDmIn' 'AdminPass_123'
 Assert-Check ($admin2.UserId -ceq $admin.UserId) 'Username matching is invariant and case-insensitive'
 Assert-Check ((Read-TestDatabase $context).LoginFailures -eq 0) 'Successful authentication clears persisted failure count'
 $before=Get-TestSha $context.DatabasePath
 Assert-Rejected {Set-MedicalAccountEnabled $admin $admin.UserId $false} 'Last enabled administrator cannot be disabled'
 Assert-Check ((Get-TestSha $context.DatabasePath) -ceq $before) 'Rejected disable leaves account database byte-identical'
 Assert-Rejected {Set-MedicalAccountRole $admin $admin.UserId 'User'} 'Last enabled administrator cannot be demoted'
 Assert-Check ((Get-TestSha $context.DatabasePath) -ceq $before) 'Rejected demotion leaves account database byte-identical'
 $secondAdmin=New-MedicalUserAccount $admin 'reserve-admin' 'Резервный администратор' 'ReserveAdmin123' 'Administrator'
 $null=Set-MedicalAccountEnabled $admin $secondAdmin.Id $false
 Assert-Rejected {Set-MedicalAccountRole $admin $admin.UserId 'User'} 'Disabled second administrator does not permit demoting the only enabled administrator'
 $null=Set-MedicalAccountRole $admin $secondAdmin.Id 'User'
 $doctor=New-MedicalUserAccount $admin 'Доктор' 'Врач №1' 'Пароль12345'
 Assert-Check ($doctor.Role -ceq 'User' -and $doctor.Enabled) 'Administrator creates ordinary enabled employee'
 Assert-Check (-not ($doctor.PSObject.Properties.Name -contains 'Password')) 'Public account projection exposes no password verifier'
 $doctorSession=Invoke-MedicalAccountLogin $context 'доктор' 'Пароль12345'
 Assert-Check ($doctorSession.DataRoot -cne $admin.DataRoot) 'Employees have different private workspace directories'
 Assert-Rejected {New-MedicalUserAccount $admin 'ＡＤＭＩＮ' 'Еще администратор' 'DoctorPass_12'} 'Unicode compatibility-equivalent username cannot duplicate administrator'

 foreach($action in @(
  {New-MedicalUserAccount $doctorSession 'intruder' 'Нарушитель' 'IntruderPass_1' 'Administrator'},
  {Set-MedicalAccountRole $doctorSession $doctor.Id 'Administrator'},
  {Set-MedicalAccountEnabled $doctorSession $admin.UserId $false},
  {Reset-MedicalAccountPassword $doctorSession $admin.UserId 'StolenPass_123'},
  {Get-MedicalAccounts $doctorSession}
 )){Assert-Rejected $action 'Ordinary employee cannot invoke administrator operation'}
 $doctorSession.Role='Administrator'
 Assert-Rejected {Assert-MedicalAdministrator $doctorSession} 'Forged public Role cannot grant administrator privileges'
 Assert-Check ($doctorSession.Role -ceq 'User') 'Session guard restores role from authoritative database'
 $forged=[pscustomobject]@{UserId=$admin.UserId;Username='Admin';DisplayName='Forged';Role='Administrator';Context=$context;DataRoot=$admin.DataRoot;Token=[Convert]::ToBase64String([byte[]](1..48))}
 Assert-Check (-not (Test-MedicalSession $forged)) 'Fabricated session without issued random ticket is rejected'
 $forged=$admin.PSObject.Copy();$forged.UserId=$doctor.Id
 Assert-Check (-not (Test-MedicalSession $forged)) 'Issued ticket cannot be replayed as another employee'
 $tamperedContext=$context.PSObject.Copy();$tamperedContext.BackupPath=Join-Path $temp 'arbitrary-file.txt'
 Assert-Rejected {Get-MedicalAccountsState $tamperedContext} 'Tampered context cannot redirect account backup writes'
 $doctorSession.DataRoot=$admin.DataRoot;$null=Assert-MedicalAccountSession $doctorSession
 Assert-Check ($doctorSession.DataRoot -ceq [IO.Path]::Combine($root,'Данные',$doctor.Id)) 'Session validation restores own data root after property tampering'
 $samePassword=New-MedicalUserAccount $admin 'doctor-two' 'Врач №2' 'Пароль12345';$db=Read-TestDatabase $context
 $record1=Find-MedicalAccountById $db $doctor.Id;$record2=Find-MedicalAccountById $db $samePassword.Id
 Assert-Check ($record1.Password.Salt -cne $record2.Password.Salt -and $record1.Password.Hash -cne $record2.Password.Hash) 'Equal passwords receive independent random salts and hashes'
 $before=Get-TestSha $context.DatabasePath
 Assert-Rejected {Set-MedicalOwnPassword $doctorSession 'Incorrect123' 'NewPassword123'} 'Own password change requires current password'
 Assert-Check ((Get-TestSha $context.DatabasePath) -ceq $before) 'Wrong current password leaves database unchanged'
 $otherDoctorSession=Invoke-MedicalAccountLogin $context 'Доктор' 'Пароль12345'
 $oldToken=$doctorSession.Token;$updated=Set-MedicalOwnPassword $doctorSession 'Пароль12345' 'НовыйПароль54321'
 Assert-Check ($updated.Token -cne $oldToken -and (Test-MedicalSession $updated)) 'Own password change renews current session securely'
 Assert-Check (-not (Test-MedicalSession $otherDoctorSession)) 'Password change invalidates other sessions immediately'
 Assert-Rejected {Invoke-MedicalAccountLogin $context 'Доктор' 'Пароль12345'} 'Old password stops authenticating after change'
 $updated=Invoke-MedicalAccountLogin $context 'Доктор' 'НовыйПароль54321'
 Reset-MedicalAccountPassword $admin $doctor.Id 'ResetPassword123'
 Assert-Check (-not (Test-MedicalSession $updated)) 'Administrator password reset revokes target active sessions'
 $reset=Invoke-MedicalAccountLogin $context 'Доктор' 'ResetPassword123'
 $null=Set-MedicalAccountEnabled $admin $doctor.Id $false
 Assert-Check (-not (Test-MedicalSession $reset)) 'Disabled account loses access immediately'
 $disabledError='';try{$null=Invoke-MedicalAccountLogin $context 'Доктор' 'ResetPassword123'}catch{$disabledError=$_.Exception.Message}
 $unknownError='';try{$null=Invoke-MedicalAccountLogin $context 'unlisted' 'ResetPassword123'}catch{$unknownError=$_.Exception.Message}
 Assert-Check ($disabledError -ceq $unknownError -and $disabledError.Length -gt 10) 'Disabled and unknown accounts return identical login failure text'
 $null=Set-MedicalAccountEnabled $admin $doctor.Id $true
 Assert-Check (-not (Test-MedicalSession $reset)) 'Re-enabling account does not revive sessions revoked by disable'
 $active=Invoke-MedicalAccountLogin $context 'Доктор' 'ResetPassword123'
 $null=Set-MedicalAccountRole $admin $doctor.Id 'Administrator'
 Assert-Check ((Assert-MedicalAccountSession $active).Role -ceq 'Administrator') 'Role promotion becomes authoritative on next session validation'
 $null=Set-MedicalAccountRole $admin $doctor.Id 'User'
 Assert-Rejected {Assert-MedicalAdministrator $active} 'Role demotion removes administrator authority immediately'
 Close-MedicalSession $active
 Assert-Check (-not (Test-MedicalSession $active)) 'Logout revokes issued ticket'
 # Persisted global throttle applies to unknown and known names equally, including after reinitialization.
 Set-TestThrottle $context 0 $null
 for($i=1;$i -le 5;$i++){Assert-Rejected {Invoke-MedicalAccountLogin $context 'unknown-name' 'WrongPassword123'} ('Unknown login attempt rejected '+$i)}
 $db=Read-TestDatabase $context
 Assert-Check ($db.LoginFailures -eq 5 -and $null -ne $db.LoginLockedUntilUtc) 'Five failed attempts persist a cooldown in account database'
 $reopened=Initialize-MedicalAccounts $root
 $before=Get-TestSha $context.DatabasePath
 Assert-Rejected {Invoke-MedicalAccountLogin $reopened 'Admin' 'AdminPass_123'} 'Restarting application cannot bypass persisted login throttle'
 Assert-Check ((Get-TestSha $context.DatabasePath) -ceq $before) 'Attempt during cooldown does not rewrite database repeatedly'
 Set-TestThrottle $context 5 ([datetime]::UtcNow.AddMinutes(-1).ToString('yyyy-MM-dd HH:mm:ss.fffffffZ',[Globalization.CultureInfo]::InvariantCulture))
 $null=Invoke-MedicalAccountLogin $context 'Admin' 'AdminPass_123'
 Assert-Check ((Read-TestDatabase $context).LoginFailures -eq 0) 'Correct password authenticates after persisted cooldown expires'
 # Real file lock enforces serialization between independent processes.
 $childPath=Join-Path $temp 'lock-child.ps1';$childOutput=Join-Path $temp 'lock-output.txt'
 $module=(Join-Path $Project 'accounts-v71.ps1').Replace("'","''");$childRoot=$root.Replace("'","''");$childResult=$childOutput.Replace("'","''")
 $childCode="`$ErrorActionPreference='Stop';. '$module';`$c=Initialize-MedicalAccounts '$childRoot';`$s=Get-MedicalAccountsState `$c;[IO.File]::WriteAllText('$childResult',[string]`$s.Count)"
 [IO.File]::WriteAllText($childPath,$childCode,(New-Object Text.UTF8Encoding($true)))
 $lock=Enter-MedicalAccountsLock $context
 $start=New-Object Diagnostics.ProcessStartInfo;$start.FileName=(Get-Process -Id $PID).Path;$start.UseShellExecute=$false;$start.Arguments='-NoProfile -File "'+$childPath+'"';$start.RedirectStandardError=$true;$start.RedirectStandardOutput=$true
 $process=[Diagnostics.Process]::Start($start)
 try{[Threading.Thread]::Sleep(800);Assert-Check (-not [IO.File]::Exists($childOutput)) 'Independent process cannot read account database while exclusive transaction lock held'}finally{$lock.Dispose()}
 Assert-Check ($process.WaitForExit(15000)) 'Waiting account process completes after transaction lock released'
 $childError=$process.StandardError.ReadToEnd();Assert-Check ($process.ExitCode -eq 0) ('Independent account process exits cleanly: '+$childError)
 Assert-Check ([IO.File]::ReadAllText($childOutput) -ceq '4') 'Independent process reads complete committed account list'
 $process.Dispose()
 # Independent authenticated writers share the same lock and preserve both committed additions.
 $writerPaths=@();$writerProcesses=@()
 for($i=1;$i -le 2;$i++){
  $writerPath=Join-Path $temp ('writer-'+$i+'.ps1');$writerPaths+=@($writerPath)
  $writerCode="`$ErrorActionPreference='Stop';. '$module';`$c=Initialize-MedicalAccounts '$childRoot';`$a=Invoke-MedicalAccountLogin `$c 'Admin' 'AdminPass_123';`$null=New-MedicalUserAccount `$a 'writer$i' 'Concurrent Writer $i' 'WriterPassword123'"
  [IO.File]::WriteAllText($writerPath,$writerCode,(New-Object Text.UTF8Encoding($true)))
  $writerStart=New-Object Diagnostics.ProcessStartInfo;$writerStart.FileName=(Get-Process -Id $PID).Path;$writerStart.UseShellExecute=$false;$writerStart.Arguments='-NoProfile -File "'+$writerPath+'"';$writerStart.RedirectStandardError=$true;$writerStart.RedirectStandardOutput=$true
  $writerProcesses+=@([Diagnostics.Process]::Start($writerStart))
 }
 foreach($writer in $writerProcesses){Assert-Check ($writer.WaitForExit(20000)) 'Concurrent account writer completes without deadlock';$writerError=$writer.StandardError.ReadToEnd();Assert-Check ($writer.ExitCode -eq 0) ('Concurrent writer commits cleanly: '+$writerError);$writer.Dispose()}
 $db=Read-TestDatabase $context
 Assert-Check ($db.Accounts.Count -eq 6) 'Concurrent writer transactions preserve both additions without lost update'
 Assert-Check (@($db.Accounts|Where-Object{$_.Username -in @('writer1','writer2')}).Count -eq 2) 'Both independent writer records survive verified commit'
 # Write interruption before Replace leaves primary bytes intact and no orphan temporary files.
 $before=Get-TestSha $context.DatabasePath;$db=Read-TestDatabase $context;$db.Accounts[1].DisplayName='Не должно примениться'
 $backupPath=$context.BackupPath;$backupBytes=[IO.File]::ReadAllBytes($backupPath);[IO.File]::Delete($backupPath);[void][IO.Directory]::CreateDirectory($backupPath)
 try{Assert-Rejected {Write-MedicalAccountsDatabase $context $db} 'Atomic account write fails safely when backup target cannot be replaced';Assert-Check ((Get-TestSha $context.DatabasePath) -ceq $before) 'Failed atomic replace preserves previous primary database';Assert-Check (@(Get-ChildItem -LiteralPath $context.AccountsDirectory -Filter '*.tmp').Count -eq 0) 'Failed write cleans its temporary account file'}finally{[IO.Directory]::Delete($backupPath);[IO.File]::WriteAllBytes($backupPath,$backupBytes)}
 # Strict schema/corruption cases are isolated and never interpreted as new installations.
 $good=[IO.File]::ReadAllBytes($context.DatabasePath);$goodText=[Text.Encoding]::UTF8.GetString($good)
 $mutations=@(
  {param($x)$x.Version=2},
  {param($x)$x.Accounts[0].Role='SuperAdmin'},
  {param($x)$x.Accounts[0].Enabled='true'},
  {param($x)$x.Accounts[0].Password.Iterations=1},
  {param($x)$x.Accounts[0].Password.Iterations=90000000},
  {param($x)$x.Accounts[0].Password.Hash='bad'},
  {param($x)$x.Accounts[0].Password.Salt=[Convert]::ToBase64String([byte[]](1..16))},
  {param($x)$x.Accounts[1].Id=$x.Accounts[0].Id},
  {param($x)$x.Accounts[1].Username=$x.Accounts[0].Username;$x.Accounts[1].NormalizedUsername=$x.Accounts[0].NormalizedUsername},
  {param($x)$x.Accounts[0].Enabled=$false},
  {param($x)$x.Accounts[0].PasswordRevision='../../escape'},
  {param($x)$x.LoginFailures=-1},
  {param($x)$x.CreatedUtc='bad time'},
  {param($x)Add-Member -InputObject $x -NotePropertyName 'Injected' -NotePropertyValue 'bad'},
  {param($x)$x.Accounts=@()}
 )
 $index=0
 foreach($mutation in $mutations){$index++;$bad=ConvertFrom-Json $goodText;& $mutation $bad;[IO.File]::WriteAllText($context.DatabasePath,(ConvertTo-Json -InputObject $bad -Depth 12),(New-Object Text.UTF8Encoding($false)));Assert-Rejected {Get-MedicalAccountsState $context} ('Strict account schema rejects mutation '+$index);Assert-Rejected {New-MedicalFirstAdministrator $context 'replacement' 'Нельзя' 'Replacement123'} ('Corruption cannot reopen first-admin setup '+$index);[IO.File]::WriteAllBytes($context.DatabasePath,$good)}
 foreach($badBytes in @([byte[]](0x7b),[byte[]](0xff,0xfe,0xfd),(New-Object byte[] 1048577))){[IO.File]::WriteAllBytes($context.DatabasePath,$badBytes);Assert-Rejected {Get-MedicalAccountsState $context} 'Truncated invalid UTF8 or oversized database fails closed';[IO.File]::WriteAllBytes($context.DatabasePath,$good)}
 [IO.File]::Delete($context.DatabasePath)
 Assert-Rejected {Get-MedicalAccountsState $context} 'Missing primary with last-good backup cannot be treated as first run'
 Assert-Rejected {New-MedicalFirstAdministrator $context 'replacement' 'Нельзя' 'Replacement123'} 'Missing primary cannot create replacement administrator'
 [IO.File]::WriteAllBytes($context.DatabasePath,$good)
 Assert-Check (Test-MedicalSession $admin) 'Restoring exact valid primary restores existing authorized session'
 # Portability does not use Windows identity, DPAPI, host keys or absolute paths in persisted DB.
 $moved=Join-Path $temp 'Другой ПК/Перемещенная программа';[void][IO.Directory]::CreateDirectory($moved)
 Copy-Item -LiteralPath $context.AccountsDirectory -Destination (Join-Path $moved 'Учетные записи') -Recurse
 $movedContext=Initialize-MedicalAccounts $moved;$movedSession=Invoke-MedicalAccountLogin $movedContext 'Admin' 'AdminPass_123'
 Assert-Check ($movedSession.UserId -ceq $admin.UserId) 'Copied program authenticates with same account on a different folder'
 Assert-Check ($movedSession.DataRoot -ceq [IO.Path]::Combine($moved,'Данные',$admin.UserId)) 'Moved private workspace resolves under new installation root'
 Assert-Check (-not ([IO.File]::ReadAllText($context.DatabasePath)).Contains($root)) 'Persisted credentials contain no original machine path'
 Assert-Check (-not [MedicalAccountsV71.Security]::Check($admin.Token,$movedContext.DatabasePath,$admin.UserId,(Read-TestDatabase $movedContext).Accounts[0].PasswordRevision)) 'Session ticket cannot cross to a copied installation context'
 $source=[IO.File]::ReadAllText((Join-Path $Project 'accounts-v71.ps1'))
 Assert-Check (-not ($source -match 'Invoke-WebRequest|HttpClient|WebClient|ProtectedData|GetCurrent\(')) 'Account module uses no network, DPAPI or Windows identity binding'
 Assert-Check (@(Get-ChildItem -LiteralPath $context.AccountsDirectory -Filter '*.tmp').Count -eq 0) 'Normal account transactions leave no temporary files'
 Write-Output ('ALL '+$script:checks+' ACCOUNT CHECKS PASSED')
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
