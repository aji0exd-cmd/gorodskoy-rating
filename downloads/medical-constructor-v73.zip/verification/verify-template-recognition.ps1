﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v73'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Recognition([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
function Assert-RecognitionThrows([scriptblock]$action,[string]$message){$thrown=$false;try{& $action}catch{$thrown=$true};Assert-Recognition $thrown $message}
function Import-RecognitionFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors|Out-String)}
 foreach($node in $ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}}
}
Import-RecognitionFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
foreach($file in @('universal.ps1','forms-v59.ps1','template-editor-v59.ps1','template-recognition-v71.ps1')){Import-RecognitionFunctions (Join-Path $Project $file)}
$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-recognition-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
function New-RecognitionFixture([string]$body){
 $path=Join-Path $temp ([guid]::NewGuid().ToString('N')+'.docx');New-UniversalTemplate $path (New-UniversalConfig);$model=Read-MedicalTemplateModel $path
 $xml=Read-MedicalEditorXml ([Text.Encoding]::UTF8.GetBytes(('<w:document xmlns:w="'+$script:ns+'"><w:body>'+$body+'<w:sectPr><w:pgSz w:w="11906" w:h="16838"/></w:sectPr></w:body></w:document>')))
 $model.Parts['word/document.xml'].Xml=$xml;$model.Parts['word/document.xml'].Modified=$false;Update-MedicalEditorParagraphs $model;return $model
}
function New-RecognitionEmptySchema{return [pscustomobject]@{Version=49;AutoTemplate=$false;Template='input.docx';Sections=@([pscustomobject]@{Id='template_fields';Title='Поля шаблона';Fields=@()})}}
function Get-RecognitionRows($plan,[string]$marker){return @($plan.Rows|Where-Object {$_.Marker -ceq $marker})}
try{
 Assert-Recognition ((Normalize-MedicalRecognitionLabel '  Ф. И. О. : ') -ceq 'фио') 'Russian label normalization ignores harmless punctuation'
 Assert-Recognition ((Normalize-MedicalRecognitionLabel 'Проведённое лечение') -ceq (Normalize-MedicalRecognitionLabel 'Проведенное лечение')) 'Russian yo/e label variants normalize consistently'
 Assert-Recognition ((Normalize-MedicalRecognitionLabel 'Дата рождения (ДД.ММ.ГГГГ)') -ceq 'датарождения') 'Date input hints do not prevent exact label matches'
 $schema=New-RecognitionEmptySchema
 $body=(New-UniversalParagraph 'Первичный осмотр')+(New-UniversalParagraph 'Ф.И.О.: __________')+(New-UniversalParagraph 'Дата рождения: 01.01.2000')+(New-UniversalParagraph 'Жалобы')+(New-UniversalParagraph '')+(New-UniversalParagraph 'Анамнез заболевания: _____')
 $model=New-RecognitionFixture $body;$xmlBefore=$model.Parts['word/document.xml'].Xml.OuterXml;$fileBefore=[Convert]::ToBase64String([IO.File]::ReadAllBytes($model.SourcePath));$schemaBefore=$schema|ConvertTo-Json -Depth 40
 $plan=Get-MedicalTemplateRecognitionPlan $model $schema
 Assert-Recognition $plan.NewSchema 'Empty imported form activates structure derivation'
 Assert-Recognition ((Get-RecognitionRows $plan 'PATIENT_NAME').Count -eq 1) 'FIO label produces patient-name marker'
 Assert-Recognition ((Get-RecognitionRows $plan 'PATIENT_NAME')[0].Selected) 'Blank underline answer is selected as a safe proposal'
 Assert-Recognition (-not (Get-RecognitionRows $plan 'PATIENT_BIRTH')[0].Selected) 'An existing birth-date answer requires an explicit review choice'
 Assert-Recognition ((Get-RecognitionRows $plan 'COMPLAINTS')[0].OriginalText -ceq '') 'Standalone heading targets its following blank paragraph'
 Assert-Recognition ((Get-RecognitionRows $plan 'COMPLAINTS')[0].Selected) 'Blank paragraph below an exact heading is selected'
 Assert-Recognition ((Get-RecognitionRows $plan 'ADMISSION_DATETIME').Count -eq 1 -and (Get-RecognitionRows $plan 'ADMISSION_DATETIME')[0].Action -ceq 'add-date') 'Missing admission date produces a separate insertion proposal'
 Assert-Recognition (-not (Get-RecognitionRows $plan 'ADMISSION_DATETIME')[0].Selected) 'Adding an absent admission date is never silently selected'
 Assert-Recognition ($plan.Missing.Count -gt 0) 'Unmatched known fields are reported for manual editing'
 Assert-Recognition ($xmlBefore -ceq $model.Parts['word/document.xml'].Xml.OuterXml) 'Analysis never mutates the working Word XML'
 Assert-Recognition ($schemaBefore -ceq ($schema|ConvertTo-Json -Depth 40)) 'Analysis never changes reusable form structure'
 Assert-RecognitionThrows {Apply-MedicalTemplateRecognitionPlan $model $schema $plan @((Get-RecognitionRows $plan 'PATIENT_NAME')[0].Id)} 'New structure cannot apply without the explicitly accepted date marker'
 $ids=@($plan.Rows|Where-Object {$_.Selected -or $_.Action -eq 'add-date'}|ForEach-Object {$_.Id})
 $result=Apply-MedicalTemplateRecognitionPlan $model $schema $plan $ids
 Assert-Recognition ($result.AppliedCount -eq $ids.Count) 'Applied count matches the reviewed checkbox selection'
 Assert-Recognition (@(Get-UniversalFields $result.Schema).Count -eq 3) 'New structure contains exactly selected recognized data fields'
 Assert-Recognition (@((Get-UniversalFields $result.Schema)|Where-Object {$_.Marker -ceq 'PATIENT_BIRTH'}).Count -eq 0) 'Unselected real patient answer does not become a reusable field'
 Assert-Recognition (@((Get-UniversalFields $result.Schema)|Where-Object {$_.System -ceq 'name'}).Count -eq 1) 'Recognized FIO retains patient role for case naming'
 Assert-Recognition ($result.Model.Parts['word/document.xml'].Xml.OuterXml.Contains('{{PATIENT_NAME}}') -and $result.Model.Parts['word/document.xml'].Xml.OuterXml.Contains('{{ADMISSION_DATETIME}}')) 'Accepted replacements and confirmed date exist in the result model'
 Assert-Recognition ($xmlBefore -ceq $model.Parts['word/document.xml'].Xml.OuterXml) 'Applying proposals works on a private copy of Word XML'
 Assert-Recognition ($schemaBefore -ceq ($schema|ConvertTo-Json -Depth 40)) 'Applying proposals keeps the caller schema unchanged'
 Assert-Recognition ($fileBefore -ceq [Convert]::ToBase64String([IO.File]::ReadAllBytes($model.SourcePath))) 'The uploaded DOCX is byte-for-byte unchanged by analysis and apply'
 Assert-MedicalEditorTemplateCoverage $result.Schema $result.Model
 Assert-Recognition $true 'Derived structure passes the real Word marker coverage validator'
 $export=Join-Path $temp 'recognized.docx';Write-MedicalTemplateModel $export $result.Model;$reread=Read-MedicalTemplateModel $export
 Assert-Recognition (@($reread.Paragraphs|Where-Object {$_.Text.Contains('{{COMPLAINTS}}')}).Count -eq 1) 'Recognized marker survives actual DOCX serialization and readback'
 $emptyChoices=@();Assert-RecognitionThrows {Apply-MedicalTemplateRecognitionPlan $model $schema $plan $emptyChoices} 'Empty selection cannot report a successful import'
 Assert-RecognitionThrows {Apply-MedicalTemplateRecognitionPlan $model $schema $plan @('unknown')} 'Unknown review row IDs are rejected'
 Assert-RecognitionThrows {Apply-MedicalTemplateRecognitionPlan $model $schema $plan @($ids[0],$ids[0])} 'Duplicate review row IDs are rejected'
 $changed=Copy-MedicalRecognitionModel $model;Set-MedicalTemplateParagraph $changed $changed.Paragraphs[0].Id 'Changed title'
 Assert-RecognitionThrows {Apply-MedicalTemplateRecognitionPlan $changed $schema $plan $ids} 'Stale proposals cannot apply after Word text changes'
 $changedSchema=Copy-MedicalFormSchema $schema;$changedSchema.Template='another.docx'
 Assert-RecognitionThrows {Apply-MedicalTemplateRecognitionPlan $model $changedSchema $plan $ids} 'Stale proposals cannot apply after schema changes'
 $original=$plan.Rows[0].OriginalText;$plan.Rows[0].OriginalText='tampered'
 Assert-RecognitionThrows {Apply-MedicalTemplateRecognitionPlan $model $schema $plan $ids} 'Tampered per-row source text is checked before applying'
 $plan.Rows[0].OriginalText=$original
 $existing=New-UniversalConfig;$existing.Template='existing.docx';$existing.AutoTemplate=$false
 $partial=Get-MedicalTemplateRecognitionPlan $model $existing;$partialId=(Get-RecognitionRows $partial 'PATIENT_NAME')[0].Id
 $partialResult=Apply-MedicalTemplateRecognitionPlan $model $existing $partial @($partialId)
 Assert-Recognition (@(Get-UniversalFields $partialResult.Schema).Count -eq @(Get-UniversalFields $existing).Count) 'Partial recognition preserves every existing schema field'
 Assert-Recognition ($partialResult.Schema.Template -ceq $existing.Template -and -not $partialResult.Schema.AutoTemplate) 'Partial recognition retains the existing Word reference and metadata'
 Assert-RecognitionThrows {Assert-MedicalEditorTemplateCoverage $partialResult.Schema $partialResult.Model} 'Existing editor Save still rejects incomplete marker coverage after partial recognition'
 # XML runs keep independently styled label/value/suffix fragments.
 $formatted=New-RecognitionFixture '<w:p><w:pPr><w:jc w:val="center"/><w:spacing w:after="80"/></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>Ф.И.О.: </w:t></w:r><w:r><w:rPr><w:i/></w:rPr><w:t>Ива</w:t></w:r><w:r><w:rPr><w:color w:val="004488"/></w:rPr><w:t>нов</w:t></w:r><w:r><w:rPr><w:u w:val="single"/></w:rPr><w:t> (подпись)</w:t></w:r></w:p>'
 $paragraph=$formatted.Paragraphs[0];$formatNs=Get-MedicalEditorNamespace $paragraph.Node.OwnerDocument;$pPr=$paragraph.Node.SelectSingleNode('./w:pPr',$formatNs).OuterXml;$rPr=@($paragraph.Node.SelectNodes('./w:r/w:rPr',$formatNs)|ForEach-Object {$_.OuterXml})
 Set-MedicalRecognitionTextRange $formatted $paragraph 8 6 '{{PATIENT_NAME}}'
 Assert-Recognition ($paragraph.Text -ceq 'Ф.И.О.: {{PATIENT_NAME}} (подпись)') 'Range replacement preserves label and untouched suffix across split runs'
 Assert-Recognition ($pPr -ceq $paragraph.Node.SelectSingleNode('./w:pPr',$formatNs).OuterXml) 'Range replacement preserves all paragraph properties'
 Assert-Recognition (($rPr -join '|') -ceq (@($paragraph.Node.SelectNodes('./w:r/w:rPr',$formatNs)|ForEach-Object {$_.OuterXml}) -join '|')) 'Range replacement preserves each original run style'
 Assert-Recognition ($paragraph.Node.SelectSingleNode('./w:r[2]/w:t',$formatNs).InnerText -ceq '{{PATIENT_NAME}}') 'Marker inherits the replaced value run rather than the bold label run'
 $tabbed=New-RecognitionFixture '<w:p><w:r><w:t>Ф.И.О.: </w:t><w:tab/><w:t>Иванов</w:t></w:r></w:p>'
 $tabBefore=$tabbed.Parts['word/document.xml'].Xml.OuterXml
 Assert-RecognitionThrows {Set-MedicalRecognitionTextRange $tabbed $tabbed.Paragraphs[0] 8 7 '{{PATIENT_NAME}}'} 'Unsafe replacement through tab controls is refused'
 Assert-Recognition ($tabBefore -ceq $tabbed.Parts['word/document.xml'].Xml.OuterXml) 'Refused structural range leaves XML unchanged'
 $table=New-RecognitionFixture '<w:tbl><w:tblPr/><w:tr><w:tc><w:tcPr/><w:p><w:r><w:t>Адрес регистрации</w:t></w:r></w:p></w:tc><w:tc><w:tcPr/><w:p><w:r><w:rPr><w:i/></w:rPr><w:t>___</w:t></w:r></w:p></w:tc></w:tr></w:tbl>'
 $tablePlan=Get-MedicalTemplateRecognitionPlan $table $schema;$tableRow=(Get-RecognitionRows $tablePlan 'PATIENT_ADDRESS')[0]
 Assert-Recognition ($tableRow.ParagraphId -ceq $table.Paragraphs[1].Id -and $tableRow.Selected) 'Table label maps to the adjacent blank cell, not to its label cell'
 $tablePartialPlan=Get-MedicalTemplateRecognitionPlan $table $existing;$tableResult=Apply-MedicalTemplateRecognitionPlan $table $existing $tablePartialPlan @((Get-RecognitionRows $tablePartialPlan 'PATIENT_ADDRESS')[0].Id)

 Assert-Recognition ($tableResult.Model.Parts['word/document.xml'].Xml.OuterXml.Contains('<w:tbl>') -and $tableResult.Model.Parts['word/document.xml'].Xml.OuterXml.Contains('{{PATIENT_ADDRESS}}')) 'Applying table recognition preserves the table structure'
 $ambiguous=Copy-MedicalFormSchema $existing;$customField=New-UniversalField 'custom_address' 'Адрес регистрации' 'CUSTOM_ADDRESS' 'text';$ambiguous.Sections[0].Fields+=@($customField)
 $ambiguousPlan=Get-MedicalTemplateRecognitionPlan $table $ambiguous;$ambiguousRow=@($ambiguousPlan.Rows|Where-Object {$_.Label -ceq 'Адрес регистрации'})[0]
 Assert-Recognition (-not $ambiguousRow.Marker -and -not $ambiguousRow.Selected -and $ambiguousRow.Reason.Contains('Неоднозначная')) 'Conflicting current-schema labels require manual marker selection'
 $custom=New-RecognitionFixture ((New-UniversalParagraph 'Иной осмотр')+(New-UniversalParagraph 'Особое поле: ____'))
 $customPlan=Get-MedicalTemplateRecognitionPlan $custom $schema;$customRow=@($customPlan.Rows|Where-Object {$_.Label -ceq 'Особое поле'})[0]
 Assert-Recognition (-not $customRow.Marker -and -not $customRow.Selected) 'Unknown label is shown for review without inventing a medical mapping'
 Set-MedicalRecognitionCustomField $customPlan $customRow
 Assert-Recognition ($customRow.Marker -cmatch '^FIELD_AUTO_[A-F0-9]{12}$' -and $customRow.Selected) 'Explicit create-field action gives an unknown label a safe unique marker'
 $customResult=Apply-MedicalTemplateRecognitionPlan $custom $schema $customPlan @($customRow.Id,(@($customPlan.Rows|Where-Object {$_.Action -eq 'add-date'})[0].Id))
 Assert-Recognition (@(Get-UniversalFields $customResult.Schema).Count -eq 1 -and @((Get-UniversalFields $customResult.Schema))[0].Label -ceq 'Особое поле') 'Explicit custom recognition creates one reusable field from the label, without answer defaults'
 $noMatch=New-RecognitionFixture (New-UniversalParagraph 'Обычный текст без полей и двоеточий')
 $noMatchPlan=Get-MedicalTemplateRecognitionPlan $noMatch $schema
 Assert-Recognition (@($noMatchPlan.Rows|Where-Object {$_.Action -ne 'add-date'}).Count -eq 0) 'Free prose is not guessed into medical fields'
 $existingDate=New-RecognitionFixture ((New-UniversalParagraph 'Осмотр')+(New-UniversalParagraph '{{ADMISSION_DATE}} {{ADMISSION_TIME}}')+(New-UniversalParagraph 'Жалобы: ____'))
 $existingDatePlan=Get-MedicalTemplateRecognitionPlan $existingDate $schema
 Assert-Recognition ($existingDatePlan.DatePresent -and @($existingDatePlan.Rows|Where-Object {$_.Action -eq 'add-date'}).Count -eq 0) 'Existing separate date and time markers do not cause a duplicate insertion'
 $dateResult=Apply-MedicalTemplateRecognitionPlan $existingDate $schema $existingDatePlan @((Get-RecognitionRows $existingDatePlan 'COMPLAINTS')[0].Id)
 Assert-Recognition (@(Get-UniversalFields $dateResult.Schema).Count -eq 1) 'Existing date markers satisfy derived-schema date coverage'
 $complex=New-RecognitionFixture '<w:p><w:hyperlink><w:r><w:t>Ф.И.О.: ___</w:t></w:r></w:hyperlink></w:p><w:p><w:r><w:t>Жалобы: ___</w:t></w:r></w:p>'
 $complexBefore=$complex.Parts['word/document.xml'].Xml.OuterXml;$complexPlan=Get-MedicalTemplateRecognitionPlan $complex $schema
 Assert-Recognition ((Get-RecognitionRows $complexPlan 'PATIENT_NAME').Count -eq 0 -and $complexPlan.Warnings.Count -eq 1) 'Complex Word element is skipped with an actionable review warning'
 Assert-Recognition ($complexBefore -ceq $complex.Parts['word/document.xml'].Xml.OuterXml) 'Skipping a complex Word element preserves its original XML'
 $repeatPlan=Get-MedicalTemplateRecognitionPlan $result.Model $result.Schema
 Assert-Recognition ((Get-RecognitionRows $repeatPlan 'PATIENT_NAME').Count -eq 0 -and (Get-RecognitionRows $repeatPlan 'COMPLAINTS').Count -eq 0 -and @($repeatPlan.Rows|Where-Object {$_.Action -eq 'add-date'}).Count -eq 0) 'Already marked fields and date are not marked again on repeated analysis'
 $inline=New-RecognitionFixture (New-UniversalParagraph 'Жалобы')
 $inlinePlan=Get-MedicalTemplateRecognitionPlan $inline $existing;$inlineResult=Apply-MedicalTemplateRecognitionPlan $inline $existing $inlinePlan @((Get-RecognitionRows $inlinePlan 'COMPLAINTS')[0].Id)
 Assert-Recognition ($inlineResult.Model.Paragraphs[0].Text -ceq 'Жалобы {{COMPLAINTS}}') 'Inline insertion separates the heading from its marker with a space'

 $atomicPlan=Get-MedicalTemplateRecognitionPlan $model $existing;$atomicRows=@($atomicPlan.Rows|Where-Object {$_.Marker -in @('PATIENT_NAME','DISEASE_HISTORY')});$atomicBefore=$model.Parts['word/document.xml'].Xml.OuterXml
 $atomicRows[1].Start=$atomicRows[1].OriginalText.Length+99
 Assert-RecognitionThrows {Apply-MedicalTemplateRecognitionPlan $model $existing $atomicPlan @($atomicRows|ForEach-Object {$_.Id})} 'A failed later replacement aborts the whole recognition batch'
 Assert-Recognition ($model.Parts['word/document.xml'].Xml.OuterXml -ceq $atomicBefore) 'A later batch error leaves earlier source paragraphs unchanged'
 $labelBoundary=New-RecognitionFixture ((New-UniversalParagraph 'Ф.И.О.:')+(New-UniversalParagraph 'Место работы: _____'))
 $boundaryPlan=Get-MedicalTemplateRecognitionPlan $labelBoundary $existing
 Assert-Recognition ((Get-RecognitionRows $boundaryPlan 'PATIENT_NAME')[0].ParagraphId -ceq $labelBoundary.Paragraphs[0].Id) 'An unknown next colon-label is never mistaken for the previous field answer'
 $customExistingPlan=Get-MedicalTemplateRecognitionPlan $custom $existing;$existingCustom=@($customExistingPlan.Rows|Where-Object {$_.Label -ceq 'Особое поле'})[0];Set-MedicalRecognitionCustomField $customExistingPlan $existingCustom
 $customExistingResult=Apply-MedicalTemplateRecognitionPlan $custom $existing $customExistingPlan @($existingCustom.Id)
 Assert-Recognition (@(Get-UniversalFields $customExistingResult.Schema).Count -eq @(Get-UniversalFields $existing).Count+1) 'Explicit custom fields are appended while preserving an existing form'
 Assert-Recognition ($customExistingResult.Schema.Sections[-1].Title -ceq 'Распознанные поля') 'New custom fields have an editable separate section'
 $customActual=New-UniversalField 'user_field' 'Пульс пациента' 'USER_PULSE' 'text'
 $ownSchema=New-RecognitionEmptySchema;$ownSchema.Sections[0].Fields=@($customActual)
 $ownModel=New-RecognitionFixture (New-UniversalParagraph 'Пульс пациента: ____');$ownPlan=Get-MedicalTemplateRecognitionPlan $ownModel $ownSchema
 Assert-Recognition ((Get-RecognitionRows $ownPlan 'USER_PULSE').Count -eq 1) 'Recognition follows the user current-schema label and marker rather than a fixed medical list'
 $multiline=New-RecognitionFixture '<w:p><w:r><w:t>Жалобы: ответ</w:t><w:br/><w:t>продолжение</w:t></w:r></w:p>'
 $multilinePlan=Get-MedicalTemplateRecognitionPlan $multiline $existing
 Assert-Recognition ((Get-RecognitionRows $multilinePlan 'COMPLAINTS').Count -eq 0 -and $multilinePlan.Warnings.Count -eq 1) 'A multiline answer with structural breaks is left for safe manual editing'

 $roleSchema=New-RecognitionEmptySchema;$roleSchema.Sections[0].Fields=@((New-UniversalField 'my_name' 'Клиент' 'CUSTOM_PATIENT' 'text' 'name'))
 $roleModel=New-RecognitionFixture (New-UniversalParagraph 'Фамилия, имя, отчество: ____');$rolePlan=Get-MedicalTemplateRecognitionPlan $roleModel $roleSchema
 Assert-Recognition ((Get-RecognitionRows $rolePlan 'CUSTOM_PATIENT').Count -eq 1) 'Patient-role aliases use a custom schema marker when the user renamed FIO'
 $numbered=New-RecognitionFixture (New-UniversalParagraph '2. Жалобы: ____');$numberedPlan=Get-MedicalTemplateRecognitionPlan $numbered $existing
 Assert-Recognition ((Get-RecognitionRows $numberedPlan 'COMPLAINTS').Count -eq 1) 'Numbered medical section labels are recognized without deleting their numbering'
 $sameCustomPlan=Get-MedicalTemplateRecognitionPlan $custom $schema;$sameCustom=@($sameCustomPlan.Rows|Where-Object {$_.Label -ceq 'Особое поле'})[0];Set-MedicalRecognitionCustomField $sameCustomPlan $sameCustom
 Assert-Recognition ($sameCustom.Marker -ceq $customRow.Marker) 'Custom marker generation is stable across application launches and language settings'
 $uiText=[IO.File]::ReadAllText((Join-Path $Project 'template-recognition-ui-v71.ps1'))
 $tokens=$null;$errors=$null;[void][Management.Automation.Language.Parser]::ParseInput($uiText,[ref]$tokens,[ref]$errors)
 Assert-Recognition (-not $errors.Count) 'Windows review UI passes the PowerShell parser'
 Assert-Recognition ($uiText.Contains("'Get-MedicalTemplateRecognitionPlan','Apply-MedicalTemplateRecognitionPlan','Update-MedicalRecognitionRow','Set-MedicalRecognitionCustomField'") -and $uiText.Contains('Get-Command $name -CommandType Function')) 'Review callbacks capture all private commands before GetNewClosure'
 Assert-Recognition ($uiText.Contains('Непустые ответы не отмечены автоматически') -and $uiText.Contains('удалите все исходные ответы пациента')) 'Review explicitly explains sample-answer handling before creating a reusable form'
 Assert-Recognition (-not ([IO.File]::ReadAllText((Join-Path $Project 'template-recognition-v71.ps1')) -match 'Invoke-WebRequest|Invoke-RestMethod|Net\.Http|WebClient|Start-Process')) 'Recognition module has no upload, download or network execution path'
 Write-Output ('Completed '+$script:checks+' template-recognition checks.')
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
