﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v73'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Check([bool]$test,[string]$label){if(-not $test){throw $label};$script:checks++;Write-Output ('PASS '+$label)}
function Assert-Reject([scriptblock]$operation,[string]$label,[string]$message=''){
 $failure='';try{& $operation | Out-Null}catch{$failure=$_.Exception.Message}
 Assert-Check ($failure -and (-not $message -or $failure.Contains($message))) $label
}
function Import-TestFunctions([string]$path,[string[]]$names=@()){
 $t=$null;$e=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$t,[ref]$e);if($e.Count){throw ($e|Out-String)}
 foreach($node in $ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
  if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}
 }
}
function Capture-Stage {}
function Set-TestRoot([string]$folder){
 [void][IO.Directory]::CreateDirectory($folder);$script:medicalProgramRoot=$folder;$script:medicalTemplatesFolder=Join-Path $folder 'Шаблоны'
}
function Get-TestTree([string]$folder){return ((Get-ChildItem -LiteralPath $folder -File -Recurse | Sort-Object FullName | ForEach-Object {$_.FullName+':'+(Get-FileHash -LiteralPath $_.FullName).Hash}) -join ';')}
function Write-TestBackup([string]$path,$data){
 $payload=[pscustomobject]@{Data=$data;FormSavedSignature='';CaseSavedSignature='';FormSignature=(Get-MedicalBackupFormSignature $data);CaseSignature=(Get-MedicalBackupCaseSignature $data)}
 $envelope=[pscustomobject]@{Format='MedicalConstructorSession';Version=1;CanonicalOrder='OrdinalV69';CreatedUtc=[datetime]::UtcNow.ToString('o');Closed=$false;PayloadJson=($payload|ConvertTo-Json -Depth 100 -Compress);Sha256=''}
 $envelope.Sha256=Get-MedicalBackupEnvelopeHash $envelope
 [IO.File]::WriteAllText($path,($envelope|ConvertTo-Json -Depth 5 -Compress),[Text.UTF8Encoding]::new($false))
}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-shared-diary-portability-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 Add-Type -AssemblyName System.IO.Compression;Add-Type -AssemblyName System.IO.Compression.FileSystem
 Import-TestFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart','Get-HospitalizationValues','Get-FullRegistration')
 foreach($module in @('universal.ps1','forms-v59.ps1','template-recovery-v66.ps1','template-editor-v59.ps1','template-editor-operations-v61.ps1','clinical-stages-v67.ps1','backup-v67.ps1','card-document-v65.ps1','hospitalization-document-v68.ps1','diary-period-v69.ps1')){Import-TestFunctions (Join-Path $Project $module)}
 Import-TestFunctions (Join-Path $Project 'universal-ui.ps1') @('Set-UniversalDemographics')
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 foreach($name in @('patientNameControl','patientBirthControl','patientAddressControl','streetControl','houseControl','apartmentControl')){Set-Variable -Scope Script -Name $name -Value ([pscustomobject]@{Text=''})}
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-16T10:20:30'};$script:hospitalControls=@{}
 $script:universalConfig=New-UniversalConfig;$script:universalValues=@{patient_name='TEST_PRIVATE_PATIENT_7316'};$script:universalDetails=@{}
 $script:stage='initial';$script:diaryIndex=1;$script:stageTemplates=@{initial='';diary='';discharge=''};$script:stageData=@{}
 $script:activeMedicalFormPath='';$script:activeMedicalFormName='Общая форма';$script:caseFile='';$script:caseFolder='';$script:caseLastSavedPatientName=$null;$script:source=''
 $script:medicalWorkspaceReady=$true;$script:medicalBackupPath='';$script:medicalBackupBusy=$false;$script:medicalBackupLastError='';$script:medicalBackupLegacyHashOrder=$false
 $script:medicalBackupFormSavedSignature='';$script:medicalBackupCaseSavedSignature='';$script:medicalBackupEditorDraft=$null;$script:medicalBackupRetainedDraft=$null;$script:medicalEditorRecoveryDraft=$null;$script:medicalBackupPendingDeferred=$false;$script:medicalActiveDiaryId=''
 $rootA=Join-Path $temp 'program-a';Set-TestRoot $rootA
 [void](Initialize-MedicalClinicalWorkspace)
 Assert-Check ($script:medicalClinicalForms.DiaryForm -and @($script:medicalClinicalForms.Diaries).Count -eq 0) 'New workspace owns a common diary form before any patient note exists'
 $common=Get-MedicalSharedDiarySchema;$common.DocumentTitle='Общий дневник: авторское оформление'
 $source=Join-Path $rootA 'Авторский общий дневник.docx';New-UniversalTemplate $source $common
 $common.AutoTemplate=$false;$common.Template=$source
 [void](Set-MedicalSharedDiarySchema $common)
 $sourceHash=Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($source))
 $portable=Get-MedicalClinicalPortableForms
 Assert-Check (@($portable.Diaries).Count -eq 0 -and $portable.DiaryForm.TemplateBase64) 'Portable zero-note form embeds the standalone common diary asset'
 Assert-Check ($portable.DiaryForm.TemplateSha256 -ceq $sourceHash) 'Standalone common diary Word checksum matches authored source bytes'
 $formPath=Join-Path $rootA 'Общая форма.mcform';[void](Write-MedicalForm $formPath $script:universalConfig 'Общая форма')
 Assert-Check (-not [IO.File]::ReadAllText($formPath).Contains('TEST_PRIVATE_PATIENT_7316')) 'Reusable form stores no patient answer while embedding the shared template'
 $rootB=Join-Path $temp 'program-b';Set-TestRoot $rootB
 $read=Read-MedicalForm $formPath;$restoredSource=Get-UniversalTemplatePath $read.StageForms.DiaryForm.Schema
 Assert-Check (@($read.StageForms.Diaries).Count -eq 0 -and [IO.File]::Exists($restoredSource)) 'Opening zero-note form in a new folder imports the common diary Word file'
 Assert-Check ((Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($restoredSource))) -ceq $sourceHash) 'Common diary custom Word bytes survive a real mcform roundtrip'
 Restore-MedicalClinicalFormData $read.StageForms
 $first=Add-MedicalClinicalDiary;Set-MedicalClinicalValue 'diary' $first.Id 'diary_complaints' 'TEST_NOTE_1'
 Set-MedicalDiaryDateCount $first.Id 2;Set-MedicalDiaryDates $first.Id ([datetime]'2026-10-02T10:00:00') ([datetime]'2026-10-04T11:00:00')
 $second=Add-MedicalClinicalDiary;Set-MedicalClinicalValue 'diary' $second.Id 'diary_complaints' 'TEST_NOTE_2'
 $script:medicalActiveDiaryId=$second.Id
 [void](Initialize-MedicalSessionBackup $rootB);$checkpoint=Write-MedicalSessionBackup;$savedPath=Join-Path $temp 'two-notes.mcbak';[IO.File]::Copy($checkpoint.Path,$savedPath)
 Assert-Check ($checkpoint.Payload.Data.ClinicalForms.DiaryForm.TemplateSha256 -ceq $sourceHash) 'Actual patient checkpoint contains the independent common diary template'
 $rootC=Join-Path $temp 'program-c';Set-TestRoot $rootC
 [void](Restore-MedicalSessionBackup $savedPath)
 Assert-Check ((Get-MedicalClinicalContext 'diary' $first.Id).Values.diary_complaints -ceq 'TEST_NOTE_1' -and (Get-MedicalClinicalContext 'diary' $second.Id).Values.diary_complaints -ceq 'TEST_NOTE_2') 'Actual backup recovery retains each patient note independently'
 $firstContext=Get-MedicalClinicalContext 'diary' $first.Id
 Assert-Check ($firstContext.DateCount -eq 2 -and $firstContext.DateTime -eq [datetime]'2026-10-02T10:00:00' -and $firstContext.EndDateTime -eq [datetime]'2026-10-04T11:00:00') 'Recovered patient note retains its own date count and full inspection period'
 $commonPath=Get-UniversalTemplatePath (Get-MedicalSharedDiarySchema)
 Assert-Check ([IO.File]::Exists($commonPath) -and (Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($commonPath))) -ceq $sourceHash) 'Recovery in a third program folder recreates exact common diary source'
 Remove-MedicalClinicalDiary $first.Id;Remove-MedicalClinicalDiary $second.Id;$script:medicalActiveDiaryId=''
 Assert-Check (@($script:medicalClinicalForms.Diaries).Count -eq 0 -and $script:medicalClinicalForms.DiaryForm) 'Deleting the last patient note retains the reusable common diary form'
 $script:medicalBackupPath='';[void](Initialize-MedicalSessionBackup $rootC);$zero=Write-MedicalSessionBackup
 Assert-Check (@($zero.Payload.Data.Clinical.Diaries).Count -eq 0 -and $zero.Payload.Data.ClinicalForms.DiaryForm.TemplateBase64) 'Zero-note checkpoint still embeds the common Word template after deletion'
 $data=Copy-MedicalBackupValue $zero.Payload.Data;$signature=Get-MedicalBackupFormSignature $data
 Assert-Check ($signature -ceq (Get-MedicalBackupFormSignature (Copy-MedicalBackupValue $data))) 'Common template contributes a stable form dirty-state signature'
 $changed=Copy-MedicalBackupValue $data;$changed.ClinicalForms.DiaryForm.Schema.DocumentTitle='Changed common diary title'
 Assert-Check ($signature -cne (Get-MedicalBackupFormSignature $changed)) 'Shared schema edit dirties the reusable form even with no patient notes'
 $changed=Copy-MedicalBackupValue $data;$bytes=[Convert]::FromBase64String($changed.ClinicalForms.DiaryForm.TemplateBase64)
 $mutable=Join-Path $temp 'changed-common.docx';[IO.File]::WriteAllBytes($mutable,$bytes)
 $archive=[IO.Compression.ZipFile]::Open($mutable,[IO.Compression.ZipArchiveMode]::Update)
 try{$entry=$archive.CreateEntry('customXml/shared-test.xml');$stream=$entry.Open();$testBytes=[Text.Encoding]::UTF8.GetBytes('<shared-test>changed source</shared-test>');try{$stream.Write($testBytes,0,$testBytes.Length)}finally{$stream.Dispose()}}finally{$archive.Dispose()}
 $changed.ClinicalForms.DiaryForm.TemplateBase64=[Convert]::ToBase64String([IO.File]::ReadAllBytes($mutable));$changed.ClinicalForms.DiaryForm.TemplateSha256=Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($mutable))
 Assert-Check ($signature -cne (Get-MedicalBackupFormSignature $changed)) 'Common Word content edit dirties the reusable form even without patient notes'
 Assert-Reject {Assert-MedicalCardOutputPath $commonPath} 'Save Card protects the common diary Word source when zero notes exist' 'исходного Word'
 Assert-Reject {Export-MedicalHospitalizationDocument $commonPath $true} 'Hospitalization export protects the standalone common diary source before rendering' 'исходного Word'
 Assert-Check ((Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($commonPath))) -ceq $sourceHash) 'Rejected card exports leave authored common Word bytes intact'
 $bad=Copy-MedicalBackupValue $data;$bad.ClinicalForms.DiaryForm.TemplateSha256='0'*64;$badPath=Join-Path $temp 'bad-common.mcbak';Write-TestBackup $badPath $bad
 $tree=Get-TestTree $rootC;$prior=Get-MedicalClinicalState|ConvertTo-Json -Depth 100 -Compress
 Assert-Reject {Restore-MedicalSessionBackup $badPath} 'Corrupt shared diary asset rejects checkpoint recovery before any import'
 Assert-Check ((Get-TestTree $rootC) -ceq $tree -and (Get-MedicalClinicalState|ConvertTo-Json -Depth 100 -Compress) -ceq $prior) 'Invalid shared asset cannot modify current note state or managed Word files'
 # Exercise the actual shared editor draft registration and disk recovery path.
 $script:stage='diary';$script:medicalActiveDiaryId='ignored-active-record'
 $model=Read-MedicalTemplateModel $commonPath;$schema=Get-MedicalSharedDiarySchema
 $token=Register-MedicalEditorDraft $schema $model ([pscustomobject]@{Schema=$schema;Model=$model}) $null $null 'edit' 'DiaryForm'
 $draft=Get-MedicalBackupEditorDraft
 Assert-Check ($draft.Scope -ceq 'DiaryForm' -and $draft.Stage -ceq 'diary' -and -not $draft.ClinicalId) 'Shared editor draft uses an explicit scope and no patient-note ID'
 $script:medicalActiveDiaryId='';$withDraft=Write-MedicalSessionBackup
 Assert-Check ($withDraft.Payload.Data.EditorDraft.Scope -ceq 'DiaryForm') 'A shared editor opened before Add is recoverable from an actual checkpoint'
 $script:medicalEditorRecoveryDraft=$withDraft.Payload.Data.EditorDraft;$recovered=Get-MedicalRecoveredEditorDraft
 Assert-Check ($recovered.Scope -ceq 'DiaryForm' -and $recovered.Model.Parts.ContainsKey('word/document.xml')) 'Recovered shared editor restores its scope and actual editable Word model'
 Unregister-MedicalEditorDraft $token $false $false;$script:medicalEditorRecoveryDraft=$null
 $base=Copy-MedicalBackupValue $withDraft.Payload.Data
 foreach($variation in @('UnknownScope','NullScope','WrongStage','WrongPurpose','RecordId','MissingCommon','LegacyEmptyId')){
  $invalid=Copy-MedicalBackupValue $base
  switch($variation){
   'UnknownScope'{$invalid.EditorDraft.Scope='unknown'}
   'NullScope'{$invalid.EditorDraft.Scope=$null}
   'WrongStage'{$invalid.EditorDraft.Stage='initial'}
   'WrongPurpose'{$invalid.EditorDraft.Purpose='new'}
   'RecordId'{$invalid.EditorDraft.ClinicalId='patient-note-id'}
   'MissingCommon'{$invalid.ClinicalForms.PSObject.Properties.Remove('DiaryForm')}
   'LegacyEmptyId'{$invalid.EditorDraft.PSObject.Properties.Remove('Scope')}
  }
  $invalidPath=Join-Path $temp ($variation+'.mcbak');Write-TestBackup $invalidPath $invalid
  Assert-Reject {Read-MedicalSessionBackup $invalidPath} ('Invalid shared editor scope binding rejects recovery: '+$variation)
 }
 Assert-Reject {Register-MedicalEditorDraft $schema $model $null $null $null 'new' 'DiaryForm'} 'Register rejects a shared diary scope disguised as a new initial form'
 Assert-Reject {Register-MedicalEditorDraft $schema $model $null $null $null 'edit' 'unknown'} 'Register rejects unknown shared editor scopes'
 $script:stage='initial'
 $token=Register-MedicalEditorDraft $schema $model $null $null $null 'edit' 'DiaryForm'
 Assert-Check ($script:medicalBackupEditorDraft.Stage -ceq 'diary' -and -not $script:medicalBackupEditorDraft.ClinicalId) 'Shared editor recovery registers its own diary stage independently of the current view'
 Unregister-MedicalEditorDraft $token $true $false
 foreach($name in @('backup-v67.ps1','card-document-v65.ps1','hospitalization-document-v68.ps1')){
  $bytes=[IO.File]::ReadAllBytes((Join-Path $Project $name));$text=[Text.Encoding]::UTF8.GetString($bytes)
  Assert-Check ($bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191 -and $text -notmatch '(?<!\r)\n') ('Windows source encoding retained: '+$name)
 }
 Write-Output ('TOTAL CHECKS '+$script:checks)
}finally{
 $script:medicalBackupEditorDraft=$null;$script:medicalBackupRetainedDraft=$null
 if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}
}
