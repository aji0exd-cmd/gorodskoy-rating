﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v73'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Preview([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
function Assert-PreviewRejected([scriptblock]$operation,[string]$message){$rejected=$false;try{& $operation}catch{$rejected=$true};Assert-Preview $rejected $message}

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
. (Join-Path $Project 'template-editor-v59.ps1')
. (Join-Path $Project 'word-preview-v62.ps1')
$realRenderer=(Get-Command Save-MedicalPreviewPage -CommandType Function).ScriptBlock
$realApplication=(Get-Command New-MedicalPreviewWordApplication -CommandType Function).ScriptBlock

# Native COM and GDI are the only mocked boundaries. Snapshot writing, XML
# validation, all pagination/control flow, cleanup and path guards are real.
function New-PreviewMock([int]$count=3){
 $script:mock=[pscustomobject]@{Application=$null;Document=$null;OpenPath='';OpenFlags=@();Repaginated=0;Closed=0;Quit=0;Rendered=(New-Object Collections.ArrayList);FailOpen=$false;FailRender=0;FailClose=$false;FailQuit=$false;MissingWord=$false;Pages=@();Snapshot=$null}
 for($index=1;$index -le $count;$index++){$script:mock.Pages+=@([pscustomobject]@{Width=595.3;Height=841.9;EnhMetaFileBits=([byte[]]@(1,2,$index))})}
 $pageCollection=[pscustomobject]@{Count=$count}
 $pageCollection | Add-Member ScriptMethod Item {param($index) return $script:mock.Pages[$index-1]}
 $pane=[pscustomobject]@{Pages=$pageCollection};$panes=[pscustomobject]@{First=$pane}
 $panes | Add-Member ScriptMethod Item {param($index) if($index -ne 1){throw 'Unexpected pane'};return $this.First}
 $window=[pscustomobject]@{View=([pscustomobject]@{Type=0});Panes=$panes}
 $document=[pscustomobject]@{ActiveWindow=$window}
 $document | Add-Member ScriptMethod Repaginate {$script:mock.Repaginated++}
 $document | Add-Member ScriptMethod Close {param($save) $script:mock.Closed++;if($save -ne 0){throw 'Must close without saving'};if($script:mock.FailClose){throw 'Simulated close failure'}}
 $documents=New-Object PSObject
 $documents | Add-Member ScriptMethod Open {
  param($path,$confirm,$readOnly,$recent)
  $script:mock.OpenPath=$path;$script:mock.OpenFlags=@($confirm,$readOnly,$recent)
  if($script:mock.FailOpen){throw 'Simulated document open failure'}
  $script:mock.Snapshot=Read-MedicalTemplateModel $path
  return $script:mock.Document
 }
 $application=[pscustomobject]@{Documents=$documents;Visible=$true;DisplayAlerts=1;AutomationSecurity=1}
 $application | Add-Member ScriptMethod Quit {param($save) $script:mock.Quit++;if($save -ne 0){throw 'Must quit without saving'};if($script:mock.FailQuit){throw 'Simulated quit failure'}}
 $script:mock.Application=$application;$script:mock.Document=$document
}
function New-MedicalPreviewWordApplication {
 if($script:mock.MissingWord){throw 'Microsoft Word is not installed'}
 return $script:mock.Application
}
function Save-MedicalPreviewPage([byte[]]$bytes,[double]$widthPoints,[double]$heightPoints,[string]$path,[int]$dpi){
 [void]$script:mock.Rendered.Add([pscustomobject]@{Bytes=$bytes;Width=$widthPoints;Height=$heightPoints;Path=$path;Dpi=$dpi})
 if($script:mock.FailRender -eq $script:mock.Rendered.Count){throw 'Simulated EMF rendering failure'}
 $png=[Convert]::FromBase64String('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aL1kAAAAASUVORK5CYII=')
 [IO.File]::WriteAllBytes($path,$png)
}

$temporary=Join-Path ([IO.Path]::GetTempPath()) ('medical-preview-tests-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temporary);$previews=New-Object Collections.ArrayList
try{
 $source=Join-Path $Project 'Универсальный первичный осмотр.docx'
 $model=Read-MedicalTemplateModel $source;$original=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
 $first=$model.Paragraphs[0];Set-MedicalTemplateParagraph $model $first.Id 'Edited preview snapshot'
 New-PreviewMock 3;$preview=New-MedicalWordPreview $model;[void]$previews.Add($preview)
 Assert-Preview $preview.Available 'Word preview succeeds using real snapshot writer with mocked native boundaries'
 Assert-Preview ($preview.Pages.Count -eq 3 -and $preview.PageCount -eq 3 -and -not $preview.Truncated) 'Every Word-rendered page is returned in document order'
 Assert-Preview ($script:mock.OpenFlags.Count -eq 3 -and $script:mock.OpenFlags[0] -eq $false -and $script:mock.OpenFlags[1] -eq $true -and $script:mock.OpenFlags[2] -eq $false) 'Private document opens read-only without conversion prompts or recent-file entry'
 Assert-Preview ($script:mock.OpenPath -ne $source -and (Split-Path -Parent $script:mock.OpenPath) -eq $preview.TempFolder) 'Word opens a temporary snapshot instead of the source template'
 Assert-Preview ($script:mock.Snapshot.Paragraphs[0].Text -eq 'Edited preview snapshot') 'Pending template edits are included in the rendered snapshot'
 Assert-Preview ($script:mock.Application.Visible -eq $false -and $script:mock.Application.DisplayAlerts -eq 0 -and $script:mock.Application.AutomationSecurity -eq 3) 'Owned Word instance is hidden with alerts suppressed and macros disabled'
 Assert-Preview ($script:mock.Document.ActiveWindow.View.Type -eq 3 -and $script:mock.Repaginated -eq 1) 'Word uses print layout and repaginates before reading pages'
 Assert-Preview ($script:mock.Closed -eq 1 -and $script:mock.Quit -eq 1) 'Owned document and Word instance close after successful render'
 Assert-Preview ($script:mock.Rendered.Count -eq 3 -and $script:mock.Rendered[1].Bytes[2] -eq 2 -and $script:mock.Rendered[1].Dpi -eq 120) 'Actual Word EMF bytes and resolution are passed to the raster boundary'
 Assert-Preview ($preview.Pages[0].WidthPoints -eq 595.3 -and $preview.Pages[0].HeightPoints -eq 841.9) 'Word page dimensions are preserved in points for UI scaling'
 Assert-Preview (@($preview.Pages | Where-Object {-not [IO.File]::Exists($_.Path)}).Count -eq 0) 'PNG paths remain available until UI disposes the preview'
 $successFolder=$preview.TempFolder;Remove-MedicalWordPreview $preview
 Assert-Preview (-not [IO.Directory]::Exists($successFolder)) 'Explicit preview disposal removes only its temporary files'
 Remove-MedicalWordPreview $preview
 Assert-Preview (-not [IO.Directory]::Exists($successFolder)) 'Preview disposal is idempotent'

 New-PreviewMock 3;$limited=New-MedicalWordPreview $model -maxPages 2 -dpi 90;[void]$previews.Add($limited)
 Assert-Preview ($limited.Available -and $limited.Truncated -and $limited.PageCount -eq 3 -and $limited.Pages.Count -eq 2) 'Page cap reports truncation without pretending the document is shorter'
 Assert-Preview ($script:mock.Rendered.Count -eq 2 -and $script:mock.Rendered[0].Dpi -eq 90) 'Page cap bounds rendering work and requested resolution is respected'
 Assert-Preview ($limited.Message.Contains('2') -and $limited.Message.Contains('3')) 'Truncation is explained to the user'

 New-PreviewMock;$script:mock.MissingWord=$true;$missing=New-MedicalWordPreview $model
 Assert-Preview (-not $missing.Available -and -not $missing.WordAvailable -and $missing.Pages.Count -eq 0 -and $null -eq $missing.TempFolder) 'Missing Word yields an unavailable preview without temporary files'
 Assert-Preview ($missing.Message -eq 'Microsoft Word is not installed') 'Unavailable Word has a clear explanation'
 Assert-Preview ($script:mock.Quit -eq 0) 'Missing Word never attempts to quit an unrelated application'

 New-PreviewMock;$script:mock.FailOpen=$true;$failed=New-MedicalWordPreview $model
 Assert-Preview (-not $failed.Available -and $failed.WordAvailable -and $failed.Pages.Count -eq 0) 'Document open failure returns no partial preview'
 Assert-Preview ($script:mock.Closed -eq 0 -and $script:mock.Quit -eq 1) 'Open failure quits the owned Word instance without closing a nonexistent document'
 Assert-Preview (-not [IO.Directory]::Exists((Split-Path -Parent $script:mock.OpenPath))) 'Open failure deletes its snapshot folder'
 Assert-Preview ($failed.Message.Contains('Simulated document open failure')) 'Render failure explains Word error'

 New-PreviewMock;$script:mock.FailRender=2;$failed=New-MedicalWordPreview $model
 Assert-Preview (-not $failed.Available -and $failed.Pages.Count -eq 0) 'Mid-render failure returns no incomplete page list'
 Assert-Preview ($script:mock.Closed -eq 1 -and $script:mock.Quit -eq 1) 'Mid-render failure still closes document and quits Word'
 Assert-Preview (-not [IO.Directory]::Exists((Split-Path -Parent $script:mock.OpenPath))) 'Mid-render failure deletes rendered pages and snapshot'

 New-PreviewMock 0;$empty=New-MedicalWordPreview $model
 Assert-Preview (-not $empty.Available -and $script:mock.Closed -eq 1 -and $script:mock.Quit -eq 1) 'A zero-page Word response is rejected and resources are closed'
 Assert-Preview (-not [IO.Directory]::Exists((Split-Path -Parent $script:mock.OpenPath))) 'A zero-page result leaves no snapshot folder'

 New-PreviewMock 1;$script:mock.FailClose=$true;$script:mock.FailQuit=$true;$cleanup=New-MedicalWordPreview $model;[void]$previews.Add($cleanup)
 Assert-Preview ($cleanup.Available -and $script:mock.Closed -eq 1 -and $script:mock.Quit -eq 1) 'Quit is attempted even if document close fails'

 New-PreviewMock
 Assert-PreviewRejected {New-MedicalWordPreview $model -maxPages 0} 'Zero page cap is rejected before Word starts'
 Assert-PreviewRejected {New-MedicalWordPreview $model -maxPages 101} 'Page cap above the safety limit is rejected'
 Assert-PreviewRejected {New-MedicalWordPreview $model -dpi 200} 'Excessive raster resolution is rejected before Word starts'
 Assert-PreviewRejected {& $realRenderer ([byte[]]@()) 595 842 (Join-Path $temporary 'bad.png') 120} 'Native raster boundary rejects empty Word image bytes before using GDI'
 Assert-PreviewRejected {& $realRenderer ([byte[]]@(1)) ([double]::NaN) 842 (Join-Path $temporary 'bad.png') 120} 'Native raster boundary rejects NaN page dimensions'
 Assert-PreviewRejected {& $realRenderer ([byte[]]@(1)) 595 ([double]::PositiveInfinity) (Join-Path $temporary 'bad.png') 120} 'Native raster boundary rejects infinite page dimensions'
 Assert-PreviewRejected {& $realRenderer ([byte[]]@(1)) 0 842 (Join-Path $temporary 'bad.png') 120} 'Native raster boundary rejects zero page width'
 Assert-PreviewRejected {& $realRenderer ([byte[]]@(1)) 20000 20000 (Join-Path $temporary 'bad.png') 120} 'Native raster boundary bounds bitmap allocation'

 $sentinel=Join-Path $temporary 'keep.txt';[IO.File]::WriteAllText($sentinel,'Keep user files')
 Assert-PreviewRejected {Remove-MedicalWordPreview ([pscustomobject]@{TempFolder=$temporary})} 'Preview cleanup rejects folders outside its own GUID naming scheme'
 Assert-Preview ([IO.File]::ReadAllText($sentinel) -eq 'Keep user files') 'Rejected cleanup preserves unrelated files'
 Assert-PreviewRejected {Remove-MedicalWordPreview ([pscustomobject]@{TempFolder=(Join-Path $temporary ('mc-word-preview-'+[guid]::NewGuid().ToString('N')))})} 'Preview cleanup rejects matching names outside the system temp root'
 Remove-MedicalWordPreview $null
 Assert-Preview ($original -eq (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash) 'All preview outcomes preserve the source template byte for byte'
 if([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT){Assert-PreviewRejected {& $realApplication} 'Native Word renderer reports unsupported host without attempting COM'}
 Write-Output ('Completed '+$script:checks+' Word preview checks. Word COM and EMF rasterization were mocked; native Windows Word rendering remains untested.')
}finally{
 foreach($preview in $previews){Remove-MedicalWordPreview $preview}
 if([IO.Directory]::Exists($temporary)){[IO.Directory]::Delete($temporary,$true)}
}
