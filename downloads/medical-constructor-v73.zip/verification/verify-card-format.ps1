﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v73'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Format([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
function Assert-FormatRejected([scriptblock]$operation,[string]$message){$failed=$false;try{& $operation | Out-Null}catch{$failed=$true};Assert-Format $failed $message}
Add-Type -AssemblyName System.IO.Compression.FileSystem
# Only native dialogs and display widgets are replaced. Actual preview renderer,
# Save Card, package metadata readers, form guards and restore routines run unchanged.
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @'
using System;
namespace System.Windows.Forms {
 public enum DialogResult {None,OK,Cancel}
 public sealed class SaveFileDialog {
  public static string OverrideName=""; public static int Calls=0; public static DialogResult Result=DialogResult.OK;
  public string Title {get;set;} public string Filter {get;set;} public string DefaultExt {get;set;} public bool AddExtension {get;set;}
  public string InitialDirectory {get;set;} public string FileName {get;set;} public bool OverwritePrompt {get;set;}
  public DialogResult ShowDialog(){Calls++;FileName=System.IO.Path.Combine(InitialDirectory,OverrideName.Length>0?OverrideName:FileName);return Result;}
 }
 public sealed class FolderBrowserDialog {public string Description {get;set;}public string SelectedPath {get;set;}public DialogResult ShowDialog(){return DialogResult.Cancel;}}
 public static class MessageBox {public static string Show(params object[] args){return "OK";}}
}
'@
function Import-FormatFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors | Out-String)}
 foreach($node in $ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
  if($names.Count -eq 0 -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}
 }
}
Import-FormatFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart','Get-InitialExamBindings','Sync-InitialExamValues','Get-StageKey','Capture-Stage','Get-FullRegistration','Get-HospitalizationValues','Set-SdtValue','Set-PatientDetails','Save-Document','Save-Case','Read-CaseDocument')
. (Join-Path $Project 'universal.ps1')
. (Join-Path $Project 'universal-ui.ps1')
. (Join-Path $Project 'document-actions.ps1')
. (Join-Path $Project 'card-document-v65.ps1')
. (Join-Path $Project 'forms-v59.ps1')
. (Join-Path $Project 'template-editor-v59.ps1')
. (Join-Path $Project 'template-recovery-v66.ps1')
. (Join-Path $Project 'forms-ui-v59.ps1')
. (Join-Path $Project 'workspace-settings.ps1')
$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
$script:fontFile=Join-Path $Project 'document-font.json'
function Set-FormatPart([string]$path,[string]$part,[string]$xml){
 $z=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update)
 try{$e=$z.GetEntry($part);if($e){$e.Delete()};Write-UniversalZipText $z $part $xml}finally{$z.Dispose()}
}
function Get-FormatParts([string]$path){
 $result=@{};$z=[IO.Compression.ZipFile]::OpenRead($path)
 try{foreach($entry in $z.Entries){$stream=$entry.Open();$memory=[IO.MemoryStream]::new();try{$stream.CopyTo($memory);$result[$entry.FullName]=[Convert]::ToBase64String($memory.ToArray())}finally{$memory.Dispose();$stream.Dispose()}}}finally{$z.Dispose()}
 return $result
}
function Get-FormatXml([string]$path,[string]$part){$z=[IO.Compression.ZipFile]::OpenRead($path);try{return (Get-XmlPart $z $part)}finally{$z.Dispose()}}
function Get-FormatMetadataFreeXml([string]$encoded,[bool]$relationships){
 $x=[xml][Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($encoded))
 foreach($node in @($x.DocumentElement.ChildNodes)){
  if($node -isnot [Xml.XmlElement]){continue}
  if($relationships -and $node.GetAttribute('Type') -eq 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXml' -and $node.GetAttribute('Target') -in @('../customXml/mc49.xml','../customXml/mc-case.xml')){[void]$x.DocumentElement.RemoveChild($node)}
  elseif(-not $relationships -and $node.GetAttribute('PartName') -in @('/customXml/mc49.xml','/customXml/mc-case.xml')){[void]$x.DocumentElement.RemoveChild($node)}
 }
 return $x.OuterXml
}
function Assert-PreviewParts([string]$preview,[string]$card,[string]$label){
 $a=Get-FormatParts $preview;$b=Get-FormatParts $card
 foreach($part in @($a.Keys | Sort-Object)){
  if($part -match '^customXml/'){continue}
  Assert-Format ($b.ContainsKey($part)) ($label+' retains preview part '+$part)
  if($part -eq 'word/_rels/document.xml.rels'){
   Assert-Format ((Get-FormatMetadataFreeXml $a[$part] $true) -ceq (Get-FormatMetadataFreeXml $b[$part] $true)) ($label+' preserves all visible document relationships')
  }elseif($part -eq '[Content_Types].xml'){
   Assert-Format ((Get-FormatMetadataFreeXml $a[$part] $false) -ceq (Get-FormatMetadataFreeXml $b[$part] $false)) ($label+' preserves all visible content types')
  }else{Assert-Format ($a[$part] -ceq $b[$part]) ($label+' matches preview bytes '+$part)}
 }
 foreach($part in @($b.Keys | Where-Object {-not $a.ContainsKey($_)})){Assert-Format ($part -ceq 'customXml/mc-case.xml') ($label+' adds only full case state, outside visible Word content: '+$part)}
}
function New-StyledConfig([string]$path){
 $fieldSpecs=@(@('name','Ф.И.О.','PATIENT_NAME','text','name'),@('birth','Дата рождения','PATIENT_BIRTH','text','birth'),@('address','Адрес','PATIENT_ADDRESS','text','address'),@('notes','Жалобы','NOTES','multiline',''),@('choice','Уточнение','CHOICE','choice_detail',''))
 $fields=@(foreach($spec in $fieldSpecs){$f=New-UniversalField $spec[0] $spec[1] $spec[2] $spec[3] $spec[4];if($f.Type -eq 'choice_detail'){$f.Options=@('Выбор & <проверка>','Другое');$f | Add-Member -NotePropertyName DetailWordPosition -NotePropertyValue 'marker';$f | Add-Member -NotePropertyName DetailMarker -NotePropertyValue 'CHOICE_DETAIL'};$f})
 return [pscustomobject]@{Version=49;AutoTemplate=$false;Template=$path;PreserveTemplateFormatting=$true;Sections=@([pscustomobject]@{Id='patient';Title='Мой осмотр';Fields=$fields})}
}
function New-StyledTemplate([string]$path,$config){
 New-UniversalTemplate $path $config
 $document=@'
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"><w:body>
<w:p><w:pPr><w:pStyle w:val="Heading1"/><w:jc w:val="center"/><w:spacing w:before="160" w:after="200"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Georgia" w:hAnsi="Georgia"/><w:b/><w:color w:val="17365D"/><w:sz w:val="36"/></w:rPr><w:t>МОЙ ПЕРВИЧНЫЙ ОСМОТР</w:t></w:r></w:p>
<w:p><w:pPr><w:jc w:val="both"/><w:ind w:left="180" w:right="220" w:firstLine="340"/><w:spacing w:line="280" w:lineRule="auto"/></w:pPr><w:r><w:rPr><w:i/><w:rFonts w:ascii="Cambria" w:hAnsi="Cambria"/><w:sz w:val="28"/></w:rPr><w:t>Ф.И.О.: {{PATIENT_</w:t></w:r><w:r><w:rPr><w:b/><w:color w:val="A31020"/></w:rPr><w:t>NAME}}</w:t></w:r></w:p>
<w:p><w:r><w:t>Дата рождения: {{PATIENT_BIRTH}}</w:t></w:r></w:p>
<w:p><w:r><w:t>Адрес: {{PATIENT_ADDRESS}}</w:t></w:r></w:p>
<w:p><w:r><w:t>Поступление: {{ADMISSION_DATETIME}}</w:t></w:r></w:p>
<w:tbl><w:tblPr><w:tblW w:w="8400" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders><w:top w:val="single" w:sz="12" w:color="1C3349"/><w:bottom w:val="single" w:sz="12" w:color="1C3349"/></w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w="2100"/><w:gridCol w:w="6300"/></w:tblGrid><w:tr><w:tc><w:tcPr><w:tcW w:w="2100" w:type="dxa"/><w:shd w:fill="DDEEFF"/></w:tcPr><w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Жалобы</w:t></w:r></w:p></w:tc><w:tc><w:tcPr><w:tcW w:w="6300" w:type="dxa"/></w:tcPr><w:p><w:pPr><w:jc w:val="both"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:sz w:val="22"/></w:rPr><w:t>{{NOTES}}</w:t></w:r></w:p></w:tc></w:tr></w:tbl>
<w:p><w:pPr><w:numPr><w:ilvl w:val="0"/><w:numId w:val="7"/></w:numPr></w:pPr><w:r><w:t>{{CHOICE}}</w:t></w:r><w:r><w:rPr><w:u w:val="single"/></w:rPr><w:t> — {{CHOICE_DETAIL}}</w:t></w:r></w:p>
<w:p><w:r><w:drawing><wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"><wp:extent cx="914400" cy="914400"/><wp:docPr id="1" name="Логотип"/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="0" name="logo.png"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="rIdLogo"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="914400" cy="914400"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>
<w:p><w:r><w:t>Нередактируемая формула </w:t></w:r><m:oMath><m:r><m:t>x+y=2</m:t></m:r></m:oMath></w:p>
<w:p><w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> PAGE </w:instrText></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r></w:p>
<w:sectPr><w:headerReference w:type="default" r:id="rIdHeader"/><w:footerReference w:type="default" r:id="rIdFooter"/><w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/><w:pgMar w:top="980" w:right="1320" w:bottom="1100" w:left="1700" w:header="500" w:footer="620" w:gutter="0"/><w:cols w:num="1" w:space="720"/></w:sectPr>
</w:body></w:document>
'@
 Set-FormatPart $path 'word/document.xml' $document
 Set-FormatPart $path 'word/header1.xml' ('<w:hdr xmlns:w="'+$script:ns+'"><w:p><w:pPr><w:jc w:val="right"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="126678"/></w:rPr><w:t>Моя клиника — {{PATIENT_NAME}}</w:t></w:r></w:p></w:hdr>')
 Set-FormatPart $path 'word/footer1.xml' ('<w:ftr xmlns:w="'+$script:ns+'"><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:i/><w:sz w:val="18"/></w:rPr><w:t>Поступление {{ADMISSION_DATETIME}}</w:t></w:r></w:p></w:ftr>')
 Set-FormatPart $path 'word/numbering.xml' ('<w:numbering xmlns:w="'+$script:ns+'"><w:abstractNum w:abstractNumId="5"><w:multiLevelType w:val="singleLevel"/><w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%1."/><w:lvlJc w:val="left"/><w:pPr><w:tabs><w:tab w:val="num" w:pos="450"/></w:tabs><w:ind w:left="450" w:hanging="220"/></w:pPr></w:lvl></w:abstractNum><w:num w:numId="7"><w:abstractNumId w:val="5"/></w:num></w:numbering>')
 Set-FormatPart $path 'word/settings.xml' ('<w:settings xmlns:w="'+$script:ns+'"><w:defaultTabStop w:val="720"/><w:compat/></w:settings>')
 Set-FormatPart $path 'word/fontTable.xml' ('<w:fonts xmlns:w="'+$script:ns+'"><w:font w:name="Georgia"/><w:font w:name="Arial"/><w:font w:name="Cambria"/></w:fonts>')
 $rels=Get-FormatXml $path 'word/_rels/document.xml.rels';$relNs=$rels.DocumentElement.NamespaceURI
 foreach($spec in @(@('rIdHeader','header','header1.xml'),@('rIdFooter','footer','footer1.xml'),@('rIdNum','numbering','numbering.xml'),@('rIdSettings','settings','settings.xml'),@('rIdFonts','fontTable','fontTable.xml'),@('rIdLogo','image','media/logo.png'),@('rIdTheme','theme','theme/theme1.xml'))){$r=$rels.CreateElement('Relationship',$relNs);$r.SetAttribute('Id',$spec[0]);$r.SetAttribute('Type','http://schemas.openxmlformats.org/officeDocument/2006/relationships/'+$spec[1]);$r.SetAttribute('Target',$spec[2]);[void]$rels.DocumentElement.AppendChild($r)}
 Set-FormatPart $path 'word/_rels/document.xml.rels' $rels.OuterXml
 $types=Get-FormatXml $path '[Content_Types].xml';$ctNs=$types.DocumentElement.NamespaceURI
 foreach($spec in @(@('/word/header1.xml','header'),@('/word/footer1.xml','footer'),@('/word/numbering.xml','numbering'),@('/word/settings.xml','settings'),@('/word/fontTable.xml','fontTable'))){$node=$types.CreateElement('Override',$ctNs);$node.SetAttribute('PartName',$spec[0]);$node.SetAttribute('ContentType','application/vnd.openxmlformats-officedocument.wordprocessingml.'+$spec[1]+'+xml');[void]$types.DocumentElement.AppendChild($node)}
 $node=$types.CreateElement('Default',$ctNs);$node.SetAttribute('Extension','png');$node.SetAttribute('ContentType','image/png');[void]$types.DocumentElement.AppendChild($node)
 $node=$types.CreateElement('Override',$ctNs);$node.SetAttribute('PartName','/word/theme/theme1.xml');$node.SetAttribute('ContentType','application/vnd.openxmlformats-officedocument.theme+xml');[void]$types.DocumentElement.AppendChild($node)
 Set-FormatPart $path '[Content_Types].xml' $types.OuterXml
 $original=[IO.Compression.ZipFile]::OpenRead((Join-Path $Project 'Шаблон первичного осмотра.docx'));try{$theme=Get-XmlPart $original 'word/theme/theme1.xml';Set-FormatPart $path 'word/theme/theme1.xml' $theme.OuterXml}finally{$original.Dispose()}
 $z=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update);try{$entry=$z.CreateEntry('word/media/logo.png');$out=$entry.Open();try{$bytes=[Convert]::FromBase64String('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jLQAAAABJRU5ErkJggg==');$out.Write($bytes,0,$bytes.Length)}finally{$out.Dispose()}}finally{$z.Dispose()}
}
function Set-FormatFixture([string]$root,$config){
 # This suite intentionally keeps the legacy stage renderer active. Full modern
 # hospitalization preview/card equality is verified through actual UI actions.
 $script:medicalClinicalForms=$null;$script:medicalClinicalState=$null;$script:medicalClinicalBindings=@{}
 $script:medicalProgramRoot=$root;$script:medicalTemplatesFolder=Join-Path $root 'Шаблоны'
 $script:universalConfig=Copy-UniversalObject $config
 $script:universalValues=@{name='Пациент & <Иванов>';birth='02.03.1984';address='Ирбит, Ленина, 1';notes="Первая строка`r`nВторая строка";choice='Выбор & <проверка>'}
 $script:universalDetails=@{choice='Текущее уточнение'};$script:universalInputs=@{};$script:universalDetailInputs=@{choice=[pscustomobject]@{Text='Текущее уточнение'}}
 foreach($field in Get-UniversalFields $script:universalConfig){$script:universalInputs[[string]$field.Id]=[pscustomobject]@{Text=[string]$script:universalValues[[string]$field.Id]}}
 $script:universalMultiInputs=@{};$script:universalRepeatInputs=@{}
 foreach($name in @('patientNameControl','patientBirthControl','patientAddressControl','streetControl','houseControl','apartmentControl')){Set-Variable -Scope Script -Name $name -Value ([pscustomobject]@{Text=''})}
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-13T20:15:00'}
 $script:stage='initial';$script:source=$config.Template;$script:fields=@();$script:controls=@();$script:hospitalControls=@{count=[pscustomobject]@{Text='Повторно'}}
 $script:stageData=@{diary_1=@('Первый дневник');diary_2=@('Второй дневник');discharge=@('Выписка')};$script:stageTemplates=@{initial=$config.Template;diary=$config.Template;discharge=$config.Template};$script:diaryIndex=2
 $script:caseFolder=$root;$script:caseFile='';$script:caseLastSavedPatientName=$null
 [System.Windows.Forms.SaveFileDialog]::Calls=0;[System.Windows.Forms.SaveFileDialog]::OverrideName='';[System.Windows.Forms.SaveFileDialog]::Result='OK'
 Capture-Universal
}
function New-LegacyCard([string]$path,$record){
 $payload=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($record | ConvertTo-Json -Depth 40 -Compress)))
 $z=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Create)
 try{Write-UniversalZipText $z 'word/document.xml' ('<w:document xmlns:w="'+$script:ns+'"><w:body><w:p><w:r><w:t>Старая карта</w:t></w:r></w:p><w:p><w:r><w:rPr><w:vanish/></w:rPr><w:t>MC_CASE_V24:'+$payload+':END_MC_CASE</w:t></w:r></w:p><w:sectPr/></w:body></w:document>')}finally{$z.Dispose()}
}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-card-format-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 $source=Join-Path $temp 'Мой оформленный шаблон.docx';$config=New-StyledConfig $source;New-StyledTemplate $source $config
 $sourceBytes=[IO.File]::ReadAllBytes($source);Set-FormatFixture $temp $config
 $preview=Join-Path $temp 'Предпросмотр.docx';Export-CurrentStageDocument $preview;Save-Case;$card=$script:caseFile
 Assert-PreviewParts $preview $card 'Initial Save Card'
 $body=Get-FormatXml $card 'word/document.xml';$n=[Xml.XmlNamespaceManager]::new($body.NameTable);$n.AddNamespace('w',$script:ns);$n.AddNamespace('m','http://schemas.openxmlformats.org/officeDocument/2006/math')
 $text=(($body.SelectNodes('//w:t',$n) | ForEach-Object {$_.InnerText}) -join '')
 Assert-Format ($text.Contains('Пациент & <Иванов>') -and $text.Contains('Первая строка') -and $text.Contains('Вторая строка') -and $text.Contains('Текущее уточнение')) 'Saved clinical body shows current answers and clarifications, with XML characters decoded'
 Assert-Format (-not $text.Contains('MC_CASE_V24:') -and -not $text.Contains('КАРТА ГОСПИТАЛИЗАЦИИ') -and $body.SelectNodes('//w:vanish',$n).Count -eq 0) 'Saving a card adds no visible or hidden paragraphs that can change pagination'
 Assert-Format ($body.SelectSingleNode('//w:sectPr/w:pgSz',$n).GetAttribute('orient',$script:ns) -ceq 'landscape' -and $body.SelectSingleNode('//w:sectPr/w:pgMar',$n).GetAttribute('left',$script:ns) -ceq '1700') 'Card retains authored landscape page geometry and custom margins'
 Assert-Format ($body.SelectNodes('//w:tbl',$n).Count -eq 1 -and $body.SelectNodes('//m:oMath',$n).Count -eq 1 -and $body.SelectNodes('//w:fldChar',$n).Count -eq 2 -and $body.SelectNodes('//w:drawing',$n).Count -eq 1) 'Card retains tables, formula, inline image and field-code architecture'
 $record=Read-CaseDocument $card
 Assert-Format ($record.patientName -ceq 'Пациент & <Иванов>' -and $record.universal.Values.name -ceq 'Пациент & <Иванов>' -and $record.universal.Values.notes -ceq "Первая строка`r`nВторая строка") 'Full custom XML card state preserves exact patient and multiline answers'
 Assert-Format ($record.universal.Details.choice -ceq 'Текущее уточнение' -and $record.stages.diary_1[0] -ceq 'Первый дневник' -and $record.stages.diary_2[0] -ceq 'Второй дневник' -and $record.stages.discharge[0] -ceq 'Выписка' -and $record.diaryCount -eq 2) 'Full card state retains clarification, every diary and discharge answers'
 Assert-Format ($record.templates.initial -ceq $source -and $record.templates.diary -ceq $source -and $record.templates.discharge -ceq $source -and $record.hospitalization.count -ceq 'Повторно') 'Full card state retains template references and hospitalization fields'
 Restore-UniversalState $record.universal
 Assert-Format ($script:universalValues.notes -ceq "Первая строка`r`nВторая строка" -and $script:universalDetails.choice -ceq 'Текущее уточнение' -and $script:universalConfig.PreserveTemplateFormatting) 'Actual state restore retains answers, clarification and template-format flag'
 Assert-Format ([Convert]::ToBase64String([IO.File]::ReadAllBytes($source)) -ceq [Convert]::ToBase64String($sourceBytes)) 'Preview and Save Card leave the source Word template unchanged'
 Assert-FormatRejected {Test-MedicalTemplateBytes ([IO.File]::ReadAllBytes($card))} 'A formatted card containing patient answers cannot be imported as a reusable Word template'
 $legacyPath=Join-Path $temp 'Карта v64.docx';New-LegacyCard $legacyPath $record;$legacy=Read-CaseDocument $legacyPath
 Assert-Format ($legacy.patientName -ceq $record.patientName -and $legacy.universal.Values.notes -ceq $record.universal.Values.notes -and $legacy.stages.diary_2[0] -ceq 'Второй дневник') 'v64 hidden-state cards remain readable with complete state'
 foreach($bad in @('<case xmlns="urn:wrong">QQ==</case>','<mc:case xmlns:mc="urn:medical-constructor:case:v65">%%%not-base64%%%</mc:case>',('<mc:case xmlns:mc="urn:medical-constructor:case:v65">'+[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes('{bad json'))+'</mc:case>'))){
  $badPath=Join-Path $temp ('bad-case-'+[guid]::NewGuid().ToString('N')+'.docx');Copy-Item -LiteralPath $card -Destination $badPath;Set-FormatPart $badPath 'customXml/mc-case.xml' $bad
  Assert-FormatRejected {Read-CaseDocument $badPath} 'Malformed new card metadata is rejected instead of losing or silently substituting case state'
 }
 # Draft saves preserve unfinished work. Preview and Print continue strict validation.
 Set-FormatFixture $temp $config;$script:universalInputs.notes.Text='';$script:universalInputs.birth.Text='неверная дата';$script:universalInputs.choice.Text='';$script:universalDetailInputs.choice.Text='Уточнение без выбора'
 Assert-FormatRejected {Export-CurrentStageDocument (Join-Path $temp 'strict-missing.docx')} 'Strict preview rejects missing required answers'
 Save-Case;$draft=Read-CaseDocument $script:caseFile
 Assert-Format ([string]$draft.universal.Values.notes -ceq '' -and $draft.universal.Values.birth -ceq 'неверная дата' -and [string]$draft.universal.Values.choice -ceq '' -and $draft.universal.Details.choice -ceq 'Уточнение без выбора') 'Save Card preserves an unfinished form, typed invalid date and clarification without a choice'
 $draftBody=Get-FormatXml $script:caseFile 'word/document.xml';Assert-Format ($draftBody.OuterXml.Contains('неверная дата') -and $draftBody.OuterXml.Contains('Уточнение без выбора')) 'Draft clinical document displays the current incomplete answers'
 $script:universalInputs.notes.Text='Заполнено';$script:universalInputs.choice.Text='Другое';$script:universalDetailInputs.choice.Text='';Assert-FormatRejected {Export-CurrentStageDocument (Join-Path $temp 'strict-date.docx')} 'Strict preview rejects an invalid typed birth date even when all required fields are filled'
 # Saving cannot overwrite the source template and failed writes preserve an older card.
 Set-FormatFixture $temp $config;Save-Case;$validPath=$script:caseFile;$validBytes=[IO.File]::ReadAllBytes($validPath)
 $script:universalInputs.name.Text='Изменённый пациент';[System.Windows.Forms.SaveFileDialog]::OverrideName=$source
 Assert-FormatRejected {Save-Case} 'Save Card refuses the source Word template as a destination'
 Assert-Format ($script:caseFile -ceq $validPath -and [Convert]::ToBase64String([IO.File]::ReadAllBytes($source)) -ceq [Convert]::ToBase64String($sourceBytes)) 'Source overwrite rejection preserves the previous card path and source bytes'
 [System.Windows.Forms.SaveFileDialog]::OverrideName='failed-replacement.docx';$beforeChoice=$script:caseLastSavedPatientName
 $script:universalConfig.Template=Join-Path $temp 'source-does-not-exist.docx';Assert-FormatRejected {Save-Case} 'Unavailable template rejects Save Card before committing a new destination'
 Assert-Format ($script:caseFile -ceq $validPath -and $script:caseLastSavedPatientName -ceq $beforeChoice -and [Convert]::ToBase64String([IO.File]::ReadAllBytes($validPath)) -ceq [Convert]::ToBase64String($validBytes) -and -not (Test-Path -LiteralPath (Join-Path $temp 'failed-replacement.docx'))) 'Failed clinical export leaves the previous card bytes, path and name baseline intact'
 # A real malformed template creates a clinical temporary package but fails metadata insertion.
 Set-FormatFixture $temp $config;Save-Case;$metadataPath=$script:caseFile;$metadataBytes=[IO.File]::ReadAllBytes($metadataPath);$metadataName=$script:caseLastSavedPatientName
 $partialSource=Join-Path $temp 'Missing content types.docx';Copy-Item -LiteralPath $source -Destination $partialSource
 $partialZip=[IO.Compression.ZipFile]::Open($partialSource,[IO.Compression.ZipArchiveMode]::Update);try{$partialZip.GetEntry('[Content_Types].xml').Delete()}finally{$partialZip.Dispose()}
 $script:universalConfig.Template=$partialSource;Assert-FormatRejected {Save-Case} 'Actual metadata insertion rejects a malformed clinical package after export'
 Assert-Format ($script:caseFile -ceq $metadataPath -and $script:caseLastSavedPatientName -ceq $metadataName -and [Convert]::ToBase64String([IO.File]::ReadAllBytes($metadataPath)) -ceq [Convert]::ToBase64String($metadataBytes)) 'Actual metadata insertion failure preserves the complete earlier card and its destination state'
 # A simulated OS commit failure happens after the real document and metadata were fully built.
 Set-FormatFixture $temp $config;Save-Case;$oldPath=$script:caseFile;$oldBytes=[IO.File]::ReadAllBytes($oldPath);$oldName=$script:caseLastSavedPatientName
 $actualCommit=${function:Complete-MedicalCardDocumentSave};function Complete-MedicalCardDocumentSave([string]$temporary,[string]$path){throw 'Simulated destination locked during final commit'}
 try{Assert-FormatRejected {Save-Case} 'An OS failure during final card replacement is surfaced to the user'}finally{Set-Item Function:Complete-MedicalCardDocumentSave $actualCommit}
 Assert-Format ($script:caseFile -ceq $oldPath -and $script:caseLastSavedPatientName -ceq $oldName -and [Convert]::ToBase64String([IO.File]::ReadAllBytes($oldPath)) -ceq [Convert]::ToBase64String($oldBytes)) 'A final-commit failure preserves the complete previous card and path/name state'
 # Diary/discharge use the same production legacy Word-control pipeline for Preview and Card.
 foreach($stageToTest in @('diary','discharge')){
  Set-FormatFixture $temp $config;$script:stage=$stageToTest;$script:patientNameControl.Text='Текущий пациент этапа';$script:patientBirthControl.Text='03.04.1986';$script:patientAddressControl.Text='Новый адрес'
  $legacySource=Join-Path $temp ($stageToTest+'-source.docx');Copy-Item -LiteralPath $source -Destination $legacySource
  $legacyBody=Get-FormatXml $legacySource 'word/document.xml';$legacyN=[Xml.XmlNamespaceManager]::new($legacyBody.NameTable);$legacyN.AddNamespace('w',$script:ns)
  $notesNode=@($legacyBody.SelectNodes('//w:t',$legacyN) | Where-Object {$_.InnerText -ceq '{{NOTES}}'})[0];$notesRun=$notesNode.ParentNode
  $sdt=$legacyBody.CreateElement('w','sdt',$script:ns);$sdt.InnerXml='<w:sdtPr xmlns:w="'+$script:ns+'"><w:id w:val="51"/><w:alias w:val="Текст этапа"/><w:text/></w:sdtPr><w:sdtContent xmlns:w="'+$script:ns+'">'+$notesRun.OuterXml+'</w:sdtContent>'
  [void]$notesRun.ParentNode.ReplaceChild($sdt,$notesRun);Set-FormatPart $legacySource 'word/document.xml' $legacyBody.OuterXml;$script:source=$legacySource;$script:stageTemplates[$stageToTest]=$legacySource
  $script:fields=@([pscustomobject]@{HospitalKey='';IsAddress=$false;ClinicalKey='';Label='Текст этапа'});$script:controls=@([pscustomobject]@{Text=('Заполненный текст '+$stageToTest)});$script:hospitalControls=@{}
  $stagePreview=Join-Path $temp ($stageToTest+'-preview.docx');Export-CurrentStageDocument $stagePreview;Save-Case;$stageCard=$script:caseFile
  Assert-PreviewParts $stagePreview $stageCard ('Save Card '+$stageToTest)
  $stageRecord=Read-CaseDocument $stageCard
  Assert-Format ($stageRecord.patientName -ceq 'Текущий пациент этапа' -and $stageRecord.universal.Values.name -ceq 'Текущий пациент этапа') ('Saving '+$stageToTest+' uses current stage patient identity while preserving complete case state')
  $renderedStage=Get-FormatXml $stageCard 'word/document.xml';$stageKey=if($stageToTest -eq 'diary'){'diary_2'}else{'discharge'}
  Assert-Format ($renderedStage.OuterXml.Contains('Заполненный текст '+$stageToTest) -and $stageRecord.stages.$stageKey[0] -ceq ('Заполненный текст '+$stageToTest) -and $stageRecord.universal.Values.notes -ceq "Первая строка`r`nВторая строка") ('Saving '+$stageToTest+' renders its real Word control and retains initial-stage answers')
  Assert-FormatRejected {Test-MedicalTemplateBytes ([IO.File]::ReadAllBytes($stageCard))} ('Saved '+$stageToTest+' card is rejected as a reusable template even without initial mc49 metadata')
  $parts=Get-FormatParts $stageCard;Assert-Format (-not $parts.ContainsKey('customXml/mc49.xml') -and $parts.ContainsKey('customXml/mc-case.xml')) ('Saved '+$stageToTest+' stores complete case metadata without depending on initial-form metadata')
  $script:patientBirthControl.Text='черновик даты';$script:patientNameControl.Text='Черновик '+$stageToTest;Save-Case;$otherDraft=Read-CaseDocument $script:caseFile
  Assert-Format ($otherDraft.birthYear -ceq 'черновик даты' -and $otherDraft.universal.Values.birth -ceq 'черновик даты') ('Save Card '+$stageToTest+' preserves an unfinished patient birth-date entry')
  Assert-FormatRejected {Export-CurrentStageDocument (Join-Path $temp ($stageToTest+'-invalid-preview.docx'))} ('Strict '+$stageToTest+' preview continues to reject an invalid birth date')
 }
 Assert-Format (@(Get-ChildItem -LiteralPath $temp -Recurse | Where-Object {$_.Name -match '\.(tmp|font)$'}).Count -eq 0) 'All preview/card atomic export and metadata temporary files are cleaned up'
 Write-Output ('PASS '+$script:checks+' card-format checks')
}finally{Remove-Item -LiteralPath $temp -Recurse -Force}
