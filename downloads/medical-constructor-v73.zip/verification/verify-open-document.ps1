﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v73'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Open([bool]$condition,[string]$label){if(-not $condition){throw $label};$script:checks++;Write-Output ('PASS '+$label)}
function Assert-OpenRejected([scriptblock]$operation,[string]$label){$failed=$false;try{& $operation | Out-Null}catch{$failed=$true};Assert-Open $failed $label}
function Import-OpenFunctions([string]$path,[string[]]$names=@()){
 $t=$null;$e=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$t,[ref]$e);if($e.Count){throw ($e|Out-String)}
 foreach($node in $ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}}
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @'
namespace Windows.Forms {public static class MessageBox {public static string Show(params object[] args){return "OK";}}}
'@
Import-OpenFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart','Read-CaseDocument')
foreach($file in @('universal.ps1','forms-v59.ps1','template-editor-v59.ps1','template-recovery-v66.ps1','card-document-v65.ps1','offline-import-v71.ps1','template-recognition-v71.ps1','clinical-stages-v67.ps1','open-document-v72.ps1')){Import-OpenFunctions (Join-Path $Project $file)}
Import-OpenFunctions (Join-Path $Project 'forms-ui-v59.ps1') @('Import-MedicalLocalTemplateChoice')
$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
$root=Join-Path ([IO.Path]::GetTempPath()) ('mc-open-document-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($root)
function Write-OpenPart([string]$path,[string]$name,[string]$text){$z=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update);try{foreach($entry in @($z.Entries | Where-Object {$_.FullName -ceq $name})){$entry.Delete()};Write-UniversalZipText $z $name $text}finally{$z.Dispose()}}
function New-OpenCopy([string]$name){$path=Join-Path $root $name;[IO.File]::Copy($script:sourcePath,$path,$true);return $path}
function New-OpenState([string]$name,[string]$state){$path=New-OpenCopy $name;Write-OpenPart $path 'customXml/mc49.xml' $state;return $path}
function New-OpenText([string]$name,[string]$text,[bool]$hidden=$false){$path=New-OpenCopy $name;$runProperties=if($hidden){'<w:rPr><w:vanish/></w:rPr>'}else{''};Write-OpenPart $path 'word/document.xml' ('<w:document xmlns:w="'+$script:ns+'"><w:body><w:p><w:r>'+$runProperties+'<w:t>'+[Security.SecurityElement]::Escape($text)+'</w:t></w:r></w:p></w:body></w:document>');return $path}
$script:guardCalls=New-Object Collections.ArrayList;$script:blockedPath=''
function Assert-MedicalAccountPath([string]$path){[void]$script:guardCalls.Add($path);if($path -eq $script:blockedPath){throw 'Other employee file denied intentionally'}}
$script:dispatch=New-Object Collections.ArrayList;$script:confirm=$true;$script:editorMode='cancel';$script:recognitionMode='cancel';$script:importMode='ok'
function Confirm-MedicalFormReset {[void]$script:dispatch.Add('confirm');return $script:confirm}
function Open-CasePath([string]$path){[void]$script:dispatch.Add('card');$null=Read-CaseDocument $path}
function Open-UniversalDocument([string]$path){[void]$script:dispatch.Add('stage')}
function Show-MedicalFormTemplateEditor($owner,$schema,$draft,$purpose,$saveContext){
 [void]$script:dispatch.Add('editor:'+ $purpose)
 Assert-Open ($purpose -ceq 'new' -and -not $draft) 'Ordinary Word always enters a new reusable form editor' | Out-Host
 Assert-Open ($saveContext.Purpose -ceq 'new' -and -not $saveContext.Path -and $saveContext.Name -notin @('CURRENT FORM','Новая форма')) 'Imported editor Save uses the source title and never overwrites the current form path' | Out-Host
 Assert-Open (-not $schema.PSObject.Properties['Values'] -and -not $schema.PSObject.Properties['Details']) 'Candidate schema contains no patient answer maps' | Out-Host
 if($script:editorMode -eq 'error'){throw 'Editor failed before accepting intentionally'}
 if($script:editorMode -eq 'cancel'){return $null}
 return [pscustomobject]@{Schema=$schema;SavedFormPath='';SavedStageForms=$null;SavedFormName='Шаблон из Word'}
}
function Use-MedicalFormSchema($schema,[string]$name,[string]$path,$stageForms){
 [void]$script:dispatch.Add('use')
 $script:universalConfig=Copy-MedicalFormSchema $schema;$script:universalValues=@{};$script:universalDetails=@{};$script:medicalClinicalState=[pscustomobject]@{Diaries=@();Discharge=$null};$script:stage='initial';$script:caseFile='';$script:activeMedicalFormPath=$path
}
function Set-MedicalEditorSavedFormMetadata($result){[void]$script:dispatch.Add('metadata')}
$script:realImportLocal=(Get-Command Import-MedicalLocalDocument -CommandType Function).ScriptBlock
function Import-MedicalLocalDocument([string]$Path,$Owner){[void]$script:dispatch.Add('import');if($script:importMode -eq 'error'){throw 'Import failed intentionally'};if($script:importMode -eq 'cancel'){return $null};& $script:realImportLocal $Path $Owner}
function Invoke-MedicalTemplateRecognition($owner,$model,$schema){
 [void]$script:dispatch.Add('recognition')
 if($script:recognitionMode -eq 'error'){throw 'Recognition failed intentionally'}
 if($script:recognitionMode -eq 'cancel'){return $null}
 $plan=Get-MedicalTemplateRecognitionPlan $model $schema
 $ids=@($plan.Rows | Where-Object {$_.Selected -or $_.Action -ceq 'add-date'} | ForEach-Object {$_.Id})
 return (Apply-MedicalTemplateRecognitionPlan $model $schema $plan $ids)
}
function Set-OpenWorkspace {
 $script:universalConfig=New-UniversalConfig;$script:universalValues=@{patient_name='CURRENT PRIVATE PATIENT'};$script:universalDetails=@{complaints='PRIVATE DETAIL'}
 $script:medicalClinicalForms=[pscustomobject]@{Diaries=@([pscustomobject]@{Id='d1';Title='CURRENT PRIVATE DIARY'})}
 $script:medicalClinicalState=[pscustomobject]@{Diaries=@([pscustomobject]@{Values=@{note='CURRENT DIARY ANSWER'}});Discharge=@{Values=@{notes='CURRENT DISCHARGE ANSWER'}}}
 $script:stage='discharge';$script:caseFile='CURRENT CARD';$script:activeMedicalFormPath='CURRENT FORM'
 $script:refs=@{Config=$script:universalConfig;Values=$script:universalValues;Details=$script:universalDetails;Forms=$script:medicalClinicalForms;State=$script:medicalClinicalState}
 $script:dispatch.Clear();$script:confirm=$true;$script:editorMode='cancel';$script:recognitionMode='cancel';$script:importMode='ok'
}
function Assert-OpenWorkspace([string]$label){
 foreach($entry in @(@('Config',$script:universalConfig),@('Values',$script:universalValues),@('Details',$script:universalDetails),@('Forms',$script:medicalClinicalForms),@('State',$script:medicalClinicalState))){Assert-Open ([object]::ReferenceEquals($script:refs[$entry[0]],$entry[1])) ($label+' preserves '+$entry[0]+' reference')}
 Assert-Open ($script:stage -ceq 'discharge' -and $script:caseFile -ceq 'CURRENT CARD' -and $script:activeMedicalFormPath -ceq 'CURRENT FORM') ($label+' preserves active stage and file bindings')
 Assert-Open ($script:universalValues.patient_name -ceq 'CURRENT PRIVATE PATIENT' -and $script:medicalClinicalState.Diaries[0].Values.note -ceq 'CURRENT DIARY ANSWER') ($label+' preserves patient and diary answers')
}
try{
 $script:medicalProgramRoot=Join-Path $root 'personal';$script:medicalTemplatesFolder=Join-Path $script:medicalProgramRoot 'Шаблоны'
 $script:sourcePath=Join-Path $root 'Исходный Word.docx';$config=New-UniversalConfig;New-UniversalTemplate $script:sourcePath $config
 $sourceHash=Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($script:sourcePath))
 $kind=Get-MedicalDocumentKind $script:sourcePath
 Assert-Open ($kind.Kind -ceq 'Template' -and -not $kind.Legacy) 'Ordinary DOCX is detected as a reusable template'
 Assert-Open ([IO.Path]::IsPathRooted($kind.Path)) 'Classifier returns a canonical full path'
 $dotx=New-OpenCopy 'Шаблон.dotx';Assert-Open ((Get-MedicalDocumentKind $dotx).Kind -ceq 'Template') 'DOTX package is accepted by Word document classifier'
 foreach($extension in @('doc','dot','rtf')){
  $path=Join-Path $root ('Обычный.'+$extension);[IO.File]::WriteAllText($path,'{\rtf1 ordinary Word text}')
  $kind=Get-MedicalDocumentKind $path;Assert-Open ($kind.Kind -ceq 'Template' -and $kind.Legacy) ('Legacy '+$extension+' is routed to the existing local Word converter')
 }
 foreach($extension in @('docm','dotm','exe','txt')){
  $path=Join-Path $root ('Не поддерживается.'+$extension);[IO.File]::WriteAllText($path,'test')
  Assert-OpenRejected {Get-MedicalDocumentKind $path} ('Unsupported '+$extension+' is rejected explicitly')
 }
 $empty=Join-Path $root 'Пустой.docx';[IO.File]::WriteAllBytes($empty,[byte[]]@())
 Assert-OpenRejected {Get-MedicalDocumentKind $empty} 'Empty Word document is rejected before import'
 $encrypted=Join-Path $root 'Защищённый.docx';[IO.File]::WriteAllBytes($encrypted,[byte[]]@(0xd0,0xcf,0x11,0xe0))
 Assert-OpenRejected {Get-MedicalDocumentKind $encrypted} 'Encrypted/OLE DOCX reports unsupported protected package without import'
 $broken=Join-Path $root 'Повреждённый.docx';[IO.File]::WriteAllBytes($broken,[byte[]]@(0x50,0x4b,0x03,0x04,0x01,0x02))
 Assert-OpenRejected {Get-MedicalDocumentKind $broken} 'Truncated ZIP package is rejected without template fallback'
 $record=[pscustomobject]@{version=49;patientName='SAVED PRIVATE PATIENT';universal=[pscustomobject]@{Schema=$config;Values=@{patient_name='SAVED PRIVATE PATIENT'}};stages=[pscustomobject]@{initial=@()};templates=[pscustomobject]@{initial='saved-template.docx'}}
 $card=New-OpenCopy 'Карта.docx';Set-MedicalCardDocumentState $card $record
 Assert-Open ((Get-MedicalDocumentKind $card).Kind -ceq 'Card') 'Saved case metadata is detected before ordinary Word import'
 Assert-Open ((Read-CaseDocument $card).patientName -ceq 'SAVED PRIVATE PATIENT') 'Existing card reader retains the saved patient payload'
 $tamperedRecord=Copy-UniversalObject $record
 $tamperedRecord | Add-Member -NotePropertyName TemplateSnapshots -NotePropertyValue ([pscustomobject]@{initial=[pscustomobject]@{Name='Шаблон.docx';Sha256=('0'*64);BytesBase64=[Convert]::ToBase64String([IO.File]::ReadAllBytes($script:sourcePath))}})
 $tamperedCard=New-OpenCopy 'Подменённая контрольная сумма.docx';Set-MedicalCardDocumentState $tamperedCard $tamperedRecord
 Set-OpenWorkspace
 Assert-OpenRejected {Open-MedicalDocumentPath $tamperedCard} 'A tampered embedded template checksum is rejected by actual card validation'
 Assert-Open ($script:dispatch.Count -eq 0) 'A tampered card never falls back to template recognition'
 Assert-OpenWorkspace 'Tampered snapshot'

 $uppercase=New-OpenCopy 'Регистр.docx';$payload=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($record | ConvertTo-Json -Depth 40 -Compress)))
 Write-OpenPart $uppercase 'CUSTOMXML/MC-CASE.XML' ('<case xmlns="urn:medical-constructor:case:v65">'+$payload+'</case>')
 Assert-Open ((Get-MedicalDocumentKind $uppercase).Kind -ceq 'Card') 'Case-insensitive card metadata spelling cannot bypass the card branch'
 foreach($badState in @('<broken>', '<case xmlns="wrong">e30=</case>', '<case xmlns="urn:medical-constructor:case:v65">!!!</case>', '<case xmlns="urn:medical-constructor:case:v65">e30=</case>', '<!DOCTYPE case [<!ENTITY x SYSTEM "file:///private">]><case xmlns="urn:medical-constructor:case:v65">&x;</case>')){
  $bad=New-OpenCopy ('Повреждение-'+[guid]::NewGuid().ToString('N')+'.docx');Write-OpenPart $bad 'customXml/mc-case.xml' $badState
  Set-OpenWorkspace;Assert-OpenRejected {Open-MedicalDocumentPath $bad} 'Malformed/unknown card metadata never becomes an ordinary template'
  Assert-Open ($script:dispatch.Count -eq 0) 'Corrupt case never reaches import, editor, reset, or card restoration'
  Assert-OpenWorkspace 'Corrupt case'
 }
 $missing=New-OpenCopy 'Нет состояния.docx';Write-OpenPart $missing 'word/_rels/document.xml.rels' '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdCase" Target="../customXml/mc-case.xml" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXml"/></Relationships>'
 Assert-OpenRejected {Get-MedicalDocumentKind $missing} 'A missing referenced case state is damage and never a template'
 $duplicate=New-OpenCopy 'Повтор документа.docx';$z=[IO.Compression.ZipFile]::Open($duplicate,[IO.Compression.ZipArchiveMode]::Update);try{Write-UniversalZipText $z 'WORD/DOCUMENT.XML' '<broken/>'}finally{$z.Dispose()}
 Assert-OpenRejected {Get-MedicalDocumentKind $duplicate} 'Ambiguous duplicate package parts are rejected case-insensitively'
 $dtd=New-OpenCopy 'Внешняя сущность.docx';Write-OpenPart $dtd 'word/document.xml' '<!DOCTYPE document [<!ENTITY x SYSTEM "file:///private">]><document>&x;</document>'
 Assert-OpenRejected {Get-MedicalDocumentKind $dtd} 'Word DTD and external entity expansion are prohibited'
 $legacyPayload=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($record | ConvertTo-Json -Depth 40 -Compress)))
 $legacy=New-OpenText 'Старая карта.docx' ('MC_CASE_V24:'+$legacyPayload+':END_MC_CASE') $true
 $kind=Get-MedicalDocumentKind $legacy;Assert-Open ($kind.Kind -ceq 'Card' -and $kind.Legacy) 'A valid hidden legacy payload is recognized as the full saved card'
 Assert-Open ((Read-CaseDocument $legacy).patientName -ceq 'SAVED PRIVATE PATIENT') 'The original legacy card reader can still restore old card data'
 $legacyStatePayload=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(([pscustomobject]@{Version=49;Schema=$config} | ConvertTo-Json -Depth 40 -Compress)))
 Write-OpenPart $legacy 'customXml/mc49.xml' ('<state xmlns="urn:medical-constructor:v49">'+$legacyStatePayload+'</state>')
 Assert-Open ((Get-MedicalDocumentKind $legacy).Kind -ceq 'Card') 'A full legacy card takes precedence over its embedded single-stage state'
 Set-OpenWorkspace;$script:confirm=$false
 Assert-Open (-not (Open-MedicalDocumentPath $legacy)) 'A legacy card with stage metadata still respects current-work cancellation'
 Assert-Open (($script:dispatch -join ',') -ceq 'confirm') 'Legacy card metadata cannot bypass the saved-card replacement guard'
 $splitLegacy=New-OpenCopy 'Разбитая скрытая карта.docx'
 Write-OpenPart $splitLegacy 'word/document.xml' ('<w:document xmlns:w="'+$script:ns+'"><w:body><w:p><w:r><w:rPr><w:vanish/></w:rPr><w:t>MC_</w:t></w:r><w:r><w:rPr><w:vanish/></w:rPr><w:t>CASE_V24:broken</w:t></w:r></w:p></w:body></w:document>')
 Assert-OpenRejected {Get-MedicalDocumentKind $splitLegacy} 'A damaged hidden legacy marker split across runs cannot be imported as a template'

 $malformedLegacy=New-OpenText 'Повреждённая старая карта.docx' 'MC_CASE_V24:eyJbroken:END_MC_CASE' $true
 Assert-OpenRejected {Get-MedicalDocumentKind $malformedLegacy} 'A malformed hidden legacy marker is rejected before template import'
 $textMarker=New-OpenText 'Обычное описание маркера.docx' 'Инструкция: MC_CASE_V24: это название служебного маркера.'
 Assert-Open ((Get-MedicalDocumentKind $textMarker).Kind -ceq 'Template') 'An incomplete literal marker in ordinary visible text is not mistaken for a saved card'
 $unrelated=New-OpenCopy 'Другая служебная часть.docx';Write-OpenPart $unrelated 'customXml/other.xml' '<case xmlns="another-application">ordinary text</case>'
 Assert-Open ((Get-MedicalDocumentKind $unrelated).Kind -ceq 'Template') 'Unrelated custom XML is not mistaken for application patient state'
 $stagePayload=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(([pscustomobject]@{Version=49;Schema=$config;Values=@{patient_name='STAGE ANSWER'}} | ConvertTo-Json -Depth 40 -Compress)))
 $stageDocument=New-OpenState 'Документ осмотра.docx' ('<state xmlns="urn:medical-constructor:v49">'+$stagePayload+'</state>')
 Assert-Open ((Get-MedicalDocumentKind $stageDocument).Kind -ceq 'Stage') 'Filled single-stage exports are kept separate from reusable templates'
 Set-OpenWorkspace;Open-MedicalDocumentPath $stageDocument
 Assert-Open (($script:dispatch -join ',') -ceq 'stage') 'Saved single-stage documents retain their guarded existing restoration route'
 foreach($badState in @('<broken/>','<state xmlns="wrong">e30=</state>','<state xmlns="urn:medical-constructor:v49">!!!</state>','<state xmlns="urn:medical-constructor:v49">e30=</state>')){
  $badStage=New-OpenState ('Неверная форма-'+[guid]::NewGuid().ToString('N')+'.docx') $badState
  Assert-OpenRejected {Get-MedicalDocumentKind $badStage} 'Corrupt single-stage application state never becomes a template'
 }
 Set-OpenWorkspace;$script:blockedPath=Join-Path $root 'Другой сотрудник.docx';$before=$script:guardCalls.Count
 Assert-OpenRejected {Get-MedicalDocumentKind $script:blockedPath} 'Account access rejects another employee path before existence or content inspection'
 Assert-Open ($script:guardCalls.Count -eq $before+1 -and $script:dispatch.Count -eq 0) 'Account guard is the first and only action for a denied source'
 Assert-OpenWorkspace 'Denied source';$script:blockedPath=''
 Set-OpenWorkspace;$script:confirm=$false
 Assert-Open (-not (Open-MedicalDocumentPath $card)) 'Declining current-work replacement cancels opening a saved card'
 Assert-Open (($script:dispatch -join ',') -ceq 'confirm') 'Saved card cancellation does not enter the ordinary import/editor route'
 Assert-OpenWorkspace 'Cancelled saved card'
 Set-OpenWorkspace
 Assert-Open (Open-MedicalDocumentPath $card) 'Accepted saved card is opened successfully'
 Assert-Open (($script:dispatch -join ',') -ceq 'confirm,card') 'Saved card uses confirmation then actual card dispatch'
 foreach($scenario in @('import-cancel','import-error','recognition-error','editor-cancel','editor-error','reset-cancel')){
  Set-OpenWorkspace
  switch($scenario){'import-cancel'{$script:importMode='cancel'}'import-error'{$script:importMode='error'}'recognition-error'{$script:recognitionMode='error'}'editor-error'{$script:editorMode='error'}'reset-cancel'{$script:editorMode='accept';$script:confirm=$false}}
  if($scenario -in @('import-error','recognition-error','editor-error')){Assert-OpenRejected {Open-MedicalDocumentPath $script:sourcePath} ($scenario+' reports the actual failure without replacing current work')}
  else{Assert-Open (-not (Open-MedicalDocumentPath $script:sourcePath)) ($scenario+' cancels ordinary template opening')}
  Assert-OpenWorkspace $scenario
  Assert-Open (-not $script:dispatch.Contains('use') -and -not $script:dispatch.Contains('metadata')) ($scenario+' never commits form schema or metadata')
  Assert-Open ((Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($script:sourcePath))) -ceq $sourceHash) ($scenario+' preserves every byte of the original Word file')
 }
 $recognitionSource=New-OpenText 'Карта без маркеров.docx' 'Ф.И.О.: ______________'
 $recognitionHash=Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($recognitionSource))
 Set-OpenWorkspace;$script:editorMode='accept';$script:recognitionMode='accept'
 Assert-Open (Open-MedicalDocumentPath $recognitionSource) 'An accepted ordinary Word document becomes a new reusable form'
 Assert-Open (($script:dispatch -join ',') -ceq 'import,recognition,editor:new,confirm,use,metadata') 'The complete ordinary Word workflow reviews before authorizing replacement'
 Assert-Open ($script:stage -ceq 'initial' -and $script:caseFile -ceq '' -and $script:universalValues.Count -eq 0 -and $script:universalDetails.Count -eq 0) 'Accepted reusable form starts at initial examination with empty patient values'
 Assert-Open ($script:medicalClinicalState.Diaries.Count -eq 0) 'Accepted ordinary Word never silently reuses the previous patient diaries'
 Assert-Open ((Get-MedicalBytesSha256 ([IO.File]::ReadAllBytes($recognitionSource))) -ceq $recognitionHash) 'Accepted opening preserves the original source package exactly'
 $filter=Get-MedicalOpenDocumentFilter
 foreach($extension in @('docx','dotx','doc','dot','rtf')){Assert-Open ($filter.Contains('*.'+$extension)) ('Open Card filter offers '+$extension)}
 Assert-Open (-not $filter.Contains('*.docm') -and -not $filter.Contains('*.dotm')) 'The picker does not advertise unimplemented macro formats'
 Write-Output ('Completed '+$script:checks+' Word opening checks. Real Windows dialogs and Microsoft Word conversion were not run on Linux.')
}finally{if([IO.Directory]::Exists($root)){[IO.Directory]::Delete($root,$true)}}
