﻿param([string]$Project=(Join-Path $PSScriptRoot '../Медицинский конструктор v73'))
$ErrorActionPreference='Stop';$passed=0;$lines=New-Object Collections.ArrayList
function Check($value,[string]$message){if(-not $value){throw ('FAILED: '+$message)};$script:passed++;[void]$script:lines.Add(('PASS: '+$message))}
function Reject([scriptblock]$action,[string]$message){$caught=$false;try{& $action|Out-Null}catch{$caught=$true};Check $caught $message}
. (Join-Path $Project 'local-ai-v72.ps1')
Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
public sealed class LocalAiTestServerV72:IDisposable {
 private HttpListener listener;private Thread thread;private volatile bool stopped;
 public volatile string Reply="{}";public volatile string TokenReply="{\"tokens\":[1,2,3]}";public volatile string TagsReply="{\"models\":[{\"name\":\"qwen2.5:0.5b\",\"model\":\"qwen2.5:0.5b\",\"size\":491000000,\"digest\":\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"}]}";public volatile string ShowReply="{\"modelfile\":\"FROM /models/blobs/sha256-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\",\"details\":{\"format\":\"gguf\"}}";public int Status=200;public int DelayMs=0;public bool Chunked=false;public bool Disconnect=false;
 public string Body="";public string Authorization="";public string Path="";public int Requests=0;public string Endpoint;
 public LocalAiTestServerV72() {
  System.Net.Sockets.TcpListener socket=new System.Net.Sockets.TcpListener(IPAddress.Loopback,0);socket.Start();int port=((IPEndPoint)socket.LocalEndpoint).Port;socket.Stop();
  Endpoint="http://127.0.0.1:"+port.ToString();listener=new HttpListener();listener.Prefixes.Add(Endpoint+"/");listener.Start();thread=new Thread(Run);thread.IsBackground=true;thread.Start();
 }
 private void Run() {while(!stopped){HttpListenerContext context=null;try{context=listener.GetContext();Requests++;Path=context.Request.Url.AbsolutePath;Authorization=context.Request.Headers["Authorization"]??"";using(StreamReader r=new StreamReader(context.Request.InputStream,Encoding.UTF8))Body=r.ReadToEnd();int delay=DelayMs;for(int i=0;i<delay && !stopped;i+=25)Thread.Sleep(25);if(Disconnect){context.Response.Abort();continue;}context.Response.StatusCode=Status;if(Status==302)context.Response.RedirectLocation="http://example.invalid/forbidden";byte[] bytes=Encoding.UTF8.GetBytes(Path=="/tokenize"?TokenReply:(Path=="/api/tags"?TagsReply:(Path=="/api/show"?ShowReply:Reply)));context.Response.ContentType="application/json";if(Chunked)context.Response.SendChunked=true;else context.Response.ContentLength64=bytes.Length;context.Response.OutputStream.Write(bytes,0,bytes.Length);context.Response.Close();}catch{if(context!=null)try{context.Response.Abort();}catch{}}}}
 public void Dispose(){stopped=true;try{listener.Stop();listener.Close();}catch{}thread.Join(2000);}
}
'@
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-ai-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
$app=Join-Path $temp 'app';$profile=Join-Path $temp 'profile';[void][IO.Directory]::CreateDirectory($app)
$server=$null;$control=$null
function Set-TestReply([string]$text,[string]$done='stop'){$server.Reply=(@{message=@{role='assistant';content=$text};done_reason=$done;done=$true}|ConvertTo-Json -Compress -Depth 5)}
function New-TestGguf([string]$path,[int]$version=3){[void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($path));$stream=[IO.File]::Create($path);try{$header=[Text.Encoding]::ASCII.GetBytes('GGUF')+[BitConverter]::GetBytes($version);$stream.Write($header,0,$header.Length);$stream.SetLength(1048576)}finally{$stream.Dispose()}}
try{
 $cfg=Initialize-MedicalLocalAi $app $profile
 Check ($cfg.ContextSize -eq 2048 -and $cfg.Predict -eq 512 -and $cfg.Threads -le 4) 'Low-memory defaults bound context, response and CPU threads'
 Check (-not (Get-MedicalLocalAiStatus).Available) 'Uninstalled AI reports unavailable instead of pretending inference'
 Check ((Get-MedicalLocalAiStatus).Offline -and (Get-MedicalLocalAiStatus).AppRoot -eq $app -and (Get-MedicalLocalAiStatus).ProfileRoot -eq $profile) 'UI worker receives explicit local roots'
 $result=Invoke-MedicalLocalAi -Task Text -Input 'Текст 12.'
 Check (-not $result.Success -and $result.Error -match 'GGUF' -and $result.NeedsReview) 'No model gives a useful failure with original input untouched'
 foreach($endpoint in @('https://127.0.0.1:11434','http://192.168.0.1:11434','http://example.org','http://127.0.0.1.evil.test','http://user:pass@127.0.0.1:11434','http://127.0.0.1:11434/api/chat','http://127.0.0.1:11434/?q=x','file:///tmp/data','http://2130706433:11434','http://0.0.0.0:11434')){Reject {Assert-MedicalLocalAiEndpoint $endpoint} ('External or ambiguous endpoint is refused: '+$endpoint)}
 Check ((Assert-MedicalLocalAiEndpoint 'http://localhost:11434/') -ceq 'http://127.0.0.1:11434') 'localhost resolves to a literal loopback address before document transport'
 Check ((Assert-MedicalLocalAiEndpoint 'http://[::1]:11434') -match '\[::1\]') 'Explicit IPv6 loopback is allowed'
 Reject {[MedicalLocalAiTransportV72]::Execute('http://example.org','GET',$null,'',1000,1024,[Threading.CancellationToken]::None)} 'Transport independently refuses a remote destination'
 $bad=[pscustomobject]@{Backend='remote'};Reject {Set-MedicalLocalAiConfig $bad} 'Remote provider cannot be configured'
 foreach($threads in @(0,5,100)){Reject {Test-MedicalLocalAiConfig @{Threads=$threads}} ('CPU thread bound rejects '+$threads)}
 Reject {Test-MedicalLocalAiConfig @{TimeoutSeconds=301}} 'Unbounded timeout setting is rejected'
 Reject {Test-MedicalLocalAiConfig @{OllamaModel="model`nmalformed"}} 'Malformed Ollama identifier cannot enter payload'
 Reject {Resolve-MedicalLocalAiModelPath 'app:../foreign.gguf'} 'Portable model traversal is rejected'
 Reject {Resolve-MedicalLocalAiModelPath 'profile:../foreign.gguf'} 'Profile model traversal is rejected'
 Reject {Resolve-MedicalLocalAiModelPath 'relative.gguf'} 'Unqualified paths cannot bind to arbitrary process cwd'
 $model=Join-Path $app 'ИИ/Модели/small.gguf';New-TestGguf $model
 Check ((Test-MedicalLocalAiModel $model) -eq $model) 'Real GGUF magic, version and minimum length are checked'
 Check (@(Get-MedicalLocalAiModels).Count -eq 1) 'Installed local models are discovered without a network request'
 $invalid=Join-Path $temp 'invalid.gguf';[IO.File]::WriteAllText($invalid,'GGUF');Reject {Test-MedicalLocalAiModel $invalid} 'Truncated GGUF cannot be launched'
 $wrong=Join-Path $temp 'wrong.gguf';New-TestGguf $wrong 99;Reject {Test-MedicalLocalAiModel $wrong} 'Unsupported GGUF version is rejected'
 $cfg.ModelPath=$model;$cfg=Set-MedicalLocalAiConfig $cfg
 $stored=[IO.File]::ReadAllText((Join-Path $profile 'local-ai.json'))|ConvertFrom-Json
 Check ($stored.ModelPath -ceq 'app:small.gguf') 'App model path is stored relative to the portable model directory'
 Check ($cfg.ModelPath -ceq $model) 'Runtime settings resolve portable model path to current installation'
 $moved=Join-Path $temp 'moved';[void][IO.Directory]::CreateDirectory($moved);Copy-Item -LiteralPath $app -Destination (Join-Path $moved 'app') -Recurse;Copy-Item -LiteralPath $profile -Destination (Join-Path $moved 'profile') -Recurse
 $movedApp=Join-Path $moved 'app';$movedProfile=Join-Path $moved 'profile';$cfg=Initialize-MedicalLocalAi $movedApp $movedProfile
 Check ($cfg.ModelPath -ceq (Join-Path $movedApp 'ИИ/Модели/small.gguf')) 'Copied installation resolves shared model under its new root'
 $profileModel=Join-Path $movedProfile 'models/private.gguf';New-TestGguf $profileModel;$cfg.ModelPath=$profileModel;$null=Set-MedicalLocalAiConfig $cfg
 $stored=[IO.File]::ReadAllText((Join-Path $movedProfile 'local-ai.json'))|ConvertFrom-Json;Check ($stored.ModelPath -ceq 'profile:models/private.gguf') 'User model path remains relative to user profile'
 $cfg=Initialize-MedicalLocalAi $app $profile;$external=Join-Path $temp 'external.gguf';New-TestGguf $external;$cfg.ModelPath=$external;$null=Set-MedicalLocalAiConfig $cfg
 Check (([IO.File]::ReadAllText((Join-Path $profile 'local-ai.json'))|ConvertFrom-Json).ModelPath -ceq $external) 'Explicit external file retains exact path and is never rebound by basename'
 [IO.File]::Delete($external);Check (-not (Get-MedicalLocalAiStatus).Available) 'Missing external model reports choose-model rather than using another installation file'
 $runtimeRoot=Join-Path $app 'ИИ';$runtime=Join-Path $runtimeRoot 'Движок/llama-server.exe';[void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($runtime));[IO.File]::WriteAllText($runtime,'test fixture executable bytes')
 $manifest=@{Executable='Движок/llama-server.exe';Files=@(@{Path='Движок/llama-server.exe';Sha256=(Get-FileHash $runtime -Algorithm SHA256).Hash})};$manifestPath=Join-Path $runtimeRoot 'runtime-manifest.json';[IO.File]::WriteAllText($manifestPath,($manifest|ConvertTo-Json -Depth 5))
 Check ((Get-MedicalLocalAiRuntimePath) -ceq $runtime) 'Runtime launch path requires an exact checksum-pinned file'
 [IO.File]::AppendAllText($runtime,'tampered');Reject {Get-MedicalLocalAiRuntimePath} 'Modified engine executable is rejected before process creation'
 $manifest.Files[0].Path='../escape.exe';[IO.File]::WriteAllText($manifestPath,($manifest|ConvertTo-Json -Depth 5));Reject {Get-MedicalLocalAiRuntimePath} 'Runtime manifest traversal cannot escape bundled engine folder'
 Check ([MedicalLocalAiTransportV72]::Quote('C:\folder with spaces\model.gguf') -ceq '"C:\folder with spaces\model.gguf"') 'Process paths containing spaces are quoted as one argument'
 Check ([MedicalLocalAiTransportV72]::Quote('a"b\') -ceq '"a\"b\\"') 'Quotes and trailing backslashes use Windows native argument escaping'
 Reject {[MedicalLocalAiTransportV72]::Quote("a`n--host external")} 'Newline command arguments are rejected'
 $server=New-Object LocalAiTestServerV72;$cfg=Get-MedicalLocalAiConfig;$cfg.Backend='ollama';$cfg.OllamaEndpoint=$server.Endpoint;$cfg.OllamaModel='qwen2.5:0.5b';$null=Set-MedicalLocalAiConfig $cfg
 $server.Reply='{"status":"ok"}';$health=[MedicalLocalAiTransportV72]::Execute($server.Endpoint+'/health','GET',$null,'test-key',1000,1024,[Threading.CancellationToken]::None)|ConvertFrom-Json
 Check ($health.status -ceq 'ok' -and $server.Path -ceq '/health' -and $server.Body -ceq '') 'Native health GET sends no body even when PowerShell converts null string arguments'
 Set-TestReply 'Пациент 12. Жалоб нет.'
 $result=Invoke-MedicalLocalAi -Task Text -Input 'Пациент 12. Жалоб нет.' -Instruction 'Исправь пунктуацию.'
 Check ($result.Success -and $result.Text -ceq 'Пациент 12. Жалоб нет.' -and $result.NeedsReview) 'Real loopback API response is parsed as review-only text result'
 $payload=$server.Body|ConvertFrom-Json
 Check ($server.Path -ceq '/api/chat' -and $payload.model -ceq 'qwen2.5:0.5b') 'Ollama inference uses the selected local model and chat route'
 Check ($payload.stream -eq $false -and $payload.options.num_ctx -eq 2048 -and $payload.options.num_predict -eq 512 -and $payload.options.temperature -eq 0) 'Inference explicitly bounds context/output and disables sampling randomness'
 Check (($payload.messages[1].content|ConvertFrom-Json).editingRequest -ceq 'Исправь пунктуацию.') 'User editing instruction is passed as data with exact source text'
 Check (($payload.messages[1].content|ConvertFrom-Json).sourceText -ceq 'Пациент 12. Жалоб нет.') 'Input alias does not collide with PowerShell automatic input variable'
 Check ($payload.messages[0].content -match 'negations' -and $payload.messages[0].content -match 'Do not add diagnoses') 'Text task explicitly prohibits invented clinical facts'
 Check ($server.Authorization -ceq '') 'Existing Ollama never receives the embedded server secret'
 $goodTags=$server.TagsReply;$goodShow=$server.ShowReply
 $sensitive='Секретная запись пациента 12.'
 foreach($cloudName in @('qwen3:cloud','qwen3:480b-cloud','CLOUD-model:latest')){
  $cfg.OllamaModel=$cloudName;$null=Set-MedicalLocalAiConfig $cfg;$before=$server.Requests;$r=Invoke-MedicalLocalAi -Task Text -Input $sensitive
  Check (-not $r.Success -and $server.Requests -eq $before) ('Cloud model name rejected before any document request: '+$cloudName)
 }
 $cfg.OllamaModel='qwen2.5:0.5b';$null=Set-MedicalLocalAiConfig $cfg
 foreach($badTags in @('{"models":[]}','{"models":[{"name":"qwen2.5:0.5b","model":"qwen2.5:0.5b","size":400,"digest":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"}]}','{"models":[{"name":"qwen2.5:0.5b","size":491000000,"digest":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"}]}','{"models":[{"name":"qwen2.5:0.5b","model":"qwen2.5:0.5b","size":491000000}]}','{"models":[{"name":"qwen2.5:0.5b","model":"qwen2.5:0.5b","size":491000000,"digest":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","remote_host":"https://ollama.com"}]}')){
  $server.TagsReply=$badTags;$before=$server.Requests;$r=Invoke-MedicalLocalAi -Task Text -Input $sensitive
  Check (-not $r.Success -and $server.Requests -eq $before+1 -and $server.Path -eq '/api/tags' -and -not $server.Body) 'Absent, metadata-only or remote-tag model cannot receive patient text'
 }
 $server.TagsReply=$goodTags
 foreach($badShow in @('{"modelfile":"FROM /models/blob","remote_host":"https://ollama.com"}','{"modelfile":"FROM /models/blob","remote_model":"remote-big"}','{"modelfile":"FROM /models/blob","details":{"model_info.remote_host":"ollama.com"}}','{"modelfile":"FROM /models/blob","cloud":true}','{"modelfile":"FROM /models/blob","capabilities":["completion","cloud"]}','{"modelfile":"FROM https://ollama.com/model"}','{"modelfile":"FROM ollama.com/library/remote:latest"}','{"modelfile":"FROM wrapped:cloud"}','{"modelfile":"FROM hidden-alias:latest"}','{"modelfile":"FROM ftp://remote.invalid/weights"}','{}')){
  $server.ShowReply=$badShow;$before=$server.Requests;$r=Invoke-MedicalLocalAi -Task Text -Input $sensitive
  Check (-not $r.Success -and $server.Requests -eq $before+2 -and $server.Path -eq '/api/show' -and $server.Body -notmatch 'Секретная|пациента') 'Aliased cloud or remote source is rejected during metadata-only preflight'
 }
 $server.ShowReply=$goodShow;Set-TestReply 'Пациент 12. Жалоб нет.'
 $r=Invoke-MedicalLocalAi -Task Text -Input 'Пациент 12. Жалоб нет.';Check ($r.Success -and $server.Path -eq '/api/chat') 'Verified already-installed local weights can receive a reviewed inference request'
 Check ((Get-MedicalLocalAiStatus).Message -match 'Доступность проверяется' -and -not (Get-MedicalLocalAiStatus).Available -and (Get-MedicalLocalAiStatus).VerificationRequired) 'Configured Ollama status does not claim runtime local-model verification'
 Set-TestReply 'Пациент 13. Жалоб нет.';$result=Invoke-MedicalLocalAi -Task Text -Input 'Пациент 12. Жалоб нет.'
 Check (-not $result.Success -and $result.Text -ceq '' -and $result.Error -match 'числа') 'Changed clinical number cannot be applied as edited text'
 foreach($pair in @(@('Дата 01.10.2026','Дата 02.10.2026'),@('Поле {{PATIENT_NAME}}','Поле {{PATIENT_BIRTH}}'),@('Доза -1,5 мг','Доза 1,5 мг'),@('12 и 12','12'),@('T 38.5°','T 38.6°'),@('Диагноз F10.2','Диагноз F12.2'),@('Диагноз F10.2','Диагноз G10.2'),@('Витамин B12','Витамин B6'),@('Доза 12 мг','Доза 12 мл'))){Set-TestReply $pair[1];$r=Invoke-MedicalLocalAi -Task Text -Input $pair[0];Check (-not $r.Success) ('Invariant change is rejected: '+$pair[0])}
 Set-TestReply 'Дата 01.10.2026, доза 12 мг; {{PATIENT_NAME}}.';$r=Invoke-MedicalLocalAi -Task Text -Input 'Дата 01.10.2026 доза 12 мг {{PATIENT_NAME}}.'
 Check $r.Success 'Punctuation correction preserves exact date, dose and Word markers'
 $defs=@([pscustomobject]@{Marker='PATIENT_NAME';Label='ФИО'});$paragraphs=@([pscustomobject]@{Id='p1';Text='ФИО: Иванов'},[pscustomobject]@{Id='p2';Text=''});$inputJson=$paragraphs|ConvertTo-Json -Compress
 Set-TestReply '{"suggestions":[{"paragraphId":"p1","marker":"PATIENT_NAME","value":"Иванов"}]}'
 $r=Invoke-MedicalLocalAi -Task Markers -Input $inputJson -Schema $defs
 Check ($r.Success -and $r.Suggestions.Count -eq 1 -and $r.Suggestions[0].Start -eq 5 -and $r.Suggestions[0].Length -eq 6) 'Real model marker proposal resolves an exact substring to a bounded native range'
 Check ($r.Suggestions[0].ReplacementText -ceq 'ФИО: {{PATIENT_NAME}}' -and -not $r.Suggestions[0].Selected) 'Marker review retains label and requires explicit user acceptance'
 $markerPayload=$server.Body|ConvertFrom-Json;Check ($markerPayload.format -ceq 'json') 'Marker inference requests structured JSON mode'
 Set-TestReply '{"suggestions":[{"paragraphId":"p2","marker":"PATIENT_NAME","value":""}]}'
 $r=Invoke-MedicalLocalAi -Task Markers -Input $inputJson -Schema $defs;Check ($r.Success -and $r.Suggestions[0].Start -eq 0 -and $r.Suggestions[0].Length -eq 0) 'Entirely empty paragraph may receive a reviewed marker insertion'
 foreach($answer in @('{"suggestions":[{"paragraphId":"foreign","marker":"PATIENT_NAME","value":"Иванов"}]}','{"suggestions":[{"paragraphId":"p1","marker":"EVIL","value":"Иванов"}]}','{"suggestions":[{"paragraphId":"p1","marker":"patient_name","value":"Иванов"}]}','{"suggestions":[{"paragraphId":"P1","marker":"PATIENT_NAME","value":"Иванов"}]}','{"suggestions":[{"paragraphId":"p1","marker":"PATIENT_NAME","value":"нет"}]}','{"suggestions":[{"paragraphId":"p1","marker":"PATIENT_NAME","value":""}]}','{"suggestions": "wrong"}','{"other":[]}','not json')){Set-TestReply $answer;$r=Invoke-MedicalLocalAi -Task Markers -Input $inputJson -Schema $defs;Check (-not $r.Success -and $r.Suggestions.Count -eq 0) 'Malformed, unknown or mismatched marker output is refused atomically'}
 Reject {ConvertFrom-MedicalLocalAiAnswer Markers '{"suggestions":[{"paragraphId":"p1","marker":"PATIENT_NAME","value":"Иванов"}]}' '' $defs @(@{Id='p1';Text='Иванов Иванов'})} 'Ambiguous repeated text range is not guessed'
 Reject {ConvertFrom-MedicalLocalAiAnswer Markers '{"suggestions":[{"paragraphId":"p1","marker":"PATIENT_NAME","value":"{{PATIENT_NAME}}"}]}' '' $defs @(@{Id='p1';Text='{{PATIENT_NAME}}'})} 'Existing Word marker cannot be replaced by language-model output'
 Reject {ConvertFrom-MedicalLocalAiAnswer Markers '{"suggestions":[{"paragraphId":"p1","marker":"PATIENT_NAME","value":"Иван"},{"paragraphId":"p1","marker":"PATIENT_NAME","value":"Иванов"}]}' '' $defs $paragraphs} 'Overlapping marker replacements are rejected'
 Reject {ConvertFrom-MedicalLocalAiAnswer Markers '{"suggestions":[{"paragraphId":"p1","marker":"PATIENT_NAME","value":"Иванов"},{"paragraphId":"p1","marker":"PATIENT_NAME","value":"Иванов"}]}' '' $defs $paragraphs} 'Duplicate proposed replacements are rejected'
 $nested=@{Sections=@(@{Fields=@(@{Marker='PATIENT_NAME';Label='ФИО'},@{Marker='PATIENT_NAME';Label='ФИО'},@{Marker='invalid';Label='No'})})};Check (@(Get-MedicalLocalAiMarkerDefinitions $nested).Count -eq 1) 'Actual form schema produces only valid unique allowed markers'
 $before=$server.Requests;$r=Invoke-MedicalLocalAi -Task Text -Input ('x'*12001);Check (-not $r.Success -and $server.Requests -eq $before) 'Excessive source is rejected before HTTP transport'
 $r=Invoke-MedicalLocalAi -Task Text -Input 'текст' -Instruction ('x'*1001);Check (-not $r.Success -and $server.Requests -eq $before) 'Excessive instruction is rejected before HTTP transport'
 $r=Invoke-MedicalLocalAi -Task Text -Input ('x'*2801);Check (-not $r.Success -and $server.Requests -eq $before) 'Small-context Ollama input is rejected instead of silently truncated'
 $cts=New-Object Threading.CancellationTokenSource;$cts.Cancel();$r=Invoke-MedicalLocalAi -Task Text -Input 'текст' -CancellationToken $cts.Token;Check ($r.Cancelled -and -not $r.Success -and $server.Requests -eq $before) 'Pre-cancelled work never sends document text';$cts.Dispose()
 $server.Reply='{invalid';$r=Invoke-MedicalLocalAi -Task Text -Input 'текст';Check (-not $r.Success) 'Corrupt service JSON cannot become a successful result'
 Set-TestReply 'текст' 'length';$r=Invoke-MedicalLocalAi -Task Text -Input 'текст';Check (-not $r.Success -and $r.Error -match 'обрезан') 'Output cut off by token limit cannot overwrite the source'
 $server.Status=302;$server.Reply='{}';$r=Invoke-MedicalLocalAi -Task Text -Input 'текст';Check (-not $r.Success -and $server.Path -eq '/api/tags' -and -not $server.Body) 'HTTP redirect is refused rather than following a remote Location'
 $server.Status=200;$server.Reply='x'*2097153;$r=Invoke-MedicalLocalAi -Task Text -Input 'текст';Check (-not $r.Success) 'Oversized advertised response is rejected before allocation'
 $server.Chunked=$true;$r=Invoke-MedicalLocalAi -Task Text -Input 'текст';Check (-not $r.Success) 'Chunked oversized response is bounded during streaming';$server.Chunked=$false
 $server.Reply='{}';$server.Disconnect=$true;$r=Invoke-MedicalLocalAi -Task Text -Input 'текст';Check (-not $r.Success) 'Disconnected response is a safe failure';$server.Disconnect=$false
 $server.DelayMs=2000;Set-TestReply 'текст';$watch=[Diagnostics.Stopwatch]::StartNew();$r=Invoke-MedicalLocalAi -Task Text -Input 'текст' -TimeoutSeconds 1;$watch.Stop();Check (-not $r.Success -and $watch.Elapsed.TotalSeconds -lt 3) 'Request deadline bounds an unresponsive local model'
 $server.Dispose();$server=New-Object LocalAiTestServerV72;$cfg.OllamaEndpoint=$server.Endpoint;$null=Set-MedicalLocalAiConfig $cfg;$server.DelayMs=2000;Set-TestReply 'текст';$cts=New-Object Threading.CancellationTokenSource;$cts.CancelAfter(150);$watch.Restart();$r=Invoke-MedicalLocalAi -Task Text -Input 'текст' -CancellationToken $cts.Token;$watch.Stop();Check ($r.Cancelled -and $watch.Elapsed.TotalSeconds -lt 2) 'Cancellation aborts an active HTTP request promptly';$cts.Dispose();$server.Dispose();$server=$null
 # Test the embedded llama.cpp HTTP protocol with a real loopback server and an owned harmless child.
 $server=New-Object LocalAiTestServerV72;$cfg=Get-MedicalLocalAiConfig;$cfg.Backend='llama';$cfg.ModelPath=$model;$null=Set-MedicalLocalAiConfig $cfg
 $native=New-Object Diagnostics.ProcessStartInfo;$native.FileName=[Diagnostics.Process]::GetCurrentProcess().MainModule.FileName;$native.Arguments='-NoProfile -NonInteractive -Command "Start-Sleep -Seconds 30"';if([IO.Path]::DirectorySeparatorChar -eq '/'){$native.FileName='/bin/sleep';$native.Arguments='30'};$native.UseShellExecute=$false;$native.CreateNoWindow=$true
 $control=[Diagnostics.Process]::Start($native);$controlId=$control.Id;$registry=[hashtable]::Synchronized(@{});$null=Initialize-MedicalLocalAi $app $profile -RuntimeRegistry $registry
 $owned=@{Process=$control;Id=$control.Id;StartTicks=$control.StartTime.ToUniversalTime().Ticks;Path=$control.MainModule.FileName;Endpoint=$server.Endpoint;Key='test-random-owned-key'};$script:medicalLocalAiState.Owned=$owned;$registry.Owned=$owned
 $server.Reply=(@{choices=@(@{message=@{content='Текст 12.'};finish_reason='stop'})}|ConvertTo-Json -Compress -Depth 5)
 $r=Invoke-MedicalLocalAi -Task Text -Input 'Текст 12.'
 Check ($r.Success -and $r.Provider -ceq 'llama') 'Embedded llama.cpp inference follows the actual OpenAI-compatible protocol'
 Check ($server.Requests -eq 2 -and $server.Path -ceq '/v1/chat/completions') 'Embedded inference tokenizes the full request before chat completion'
 Check ($server.Authorization -ceq 'Bearer test-random-owned-key') 'Only the owned embedded server receives its transient authentication token'
 $payload=$server.Body|ConvertFrom-Json;Check ($payload.model -ceq 'local' -and $payload.max_tokens -eq 512 -and -not $payload.stream) 'Embedded completion has explicit local model and bounded response'
 $server.Reply=(@{choices=@(@{message=@{content='{"suggestions":[{"paragraphId":"p1","marker":"PATIENT_NAME","value":"Иванов"}]}'};finish_reason='stop'})}|ConvertTo-Json -Compress -Depth 5)
 $r=Invoke-MedicalLocalAi -Task Markers -Input $inputJson -Schema $defs
 Check ($r.Success -and $r.Suggestions.Count -eq 1) 'Embedded marker completion passes the same strict proposal validator'
 Check (($server.Body|ConvertFrom-Json).response_format.type -ceq 'json_object') 'Embedded markers request constrained JSON output'
 $server.TokenReply=(@{tokens=@(1..1401)}|ConvertTo-Json -Compress);$before=$server.Requests;$r=Invoke-MedicalLocalAi -Task Text -Input 'Текст 12.'
 Check (-not $r.Success -and $server.Requests -eq $before+1 -and $server.Path -ceq '/tokenize') 'Real tokenizer budget rejection prevents silent context truncation and skips generation'
 $server.TokenReply='{"tokens":[]}';$r=Invoke-MedicalLocalAi -Task Text -Input 'Текст 12.';Check (-not $r.Success) 'Missing tokenizer output cannot bypass the context budget'
 $server.TokenReply='{"tokens":[1,2,3]}';$server.Reply=(@{choices=@(@{message=@{content='Текст 12.'};finish_reason='length'})}|ConvertTo-Json -Compress -Depth 5);$r=Invoke-MedicalLocalAi -Task Text -Input 'Текст 12.';Check (-not $r.Success) 'Truncated embedded completion cannot be accepted'
 $server.Reply=(@{choices=@(@{message=@{content='Текст 12.'};finish_reason='stop'},@{message=@{content='Текст 12.'};finish_reason='stop'})}|ConvertTo-Json -Compress -Depth 5);$r=Invoke-MedicalLocalAi -Task Text -Input 'Текст 12.';Check (-not $r.Success) 'Ambiguous multiple embedded answers cannot be silently selected'
 Stop-MedicalLocalAiRuntime -RuntimeRegistry $registry
 Check ($null -eq $registry.Owned -and $null -eq $script:medicalLocalAiState.Owned -and $owned.Key -ceq '') 'Shared UI ownership registry safely clears the owned process and secret on forced cleanup'
 $control=$null;$server.Dispose();$server=$null
 $info=New-Object Diagnostics.ProcessStartInfo;$info.FileName=[Diagnostics.Process]::GetCurrentProcess().MainModule.FileName;$info.Arguments='-NoProfile -NonInteractive -Command "Start-Sleep -Seconds 30"';if([IO.Path]::DirectorySeparatorChar -eq '/'){$info.FileName='/bin/sleep';$info.Arguments='30'};$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$control=[Diagnostics.Process]::Start($info);$nativeChildPath=$control.MainModule.FileName
 $controlId=$control.Id;$script:medicalLocalAiState.Owned=@{Process=$control;Id=$control.Id;StartTicks=$control.StartTime.ToUniversalTime().Ticks+1;Path=$nativeChildPath;Key='test'};Stop-MedicalLocalAiRuntime
 $control=[Diagnostics.Process]::GetProcessById($controlId);Check (-not $control.HasExited) 'Cleanup does not kill a process with a reused or mismatched creation time'
 $script:medicalLocalAiState.Owned=@{Process=$control;Id=$control.Id;StartTicks=$control.StartTime.ToUniversalTime().Ticks;Path='different-executable';Key='test'};Stop-MedicalLocalAiRuntime
 $control=[Diagnostics.Process]::GetProcessById($controlId);Check (-not $control.HasExited) 'Cleanup refuses a process whose executable differs from the owned engine'
 # Previous calls disposed the Process wrapper, not the native child. Reopen by its ID for real owned cleanup.
 $controlId=$control.Id
 $control=[Diagnostics.Process]::GetProcessById($controlId);$script:medicalLocalAiState.Owned=@{Process=$control;Id=$control.Id;StartTicks=$control.StartTime.ToUniversalTime().Ticks;Path=$nativeChildPath;Key='test'};Stop-MedicalLocalAiRuntime
 $gone=$false;try{$remaining=[Diagnostics.Process]::GetProcessById($controlId);$gone=$remaining.HasExited;$remaining.Dispose()}catch{$gone=$true};Check $gone 'Cleanup terminates only a positively identified owned engine process';$control=$null
 Check (-not $script:medicalLocalAiState.Owned) 'Owned process and transient API key are removed after cleanup'
 $rawConfig=[IO.File]::ReadAllText((Join-Path $profile 'local-ai.json'));Check ($rawConfig -notmatch 'Иванов|sourceText|Authorization|Bearer|messages') 'Persistent settings never contain prompts, patient text or transient API keys'
 $source=[IO.File]::ReadAllText((Join-Path $Project 'local-ai-v72.ps1'));Check ($source -match "'--host','127.0.0.1'" -and $source.Contains("'--api-key',"+'$key') -and $source -match 'UseShellExecute=\$false') 'Owned runtime launch binds literal loopback, uses random API auth and avoids a command shell'
 [void]$lines.Add(('PASSED: '+$passed+' checks. Real loopback HTTP tested; native Windows llama.cpp process and real model inference are not exercised by this suite.'))
 $lines|ForEach-Object {Write-Output $_}
 [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'local-ai-results.txt'),(($lines -join "`r`n")+"`r`n"),(New-Object Text.UTF8Encoding($true)))
}finally{if($server){$server.Dispose()};Stop-MedicalLocalAiRuntime;if($control){try{if(-not $control.HasExited){$control.Kill();$control.WaitForExit(2000)|Out-Null}}catch{};$control.Dispose()};if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
