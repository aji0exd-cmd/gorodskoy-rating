﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v73'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Acquire([bool]$condition,[string]$label){if(-not $condition){throw $label};$script:checks++;Write-Output ('PASS '+$label)}
function Assert-AcquireRejected([scriptblock]$operation,[string]$label){$failed=$false;try{& $operation | Out-Null}catch{$failed=$true};Assert-Acquire $failed $label}
function Assert-AcquireCancelled([scriptblock]$operation,[string]$label){$cancelled=$false;try{& $operation | Out-Null}catch [OperationCanceledException]{$cancelled=$true};Assert-Acquire $cancelled $label}
Add-Type -AssemblyName System.Net.Http
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @'
using System;
using System.Collections;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
public sealed class AcquireDisposeFailure {public bool IsDisposed;public void Dispose(){throw new InvalidOperationException("Dispose failure fixture");}}
public sealed class AcquireHttpHandler:HttpMessageHandler {public string Method,Uri;public bool HasBody;protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken token){Method=request.Method.Method;Uri=request.RequestUri.AbsoluteUri;HasBody=request.Content!=null;return Task.FromResult(new HttpResponseMessage(System.Net.HttpStatusCode.OK){Content=new ByteArrayContent(new byte[]{1,2,3})});}}
namespace Windows.Forms {
 public sealed class Collection:IEnumerable {private ArrayList items=new ArrayList();public void Add(object o){items.Add(o);}public IEnumerator GetEnumerator(){return items.GetEnumerator();}}
 public class Form {public static Form Last;public string Text,FormBorderStyle,StartPosition;public int Width,Height,Activations;public bool MaximizeBox,MinimizeBox,ShowInTaskbar,IsDisposed,Enabled=true;public Collection Controls=new Collection();public event EventHandler FormClosing;public void Show(object owner){Last=this;}public void Activate(){Activations++;}public void Dispose(){IsDisposed=true;}public void RaiseClose(){if(FormClosing!=null)FormClosing(this,EventArgs.Empty);}}
 public sealed class Label {public string Text,Dock;public object Padding;}
 public sealed class ProgressBar {public string Dock;public int Height,Minimum,Maximum,Value;}
 public sealed class Padding {public Padding(int all){}}
 public sealed class Button {public string Text,Dock;public int Height;public event EventHandler Click;public void RaiseClick(){if(Click!=null)Click(this,EventArgs.Empty);}}
 public static class Application {public static bool CancelOnPump,CloseOnPump;public static Form DisposeOwner;public static int Pumps;public static void DoEvents(){Pumps++;if(DisposeOwner!=null){DisposeOwner.IsDisposed=true;DisposeOwner=null;}if(Form.Last!=null&&CancelOnPump){CancelOnPump=false;foreach(object o in Form.Last.Controls){Button b=o as Button;if(b!=null){b.RaiseClick();break;}}}if(Form.Last!=null&&CloseOnPump){CloseOnPump=false;Form.Last.RaiseClose();}}}
}
'@
. (Join-Path $Project 'model-acquisition-v72.ps1')
$script:realHttpSend=(Get-Command Invoke-MedicalAiModelHttpSend).ScriptBlock
$script:realCopy=(Get-Command Copy-MedicalAiAcquisitionStream).ScriptBlock
$script:realPump=(Get-Command Invoke-MedicalAiAcquisitionPump).ScriptBlock;$script:realContext=(Get-Command New-MedicalAiAcquisitionContext).ScriptBlock
$script:pumps=0;$script:cancelAfter=0;$script:lastContext=$null;$script:blockedSource=''
function Invoke-MedicalAiAcquisitionPump($Context){$script:pumps++;if($script:cancelAfter -gt 0 -and $script:pumps -ge $script:cancelAfter){$Context.Cancelled=$true};& $script:realPump $Context}
function New-MedicalAiAcquisitionContext($Owner,[bool]$Downloading){$context=& $script:realContext $Owner $Downloading;$script:lastContext=$context;return $context}
function Assert-MedicalAccountPath([string]$Path){if($Path -ceq $script:blockedSource){throw 'Other employee model path denied intentionally'}}
$script:responses=New-Object Collections.Queue;$script:requests=New-Object Collections.ArrayList
function Invoke-MedicalAiModelHttpSend($Client,[Uri]$Uri,$Context){[void]$script:requests.Add($Uri.AbsoluteUri);if($script:responses.Count -eq 0){throw 'No synthetic HTTP response was arranged; real HTTP is disabled in this suite'};return $script:responses.Dequeue()}
function New-AcquireResponse([int]$status,[byte[]]$bytes,[string]$location='', [long]$declaredLength=-1){
 $response=New-Object Net.Http.HttpResponseMessage ([Net.HttpStatusCode]$status)
 if($null -ne $bytes){$response.Content=New-Object Net.Http.ByteArrayContent(,$bytes);if($declaredLength -ge 0){$response.Content.Headers.ContentLength=$declaredLength}}
 if($location){$response.Headers.Location=New-Object Uri($location,[UriKind]::RelativeOrAbsolute)}
 return $response
}
function Reset-AcquireTransport {$script:responses.Clear();$script:requests.Clear();$script:pumps=0;$script:cancelAfter=0;[Windows.Forms.Application]::CancelOnPump=$false;[Windows.Forms.Application]::CloseOnPump=$false;[Windows.Forms.Application]::DisposeOwner=$null}
function Get-AcquireHash([string]$Path){$stream=[IO.File]::OpenRead($Path);$sha=[Security.Cryptography.SHA256]::Create();try{return ([BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-','').ToLowerInvariant())}finally{$sha.Dispose();$stream.Dispose()}}
function New-AcquireApp([string]$name){$app=Join-Path $script:root $name;[void][IO.Directory]::CreateDirectory((Join-Path $app 'ИИ'));[IO.File]::Copy((Join-Path $Project 'ИИ/model-manifest.json'),(Join-Path $app 'ИИ/model-manifest.json'));return $app}
function New-AcquireFixture([string]$name,[int]$version=3,[long]$size=1048576,[int]$variant=0){$path=Join-Path $script:root $name;$stream=[IO.File]::Open($path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$header=[Text.Encoding]::ASCII.GetBytes('GGUF')+[BitConverter]::GetBytes([uint32]$version);$stream.Write($header,0,8);$stream.SetLength($size);if($size -gt 100){$stream.Position=100;$stream.WriteByte([byte]$variant)}}finally{$stream.Dispose()};return $path}
function Get-AcquireFiles([string]$App){$folder=Join-Path $App 'ИИ/Модели';if(-not [IO.Directory]::Exists($folder)){return ''};return (@(Get-ChildItem -LiteralPath $folder -File|Sort-Object Name|ForEach-Object {$_.Name+' '+(Get-AcquireHash $_.FullName)}) -join "`n")}
function Assert-NoAcquirePartial([string]$App,[string]$label){Assert-Acquire (@(Get-ChildItem -LiteralPath $App -File -Recurse -Filter '*.partial').Count -eq 0) $label}
function New-AcquireMetadata([string]$Hash,[long]$Size){return [pscustomobject]@{sha=('a'*40);siblings=@([pscustomobject]@{rfilename='qwen2.5-0.5b-instruct-q4_k_m.gguf';size=$Size;lfs=[pscustomobject]@{sha256=$Hash;size=$Size}})}}
function Queue-AcquirePreset($Metadata,[byte[]]$Bytes,[string]$Redirect='', [long]$DeclaredLength=-1){$json=[Text.Encoding]::UTF8.GetBytes(($Metadata|ConvertTo-Json -Depth 8 -Compress));$script:responses.Enqueue((New-AcquireResponse 200 $json));if($Redirect){$script:responses.Enqueue((New-AcquireResponse 302 ([byte[]]@()) $Redirect))};$script:responses.Enqueue((New-AcquireResponse 200 $Bytes '' $DeclaredLength))}
$script:root=Join-Path ([IO.Path]::GetTempPath()) ('mc-acquire-model-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($script:root)
try{
 $profile=Join-Path $script:root 'private-profile';[void][IO.Directory]::CreateDirectory($profile)
 $app=New-AcquireApp 'program';$manifest=Get-MedicalAiModelManifest $app
 Assert-Acquire ($manifest.Name -like '*0.5B*' -and $manifest.License -ceq 'Apache-2.0' -and $manifest.Bytes -ge 1048576) 'The shipped recommended-model manifest exposes a small model, public license and approximate display size'
 Assert-Acquire (-not [IO.Directory]::Exists((Join-Path $app 'ИИ/Модели')) -and $script:requests.Count -eq 0) 'Reading the model passport neither creates weights nor starts a network request'
 $validSource=New-AcquireFixture 'PRIVATE PATIENT NAME must not be recorded.gguf';$sourceHash=Get-AcquireHash $validSource
 $oldModel=Join-Path $app 'ИИ/Модели/model-old-good.gguf';[void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($oldModel));[IO.File]::Copy($validSource,$oldModel)
 $oldHash=Get-AcquireHash $oldModel
 Reset-AcquireTransport;$installed=Install-MedicalAiModel $null $app $profile $validSource
 Assert-Acquire ([IO.File]::Exists($installed) -and [IO.Path]::GetFileName($installed) -ceq ('model-'+$sourceHash.Substring(0,12)+'.gguf')) 'Offline installation publishes a content-addressed GGUF filename'
 Assert-Acquire ((Get-AcquireHash $installed) -ceq $sourceHash -and (Get-AcquireHash $validSource) -ceq $sourceHash) 'Streamed offline copy matches the independent hash and preserves source bytes'
 Assert-Acquire ((Get-AcquireHash $oldModel) -ceq $oldHash) 'Offline installation never overwrites an existing different good model'
 Assert-Acquire ($script:requests.Count -eq 0 -and $script:pumps -gt 30) 'Offline copy and disk verification keep pumping cancellation without any HTTP request'
 $metadataText=[IO.File]::ReadAllText($installed+'.json');$metadata=$metadataText|ConvertFrom-Json
 Assert-Acquire ($metadata.Kind -ceq 'ImportedFile' -and $metadata.Sha256 -ceq $sourceHash -and $metadata.Bytes -eq 1048576 -and -not $metadata.Revision -and -not $metadata.Repository) 'Custom GGUF metadata records a local hash without claiming an authenticated preset'
 Assert-Acquire (-not $metadataText.Contains($script:root) -and -not $metadataText.Contains('PRIVATE PATIENT NAME') -and -not $metadataText.Contains($profile)) 'Model metadata contains no absolute source path, employee folder or source filename'
 Assert-NoAcquirePartial $app 'Successful offline copy removes all private partial files'
 $beforeFiles=Get-AcquireFiles $app;$modified=[IO.File]::GetLastWriteTimeUtc($installed)
 $again=Install-MedicalAiModel $null $app $profile $validSource
 Assert-Acquire ($again -ceq $installed -and (Get-AcquireFiles $app) -ceq $beforeFiles -and [IO.File]::GetLastWriteTimeUtc($installed) -eq $modified) 'Reinstalling identical verified bytes reuses the existing model without replacing it'
 $fixtureV2=New-AcquireFixture 'version-2.gguf' 2 1048576 2;$fixtureV2Hash=Get-AcquireHash $fixtureV2
 Assert-Acquire ((Test-MedicalAiAcquiredGguf $fixtureV2) -eq 1048576) 'The offline installer accepts supported GGUF version 2 as well as version 3'
 foreach($spec in @(@('version-1.gguf',1,1048576),@('version-4.gguf',4,1048576),@('too-small.gguf',3,1024),@('too-large.gguf',3,2147483649))){$bad=New-AcquireFixture $spec[0] $spec[1] $spec[2];Assert-AcquireRejected {Install-MedicalAiModel $null $app $profile $bad} ('Reject invalid GGUF fixture '+$spec[0])}
 $wrongMagic=New-AcquireFixture 'wrong-magic.gguf';$stream=[IO.File]::OpenWrite($wrongMagic);try{$stream.WriteByte(0)}finally{$stream.Dispose()}
 Assert-AcquireRejected {Install-MedicalAiModel $null $app $profile $wrongMagic} 'A wrong magic header cannot be published as a model'
 $wrongExtension=Join-Path $script:root 'model.bin';[IO.File]::Copy($validSource,$wrongExtension)
 Assert-AcquireRejected {Install-MedicalAiModel $null $app $profile $wrongExtension} 'Offline installation requires the explicit GGUF file extension'
 $script:blockedSource=$validSource
 Assert-AcquireRejected {Install-MedicalAiModel $null $app $profile $validSource} 'The active-account guard can deny a source in another employee workspace'
 $script:blockedSource=''
 Reset-AcquireTransport;$script:cancelAfter=5
 Assert-AcquireCancelled {Install-MedicalAiModel $null $app $profile $fixtureV2} 'Cancellation during streamed offline copying exits without publishing a partial model'
 Assert-Acquire ((Get-AcquireFiles $app) -ceq $beforeFiles) 'Cancelled copying preserves every previously installed model and metadata file'
 Assert-NoAcquirePartial $app 'Cancelled offline copy removes its partial file'
 Assert-Acquire ((Get-AcquireHash $fixtureV2) -ceq $fixtureV2Hash -and $script:pumps -ge 5) 'Cancellation actually interrupts streaming while preserving the independent source digest'
 Reset-AcquireTransport
 $collisionPath=Join-Path $app ('ИИ/Модели/model-'+(Get-AcquireHash $fixtureV2).Substring(0,12)+'.gguf');[IO.File]::Copy($validSource,$collisionPath)
 $collisionHash=Get-AcquireHash $collisionPath
 Assert-AcquireRejected {Install-MedicalAiModel $null $app $profile $fixtureV2} 'A content-address prefix collision or foreign existing file is never overwritten'
 Assert-Acquire ((Get-AcquireHash $collisionPath) -ceq $collisionHash) 'Collision handling leaves the existing file byte-for-byte unchanged'
 [IO.File]::Delete($collisionPath);Assert-NoAcquirePartial $app 'Collision failure removes only the new private partial'
 $orphanMetadata=$collisionPath+'.json';[IO.File]::WriteAllText($orphanMetadata,'Existing provenance must survive');$orphanHash=Get-AcquireHash $orphanMetadata
 Assert-AcquireRejected {Install-MedicalAiModel $null $app $profile $fixtureV2} 'A metadata publication failure rolls back only the newly published model'
 Assert-Acquire (-not [IO.File]::Exists($collisionPath) -and (Get-AcquireHash $orphanMetadata) -ceq $orphanHash -and (Get-AcquireHash $oldModel) -ceq $oldHash) 'Atomic publication failure preserves old model bytes and pre-existing metadata'
 Assert-NoAcquirePartial $app 'Publication failure cleans both private partial files';[IO.File]::Delete($orphanMetadata)
 function Copy-MedicalAiAcquisitionStream($InputStream,[string]$Destination,[long]$ExpectedBytes,[long]$Maximum,$Context){$received=& $script:realCopy $InputStream $Destination $ExpectedBytes $Maximum $Context;$file=[IO.File]::OpenWrite($Destination);try{$file.Position=200;$file.WriteByte(211)}finally{$file.Dispose()};return $received}
 Assert-AcquireRejected {Install-MedicalAiModel $null $app $profile $fixtureV2} 'A simulated corrupted disk write is detected by the independent post-copy digest'
 Assert-Acquire (-not [IO.File]::Exists($collisionPath) -and (Get-AcquireHash $validSource) -ceq $sourceHash -and (Get-AcquireHash $fixtureV2) -ceq $fixtureV2Hash) 'Post-write corruption never publishes or alters source models'
 Assert-NoAcquirePartial $app 'Post-write corruption removes the damaged private copy'
 Set-Item -LiteralPath Function:Copy-MedicalAiAcquisitionStream -Value $script:realCopy

 foreach($hostAddress in @('https://huggingface.co/file','https://cdn-lfs.huggingface.co/file','https://cas-bridge.xethub.hf.co/file?download=1')){Assert-Acquire ((Assert-MedicalAiModelDownloadUri $hostAddress).Scheme -ceq 'https') ('Allow trusted public model host '+$hostAddress)}
 foreach($hostAddress in @('http://huggingface.co/file','https://example.com/file','https://huggingface.co.attacker.invalid/file','https://attackerhuggingface.co/file','https://hf.co/file','https://user:password@huggingface.co/file','https://huggingface.co:444/file','https://huggingface.co/file#fragment','file:///private/model.gguf','https://127.0.0.1/model')){Assert-AcquireRejected {Assert-MedicalAiModelDownloadUri $hostAddress} ('Reject untrusted model address '+$hostAddress)}
 $presetSource=New-AcquireFixture 'synthetic-model-for-http-tests.gguf' 3 1048576 91;$presetBytes=[IO.File]::ReadAllBytes($presetSource);$presetHash=Get-AcquireHash $presetSource
 $upstream=New-AcquireMetadata $presetHash $presetBytes.Length;$resolved=Resolve-MedicalAiModelDownload $manifest $upstream
 Assert-Acquire ($resolved.Uri -ceq ('https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/'+('a'*40)+'/qwen2.5-0.5b-instruct-q4_k_m.gguf?download=true') -and $resolved.Sha256 -ceq $presetHash) 'Official metadata pins the exact LFS hash, byte size and immutable revision URL'
 $caseMetadata=New-AcquireMetadata $presetHash $presetBytes.Length;$caseMetadata.siblings[0].rfilename=$caseMetadata.siblings[0].rfilename.ToUpperInvariant()
 Assert-Acquire ((Resolve-MedicalAiModelDownload $manifest $caseMetadata).Sha256 -ceq $presetHash) 'The official filename lookup is exact apart from letter case'
 Assert-Acquire ((Resolve-MedicalAiModelDownload $manifest $caseMetadata).Uri.Contains('/'+$caseMetadata.siblings[0].rfilename+'?download=true')) 'The immutable HTTP URL preserves the actual upstream filename case'
 foreach($change in @('bad-revision','missing-hash','bad-hash','too-small','too-large','different-size','missing-file','duplicate-file')){
  $bad=New-AcquireMetadata $presetHash $presetBytes.Length
  switch($change){'bad-revision'{$bad.sha='main'}'missing-hash'{$bad.siblings[0].lfs.sha256=''}'bad-hash'{$bad.siblings[0].lfs.sha256='made-up'}'too-small'{$bad.siblings[0].lfs.size=100}'too-large'{$bad.siblings[0].lfs.size=1073741825}'different-size'{$bad.siblings[0].size=1048577}'missing-file'{$bad.siblings=@()}'duplicate-file'{$bad.siblings+=@($bad.siblings[0])}}
  Assert-AcquireRejected {Resolve-MedicalAiModelDownload $manifest $bad} ('Official metadata rejects '+$change+' without guessing a replacement hash')
 }

 Reset-AcquireTransport;$context=New-MedicalAiAcquisitionContext $null $true;$httpHandler=New-Object AcquireHttpHandler;$httpClient=New-Object Net.Http.HttpClient($httpHandler,$true)
 try{$response=& $script:realHttpSend $httpClient (New-Object Uri $manifest.ApiUrl) $context;try{Assert-Acquire ([int]$response.StatusCode -eq 200 -and $httpHandler.Method -ceq 'GET' -and -not $httpHandler.HasBody -and $httpHandler.Uri -ceq $manifest.ApiUrl) 'The production async HttpClient send path issues a bodyless GET with only the public model URL'}finally{$response.Dispose()}}finally{$httpClient.Dispose();Close-MedicalAiAcquisitionContext $context}
 $downloadApp=New-AcquireApp 'download-program';Reset-AcquireTransport
 Queue-AcquirePreset $upstream $presetBytes 'https://cas-bridge.xethub.hf.co/synthetic-test-model'
 $tlsBefore=[Net.ServicePointManager]::SecurityProtocol;$downloaded=Install-MedicalAiModel $null $downloadApp $profile
 Assert-Acquire ((Get-AcquireHash $downloaded) -ceq $presetHash) 'Synthetic HTTP adapter exercises exact verified download publication with real file hashing'
 Assert-Acquire ($script:requests.Count -eq 3 -and $script:requests[0] -ceq $manifest.ApiUrl -and $script:requests[1] -ceq $resolved.Uri -and $script:requests[2] -ceq 'https://cas-bridge.xethub.hf.co/synthetic-test-model') 'Acquisition requests only public model metadata and allowed model URLs'
 Assert-Acquire (-not (($script:requests -join '|').Contains($profile)) -and -not (($script:requests -join '|').Contains('PRIVATE'))) 'No source filename, profile location, patient data or account name enters an HTTP URL'
 Assert-Acquire ([Net.ServicePointManager]::SecurityProtocol -eq $tlsBefore) 'Temporary TLS 1.2 configuration is restored after acquisition'
 Assert-Acquire (-not $script:lastContext.HttpHandler.AllowAutoRedirect -and -not $script:lastContext.HttpHandler.UseProxy -and -not $script:lastContext.HttpHandler.UseDefaultCredentials) 'Real HttpClient disables automatic redirects, system proxy credentials and default account credentials'
 $downloadMetadata=[IO.File]::ReadAllText($downloaded+'.json')|ConvertFrom-Json
 Assert-Acquire ($downloadMetadata.Kind -ceq 'OfficialPreset' -and $downloadMetadata.Repository -ceq $manifest.Repository -and $downloadMetadata.Revision -ceq ('a'*40) -and $downloadMetadata.Sha256 -ceq $presetHash) 'Preset provenance records only the verified public repository revision and actual file digest'
 Assert-NoAcquirePartial $downloadApp 'Successful synthetic preset acquisition leaves no partial model or metadata'
 $downloadBefore=Get-AcquireFiles $downloadApp
 foreach($failure in @('wrong-checksum','truncated','long-body','wrong-header','wrong-content-length','metadata-error','unsafe-redirect')){
  Reset-AcquireTransport;$meta=New-AcquireMetadata $presetHash $presetBytes.Length;$body=$presetBytes;$declared=-1L;$redirect=''
  switch($failure){'wrong-checksum'{$meta.siblings[0].lfs.sha256='0'*64}'truncated'{$body=New-Object byte[] 524288;$declared=1048576}'long-body'{$body=$presetBytes+(New-Object byte[] 65536);$declared=1048576}'wrong-header'{$body=$presetBytes.Clone();$body[0]=0;$badPath=Join-Path $script:root 'bad-http-body.bin';[IO.File]::WriteAllBytes($badPath,$body);$meta.siblings[0].lfs.sha256=Get-AcquireHash $badPath}'wrong-content-length'{$declared=1048577}'metadata-error'{$meta.sha='main'}'unsafe-redirect'{$redirect='https://attacker.invalid/model'}}
  Queue-AcquirePreset $meta $body $redirect $declared
  Assert-AcquireRejected {Install-MedicalAiModel $null $downloadApp $profile} ('Preset acquisition rejects '+$failure)
  Assert-Acquire ((Get-AcquireFiles $downloadApp) -ceq $downloadBefore) ($failure+' preserves all existing good models and their provenance')
  Assert-NoAcquirePartial $downloadApp ($failure+' removes private partial files')
  if($failure -eq 'unsafe-redirect'){Assert-Acquire ($script:requests.Count -eq 2) 'An unsafe redirect is rejected before sending any request to its host'}
 }
 Reset-AcquireTransport;$script:responses.Enqueue((New-AcquireResponse 503 ([byte[]]@())))
 Assert-AcquireRejected {Install-MedicalAiModel $null $downloadApp $profile} 'HTTP errors fail before attempting a model transfer'
 Assert-Acquire ((Get-AcquireFiles $downloadApp) -ceq $downloadBefore) 'HTTP errors preserve previous installations'
 Reset-AcquireTransport;$script:responses.Enqueue((New-AcquireResponse 200 (New-Object byte[] 2097153)))
 Assert-AcquireRejected {Install-MedicalAiModel $null $downloadApp $profile} 'Oversized model API metadata is bounded to 2 MB'
 Reset-AcquireTransport;Queue-AcquirePreset $upstream $presetBytes;$script:cancelAfter=8
 Assert-AcquireCancelled {Install-MedicalAiModel $null $downloadApp $profile} 'Cancellation also interrupts the real streamed download pipeline'
 Assert-Acquire ((Get-AcquireFiles $downloadApp) -ceq $downloadBefore) 'Cancelled synthetic download preserves prior models'
 Assert-NoAcquirePartial $downloadApp 'Cancelled synthetic download cleans its private partial'
 foreach($redirectCount in @(8,9)){
  Reset-AcquireTransport;$context=New-MedicalAiAcquisitionContext $null $true
  try{for($i=0;$i -lt $redirectCount;$i++){$script:responses.Enqueue((New-AcquireResponse 302 ([byte[]]@()) ('/redirect-'+$i)))};$script:responses.Enqueue((New-AcquireResponse 200 ([byte[]]@(1))))
   if($redirectCount -eq 8){$response=Get-MedicalAiModelHttpResponse $null 'https://huggingface.co/start' $context;try{Assert-Acquire ($script:requests.Count -eq 9 -and [int]$response.StatusCode -eq 200) 'Exactly eight safe redirects are allowed'}finally{$response.Dispose()}}
   else{Assert-AcquireRejected {Get-MedicalAiModelHttpResponse $null 'https://huggingface.co/start' $context} 'A ninth redirect is rejected by the fixed redirect bound';Assert-Acquire ($script:requests.Count -eq 9) 'Redirect overflow sends no tenth request'}
  }finally{Close-MedicalAiAcquisitionContext $context}
 }
 Reset-AcquireTransport;$context=New-MedicalAiAcquisitionContext $null $false
 try{$context.TotalSeconds=-1;Assert-AcquireRejected {Invoke-MedicalAiAcquisitionPump $context} 'The total acquisition deadline cancels without a blocking long wait'}finally{Close-MedicalAiAcquisitionContext $context}
 Reset-AcquireTransport;$context=New-MedicalAiAcquisitionContext $null $false
 try{$context.IoSeconds=0.02;$taskSource=New-Object 'Threading.Tasks.TaskCompletionSource[int]';Assert-AcquireRejected {Wait-MedicalAiAcquisitionTask $taskSource.Task $context} 'A stalled asynchronous operation obeys the I/O deadline and cancellation'}finally{Close-MedicalAiAcquisitionContext $context}
 foreach($mode in @('success','cancel-button','close-progress','disposed-owner','disabled-owner')){
  Reset-AcquireTransport;$owner=New-Object Windows.Forms.Form
  if($mode -eq 'cancel-button'){[Windows.Forms.Application]::CancelOnPump=$true}
  if($mode -eq 'close-progress'){[Windows.Forms.Application]::CloseOnPump=$true}
  if($mode -eq 'disposed-owner'){[Windows.Forms.Application]::DisposeOwner=$owner}
  if($mode -eq 'disabled-owner'){$owner.Enabled=$false}
  if($mode -in @('success','disabled-owner')){$result=Install-MedicalAiModel $owner $app $profile $validSource;Assert-Acquire ($result -ceq $installed) ($mode+' returns the verified local model')}
  else{Assert-AcquireCancelled {Install-MedicalAiModel $owner $app $profile $validSource} ($mode+' cancels acquisition through the actual progress event handlers')}
  Assert-Acquire ($script:lastContext.Dialog.IsDisposed) ($mode+' disposes the native-like progress dialog')
  if($mode -eq 'disposed-owner'){Assert-Acquire ($owner.IsDisposed -and $owner.Activations -eq 0) 'A disposed owner is never reactivated'}else{Assert-Acquire ($owner.Enabled -eq ($mode -ne 'disabled-owner') -and $owner.Activations -eq 1) ($mode+' restores exactly the previous owner enabled state')}
  Assert-NoAcquirePartial $app ($mode+' leaves no temporary partials')
 }

 Reset-AcquireTransport;$owner=New-Object Windows.Forms.Form;$context=New-MedicalAiAcquisitionContext $owner $false
 $context.Dialog.Dispose();$context.Dialog=New-Object AcquireDisposeFailure;$context.HttpClient=New-Object AcquireDisposeFailure
 Close-MedicalAiAcquisitionContext $context
 Assert-Acquire ($owner.Enabled -and $owner.Activations -eq 1 -and -not $context.Watch.IsRunning) 'Cleanup failures still restore the owner and stop the acquisition deadline'
 Reset-AcquireTransport
 if([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT){
  $linked=New-AcquireApp 'linked-program';$outside=Join-Path $script:root 'outside';[void][IO.Directory]::CreateDirectory($outside)
  $null=New-Item -ItemType SymbolicLink -Path (Join-Path $linked 'ИИ/Модели') -Target $outside
  Assert-AcquireRejected {Install-MedicalAiModel $null $linked $profile $validSource} 'A managed models-directory symlink is rejected before writing outside the program'
  Assert-Acquire (@(Get-ChildItem -LiteralPath $outside).Count -eq 0) 'Rejected managed redirection writes no model or partial in its target'
  $dangling=Join-Path $script:root 'dangling';$null=New-Item -ItemType SymbolicLink -Path $dangling -Target (Join-Path $script:root 'does-not-exist')
  Assert-AcquireRejected {Assert-MedicalAiManagedModelPath (Join-Path $dangling 'models') $dangling} 'Dangling managed symlink ancestors are rejected too'
  $sourceLink=Join-Path $script:root 'source-link.gguf';$null=New-Item -ItemType SymbolicLink -Path $sourceLink -Target $validSource
  Assert-AcquireRejected {Install-MedicalAiModel $null $app $profile $sourceLink} 'A selected GGUF symlink cannot bypass the regular-file guard'
 }
 $badApp=New-AcquireApp 'bad-manifest-program';$badManifest=Get-MedicalAiModelManifest $badApp;$badManifest.ApiUrl='https://attacker.invalid/api';[IO.File]::WriteAllText((Join-Path $badApp 'ИИ/model-manifest.json'),($badManifest|ConvertTo-Json))
 Assert-AcquireRejected {Get-MedicalAiModelManifest $badApp} 'A modified passport cannot redirect automatic acquisition to a different API'
 Assert-Acquire ($script:requests.Count -eq 0) 'Local manifest validation and all offline UI operations initiate no HTTP transport'
 Write-Output ('Completed '+$script:checks+' model acquisition checks. GGUF fixtures are synthetic format-test files, not usable model weights. HTTP responses and WinForms widgets were substituted; real streamed file hashing, metadata validation, cancellation, atomic publication and safety guards ran. No authentic model download or Windows UI was claimed.')
}finally{if([IO.Directory]::Exists($script:root)){[IO.Directory]::Delete($script:root,$true)}}
