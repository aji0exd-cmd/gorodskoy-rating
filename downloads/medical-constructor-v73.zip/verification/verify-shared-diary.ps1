﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v73'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Check([bool]$condition,[string]$label){if(-not $condition){throw $label};$script:checks++;Write-Output ('PASS '+$label)}
function Assert-Reject([scriptblock]$operation,[string]$label){$rejected=$false;try{& $operation|Out-Null}catch{$rejected=$true};Assert-Check $rejected $label}
function Import-TestFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors|Out-String)}
 foreach($node in $ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}}
}
function Get-TestFingerprint($source){return ($source|ConvertTo-Json -Depth 80 -Compress)}
function Get-TestTree($path){if(-not [IO.Directory]::Exists($path)){return ''};return ((Get-ChildItem -LiteralPath $path -Recurse -File|Sort-Object FullName|ForEach-Object {$_.FullName+':'+(Get-FileHash -LiteralPath $_.FullName).Hash}) -join ';')}
function Get-TestText($path){$zip=[IO.Compression.ZipFile]::OpenRead($path);try{$x=Get-XmlPart $zip 'word/document.xml';$n=[Xml.XmlNamespaceManager]::new($x.NameTable);$n.AddNamespace('w',$script:ns);return (($x.SelectNodes('//w:t',$n)|ForEach-Object {$_.InnerText}) -join "`n")}finally{$zip.Dispose()}}
function Apply-DocumentFont($path){}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-v73-shared-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 Add-Type -AssemblyName System.IO.Compression.FileSystem
 Import-TestFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
 foreach($module in @('universal.ps1','forms-v59.ps1','clinical-stages-v67.ps1')){Import-TestFunctions (Join-Path $Project $module)}
 $script:medicalProgramRoot=$temp;$script:medicalTemplatesFolder=Join-Path $temp 'Шаблоны';$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-01T10:15:00'}
 $script:universalConfig=New-UniversalConfig;$script:universalValues=@{patient_name='ИМЯ ПЕРВИЧНОГО ОСМОТРА'};$script:universalDetails=@{}
 $script:medicalClinicalForms=$null;$script:medicalClinicalState=$null
 [void](Initialize-MedicalClinicalWorkspace)
 $common=Get-MedicalSharedDiarySchema
 Assert-Check ($null -ne $common -and @($script:medicalClinicalForms.Diaries).Count -eq 0) 'Common diary form exists before adding a patient diary'
 Assert-Check (@(Get-UniversalFields $common).Count -gt 0) 'Empty workspace common form has editable diary fields'
 $common.Sections[1].Title='Общий раздел дневников'
 $choice=New-UniversalField 'shared_extra' 'Общее уточнение' 'SHARED_EXTRA' 'choice_detail';$choice.Options=@('Улучшение','Без изменений')
 $common.Sections[1].Fields+=@($choice)
 [void](Set-MedicalSharedDiarySchema $common)
 Assert-Check (@($script:medicalClinicalForms.Diaries).Count -eq 0) 'Editing common form does not create a patient record'
 Assert-Check ((Get-MedicalSharedDiarySchema).Sections[1].Title -eq 'Общий раздел дневников') 'Common structure edits persist with zero patient records'
 $copied=Get-MedicalSharedDiarySchema;$copied.Sections[1].Title='Mutated external clone'
 Assert-Check ((Get-MedicalSharedDiarySchema).Sections[1].Title -eq 'Общий раздел дневников') 'Common getter returns an independent schema clone'
 $formPath=Join-Path $temp 'empty.mcform';$envelope=Write-MedicalForm $formPath $script:universalConfig 'Пустая общая форма'
 Assert-Check ($null -ne $envelope.StageForms.DiaryForm.TemplateBase64) 'Empty reusable form embeds the common Word template'
 Assert-Check (@($envelope.StageForms.Diaries).Count -eq 0) 'Saving an empty common form keeps its diary count zero'
 $newRoot=Join-Path $temp 'other-install';[void][IO.Directory]::CreateDirectory($newRoot)
 $script:medicalProgramRoot=$newRoot;$script:medicalTemplatesFolder=Join-Path $newRoot 'Шаблоны'
 $opened=Read-MedicalForm $formPath;[void](Initialize-MedicalClinicalWorkspace $opened.StageForms)
 Assert-Check ((Get-MedicalSharedDiarySchema).Sections[1].Title -eq 'Общий раздел дневников') 'Portable common form restores in another installation without records'
 Assert-Check ([IO.File]::Exists((Join-Path $newRoot $script:medicalClinicalForms.DiaryForm.Schema.Template))) 'Portable common Word template is imported with zero records'
 $first=Add-MedicalClinicalDiary;$second=Add-MedicalClinicalDiary
 foreach($entry in @($first,$second)){Assert-Check ($entry.Schema.Sections[1].Title -eq 'Общий раздел дневников') 'Add diary immediately uses the configured shared structure'}
 Set-MedicalClinicalValue 'diary' $first.Id 'diary_complaints' 'ПЕРВЫЙ ОТВЕТ'
 Set-MedicalClinicalValue 'diary' $first.Id 'shared_extra' 'Улучшение' 'ПЕРВОЕ УТОЧНЕНИЕ'
 Set-MedicalClinicalValue 'diary' $first.Id 'patient_name' 'РУЧНОЕ ИМЯ ДНЕВНИКА'
 Set-MedicalClinicalValue 'diary' $second.Id 'diary_complaints' 'ВТОРОЙ ОТВЕТ'
 Set-MedicalClinicalDate $first.Id ([datetime]'2026-10-02T12:34:56');Set-MedicalClinicalDate $second.Id ([datetime]'2026-10-03T18:00:00')
 $script:medicalClinicalForms.Diaries[0].DateCount=2;$script:medicalClinicalState.Diaries[0].EndDateTime='2026-10-05T19:00:00'
 $before=Get-MedicalClinicalState;$beforeForm=Get-MedicalClinicalFormData
 $change=Get-MedicalSharedDiarySchema;$change.Sections[1].Title='Обновленный общий раздел';$change.Sections[1].Fields+=@(New-UniversalField 'new_shared' 'Новое общее поле' 'NEW_SHARED')
 $candidate=Set-MedicalSharedDiaryFormData $beforeForm $change
 Assert-Check ((Get-TestFingerprint $beforeForm) -ceq (Get-TestFingerprint (Get-MedicalClinicalFormData))) 'Pure shared form edit never mutates live structures'
 Assert-Check ($candidate.DiaryForm.Schema.Sections[1].Title -eq 'Обновленный общий раздел') 'Pure shared form edit includes the new common definition'
 Assert-Check (@($candidate.Diaries|Where-Object {$_.Schema.Sections[1].Title -ne 'Обновленный общий раздел'}).Count -eq 0) 'Pure shared form edit updates every reusable diary schema'
 Assert-Check ($candidate.Diaries[0].Id -eq $first.Id -and $candidate.Diaries[0].DateCount -eq 2) 'Pure edit preserves record IDs and per-record date count'
 [void](Set-MedicalSharedDiarySchema $change)
 $a=Get-MedicalClinicalContext 'diary' $first.Id;$b=Get-MedicalClinicalContext 'diary' $second.Id
 Assert-Check ($a.Values.diary_complaints -ceq 'ПЕРВЫЙ ОТВЕТ' -and $b.Values.diary_complaints -ceq 'ВТОРОЙ ОТВЕТ') 'Common schema apply preserves independent diary answers'
 Assert-Check ($a.Details.shared_extra -ceq 'ПЕРВОЕ УТОЧНЕНИЕ') 'Common schema apply preserves per-record clarifications'
 Assert-Check ($a.Values.patient_name -eq 'РУЧНОЕ ИМЯ ДНЕВНИКА' -and $a.Overrides.patient_name) 'Common schema apply preserves manual source-link override'
 Assert-Check ($a.DateCount -eq 2 -and $b.DateCount -eq 1) 'Applying shared schema preserves each record date count independently'
 Assert-Check ($a.DateTime -eq [datetime]'2026-10-02T12:34:56' -and $a.EndDateTime -eq [datetime]'2026-10-05T19:00:00') 'Applying shared schema preserves diary start and end timestamps'
 Assert-Check (@($a.ArchivedFields).Count -eq 0) 'Compatible shared schema edit creates no unnecessary archived fields'
 $third=Add-MedicalClinicalDiary
 Assert-Check ([string]::IsNullOrEmpty([string]$third.Values.diary_complaints) -and [string]::IsNullOrEmpty([string]$third.Details.shared_extra)) 'New diary has fresh patient answers and clarifications'
 Assert-Check (-not $third.Overrides.ContainsKey('patient_name') -and $third.Values.patient_name -eq $script:universalValues.patient_name) 'New diary links current primary demographics without copying prior overrides'
 Assert-Check ($third.Schema.Sections[1].Title -eq 'Обновленный общий раздел') 'New diary sees the latest common structure'
 # Legacy heterogeneous forms keep their original schemas until explicit apply.
 $legacy=Get-MedicalClinicalFormData;$legacy.PSObject.Properties.Remove('DiaryForm')
 $legacy.Diaries[0].Schema.Sections[1].Title='ПЕРВАЯ СТАРАЯ СТРУКТУРА'
 $legacy.Diaries[-1].Schema.Sections[1].Title='ПОСЛЕДНЯЯ СТАРАЯ СТРУКТУРА'
 $legacy.Diaries[0].Schema.Sections[1].Fields+=@(New-UniversalField 'legacy_only' 'Старое заполненное поле' 'LEGACY_ONLY')
 $oldState=Get-MedicalClinicalState;$oldState.Diaries[0].Values | Add-Member -NotePropertyName legacy_only -NotePropertyValue 'НЕ ПОТЕРЯТЬ ДАННЫЕ' -Force;$oldState.Diaries[0].Overrides | Add-Member -NotePropertyName legacy_only -NotePropertyValue $true -Force
 [void](Initialize-MedicalClinicalWorkspace $legacy);Restore-MedicalClinicalState $oldState
 Assert-Check ((Get-MedicalClinicalContext 'diary' $first.Id).Schema.Sections[1].Title -eq 'ПЕРВАЯ СТАРАЯ СТРУКТУРА') 'Opening legacy form preserves first heterogeneous diary schema'
 Assert-Check ((Get-MedicalSharedDiarySchema).Sections[1].Title -eq 'ПОСЛЕДНЯЯ СТАРАЯ СТРУКТУРА') 'Legacy common form is seeded from the last reusable definition'
 $beforeLegacy=Get-MedicalClinicalState;$added=Add-MedicalClinicalDiary
 Assert-Check ($added.Schema.Sections[1].Title -eq 'ПОСЛЕДНЯЯ СТАРАЯ СТРУКТУРА') 'Future add uses common legacy seed without altering older records'
 Assert-Check ((Get-MedicalClinicalContext 'diary' $first.Id).Values.legacy_only -eq 'НЕ ПОТЕРЯТЬ ДАННЫЕ') 'Adding a common record preserves filled legacy-only answers'
 # Unique markers migrate values even when a field ID was recreated in editor.
 $migrate=Get-MedicalSharedDiarySchema
 $migrate.Sections[1].Fields[0].Id='complaints_new_id'
 $migrate.Sections[1].Fields=@($migrate.Sections[1].Fields|Where-Object {$_.Id -ne 'shared_extra'})
 [void](Set-MedicalSharedDiarySchema $migrate)
 $a=Get-MedicalClinicalContext 'diary' $first.Id;$b=Get-MedicalClinicalContext 'diary' $second.Id
 Assert-Check ($a.Values.complaints_new_id -eq 'ПЕРВЫЙ ОТВЕТ' -and $b.Values.complaints_new_id -eq 'ВТОРОЙ ОТВЕТ') 'Unique stable marker migrates answers when IDs change'
 Assert-Check (-not $a.Values.ContainsKey('diary_complaints')) 'Migrated answer is stored under the new field identifier'
 $archived=@($a.ArchivedFields|Where-Object {$_.FieldId -eq 'legacy_only'})
 Assert-Check ($archived.Count -eq 1 -and $archived[0].Value -eq 'НЕ ПОТЕРЯТЬ ДАННЫЕ' -and $archived[0].Override) 'Removed nonempty legacy fields are retained as labeled patient archive'
 $archivedDetail=@($a.ArchivedFields|Where-Object {$_.FieldId -eq 'shared_extra'})
 Assert-Check ($archivedDetail.Count -eq 1 -and $archivedDetail[0].Detail -eq 'ПЕРВОЕ УТОЧНЕНИЕ') 'Removed clarification fields retain their answer and detail in patient archive'
 $patient=Get-MedicalClinicalState;$portable=Get-MedicalClinicalFormData
 Assert-Check (-not (Get-TestFingerprint $portable).Contains('НЕ ПОТЕРЯТЬ ДАННЫЕ')) 'Archived clinical answers never enter reusable forms'
 Assert-Check ((Get-TestFingerprint $patient).Contains('НЕ ПОТЕРЯТЬ ДАННЫЕ')) 'Patient checkpoints retain archived legacy answers'
 [void](Initialize-MedicalClinicalWorkspace $portable);Restore-MedicalClinicalState ($patient|ConvertTo-Json -Depth 80|ConvertFrom-Json)
 Assert-Check (@((Get-MedicalClinicalContext 'diary' $first.Id).ArchivedFields|Where-Object {$_.Value -eq 'НЕ ПОТЕРЯТЬ ДАННЫЕ'}).Count -eq 1) 'Archived fields survive JSON card-state roundtrip'
 $bad=Copy-UniversalObject $patient;$bad.Diaries[0].ArchivedFields[0].Override='yes'
 $before=Get-TestFingerprint (Get-MedicalClinicalState)
 Assert-Reject {Restore-MedicalClinicalState $bad} 'Malformed archive is rejected instead of being coerced'
 Assert-Check ((Get-TestFingerprint (Get-MedicalClinicalState)) -ceq $before) 'Rejected archived state leaves live diary data unchanged'
 $invalid=Get-MedicalSharedDiarySchema;$invalid.Sections[0].Title=''
 $beforeForm=Get-TestFingerprint (Get-MedicalClinicalFormData)
 Assert-Reject {Set-MedicalSharedDiarySchema $invalid} 'Invalid common schema is rejected before publishing candidates'
 Assert-Check ((Get-TestFingerprint (Get-MedicalClinicalFormData)) -ceq $beforeForm -and (Get-TestFingerprint (Get-MedicalClinicalState)) -ceq $before) 'Failed common apply preserves both live structures and patient state'
 # Common file integrity must validate even when there are no patient diary entries.
 foreach($entry in @(Get-MedicalClinicalDiaryContexts)){Remove-MedicalClinicalDiary $entry.Id}
 Assert-Check (@(Get-MedicalClinicalDiaryContexts).Count -eq 0) 'Deleting all patient records empties the working diary list'
 Assert-Check ((Get-MedicalSharedDiarySchema).Sections[1].Fields[0].Id -eq 'complaints_new_id') 'Deleting the last diary retains the configured common structure'
 $again=Add-MedicalClinicalDiary
 Assert-Check ($again.Schema.Sections[1].Fields[0].Id -eq 'complaints_new_id') 'Adding after last deletion reuses the common form'
 Remove-MedicalClinicalDiary $again.Id
 $zeroForm=Write-MedicalForm (Join-Path $temp 'after-delete.mcform') $script:universalConfig 'После удаления'
 Assert-Check ($zeroForm.StageForms.DiaryForm.TemplateBase64.Length -gt 100 -and @($zeroForm.StageForms.Diaries).Count -eq 0) 'Saving after last deletion retains embedded common Word template'
 $bad=Copy-UniversalObject $zeroForm;$bad.StageForms.DiaryForm.TemplateSha256=('0'*64)
 $badPath=Join-Path $temp 'bad-common.mcform';[IO.File]::WriteAllText($badPath,($bad|ConvertTo-Json -Depth 80))
 $tree=Get-TestTree $newRoot
 Assert-Reject {Read-MedicalForm $badPath} 'Corrupt common Word asset rejects an otherwise empty form'
 Assert-Check ((Get-TestTree $newRoot) -ceq $tree) 'Every common asset validates before any template import'
 $bad=Copy-UniversalObject $zeroForm;$bad.StageForms.DiaryForm.PSObject.Properties.Remove('TemplateBase64')
 [IO.File]::WriteAllText($badPath,($bad|ConvertTo-Json -Depth 80))
 Assert-Reject {Read-MedicalForm $badPath} 'Saved common form cannot omit its Word asset'
 $generation=Add-MedicalClinicalDiaryPeriod '2026-10-01' '2026-10-03'
 Assert-Check ($generation.AddedCount -eq 2) 'Period generation creates one common-structure diary per required day'
 foreach($entry in @(Get-MedicalClinicalDiaryContexts)){Assert-Check ($entry.Schema.Sections[1].Fields[0].Id -eq 'complaints_new_id') 'Period-generated record uses the common form'}
 Assert-Check ($script:medicalClinicalForms.Version -eq 1 -and $script:medicalClinicalState.Version -eq 1) 'Existing version-one form and card envelopes remain compatible'
 # Generated numbering remains clear after deletion, while custom titles survive.
 [void](Initialize-MedicalClinicalWorkspace)
 $numberOne=Add-MedicalClinicalDiary;$numberTwo=Add-MedicalClinicalDiary;$numberThree=Add-MedicalClinicalDiary
 $script:medicalClinicalForms.Diaries[0].Title='Особый дневник врача'
 Remove-MedicalClinicalDiary $numberTwo.Id
 $numberFour=Add-MedicalClinicalDiary
 Assert-Check ((Get-MedicalClinicalContext 'diary' $numberOne.Id).Title -eq 'Особый дневник врача') 'Deleting another diary preserves a custom record title'
 Assert-Check ((Get-MedicalClinicalContext 'diary' $numberThree.Id).Title -eq 'Дневник наблюдения №2' -and $numberFour.Title -eq 'Дневник наблюдения №3') 'Delete then add keeps generated diary titles unique and ordered'
 $before=Get-TestFingerprint (Get-MedicalClinicalState)
 Assert-Reject {Remove-MedicalClinicalDiary 'missing'} 'Unknown diary deletion is rejected'
 Assert-Check ((Get-TestFingerprint (Get-MedicalClinicalState)) -ceq $before) 'Rejected deletion cannot remove another diary patient record'
 # A custom shared form may reuse initial-examination field IDs. These must not
 # copy clinical answers or clarifications when a new patient diary is added.
 $shared=Copy-MedicalFormSchema $script:universalConfig
 $script:universalValues.complaints='ПЕРВИЧНЫЕ ЖАЛОБЫ НЕ КОПИРОВАТЬ'
 $complaint=@(Get-UniversalFields $shared|Where-Object {$_.Id -eq 'complaints'})[0]
 $complaint.Type='choice_detail';$complaint.Options=@('ПЕРВИЧНЫЕ ЖАЛОБЫ НЕ КОПИРОВАТЬ','Другой ответ')
 $script:universalDetails.complaints='ПЕРВИЧНОЕ УТОЧНЕНИЕ НЕ КОПИРОВАТЬ'
 [void](Set-MedicalSharedDiarySchema $shared)
 $blank=Add-MedicalClinicalDiary
 Assert-Check ([string]::IsNullOrEmpty([string]$blank.Values.complaints) -and [string]::IsNullOrEmpty([string]$blank.Details.complaints)) 'Custom common form with initial IDs starts new clinical answers and details blank'
 Assert-Check ($blank.Values.patient_name -eq $script:universalValues.patient_name) 'Custom common form still links patient identity'
 [void](Set-MedicalSharedDiarySchema $shared);$blank=Get-MedicalClinicalContext 'diary' $blank.Id
 Assert-Check ([string]::IsNullOrEmpty([string]$blank.Values.complaints) -and [string]::IsNullOrEmpty([string]$blank.Details.complaints)) 'Reapplying common schema cannot repopulate blank diary clinical answers'
 $bulk=Add-MedicalClinicalDiaryPeriod '2026-10-01' '2026-10-03'
 foreach($id in $bulk.DiaryIds){$entry=Get-MedicalClinicalContext 'diary' $id;Assert-Check ([string]::IsNullOrEmpty([string]$entry.Values.complaints)) 'Period generation with custom initial IDs keeps clinical answers blank'}
 # Stable identifiers take precedence over a marker claimed by another new field.
 [void](Initialize-MedicalClinicalWorkspace)
 $collision=Add-MedicalClinicalDiary
 Set-MedicalClinicalValue 'diary' $collision.Id 'diary_complaints' 'СТАБИЛЬНОЕ ПОЛЕ А'
 Set-MedicalClinicalValue 'diary' $collision.Id 'diary_examination' 'СТАРОЕ ПОЛЕ Б'
 $changed=Get-MedicalSharedDiarySchema
 $changed.Sections[1].Fields[0].Marker='DIARY_EXAMINATION'
 $changed.Sections[2].Fields[0].Id='recreated_examination';$changed.Sections[2].Fields[0].Marker='DIARY_COMPLAINTS'
 [void](Set-MedicalSharedDiarySchema $changed)
 $collision=Get-MedicalClinicalContext 'diary' $collision.Id
 Assert-Check ($collision.Values.diary_complaints -eq 'СТАБИЛЬНОЕ ПОЛЕ А') 'Stable field ID wins when marker assignments are rearranged'
 Assert-Check ([string]::IsNullOrEmpty([string]$collision.Values.recreated_examination)) 'Marker migration never duplicates an answer reserved by its stable field ID'
 Assert-Check (@($collision.ArchivedFields|Where-Object {$_.Value -eq 'СТАРОЕ ПОЛЕ Б'}).Count -eq 1) 'Ambiguous marker reassignment archives the unmatched answer instead of discarding it'
 # Details removed by a type change remain available in the old-field archive.
 $detailForm=Get-MedicalSharedDiarySchema;$extra=New-UniversalField 'detail_type_change' 'Поле с уточнением' 'TYPE_CHANGE' 'choice_detail';$extra.Options=@('Да','Нет')
 $detailForm.Sections[1].Fields+=@($extra);[void](Set-MedicalSharedDiarySchema $detailForm)
 Set-MedicalClinicalValue 'diary' $collision.Id 'detail_type_change' 'Да' 'СОХРАНИТЬ УТОЧНЕНИЕ ПРИ СМЕНЕ ТИПА'
 $detailForm=Get-MedicalSharedDiarySchema;@($detailForm.Sections[1].Fields|Where-Object {$_.Id -eq 'detail_type_change'})[0].Type='multiline'
 [void](Set-MedicalSharedDiarySchema $detailForm)
 $collision=Get-MedicalClinicalContext 'diary' $collision.Id
 Assert-Check ($collision.Values.detail_type_change -eq 'Да') 'Changing a field type preserves its existing main answer'
 Assert-Check (@($collision.ArchivedFields|Where-Object {$_.Detail -eq 'СОХРАНИТЬ УТОЧНЕНИЕ ПРИ СМЕНЕ ТИПА'}).Count -eq 1) 'Changing detail field to plain text archives its now-hidden clarification'
 $archiveCount=@($collision.ArchivedFields).Count;[void](Set-MedicalSharedDiarySchema $detailForm)
 Assert-Check (@((Get-MedicalClinicalContext 'diary' $collision.Id).ArchivedFields).Count -eq $archiveCount) 'Reapplying unchanged structure does not duplicate archived answers'
 $definition=$script:medicalClinicalForms.Diaries[0]
 $archiveOnly=[pscustomobject]@{DateIsAutomatic=$true;Values=@{};Details=@{};Overrides=@{};ArchivedFields=@([pscustomobject]@{FieldId='removed';Marker='REMOVED';Label='Удаленное поле';Value='ЕСТЬ ДАННЫЕ';Detail='';Override=$false})}
 Assert-Check (-not (Test-MedicalClinicalDiaryPlaceholder $definition $archiveOnly)) 'Diary with archived clinical answers is never treated as a blank scheduling placeholder'
 Write-Output ('CHECKS '+$script:checks)
}finally{if([IO.Directory]::Exists($temp)){Remove-Item -LiteralPath $temp -Recurse -Force}}
