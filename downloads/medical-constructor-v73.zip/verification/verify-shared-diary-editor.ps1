﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v73'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-SharedEditor([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
function Assert-SharedEditorReject([scriptblock]$action,[string]$message){$rejected=$false;try{& $action | Out-Null}catch{$rejected=$true};Assert-SharedEditor $rejected $message}
function Import-SharedEditorFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors|Out-String)}
 foreach($node in $ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
  if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}
 }
}
function Get-SharedEditorJson($value){if($value -and $value.PSObject.Properties['Sections'] -and $value.PSObject.Properties['Version']){$value=Copy-MedicalFormSchema $value};return ($value|ConvertTo-Json -Depth 70 -Compress)}
function Get-SharedEditorTree([string]$path){if(-not [IO.Directory]::Exists($path)){return ''};return ((Get-ChildItem -LiteralPath $path -File -Recurse | Sort-Object FullName | ForEach-Object {$_.FullName+':'+(Get-FileHash -LiteralPath $_.FullName).Hash}) -join ';')}
# Only OS modal dialogs are adapted. Schema copying, shared-form updates,
# document model serialization, atomic MCFORM persistence and editor dispatch
# below are the production functions shipped with the application.
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @'
using System;
using System.Collections.Generic;
namespace Windows.Forms {
 public sealed class SaveFileDialog:IDisposable {
  public static string Result="Cancel";public static string Destination="";public static int Calls;public static int Disposals;
  public string Filter;public string DefaultExt;public bool AddExtension;public bool OverwritePrompt;public string Title;public string InitialDirectory;public string FileName;
  public string ShowDialog(object owner){Calls++;if(Result=="OK")FileName=Destination;return Result;}public void Dispose(){Disposals++;}
 }
 public static class MessageBox {
  public static List<string> Messages=new List<string>();
  public static string Show(params object[] args){Messages.Add(args.Length>1?Convert.ToString(args[1]):"");return "Cancel";}
 }
}
'@
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-shared-diary-editor-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
try{
 Import-SharedEditorFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
 foreach($file in @('universal.ps1','forms-v59.ps1','clinical-stages-v67.ps1','template-editor-v59.ps1')){Import-SharedEditorFunctions (Join-Path $Project $file)}
 $script:medicalProgramRoot=$temp;$script:medicalTemplatesFolder=Join-Path $temp 'Шаблоны';$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-16T12:34:56'}
 $script:universalConfig=New-UniversalConfig
 $script:universalValues=@{patient_name='PATIENT SECRET';complaints='INITIAL ANSWER SECRET'};$script:universalDetails=@{complaints='INITIAL DETAIL SECRET'}
 $script:stage='diary';$script:medicalActiveDiaryId='stale-record-id';$script:activeMedicalFormName='Общая форма';$script:activeMedicalFormPath='';$script:medicalWorkspaceReady=$true
 [void](Initialize-MedicalClinicalWorkspace)
 $schema=Get-MedicalSharedDiarySchema
 $schema.Sections[1].Title='Единая структура дневника';$schema.Sections[1].Fields[0].Label='Общие жалобы дневника'
 $source=Join-Path $temp 'Общий дневник.docx';New-UniversalTemplate $source $schema
 $model=Read-MedicalTemplateModel $source
 $context=New-MedicalEditorSaveContext $schema 'edit' 'diary' 'must-not-target-record' 'DiaryForm'
 Assert-SharedEditor ($context.Scope -ceq 'DiaryForm' -and $context.Stage -ceq 'diary' -and [string]::IsNullOrEmpty($context.ClinicalId)) 'Shared editor context targets the reusable diary form rather than a diary record'
 Assert-SharedEditor (@($context.StageForms.Diaries).Count -eq 0 -and $context.StageForms.DiaryForm) 'Shared editor context is valid before the first diary exists'
 Assert-SharedEditorReject {New-MedicalEditorSaveContext $schema 'edit' 'diary' '' 'UnknownScope'} 'Unsupported shared editor scope is rejected'
 Assert-SharedEditorReject {New-MedicalEditorSaveContext $schema 'new' 'diary' '' 'DiaryForm'} 'Creating a new whole form cannot masquerade as an existing common-diary edit'
 $contextBefore=Get-SharedEditorJson $context;$formsBefore=Get-SharedEditorJson $script:medicalClinicalForms;$stateBefore=Get-SharedEditorJson $script:medicalClinicalState
 $treeBefore=Get-SharedEditorTree $script:medicalTemplatesFolder
 $cancelled=Save-MedicalEditorFormSnapshot $schema $model 'Общий дневник.docx' $context $null
 Assert-SharedEditor (-not $cancelled -and (Get-SharedEditorJson $context) -ceq $contextBefore) 'Cancelling Save preserves the shared editor destination and snapshot'
 Assert-SharedEditor ((Get-SharedEditorTree $script:medicalTemplatesFolder) -ceq $treeBefore -and [Windows.Forms.SaveFileDialog]::Calls -eq [Windows.Forms.SaveFileDialog]::Disposals) 'Cancelling Save imports no template and disposes the picker'
 $context.Path=Join-Path $temp 'Общая форма без записей.mcform'
 $saved=Save-MedicalEditorFormSnapshot $schema $model 'Общий дневник.docx' $context $null
 $opened=Read-MedicalForm $context.Path
 Assert-SharedEditor ([IO.File]::Exists($context.Path) -and $saved.SavedSnapshotMatches) 'Shared editor Save writes a real reusable mcform without requiring diary records'
 Assert-SharedEditor (@($opened.StageForms.Diaries).Count -eq 0 -and $opened.StageForms.DiaryForm.Schema.Sections[1].Title -ceq 'Единая структура дневника') 'An empty saved diary list retains its authored common diary schema'
 Assert-SharedEditor ($opened.Schema.Sections[0].Fields[0].Label -ceq $script:universalConfig.Sections[0].Fields[0].Label) 'Saving the common diary form preserves the initial examination schema'
 Assert-SharedEditor ((Get-SharedEditorJson $script:medicalClinicalForms) -ceq $formsBefore -and (Get-SharedEditorJson $script:medicalClinicalState) -ceq $stateBefore) 'Saving a modal shared snapshot does not publish draft structure or alter patient state'
 Assert-SharedEditor ((Get-SharedEditorJson $saved.SavedStageForms.DiaryForm.Schema) -ceq (Get-SharedEditorJson $saved.Schema)) 'Saved editor result and reusable common schema carry exactly the same Word reference'
 $embedded=Get-UniversalTemplatePath $opened.Schema
 Assert-SharedEditor ([IO.File]::Exists($embedded)) 'Saved reusable initial schema still resolves its embedded template'
 # Editing the live common schema and creating records use the same production
 # schema/data functions; answers are subsequently independent of structure.
 [void](Set-MedicalSharedDiarySchema $saved.Schema)
 $first=Add-MedicalClinicalDiary;$second=Add-MedicalClinicalDiary
 Set-MedicalClinicalValue 'diary' $first.Id 'diary_complaints' 'FIRST DIARY SECRET'
 Set-MedicalClinicalValue 'diary' $second.Id 'diary_complaints' 'SECOND DIARY SECRET'
 Set-MedicalClinicalValue 'diary' $first.Id 'patient_name' 'MANUAL DIARY PATIENT SECRET'
 Set-MedicalClinicalDate $first.Id ([datetime]'2026-10-17T08:09:10')
 Set-MedicalClinicalDate $second.Id ([datetime]'2026-10-18T08:09:10')
 $script:medicalActiveDiaryId=$second.Id
 $edited=Copy-MedicalFormSchema $saved.Schema;$edited.Sections[1].Fields[0].Label='Новое общее название'
 $editedPath=Join-Path $temp 'Проверяемый общий Word.docx';New-UniversalTemplate $editedPath $edited
 $editedModel=Read-MedicalTemplateModel $editedPath
 $paragraph=$editedModel.Paragraphs[0];Set-MedicalTemplateParagraph $editedModel $paragraph.Id 'Оформленный общий дневник'
 $paragraph=$editedModel.Paragraphs[0];$doc=$paragraph.Node.OwnerDocument
 $pPr=$doc.CreateElement('w','pPr',$script:ns);$jc=$doc.CreateElement('w','jc',$script:ns);$jc.SetAttribute('val',$script:ns,'center');[void]$pPr.AppendChild($jc);[void]$paragraph.Node.PrependChild($pPr)
 $sourceHash=(Get-FileHash -LiteralPath $editedPath).Hash
 $context=New-MedicalEditorSaveContext $edited 'edit' 'diary' $second.Id 'DiaryForm';$context.Path=Join-Path $temp 'Общая форма с записями.mcform'
 $formsBefore=Get-SharedEditorJson $script:medicalClinicalForms;$stateBefore=Get-SharedEditorJson $script:medicalClinicalState
 $savedMany=Save-MedicalEditorFormSnapshot $edited $editedModel 'Оформленный общий дневник.docx' $context $null
 $openedMany=Read-MedicalForm $context.Path
 Assert-SharedEditor (@($openedMany.StageForms.Diaries).Count -eq 2) 'Shared Save retains the existing diary record definitions'
 Assert-SharedEditor ($openedMany.StageForms.DiaryForm.Schema.Sections[1].Fields[0].Label -ceq 'Новое общее название') 'Shared Save updates the canonical reusable diary form'
 foreach($definition in $openedMany.StageForms.Diaries){
  Assert-SharedEditor ($definition.Schema.Sections[1].Fields[0].Label -ceq 'Новое общее название') ('Shared Save updates existing diary schema '+$definition.Id)
  Assert-SharedEditor ((Get-SharedEditorJson $definition.Schema) -ceq (Get-SharedEditorJson $openedMany.StageForms.DiaryForm.Schema)) ('Saved existing diary uses exactly the common Word template '+$definition.Id)
 }
 $text=[IO.File]::ReadAllText($context.Path)
 foreach($secret in @('PATIENT SECRET','INITIAL ANSWER SECRET','INITIAL DETAIL SECRET','FIRST DIARY SECRET','SECOND DIARY SECRET','MANUAL DIARY PATIENT SECRET')){Assert-SharedEditor (-not $text.Contains($secret)) ('Reusable shared diary save excludes '+$secret)}
 Assert-SharedEditor ((Get-SharedEditorJson $script:medicalClinicalForms) -ceq $formsBefore -and (Get-SharedEditorJson $script:medicalClinicalState) -ceq $stateBefore) 'Shared Save leaves every live diary answer, date, override and schema unchanged until Apply'
 Assert-SharedEditor ((Get-FileHash -LiteralPath $editedPath).Hash -ceq $sourceHash) 'Serializing an edited common Word model preserves the selected source file bytes'
 $resultPath=Get-UniversalTemplatePath $savedMany.Schema;$verifiedModel=Read-MedicalTemplateModel $resultPath
 Assert-SharedEditor ($verifiedModel.Paragraphs[0].Text -ceq 'Оформленный общий дневник') 'Shared Save serializes the actual edited Word text rather than rebuilding a replacement template'
 $namespace=Get-MedicalEditorNamespace $verifiedModel.Paragraphs[0].Node.OwnerDocument
 Assert-SharedEditor ($verifiedModel.Paragraphs[0].Node.SelectSingleNode('w:pPr/w:jc',$namespace).GetAttribute('val',$script:ns) -ceq 'center') 'The common Word template preserves authored paragraph alignment during Save'
 $savedMany.SavedStageForms.DiaryForm.Schema.Sections[1].Title='Only mutate returned clone'
 Assert-SharedEditor ($context.StageForms.DiaryForm.Schema.Sections[1].Title -cne 'Only mutate returned clone') 'Returned saved stage definitions are independent clones of the editor save context'
 $savedMany.SavedStageForms.DiaryForm.Schema.Sections[1].Title=$context.StageForms.DiaryForm.Schema.Sections[1].Title
 $failedContext=New-MedicalEditorSaveContext $edited 'edit' 'diary' '' 'DiaryForm';$failedContext.Path=Join-Path $temp 'missing-folder/Failure.mcform'
 $failedContextBefore=Get-SharedEditorJson $failedContext;$formsBefore=Get-SharedEditorJson $script:medicalClinicalForms;$stateBefore=Get-SharedEditorJson $script:medicalClinicalState
 Assert-SharedEditorReject {Save-MedicalEditorFormSnapshot $edited $editedModel 'Оформленный общий дневник.docx' $failedContext $null} 'A shared-form persistence failure is reported instead of returning a saved result'
 Assert-SharedEditor ((Get-SharedEditorJson $failedContext) -ceq $failedContextBefore -and -not [IO.File]::Exists($failedContext.Path)) 'Failed atomic Save publishes no context metadata or partial mcform'
 Assert-SharedEditor ((Get-SharedEditorJson $script:medicalClinicalForms) -ceq $formsBefore -and (Get-SharedEditorJson $script:medicalClinicalState) -ceq $stateBefore) 'Failed shared-form Save preserves all live reusable definitions and patient answers'
 # Legacy selected-record save contexts remain valid and cannot silently
 # overwrite the new canonical common form.
 $legacy=New-MedicalEditorSaveContext $edited 'edit' 'diary' $first.Id
 $legacy.Path=Join-Path $temp 'Совместимость отдельного дневника.mcform'
 $legacySchema=Copy-MedicalFormSchema $edited;$legacySchema.Sections[1].Fields[0].Label='Только совместимость старого редактора'
 $legacyModelPath=Join-Path $temp 'Старый дневник.docx';New-UniversalTemplate $legacyModelPath $legacySchema
 [void](Save-MedicalEditorFormSnapshot $legacySchema (Read-MedicalTemplateModel $legacyModelPath) 'Старый дневник.docx' $legacy $null)
 $legacyOpened=Read-MedicalForm $legacy.Path
 Assert-SharedEditor ($legacyOpened.StageForms.Diaries[0].Schema.Sections[1].Fields[0].Label -ceq 'Только совместимость старого редактора') 'Legacy per-record editor context still targets its stable diary identifier'
 Assert-SharedEditor ($legacyOpened.StageForms.DiaryForm.Schema.Sections[1].Fields[0].Label -cne 'Только совместимость старого редактора') 'Legacy selected-record Save does not silently change the common diary form'
 # Main command uses the production dispatcher. The modal boundary returns
 # either Cancel or a real result from the persistent-save path above.
 Import-SharedEditorFunctions (Join-Path $Project 'forms-ui-v59.ps1') @('Invoke-MedicalFormTemplateEditor','Invoke-MedicalRestoreEditorDraft','Set-MedicalEditorSavedFormMetadata','Get-MedicalFormSignature','Get-MedicalGeneratedSchema')
 $script:captures=0;$script:opens=0;$script:checkpointCalls=0;$script:marked=0;$script:addAttempts=0;$script:editorCalls=0;$script:nextEditorResult=$null;$script:lastEditorCall=$null
 function Capture-Stage {$script:captures++}
 function Capture-MedicalClinicalStage {$script:captures++}
 function Open-MedicalClinicalStage {$script:opens++}
 function Request-MedicalClinicalCheckpoint {$script:checkpointCalls++}
 function Mark-MedicalFormSaved {$script:marked++}
 function Invoke-MedicalAddDiary {$script:addAttempts++;throw 'Editor must not create a diary'}
 function Ensure-MedicalClinicalTemplate {return $true}
 function Ensure-MedicalCurrentTemplate {return $true}
 function Show-MedicalFormTemplateEditor($owner,$config,$recoveryDraft=$null,[string]$draftPurpose='edit',$saveContext=$null){
  $script:editorCalls++;$script:lastEditorCall=[pscustomobject]@{Schema=(Copy-MedicalFormSchema $config);Recovery=$recoveryDraft;Purpose=$draftPurpose;Context=$saveContext}
  return $script:nextEditorResult
 }
 $form=$null;$script:stage='diary';$before=Get-SharedEditorJson $script:medicalClinicalState
 Invoke-MedicalFormTemplateEditor
 Assert-SharedEditor ($script:editorCalls -eq 1 -and $script:lastEditorCall.Context.Scope -ceq 'DiaryForm' -and -not $script:lastEditorCall.Context.ClinicalId) 'Global diary editor command opens a shared-form context despite an active diary record'
 Assert-SharedEditor ($script:addAttempts -eq 0 -and (Get-SharedEditorJson $script:medicalClinicalState) -ceq $before) 'Cancelling the common diary editor adds no entry and preserves patient data'
 $script:nextEditorResult=$savedMany;Invoke-MedicalFormTemplateEditor
 Assert-SharedEditor ((Get-MedicalSharedDiarySchema).Sections[1].Fields[0].Label -ceq 'Новое общее название') 'Applying the saved editor result publishes the same common schema to the live workspace'
 foreach($id in @($first.Id,$second.Id)){Assert-SharedEditor ((Get-MedicalClinicalContext 'diary' $id).Schema.Sections[1].Fields[0].Label -ceq 'Новое общее название') ('Applying shared editor updates existing diary '+$id)}
 Assert-SharedEditor ((Get-MedicalClinicalContext 'diary' $first.Id).Values.diary_complaints -ceq 'FIRST DIARY SECRET' -and (Get-MedicalClinicalContext 'diary' $second.Id).Values.diary_complaints -ceq 'SECOND DIARY SECRET') 'Applying a common form retains independent answers in each existing diary'
 Assert-SharedEditor ((Get-MedicalClinicalContext 'diary' $first.Id).Values.patient_name -ceq 'MANUAL DIARY PATIENT SECRET') 'Applying a common form retains manual overrides of source-linked demographics'
 Assert-SharedEditor ($script:marked -eq 1 -and $script:activeMedicalFormPath -ceq $savedMany.SavedFormPath) 'Shared editor handoff marks the actual saved reusable form path as saved'
 Assert-SharedEditor ($script:addAttempts -eq 0 -and @($script:medicalClinicalForms.Diaries).Count -eq 2) 'Applying the common editor never inserts an implicit diary record'
 Remove-MedicalClinicalDiary $first.Id;Remove-MedicalClinicalDiary $second.Id
 $script:nextEditorResult=$null;$script:stage='diary';$script:medicalActiveDiaryId='deleted-id';$calls=$script:editorCalls
 Invoke-MedicalFormTemplateEditor
 Assert-SharedEditor ($script:editorCalls -eq $calls+1 -and $script:lastEditorCall.Context.Scope -ceq 'DiaryForm' -and @($script:medicalClinicalForms.Diaries).Count -eq 0 -and $script:addAttempts -eq 0) 'The common form editor remains available after deleting the last diary'
 # The very first editor opening also accepts the generated default form.
 [void](Set-MedicalSharedDiarySchema (New-MedicalDiarySchema $script:universalConfig))
 $calls=$script:editorCalls;Invoke-MedicalFormTemplateEditor
 Assert-SharedEditor ($script:editorCalls -eq $calls+1 -and $script:lastEditorCall.Schema.AutoTemplate -and @($script:medicalClinicalForms.Diaries).Count -eq 0) 'A generated default common form opens in the editor before creating the first diary'
 # Missing Word references are recovered as a staged editor candidate. Neither
 # cancelling the source picker nor cancelling the editor publishes that path.
 $missingSchema=Copy-MedicalFormSchema $savedMany.Schema;$missingSchema.Template='Missing common Word.docx';[void](Set-MedicalSharedDiarySchema $missingSchema)
 $script:recoveryChoice=$null;$script:recoveryChoiceCalls=0
 function Show-MedicalTemplateRecoveryChoice($owner,$schema,$purpose){$script:recoveryChoiceCalls++;return $script:recoveryChoice}
 $calls=$script:editorCalls;Invoke-MedicalFormTemplateEditor
 Assert-SharedEditor ($script:editorCalls -eq $calls -and $script:recoveryChoiceCalls -eq 1 -and (Get-MedicalSharedDiarySchema).Template -ceq 'Missing common Word.docx') 'Cancelling missing-source recovery preserves the common form and does not enter the editor'
 $script:recoveryChoice=[pscustomobject]@{Schema=$savedMany.Schema};Invoke-MedicalFormTemplateEditor
 Assert-SharedEditor ($script:editorCalls -eq $calls+1 -and (Get-MedicalSharedDiarySchema).Template -ceq 'Missing common Word.docx') 'Cancelling the editor after selecting a replacement Word source keeps the previous common-form reference'
 Assert-SharedEditor (@($script:medicalClinicalForms.Diaries).Count -eq 0 -and $script:addAttempts -eq 0) 'Neither missing-source recovery path inserts a diary as a side effect'
 [void](Set-MedicalSharedDiarySchema $savedMany.Schema)
 # A recovered common-form draft deliberately contains no record identifier.
 # Reopening it must target the shared definition even with no diary records.
 $script:recoveredDraft=[pscustomobject]@{Scope='DiaryForm';Stage='diary';ClinicalId='';Purpose='edit';Schema=$savedMany.Schema;Model=$verifiedModel}
 function Get-MedicalRecoveredEditorDraft {return $script:recoveredDraft}
 $script:stage='initial';$script:medicalActiveDiaryId='deleted-id';$calls=$script:editorCalls
 Invoke-MedicalRestoreEditorDraft
 Assert-SharedEditor ($script:editorCalls -eq $calls+1 -and $script:lastEditorCall.Context.Scope -ceq 'DiaryForm' -and -not $script:lastEditorCall.Context.ClinicalId) 'Recovered common diary editor reopens the shared definition without resolving a deleted diary'
 Assert-SharedEditor ($script:lastEditorCall.Recovery -eq $script:recoveredDraft -and $script:addAttempts -eq 0 -and @($script:medicalClinicalForms.Diaries).Count -eq 0) 'Cancelling common-form draft recovery preserves the draft and creates no diary'
 $script:nextEditorResult=$savedMany;Invoke-MedicalRestoreEditorDraft
 Assert-SharedEditor ($script:stage -ceq 'diary' -and (Get-MedicalSharedDiarySchema).Sections[1].Fields[0].Label -ceq 'Новое общее название') 'Applying a recovered shared draft restores the diary workspace and common schema'
 Assert-SharedEditor (@($script:medicalClinicalForms.Diaries).Count -eq 0 -and $script:addAttempts -eq 0 -and -not $script:medicalEditorRecoveryDraft) 'Applying shared draft recovery clears the accepted draft while preserving zero diary records'
 Assert-SharedEditor ([Windows.Forms.MessageBox]::Messages.Count -eq 0) ('Production shared-form commands complete without swallowed errors: '+([Windows.Forms.MessageBox]::Messages -join '; '))
 Write-Output ('All '+$script:checks+' shared-diary-editor checks passed.')
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
