﻿param(
 [string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v70'),
 [string]$OutputPath='',
 [int]$Events=12
)
$ErrorActionPreference='Stop'
function Import-InputBenchmarkFunctions([string]$path){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors|Out-String)}
 foreach($node in $ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @"
using System;
public class MedicalInputBenchmarkWidget {
 string text="";
 public object Tag {get;set;} public bool IsDisposed {get;set;} public object ForeColor {get;set;} public string AccessibleName {get;set;}
 public string Text {get{return text;}set{if(text==value)return;text=value;if(TextChanged!=null)TextChanged(this,EventArgs.Empty);}}
 public event EventHandler TextChanged;
}
"@
$root=Join-Path ([IO.Path]::GetTempPath()) ('medical-input-benchmark-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($root)
try{
 Import-InputBenchmarkFunctions (Join-Path $Project 'constructor.ps1')
 Import-InputBenchmarkFunctions (Join-Path $Project 'universal.ps1')
 Import-InputBenchmarkFunctions (Join-Path $Project 'forms-v59.ps1')
 . (Join-Path $Project 'clinical-stages-v67.ps1')
 . (Join-Path $Project 'clinical-ui-v67.ps1')
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main';$script:medicalProgramRoot=$root;$script:medicalTemplatesFolder=Join-Path $root 'Шаблоны'
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-01T10:30:00'}
 $script:universalConfig=New-UniversalConfig
 foreach($number in 1..12){$field=New-UniversalField ('bench_'+$number) ('Synthetic field '+$number) ('BENCH_'+$number);$script:universalConfig.Sections[0].Fields+=@($field)}
 $path=Join-Path $root 'initial.docx';New-UniversalTemplate $path $script:universalConfig
 $script:universalConfig.AutoTemplate=$false;$script:universalConfig.Template='initial.docx'
 $script:universalValues=@{patient_name='SYNTHETIC PATIENT';patient_birth='01.01.2000';patient_address='SYNTHETIC ADDRESS'};$script:universalDetails=@{}
 $script:uiSuccess='Success';$script:uiDanger='Danger';$script:darkMuted='Muted';$script:progressLabel=New-Object MedicalInputBenchmarkWidget
 $script:medicalClinicalForms=$null;$script:medicalClinicalState=$null
 [void](Initialize-MedicalClinicalWorkspace)
 $diarySchema=New-MedicalDiarySchema
 foreach($number in 1..12){$field=New-UniversalField ('diary_bench_'+$number) ('Synthetic diary field '+$number) ('DIARY_BENCH_'+$number);$diarySchema.Sections[1].Fields+=@($field)}
 $measurements=@()
 foreach($count in @(10,30)){
  while(@($script:medicalClinicalForms.Diaries).Count -lt $count){[void](Add-MedicalClinicalDiary $diarySchema)}
  $script:medicalClinicalBindings=@{};$script:stage='diary';$script:medicalClinicalBuilding=$false
  $contexts=@(Get-MedicalClinicalDiaryContexts)
  if($contexts.Count -ne $count){throw 'Benchmark diary count differs from the requested scenario.'}
  foreach($context in $contexts){
   $binding=[pscustomobject]@{Stage='diary';Id=[string]$context.Id;Context=$context;Inputs=@{};DetailInputs=@{};MultiInputs=@{};RepeatInputs=@{};Indicators=@{};CompletionLabel=(New-Object MedicalInputBenchmarkWidget);DateControl=$null}
   foreach($field in Get-UniversalFields $context.Schema){
    $editor=New-Object MedicalInputBenchmarkWidget;$editor.Text=[string]$context.Values[[string]$field.Id];$editor.Tag=[pscustomobject]@{Binding=$binding;FieldId=[string]$field.Id};$editor.Add_TextChanged({Save-MedicalClinicalInput $this.Tag})
    $binding.Inputs[[string]$field.Id]=$editor;$binding.Indicators[[string]$field.Id]=New-Object MedicalInputBenchmarkWidget
   }
   $script:medicalClinicalBindings[[string]$context.Id]=$binding
  }
  Update-MedicalClinicalCompletion
  $last=$script:medicalClinicalBindings[[string]$contexts[-1].Id];$editor=$last.Inputs.diary_complaints
  foreach($warmup in 1..3){$editor.Text='warmup '+$warmup}
  $samples=@();foreach($i in 1..$Events){$watch=[Diagnostics.Stopwatch]::StartNew();$editor.Text='Synthetic input '+$i;$watch.Stop();$samples+=@($watch.Elapsed.TotalMilliseconds)}
  $samples=@($samples|Sort-Object);$middle=[int][Math]::Floor($samples.Count/2);$median=$samples[$middle]
  if($samples.Count%2 -eq 0){$median=($samples[$middle-1]+$samples[$middle])/2}
  $refreshSamples=@();$captureSamples=@()
  foreach($repeat in 1..3){
   $watch=[Diagnostics.Stopwatch]::StartNew();$contexts=@(Get-MedicalClinicalDiaryContexts);$watch.Stop();$refreshSamples+=@($watch.Elapsed.TotalMilliseconds)
   $watch=[Diagnostics.Stopwatch]::StartNew();Capture-MedicalClinicalStage;$watch.Stop();$captureSamples+=@($watch.Elapsed.TotalMilliseconds)
  }
  $refreshMs=@($refreshSamples|Sort-Object)[1];$captureMs=@($captureSamples|Sort-Object)[1]
  if((Get-MedicalClinicalContext 'diary' $last.Id).Values.diary_complaints -cne ('Synthetic input '+$Events)){throw 'Benchmark lost the final immediate answer.'}
  $measurements+=@([pscustomobject]@{DiaryCount=$count;Events=$Events;FieldsPerDiary=@(Get-UniversalFields $contexts[0].Schema).Count;InputMedianMs=[math]::Round($median,3);InputMinMs=[math]::Round($samples[0],3);InputMaxMs=[math]::Round($samples[-1],3);ContextRefreshMs=[math]::Round($refreshMs,3);CaptureMs=[math]::Round($captureMs,3)})
 }
 $result=[pscustomobject]@{ProjectName=(Split-Path -Leaf $Project);PowerShell=$PSVersionTable.PSVersion.ToString();Platform=[Environment]::OSVersion.VersionString;RefreshAndCaptureRepeats=3;Method='Real production TextChanged callback and clinical core; synthetic widget replaces Windows painting and patient data. Same generated custom Word template, synthetic schema and diary count. Timings exclude setup and do not measure native Windows or Word latency.';Measurements=$measurements}
 $json=$result|ConvertTo-Json -Depth 8
 if($OutputPath){[IO.File]::WriteAllText($OutputPath,$json,(New-Object Text.UTF8Encoding($true)))}
 $json
}finally{if([IO.Directory]::Exists($root)){[IO.Directory]::Delete($root,$true)}}
