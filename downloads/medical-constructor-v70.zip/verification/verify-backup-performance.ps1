﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v70'),[ValidateSet('Verify','Benchmark')][string]$Mode='Verify',[int]$Iterations=5,[string]$ExportCheckpoint='',[string]$CultureName='')
$ErrorActionPreference='Stop';$script:checks=0
if($CultureName){[Globalization.CultureInfo]::CurrentCulture=[Globalization.CultureInfo]::GetCultureInfo($CultureName)}
function Assert-Check([bool]$test,[string]$label){if(-not $test){throw $label};$script:checks++;Write-Output ('PASS '+$label)}
function Assert-Reject([scriptblock]$action,[string]$label){$failed=$false;try{&$action|Out-Null}catch{$failed=$true};Assert-Check $failed $label}
function Import-TestFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors|Out-String)}
 foreach($node in $ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
  if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}
 }
}
function Capture-Stage {$script:captureCount++;$script:patientName=[string]$script:universalValues.patient_name}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-v69-backup-performance-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 Import-TestFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart','Get-HospitalizationValues','Get-FullRegistration')
 foreach($module in @('universal.ps1','forms-v59.ps1','template-recovery-v66.ps1','template-editor-v59.ps1','template-editor-operations-v61.ps1','clinical-stages-v67.ps1','backup-v67.ps1')){Import-TestFunctions (Join-Path $Project $module)}
 $script:medicalProgramRoot=$temp;$script:medicalTemplatesFolder=Join-Path $temp 'Шаблоны';$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 foreach($name in @('patientNameControl','patientBirthControl','patientAddressControl','streetControl','houseControl','apartmentControl')){Set-Variable -Scope Script -Name $name -Value ([pscustomobject]@{Text=''})}
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-01T10:20:30'};$script:hospitalControls=@{}
 $script:universalConfig=New-UniversalConfig;$script:universalValues=@{patient_name='BENCHMARK PATIENT';patient_birth='01.01.2000';patient_address='TEST ADDRESS';complaints='INITIAL COMPLAINTS'};$script:universalDetails=@{}
 $script:stage='initial';$script:diaryIndex=1;$script:stageTemplates=@{initial='';diary='';discharge=''};$script:stageData=@{};$script:activeMedicalFormPath='';$script:activeMedicalFormName='BENCHMARK FORM';$script:caseFile='';$script:caseFolder='';$script:caseLastSavedPatientName=$null
 $script:medicalWorkspaceReady=$true;$script:medicalBackupPath='';$script:medicalBackupBusy=$false;$script:medicalBackupLastError='';$script:medicalBackupFormSavedSignature='';$script:medicalBackupCaseSavedSignature='';$script:medicalBackupEditorDraft=$null;$script:medicalBackupRetainedDraft=$null;$script:medicalBackupPendingDeferred=$false;$script:captureCount=0
 [void](Initialize-MedicalClinicalWorkspace)
 for($i=0;$i -lt 10;$i++){$diary=Add-MedicalClinicalDiary;Set-MedicalClinicalValue 'diary' $diary.Id 'diary_complaints' ('DIARY ANSWERS '+$i);Set-MedicalClinicalDate $diary.Id ([datetime]'2026-10-02T09:00:00').AddDays($i)}
 Set-MedicalClinicalValue 'discharge' '' 'recommendations' 'PATIENT RECOMMENDATION SECRET'
 # Unicode field-value keys expose culture-dependent ordering in older backup hashes.
 $script:universalDetails=@{'я_тест'='UNICODE TEST';'ё_тест'='UNICODE TEST';'ä_test'='UNICODE TEST'}
 [void](Initialize-MedicalSessionBackup $temp)
 # Two warmups include actual checksummed files, .bak replacement and live patient capture.
 for($i=0;$i -lt 2;$i++){[void](Write-MedicalSessionBackup)}
 $timings=@();$previousCase=''
 for($i=0;$i -lt $Iterations;$i++){
  $script:universalValues.complaints='UPDATED ANSWER '+$i
  $clock=[Diagnostics.Stopwatch]::StartNew();$saved=Write-MedicalSessionBackup;$clock.Stop();$timings+=@([Math]::Round($clock.Elapsed.TotalMilliseconds,3))
  if($saved.Payload.Data.Record.universal.Values.complaints -cne ('UPDATED ANSWER '+$i)){throw 'Benchmark lost a new patient answer'}
  if($previousCase -and $previousCase -ceq $saved.Payload.CaseSignature){throw 'Benchmark cached stale patient signature'};$previousCase=$saved.Payload.CaseSignature
 }
 $sorted=@($timings|Sort-Object);$median=$sorted[[int][Math]::Floor($sorted.Count/2)]
 Write-Output ('BENCHMARK '+([pscustomobject]@{Project=[IO.Path]::GetFileName($Project);Diaries=10;WarmupWrites=2;Iterations=$Iterations;Milliseconds=$timings;MedianMilliseconds=$median;StateChangesVerified=$Iterations;PowerShell=$PSVersionTable.PSVersion.ToString()}|ConvertTo-Json -Compress))
 if($ExportCheckpoint){[IO.File]::Copy($saved.Path,$ExportCheckpoint,$true)}
 if($Mode -eq 'Benchmark'){return}
 Assert-Check ($script:captureCount -ge $Iterations+2) 'Every checkpoint captures the active patient even after assets are cached'
 $cultureBefore=[Globalization.CultureInfo]::CurrentCulture
 $newEnvelope=[IO.File]::ReadAllText($saved.Path)|ConvertFrom-Json
 Assert-Check ($newEnvelope.CanonicalOrder -ceq 'OrdinalV69') 'New portable backup records its ordinal checksum algorithm'
 foreach($cultureName in @('ru-RU','en-US','tr-TR','sv-SE','ja-JP')){
  [Globalization.CultureInfo]::CurrentCulture=[Globalization.CultureInfo]::GetCultureInfo($cultureName)
  $portable=Read-MedicalSessionBackup $saved.Path
  Assert-Check ($portable.Payload.CaseSignature -ceq $saved.Payload.CaseSignature) ('Checkpoint verifies unchanged under '+$cultureName+' culture')
  Assert-Check ((Get-MedicalBackupFormSignature $portable.Payload.Data) -ceq $saved.Payload.FormSignature -and (Get-MedicalBackupCaseSignature $portable.Payload.Data) -ceq $saved.Payload.CaseSignature) ('New form and patient signature order is independent of '+$cultureName+' culture')
 }
 [Globalization.CultureInfo]::CurrentCulture=$cultureBefore
 Assert-Check (-not $script:medicalBackupLegacyHashOrder) 'Reading backup always restores current hash algorithm context'
 $legacyEnvelope=[pscustomobject]@{Format='MedicalConstructorSession';Version=1;CreatedUtc=[datetime]::UtcNow.ToString('o');Closed=$false;PayloadJson='';Sha256=''}
 foreach($sourceCulture in @('ru-RU','en-US','tr-TR')){
  $legacyPayload=Copy-MedicalBackupValue $saved.Payload
  try{
   [Globalization.CultureInfo]::CurrentCulture=[Globalization.CultureInfo]::GetCultureInfo($sourceCulture);$script:medicalBackupLegacyHashOrder=$true
   $legacyPayload.FormSignature=Get-MedicalBackupFormSignature $legacyPayload.Data;$legacyPayload.CaseSignature=Get-MedicalBackupCaseSignature $legacyPayload.Data
   $legacyEnvelope.PayloadJson=$legacyPayload|ConvertTo-Json -Depth 100 -Compress;$legacyEnvelope.Sha256=Get-MedicalBackupEnvelopeHash $legacyEnvelope
  }finally{$script:medicalBackupLegacyHashOrder=$false;[Globalization.CultureInfo]::CurrentCulture=$cultureBefore}
  $legacyPath=Join-Path $temp ('legacy-'+$sourceCulture+'.mcbak');[IO.File]::WriteAllText($legacyPath,($legacyEnvelope|ConvertTo-Json -Depth 10 -Compress),[Text.UTF8Encoding]::new($false))
  [Globalization.CultureInfo]::CurrentCulture=[Globalization.CultureInfo]::GetCultureInfo('sv-SE')
  $legacyResult=Read-MedicalSessionBackup $legacyPath
  Assert-Check ($legacyResult.Payload.Data.Record.universal.Values.patient_name -ceq 'BENCHMARK PATIENT') ('Unmarked legacy '+$sourceCulture+' checksum is fully verified when read on another locale')
  Assert-Check ([Globalization.CultureInfo]::CurrentCulture.Name -ceq 'sv-SE' -and -not $script:medicalBackupLegacyHashOrder) 'Legacy fallback restores caller locale and algorithm'
 }
 [Globalization.CultureInfo]::CurrentCulture=$cultureBefore
 $unknownEnvelope=Copy-MedicalBackupValue $newEnvelope;$unknownEnvelope.CanonicalOrder='unknown';$unknownPath=Join-Path $temp 'unknown-order.mcbak';[IO.File]::WriteAllText($unknownPath,($unknownEnvelope|ConvertTo-Json -Depth 10 -Compress))
 Assert-Reject {Read-MedicalSessionBackup $unknownPath} 'Unknown checksum order is rejected before recovery'
 Assert-Check ([Globalization.CultureInfo]::CurrentCulture.Name -ceq $cultureBefore.Name -and -not $script:medicalBackupLegacyHashOrder) 'Failed validation also restores caller locale and checksum mode'
 Assert-Check ([IO.File]::Exists($saved.Path+'.bak')) 'Optimized checkpoints retain atomic previous valid backup'
 Assert-Check (@($saved.Payload.Data.ClinicalForms.Diaries).Count -eq 10) 'All ten diary layouts remain embedded'
 Assert-Check (@($saved.Payload.Data.Clinical.Diaries).Count -eq 10) 'All ten diary records remain embedded'
 $assets=Get-MedicalClinicalPortableForms;$assetText=$assets|ConvertTo-Json -Depth 100
 Assert-Check (-not $assetText.Contains('DIARY ANSWERS') -and -not $assetText.Contains('PATIENT RECOMMENDATION SECRET') -and -not $assetText.Contains('UPDATED ANSWER')) 'Reusable cached assets contain no patient answers'
 $firstAsset=Get-MedicalFormTemplateAsset $script:universalConfig;$secondAsset=Get-MedicalFormTemplateAsset $script:universalConfig
 Assert-Check ($firstAsset.TemplateBase64 -ceq $secondAsset.TemplateBase64) 'Unchanged auto schema reuses identical validated Word bytes'
 $firstAsset.TemplateBase64='tampered return object';$thirdAsset=Get-MedicalFormTemplateAsset $script:universalConfig
 Assert-Check ($thirdAsset.TemplateBase64 -ceq $secondAsset.TemplateBase64) 'Returned asset object cannot mutate the cached source'
 $changed=Copy-MedicalFormSchema $script:universalConfig;$changed.Sections[0].Title='UPDATED SECTION TITLE';$changedAsset=Get-MedicalFormTemplateAsset $changed
 Assert-Check ($changedAsset.TemplateSha256 -cne $thirdAsset.TemplateSha256) 'Changing section schema invalidates generated Word asset'
 $author=Join-Path $temp 'external.docx';[IO.File]::WriteAllBytes($author,[Convert]::FromBase64String($thirdAsset.TemplateBase64))
 $authored=Copy-MedicalFormSchema $script:universalConfig;$authored.AutoTemplate=$false;$authored.Template=$author
 $a=Get-MedicalFormTemplateAsset $authored;$originalInfo=[IO.FileInfo]$author;$originalTime=$originalInfo.LastWriteTimeUtc
 # Replacing a valid document while restoring the exact mtime must never return stale bytes.
 $replacement=[Convert]::FromBase64String($changedAsset.TemplateBase64);[IO.File]::WriteAllBytes($author,$replacement);[IO.File]::SetLastWriteTimeUtc($author,$originalTime)
 $b=Get-MedicalFormTemplateAsset $authored
 Assert-Check ($a.TemplateSha256 -cne $b.TemplateSha256 -and $b.TemplateSha256 -ceq (Get-MedicalBytesSha256 $replacement)) 'External Word edits are detected even with unchanged modification time'
 # ZIP timestamps can be changed in-place without changing file length or mtime.
 $sameSize=[byte[]]$replacement.Clone();$sameSize[10]=$sameSize[10] -bxor 1;[IO.File]::WriteAllBytes($author,$sameSize);[IO.File]::SetLastWriteTimeUtc($author,$originalTime)
 $c=Get-MedicalFormTemplateAsset $authored
 Assert-Check ($sameSize.Length -eq $replacement.Length -and $c.TemplateSha256 -cne $b.TemplateSha256) 'Same-size same-time valid byte edits invalidate authored asset cache'
 Assert-Check ((Get-MedicalBackupWordFingerprint $sameSize) -ceq (Get-MedicalBackupWordFingerprint $replacement)) 'ZIP timestamp edits retain the logical Word fingerprint'
 [IO.File]::Delete($author)
 Assert-Reject {Get-MedicalFormTemplateAsset $authored} 'Deleted Word source is not resurrected from cache'
 [IO.File]::WriteAllText($author,'not a valid Word document');[IO.File]::SetLastWriteTimeUtc($author,$originalTime)
 Assert-Reject {Get-MedicalFormTemplateAsset $authored} 'Corrupted external Word source is rejected after prior cache hit'
 # Bound memory by both size and entry count; asset evictions cannot alter future rebuilds.
 for($i=0;$i -lt 150;$i++){Set-MedicalTemplateMemo 'test' ([string]$i) ('VALUE '+$i) 1}
 Assert-Check ($script:medicalTemplateMemo.Count -le 128 -and $script:medicalTemplateMemoBytes -le 33554432) 'Memory cache has hard count and byte limits'
 $rebuilt=Get-MedicalFormTemplateAsset $script:universalConfig
 Assert-Check ((Get-MedicalBackupWordFingerprint ([Convert]::FromBase64String($rebuilt.TemplateBase64))) -ceq (Get-MedicalBackupWordFingerprint ([Convert]::FromBase64String($secondAsset.TemplateBase64)))) 'Evicted auto asset rebuild preserves exact Word content'
 Set-MedicalTemplateMemo 'oversize' 'entry' 'unused' 33554433
 Assert-Check ($null -eq (Get-MedicalTemplateMemo 'oversize' 'entry')) 'Oversized entries cannot bypass memory bound'
 $path=$saved.Path;$envelope=[IO.File]::ReadAllText($path);[IO.File]::WriteAllText($path,$envelope.Replace('UPDATED ANSWER','CORRUPT ANSWER'))
 Assert-Reject {Read-MedicalSessionBackup $path} 'On-disk checkpoint tampering is still checked after cache warmup'
 $repaired=Write-MedicalSessionBackup
 Assert-Check ($repaired.Payload.Data.Record.universal.Values.complaints -ceq ('UPDATED ANSWER '+($Iterations-1))) 'Fresh valid checkpoint replaces externally damaged file'
 $oldSignature=$repaired.Payload.FormSignature;$script:universalConfig.Sections[0].Title='FORM CHANGE AFTER WARMUP';$changedCheckpoint=Write-MedicalSessionBackup
 Assert-Check ($changedCheckpoint.Payload.FormSignature -cne $oldSignature) 'Form changes after warmup update checkpoint signatures'
 $script:stage='diary';$script:medicalActiveDiaryId=$diary.Id;$viewBackup=Write-MedicalSessionBackup
 Assert-Check ($viewBackup.Payload.Data.View.Stage -ceq 'diary' -and $viewBackup.Payload.Data.View.ActiveDiaryId -ceq $diary.Id) 'View and active diary updates are never hidden by asset cache'
 $closed=Write-MedicalSessionBackup $true
 Assert-Check ($closed.Closed) 'Closed flag is persisted even if patient and form are unchanged'
 Assert-Check ($script:medicalBackupLastCheckpoint.Closed -and $script:medicalBackupLastCheckpoint.Payload.FormSignature -ceq $closed.Payload.FormSignature) 'Footer exposes the last verified checkpoint signature after commit only'
 $closed.Payload.FormSignature='caller mutation'
 Assert-Check ($script:medicalBackupLastCheckpoint.Payload.FormSignature -cne 'caller mutation') 'Caller return object cannot alter verified footer signature'
 Assert-Check (-not $script:medicalBackupBusy -and -not $script:medicalBackupLastError) 'Checkpoint busy guard and error state finish cleanly'
 Write-Output ('CHECKS '+$script:checks)
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
