﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v70'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Card([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
Add-Type -AssemblyName System.IO.Compression.FileSystem
# The file-format and capture routines below are the actual shipped functions.
# Native dialogs and the Open-Stage view adapter are replaced; real clinical exports create every saved card.
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @'
using System;
namespace System.Windows.Forms {
 public enum DialogResult {None,OK,Cancel}
 public sealed class SaveFileDialog {
  public static string CapturedName=""; public static string OverrideName=""; public static int Calls=0; public static DialogResult Result=DialogResult.OK;
  public string Title {get;set;} public string Filter {get;set;} public string DefaultExt {get;set;} public bool AddExtension {get;set;}
  public string InitialDirectory {get;set;} public string FileName {get;set;} public bool OverwritePrompt {get;set;}
  public DialogResult ShowDialog(){Calls++;CapturedName=FileName;FileName=System.IO.Path.Combine(InitialDirectory,OverrideName.Length>0?OverrideName:FileName);return Result;}
 }
 public sealed class FolderBrowserDialog {
  public static string PickedPath=""; public static int Calls=0; public static DialogResult Result=DialogResult.OK;
  public string Description {get;set;} public string SelectedPath {get;set;}
  public DialogResult ShowDialog(){Calls++;SelectedPath=PickedPath;return Result;}
 }
 public static class MessageBox {public static string Show(params object[] args){return "OK";}}
}
'@
$tokens=$null;$parseErrors=$null
$constructor=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'constructor.ps1'),[ref]$tokens,[ref]$parseErrors)
if($parseErrors.Count){throw ($parseErrors | Out-String)}
foreach($name in @('Get-XmlPart','Sync-InitialExamValues','Get-StageKey','Capture-Stage','Get-FullRegistration','Get-HospitalizationValues','Save-Case','Read-CaseDocument','Set-SdtValue','Set-PatientDetails','Save-Document')){
 $definition=$constructor.Find({param($node)$node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $name},$false)
 if(-not $definition){throw ('Missing production function '+$name)}
 . ([scriptblock]::Create($definition.Extent.Text))
}
. (Join-Path $Project 'universal.ps1')
. (Join-Path $Project 'universal-ui.ps1')
. (Join-Path $Project 'forms-v59.ps1')
. (Join-Path $Project 'template-editor-v59.ps1')
. (Join-Path $Project 'template-recovery-v66.ps1')
. (Join-Path $Project 'forms-ui-v59.ps1')
. (Join-Path $Project 'clinical-stages-v67.ps1')
. (Join-Path $Project 'clinical-ui-v67.ps1')
. (Join-Path $Project 'workspace-settings.ps1')
. (Join-Path $Project 'document-actions.ps1')
. (Join-Path $Project 'card-document-v65.ps1')
. (Join-Path $Project 'diary-document-v67.ps1')
. (Join-Path $Project 'hospitalization-document-v68.ps1')
# Native Word merger is covered separately; this suite exercises real patient
# capture and card restoration without a native Office installation.
function Merge-MedicalDiaryWordSnapshots([string[]]$snapshots,[string]$output){[IO.File]::Copy($snapshots[0],$output,$false)}
$script:fontFile=Join-Path $Project 'document-font.json'
$formsUi=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Project 'forms-ui-v59.ps1'),[ref]$tokens,[ref]$parseErrors)
if($parseErrors.Count){throw ($parseErrors | Out-String)}
$signature=$formsUi.Find({param($node)$node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Get-MedicalFormSignature'},$false)
. ([scriptblock]::Create($signature.Extent.Text))
# This test view adapter supplies only widgets and does not restore or modify card state.
# Real Open-CasePath, Restore-UniversalState, Capture-Universal and Save-Case run unchanged.
function Open-Stage {
 $script:openedStages++
 $script:universalInputs=@{};$script:universalDetailInputs=@{}
 foreach($field in Get-UniversalFields $script:universalConfig){
  if($field.Type -eq 'heading'){continue}
  $script:universalInputs[[string]$field.Id]=[pscustomobject]@{Text=[string]$script:universalValues[[string]$field.Id]}
  if($field.Type -eq 'choice_detail'){$script:universalDetailInputs[[string]$field.Id]=[pscustomobject]@{Text=[string]$script:universalDetails[[string]$field.Id]}}
 }
}
function Set-CardFixture([string]$root,[string]$inputName='Текущий Пациент',[string]$fieldId='patient_name'){
 $script:medicalClinicalForms=$null;$script:medicalClinicalState=$null;$script:medicalClinicalBindings=@{}
 $script:medicalProgramRoot=$root;$script:medicalTemplatesFolder=Join-Path $root 'Шаблоны'
 $script:universalConfig=New-UniversalConfig
 $name=@(Get-UniversalFields $script:universalConfig | Where-Object {$_.System -eq 'name'})[0];$name.Id=$fieldId
 $script:universalValues=@{$fieldId='Старое ФИО из кэша';patient_birth='02.03.1984';patient_address='Адрес пациента';complaints='Сохранить все ответы'}
 $script:universalInputs=@{$fieldId=[pscustomobject]@{Text=$inputName};patient_birth=[pscustomobject]@{Text='02.03.1984'};patient_address=[pscustomobject]@{Text='Адрес пациента'};complaints=[pscustomobject]@{Text='Сохранить все ответы'}}
 $script:universalDetails=@{history='Сохранить уточнение'};$script:universalDetailInputs=@{history=[pscustomobject]@{Text='Сохранить уточнение'}}
 $script:universalMultiInputs=@{};$script:universalRepeatInputs=@{}
 foreach($name in @('patientNameControl','patientBirthControl','patientAddressControl','streetControl','houseControl','apartmentControl')){Set-Variable -Scope Script -Name $name -Value ([pscustomobject]@{Text='Старая скрытая копия'})}
 $script:patientName='Старое ФИО из переменной';$script:patientBirthYear='Старая дата';$script:patientAddress='Старый адрес'
 $script:stage='initial';$script:fields=@();$script:controls=@();$script:hospitalControls=@{}
 $script:source=Join-Path $root 'fixture-stage-template.docx'
 if(Test-Path -LiteralPath $script:source){Remove-Item -LiteralPath $script:source -Force}
 New-UniversalTemplate $script:source $script:universalConfig
 $script:stageData=@{diary_1=@('Текст дневника')};$script:stageTemplates=@{initial='Шаблоны/шаблон.docx';diary='Дневник.dotx';discharge='Выписка.dotx'};$script:diaryIndex=1
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-13T20:15:00'}
 $script:caseFolder=$root;$script:caseFile='';$script:caseLastSavedPatientName=$null;$script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
 [System.Windows.Forms.SaveFileDialog]::Calls=0;[System.Windows.Forms.SaveFileDialog]::CapturedName='';[System.Windows.Forms.SaveFileDialog]::OverrideName='';[System.Windows.Forms.SaveFileDialog]::Result='OK'
 [System.Windows.Forms.FolderBrowserDialog]::Calls=0;[System.Windows.Forms.FolderBrowserDialog]::PickedPath=$root;[System.Windows.Forms.FolderBrowserDialog]::Result='OK'
}
function Get-CardBody([string]$path){
 $zip=[IO.Compression.ZipFile]::OpenRead($path)
 try{$xml=Get-XmlPart $zip 'word/document.xml';$n=[Xml.XmlNamespaceManager]::new($xml.NameTable);$n.AddNamespace('w',$script:ns);return (($xml.SelectNodes('//w:p[not(w:r/w:rPr/w:vanish)]//w:t',$n) | ForEach-Object {$_.InnerText}) -join "`n")}finally{$zip.Dispose()}
}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-card-current-patient-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 Set-CardFixture $temp 'Новый Пациент Иванович'
 Save-Case
 $firstPath=$script:caseFile;$record=Read-CaseDocument $firstPath;$body=Get-CardBody $firstPath
 Assert-Card ((Test-Path -LiteralPath $firstPath) -and [IO.Path]::GetFileName($firstPath) -ceq 'Новый Пациент Иванович_13.10.2026.docx') 'First Save Card filename uses the current visible patient name'
 Assert-Card ($record.patientName -ceq 'Новый Пациент Иванович') 'Hospitalization record uses the current visible patient name'
 Assert-Card ($record.universal.Values.patient_name -ceq 'Новый Пациент Иванович') 'Embedded form state uses the same current patient name'
 Assert-Card ($body.Contains('Ф.И.О.: Новый Пациент Иванович') -and -not $body.Contains('Старое ФИО') -and -not $body.Contains('Старая скрытая копия')) 'Visible Word card contains current name without old copies'
 Assert-Card ($script:patientName -ceq $record.patientName -and $script:patientNameControl.Text -ceq $record.patientName) 'Case identity and hidden mirror are synchronized'
 Assert-Card ($record.universal.Values.complaints -ceq 'Сохранить все ответы' -and $record.universal.Details.history -ceq 'Сохранить уточнение') 'Capturing current name preserves other answers and clarifications'
 Assert-Card ($record.universal.AdmissionDateTime.ToString('yyyy-MM-ddTHH:mm:ss') -ceq '2026-10-13T20:15:00' -and $record.admissionDate -ceq '2026-10-13') 'Card preserves the admission date and time'
 Assert-Card ($record.stages.diary_1[0] -ceq 'Текст дневника' -and $record.templates.diary -ceq 'Дневник.dotx') 'Card preserves other stages and template references'
 Assert-Card ($record.birthYear -ceq '02.03.1984' -and $record.registration -ceq 'Адрес пациента') 'Card preserves current birth date and registration'
 Save-Case
 $firstBytes=[IO.File]::ReadAllBytes($firstPath)
 Assert-Card ($script:caseFile -ceq $firstPath -and [System.Windows.Forms.SaveFileDialog]::Calls -eq 1) 'Unchanged patient name saves to the chosen card without another dialog'
 $script:universalInputs.patient_name.Text='Пациент после правки';Save-Case
 $renamedPath=$script:caseFile;$updated=Read-CaseDocument $renamedPath
 Assert-Card ([IO.Path]::GetFileName($renamedPath) -ceq 'Пациент после правки_13.10.2026.docx' -and [System.Windows.Forms.SaveFileDialog]::Calls -eq 2) 'Changed patient name opens Save Card with the current suggested filename'
 Assert-Card ($updated.patientName -ceq 'Пациент после правки' -and $updated.universal.Values.patient_name -ceq 'Пациент после правки') 'Saving after a name change refreshes both record and embedded form patient name'
 Assert-Card ((Get-CardBody $renamedPath).Contains('Ф.И.О.: Пациент после правки') -and -not (Get-CardBody $renamedPath).Contains('Ф.И.О.: Новый Пациент Иванович')) 'Saving after a name change refreshes the visible Word patient name'
 Assert-Card ([Convert]::ToBase64String([IO.File]::ReadAllBytes($firstPath)) -ceq [Convert]::ToBase64String($firstBytes)) 'Saving to the newly suggested filename preserves the original card'
 $script:universalInputs.patient_name.Text='';Save-Case;$cleared=Read-CaseDocument $script:caseFile
 Assert-Card ([string]$cleared.patientName -ceq '' -and [string]$cleared.universal.Values.patient_name -ceq '' -and $script:patientName -ceq '') 'Clearing the visible name clears saved and mirrored names without restoring the old patient'
 Set-CardFixture $temp 'Имя по новой роли' 'custom_patient_name'
 Save-Case;$custom=Read-CaseDocument $script:caseFile
 Assert-Card ($custom.patientName -ceq 'Имя по новой роли' -and $custom.universal.Values.custom_patient_name -ceq 'Имя по новой роли') 'Patient identity uses the configured name role with a custom field ID'
 Assert-Card ([IO.Path]::GetFileName($script:caseFile) -ceq 'Имя по новой роли_13.10.2026.docx') 'Filename follows the configured name role with a custom field ID'
 Set-CardFixture $temp 'Название похожее на ФИО'
 $script:universalConfig.Sections[0].Fields[0].System='';Save-Case;$noRole=Read-CaseDocument $script:caseFile
 Assert-Card ([string]$noRole.patientName -ceq '' -and $noRole.universal.Values.patient_name -ceq 'Название похожее на ФИО') 'A field without a patient name role keeps its answer without guessing identity'
 Assert-Card ([IO.Path]::GetFileName($script:caseFile) -ceq 'Пациент_13.10.2026.docx') 'An unassigned patient name uses the generic filename'
 Set-CardFixture $temp '';Save-Case;$empty=Read-CaseDocument $script:caseFile
 Assert-Card ([string]$empty.patientName -ceq '' -and [IO.Path]::GetFileName($script:caseFile) -ceq 'Пациент_13.10.2026.docx') 'An empty current name uses the generic filename and does not reuse the previous name'
 Set-CardFixture $temp '  Иванов / Пётр: «Имя»?  ';Save-Case;$unsafe=Read-CaseDocument $script:caseFile
 Assert-Card ($unsafe.patientName -ceq '  Иванов / Пётр: «Имя»?  ' -and [IO.Path]::GetFileName($script:caseFile) -ceq 'Иванов _ Пётр_ «Имя»__13.10.2026.docx') 'Windows filename sanitation preserves the exact patient answer in the card'
 Set-CardFixture $temp 'Иванов & Петров <Проверка>';Save-Case;$escaped=Read-CaseDocument $script:caseFile
 Assert-Card ($escaped.patientName -ceq 'Иванов & Петров <Проверка>' -and (Get-CardBody $script:caseFile).Contains('Ф.И.О.: Иванов & Петров <Проверка>')) 'Special XML characters remain readable in patient identity and Word text'
 Set-CardFixture $temp 'Пациент с уточнением';$nameField=$script:universalConfig.Sections[0].Fields[0];$nameField.Type='choice_detail';$nameField.Options=@('Пациент с уточнением');$script:universalDetailInputs.patient_name=[pscustomobject]@{Text='уточнение имени'}
 Save-Case;$detailed=Read-CaseDocument $script:caseFile
 Assert-Card ($detailed.patientName -ceq 'Пациент с уточнением: уточнение имени' -and $detailed.universal.Values.patient_name -ceq 'Пациент с уточнением' -and $detailed.universal.Details.patient_name -ceq 'уточнение имени') 'Configured choice-with-detail identity uses current display value while raw answers remain separate'
 Set-CardFixture $temp 'Выбранное пользователем имя';[System.Windows.Forms.SaveFileDialog]::OverrideName='Моё имя файла.docx';Save-Case
 Assert-Card ([IO.Path]::GetFileName($script:caseFile) -ceq 'Моё имя файла.docx' -and (Read-CaseDocument $script:caseFile).patientName -ceq 'Выбранное пользователем имя') 'User-selected filename is respected while the saved patient identity stays current'
 $customPath=$script:caseFile;Save-Case
 Assert-Card ($script:caseFile -ceq $customPath -and [System.Windows.Forms.SaveFileDialog]::Calls -eq 1) 'Unchanged patient name respects the custom card filename without another dialog'
 $savedBytes=[IO.File]::ReadAllBytes($customPath);$savedName=$script:caseLastSavedPatientName
 $script:universalInputs.patient_name.Text='Новое ФИО до отмены';[System.Windows.Forms.SaveFileDialog]::Result='Cancel';Save-Case
 Assert-Card ($script:caseFile -ceq $customPath -and $script:caseLastSavedPatientName -ceq $savedName) 'Canceling a changed-name save preserves the chosen path and last successful patient name'
 Assert-Card ([Convert]::ToBase64String([IO.File]::ReadAllBytes($customPath)) -ceq [Convert]::ToBase64String($savedBytes)) 'Canceling a changed-name save preserves the previous card bytes'
 Assert-Card ([System.Windows.Forms.SaveFileDialog]::CapturedName -ceq 'Новое ФИО до отмены_13.10.2026.docx' -and $script:universalValues.patient_name -ceq 'Новое ФИО до отмены') 'Canceling a changed-name save retains the current visible answer and current filename suggestion'
 [System.Windows.Forms.SaveFileDialog]::Result='OK';[System.Windows.Forms.SaveFileDialog]::OverrideName=Join-Path $temp 'missing-directory/fail.docx';$failed=$false
 try{Save-Case}catch{$failed=$true}
 Assert-Card ($failed -and $script:caseFile -ceq $customPath -and $script:caseLastSavedPatientName -ceq $savedName) 'A failed changed-name write preserves the previously chosen path and last successful patient name'
 Assert-Card ([Convert]::ToBase64String([IO.File]::ReadAllBytes($customPath)) -ceq [Convert]::ToBase64String($savedBytes)) 'A failed changed-name write preserves the previous card bytes'
 [System.Windows.Forms.SaveFileDialog]::OverrideName=[IO.Path]::GetFileName($customPath);Save-Case
 Assert-Card ($script:caseFile -ceq $customPath -and $script:caseLastSavedPatientName -ceq 'Новое ФИО до отмены' -and (Read-CaseDocument $customPath).patientName -ceq 'Новое ФИО до отмены') 'The user can explicitly keep the original filename after changing the patient name'
 Set-CardFixture $temp 'Пациент из папки';$script:caseFolder='';Save-Case
 Assert-Card ([System.Windows.Forms.FolderBrowserDialog]::Calls -eq 1 -and (Read-CaseDocument $script:caseFile).patientName -ceq 'Пациент из папки') 'Selecting a hospitalization folder keeps the captured current name'
 Set-CardFixture $temp 'Не сохранять';[System.Windows.Forms.SaveFileDialog]::Result='Cancel';$before=@(Get-ChildItem -LiteralPath $temp).Count;Save-Case
 Assert-Card ($script:caseFile -ceq '' -and @(Get-ChildItem -LiteralPath $temp).Count -eq $before) 'Canceling Save Card creates no new file'
 Set-CardFixture $temp 'Не сохранять папку';$script:caseFolder='';[System.Windows.Forms.FolderBrowserDialog]::Result='Cancel';Save-Case
 Assert-Card ($script:caseFolder -ceq '' -and $script:caseFile -ceq '' -and [System.Windows.Forms.SaveFileDialog]::Calls -eq 0) 'Canceling folder selection does not open Save Card'
 # Opening an existing custom-named card uses its saved patient identity as the baseline.
 Set-CardFixture $temp 'Пациент существующей карты';[System.Windows.Forms.SaveFileDialog]::OverrideName='Открытая карта — своё имя.docx';Save-Case
 $openedPath=$script:caseFile;[System.Windows.Forms.SaveFileDialog]::Calls=0;[System.Windows.Forms.SaveFileDialog]::OverrideName=''
 $stageInitial=[pscustomobject]@{Enabled=$false};$stageDiary=[pscustomobject]@{Enabled=$false};$stageDischarge=[pscustomobject]@{Enabled=$false};$script:openedStages=0
 $script:caseLastSavedPatientName='Иное имя из предыдущей карты';$script:universalValues.patient_name='Иное имя из предыдущего состояния';$script:patientNameControl.Text='Иное имя скрытого ввода'
 Open-CasePath $openedPath
 Assert-Card ($script:caseLastSavedPatientName -ceq 'Пациент существующей карты') 'Actual Open Card initializes the saved-name baseline from the opened record'
 Assert-Card ($script:caseFile -ceq $openedPath -and $script:caseFolder -ceq $temp) 'Actual Open Card restores the exact custom path and hospitalization folder'
 Assert-Card ($script:universalValues.patient_name -ceq 'Пациент существующей карты' -and $script:patientNameControl.Text -ceq 'Пациент существующей карты' -and $script:universalInputs.patient_name.Text -ceq 'Пациент существующей карты') 'Actual Open Card restores patient state and the capture widgets from the saved card'
 Assert-Card ($script:openedStages -eq 1 -and $stageInitial.Enabled -and $stageDiary.Enabled -and $stageDischarge.Enabled) 'Actual Open Card restores the initial stage and enables the case stage controls'
 Assert-Card ($script:stageData.diary_1[0] -ceq 'Текст дневника' -and $script:universalDetails.history -ceq 'Сохранить уточнение') 'Actual Open Card preserves saved stages and initial clarifications'
 Save-Case
 Assert-Card ([System.Windows.Forms.SaveFileDialog]::Calls -eq 0 -and $script:caseFile -ceq $openedPath) 'Saving an opened unchanged card does not show another dialog or change its custom filename'
 Assert-Card ((Read-CaseDocument $openedPath).patientName -ceq 'Пациент существующей карты') 'Saving an opened unchanged card keeps the restored patient identity'
 $openedBytes=[IO.File]::ReadAllBytes($openedPath);$script:universalInputs.patient_name.Text='Пациент после открытия и правки';Save-Case
 Assert-Card ([System.Windows.Forms.SaveFileDialog]::Calls -eq 1 -and [System.Windows.Forms.SaveFileDialog]::CapturedName -ceq 'Пациент после открытия и правки_13.10.2026.docx') 'Changing patient name after actual Open Card shows the current filename suggestion'
 Assert-Card ([IO.Path]::GetFileName($script:caseFile) -ceq 'Пациент после открытия и правки_13.10.2026.docx' -and (Read-CaseDocument $script:caseFile).patientName -ceq 'Пациент после открытия и правки') 'Saving a changed opened card writes the current name to the newly selected file'
 Assert-Card ([Convert]::ToBase64String([IO.File]::ReadAllBytes($openedPath)) -ceq [Convert]::ToBase64String($openedBytes)) 'Saving a changed opened card preserves its previous custom-named file'
 Set-CardFixture $temp '';[System.Windows.Forms.SaveFileDialog]::OverrideName='Карта без ФИО.docx';Save-Case;$emptyPath=$script:caseFile
 [System.Windows.Forms.SaveFileDialog]::Calls=0;[System.Windows.Forms.SaveFileDialog]::OverrideName='';$script:caseLastSavedPatientName=$null;Open-CasePath $emptyPath;Save-Case
 Assert-Card ([System.Windows.Forms.SaveFileDialog]::Calls -eq 0 -and $script:caseFile -ceq $emptyPath -and $script:caseLastSavedPatientName -ceq '') 'Actual Open Card treats an empty saved patient name as a known baseline and keeps its custom filename'
 # Editing the existing initial admission control must update visible Word and
 # the exact restorable timestamp, including when the filename stays unchanged.
 Set-CardFixture $temp 'Пациент с исправленным временем';Save-Case;$admissionPath=$script:caseFile
 $script:admissionControl.Value=[datetime]'2026-10-12T07:43:19';Save-Case;$admissionRecord=Read-CaseDocument $admissionPath
 Assert-Card (([datetime]$admissionRecord.universal.AdmissionDateTime) -eq [datetime]'2026-10-12T07:43:19' -and $admissionRecord.admissionDate -ceq '2026-10-12') 'Saving after editing admission date and time stores the corrected full timestamp and corrected date'
 Assert-Card ((Get-CardBody $admissionPath).Contains('12.10.2026 07:43') -and -not (Get-CardBody $admissionPath).Contains('13.10.2026 20:15')) 'Saving after editing admission date and time renders corrected time in the visible initial examination'
 Assert-Card ($script:caseFile -ceq $admissionPath -and [System.Windows.Forms.SaveFileDialog]::Calls -eq 1) 'Correcting admission time preserves the chosen card path when patient identity is unchanged'
 $script:admissionControl.Value=[datetime]'2030-01-01T00:00:00';Open-CasePath $admissionPath
 Assert-Card ($script:admissionControl.Value -eq [datetime]'2026-10-12T07:43:19') 'Actual Open Card restores the manually corrected admission date and time'
 # Native diary/discharge patient widgets remain authoritative for their own edits.
 foreach($stageToTest in @('diary','discharge')){
  Set-CardFixture $temp 'Первичный осмотр';Capture-Universal;$script:stage=$stageToTest
  # A real active stage binds its actual source to the stage template map.
  $script:stageTemplates[$stageToTest]=$script:source
  $script:patientNameControl.Text=('Пациент после правки в '+$stageToTest);$script:patientBirthControl.Text='04.05.1990';$script:patientAddressControl.Text='Ирбит';$script:streetControl.Text='Ленина';$script:houseControl.Text='7';$script:apartmentControl.Text='9'
  $script:fields=@([pscustomobject]@{HospitalKey='';IsAddress=$false;ClinicalKey='';Label='Текст этапа'});$script:controls=@([pscustomobject]@{Text='Изменённый текст этапа'})
  Save-Case;$other=Read-CaseDocument $script:caseFile;$expected='Пациент после правки в '+$stageToTest
  Assert-Card ($other.patientName -ceq $expected -and $other.universal.Values.patient_name -ceq $expected) ('Saving from '+$stageToTest+' preserves current patient widget edits in record and form')
  Assert-Card ($script:patientName -ceq $expected) ('Saving from '+$stageToTest+' refreshes the case patient identity variable')
  Assert-Card ([IO.Path]::GetFileName($script:caseFile) -ceq ($expected+'_13.10.2026.docx')) ('Saving from '+$stageToTest+' suggests the current patient name')
  Assert-Card ($other.birthYear -ceq '04.05.1990' -and $other.registration -ceq 'Ирбит, ул. Ленина, д. 7, кв. 9') ('Saving from '+$stageToTest+' preserves birth and address components')
  $key=if($stageToTest -eq 'diary'){'diary_1'}else{'discharge'}
  Assert-Card ($other.stages.$key[0] -ceq 'Изменённый текст этапа' -and $other.universal.Details.history -ceq 'Сохранить уточнение') ('Saving from '+$stageToTest+' preserves current stage text and initial clarifications')
 }
 Assert-Card (@(Get-ChildItem -LiteralPath $temp -Filter '*.tmp').Count -eq 0) 'All atomic Save Card temporary files are cleaned up'
 Write-Output ('PASS '+$script:checks+' current-patient card checks')
}finally{Remove-Item -LiteralPath $temp -Recurse -Force}
