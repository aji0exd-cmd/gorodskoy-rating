﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v70'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Diary([bool]$test,[string]$message){if(-not $test){throw $message};$script:checks++;Write-Output ('PASS '+$message)}
function Assert-DiaryRejected([scriptblock]$operation,[string]$message,[string]$contains=''){$errorText='';try{& $operation|Out-Null}catch{$errorText=$_.Exception.Message};Assert-Diary (-not [string]::IsNullOrEmpty($errorText) -and (-not $contains -or $errorText.Contains($contains))) $message}
function Import-TestFunctions([string]$path,[string[]]$names=@()){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors);if($errors.Count){throw ($errors|Out-String)}
 foreach($node in $ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){if(-not $names.Count -or $node.Name -in $names){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}}
}
function Apply-DocumentFont($path){}
function ConvertTo-DiaryCanonical($value){
 if($null -eq $value){return 'null'}
 if($value -is [Collections.IDictionary]){$parts=@();foreach($key in @($value.Keys|Sort-Object)){$parts+=@((ConvertTo-Json ([string]$key) -Compress)+':'+(ConvertTo-DiaryCanonical $value[$key]))};return ('{'+($parts -join ',')+'}')}
 if($value -is [pscustomobject]){$parts=@();foreach($property in @($value.PSObject.Properties|Sort-Object Name)){$parts+=@((ConvertTo-Json $property.Name -Compress)+':'+(ConvertTo-DiaryCanonical $property.Value))};return ('{'+($parts -join ',')+'}')}
 if($value -is [Collections.IList]){$parts=@();foreach($entry in $value){$parts+=@(ConvertTo-DiaryCanonical $entry)};return ('['+($parts -join ',')+']')}
 return (ConvertTo-Json $value -Compress)
}
function Read-DiaryPart([string]$path,[string]$part){$z=[IO.Compression.ZipFile]::OpenRead($path);try{return ,(Get-MedicalDiaryXml $z $part)}finally{$z.Dispose()}}
function Get-DiaryText([string]$path){$x=Read-DiaryPart $path 'word/document.xml';return (($x.GetElementsByTagName('t',$script:ns)|ForEach-Object {$_.InnerText})-join "`n")}
function Set-DiaryPart([string]$path,[string]$part,[string]$xml){$z=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Update);try{Set-MedicalDiaryXml $z $part ([xml]$xml)}finally{$z.Dispose()}}
function Get-DiaryPackageParts([string]$path){$z=[IO.Compression.ZipFile]::OpenRead($path);try{return @($z.Entries.FullName)}finally{$z.Dispose()}}
function New-TestRange([string]$text){return [pscustomobject]@{Text=$text;FormattedText=('FORMATTED '+$text)}}
function New-TestHeaderCollection([int]$seed){
 $items=@();for($index=1;$index -le 3;$index++){
  $item=[pscustomobject]@{Exists=($index -ne 2);LinkToPrevious=$true;RangeValue=(New-TestRange ('HEADER '+$seed+' '+$index));PageNumbers=([pscustomobject]@{Count=1;RestartNumberingAtSection=$true;StartingNumber=$seed;NumberStyle=$index})}
  $item|Add-Member ScriptProperty Range {if(-not $this.Exists){throw 'Word range is unavailable for an absent header/footer'};return $this.RangeValue}
  $items+=@($item)
 }
 $collection=[pscustomobject]@{Items=$items};$collection|Add-Member ScriptMethod Item {param($index) return $this.Items[$index-1]};return $collection
}
function New-TestSection([int]$seed){
 $columns=[pscustomobject]@{Count=2;EvenlySpaced=$false;LineBetween=$true;Items=@([pscustomobject]@{Width=(200+$seed);SpaceAfter=14},[pscustomobject]@{Width=(100+$seed);SpaceAfter=0})}
 $columns|Add-Member ScriptMethod Item {param($index) return $this.Items[$index-1]}
 $columns|Add-Member ScriptMethod SetCount {param($count) $this.Count=$count;while($this.Items.Count -lt $count){$this.Items+=@([pscustomobject]@{Width=0;SpaceAfter=0})}}
 $setup=[pscustomobject]@{Orientation=($seed%2);PageWidth=(590+$seed);PageHeight=(840+$seed);TopMargin=(50+$seed);BottomMargin=55;LeftMargin=60;RightMargin=45;Gutter=3;GutterPos=0;HeaderDistance=20;FooterDistance=25;DifferentFirstPageHeaderFooter=$true;OddAndEvenPagesHeaderFooter=$true;MirrorMargins=$true;VerticalAlignment=1;SectionStart=2;SuppressEndnotes=$false;TextColumns=$columns}
 return [pscustomobject]@{PageSetup=$setup;Headers=(New-TestHeaderCollection $seed);Footers=(New-TestHeaderCollection ($seed+100))}
}
function New-DiaryComMock {
 $script:mock=[pscustomobject]@{Opened=(New-Object Collections.ArrayList);Insertions=(New-Object Collections.ArrayList);Closed=(New-Object Collections.ArrayList);Breaks=0;Repaginated=0;Quit=0;FailOpen='';FailInsert=0;FailSave=$false;BadSections=$false;MissingWord=$false;Destination=$null;Sources=@{};Application=$null;InputSnapshots=@()}
 $documents=New-Object PSObject
 $documents|Add-Member ScriptMethod Open {
  param($path,$confirm,$readonly,$recent)
  [void]$script:mock.Opened.Add([pscustomobject]@{Path=$path;Confirm=$confirm;ReadOnly=$readonly;Recent=$recent})
  if($path -eq $script:mock.FailOpen){throw 'Simulated Word open error'}
  $seed=10*$script:mock.Opened.Count;$sections=[pscustomobject]@{Count=1;Items=@((New-TestSection $seed))}
  if($script:mock.Opened.Count -eq 3){$sections.Items+=@((New-TestSection ($seed+1)));$sections.Count=2}
  $sections|Add-Member ScriptMethod Item {param($index) return $this.Items[$index-1]}
  $document=[pscustomobject]@{Path=$path;Sections=$sections;Content=([pscustomobject]@{End=100});UpdateStylesOnOpen=$true;Imported=@()}
  $document|Add-Member ScriptMethod Range {
   param($start,$end)
   if($start -ne ($this.Content.End-1) -or $end -ne $start){throw 'Insertions must append before final document paragraph'}
   $range=[pscustomobject]@{Owner=$this}
   $range|Add-Member ScriptMethod InsertBreak {
    param($kind) if($kind -ne 2){throw 'Expected next-page section break'};$script:mock.Breaks++
    $this.Owner.Sections.Items+=@((New-TestSection 0));$this.Owner.Sections.Count++;$this.Owner.Content.End++
   }
   $range|Add-Member ScriptMethod InsertFile {
    param($path,$range,$confirm,$link,$attachment)
    if($range -ne [Type]::Missing -or $confirm -or $link -or $attachment){throw 'InsertFile must embed a whole document without links or prompts'}
    [void]$script:mock.Insertions.Add($path)
    if($script:mock.FailInsert -eq $script:mock.Insertions.Count){throw 'Simulated Word insertion error'}
    $from=$script:mock.Sources[$path]
    if(-not $script:mock.BadSections){for($index=1;$index -lt $from.Sections.Count;$index++){$this.Owner.Sections.Items+=@((New-TestSection 0));$this.Owner.Sections.Count++}}
    $this.Owner.Imported+=@($path);$this.Owner.Content.End+=100
   }
   return $range
  }
  $document|Add-Member ScriptMethod Repaginate {$script:mock.Repaginated++}
  $document|Add-Member ScriptMethod SaveAs2 {
   param($output,$format)
   if($format -ne 12){throw 'Expected DOCX format'}
   if($script:mock.FailSave){throw 'Simulated Word save error'}
   # This mock stores the first real rendered DOCX and appends actual rendered
   # paragraphs. Native Word owns styles/media/relationships in production;
   # this mock only verifies control flow and rendered input ordering.
   [IO.File]::Copy($this.Path,$output,$false)
   $archive=[IO.Compression.ZipFile]::Open($output,[IO.Compression.ZipArchiveMode]::Update)
   try{
    $xml=Get-MedicalDiaryXml $archive 'word/document.xml';$n=[Xml.XmlNamespaceManager]::new($xml.NameTable);$n.AddNamespace('w',$script:ns);$body=$xml.SelectSingleNode('/w:document/w:body',$n);$end=$body.SelectSingleNode('w:sectPr',$n)
    foreach($path in $this.Imported){$source=Read-DiaryPart $path 'word/document.xml';$sn=[Xml.XmlNamespaceManager]::new($source.NameTable);$sn.AddNamespace('w',$script:ns);foreach($node in @($source.SelectNodes('/w:document/w:body/*[not(self::w:sectPr)]',$sn))){$copy=$xml.ImportNode($node,$true);if($end){[void]$body.InsertBefore($copy,$end)}else{[void]$body.AppendChild($copy)}}}
    Set-MedicalDiaryXml $archive 'word/document.xml' $xml
   }finally{$archive.Dispose()}
  }
  $document|Add-Member ScriptMethod Close {param($save) if($save -ne 0){throw 'Source snapshots must never be saved'};[void]$script:mock.Closed.Add($this.Path)}
  if($script:mock.Opened.Count -eq 1){$script:mock.Destination=$document}else{$script:mock.Sources[$path]=$document}
  return $document
 }
 $app=[pscustomobject]@{Visible=$true;DisplayAlerts=1;AutomationSecurity=1;Documents=$documents}
 $app|Add-Member ScriptMethod Quit {param($save) if($save -ne 0){throw 'Word must quit without saving sources'};$script:mock.Quit++}
 $script:mock.Application=$app
}
function New-MedicalDiaryWordApplication {if($script:mock.MissingWord){throw 'Microsoft Word unavailable'};return $script:mock.Application}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('medical-diaries-tests-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 Add-Type -AssemblyName System.IO.Compression;Add-Type -AssemblyName System.IO.Compression.FileSystem
 Import-TestFunctions (Join-Path $Project 'constructor.ps1') @('Get-XmlPart')
 Import-TestFunctions (Join-Path $Project 'universal.ps1')
 Import-TestFunctions (Join-Path $Project 'forms-v59.ps1')
 Import-TestFunctions (Join-Path $Project 'clinical-stages-v67.ps1')
 # Capture the real native application constructor before replacing only COM.
 Import-TestFunctions (Join-Path $Project 'diary-document-v67.ps1')
 $nativeApplication=(Get-Command New-MedicalDiaryWordApplication).ScriptBlock
 function New-MedicalDiaryWordApplication {if($script:mock.MissingWord){throw 'Microsoft Word unavailable'};return $script:mock.Application}
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main';$script:medicalProgramRoot=$temp;$script:medicalTemplatesFolder=Join-Path $temp 'Шаблоны'
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-14T10:15:00'}
 $script:universalConfig=New-UniversalConfig;$script:universalValues=@{patient_name='ТЕСТОВЫЙ ПАЦИЕНТ';patient_birth='01.01.2000';patient_address='ТЕСТ АДРЕС'};$script:universalDetails=@{}
 [void](Initialize-MedicalClinicalWorkspace)
 $first=Add-MedicalClinicalDiary;$second=Add-MedicalClinicalDiary;$third=Add-MedicalClinicalDiary
 Set-MedicalClinicalValue 'diary' $first.Id 'diary_complaints' 'ПЕРВАЯ ЗАПИСЬ'
 Set-MedicalClinicalValue 'diary' $second.Id 'diary_complaints' 'ВТОРАЯ ЗАПИСЬ'
 Set-MedicalClinicalValue 'diary' $third.Id 'diary_complaints' 'ТРЕТЬЯ ЗАПИСЬ'
 Set-MedicalClinicalDate $first.Id ([datetime]'2026-10-14T11:00:00');Set-MedicalClinicalDate $second.Id ([datetime]'2026-10-15T12:00:00');Set-MedicalClinicalDate $third.Id ([datetime]'2026-10-16T13:00:00')
 $contexts=@(Get-MedicalClinicalDiaryContexts)
 $originalState=(Get-MedicalClinicalState|ConvertTo-Json -Depth 60 -Compress)
 $template=Join-Path $temp 'authored.docx';New-UniversalTemplate $template $contexts[0].Schema
 $snapshot=Join-Path $temp 'format.docx';Save-UniversalDocument $snapshot $contexts[0].Schema $contexts[0].Values $contexts[0].DateTime $contexts[0].Details $true
 $archive=[IO.Compression.ZipFile]::Open($snapshot,[IO.Compression.ZipArchiveMode]::Update)
 try{
  $styles=Get-MedicalDiaryXml $archive 'word/styles.xml';$n=[Xml.XmlNamespaceManager]::new($styles.NameTable);$n.AddNamespace('w',$script:ns)
  $fonts=$styles.SelectSingleNode('/w:styles/w:docDefaults/w:rPrDefault/w:rPr/w:rFonts',$n);$fonts.RemoveAllAttributes();$fonts.SetAttribute('asciiTheme',$script:ns,'majorHAnsi');$fonts.SetAttribute('hAnsiTheme',$script:ns,'minorHAnsi');$fonts.SetAttribute('eastAsiaTheme',$script:ns,'majorEastAsia');$fonts.SetAttribute('csTheme',$script:ns,'majorBidi')
  $fragment=$styles.CreateDocumentFragment();$fragment.InnerXml='<w:style xmlns:w="'+$script:ns+'" w:type="character" w:styleId="DefaultParagraphFont" w:default="1"><w:name w:val="Default Paragraph Font"/><w:rPr><w:i/></w:rPr></w:style><w:style xmlns:w="'+$script:ns+'" w:type="table" w:styleId="TableNormal" w:default="1"><w:name w:val="Normal table"/></w:style><w:style xmlns:w="'+$script:ns+'" w:type="character" w:styleId="Highlight"><w:name w:val="Highlight"/><w:aliases w:val="Marked,Special"/><w:link w:val="Heading1"/><w:rPr><w:color w:themeColor="accent1"/><w:b/></w:rPr></w:style><w:style xmlns:w="'+$script:ns+'" w:type="table" w:styleId="MedicalTable"><w:name w:val="Medical table"/><w:pPr><w:shd w:themeFill="accent1" w:themeFillTint="99"/></w:pPr></w:style><w:style xmlns:w="'+$script:ns+'" w:type="numbering" w:styleId="List"><w:name w:val="List"/></w:style>';[void]$styles.DocumentElement.AppendChild($fragment);Set-MedicalDiaryXml $archive 'word/styles.xml' $styles
  Set-MedicalDiaryXml $archive 'word/theme/theme1.xml' ([xml]('<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:themeElements><a:clrScheme name="Test"><a:accent1><a:srgbClr val="204060"/></a:accent1><a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1></a:clrScheme><a:fontScheme name="Test"><a:majorFont><a:latin typeface="Cambria"/><a:ea typeface="SimSun"/><a:cs typeface="Arial"/></a:majorFont><a:minorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme><a:fmtScheme name="Test"/></a:themeElements></a:theme>'))
  Set-MedicalDiaryXml $archive 'word/numbering.xml' ([xml]('<w:numbering xmlns:w="'+$script:ns+'"><w:abstractNum w:abstractNumId="1"><w:nsid w:val="12345678"/><w:multiLevelType w:val="singleLevel"/><w:tmpl w:val="87654321"/><w:styleLink w:val="List"/><w:numStyleLink w:val="List"/><w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="bullet"/><w:lvlText w:val="•"/><w:pStyle w:val="Heading1"/><w:rPr><w:rFonts w:ascii="Wingdings"/></w:rPr></w:lvl></w:abstractNum><w:num w:numId="1"><w:abstractNumId w:val="1"/></w:num></w:numbering>'))
  $doc=Get-MedicalDiaryXml $archive 'word/document.xml';$fragment=$doc.CreateDocumentFragment();$fragment.InnerXml='<w:tbl xmlns:w="'+$script:ns+'"><w:tblPr><w:tblStyle w:val="MedicalTable"/></w:tblPr><w:tblGrid><w:gridCol w:w="5000"/></w:tblGrid><w:tr><w:tc><w:tcPr><w:tcW w:w="5000" w:type="dxa"/></w:tcPr><w:p><w:r><w:rPr><w:rStyle w:val="Highlight"/></w:rPr><w:t>СОХРАНИТЬ ТАБЛИЦУ</w:t></w:r></w:p></w:tc></w:tr></w:tbl><w:tbl xmlns:w="'+$script:ns+'"><w:tblGrid><w:gridCol w:w="4000"/></w:tblGrid><w:tr><w:tc><w:p><w:r><w:t>ТАБЛИЦА ПО УМОЛЧАНИЮ</w:t></w:r></w:p></w:tc></w:tr></w:tbl>';$body=$doc.GetElementsByTagName('body',$script:ns)[0];[void]$body.InsertBefore($fragment,$body.LastChild);Set-MedicalDiaryXml $archive 'word/document.xml' $doc
  Set-MedicalDiaryXml $archive 'word/header1.xml' ([xml]('<w:hdr xmlns:w="'+$script:ns+'"><w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr><w:r><w:t>КОЛОНТИТУЛ</w:t></w:r></w:p></w:hdr>'))
  Set-MedicalDiaryXml $archive 'word/footer1.xml' ([xml]('<w:ftr xmlns:w="'+$script:ns+'"><w:p><w:r><w:rPr><w:rStyle w:val="Highlight"/></w:rPr><w:t>ПОДВАЛ</w:t></w:r></w:p></w:ftr>'))
  Set-MedicalDiaryXml $archive 'word/diagrams/colors1.xml' ([xml]('<a:clr xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:schemeClr val="accent1"><a:alpha val="50000"/></a:schemeClr><a:latin typeface="+mj-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="ExplicitFace"/></a:clr>'))
  $entry=$archive.CreateEntry('word/media/keep.png');$stream=$entry.Open();try{$stream.Write(([byte[]]@(1,2,3,4)),0,4)}finally{$stream.Dispose()}
 }finally{$archive.Dispose()}
 $stylePrefix='MC67_'+[guid]::NewGuid().ToString('N')+'_';$beforeText=Get-DiaryText $snapshot;$partsBefore=@(Get-DiaryPackageParts $snapshot)
 Protect-MedicalDiarySnapshotFormatting $snapshot $stylePrefix
 $styles=Read-DiaryPart $snapshot 'word/styles.xml';$n=[Xml.XmlNamespaceManager]::new($styles.NameTable);$n.AddNamespace('w',$script:ns)
 foreach($id in @('Normal','Title','Heading1','Highlight','MedicalTable','List','DefaultParagraphFont','TableNormal')){Assert-Diary ($null -ne $styles.SelectSingleNode('/w:styles/w:style[@w:styleId="'+$stylePrefix+$id+'"]',$n)) ('Source style namespace retained for '+$id)}
 Assert-Diary ($styles.SelectSingleNode('/w:styles/w:style[@w:styleId="'+$stylePrefix+'Normal"]/w:basedOn',$n).GetAttribute('val',$script:ns) -eq ($stylePrefix+'Base')) 'Source default formatting is materialized in an inherited base style'
 Assert-Diary ($styles.SelectSingleNode('/w:styles/w:style[@w:styleId="'+$stylePrefix+'Title"]/w:basedOn',$n).GetAttribute('val',$script:ns) -eq ($stylePrefix+'Normal')) 'Paragraph inheritance points to its own source styles'
 Assert-Diary ($styles.SelectSingleNode('/w:styles/w:style[@w:styleId="'+$stylePrefix+'Highlight"]/w:aliases',$n).GetAttribute('val',$script:ns) -ceq ($stylePrefix+'Marked,'+$stylePrefix+'Special')) 'Style aliases are isolated from destination style names'
 Assert-Diary ($styles.SelectSingleNode('/w:styles/w:style[@w:styleId="'+$stylePrefix+'Highlight"]/w:link',$n).GetAttribute('val',$script:ns) -eq ($stylePrefix+'Heading1')) 'Linked character styles use their own paragraph style'
 $fonts=$styles.SelectSingleNode('/w:styles/w:docDefaults/w:rPrDefault/w:rPr/w:rFonts',$n)
 foreach($pair in @(@('ascii','Cambria'),@('hAnsi','Calibri'),@('eastAsia','SimSun'),@('cs','Arial'))){Assert-Diary ($fonts.GetAttribute($pair[0],$script:ns) -ceq $pair[1]) ('Source theme font materialized for '+$pair[0])}
 Assert-Diary (-not $fonts.HasAttribute('asciiTheme',$script:ns)) 'Resolved font no longer depends on destination theme'
 Assert-Diary ($null -ne $styles.SelectSingleNode('//w:color[@w:val="204060"]',$n)) 'Theme text color becomes a concrete RGB color'
 Assert-Diary ($null -ne $styles.SelectSingleNode('//w:shd[@w:fill="798CA0"]',$n)) 'Theme tint keeps its concrete shaded fill'
 Assert-Diary ((Get-DiaryText $snapshot) -ceq $beforeText) 'Formatting protection preserves every filled paragraph and table cell'
 $doc=Read-DiaryPart $snapshot 'word/document.xml';$n=[Xml.XmlNamespaceManager]::new($doc.NameTable);$n.AddNamespace('w',$script:ns)
 Assert-Diary (@($doc.SelectNodes('//w:p[not(w:pPr/w:pStyle)]',$n)).Count -eq 0) 'Implicit paragraph styles become explicit in tables and document body'
 Assert-Diary ($doc.SelectSingleNode('//w:tblStyle',$n).GetAttribute('val',$script:ns) -eq ($stylePrefix+'MedicalTable')) 'Table style links use the source style namespace'
 Assert-Diary ($doc.SelectSingleNode('//w:tblStyle[@w:val="'+$stylePrefix+'TableNormal"]',$n) -ne $null) 'Implicit table style belongs to its own source template'
 Assert-Diary ($doc.SelectSingleNode('//w:tbl//w:rStyle[@w:val="'+$stylePrefix+'Highlight"]',$n).GetAttribute('val',$script:ns) -eq ($stylePrefix+'Highlight')) 'Run style links use the source style namespace'
 Assert-Diary (@($doc.SelectNodes('//w:r[not(w:rPr/w:rStyle)]',$n)).Count -eq 0) 'Implicit character styles are materialized in every source run'
 Assert-Diary ($doc.SelectSingleNode('//w:rStyle[@w:val="'+$stylePrefix+'DefaultParagraphFont"]',$n) -ne $null) 'Unstyled source text uses its own default character style'
 Assert-Diary ($doc.SelectSingleNode('/w:document/w:body/w:sectPr/w:pgSz',$n).GetAttribute('w',$script:ns) -eq '11906') 'OOXML preparation preserves authored page width'
 $numbering=Read-DiaryPart $snapshot 'word/numbering.xml';$n=[Xml.XmlNamespaceManager]::new($numbering.NameTable);$n.AddNamespace('w',$script:ns)
 foreach($link in @('styleLink','numStyleLink')){Assert-Diary ($numbering.SelectSingleNode('//w:'+$link,$n).GetAttribute('val',$script:ns) -eq ($stylePrefix+'List')) ('Numbering '+$link+' is remapped')}
 Assert-Diary ($numbering.SelectSingleNode('//w:pStyle',$n).GetAttribute('val',$script:ns) -eq ($stylePrefix+'Heading1')) 'Numbering paragraph style is remapped'
 foreach($identity in @('nsid','tmpl')){Assert-Diary ($numbering.SelectSingleNode('//w:'+$identity,$n).GetAttribute('val',$script:ns) -match '^[0-9A-F]{8}$' -and $numbering.SelectSingleNode('//w:'+$identity,$n).GetAttribute('val',$script:ns) -notin @('12345678','87654321')) ('Independent numbering identity for '+$identity)}
 $rfonts=$numbering.SelectSingleNode('//w:lvl/w:rPr/w:rFonts',$n)
 Assert-Diary ($rfonts.GetAttribute('ascii',$script:ns) -eq 'Wingdings') 'Explicit bullet glyph font survives default materialization'
 Assert-Diary ($rfonts.GetAttribute('hAnsi',$script:ns) -eq 'Calibri') 'Numbering glyph inherits its source theme font'
 Assert-Diary ($numbering.SelectSingleNode('//w:lvl/w:rPr/w:sz',$n).GetAttribute('val',$script:ns) -eq '24') 'Numbering glyph inherits its source default size'
 foreach($part in @('word/header1.xml','word/footer1.xml')){$xml=Read-DiaryPart $snapshot $part;Assert-Diary ($xml.OuterXml.Contains($stylePrefix)) ('Source style remapping includes '+$part)}
 $drawing=Read-DiaryPart $snapshot 'word/diagrams/colors1.xml';Assert-Diary ($drawing.OuterXml.Contains('typeface="Cambria"') -and $drawing.OuterXml.Contains('typeface="Calibri"') -and $drawing.OuterXml.Contains('typeface="ExplicitFace"')) 'Drawing text theme fonts resolve while explicit typefaces remain unchanged'
 Assert-Diary ($drawing.OuterXml.Contains('srgbClr') -and $drawing.OuterXml.Contains('204060') -and $drawing.OuterXml.Contains('50000')) 'Drawing colors resolve while preserving alpha transforms'
 $archive=[IO.Compression.ZipFile]::OpenRead($snapshot);try{$stream=$archive.GetEntry('word/media/keep.png').Open();$memory=New-Object IO.MemoryStream;try{$stream.CopyTo($memory);Assert-Diary ([Convert]::ToBase64String($memory.ToArray()) -eq 'AQIDBA==') 'Media bytes are unchanged by XML/style preparation'}finally{$stream.Dispose();$memory.Dispose()}}finally{$archive.Dispose()}
 Assert-Diary ((@(Get-DiaryPackageParts $snapshot)|Sort-Object)-join '|' -ceq (($partsBefore|Sort-Object)-join '|')) 'Formatting preparation does not drop package parts'
 Assert-DiaryRejected {Protect-MedicalDiarySnapshotFormatting $snapshot 'bad'} 'Invalid source-style prefix is rejected before changing ZIP'
 Remove-MedicalDiarySnapshotState $snapshot
 Assert-Diary (-not ((Get-DiaryPackageParts $snapshot) -contains 'customXml/mc49.xml')) 'Individual patient machine state is stripped before native insertion'
 Assert-Diary (-not (Read-DiaryPart $snapshot 'word/_rels/document.xml.rels').OuterXml.Contains('mc49.xml')) 'Removed patient state has no dangling relationship'
 Assert-Diary (-not (Read-DiaryPart $snapshot '[Content_Types].xml').OuterXml.Contains('/customXml/mc49.xml')) 'Removed patient state has no dangling content-type override'
 # Native section copy covers differing page sizes, columns, headers, and page
 # number restarts. COM objects are mocked; source OOXML above is real.
 $sourceSection=New-TestSection 7;$targetSection=New-TestSection 0;Copy-MedicalDiaryWordSection $sourceSection $targetSection
 foreach($name in @('Orientation','PageWidth','PageHeight','TopMargin','BottomMargin','LeftMargin','RightMargin','Gutter','GutterPos','HeaderDistance','FooterDistance','DifferentFirstPageHeaderFooter','OddAndEvenPagesHeaderFooter','MirrorMargins','VerticalAlignment','SectionStart','SuppressEndnotes')){Assert-Diary ($targetSection.PageSetup.$name -eq $sourceSection.PageSetup.$name) ('Native section copy preserves '+$name)}
 Assert-Diary ($targetSection.PageSetup.TextColumns.Count -eq 2 -and $targetSection.PageSetup.TextColumns.Items[0].Width -eq 207 -and $targetSection.PageSetup.TextColumns.Items[1].SpaceAfter -eq 0) 'Native section copy preserves columns and spacing'
 foreach($kind in @('Headers','Footers')){for($index=0;$index -lt 3;$index++){$from=$sourceSection.$kind.Items[$index];$to=$targetSection.$kind.Items[$index];Assert-Diary (-not $to.LinkToPrevious) ($kind+' are independent for variant '+$index);if($from.Exists){Assert-Diary ($to.Range.FormattedText -ceq $from.Range.FormattedText) ($kind+' copy rich content for variant '+$index);Assert-Diary ($to.PageNumbers.StartingNumber -eq $from.PageNumbers.StartingNumber -and $to.PageNumbers.NumberStyle -eq $from.PageNumbers.NumberStyle -and $to.PageNumbers.RestartNumberingAtSection) ($kind+' copy page numbering for variant '+$index)}else{Assert-Diary (-not $to.Exists) ($kind+' clear absent source variant '+$index)}}}
 $output=Join-Path $temp 'All diaries.docx';New-DiaryComMock;Export-MedicalDiariesDocument $output $true
 Assert-Diary ([IO.File]::Exists($output)) 'Combined diary export produces one DOCX via real individual exporters and mocked native Word'
 Assert-Diary ($script:mock.Opened.Count -eq 3 -and $script:mock.Insertions.Count -eq 2 -and $script:mock.Breaks -eq 2) 'Every diary is appended once in order using native section breaks'
 Assert-Diary ($script:mock.Destination.Sections.Count -eq 4) 'Multiple source sections are retained by the merge contract'
 for($index=0;$index -lt 3;$index++){$entry=$script:mock.Opened[$index];Assert-Diary ($entry.Confirm -eq $false -and $entry.Recent -eq $false -and $entry.ReadOnly -eq ($index -ne 0)) ('Private Word snapshot uses correct open flags for diary '+$index);Assert-Diary (-not [IO.File]::Exists($entry.Path)) ('Temporary rendered diary '+$index+' is cleaned after success')}
 Assert-Diary ($script:mock.Application.Visible -eq $false -and $script:mock.Application.DisplayAlerts -eq 0 -and $script:mock.Application.AutomationSecurity -eq 3) 'Owned Word instance is hidden with macro automation disabled'
 Assert-Diary ($script:mock.Closed.Count -eq 3 -and $script:mock.Quit -eq 1 -and $script:mock.Repaginated -eq 1) 'All owned documents close and Word quits after complete pagination'
 $text=Get-DiaryText $output;Assert-Diary ($text.IndexOf('ПЕРВАЯ ЗАПИСЬ') -lt $text.IndexOf('ВТОРАЯ ЗАПИСЬ') -and $text.IndexOf('ВТОРАЯ ЗАПИСЬ') -lt $text.IndexOf('ТРЕТЬЯ ЗАПИСЬ')) 'Real rendered diary contents arrive in patient diary order'
 foreach($date in @('14.10.2026 11:00','15.10.2026 12:00','16.10.2026 13:00')){Assert-Diary ($text.Contains($date)) ('Rendered individual diary timestamp included: '+$date)}
 $state=Read-UniversalDocumentState $output
 Assert-Diary ($state.Version -eq 67 -and $state.Stage -eq 'diaries' -and @($state.Diaries).Count -eq 3 -and $null -eq $state.Schema) 'Collection state replaces incompatible first-diary single-form metadata'
 for($index=0;$index -lt 3;$index++){Assert-Diary ($state.Diaries[$index].Id -ceq $contexts[$index].Id -and $state.Diaries[$index].Values.diary_complaints -ceq $contexts[$index].Values.diary_complaints) ('Combined machine state retains stable ID and answers for diary '+$index)}
 Assert-DiaryRejected {Test-MedicalTemplateBytes ([IO.File]::ReadAllBytes($output))} 'Filled combined patient diaries cannot be imported as a reusable template'
 New-DiaryComMock;Export-MedicalDiariesDocument $output $true
 Assert-Diary ((Read-UniversalDocumentState $output).Diaries.Count -eq 3) 'Repeated save atomically replaces an existing combined DOCX without an empty-string backup path'
 $before=(Get-FileHash $output).Hash
 foreach($failure in @('MissingWord','FailInsert','FailSave','BadSections')){
  New-DiaryComMock;switch($failure){'MissingWord'{$script:mock.MissingWord=$true};'FailInsert'{$script:mock.FailInsert=1};'FailSave'{$script:mock.FailSave=$true};'BadSections'{$script:mock.BadSections=$true}}
  Assert-DiaryRejected {Export-MedicalDiariesDocument $output $true} ('Native failure '+$failure+' rejects partial document')
  Assert-Diary ((Get-FileHash $output).Hash -ceq $before) ('Native failure '+$failure+' preserves previous saved document')
  Assert-Diary (@(Get-ChildItem -LiteralPath $temp -Filter 'mc-diary-*.docx').Count -eq 0) ('Native failure '+$failure+' leaves no target-side temporary file')
  foreach($entry in $script:mock.Opened){Assert-Diary (-not [IO.File]::Exists($entry.Path)) ('Native failure '+$failure+' cleans rendered source snapshot')}
  Assert-Diary ($script:mock.Quit -eq [int](-not $script:mock.MissingWord)) ('Native failure '+$failure+' quits only its newly owned Word instance')
 }
 Assert-Diary ((Get-MedicalClinicalState|ConvertTo-Json -Depth 60 -Compress) -ceq $originalState) 'Repeated exports and native failures preserve all diary patient answers and link state'
 $blocked=Join-Path $temp 'blocked.docx';[void][IO.Directory]::CreateDirectory($blocked);$sentinel=Join-Path $blocked 'keep.txt';[IO.File]::WriteAllText($sentinel,'Keep existing target contents')
 New-DiaryComMock;Assert-DiaryRejected {Export-MedicalDiariesDocument $blocked $true} 'Failed final placement rejects an unusable destination after successful Word rendering'
 Assert-Diary ([IO.File]::ReadAllText($sentinel) -ceq 'Keep existing target contents') 'Failed final placement preserves all existing destination contents'
 Assert-Diary (@(Get-ChildItem -LiteralPath $temp -Filter 'mc-diary-*.docx').Count -eq 0 -and $script:mock.Quit -eq 1) 'Failed final placement cleans target temporary file and owned Word instance'
 $schema=Copy-MedicalFormSchema $contexts[0].Schema;$schema.AutoTemplate=$false;$schema.Template=$template;[void](Set-MedicalClinicalSchema 'diary' $first.Id $schema)
 $templateHash=(Get-FileHash $template).Hash
 New-DiaryComMock;Assert-DiaryRejected {Export-MedicalDiariesDocument $template $true} 'Combined export refuses an original diary Word template as its target'
 Assert-Diary ((Get-FileHash $template).Hash -ceq $templateHash -and $script:mock.Opened.Count -eq 0) 'Original template is preserved and Word never starts for a forbidden output path'
 Assert-DiaryRejected {Export-MedicalDiariesDocument (Join-Path $temp 'bad.dotx') $true} 'Combined patient export rejects template file extension'
 $formsBefore=Get-MedicalClinicalFormData;$stateBefore=Get-MedicalClinicalState
 $script:medicalClinicalForms.Diaries=@($script:medicalClinicalForms.Diaries[0]);$script:medicalClinicalState.Diaries=@($script:medicalClinicalState.Diaries[0]);New-DiaryComMock
 $one=Join-Path $temp 'one.docx';Export-MedicalDiariesDocument $one $true
 Assert-Diary ([IO.File]::Exists($one) -and $script:mock.Opened.Count -eq 0 -and $script:mock.Quit -eq 0) 'One diary is exported through the real template pipeline without unnecessary native Word startup'
 Assert-Diary ((Get-DiaryText $one).Contains('ПЕРВАЯ ЗАПИСЬ') -and (Read-UniversalDocumentState $one).Diaries.Count -eq 1) 'Single diary export still uses collection metadata and real rendered answers'
 $script:medicalClinicalForms.Diaries=@();$script:medicalClinicalState.Diaries=@()
 Assert-DiaryRejected {Export-MedicalDiariesDocument $output $true} 'Empty diary list reports a useful error instead of a blank document' 'Добавьте хотя бы один дневник'
 [void](Initialize-MedicalClinicalWorkspace $formsBefore);Restore-MedicalClinicalState $stateBefore
 Assert-Diary ((ConvertTo-DiaryCanonical (Get-MedicalClinicalState)) -ceq (ConvertTo-DiaryCanonical $stateBefore)) 'Single diary export and empty-list failures preserve current patient diary state'
 Assert-Diary ((Get-FileHash $template).Hash -ceq $templateHash) 'Original template is unchanged after real single-diary export'
 if([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT){Assert-DiaryRejected {& $nativeApplication} 'Native constructor explains Windows Word requirement on this host' 'Microsoft Word в Windows'}
 Write-Output ('Completed '+$script:checks+' diary-document checks. Individual DOCX/OOXML exports and atomic writes are real; native Word COM insertion, pagination and section copying were mocked and remain untested in Windows.')
}finally{if([IO.Directory]::Exists($temp)){[IO.Directory]::Delete($temp,$true)}}
