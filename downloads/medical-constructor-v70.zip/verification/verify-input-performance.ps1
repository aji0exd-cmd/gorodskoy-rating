﻿param([string]$Project=(Join-Path (Split-Path -Parent $PSScriptRoot) 'Медицинский конструктор v70'))
$ErrorActionPreference='Stop';$script:checks=0
function Assert-Input([bool]$ok,[string]$label){if(-not $ok){throw $label};$script:checks++;Write-Output ('PASS '+$label)}
function Assert-InputReject([scriptblock]$operation,[string]$label){$rejected=$false;try{& $operation|Out-Null}catch{$rejected=$true};Assert-Input $rejected $label}
function Import-InputFunctions([string]$path){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors|Out-String)}
 foreach($node in $ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){. ([scriptblock]::Create(($node.Extent.Text -replace '^function\s+','function script:')))}
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -CompilerOptions /langversion:5 -TypeDefinition @"
using System;
public class MedicalInputTestWidget {
 string text="";
 public object Tag {get;set;} public bool IsDisposed {get;set;} public object ForeColor {get;set;} public string AccessibleName {get;set;} public int ColorChanges {get;set;} public bool Checked {get;set;}
 public string Text {get{return text;}set{if(text==value)return;text=value;if(TextChanged!=null)TextChanged(this,EventArgs.Empty);}}
 public event EventHandler TextChanged;
}
"@
$root=Join-Path ([IO.Path]::GetTempPath()) ('medical-input-tests-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($root)
try{
 Import-InputFunctions (Join-Path $Project 'constructor.ps1')
 Import-InputFunctions (Join-Path $Project 'universal.ps1')
 Import-InputFunctions (Join-Path $Project 'forms-v59.ps1')
 . (Join-Path $Project 'clinical-stages-v67.ps1')
 . (Join-Path $Project 'clinical-ui-v67.ps1')
 $script:ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main';$script:medicalProgramRoot=$root;$script:medicalTemplatesFolder=Join-Path $root 'Шаблоны'
 $script:admissionControl=[pscustomobject]@{Value=[datetime]'2026-10-01T12:30:00'}
 $script:universalConfig=New-UniversalConfig;$script:universalValues=@{patient_name='INITIAL';patient_birth='01.01.2000';patient_address='ADDRESS'};$script:universalDetails=@{}
 $initialChoice=New-UniversalField 'source_choice' 'Source choice' 'SOURCE_CHOICE' 'choice_detail';$initialChoice.Options=@('One','Two');$script:universalConfig.Sections[0].Fields+=@($initialChoice)
 $script:universalValues.source_choice='One';$script:universalDetails.source_choice='SOURCE DETAIL'
 $script:medicalClinicalForms=$null;$script:medicalClinicalState=$null;[void](Initialize-MedicalClinicalWorkspace)
 $schema=New-MedicalDiarySchema
 foreach($definition in @(@('text_field','text'),@('multiline_field','multiline'),@('choice_field','choice'),@('detail_field','choice_detail'),@('multi_field','multi'),@('repeat_field','repeat'),@('heading_field','heading'))){
  $field=New-UniversalField $definition[0] $definition[0] ($definition[0].ToUpperInvariant()) $definition[1]
  if($field.Type -in @('choice','choice_detail','multi','repeat')){$field.Options=@('One','Two')}
  $field.Required=($field.Type -ne 'heading');$schema.Sections[1].Fields+=@($field)
 }
 $converted=New-UniversalField 'source_choice' 'Converted source choice' 'CONVERTED_SOURCE_CHOICE';$converted.Required=$false;$schema.Sections[1].Fields+=@($converted)
 foreach($i in 1..30){[void](Add-MedicalClinicalDiary $schema)}
 $script:medicalClinicalBindings=@{};$script:medicalClinicalBuilding=$false;$script:stage='diary';$script:uiSuccess='Success';$script:uiDanger='Danger';$script:darkMuted='Muted';$script:progressLabel=New-Object MedicalInputTestWidget
 foreach($context in Get-MedicalClinicalDiaryContexts){
  $binding=[pscustomobject]@{Stage='diary';Id=$context.Id;Context=$context;Inputs=@{};DetailInputs=@{};MultiInputs=@{};RepeatInputs=@{};Indicators=@{};CompletionLabel=(New-Object MedicalInputTestWidget);DateControl=$null}
  foreach($field in Get-UniversalFields $context.Schema){
   $editor=New-Object MedicalInputTestWidget;$editor.Text=[string]$context.Values[[string]$field.Id];$editor.Tag=[pscustomobject]@{Binding=$binding;FieldId=[string]$field.Id};$editor.Add_TextChanged({Save-MedicalClinicalInput $this.Tag});$binding.Inputs[[string]$field.Id]=$editor;$binding.Indicators[[string]$field.Id]=New-Object MedicalInputTestWidget
  }
  $detail=New-Object MedicalInputTestWidget;$detail.Tag=$binding.Inputs.detail_field.Tag;$detail.Add_TextChanged({Save-MedicalClinicalInput $this.Tag});$binding.DetailInputs.detail_field=$detail
  $script:medicalClinicalBindings[[string]$context.Id]=$binding
 }
 Update-MedicalClinicalCompletion
 $ids=@($script:medicalClinicalForms.Diaries|ForEach-Object {$_.Id});$first=$script:medicalClinicalBindings[$ids[0]];$last=$script:medicalClinicalBindings[$ids[-1]]
 $script:signatureCalls=0;$script:copyCalls=0;$script:contextCalls=0
 $script:originalSignature=${function:Get-MedicalClinicalInitialSignature};$script:originalCopy=${function:Copy-MedicalFormSchema};$script:originalContext=${function:Get-MedicalClinicalContext}
 function Get-MedicalClinicalInitialSignature {param($initial,[bool]$force=$false);$script:signatureCalls++;& $script:originalSignature $initial $force}
 function Copy-MedicalFormSchema {param($schema);$script:copyCalls++;& $script:originalCopy $schema}
 function Get-MedicalClinicalContext {param([string]$stage,[string]$id='');$script:contextCalls++;& $script:originalContext $stage $id}
 foreach($i in 1..100){$last.Inputs.text_field.Text='key '+$i}
 Assert-Input ($script:signatureCalls -eq 0) 'One hundred real input events never fingerprint primary Word files or discharge schemas'
 Assert-Input ($script:copyCalls -eq 0) 'One hundred real input events do not copy or validate complete schemas'
 Assert-Input ($script:contextCalls -eq 0) 'Incremental completion does not resynchronize any other diary context per key'
 $raw=Get-MedicalClinicalBinding 'diary' $last.Id
 Assert-Input ($raw.State.Values.text_field -ceq 'key 100') 'The final answer is committed immediately without a timer or debounce'
 Assert-Input (-not (Get-MedicalClinicalBinding 'diary' $first.Id).State.Values.ContainsKey('text_field')) 'Typing in the last of thirty diaries leaves the first diary unchanged'
 Assert-Input ($last.Indicators.text_field.ForeColor -eq 'Success') 'Changed required field indicator immediately becomes complete'
 Assert-Input ($first.Indicators.text_field.ForeColor -eq 'Danger') 'Other diary required indicators retain their correct state'
 $before=$last.MissingCount;$last.Inputs.text_field.Text=''
 Assert-Input ($last.MissingCount -eq $before+1) 'Clearing a field increments its missing count exactly once'
 $last.Inputs.text_field.Text='filled again';$before=$last.MissingCount;$last.Inputs.text_field.Text='different filled answer'
 Assert-Input ($last.MissingCount -eq $before) 'Changing a filled answer does not drift completion totals'
 $last.Inputs.multiline_field.Text="line 1`r`nline 2"
 $last.Inputs.choice_field.Text='Two';$last.Inputs.detail_field.Text='One';$last.DetailInputs.detail_field.Text='DETAIL'
 Assert-Input ($raw.State.Values.multiline_field -ceq "line 1`r`nline 2") 'Multiline input retains exact line breaks'
 Assert-Input ($raw.State.Values.choice_field -ceq 'Two') 'Choice input saves immediately'
 Assert-Input ($raw.State.Details.detail_field -ceq 'DETAIL') 'Clarification input saves separately and immediately'
 Save-MedicalClinicalInput $last.Inputs.detail_field.Tag $true
 Assert-Input ($raw.State.Details.detail_field -ceq '') 'Changing choice can clear its clarification without stale data'
 $a=New-Object MedicalInputTestWidget;$a.Text='One';$a.Checked=$true;$b=New-Object MedicalInputTestWidget;$b.Text='Two';$b.Checked=$true
 $last.MultiInputs.multi_field=@($a,$b);Save-MedicalClinicalInput $last.Inputs.multi_field.Tag
 Assert-Input ($raw.State.Values.multi_field -ceq "One`r`nTwo") 'Multiple checked options persist in order'
 $rowA=[pscustomobject]@{Editor=(New-Object MedicalInputTestWidget)};$rowA.Editor.Text='REPEAT A';$rowB=[pscustomobject]@{Editor=(New-Object MedicalInputTestWidget)};$rowB.Editor.Text='REPEAT B'
 $last.RepeatInputs.repeat_field=[pscustomobject]@{Rows=@($rowA,$rowB)};Save-MedicalClinicalInput $last.Inputs.repeat_field.Tag
 Assert-Input ($raw.State.Values.repeat_field -ceq "REPEAT A`r`nREPEAT B") 'Repeatable row input preserves every row and order'
 $last.Inputs.patient_name.Text='MANUAL DIARY NAME';$last.Inputs.patient_birth.Text='02.02.2001';$last.Inputs.patient_address.Text='MANUAL ADDRESS'
 $script:universalValues.patient_name='UPDATED INITIAL';$script:universalValues.patient_birth='03.03.2002';$script:universalValues.patient_address='UPDATED ADDRESS'
 $context=Get-MedicalClinicalContext 'diary' $last.Id
 foreach($role in @('patient_name','patient_birth','patient_address')){Assert-Input ($context.Overrides[$role] -eq $true) ('Manual '+$role+' edit retains its override')}
 Assert-Input ($context.Values.patient_name -ceq 'MANUAL DIARY NAME') 'Manual demographic changes survive source refresh'
 Assert-Input ((Get-MedicalClinicalContext 'diary' $first.Id).Values.patient_name -ceq 'UPDATED INITIAL') 'Untouched linked demographics still follow the initial exam'
 Assert-Input ($context.Values.source_choice -ceq 'One: SOURCE DETAIL') 'Source choice clarification converts correctly for a text target'
 $last.Inputs.source_choice.Text='MANUAL CONVERTED';$script:universalDetails.source_choice='CHANGED SOURCE DETAIL'
 Assert-Input ((Get-MedicalClinicalContext 'diary' $last.Id).Values.source_choice -ceq 'MANUAL CONVERTED') 'Converted linked fields retain deliberate manual overrides'
 Reset-MedicalClinicalLink 'diary' $last.Id 'source_choice'
 Assert-Input ((Get-MedicalClinicalContext 'diary' $last.Id).Values.source_choice -ceq 'One: CHANGED SOURCE DETAIL') 'Explicit relink refreshes converted source formatting'
 $definition=$raw.Definition;$fields=$definition.Schema.Sections[1].Fields;$original=Get-MedicalClinicalField $definition.Schema 'text_field'
 $replacement=New-UniversalField 'text_field' 'Replacement field' 'TEXT_FIELD';$replacement.Required=$false
 $slot=[array]::IndexOf($fields,$original);$fields[$slot]=$replacement
 Assert-Input ([object]::ReferenceEquals((Get-MedicalClinicalField $definition.Schema 'text_field'),$replacement)) 'Cached field lookup detects in-place replacement at the same index'
 [array]::Reverse($definition.Schema.Sections[1].Fields)
 Assert-Input ([object]::ReferenceEquals((Get-MedicalClinicalField $definition.Schema 'text_field'),$replacement)) 'Cached field lookup remains correct after field reordering'
 $definition.Schema.Sections=@($definition.Schema.Sections[1],$definition.Schema.Sections[0])+$definition.Schema.Sections[2..($definition.Schema.Sections.Count-1)]
 Assert-Input ([object]::ReferenceEquals((Get-MedicalClinicalField $definition.Schema 'text_field'),$replacement)) 'Cached field lookup remains correct after section reordering'
 $replacement.Id='renamed_text';$replacement.Marker='RENAMED_TEXT'
 Assert-Input ($null -eq (Get-MedicalClinicalField $definition.Schema 'text_field')) 'Removed field identifiers never resolve from a stale cache'
 Assert-Input ([object]::ReferenceEquals((Get-MedicalClinicalField $definition.Schema 'renamed_text'),$replacement)) 'Renamed field identifiers resolve immediately'
 $candidate=Copy-MedicalFormSchema $definition.Schema
 $fresh=New-UniversalField 'fresh_field' 'Fresh field' 'FRESH_FIELD';$candidate.Sections[0].Fields+=@($fresh)
 [void](Set-MedicalClinicalSchema 'diary' $last.Id $candidate)
 Set-MedicalClinicalValue 'diary' $last.Id 'fresh_field' 'FRESH ANSWER'
 Assert-Input ((Get-MedicalClinicalContext 'diary' $last.Id).Values.fresh_field -ceq 'FRESH ANSWER') 'Replacing a schema through the public editor API invalidates field lookups'
 Assert-Input ((Get-MedicalClinicalContext 'diary' $last.Id).Values.detail_field -ceq 'One') 'Schema replacement retains existing field answers'
 $saved=Get-MedicalClinicalState;$savedForms=Get-MedicalClinicalFormData
 Restore-MedicalClinicalFormData $savedForms;Restore-MedicalClinicalState $saved
 Assert-Input ((Get-MedicalClinicalContext 'diary' $last.Id).Values.fresh_field -ceq 'FRESH ANSWER') 'Restoring forms and state cannot retain an old binding target'
 Set-MedicalClinicalValue 'diary' $last.Id 'fresh_field' 'RESTORED ANSWER'
 Assert-Input ((Get-MedicalClinicalContext 'diary' $last.Id).Values.fresh_field -ceq 'RESTORED ANSWER') 'Input after restore writes into the new patient state'
 $signatureA=Get-MedicalClinicalInitialSignature $script:universalConfig
 $script:universalConfig.Sections[0].Title='Changed initial title'
 $signatureB=Get-MedicalClinicalInitialSignature $script:universalConfig
 Assert-Input ($signatureA -cne $signatureB) 'Signature cache notices in-place primary schema edits'
 $path=Join-Path $root 'initial.docx';New-UniversalTemplate $path $script:universalConfig
 $script:universalConfig.AutoTemplate=$false;$script:universalConfig.Template='initial.docx'
 $signatureA=Get-MedicalClinicalInitialSignature $script:universalConfig
 $stamp=[IO.File]::GetLastWriteTimeUtc($path);$bytes=[IO.File]::ReadAllBytes($path);$bytes[15]=$bytes[15] -bxor 1;[IO.File]::WriteAllBytes($path,$bytes);[IO.File]::SetLastWriteTimeUtc($path,$stamp)
 $signatureB=Get-MedicalClinicalInitialSignature $script:universalConfig $true
 Assert-Input ($signatureA -cne $signatureB) 'Forced snapshot fingerprint notices changed Word bytes even with identical size and modification time'
 Assert-InputReject {Set-MedicalClinicalValue 'diary' $last.Id 'not_a_field' 'invalid'} 'Unknown fields are still rejected before changing patient state'
 [array]::Reverse($script:medicalClinicalForms.Diaries)
 Assert-Input ((Get-MedicalClinicalBinding 'diary' $last.Id).State.Values.fresh_field -ceq 'RESTORED ANSWER') 'Binding index notices in-place definition order changes'
 [array]::Reverse($script:medicalClinicalState.Diaries)
 Assert-Input ((Get-MedicalClinicalBinding 'diary' $last.Id).State.Values.fresh_field -ceq 'RESTORED ANSWER') 'Definition and state may be reordered independently without crossed answers'
 $previousBinding=Get-MedicalClinicalBinding 'diary' $last.Id
 $replacementState=Copy-UniversalObject $previousBinding.State;$replacementState.Values=ConvertTo-MedicalClinicalMap $replacementState.Values;$replacementState.Values.fresh_field='REPLACED STATE'
 $position=[array]::IndexOf($script:medicalClinicalState.Diaries,$previousBinding.State);$script:medicalClinicalState.Diaries[$position]=$replacementState
 Assert-Input ([object]::ReferenceEquals((Get-MedicalClinicalBinding 'diary' $last.Id).State,$replacementState)) 'Binding index notices in-place state replacement with the same diary ID'
 Set-MedicalClinicalValue 'diary' $last.Id 'fresh_field' 'AFTER REPLACEMENT'
 Assert-Input ($replacementState.Values.fresh_field -ceq 'AFTER REPLACEMENT') 'Input writes into replacement state immediately'
 Assert-Input ($previousBinding.State.Values.fresh_field -ceq 'RESTORED ANSWER') 'Replaced state receives no further patient changes'
 Remove-MedicalClinicalDiary $first.Id
 Assert-InputReject {Get-MedicalClinicalBinding 'diary' $first.Id} 'Deleted diary identifiers cannot resolve a stale state'
 Write-Output ('CHECKS '+$script:checks)
}finally{if([IO.Directory]::Exists($root)){[IO.Directory]::Delete($root,$true)}}
