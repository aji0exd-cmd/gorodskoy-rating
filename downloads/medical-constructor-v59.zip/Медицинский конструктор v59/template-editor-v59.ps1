﻿# v59: one window for a reusable form schema and its Word template.
# The editor never reads patient answers and never overwrites its source template.

function Get-MedicalEditorNamespace($document){
 $manager=[Xml.XmlNamespaceManager]::new($document.NameTable)
 $manager.AddNamespace('w','http://schemas.openxmlformats.org/wordprocessingml/2006/main')
 return ,$manager
}

function Read-MedicalEditorXml([byte[]]$bytes){
 $settings=New-Object Xml.XmlReaderSettings
 $settings.DtdProcessing=[Xml.DtdProcessing]::Prohibit;$settings.XmlResolver=$null
 $settings.MaxCharactersInDocument=33554432
 $stream=[IO.MemoryStream]::new($bytes,$false);$reader=$null
 try{
  $reader=[Xml.XmlReader]::Create($stream,$settings)
  $document=New-Object Xml.XmlDocument;$document.PreserveWhitespace=$true;$document.XmlResolver=$null
  $document.Load($reader);return ,$document
 }finally{if($reader){$reader.Dispose()};$stream.Dispose()}
}

function Get-MedicalEditorParagraphText($node,$namespaces){
 $text=New-Object Text.StringBuilder
 foreach($item in $node.SelectNodes('.//w:t|.//w:br|.//w:cr|.//w:tab',$namespaces)){
  if(-not [object]::ReferenceEquals($item.SelectSingleNode('ancestor::w:p[1]',$namespaces),$node)){continue}
  switch($item.LocalName){'t'{[void]$text.Append($item.InnerText)} 'tab'{[void]$text.Append("`t")} default{[void]$text.Append("`r`n")}}
 }
 return $text.ToString()
}

function Get-MedicalEditorParagraphRestriction($node,$namespaces){
 if($node.SelectSingleNode('.//w:br[@w:type="page" or @w:type="column" or @w:clear]',$namespaces)){
  return 'Абзац содержит разрыв страницы или колонки. Он сохраняется без изменений; добавьте маркер в отдельный обычный абзац.'
 }
 if($node.SelectSingleNode('ancestor::w:sdt|ancestor::w:del|ancestor::w:ins',$namespaces)){
  return 'Абзац находится внутри элемента Word или исправления. Его текст сохраняется без изменений; для маркера добавьте отдельный обычный абзац.'
 }
 foreach($child in $node.ChildNodes){
  if($child -isnot [Xml.XmlElement]){continue}
  if($child.NamespaceURI -ne 'http://schemas.openxmlformats.org/wordprocessingml/2006/main' -or $child.LocalName -notin @('pPr','r')){
   return 'Абзац содержит элемент Word, ссылку, закладку или объект. Для сохранения структуры он доступен только для чтения; вставьте маркер в новый обычный абзац.'
  }
  if($child.LocalName -eq 'r'){
   foreach($runChild in $child.ChildNodes){
    if($runChild -is [Xml.XmlElement] -and ($runChild.NamespaceURI -ne $node.NamespaceURI -or $runChild.LocalName -notin @('rPr','t','br','cr','tab'))){
     return 'Абзац содержит изображение, поле Word или встроенный объект. Он сохраняется без изменений; маркер можно вставить в отдельный абзац.'
    }
   }
  }
 }
 return ''
}

function Update-MedicalEditorParagraphs($model){
 $paragraphs=New-Object Collections.ArrayList
 foreach($partName in $model.PartOrder){
  $part=$model.Parts[$partName];$xml=$part.Xml;$namespaces=Get-MedicalEditorNamespace $xml;$index=0
  foreach($node in $xml.SelectNodes('//w:p',$namespaces)){
   $index++;$reason=Get-MedicalEditorParagraphRestriction $node $namespaces
   $location=if($node.SelectSingleNode('ancestor::w:tc',$namespaces)){'Таблица, абзац '+$index}else{'Абзац '+$index}
   if($node.SelectSingleNode('ancestor::*[local-name()="txbxContent"]',$namespaces)){$location='Текстовое поле, абзац '+$index}
   [void]$paragraphs.Add([pscustomobject]@{Id=($partName+'#'+$index);Part=$partName;Index=$index;Node=$node;Text=(Get-MedicalEditorParagraphText $node $namespaces);Editable=([string]::IsNullOrEmpty($reason));Reason=$reason;Location=$location})
  }
 }
 $model.Paragraphs=$paragraphs
}

function Read-MedicalTemplateModel([string]$path){
 $archive=$null
 $model=[pscustomobject]@{SourcePath=[IO.Path]::GetFullPath($path);TemplateExtension='';Entries=(New-Object Collections.ArrayList);Parts=@{};PartOrder=@();Paragraphs=(New-Object Collections.ArrayList)}
 try{
  $archive=[IO.Compression.ZipFile]::OpenRead($path);$names=@{};$total=0L
  foreach($entry in $archive.Entries){
   if($entry.FullName -ieq 'customXml/mc49.xml'){throw 'Вы выбрали сохранённую карту пациента. Для формы используйте чистый Word-шаблон без ответов пациента.'}
   if($names.ContainsKey($entry.FullName)){throw ('Повторяющаяся часть Word: '+$entry.FullName)};$names[$entry.FullName]=$true
   $total+=$entry.Length;if($entry.Length -gt 33554432 -or $total -gt 268435456){throw 'Шаблон слишком велик для встроенного редактора.'}
   $stream=$entry.Open();$memory=New-Object IO.MemoryStream
   try{$stream.CopyTo($memory);$bytes=$memory.ToArray()}finally{$stream.Dispose();$memory.Dispose()}
   [void]$model.Entries.Add([pscustomobject]@{Name=$entry.FullName;Bytes=$bytes;LastWriteTime=$entry.LastWriteTime;ExternalAttributes=$entry.ExternalAttributes})
   if($entry.FullName -ceq 'word/document.xml' -or $entry.FullName -cmatch '^word/(header|footer)[^/]*\.xml$'){
    $xml=Read-MedicalEditorXml $bytes
    $expected=if($entry.FullName -ceq 'word/document.xml'){'document'}elseif($entry.FullName -cmatch '/header'){'hdr'}else{'ftr'}
    if($xml.DocumentElement.LocalName -cne $expected -or $xml.DocumentElement.NamespaceURI -cne 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'){throw ('Некорректная часть Word: '+$entry.FullName)}
    $model.Parts[$entry.FullName]=[pscustomobject]@{Xml=$xml;Modified=$false}
   }
  }
  if(-not $model.Parts.ContainsKey('word/document.xml')){throw 'В файле отсутствует word/document.xml.'}
  $contentTypes=@($model.Entries | Where-Object {$_.Name -ceq '[Content_Types].xml'})
  if($contentTypes.Count -ne 1){throw 'В файле отсутствует описание частей Word.'}
  $typeXml=Read-MedicalEditorXml $contentTypes[0].Bytes
  $mainType=@($typeXml.DocumentElement.ChildNodes | Where-Object {$_ -is [Xml.XmlElement] -and $_.GetAttribute('PartName') -ceq '/word/document.xml'})
  if($mainType.Count -ne 1){throw 'В файле отсутствует тип основного документа Word.'}
  switch($mainType[0].GetAttribute('ContentType')){
   'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml'{$model.TemplateExtension='.docx'}
   'application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml'{$model.TemplateExtension='.dotx'}
   default{throw 'Поддерживаются обычные Word-файлы DOCX и DOTX без макросов.'}
  }
  $body=$model.Parts['word/document.xml'].Xml.SelectSingleNode('/w:document/w:body',(Get-MedicalEditorNamespace $model.Parts['word/document.xml'].Xml))
  if(-not $body){throw 'В шаблоне отсутствует основной текст Word.'}
  $model.PartOrder=@('word/document.xml')+@($model.Parts.Keys | Where-Object {$_ -cne 'word/document.xml'} | Sort-Object)
  foreach($partName in $model.PartOrder){
   $part=$model.Parts[$partName];$text=(($part.Xml.SelectNodes('//w:t',(Get-MedicalEditorNamespace $part.Xml)) | ForEach-Object {$_.InnerText}) -join '')
   if($text.Contains('MC_CASE_V24:')){throw 'Вы выбрали карту госпитализации с данными пациента. Для формы нужен чистый Word-шаблон.'}
  }
  Update-MedicalEditorParagraphs $model
  return $model
 }finally{if($archive){$archive.Dispose()}}
}

function Set-MedicalTemplateParagraph($model,[string]$id,[string]$text){
 $paragraph=@($model.Paragraphs | Where-Object {$_.Id -ceq $id})
 if($paragraph.Count -ne 1){throw 'Абзац шаблона не найден.'};$paragraph=$paragraph[0]
 # RichTextBox normalizes CRLF to LF. Merely selecting an existing multiline
 # paragraph must not rewrite it or collapse its original run formatting.
 if(($paragraph.Text -replace '\r\n|\r',"`n") -ceq ($text -replace '\r\n|\r',"`n")){return}
 if(-not $paragraph.Editable){throw $paragraph.Reason}
 $node=$paragraph.Node;$xml=$node.OwnerDocument;$namespaces=Get-MedicalEditorNamespace $xml
 $firstRun=$node.SelectSingleNode('./w:r',$namespaces);$runStyle=$null
 if($firstRun){$style=$firstRun.SelectSingleNode('./w:rPr',$namespaces);if($style){$runStyle=$style.CloneNode($true)}}
 foreach($run in @($node.SelectNodes('./w:r',$namespaces))){[void]$node.RemoveChild($run)}
 $run=$xml.CreateElement('w','r',$node.NamespaceURI);if($runStyle){[void]$run.AppendChild($runStyle)}
 $segments=[regex]::Split($text,'(\r\n|\r|\n|\t)')
 foreach($segment in $segments){
  if($segment -match '^\r\n$|^\r$|^\n$'){$child=$xml.CreateElement('w','br',$node.NamespaceURI)}
  elseif($segment -eq "`t"){$child=$xml.CreateElement('w','tab',$node.NamespaceURI)}
  else{$child=$xml.CreateElement('w','t',$node.NamespaceURI);$child.InnerText=$segment;$space=$xml.CreateAttribute('xml','space','http://www.w3.org/XML/1998/namespace');$space.Value='preserve';[void]$child.Attributes.Append($space)}
  [void]$run.AppendChild($child)
 }
 [void]$node.AppendChild($run);$paragraph.Text=$text;$model.Parts[$paragraph.Part].Modified=$true
}

function Add-MedicalTemplateParagraph($model,[string]$partName,[string]$afterId='',[string]$text=''){
 if(-not $model.Parts.ContainsKey($partName)){throw 'Часть Word не найдена.'}
 $part=$model.Parts[$partName];$xml=$part.Xml;$namespaces=Get-MedicalEditorNamespace $xml
 $node=$xml.CreateElement('w','p',$xml.DocumentElement.NamespaceURI)
 if($afterId){
  $selected=@($model.Paragraphs | Where-Object {$_.Id -ceq $afterId -and $_.Part -ceq $partName})
  if($selected.Count -ne 1){throw 'Выберите абзац для вставки.'}
  $anchor=$selected[0].Node
  if($anchor.ParentNode.NamespaceURI -ne $node.NamespaceURI -or $anchor.ParentNode.LocalName -notin @('body','tc','hdr','ftr')){throw 'Новый абзац можно добавить рядом с обычным абзацем, в таблице или колонтитуле. Выберите другое место.'}
  $style=$anchor.SelectSingleNode('./w:pPr',$namespaces)
  if($style){$copy=$style.CloneNode($true);foreach($sectionBreak in @($copy.SelectNodes('./w:sectPr',$namespaces))){[void]$copy.RemoveChild($sectionBreak)};[void]$node.AppendChild($copy)}
  [void]$anchor.ParentNode.InsertAfter($node,$anchor)
 }else{
  $container=if($partName -ceq 'word/document.xml'){$xml.SelectSingleNode('/w:document/w:body',$namespaces)}else{$xml.DocumentElement}
  $section=$container.SelectSingleNode('./w:sectPr',$namespaces)
  if($section){[void]$container.InsertBefore($node,$section)}else{[void]$container.AppendChild($node)}
 }
 $part.Modified=$true;Update-MedicalEditorParagraphs $model
 $record=@($model.Paragraphs | Where-Object {[object]::ReferenceEquals($_.Node,$node)})[0]
 if($text){Set-MedicalTemplateParagraph $model $record.Id $text}
 return $record
}

function Write-MedicalTemplateModel([string]$path,$model){
 $destination=[IO.Path]::GetFullPath($path)
 if($destination -eq [IO.Path]::GetFullPath($model.SourcePath)){throw 'Редактор не перезаписывает исходный шаблон. Сохраните отдельную копию.'}
 $parent=[IO.Path]::GetDirectoryName($destination)
 if(-not [IO.Directory]::Exists($parent)){throw 'Папка назначения не найдена.'}
 $temp=Join-Path $parent ('.mc-editor-'+[guid]::NewGuid().ToString('N')+'.tmp');$backup=$temp+'.bak';$archive=$null
 try{
  $archive=[IO.Compression.ZipFile]::Open($temp,[IO.Compression.ZipArchiveMode]::Create)
  foreach($entry in $model.Entries){
   $bytes=$entry.Bytes
   if($model.Parts.ContainsKey($entry.Name) -and $model.Parts[$entry.Name].Modified){
    $bytes=[Text.UTF8Encoding]::new($false).GetBytes($model.Parts[$entry.Name].Xml.OuterXml)
    [void](Read-MedicalEditorXml $bytes)
   }
   $output=$archive.CreateEntry($entry.Name,[IO.Compression.CompressionLevel]::Optimal)
   $output.LastWriteTime=$entry.LastWriteTime;$output.ExternalAttributes=$entry.ExternalAttributes
   $stream=$output.Open();try{$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
  }
  $archive.Dispose();$archive=$null
  [void](Read-MedicalTemplateModel $temp)
  if([IO.File]::Exists($destination)){[IO.File]::Replace($temp,$destination,$backup)}else{[IO.File]::Move($temp,$destination)}
  $temp=$null
 }finally{if($archive){$archive.Dispose()};if($temp -and [IO.File]::Exists($temp)){[IO.File]::Delete($temp)};if([IO.File]::Exists($backup)){[IO.File]::Delete($backup)}}
}

function Assert-MedicalEditorTemplateCoverage($config,$model){
 Assert-UniversalConfig $config
 $values=@{};$details=@{};$hits=@{}
 foreach($field in Get-UniversalFields $config){$values[[string]$field.Id]='Проверка '+[string]$field.Id;$details[[string]$field.Id]='Проверка уточнения'}
 foreach($partName in $model.PartOrder){
  # Run the real marker engine on a private XML copy. It validates unknown markers,
  # split runs, Word IDs and nested clarification bindings without changing the model.
  $copy=Read-MedicalEditorXml ([Text.Encoding]::UTF8.GetBytes($model.Parts[$partName].Xml.OuterXml))
  Set-UniversalXml $copy $config $values ([datetime]'2000-01-01T12:00:00') $hits $details
 }
 $missing=@(foreach($field in Get-UniversalFields $config){
  if(-not $hits.ContainsKey([string]$field.Marker)){$field.Label+' — {{'+$field.Marker+'}}'}
  if($field.Type -eq 'choice_detail' -and (Get-UniversalDetailWordPosition $field) -eq 'marker' -and -not $hits.ContainsKey([string]$field.DetailMarker)){$field.Label+' — {{'+$field.DetailMarker+'}} (уточнение)'}
 })
 if($missing.Count){throw ("Добавьте в шаблон маркеры полей или свяжите поля с элементами Word:`r`n"+($missing -join "`r`n"))}
 if(-not ($hits.ContainsKey('ADMISSION_DATETIME') -or ($hits.ContainsKey('ADMISSION_DATE') -and $hits.ContainsKey('ADMISSION_TIME')))){throw 'Добавьте {{ADMISSION_DATETIME}} либо оба маркера {{ADMISSION_DATE}} и {{ADMISSION_TIME}}.'}
}

function Save-MedicalEditorResult($config,$model,[string]$name){
 $schema=Copy-MedicalFormSchema $config
 Assert-MedicalEditorTemplateCoverage $schema $model
 if(-not [IO.Path]::GetExtension($name)){$name+=$model.TemplateExtension};$name=Get-MedicalTemplateName $name
 if([IO.Path]::GetExtension($name) -ine $model.TemplateExtension){throw ('Этот шаблон имеет формат '+$model.TemplateExtension+'. Используйте это расширение, чтобы Word открывал файл корректно.')}
 $folder=Join-Path ([IO.Path]::GetTempPath()) ('mc-editor-result-'+[guid]::NewGuid().ToString('N'))
 [void][IO.Directory]::CreateDirectory($folder);$path=Join-Path $folder $name
 try{
  Write-MedicalTemplateModel $path $model
  $verified=Read-MedicalTemplateModel $path;Assert-MedicalEditorTemplateCoverage $schema $verified
  $template=Import-MedicalTemplate $path
  $schema.Template=$template.RelativePath;$schema.AutoTemplate=$false
  return [pscustomobject]@{Schema=$schema;Template=$template}
 }finally{if([IO.Directory]::Exists($folder)){[IO.Directory]::Delete($folder,$true)}}
}

function New-MedicalEditorLabel([string]$text){
 $label=New-Object Windows.Forms.Label;$label.Text=$text;$label.Dock='Fill';$label.TextAlign='MiddleLeft';return $label
}

function New-MedicalEditorButton([string]$text){
 $button=New-Object Windows.Forms.Button;$button.Text=$text;$button.AutoSize=$true;$button.Height=32;$button.Margin=New-Object Windows.Forms.Padding(4);return $button
}

function Show-MedicalFormTemplateEditor($owner,$config){
 $schema=Copy-MedicalFormSchema $config
 $initialTemp=$null
 try{
  if($schema.AutoTemplate){
   $initialTemp=Join-Path ([IO.Path]::GetTempPath()) ('mc-editor-source-'+[guid]::NewGuid().ToString('N')+'.docx')
   New-UniversalTemplate $initialTemp $schema;$source=$initialTemp
  }else{
   $source=[string]$schema.Template
   if(-not [IO.Path]::IsPathRooted($source)){$source=Join-Path $script:medicalProgramRoot ($source.Replace('\',[IO.Path]::DirectorySeparatorChar))}
  }
  $model=Read-MedicalTemplateModel $source
  $state=@{Schema=$schema;Model=$model;Selected=$null;Paragraph=$null;Loading=$false;Result=$null;Dirty=$false}
  $dialog=New-Object Windows.Forms.Form;$dialog.Text='Форма и шаблон Word — единый редактор';$dialog.Size=New-Object Drawing.Size(1380,900);$dialog.MinimumSize=New-Object Drawing.Size(1100,740);$dialog.StartPosition='CenterParent';$dialog.Font=New-Object Drawing.Font('Segoe UI',10)
  $layout=New-Object Windows.Forms.TableLayoutPanel;$layout.Dock='Fill';$layout.ColumnCount=1;$layout.RowCount=2
  [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)));[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',62)))
  $split=New-Object Windows.Forms.SplitContainer;$split.Dock='Fill';$split.Orientation='Vertical';$split.Size=New-Object Drawing.Size(1360,790);$split.Panel1MinSize=380;$split.Panel2MinSize=500;$split.SplitterDistance=460
  $layout.Controls.Add($split,0,0);$dialog.Controls.Add($layout)
  $left=New-Object Windows.Forms.TableLayoutPanel;$left.Dock='Fill';$left.ColumnCount=1;$left.RowCount=3
  [void]$left.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',84)));[void]$left.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',43)));[void]$left.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',57)))
  $leftButtons=New-Object Windows.Forms.FlowLayoutPanel;$leftButtons.Dock='Fill'
  $addSection=New-MedicalEditorButton '+ Раздел';$addField=New-MedicalEditorButton '+ Поле';$delete=New-MedicalEditorButton 'Удалить';$up=New-MedicalEditorButton 'Выше';$down=New-MedicalEditorButton 'Ниже'
  foreach($button in @($addSection,$addField,$delete,$up,$down)){$leftButtons.Controls.Add($button)}
  $tree=New-Object Windows.Forms.TreeView;$tree.Dock='Fill';$tree.HideSelection=$false;$tree.FullRowSelect=$true
  $tabs=New-Object Windows.Forms.TabControl;$tabs.Dock='Fill'
  $fieldTab=New-Object Windows.Forms.TabPage;$fieldTab.Text='Поле / раздел';$fieldTab.AutoScroll=$true
  $detailTab=New-Object Windows.Forms.TabPage;$detailTab.Text='Уточнение';$detailTab.AutoScroll=$true
  $tabs.TabPages.Add($fieldTab);$tabs.TabPages.Add($detailTab)
  $left.Controls.Add($leftButtons,0,0);$left.Controls.Add($tree,0,1);$left.Controls.Add($tabs,0,2);$split.Panel1.Controls.Add($left)
  $properties=New-Object Windows.Forms.TableLayoutPanel;$properties.Dock='Top';$properties.AutoSize=$true;$properties.ColumnCount=2;$properties.Padding=New-Object Windows.Forms.Padding(6)
  [void]$properties.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Absolute',125)));[void]$properties.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',100)))
  $fieldName=New-Object Windows.Forms.TextBox;$fieldMarker=New-Object Windows.Forms.TextBox
  $fieldType=New-Object Windows.Forms.ComboBox;$fieldType.DropDownStyle='DropDownList'
  $typeIds=@('text','multiline','choice','choice_detail','heading','multi','repeat')
  $fieldType.Items.AddRange([object[]]@('Строка','Многострочный текст','Список','Список с уточнением','Подзаголовок','Галочки','Повторяемые строки'))
  $fieldOptions=New-Object Windows.Forms.TextBox;$fieldOptions.Multiline=$true;$fieldOptions.ScrollBars='Vertical';$fieldOptions.Height=100
  $fieldRequired=New-Object Windows.Forms.CheckBox;$fieldRequired.Text='Обязательное поле'
  $fieldRole=New-Object Windows.Forms.ComboBox;$fieldRole.DropDownStyle='DropDownList';$fieldRole.Items.AddRange([object[]]@('Обычное поле','Ф.И.О.','Дата рождения','Адрес'));$roleIds=@('','name','birth','address')
  $fieldWordId=New-Object Windows.Forms.TextBox
  $rows=@(@('Название',$fieldName,36),@('Маркер Word',$fieldMarker,36),@('Тип',$fieldType,36),@('Варианты',$fieldOptions,110),@('Проверка',$fieldRequired,36),@('Роль пациента',$fieldRole,36),@('ID элемента Word',$fieldWordId,36))
  $row=0;foreach($item in $rows){[void]$properties.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',[int]$item[2])));$item[1].Dock='Fill';$properties.Controls.Add((New-MedicalEditorLabel $item[0]),0,$row);$properties.Controls.Add($item[1],1,$row);$row++};$fieldTab.Controls.Add($properties)
  $detailProperties=New-Object Windows.Forms.TableLayoutPanel;$detailProperties.Dock='Top';$detailProperties.AutoSize=$true;$detailProperties.ColumnCount=1;$detailProperties.Padding=New-Object Windows.Forms.Padding(8)
  $detailForm=New-Object Windows.Forms.ComboBox;$detailForm.DropDownStyle='DropDownList';$detailForm.Items.AddRange([object[]]@('Под списком','Над списком','Справа от списка'))
  $detailWord=New-Object Windows.Forms.ComboBox;$detailWord.DropDownStyle='DropDownList';$detailWord.Items.AddRange([object[]]@('После варианта','Перед вариантом','С новой строки','Отдельный маркер'))
  $detailMarker=New-Object Windows.Forms.TextBox
  $detailControls=@((New-MedicalEditorLabel 'Расположение уточнения в форме'),$detailForm,(New-MedicalEditorLabel 'Расположение уточнения в Word'),$detailWord,(New-MedicalEditorLabel 'Отдельный маркер (без {{ }})'),$detailMarker,(New-MedicalEditorLabel 'Маркер справа вставляется в позицию курсора. Ответы пациента в форму не сохраняются.'))
  $row=0;foreach($control in $detailControls){[void]$detailProperties.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',$(if($row -eq 6){76}else{38}))));$control.Dock='Fill';$detailProperties.Controls.Add($control,0,$row);$row++};$detailTab.Controls.Add($detailProperties)
  $right=New-Object Windows.Forms.TableLayoutPanel;$right.Dock='Fill';$right.ColumnCount=1;$right.RowCount=6
  foreach($height in @(48,70,38)){[void]$right.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',$height)))}
  [void]$right.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',42)));[void]$right.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',58)));[void]$right.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',76)))
  $templateTools=New-Object Windows.Forms.FlowLayoutPanel;$templateTools.Dock='Fill'
  $loadTemplate=New-MedicalEditorButton 'Загрузить Word';$buildTemplate=New-MedicalEditorButton 'Создать по полям'
  $templateName=New-Object Windows.Forms.TextBox;$templateName.Width=230;$templateName.Margin=New-Object Windows.Forms.Padding(5,8,5,0)
  $templateName.Text=if($schema.AutoTemplate){'Мой шаблон.docx'}else{[IO.Path]::GetFileName($source)}
  foreach($control in @($loadTemplate,$buildTemplate,$templateName)){$templateTools.Controls.Add($control)}
  $hint=New-MedicalEditorLabel 'Выберите поле слева и абзац справа. Вставляйте маркеры в текст. Таблицы, изображения, стили абзацев и колонтитулы сохраняются. Изменённый обычный абзац использует стиль своего первого текстового фрагмента; это редактор текста, а не макета страниц Word.'
  $partCombo=New-Object Windows.Forms.ComboBox;$partCombo.DropDownStyle='DropDownList';$partCombo.Dock='Fill'
  $paragraphList=New-Object Windows.Forms.ListBox;$paragraphList.Dock='Fill';$paragraphList.HorizontalScrollbar=$true;$paragraphList.DisplayMember='Display'
  $paragraphText=New-Object Windows.Forms.RichTextBox;$paragraphText.Dock='Fill';$paragraphText.AcceptsTab=$true;$paragraphText.DetectUrls=$false;$paragraphText.WordWrap=$true
  $markerTools=New-Object Windows.Forms.FlowLayoutPanel;$markerTools.Dock='Fill'
  $insertField=New-MedicalEditorButton 'Вставить маркер поля';$insertDetail=New-MedicalEditorButton 'Маркер уточнения';$insertDate=New-MedicalEditorButton 'Дата и время';$addParagraph=New-MedicalEditorButton '+ Абзац'
  foreach($button in @($insertField,$insertDetail,$insertDate,$addParagraph)){$markerTools.Controls.Add($button)}
  $right.Controls.Add($templateTools,0,0);$right.Controls.Add($hint,0,1);$right.Controls.Add($partCombo,0,2);$right.Controls.Add($paragraphList,0,3);$right.Controls.Add($paragraphText,0,4);$right.Controls.Add($markerTools,0,5);$split.Panel2.Controls.Add($right)
  $footer=New-Object Windows.Forms.FlowLayoutPanel;$footer.Dock='Fill';$footer.FlowDirection='RightToLeft'
  $cancel=New-MedicalEditorButton 'Отмена';$cancel.DialogResult='Cancel';$save=New-MedicalEditorButton 'Применить форму и Word';$save.Width=245
  $footer.Controls.Add($cancel);$footer.Controls.Add($save);$layout.Controls.Add($footer,0,1);$dialog.CancelButton=$cancel

  $commitProperties={
   if($state.Loading -or -not $state.Selected){return}
   $selection=$state.Selected
   if($selection.Kind -eq 'section'){$selection.Section.Title=$fieldName.Text.Trim();return}
   $field=$selection.Field;$field.Label=$fieldName.Text.Trim();$field.Marker=$fieldMarker.Text.Trim().ToUpperInvariant()
   if($fieldType.SelectedIndex -ge 0){$field.Type=$typeIds[$fieldType.SelectedIndex]}
   $field.Options=@($fieldOptions.Lines | Where-Object {-not [string]::IsNullOrWhiteSpace($_)})
   $field.System=$roleIds[[Math]::Max(0,$fieldRole.SelectedIndex)];$field.WordId=$fieldWordId.Text.Trim()
   $field | Add-Member -NotePropertyName Required -NotePropertyValue ([bool]$fieldRequired.Checked) -Force
   if($field.Type -in @('heading','multi','repeat')){$field.System='';$field.WordId=''}
   if($field.Type -eq 'heading'){$field.Required=$false;$field.Options=@()}
   if($field.Type -eq 'choice_detail'){
    $field | Add-Member -NotePropertyName DetailFormPosition -NotePropertyValue @('below','above','right')[[Math]::Max(0,$detailForm.SelectedIndex)] -Force
    $field | Add-Member -NotePropertyName DetailWordPosition -NotePropertyValue @('after','before','newline','marker')[[Math]::Max(0,$detailWord.SelectedIndex)] -Force
    $field | Add-Member -NotePropertyName DetailMarker -NotePropertyValue $detailMarker.Text.Trim().ToUpperInvariant() -Force
   }
  }.GetNewClosure()
  $commitParagraph={if($state.Paragraph -and -not $state.Loading){Set-MedicalTemplateParagraph $state.Model $state.Paragraph.Id $paragraphText.Text}}.GetNewClosure()
  $showError={param($exception)[void][Windows.Forms.MessageBox]::Show($dialog,$exception.Exception.Message,'Форма и шаблон','OK','Warning')}.GetNewClosure()
  $loadProperties={
   $state.Loading=$true
   try{
    $selection=$state.Selected;$isField=$selection -and $selection.Kind -eq 'field'
    foreach($control in @($fieldMarker,$fieldType,$fieldOptions,$fieldRequired,$fieldRole,$fieldWordId)){$control.Enabled=[bool]$isField}
    $detailTab.Enabled=[bool]$isField -and $selection.Field.Type -eq 'choice_detail'
    $fieldName.Enabled=[bool]$selection
    if(-not $selection){$fieldName.Text='';return}
    if(-not $isField){$fieldName.Text=$selection.Section.Title;$fieldMarker.Text='';return}
    $field=$selection.Field;$fieldName.Text=$field.Label;$fieldMarker.Text=$field.Marker;$fieldType.SelectedIndex=$typeIds.IndexOf([string]$field.Type)
    $fieldOptions.Text=@($field.Options) -join "`r`n";$fieldRequired.Checked=(Test-UniversalFieldRequired $field);$fieldRole.SelectedIndex=$roleIds.IndexOf([string]$field.System);$fieldWordId.Text=[string]$field.WordId
    $detailForm.SelectedIndex=@('below','above','right').IndexOf((Get-UniversalDetailFormPosition $field));$detailWord.SelectedIndex=@('after','before','newline','marker').IndexOf((Get-UniversalDetailWordPosition $field));$detailMarker.Text=[string]$field.DetailMarker
    if(-not $detailMarker.Text){$detailMarker.Text=$field.Marker+'_DETAIL'}
   }finally{$state.Loading=$false}
  }.GetNewClosure()
  $refreshTree={param([string]$selectedId='')
   $state.Loading=$true;$tree.BeginUpdate()
   try{
    $tree.Nodes.Clear();$chosen=$null
    foreach($section in $state.Schema.Sections){
     $sectionNode=New-Object Windows.Forms.TreeNode([string]$section.Title);$sectionNode.Tag=[pscustomobject]@{Kind='section';Section=$section;Field=$null}
     [void]$tree.Nodes.Add($sectionNode);if($section.Id -eq $selectedId){$chosen=$sectionNode}
     foreach($field in $section.Fields){$node=New-Object Windows.Forms.TreeNode(($field.Label+'  {{'+$field.Marker+'}}'));$node.Tag=[pscustomobject]@{Kind='field';Section=$section;Field=$field};[void]$sectionNode.Nodes.Add($node);if($field.Id -eq $selectedId){$chosen=$node}}
     $sectionNode.Expand()
    }
    if(-not $chosen -and $tree.Nodes.Count){$chosen=$tree.Nodes[0]};$tree.SelectedNode=$chosen;$state.Selected=if($chosen){$chosen.Tag}else{$null}
   }finally{$tree.EndUpdate();$state.Loading=$false}
   & $loadProperties
  }.GetNewClosure()
  $loadParagraph={
   $state.Loading=$true
   try{
    $item=$paragraphList.SelectedItem;$state.Paragraph=if($item){$item.Paragraph}else{$null}
    if($state.Paragraph){$paragraphText.Text=$state.Paragraph.Text;$paragraphText.ReadOnly=-not $state.Paragraph.Editable;if(-not $state.Paragraph.Editable){$hint.Text=$state.Paragraph.Reason}else{$hint.Text='Редактируйте текст выбранного абзаца. Маркер вставляется в позицию курсора. Стиль абзаца и первый стиль текста сохраняются; изображения и сложные элементы не изменяются.'}}
    else{$paragraphText.Text='';$paragraphText.ReadOnly=$true}
    foreach($button in @($insertField,$insertDetail,$insertDate)){$button.Enabled=$state.Paragraph -and $state.Paragraph.Editable}
   }finally{$state.Loading=$false}
  }.GetNewClosure()
  $refreshParagraphs={param([string]$selectedId='')
   $state.Loading=$true;$paragraphList.BeginUpdate()
   try{
    $paragraphList.Items.Clear();$partIndex=$partCombo.SelectedIndex
    if($partIndex -ge 0){
     $partName=$state.Model.PartOrder[$partIndex]
     foreach($paragraph in $state.Model.Paragraphs | Where-Object {$_.Part -ceq $partName}){
      $preview=($paragraph.Text -replace '[\r\n\t]+',' ');if($preview.Length -gt 145){$preview=$preview.Substring(0,145)+'…'}
      $display=$paragraph.Location+' | '+$preview;if(-not $paragraph.Editable){$display='[только чтение] '+$display}
      $item=[pscustomobject]@{Display=$display;Paragraph=$paragraph};[void]$paragraphList.Items.Add($item)
      if($paragraph.Id -ceq $selectedId){$paragraphList.SelectedIndex=$paragraphList.Items.Count-1}
     }
    }
    if($paragraphList.SelectedIndex -lt 0 -and $paragraphList.Items.Count){$paragraphList.SelectedIndex=0}
   }finally{$paragraphList.EndUpdate();$state.Loading=$false}
   & $loadParagraph
  }.GetNewClosure()
  $refreshParts={
   $state.Loading=$true;$partCombo.Items.Clear()
   foreach($part in $state.Model.PartOrder){$label=if($part -ceq 'word/document.xml'){'Основной документ'}elseif($part -match '/header'){'Верхний колонтитул'}else{'Нижний колонтитул'};[void]$partCombo.Items.Add(($label+' — '+$part))}
   $partCombo.SelectedIndex=0;$state.Paragraph=$null;$state.Loading=$false;& $refreshParagraphs
  }.GetNewClosure()
  $tree.Add_AfterSelect({if($state.Loading){return};try{& $commitProperties;$state.Selected=$tree.SelectedNode.Tag;& $loadProperties}catch{& $showError $_}}.GetNewClosure())
  $partCombo.Add_SelectedIndexChanged({if($state.Loading){return};try{& $commitParagraph;& $refreshParagraphs}catch{& $showError $_}}.GetNewClosure())
  $paragraphList.Add_SelectedIndexChanged({if($state.Loading){return};try{& $commitParagraph;& $loadParagraph}catch{& $showError $_}}.GetNewClosure())
  $fieldType.Add_SelectedIndexChanged({if($state.Loading){return};$detailTab.Enabled=$fieldType.SelectedIndex -eq 3;$fieldOptions.Enabled=$fieldType.SelectedIndex -in @(2,3,5,6)}.GetNewClosure())
  $addSection.Add_Click({try{& $commitProperties;$section=[pscustomobject]@{Id=[guid]::NewGuid().ToString('N');Title='Новый раздел';Fields=@()};$state.Schema.Sections+=@($section);& $refreshTree $section.Id}catch{& $showError $_}}.GetNewClosure())
  $addField.Add_Click({try{& $commitProperties;if(-not $state.Selected){throw 'Добавьте или выберите раздел.'};$section=$state.Selected.Section;$id=[guid]::NewGuid().ToString('N');$field=New-UniversalField $id 'Новое поле' ('FIELD_'+$id.Substring(0,8).ToUpperInvariant()) 'multiline';$section.Fields+=@($field);& $refreshTree $field.Id}catch{& $showError $_}}.GetNewClosure())
  $delete.Add_Click({try{& $commitProperties;if(-not $state.Selected){return};if([Windows.Forms.MessageBox]::Show($dialog,'Удалить выбранное поле или раздел? Маркеры в Word удалите или замените справа.','Удаление','YesNo','Question') -ne 'Yes'){return};$selection=$state.Selected;if($selection.Kind -eq 'section'){$state.Schema.Sections=@($state.Schema.Sections | Where-Object {$_.Id -cne $selection.Section.Id})}else{$selection.Section.Fields=@($selection.Section.Fields | Where-Object {$_.Id -cne $selection.Field.Id})};& $refreshTree}catch{& $showError $_}}.GetNewClosure())
  $moveItem={param([int]$offset)
   & $commitProperties;if(-not $state.Selected){return};$selection=$state.Selected
   $items=if($selection.Kind -eq 'section'){@($state.Schema.Sections)}else{@($selection.Section.Fields)}
   $selectedId=if($selection.Kind -eq 'section'){$selection.Section.Id}else{$selection.Field.Id};$index=-1
   for($i=0;$i -lt $items.Count;$i++){if($items[$i].Id -ceq $selectedId){$index=$i;break}}
   $target=$index+$offset;if($index -lt 0 -or $target -lt 0 -or $target -ge $items.Count){return}
   $old=$items[$index];$items[$index]=$items[$target];$items[$target]=$old
   if($selection.Kind -eq 'section'){$state.Schema.Sections=$items}else{$selection.Section.Fields=$items};& $refreshTree $selectedId
  }.GetNewClosure()
  $up.Add_Click({try{& $moveItem -1}catch{& $showError $_}}.GetNewClosure());$down.Add_Click({try{& $moveItem 1}catch{& $showError $_}}.GetNewClosure())
  $insertField.Add_Click({try{& $commitProperties;if(-not $state.Selected -or $state.Selected.Kind -ne 'field'){throw 'Выберите поле слева.'};$paragraphText.SelectedText='{{'+$state.Selected.Field.Marker+'}}';[void]$paragraphText.Focus()}catch{& $showError $_}}.GetNewClosure())
  $insertDetail.Add_Click({try{& $commitProperties;if(-not $state.Selected -or $state.Selected.Kind -ne 'field' -or $state.Selected.Field.Type -ne 'choice_detail' -or (Get-UniversalDetailWordPosition $state.Selected.Field) -ne 'marker'){throw 'Выберите поле «Список с уточнением» и расположение Word «Отдельный маркер».'};$paragraphText.SelectedText='{{'+$state.Selected.Field.DetailMarker+'}}';[void]$paragraphText.Focus()}catch{& $showError $_}}.GetNewClosure())
  $insertDate.Add_Click({$paragraphText.SelectedText='{{ADMISSION_DATETIME}}';[void]$paragraphText.Focus()}.GetNewClosure())
  $addParagraph.Add_Click({try{& $commitParagraph;$partName=$state.Model.PartOrder[$partCombo.SelectedIndex];$afterId=if($state.Paragraph){$state.Paragraph.Id}else{''};$record=Add-MedicalTemplateParagraph $state.Model $partName $afterId '';& $refreshParagraphs $record.Id;[void]$paragraphText.Focus()}catch{& $showError $_}}.GetNewClosure())
  $loadTemplate.Add_Click({
   $picker=New-Object Windows.Forms.OpenFileDialog;$picker.Title='Шаблон Word для этой формы';$picker.Filter='Word (*.docx;*.dotx)|*.docx;*.dotx'
   try{if($picker.ShowDialog($dialog) -eq 'OK'){& $commitProperties;& $commitParagraph;$candidate=Read-MedicalTemplateModel $picker.FileName;if([Windows.Forms.MessageBox]::Show($dialog,'Заменить рабочий шаблон? Его текущие изменения не будут сохранены. Поля формы сохранятся.','Загрузка Word','YesNo','Question') -eq 'Yes'){$state.Model=$candidate;$templateName.Text=[IO.Path]::GetFileName($picker.FileName);& $refreshParts}}}catch{& $showError $_}finally{$picker.Dispose()}
  }.GetNewClosure())
  $buildTemplate.Add_Click({
   $path=Join-Path ([IO.Path]::GetTempPath()) ('mc-editor-rebuild-'+[guid]::NewGuid().ToString('N')+'.docx')
   try{& $commitProperties;& $commitParagraph;Assert-UniversalConfig $state.Schema;if([Windows.Forms.MessageBox]::Show($dialog,'Создать новый Word по текущим полям? Рабочий текст шаблона будет заменён; исходный файл останется сохранён.','Новый шаблон','YesNo','Question') -eq 'Yes'){New-UniversalTemplate $path $state.Schema;$state.Model=Read-MedicalTemplateModel $path;$templateName.Text='Мой шаблон.docx';& $refreshParts}}catch{& $showError $_}finally{if([IO.File]::Exists($path)){[IO.File]::Delete($path)}}
  }.GetNewClosure())
  $save.Add_Click({try{& $commitProperties;& $commitParagraph;$state.Result=Save-MedicalEditorResult $state.Schema $state.Model $templateName.Text.Trim();$dialog.DialogResult='OK';$dialog.Close()}catch{& $showError $_}}.GetNewClosure())
  & $refreshTree;& $refreshParts
  if(Get-Command Set-DarkTheme -ErrorAction SilentlyContinue){Set-DarkTheme $dialog}
  try{if($dialog.ShowDialog($owner) -eq 'OK'){return $state.Result};return $null}finally{$dialog.Dispose()}
 }finally{if($initialTemp -and [IO.File]::Exists($initialTemp)){[IO.File]::Delete($initialTemp)}}
}
