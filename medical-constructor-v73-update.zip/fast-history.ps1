﻿function Get-MedicalFastDiarySchedule([datetime]$start,[datetime]$end){
 $start=$start.Date
 $end=$end.Date
 if($end -lt $start){throw 'Дата окончания лечения не может быть раньше даты начала.'}
 # A same-day admission has a separate final entry on the discharge date.
 $last=$end.AddHours(9)
 $next=$start.AddDays(1).AddHours(9)
 for($i=0;$i -lt 3 -and $next -lt $last;$i++){
  [pscustomobject]@{Start=$next;End=$next}
  $next=$next.AddDays(1)
 }
 $remaining=[int]($last-$next).TotalDays
 $blockSize=if($remaining % 3 -eq 0){3}else{2}
 while($remaining -gt 0){
  $length=if($remaining -eq 1){1}elseif($blockSize -eq 2 -and $remaining % 2 -eq 1){3}else{$blockSize}
  [pscustomobject]@{Start=$next;End=$next.AddDays($length-1)}
  $remaining-=$length
  $next=$next.AddDays($length)
 }
 [pscustomobject]@{Start=$last;End=$last}
}

function ConvertTo-MedicalFastDiagnosisKey([string]$diagnosis){
 $value=($diagnosis.Trim() -replace '\s+',' ').ToUpperInvariant()
 if($value -match '^([A-Z][0-9]{2}(?:\.[0-9A-Z]+)?)(?:\s|$|[,:;])'){return $Matches[1]}
 return $value
}

function Get-MedicalFastTemplatePath([string]$diagnosis,[string]$sex){
 $key=(ConvertTo-MedicalFastDiagnosisKey $diagnosis)+'|'+$sex
 $hash=Get-MedicalBytesSha256 ([Text.Encoding]::UTF8.GetBytes($key))
 $folder=Join-Path $script:medicalAccountWorkspace.DataRoot 'Шаблоны быстрых историй'
 $path=Join-Path $folder ($hash+'.mcform')
 Assert-MedicalAccountPath $path
 return $path
}

function Get-MedicalFastIntakeFields($schema){
 $fields=@{}
 foreach($field in Get-UniversalFields $schema){
  $kind=Get-MedicalPatientIdentityKind $field
  if($field.Marker -in @('PRELIMINARY_DIAGNOSIS','DIAGNOSIS') -or $field.Id -eq 'diagnosis'){$kind='diagnosis'}
  if($kind -in @('name','birth','address','diagnosis') -and $field.Type -in @('text','multiline') -and -not $fields.ContainsKey($kind)){
   $fields[$kind]=[string]$field.Id
  }
 }
 foreach($key in @('name','birth','address','diagnosis')){
  if(-not $fields.ContainsKey($key)){throw 'В первичной форме нужны текстовые поля ФИО, даты рождения, адреса и диагноза. Для диагноза используйте маркер PRELIMINARY_DIAGNOSIS или DIAGNOSIS.'}
 }
 return $fields
}

function Show-MedicalFastTemplateRegistration($owner){
 try{
  $null=Assert-MedicalActiveAccount
  if(-not $script:medicalWorkspaceReady -or $script:universalConfig.StandaloneStage -or -not $script:medicalClinicalForms){
   throw 'Откройте форму полной истории болезни с первичным осмотром, дневниками и эпикризом.'
  }
  [void](Get-MedicalFastIntakeFields $script:universalConfig)
  $diagnosis=Show-UniversalTextPrompt $owner 'Диагноз или код МКБ для шаблона быстрой истории' ([string]$script:universalConfig.ProfileCode)
  if([string]::IsNullOrWhiteSpace($diagnosis)){return}
  $answer=[Windows.Forms.MessageBox]::Show($owner,"Для какого пола использовать шаблон?`r`nДа — мужской. Нет — женский.",'Пол для шаблона','YesNoCancel','Question')
  if($answer -eq 'Cancel'){return}
  $sex=if($answer -eq 'Yes'){'M'}else{'F'}
  $path=Get-MedicalFastTemplatePath $diagnosis $sex
  if([IO.File]::Exists($path) -and [Windows.Forms.MessageBox]::Show($owner,'Шаблон для этого диагноза и пола уже есть. Заменить его?','Шаблон быстрой истории','YesNo','Question') -ne 'Yes'){return}
  $schema=Copy-MedicalFormSchema $script:universalConfig
  $schema | Add-Member -NotePropertyName ProfileCode -NotePropertyValue (ConvertTo-MedicalFastDiagnosisKey $diagnosis) -Force
  $schema | Add-Member -NotePropertyName ProfileSex -NotePropertyValue $sex -Force
  [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($path))
  [void](Write-MedicalForm $path $schema $script:activeMedicalFormName (Get-MedicalClinicalFormData))
  [void][Windows.Forms.MessageBox]::Show($owner,'Форма и Word-шаблоны добавлены в подбор для быстрых историй.','Шаблон быстрой истории')
 }catch{[void][Windows.Forms.MessageBox]::Show($owner,$_.Exception.Message,'Шаблон быстрой истории')}
}

function ConvertTo-MedicalFastHistoryInput($values,[int]$row){
 foreach($name in @('Name','Birth','Address','Diagnosis','Start','End')){
  if([string]::IsNullOrWhiteSpace([string]$values[$name])){throw "Строка ${row}. Заполните ФИО, дату рождения, адрес, диагноз и обе даты лечения."}
 }
 $dates=@{}
 foreach($key in @('Birth','Start','End')){
  $date=[datetime]::MinValue
  if(-not [datetime]::TryParseExact([string]$values[$key],'dd.MM.yyyy',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$date)){
   throw "Строка ${row}. Введите даты в формате ДД.ММ.ГГГГ."
  }
  $dates[$key]=$date
 }
 if($dates.Birth -gt $dates.Start -or $dates.End -lt $dates.Start -or $dates.Start.Year -lt 1753 -or $dates.End.Year -gt 9998){
  throw "Строка ${row}. Проверьте дату рождения и порядок дат лечения."
 }
 if(($dates.End-$dates.Start).TotalDays -gt 3660){throw "Строка ${row}. Укажите период лечения до 3660 дней."}
 $sex=switch($values.Sex){'Мужской'{'M'} 'Женский'{'F'} default{''}}
 return [pscustomobject]@{Name=$values.Name;Birth=$dates.Birth;Address=$values.Address;Diagnosis=$values.Diagnosis;Sex=$sex;Start=$dates.Start;End=$dates.End}
}

function Show-MedicalFastHistoryInput($owner){
 $dialog=New-MedicalAccountsUiDialog 'Быстрая история болезни' 1120 430
 $dialog.MinimumSize=New-Object Drawing.Size(850,340)
 $dialog.FormBorderStyle='Sizable'
 $hint=New-Object Windows.Forms.Label
 $hint.Text='Одна строка — одна история. Даты вводятся в формате ДД.ММ.ГГГГ. Для подбора шаблона укажите пол.'
 $hint.SetBounds(16,14,1080,36);$hint.Anchor='Top,Left,Right';$dialog.Controls.Add($hint)
 $grid=New-Object Windows.Forms.DataGridView
 $grid.SetBounds(16,52,1088,307);$grid.Anchor='Top,Bottom,Left,Right'
 $grid.AutoSizeColumnsMode='Fill';$grid.AllowUserToAddRows=$true;$grid.AllowUserToDeleteRows=$true
 foreach($definition in @(@('Name','ФИО пациента',140),@('Birth','Дата рождения',75),@('Address','Адрес',140),
   @('Diagnosis','Диагноз / код МКБ',135),@('Sex','Пол для шаблона',85),@('Start','Начало лечения',76),@('End','Окончание лечения',82))){
  if($definition[0] -eq 'Sex'){
   $column=New-Object Windows.Forms.DataGridViewComboBoxColumn
   [void]$column.Items.Add('Мужской');[void]$column.Items.Add('Женский')
  }else{$column=New-Object Windows.Forms.DataGridViewTextBoxColumn}
  $column.Name=$definition[0];$column.HeaderText=$definition[1];$column.FillWeight=$definition[2]
  $column.SortMode='NotSortable';[void]$grid.Columns.Add($column)
 }
 $dialog.Controls.Add($grid)
 $create=New-Object Windows.Forms.Button
 $create.Text='Создать и сохранить';$create.SetBounds(765,377,200,36);$create.Anchor='Bottom,Right'
 $create.DialogResult='OK';$dialog.Controls.Add($create)
 $cancel=New-Object Windows.Forms.Button
 $cancel.Text='Отмена';$cancel.SetBounds(978,377,126,36);$cancel.Anchor='Bottom,Right'
 $cancel.DialogResult='Cancel';$dialog.Controls.Add($cancel);$dialog.CancelButton=$cancel
 try{
  while($dialog.ShowDialog($owner) -eq 'OK'){
   [void]$grid.EndEdit()
   try{
    $result=@(foreach($entry in $grid.Rows){
     if($entry.IsNewRow){continue}
     $values=@{}
     foreach($cell in $entry.Cells){$values[$cell.OwningColumn.Name]=([string]$cell.Value).Trim()}
     if(@($values.Values | Where-Object {$_}).Count){ConvertTo-MedicalFastHistoryInput $values ($entry.Index+1)}
    })
    if(-not $result.Count){throw 'Добавьте хотя бы одного пациента.'}
    return $result
   }catch{[void][Windows.Forms.MessageBox]::Show($owner,$_.Exception.Message,'Быстрая история болезни')}
  }
 }finally{$dialog.Dispose()}
}

function Initialize-MedicalFastHistory($person,$formTemplate){
 $schema=if($formTemplate){Copy-MedicalFormSchema $formTemplate.Schema}else{New-MedicalQuickCaseSchema}
 $fields=Get-MedicalFastIntakeFields $schema
 $schema | Add-Member -NotePropertyName RequireConfirmedTreatmentPeriod -NotePropertyValue $true -Force
 $schema | Add-Member -NotePropertyName ProfileSex -NotePropertyValue $person.Sex -Force
 $schema | Add-Member -NotePropertyName ProfileCode -NotePropertyValue (ConvertTo-MedicalFastDiagnosisKey $person.Diagnosis) -Force
 $forms=if($formTemplate.StageForms){Copy-MedicalClinicalFormData $formTemplate.StageForms}else{New-MedicalClinicalFormData $schema}
 $forms.Diaries=@()
 foreach($stageSchema in @($forms.DiaryForm.Schema,$forms.Discharge.Schema)){
  $stageSchema | Add-Member -NotePropertyName ProfileSex -NotePropertyValue $person.Sex -Force
  $stageSchema | Add-Member -NotePropertyName ProfileCode -NotePropertyValue $schema.ProfileCode -Force
 }
 if($forms.Discharge.FollowInitialSchema){$forms.Discharge.InitialSchemaSignature=Get-MedicalClinicalInitialSignature $schema $true}
 $title=if($formTemplate){$formTemplate.Name}else{'Быстрая история болезни'}
 Use-MedicalFormSchema $schema $title '' $forms
 $values=@{}
 $values[$fields.name]=$person.Name
 $values[$fields.birth]=$person.Birth.ToString('dd.MM.yyyy')
 $values[$fields.address]=$person.Address
 $values[$fields.diagnosis]=$person.Diagnosis
 if(Get-MedicalClinicalField $schema 'case_draft_notice'){$values.case_draft_notice='Черновик. Требуется проверка и заполнение по фактическим данным.'}
 Restore-UniversalState ([pscustomobject]@{Schema=$schema;AdmissionDateTime=$person.Start;Values=$values})
 [void](Set-MedicalTreatmentPeriod $person.Start $person.End)
 foreach($dates in @(Get-MedicalFastDiarySchedule $person.Start $person.End)){
  $entry=Add-MedicalClinicalDiary
  $count=if($dates.Start -eq $dates.End){1}else{2}
  Set-MedicalDiaryDateCount $entry.Id $count
  Set-MedicalDiaryDates $entry.Id $dates.Start $dates.End
  foreach($field in Get-UniversalFields $entry.Schema){
   if($field.Marker -in @('DIAGNOSIS','PRELIMINARY_DIAGNOSIS') -and $field.Type -in @('text','multiline')){
    Set-MedicalClinicalValue 'diary' $entry.Id ([string]$field.Id) $person.Diagnosis
   }
  }
 }
 foreach($field in Get-UniversalFields $forms.Discharge.Schema){
  if($field.Marker -in @('DIAGNOSIS','PRELIMINARY_DIAGNOSIS') -and $field.Type -in @('text','multiline')){
   Set-MedicalClinicalValue 'discharge' '' ([string]$field.Id) $person.Diagnosis
  }
 }
 Open-Stage
}

function Invoke-MedicalFastHistory($owner){
 try{
  $null=Assert-MedicalActiveAccount
  $people=@(Show-MedicalFastHistoryInput $owner)
  if(-not $people.Count){return}
  $folder=Get-MedicalDocumentFolder 'Save'
  $plans=@(foreach($person in $people){
   $template=$null
   if($person.Sex){
    $templatePath=Get-MedicalFastTemplatePath $person.Diagnosis $person.Sex
    if([IO.File]::Exists($templatePath)){$template=Read-MedicalForm $templatePath;[void](Get-MedicalFastIntakeFields $template.Schema)}
   }
   [pscustomobject]@{Person=$person;Template=$template}
  })
  if(-not (Confirm-MedicalFormReset)){return}
  $results=@(foreach($plan in $plans){
   try{
    $person=$plan.Person
    Initialize-MedicalFastHistory $person $plan.Template
    $name=($person.Name -replace '[\\/:*?"<>|]','_').Trim()
    $stem=$name+' — '+$person.Start.ToString('dd.MM.yyyy')
    $path=Join-Path $folder ($stem+'.docx')
    for($i=2;[IO.File]::Exists($path);$i++){$path=Join-Path $folder ($stem+' ('+$i+').docx')}
    Save-Case $path
    if(-not [IO.File]::Exists($path)){throw 'История не сохранена.'}
    [IO.Path]::GetFileName($path)+$(if(-not $plan.Template){' — типовой шаблон'})
   }catch{$plan.Person.Name+' — '+$_.Exception.Message}
  })
  [void][Windows.Forms.MessageBox]::Show($owner,($folder+"`r`n`r`n"+($results -join "`r`n")),'Результаты создания историй')
 }catch{[void][Windows.Forms.MessageBox]::Show($owner,$_.Exception.Message,'Быстрая история болезни')}
}
