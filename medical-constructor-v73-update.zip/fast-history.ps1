﻿function Get-MedicalFastDiarySchedule([datetime]$start,[datetime]$end){
 $start=$start.Date
 $end=$end.Date
 if($end -lt $start){throw 'Дата окончания лечения не может быть раньше даты начала.'}
 # A same-day admission has a separate final entry on the discharge date.
 $last=$end.AddHours(9)
 $next=$start.AddDays(1).AddHours(9)
 for($i=0;$i -lt 3 -and $next -lt $last;$i++){
  [pscustomobject]@{Start=$next;End=$next}
  $next=$next.AddDays(1)
 }
 $remaining=[int]($last-$next).TotalDays
 $blockSize=if($remaining % 3 -eq 0){3}else{2}
 while($remaining -gt 0){
  $length=if($remaining -eq 1){1}elseif($blockSize -eq 2 -and $remaining % 2 -eq 1){3}else{$blockSize}
  [pscustomobject]@{Start=$next;End=$next.AddDays($length-1)}
  $remaining-=$length
  $next=$next.AddDays($length)
 }
 [pscustomobject]@{Start=$last;End=$last}
}

function ConvertTo-MedicalFastDiagnosisKey([string]$diagnosis){
 $value=($diagnosis.Trim() -replace '\s+',' ').ToUpperInvariant()
 if($value -match '^([A-Z][0-9]{2}(?:\.[0-9A-Z]+)?)(?:\s|$|[,:;])'){return $Matches[1]}
 return $value
}

function Get-MedicalFastTemplatePath([string]$diagnosis,[string]$sex){
 $key=(ConvertTo-MedicalFastDiagnosisKey $diagnosis)+'|'+$sex
 $hash=Get-MedicalBytesSha256 ([Text.Encoding]::UTF8.GetBytes($key))
 $folder=Join-Path $script:medicalAccountWorkspace.DataRoot 'Шаблоны быстрых историй'
 $path=Join-Path $folder ($hash+'.mcform')
 Assert-MedicalAccountPath $path
 return $path
}

function Get-MedicalFastIntakeFields($schema){
 $fields=@{}
 foreach($field in Get-UniversalFields $schema){
  $kind=Get-MedicalPatientIdentityKind $field
  if($field.Marker -in @('PRELIMINARY_DIAGNOSIS','DIAGNOSIS') -or $field.Id -eq 'diagnosis'){$kind='diagnosis'}
  if($kind -in @('name','birth','address','diagnosis') -and $field.Type -in @('text','multiline') -and -not $fields.ContainsKey($kind)){
   $fields[$kind]=[string]$field.Id
  }
 }
 foreach($key in @('name','birth','address','diagnosis')){
  if(-not $fields.ContainsKey($key)){throw 'В первичной форме нужны текстовые поля ФИО, даты рождения, адреса и диагноза. Для диагноза используйте маркер PRELIMINARY_DIAGNOSIS или DIAGNOSIS.'}
 }
 return $fields
}

function Get-MedicalFastTemplateStages {
 $forms=Get-MedicalClinicalFormData
 if(-not $forms.DiaryForm -or -not $forms.Discharge){
  throw 'Для быстрой истории требуются формы первичного осмотра, дневника и выписного эпикриза.'
 }
 # A fast history generates diary records from the shared template.
 $forms.Diaries=@()
 # The saved discharge template belongs to this set and keeps its own layout.
 $forms.Discharge | Add-Member -NotePropertyName FollowInitialSchema -NotePropertyValue $false -Force
 return $forms
}

function Show-MedicalFastTemplateSetup($owner){
 if(-not $script:medicalWorkspaceReady -or -not $script:medicalClinicalForms -or $script:universalConfig.StandaloneStage){
  [void][Windows.Forms.MessageBox]::Show($owner,'Создайте или откройте форму полной истории болезни.','Шаблоны быстрых историй')
  return
 }
 $dialog=New-MedicalAccountsUiDialog 'Шаблон быстрой истории' 660 343
 $heading=New-Object Windows.Forms.Label
 $heading.Text='Шаблон быстрой истории'
 $heading.Font=New-Object Drawing.Font('Segoe UI',17,[Drawing.FontStyle]::Bold)
 $heading.SetBounds(22,15,616,37);$dialog.Controls.Add($heading)
 $hint=New-Object Windows.Forms.Label
 $hint.Text='Настройте три Word-шаблона. Общая форма дневника применяется ко всем записям наблюдения.'
 $hint.SetBounds(22,58,616,44);$dialog.Controls.Add($hint)
 $switchStage=Get-Command Switch-Stage -CommandType Function -ErrorAction Stop
 $editStage=Get-Command Invoke-MedicalFormTemplateEditor -CommandType Function -ErrorAction Stop
 $row=108
 foreach($entry in @(@('initial','Первичный осмотр'),@('diary','Общий шаблон дневников'),@('discharge','Выписной эпикриз'))){
  $stage=[string]$entry[0]
  $label=New-Object Windows.Forms.Label
  $label.Text=$entry[1];$label.SetBounds(24,$row,346,32);$dialog.Controls.Add($label)
  $button=New-Object Windows.Forms.Button
  $button.Text='Форма и шаблон Word…';$button.SetBounds(394,($row-4),242,36)
  $button.Add_Click({
   & $switchStage $stage
   & $editStage $dialog
  }.GetNewClosure())
  $dialog.Controls.Add($button)
  $row+=54
 }
 $save=New-Object Windows.Forms.Button
 $save.Name='mc-case-save';$save.Text='Добавить комплект в подбор…';$save.SetBounds(249,280,264,40)
 $register=Get-Command Show-MedicalFastTemplateRegistration -CommandType Function -ErrorAction Stop
 $save.Add_Click({& $register $dialog}.GetNewClosure())
 $dialog.Controls.Add($save)
 $close=New-Object Windows.Forms.Button
 $close.Text='Закрыть';$close.DialogResult='Cancel';$close.SetBounds(526,280,110,40)
 $dialog.Controls.Add($close);$dialog.CancelButton=$close
 Set-DarkTheme $dialog
 try{[void]$dialog.ShowDialog($owner)}finally{$dialog.Dispose()}
}

function Show-MedicalFastTemplateRegistration($owner){
 try{
  $null=Assert-MedicalActiveAccount
  if(-not $script:medicalWorkspaceReady -or $script:universalConfig.StandaloneStage -or -not $script:medicalClinicalForms){
   throw 'Откройте форму полной истории болезни с первичным осмотром, дневниками и эпикризом.'
  }
  [void](Get-MedicalFastIntakeFields $script:universalConfig)
  $stages=Get-MedicalFastTemplateStages
  $diagnosis=Show-UniversalTextPrompt $owner 'Диагноз или код МКБ для шаблона быстрой истории' ([string]$script:universalConfig.ProfileCode)
  if([string]::IsNullOrWhiteSpace($diagnosis)){return}
  $answer=[Windows.Forms.MessageBox]::Show($owner,"Для какого пола использовать шаблон?`r`nДа — мужской. Нет — женский.",'Пол для шаблона','YesNoCancel','Question')
  if($answer -eq 'Cancel'){return}
  $sex=if($answer -eq 'Yes'){'M'}else{'F'}
  $path=Get-MedicalFastTemplatePath $diagnosis $sex
  if([IO.File]::Exists($path) -and [Windows.Forms.MessageBox]::Show($owner,'Шаблон для этого диагноза и пола уже есть. Заменить его?','Шаблон быстрой истории','YesNo','Question') -ne 'Yes'){return}
  $schema=Copy-MedicalFormSchema $script:universalConfig
  $schema | Add-Member -NotePropertyName ProfileCode -NotePropertyValue (ConvertTo-MedicalFastDiagnosisKey $diagnosis) -Force
  $schema | Add-Member -NotePropertyName ProfileSex -NotePropertyValue $sex -Force
  [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($path))
  [void](Write-MedicalForm $path $schema $script:activeMedicalFormName $stages)
  [void][Windows.Forms.MessageBox]::Show($owner,'Комплект из трёх Word-шаблонов добавлен в подбор для быстрых историй.','Шаблон быстрой истории')
 }catch{[void][Windows.Forms.MessageBox]::Show($owner,$_.Exception.Message,'Шаблон быстрой истории')}
}

function ConvertTo-MedicalFastHistoryInput($values,[int]$row){
 foreach($name in @('Name','Birth','Address','Diagnosis','Start','End')){
  if([string]::IsNullOrWhiteSpace([string]$values[$name])){throw "Пациент ${row}. Заполните ФИО, дату рождения, адрес, диагноз и обе даты лечения."}
 }
 $dates=@{}
 foreach($key in @('Birth','Start','End')){
  $date=[datetime]::MinValue
  if(-not [datetime]::TryParseExact([string]$values[$key],'dd.MM.yyyy',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$date)){
   throw "Пациент ${row}. Введите даты в формате ДД.ММ.ГГГГ."
  }
  $dates[$key]=$date
 }
 if($dates.Birth -gt $dates.Start -or $dates.End -lt $dates.Start -or $dates.Start.Year -lt 1753 -or $dates.End.Year -gt 9998){
  throw "Пациент ${row}. Проверьте дату рождения и порядок дат лечения."
 }
 if(($dates.End-$dates.Start).TotalDays -gt 3660){throw "Пациент ${row}. Укажите период лечения до 3660 дней."}
 $sex=switch($values.Sex){'Мужской'{'M'} 'Женский'{'F'} default{''}}
 return [pscustomobject]@{Name=$values.Name;Birth=$dates.Birth;Address=$values.Address;Diagnosis=$values.Diagnosis;Sex=$sex;Start=$dates.Start;End=$dates.End}
}

function Show-MedicalFastHistoryInput($owner){
 $dialog=New-MedicalAccountsUiDialog 'Быстрая история болезни' 930 545
 $heading=New-Object Windows.Forms.Label
 $heading.Text='Быстрая история болезни'
 $heading.Font=New-Object Drawing.Font('Segoe UI',18,[Drawing.FontStyle]::Bold)
 $heading.SetBounds(24,16,890,38);$dialog.Controls.Add($heading)
 $description=New-Object Windows.Forms.Label
 $description.Name='mc-muted-fast-history'
 $description.Text='Заполните данные пациента и период лечения. Для нескольких историй добавьте пациентов в список.'
 $description.SetBounds(25,57,880,41);$dialog.Controls.Add($description)

 $patient=New-Object MedicalOutlinePanel
 $patient.SetBounds(24,105,558,359);$dialog.Controls.Add($patient)
 $fields=@{}
 foreach($definition in @(
  @('Name','ФИО пациента',20,18,518,'text'),
  @('Birth','Дата рождения',20,85,246,'birth'),
  @('Sex','Пол для подбора шаблона',290,85,248,'sex'),
  @('Address','Адрес проживания',20,152,518,'text'),
  @('Diagnosis','Диагноз или код МКБ',20,219,518,'text'),
  @('Start','Начало лечения',20,286,246,'date'),
  @('End','Окончание лечения',290,286,248,'date')
 )){
  $key,$caption,$left,$top,$width,$kind=$definition
  $label=New-Object Windows.Forms.Label
  $label.Text=$caption;$label.SetBounds($left,$top,$width,22);$patient.Controls.Add($label)
  switch($kind){
   'text'{$control=New-Object Windows.Forms.TextBox}
   'sex'{
    $control=New-Object Windows.Forms.ComboBox;$control.DropDownStyle='DropDownList'
    [void]$control.Items.AddRange(@('Не указан','Мужской','Женский'));$control.SelectedIndex=0
   }
   default{
    $control=New-Object Windows.Forms.DateTimePicker
    $control.Format='Custom';$control.CustomFormat='dd.MM.yyyy';$control.Value=[datetime]::Today
    $control.MinDate=[datetime]'1753-01-01';$control.MaxDate=[datetime]'9998-12-31'
    if($kind -eq 'birth'){$control.ShowCheckBox=$true;$control.Checked=$false}
   }
  }
  $control.AccessibleName=$caption
  $control.SetBounds($left,($top+25),$width,31);$patient.Controls.Add($control)
  $fields[$key]=$control
 }

 $batch=New-Object MedicalOutlinePanel
 $batch.SetBounds(599,105,307,359);$dialog.Controls.Add($batch)
 $batchTitle=New-Object Windows.Forms.Label
 $batchTitle.Text='Пациенты к сохранению'
 $batchTitle.Font=New-Object Drawing.Font('Segoe UI',11,[Drawing.FontStyle]::Bold)
 $batchTitle.SetBounds(16,16,275,26);$batch.Controls.Add($batchTitle)
 $queue=New-Object Windows.Forms.ListBox
 $queue.AccessibleName='Пациенты к сохранению';$queue.HorizontalScrollbar=$true
 $queue.SetBounds(16,53,275,238);$batch.Controls.Add($queue)
 $queue.DisplayMember='Name'
 $add=New-Object Windows.Forms.Button
 $add.Text='Добавить в список';$add.SetBounds(16,308,155,35);$batch.Controls.Add($add)
 $remove=New-Object Windows.Forms.Button
 $remove.Text='Удалить';$remove.SetBounds(182,308,109,35);$remove.Enabled=$false;$batch.Controls.Add($remove)
 $queue.Add_SelectedIndexChanged({$remove.Enabled=$queue.SelectedIndex -ge 0}.GetNewClosure())
 $remove.Add_Click({if($queue.SelectedIndex -ge 0){$queue.Items.RemoveAt($queue.SelectedIndex)}}.GetNewClosure())

 $status=New-Object Windows.Forms.Label
 $status.SetBounds(25,482,525,47);$dialog.Controls.Add($status)
 $create=New-Object Windows.Forms.Button
 $create.Name='mc-case-save';$create.Text='Создать и сохранить';$create.SetBounds(559,483,206,40)
 $dialog.Controls.Add($create);$dialog.AcceptButton=$create
 $cancel=New-Object Windows.Forms.Button
 $cancel.Text='Отмена';$cancel.SetBounds(779,483,127,40);$cancel.DialogResult='Cancel'
 $dialog.Controls.Add($cancel);$dialog.CancelButton=$cancel

 $convert=Get-Command ConvertTo-MedicalFastHistoryInput -CommandType Function -ErrorAction Stop
 $readPatient={
  $inputValues=@{Sex=[string]$fields.Sex.SelectedItem}
  foreach($key in @('Name','Address','Diagnosis')){$inputValues[$key]=$fields[$key].Text.Trim()}
  if($fields.Birth.Checked){$inputValues.Birth=$fields.Birth.Value.ToString('dd.MM.yyyy')}
  foreach($key in @('Start','End')){$inputValues[$key]=$fields[$key].Value.ToString('dd.MM.yyyy')}
  & $convert $inputValues ($queue.Items.Count+1)
 }.GetNewClosure()
 $result=[pscustomobject]@{People=@()}
 $add.Add_Click({
  try{
   $person=& $readPatient
   [void]$queue.Items.Add($person)
   foreach($key in @('Name','Address','Diagnosis')){$fields[$key].Clear()}
   $fields.Birth.Value=[datetime]::Today;$fields.Birth.Checked=$false
   $fields.Sex.SelectedIndex=0
   $fields.Start.Value=[datetime]::Today;$fields.End.Value=[datetime]::Today
   $status.Text='';[void]$fields.Name.Focus()
  }catch{$status.Text=$_.Exception.Message}
 }.GetNewClosure())
 $create.Add_Click({
  try{
   $people=@(foreach($person in $queue.Items){$person})
   $hasDraft=$fields.Name.Text.Trim() -or $fields.Address.Text.Trim() -or $fields.Diagnosis.Text.Trim() -or
    $fields.Birth.Checked -or $fields.Sex.SelectedIndex -gt 0 -or
    $fields.Start.Value.Date -ne [datetime]::Today -or $fields.End.Value.Date -ne [datetime]::Today
   if($hasDraft -or -not $people.Count){$people+=@(& $readPatient)}
   $result.People=$people
   $dialog.DialogResult='OK'
  }catch{$status.Text=$_.Exception.Message}
 }.GetNewClosure())
 Set-DarkTheme $dialog
 $queue.BackColor=$script:darkInput
 $status.ForeColor=$script:uiDanger
 $dialog.ActiveControl=$fields.Name
 try{if($dialog.ShowDialog($owner) -eq 'OK'){return $result.People}}finally{$dialog.Dispose()}
}

function Initialize-MedicalFastHistory($person,$formTemplate){
 $schema=if($formTemplate){Copy-MedicalFormSchema $formTemplate.Schema}else{New-MedicalQuickCaseSchema}
 $fields=Get-MedicalFastIntakeFields $schema
 $schema | Add-Member -NotePropertyName RequireConfirmedTreatmentPeriod -NotePropertyValue $true -Force
 $schema | Add-Member -NotePropertyName ProfileSex -NotePropertyValue $person.Sex -Force
 $schema | Add-Member -NotePropertyName ProfileCode -NotePropertyValue (ConvertTo-MedicalFastDiagnosisKey $person.Diagnosis) -Force
 $forms=if($formTemplate.StageForms){Copy-MedicalClinicalFormData $formTemplate.StageForms}else{New-MedicalClinicalFormData $schema}
 $forms.Diaries=@()
 foreach($stageSchema in @($forms.DiaryForm.Schema,$forms.Discharge.Schema)){
  $stageSchema | Add-Member -NotePropertyName ProfileSex -NotePropertyValue $person.Sex -Force
  $stageSchema | Add-Member -NotePropertyName ProfileCode -NotePropertyValue $schema.ProfileCode -Force
 }
 if($forms.Discharge.FollowInitialSchema){$forms.Discharge.InitialSchemaSignature=Get-MedicalClinicalInitialSignature $schema $true}
 $title=if($formTemplate){$formTemplate.Name}else{'Быстрая история болезни'}
 Use-MedicalFormSchema $schema $title '' $forms
 $values=@{}
 $values[$fields.name]=$person.Name
 $values[$fields.birth]=$person.Birth.ToString('dd.MM.yyyy')
 $values[$fields.address]=$person.Address
 $values[$fields.diagnosis]=$person.Diagnosis
 if(Get-MedicalClinicalField $schema 'case_draft_notice'){$values.case_draft_notice='Черновик. Требуется проверка и заполнение по фактическим данным.'}
 Restore-UniversalState ([pscustomobject]@{Schema=$schema;AdmissionDateTime=$person.Start;Values=$values})
 [void](Set-MedicalTreatmentPeriod $person.Start $person.End)
 foreach($dates in @(Get-MedicalFastDiarySchedule $person.Start $person.End)){
  $entry=Add-MedicalClinicalDiary
  $count=if($dates.Start -eq $dates.End){1}else{2}
  Set-MedicalDiaryDateCount $entry.Id $count
  Set-MedicalDiaryDates $entry.Id $dates.Start $dates.End
  foreach($field in Get-UniversalFields $entry.Schema){
   if($field.Marker -in @('DIAGNOSIS','PRELIMINARY_DIAGNOSIS') -and $field.Type -in @('text','multiline')){
    Set-MedicalClinicalValue 'diary' $entry.Id ([string]$field.Id) $person.Diagnosis
   }
  }
 }
 foreach($field in Get-UniversalFields $forms.Discharge.Schema){
  if($field.Marker -in @('DIAGNOSIS','PRELIMINARY_DIAGNOSIS') -and $field.Type -in @('text','multiline')){
   Set-MedicalClinicalValue 'discharge' '' ([string]$field.Id) $person.Diagnosis
  }
 }
 Open-Stage
}

function Invoke-MedicalFastHistory($owner){
 try{
  $null=Assert-MedicalActiveAccount
  $people=@(Show-MedicalFastHistoryInput $owner)
  if(-not $people.Count){return}
  $folder=Get-MedicalDocumentFolder 'Save'
  $plans=@(foreach($person in $people){
   $template=$null
   if($person.Sex){
    $templatePath=Get-MedicalFastTemplatePath $person.Diagnosis $person.Sex
    if([IO.File]::Exists($templatePath)){$template=Read-MedicalForm $templatePath;[void](Get-MedicalFastIntakeFields $template.Schema)}
   }
   [pscustomobject]@{Person=$person;Template=$template}
  })
  if(-not (Confirm-MedicalFormReset)){return}
  $results=@(foreach($plan in $plans){
   try{
    $person=$plan.Person
    Initialize-MedicalFastHistory $person $plan.Template
    $name=($person.Name -replace '[\\/:*?"<>|]','_').Trim()
    $stem=$name+' — '+$person.Start.ToString('dd.MM.yyyy')
    $path=Join-Path $folder ($stem+'.docx')
    for($i=2;[IO.File]::Exists($path);$i++){$path=Join-Path $folder ($stem+' ('+$i+').docx')}
    Save-Case $path
    if(-not [IO.File]::Exists($path)){throw 'История не сохранена.'}
    $diaryCount=@(Get-MedicalClinicalDiaryContexts).Count
    [IO.Path]::GetFileName($path)+" — осмотр, записи дневника: ${diaryCount}, эпикриз"+$(if(-not $plan.Template){' (типовой шаблон)'})
   }catch{$plan.Person.Name+' — '+$_.Exception.Message}
  })
  [void][Windows.Forms.MessageBox]::Show($owner,($folder+"`r`n`r`n"+($results -join "`r`n")),'Результаты создания историй')
 }catch{[void][Windows.Forms.MessageBox]::Show($owner,$_.Exception.Message,'Быстрая история болезни')}
}
