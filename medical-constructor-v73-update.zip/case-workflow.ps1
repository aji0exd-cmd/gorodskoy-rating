﻿function New-MedicalQuickCaseSchema {
 $schema=New-UniversalConfig
 $schema.Sections[0].Fields[2].Label='Место проживания'
 $schema.Sections[0].Fields+=@(New-UniversalField 'case_work_status' 'Статус занятости' 'PATIENT_WORK_STATUS' 'text')
 $schema.Sections=@([pscustomobject]@{Id='draft';Title='Черновик';Fields=@(
  (New-UniversalField 'case_draft_notice' 'Статус документа' 'CASE_DRAFT_NOTICE' 'text')
 )})+@($schema.Sections)
 foreach($field in Get-UniversalFields $schema){$field.Required=$false}
 $schema | Add-Member -NotePropertyName RequireConfirmedTreatmentPeriod -NotePropertyValue $true
 return $schema
}

function Show-MedicalQuickCaseInput($owner,[string]$title,[string]$mode){
 $showPeriod=$mode -ne 'diary'
 $dialog=New-Object Windows.Forms.Form
 $dialog.Text=$title
 $dialog.ClientSize=New-Object Drawing.Size(620,360)
 $dialog.StartPosition='CenterParent'
 $dialog.FormBorderStyle='FixedDialog'
 $dialog.MaximizeBox=$false
 $dialog.MinimizeBox=$false
 $inputs=@{}
 $row=16
 foreach($entry in @(@('Name','ФИО'),@('Work','Статус занятости'),@('Address','Место проживания'),@('Diagnosis','Диагноз'))){
  $label=New-Object Windows.Forms.Label
  $label.Text=$entry[1]
  $label.SetBounds(16,$row,170,24)
  $dialog.Controls.Add($label)
  $input=New-Object Windows.Forms.TextBox
  $input.SetBounds(190,$row,410,25)
  $dialog.Controls.Add($input)
  $inputs[$entry[0]]=$input
  $row+=38
 }
 $admissionLabel=New-Object Windows.Forms.Label
 $admissionLabel.Text=if($mode -eq 'diary'){'Дата и время записи'}else{'Дата и время поступления'}
 $admissionLabel.SetBounds(16,168,170,36)
 $dialog.Controls.Add($admissionLabel)
 $admission=New-Object Windows.Forms.DateTimePicker
 $admission.Format='Custom'
 $admission.CustomFormat='dd.MM.yyyy  HH:mm'
 $admission.SetBounds(190,168,220,26)
 $dialog.Controls.Add($admission)
 $end=New-Object Windows.Forms.DateTimePicker
 $end.Format='Custom'
 $end.CustomFormat='dd.MM.yyyy'
 $end.ShowCheckBox=$true
 $end.Checked=$false
 $end.SetBounds(190,210,220,26)
 if($showPeriod){
  $endLabel=New-Object Windows.Forms.Label
  $endLabel.Text='Дата окончания лечения'
  $endLabel.SetBounds(16,210,170,35)
  $dialog.Controls.Add($endLabel)
  $dialog.Controls.Add($end)
 }
 $hint=New-Object Windows.Forms.Label
 $hint.Text='Сведения пациента будут перенесены в черновик. Клинические данные внесите после проверки.'
 $hint.SetBounds(16,253,584,42)
 $dialog.Controls.Add($hint)
 $ok=New-Object Windows.Forms.Button
 $ok.Text='Создать черновик'
 $ok.DialogResult='OK'
 $ok.SetBounds(270,308,160,34)
 $dialog.Controls.Add($ok)
 $dialog.AcceptButton=$ok
 $cancel=New-Object Windows.Forms.Button
 $cancel.Text='Отмена'
 $cancel.DialogResult='Cancel'
 $cancel.SetBounds(444,308,156,34)
 $dialog.Controls.Add($cancel)
 $dialog.CancelButton=$cancel
 Set-DarkTheme $dialog
 try{
  while($dialog.ShowDialog($owner) -eq 'OK'){
   $values=@{}
   foreach($key in $inputs.Keys){$values[$key]=$inputs[$key].Text.Trim()}
   $message=''
   if(-not ($values.Name -and $values.Work -and $values.Address -and $values.Diagnosis)){
    $message='Заполните ФИО, статус занятости, место проживания и диагноз.'
   }
   $until=$null
   if($showPeriod -and $end.Checked){
    $until=$end.Value.Date
    if(-not $message){
     try{[void](ConvertTo-MedicalTreatmentDate $until 'окончания лечения');if($until -lt $admission.Value.Date){throw 'Дата окончания лечения не может быть раньше даты поступления.'}
      if(($until-$admission.Value.Date).TotalDays -gt 3660){throw 'Укажите период до 3660 дней.'}
     }catch{$message=$_.Exception.Message}
    }
   }
   if(-not $message){
    try{[void](ConvertTo-MedicalTreatmentDate $admission.Value 'поступления')}catch{$message=$_.Exception.Message}
   }
   if(-not $message){return [pscustomobject]@{Values=$values;Admission=$admission.Value;End=$until}}
   [void][Windows.Forms.MessageBox]::Show($owner,$message,$title)
  }
 }finally{$end.Dispose();$dialog.Dispose()}
}

function Invoke-MedicalQuickCase($owner,[ValidateSet('case','diary','discharge')][string]$mode){
 try{
  $null=Assert-MedicalActiveAccount
  $title=switch($mode){'diary'{'Новый дневник наблюдения'} 'discharge'{'Новый выписной эпикриз'} default{'Новая история болезни'}}
  $intake=Show-MedicalQuickCaseInput $owner $title $mode
  if(-not $intake){return}
  $schema=New-MedicalQuickCaseSchema
  $forms=New-MedicalClinicalFormData $schema
  $diarySchema=$forms.DiaryForm.Schema
  $diarySchema.Sections[0].Fields+=@(foreach($id in @('case_work_status','diagnosis','case_draft_notice')){
   $field=Copy-UniversalObject (Get-MedicalClinicalField $schema $id)
   if($id -eq 'diagnosis'){$field.Label='Указанный диагноз'}
   $field
  })
  $forms.DiaryForm.Links=Get-MedicalClinicalDefaultLinks $diarySchema $schema
  if(-not (Confirm-MedicalFormReset)){return}
  Use-MedicalFormSchema $schema $title '' $forms
  $script:admissionControl.Value=$intake.Admission
  Restore-UniversalState ([pscustomobject]@{
   Schema=$schema
   AdmissionDateTime=$intake.Admission
   Values=@{
    patient_name=$intake.Values.Name
    patient_address=$intake.Values.Address
    case_work_status=$intake.Values.Work
    diagnosis=$intake.Values.Diagnosis
    case_draft_notice='Черновик. Требуется проверка и заполнение по фактическим данным.'
   }
  })
  if($null -ne $intake.End){[void](Set-MedicalTreatmentPeriod $intake.Admission $intake.End)}
  $diaryId=''
  if($mode -eq 'case' -and $null -ne $intake.End -and $intake.End -gt $intake.Admission.Date){
   [void](Add-MedicalClinicalDiaryPeriod $intake.Admission $intake.End)
  }elseif($mode -ne 'discharge'){
   $entry=Add-MedicalClinicalDiary
   Set-MedicalClinicalDate $entry.Id $intake.Admission
   $diaryId=$entry.Id
  }
  $script:stage=if($mode -eq 'case'){'initial'}else{$mode}
  if($mode -eq 'diary'){$script:medicalActiveDiaryId=$diaryId}
  Open-Stage
  Request-MedicalClinicalCheckpoint
 }catch{[void][Windows.Forms.MessageBox]::Show($owner,$_.Exception.Message,'Создание черновика')}
}

function Invoke-MedicalSeparateDocument($owner,[ValidateSet('diary','discharge')][string]$stage,[string]$id=''){
 $picker=$null
 $temporary=''
 try{
  if(-not $script:medicalClinicalForms){throw 'Создайте или откройте форму пациента.'}
  [void](Sync-MedicalAdmissionDateTime)
  Capture-Stage
  if($stage -eq 'diary'){
   $entries=@(Get-MedicalClinicalDiaryContexts | Where-Object {
    if($id){$_.Id -eq $id}else{-not (Test-MedicalClinicalDiaryUnscheduled $_)}
   })
   if(-not $entries.Count){throw 'Добавьте хотя бы один дневник.'}
   $title=if($id){$entries[0].Title}else{'Дневники наблюдения'}
  }else{
   Sync-MedicalDischargeSchemaFromInitial $true
   $context=Get-MedicalClinicalContext 'discharge'
   $title='Выписной эпикриз'
  }
  $picker=New-Object Windows.Forms.SaveFileDialog
  $picker.Title='Сохранить отдельный документ Word'
  $picker.Filter='Документ Word (*.docx)|*.docx'
  $picker.DefaultExt='docx'
  $picker.AddExtension=$true
  $picker.OverwritePrompt=$true
  if($script:medicalAuthSession){$picker.InitialDirectory=Get-MedicalAccountCardsDirectory}
  $nameField=Get-UniversalFields $script:universalConfig | Where-Object {$_.System -eq 'name'} | Select-Object -First 1
  $patientName=if($nameField){[string]$script:universalValues[[string]$nameField.Id]}
  if($patientName){$title=$patientName+' — '+$title}
  $picker.FileName=([string]$title -replace '[\\/:*?"<>|]','_')+'.docx'
  if($picker.ShowDialog($owner) -ne 'OK'){return}
  $path=[IO.Path]::GetFullPath($picker.FileName)
  if([IO.Path]::GetExtension($path) -ine '.docx'){throw 'Выберите имя с расширением DOCX.'}
  Assert-MedicalAccountPath $path
  Assert-MedicalCardOutputPath $path
  if($script:caseFile -and $path -ieq [IO.Path]::GetFullPath($script:caseFile)){throw 'Выберите имя, отличное от имени общей карты.'}
  if([IO.File]::Exists($path)){
   $archive=[IO.Compression.ZipFile]::OpenRead($path)
   try{
    $document=Get-XmlPart $archive 'word/document.xml'
    if($archive.GetEntry('customXml/mc-case.xml') -or ($document -and $document.DocumentElement.InnerText -match 'MC_CASE_V24:')){
     throw 'Выберите имя, отличное от имени существующей карты пациента.'
    }
   }finally{$archive.Dispose()}
  }
  if($stage -eq 'diary'){
   Export-MedicalDiariesDocument $path $true $entries
  }else{
   $temporary=Join-Path ([IO.Path]::GetDirectoryName($path)) ('mc-discharge-'+[guid]::NewGuid().ToString('N')+'.docx')
   Save-UniversalDocument $temporary $context.Schema $context.Values $context.DateTime $context.Details $true 'discharge'
   Set-MedicalDischargePeriodDocument $temporary $context.Schema
   if([IO.File]::Exists($path)){[IO.File]::Replace($temporary,$path,[NullString]::Value)}else{[IO.File]::Move($temporary,$path)}
  }
  [void][Windows.Forms.MessageBox]::Show($owner,'Документ сохранён.','Документы Word')
 }catch{[void][Windows.Forms.MessageBox]::Show($owner,$_.Exception.Message,'Сохранение документа')}
 finally{
  if($picker){$picker.Dispose()}
  if($temporary -and [IO.File]::Exists($temporary)){[IO.File]::Delete($temporary)}
 }
}
