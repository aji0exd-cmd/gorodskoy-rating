﻿# v72: a classic top menu invokes the same validated commands as the workspace.
function Initialize-MedicalMainMenuTypes {
 if('MedicalMenuCommandBridgeV72' -as [type]){return}
 Add-Type -ReferencedAssemblies 'System.Windows.Forms','System.Drawing' -TypeDefinition @'
using System;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
public static class MedicalMenuCommandBridgeV72 {
    private static readonly MethodInfo ClickMethod = typeof(Button).GetMethod("OnClick", BindingFlags.Instance | BindingFlags.NonPublic);
    public static bool Invoke(Button button) {
        if (button == null || button.IsDisposed || !button.Enabled) return false;
        try { ClickMethod.Invoke(button, new object[] { EventArgs.Empty }); return true; }
        catch (TargetInvocationException ex) { if (ex.InnerException != null) throw ex.InnerException; throw; }
    }
}
public class MedicalMenuColorsV72 : ProfessionalColorTable {
    public Color PanelColor { get; set; }
    public Color SelectedColor { get; set; }
    public Color BorderColor { get; set; }
    public MedicalMenuColorsV72(Color panel, Color selected, Color border) { PanelColor=panel; SelectedColor=selected; BorderColor=border; UseSystemColors=false; }
    public override Color ToolStripDropDownBackground { get { return PanelColor; } }
    public override Color ImageMarginGradientBegin { get { return PanelColor; } }
    public override Color ImageMarginGradientMiddle { get { return PanelColor; } }
    public override Color ImageMarginGradientEnd { get { return PanelColor; } }
    public override Color MenuItemSelected { get { return SelectedColor; } }
    public override Color MenuItemSelectedGradientBegin { get { return SelectedColor; } }
    public override Color MenuItemSelectedGradientEnd { get { return SelectedColor; } }
    public override Color MenuItemPressedGradientBegin { get { return SelectedColor; } }
    public override Color MenuItemPressedGradientMiddle { get { return SelectedColor; } }
    public override Color MenuItemPressedGradientEnd { get { return SelectedColor; } }
    public override Color MenuItemBorder { get { return BorderColor; } }
    public override Color MenuBorder { get { return BorderColor; } }
}
'@
}
function Invoke-MedicalMenuButton($button){
 # Button.PerformClick requires CanSelect and silently ignores a hidden command
 # host. OnClick preserves the existing single handler, enabled state and errors.
 return [MedicalMenuCommandBridgeV72]::Invoke($button)
}
function Get-MedicalFocusedEditTarget($owner){
 $current=$owner.ActiveControl
 for($i=0;$i -lt 32 -and $current -is [Windows.Forms.ContainerControl];$i++){
  if(-not $current.ActiveControl -or $current.ActiveControl -eq $current){break}
  $current=$current.ActiveControl
 }
 if($current -is [Windows.Forms.TextBoxBase] -and -not $current.IsDisposed){return $current}
 return $null
}
function Invoke-MedicalFocusedEdit($owner,[string]$action){
 $target=Get-MedicalFocusedEditTarget $owner
 if(-not $target){return}
 switch($action){
  'Undo' {if(-not $target.ReadOnly -and $target.CanUndo){$target.Undo()}}
  'Cut' {if(-not $target.ReadOnly -and $target.SelectionLength -gt 0){$target.Cut()}}
  'Copy' {if($target.SelectionLength -gt 0){$target.Copy()}}
  'Paste' {if(-not $target.ReadOnly){$target.Paste()}}
  'SelectAll' {$target.SelectAll()}
 }
}
function Set-MedicalMenuPalette($menu){
 if(-not $menu -or $menu.IsDisposed){return}
 $colors=New-Object MedicalMenuColorsV72($script:darkPanel,$script:uiSoft,$script:uiBorder)
 $menu.Renderer=New-Object Windows.Forms.ToolStripProfessionalRenderer($colors)
 $menu.BackColor=$script:darkPanel;$menu.ForeColor=$script:darkText
 $queue=New-Object 'System.Collections.Generic.Queue[object]'
 foreach($item in $menu.Items){$queue.Enqueue($item)}
 while($queue.Count -gt 0){
  $item=$queue.Dequeue();$item.BackColor=$script:darkPanel;$item.ForeColor=$script:darkText
  if($item -is [Windows.Forms.ToolStripMenuItem]){foreach($child in $item.DropDownItems){$queue.Enqueue($child)}}
 }
}
function Update-MedicalMainMenu {
 if(-not $script:medicalMenuItems){return}
 foreach($key in $script:medicalMenuButtons.Keys){
  $item=$script:medicalMenuItems[$key];$button=$script:medicalMenuButtons[$key]
  if($item -and $button){$item.Enabled=(-not $button.IsDisposed -and $button.Enabled)}
 }
 foreach($key in @('Export-diary','Export-discharge')){
  if($script:medicalMenuItems.ContainsKey($key)){$script:medicalMenuItems[$key].Enabled=[bool]$script:medicalClinicalForms}
 }
 $standalone=if($script:stage -eq $script:universalConfig.StandaloneStage){[string]$script:universalConfig.StandaloneStage}
 foreach($stageKey in @('initial','diary','discharge')){
  if($script:medicalMenuItems.ContainsKey($stageKey)){
   $script:medicalMenuItems[$stageKey].Checked=($script:stage -eq $stageKey)
   $script:medicalMenuItems[$stageKey].Available=(-not $standalone -or $stageKey -eq $standalone)
  }
 }
 foreach($key in @('SaveCard','Export','Preview','Print')){
  if($script:medicalMenuItems.ContainsKey($key)){$script:medicalMenuItems[$key].Available=(-not $standalone)}
 }
 foreach($key in @('diary','discharge')){
  $item=$script:medicalMenuItems['Export-'+$key]
  if($item){$item.Available=(-not $standalone -or $standalone -eq $key)}
 }
 for($index=0;$index -lt 3;$index++){
  $key='theme'+$index
  if($script:medicalMenuItems.ContainsKey($key)){$script:medicalMenuItems[$key].Checked=(@('light','dark','contrast')[$index] -eq $script:uiTheme)}
 }
 if($script:medicalMenuStageLabel){
  $caption=switch($script:stage){'diary' {'Дневники наблюдения'} 'discharge' {'Выписной эпикриз'} default {'Первичный осмотр'}}
  $script:medicalMenuStageLabel.Text=$caption
 }
}
function New-MedicalMainMenu($owner,[hashtable]$buttons,$themeControl){
 Initialize-MedicalMainMenuTypes
 $invokeButton=Get-Command Invoke-MedicalMenuButton -CommandType Function -ErrorAction Stop
 $invokeEdit=Get-Command Invoke-MedicalFocusedEdit -CommandType Function -ErrorAction Stop
 $editTarget=Get-Command Get-MedicalFocusedEditTarget -CommandType Function -ErrorAction Stop
 $update=Get-Command Update-MedicalMainMenu -CommandType Function -ErrorAction Stop
 $menu=New-Object Windows.Forms.MenuStrip
 $menu.Name='mc-main-menu';$menu.Dock='Fill';$menu.AutoSize=$true;$menu.Font=$owner.Font
 $menu.GripStyle='Hidden';$menu.CanOverflow=$true;$menu.Stretch=$true
 $menu.Margin=New-Object Windows.Forms.Padding(0);$menu.Padding=New-Object Windows.Forms.Padding(8,2,8,2)
 $items=@{};$script:medicalMenuItems=$items;$script:medicalMenuButtons=$buttons
 $newItem={param($parent,[string]$key,[string]$text,$button,[string]$shortcut='')
  $item=New-Object Windows.Forms.ToolStripMenuItem;$item.Name='mc-menu-'+$key;$item.Text=$text
  if($shortcut){$item.ShortcutKeys=[Windows.Forms.Keys]$shortcut}
  if($button){$buttonCommand=$invokeButton;$item.Add_Click({[void](& $buttonCommand $button)}.GetNewClosure())}
  [void]$parent.DropDownItems.Add($item);$items[$key]=$item;return $item
 }.GetNewClosure()
 $newGroup={param([string]$text)
  $group=New-Object Windows.Forms.ToolStripMenuItem;$group.Text=$text
  $updateCommand=$update;$group.Add_DropDownOpening({& $updateCommand}.GetNewClosure());[void]$menu.Items.Add($group);return $group
 }.GetNewClosure()
 $separator={param($parent)[void]$parent.DropDownItems.Add((New-Object Windows.Forms.ToolStripSeparator))}
 $file=& $newGroup 'Файл'
 $null=& $newItem $file 'OpenCard' 'Открыть карту или Word…' $buttons.OpenCard 'Control, O'
 & $separator $file
 $fastHistory=Get-Command Invoke-MedicalFastHistory -CommandType Function -ErrorAction Stop
 $fastHistoryItem=& $newItem $file 'FastHistory' 'Быстрая история болезни…' $null
 $fastHistoryItem.Add_Click({& $fastHistory $owner}.GetNewClosure())
 $fastForms=& $newItem $file 'FastHistoryForms' 'Шаблоны быстрых историй' $null
 $importFastWord=Get-Command Invoke-MedicalFastWordImport -CommandType Function -ErrorAction Stop
 $importFastWordItem=& $newItem $fastForms 'FastHistoryImportWord' 'Импортировать шаблон из Word…' $null
 $importFastWordItem.Add_Click({& $importFastWord $owner}.GetNewClosure())
 $newFastForm=Get-Command Invoke-MedicalNewForm -CommandType Function -ErrorAction Stop
 $newFastFormItem=& $newItem $fastForms 'FastHistoryNewForm' 'Создать форму для быстрой истории…' $null
 $newFastFormItem.Add_Click({& $newFastForm $true}.GetNewClosure())
 $editFastForms=Get-Command Show-MedicalFastTemplateSetup -CommandType Function -ErrorAction Stop
 $editFastFormsItem=& $newItem $fastForms 'FastHistoryEditForms' 'Настроить три шаблона открытой формы…' $null
 $editFastFormsItem.Add_Click({& $editFastForms $owner}.GetNewClosure())
 $registerFastForm=Get-Command Show-MedicalFastTemplateRegistration -CommandType Function -ErrorAction Stop
 $registerFastFormItem=& $newItem $fastForms 'FastHistoryRegisterForm' 'Добавить открытую форму в подбор…' $null
 $registerFastFormItem.Add_Click({& $registerFastForm $owner}.GetNewClosure())
 $quickCase=Get-Command Invoke-MedicalQuickCase -CommandType Function -ErrorAction Stop
 foreach($entry in @(@('case','Новая история болезни…'),@('diary','Новый отдельный дневник…'),@('discharge','Новый отдельный эпикриз…'))){
  $mode=[string]$entry[0]
  $item=& $newItem $file ('Quick-'+$mode) $entry[1] $null
  $item.Add_Click({& $quickCase $owner $mode}.GetNewClosure())
 }
 & $separator $file
 $null=& $newItem $file 'NewForm' 'Создать новую форму…' $buttons.NewForm 'Control, N'
 $null=& $newItem $file 'OpenForm' 'Открыть форму…' $buttons.OpenForm 'Control, Shift, O'
 $null=& $newItem $file 'SaveForm' 'Сохранить форму…' $buttons.SaveForm 'Control, Shift, S'
 & $separator $file
 $null=& $newItem $file 'SaveCard' 'Сохранить историю болезни…' $buttons.SaveCard 'Control, S'
 $null=& $newItem $file 'Export' 'Сохранить карту в Word…' $buttons.Export
 $exportSeparate=Get-Command Invoke-MedicalSeparateDocument -CommandType Function -ErrorAction Stop
 foreach($entry in @(@('diary','Сохранить дневники отдельно…'),@('discharge','Сохранить эпикриз отдельно…'))){
  $documentStage=[string]$entry[0]
  $item=& $newItem $file ('Export-'+$documentStage) $entry[1] $null
  $item.Add_Click({& $exportSeparate $owner $documentStage}.GetNewClosure())
 }
 $null=& $newItem $file 'Preview' 'Предпросмотр карты…' $buttons.Preview
 $null=& $newItem $file 'Print' 'Печать карты…' $buttons.Print 'Control, P'
 $null=& $newItem $file 'PreviewFile' 'Просмотреть файл…' $buttons.PreviewFile
 & $separator $file
 $exit=& $newItem $file 'Exit' 'Выход' $null
 $exit.Add_Click({$owner.Close()}.GetNewClosure())
 $edit=& $newGroup 'Правка'
 foreach($entry in @(@('Undo','Отменить ввод','Control, Z'),@('Cut','Вырезать','Control, X'),@('Copy','Копировать','Control, C'),@('Paste','Вставить','Control, V'),@('SelectAll','Выделить всё','Control, A'))){
  $action=[string]$entry[0];$item=& $newItem $edit $action $entry[1] $null
  # Text boxes already implement Ctrl+C/X/V/A/Z. Avoid a form-level shortcut
  # consuming a key before the focused native editor can handle it.
  $item.ShortcutKeyDisplayString=([string]$entry[2]).Replace('Control','Ctrl').Replace(', ','+')
  $item.Add_Click({& $invokeEdit $owner $action}.GetNewClosure())
 }
 $edit.Add_DropDownOpening({
  $target=& $editTarget $owner
  foreach($key in @('Undo','Cut','Copy','Paste','SelectAll')){
   $enabled=($null -ne $target)
   if($enabled -and $key -in @('Cut','Paste','Undo')){$enabled=(-not $target.ReadOnly)}
   if($enabled -and $key -in @('Cut','Copy')){$enabled=($target.SelectionLength -gt 0)}
   if($enabled -and $key -eq 'Undo'){$enabled=$target.CanUndo}
   $items[$key].Enabled=$enabled
  }
 }.GetNewClosure())
 & $separator $edit
 $null=& $newItem $edit 'TemplateEditor' 'Форма и шаблон Word…' $buttons.TemplateEditor
 $null=& $newItem $edit 'FieldSettings' 'Настройки полей…' $buttons.FieldSettings
 $text=& $newGroup 'Текст'
 $null=& $newItem $text 'Font' 'Шрифт и оформление документа…' $buttons.Font
 $assistant=Get-Command Invoke-MedicalLocalAssistant -CommandType Function -ErrorAction SilentlyContinue
 if($assistant){$item=& $newItem $text 'Assistant' 'Локальный ИИ: работа с текстом…' $null;$item.Add_Click({& $assistant $owner}.GetNewClosure())}
 $settings=& $newGroup 'Настройки'
 $folders=Get-Command Show-MedicalDocumentFolders -CommandType Function -ErrorAction Stop
 $folderItem=& $newItem $settings 'DocumentFolders' 'Папки документов…' $null
 $folderItem.Add_Click({& $folders $owner}.GetNewClosure())
 $fastTemplate=Get-Command Show-MedicalFastTemplateRegistration -CommandType Function -ErrorAction Stop
 $fastTemplateItem=& $newItem $settings 'FastHistoryTemplate' 'Сохранить шаблон быстрой истории…' $null
 $fastTemplateItem.Add_Click({& $fastTemplate $owner}.GetNewClosure())
 $themeMenu=& $newItem $settings 'Themes' 'Оформление интерфейса' $null
 $themeCaptions=@('Светлая клиническая','Тёмная графитовая','Высокая контрастность')
 for($i=0;$i -lt 3;$i++){
  $themeIndex=$i;$item=& $newItem $themeMenu ('theme'+$i) $themeCaptions[$i] $null
  $item.Add_Click({$themeControl.SelectedIndex=$themeIndex;& $update}.GetNewClosure())
 }
 if($script:medicalAuthSession){
  & $separator $settings
  $password=Get-Command Invoke-MedicalPasswordChangeAction -CommandType Function -ErrorAction Stop
  $item=& $newItem $settings 'Password' 'Изменить пароль…' $null;$item.Add_Click({& $password $owner}.GetNewClosure())
  if($script:medicalAuthSession.Role -ceq 'Administrator'){
   $manager=Get-Command Invoke-MedicalAccountsManagerAction -CommandType Function -ErrorAction Stop
   $item=& $newItem $settings 'Accounts' 'Управление сотрудниками…' $null;$item.Add_Click({& $manager $owner}.GetNewClosure())
  }
  $lock=Get-Command Invoke-MedicalAccountLock -CommandType Function -ErrorAction Stop
  $item=& $newItem $settings 'Lock' 'Заблокировать программу' $null;$item.Add_Click({& $lock $owner}.GetNewClosure())
 }
 $view=& $newGroup 'Вид'
 foreach($entry in @(@('initial','Первичный осмотр'),@('diary','Дневники наблюдения'),@('discharge','Выписной эпикриз'))){$null=& $newItem $view $entry[0] $entry[1] $buttons[$entry[0]]}
 $service=& $newGroup 'Сервис'
 $null=& $newItem $service 'Templates' 'Выбрать Word-шаблон…' $buttons.Templates
 $recognize=Get-Command Invoke-MedicalDocumentRecognition -CommandType Function -ErrorAction SilentlyContinue
 if($recognize){$item=& $newItem $service 'Recognize' 'Распознать Word, PDF или изображение…' $null;$item.Add_Click({& $recognize $owner}.GetNewClosure())}
 $aiSettings=Get-Command Show-MedicalAiSettings -CommandType Function -ErrorAction SilentlyContinue
 if($aiSettings){$item=& $newItem $service 'AiSettings' 'Настройки локального ИИ…' $null;$item.Add_Click({& $aiSettings $owner}.GetNewClosure())}
 $help=& $newGroup 'Справка'
 $instruction=Join-Path $PSScriptRoot 'Инструкция.txt'
 $item=& $newItem $help 'Help' 'Инструкция…' $null 'F1'
 $item.Add_Click({if([IO.File]::Exists($instruction)){[void][Diagnostics.Process]::Start('notepad.exe',('"'+$instruction+'"'))}else{[void][Windows.Forms.MessageBox]::Show($owner,'Инструкция не найдена в папке программы.','Справка')}}.GetNewClosure())
 $about=& $newItem $help 'About' 'О программе…' $null
 $about.Add_Click({[void][Windows.Forms.MessageBox]::Show($owner,"Медицинский конструктор v73`r`nФормы, Word-шаблоны и карты госпитализации.`r`nЛокальная обработка документов и отдельные учётные записи сотрудников.",'О программе')}.GetNewClosure())
 $menu.Add_MenuActivate({& $update}.GetNewClosure())
 $script:medicalMainMenu=$menu
 & $update
 Set-MedicalMenuPalette $menu
 return $menu
}
