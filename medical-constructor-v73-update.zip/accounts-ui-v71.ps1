﻿# v71: local account dialogs. Authentication and authorization are enforced by accounts-core.
# No passwords are stored by these dialogs; native password boxes are cleared before disposal.

function New-MedicalAccountsUiDialog([string]$title,[int]$width=560,[int]$height=420){
 $dialog=New-Object Windows.Forms.Form
 $dialog.Text=$title;$dialog.StartPosition='CenterParent';$dialog.AutoScaleMode='Font'
 $dialog.Font=New-Object Drawing.Font('Segoe UI',10)
 $dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false
 $dialog.ShowInTaskbar=$false;$dialog.ClientSize=New-Object Drawing.Size($width,$height)
 return $dialog
}

function Show-MedicalAccountEntryDialog {
 param($Owner,$Context,$Session,[ValidateSet('FirstAdministrator','Login','Create','OwnPassword','ResetPassword','Lock')][string]$Mode,
       [string]$TargetUserId='',[string]$TargetDisplayName='')
 # FunctionInfo values survive the private WinForms event closure scope in Windows PowerShell 5.1.
 $commands=@{}
 foreach($name in @('New-MedicalFirstAdministrator','Invoke-MedicalAccountLogin','New-MedicalUserAccount','Set-MedicalOwnPassword','Reset-MedicalAccountPassword','Get-MedicalLoginAccounts','Get-MedicalLoginPreference','Save-MedicalLoginPreference')){
  $commands[$name]=Get-Command $name -CommandType Function -ErrorAction Stop
 }
 $newDialogCommand=Get-Command New-MedicalAccountsUiDialog -CommandType Function -ErrorAction Stop
 $title='Вход в медицинский конструктор';$intro='Выберите сотрудника из списка и введите пароль локальной учетной записи.';$buttonText='Войти'
 switch($Mode){
  'FirstAdministrator'{$title='Создать администратора';$intro='Создайте первую учетную запись администратора. Пароль — не менее 4 символов.';$buttonText='Создать и войти'}
  'Create'{$title='Добавить сотрудника';$intro='Создайте отдельную учетную запись сотрудника. Пароль — не менее 4 символов.';$buttonText='Создать'}
  'OwnPassword'{$title='Изменить мой пароль';$intro='Введите действующий пароль и новый пароль длиной не менее 4 символов.';$buttonText='Сохранить пароль'}
  'ResetPassword'{$title='Сбросить пароль сотрудника';$intro='Укажите новый пароль для сотрудника: '+$TargetDisplayName+'. После сброса потребуется войти заново.';$buttonText='Сбросить пароль'}
  'Lock'{$title='Программа заблокирована';$intro='Чтобы продолжить работу, введите пароль своей учетной записи. После закрытия данные можно восстановить из резервного сохранения.';$buttonText='Разблокировать'}
 }
 $askUsername=$Mode -in @('FirstAdministrator','Create','Lock')
 $askLogin=$Mode -eq 'Login'
 $askDisplay=$Mode -in @('FirstAdministrator','Create')
 $askCurrent=$Mode -eq 'OwnPassword'
 $askConfirm=$Mode -in @('FirstAdministrator','Create','OwnPassword','ResetPassword')
 $askRole=$Mode -eq 'Create'
 $fieldCount=1+[int]$askUsername+[int]$askLogin+[int]$askDisplay+[int]$askCurrent+[int]$askConfirm+[int]$askRole
 $startup=$Mode -in @('Login','FirstAdministrator')
 $headerHeight=if($startup){96}elseif($Mode -eq 'ResetPassword'){96}else{64}
 $dialog=& $newDialogCommand $title 570 (138+$headerHeight+42*$fieldCount)
 $layout=New-Object Windows.Forms.TableLayoutPanel;$layout.Dock='Fill';$layout.Padding=New-Object Windows.Forms.Padding(14)
 if(-not $Owner){$dialog.StartPosition='CenterScreen';$dialog.ShowInTaskbar=$true}
 if($startup){
  $layout.Padding=New-Object Windows.Forms.Padding(24)
  $layout.BackColor=[Drawing.Color]::FromArgb(245,248,250)
  $layout.ForeColor=[Drawing.Color]::FromArgb(26,43,53)
 }
 $layout.ColumnCount=2;$layout.RowCount=$fieldCount+3
 [void]$layout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',37)))
 [void]$layout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',63)))
 [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',$headerHeight)))
 for($i=0;$i -lt $fieldCount;$i++){[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',42)))}
 [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)))
 [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',42)))
 $header=New-Object Windows.Forms.Label;$header.Text=$intro;$header.Dock='Fill'
 if($startup){
  $banner=New-Object Windows.Forms.Panel
  $banner.Dock='Fill';$banner.BackColor=[Drawing.Color]::FromArgb(22,79,91)
  $banner.Margin=New-Object Windows.Forms.Padding(0,0,0,10)
  $brand=New-Object Windows.Forms.Label
  $brand.Text='Медицинский конструктор';$brand.SetBounds(16,9,474,29)
  $brand.Font=New-Object Drawing.Font('Segoe UI',15,[Drawing.FontStyle]::Bold)
  $brand.ForeColor=[Drawing.Color]::White
  $header.Dock='None';$header.SetBounds(17,41,474,42)
  $header.ForeColor=[Drawing.Color]::FromArgb(227,242,245)
  $banner.Controls.Add($brand);$banner.Controls.Add($header)
  [void]$layout.Controls.Add($banner,0,0);$layout.SetColumnSpan($banner,2)
 }else{[void]$layout.Controls.Add($header,0,0);$layout.SetColumnSpan($header,2)}
 $row=1;$boxes=@{};$passwordBoxes=New-Object 'Collections.Generic.List[object]'
 $loginPicker=$null
 if($askLogin){
  $loginAccounts=@(& $commands['Get-MedicalLoginAccounts'] -Context $Context)
  if($loginAccounts.Count -lt 1){throw 'Нет доступных сотрудников для входа.'}
  $preferredId=[string](& $commands['Get-MedicalLoginPreference'] -Context $Context)
  $loginLabel=New-Object Windows.Forms.Label;$loginLabel.Text='Сотрудник';$loginLabel.Dock='Fill';$loginLabel.TextAlign='MiddleLeft'
  $loginPicker=New-Object Windows.Forms.ComboBox;$loginPicker.Dock='Fill';$loginPicker.Margin=New-Object Windows.Forms.Padding(3,6,3,3)
  $loginPicker.DropDownStyle='DropDownList';$loginPicker.DisplayMember='Label';$loginPicker.MaxDropDownItems=12
  $selectedIndex=0
  foreach($account in $loginAccounts){
   $index=$loginPicker.Items.Add([pscustomobject]@{Label=([string]$account.DisplayName+' ('+[string]$account.Username+')');Id=[string]$account.Id;Username=[string]$account.Username;DisplayName=[string]$account.DisplayName})
   if([string]$account.Id -ceq $preferredId){$selectedIndex=$index}
  }
  $loginPicker.SelectedIndex=$selectedIndex
  [void]$layout.Controls.Add($loginLabel,0,$row);[void]$layout.Controls.Add($loginPicker,1,$row);$row++
 }
 $fields=New-Object 'Collections.Generic.List[object]'
 if($askUsername){[void]$fields.Add(@('Username','Имя пользователя',$false))}
 if($askDisplay){[void]$fields.Add(@('DisplayName','Имя сотрудника',$false))}
 if($askCurrent){[void]$fields.Add(@('CurrentPassword','Текущий пароль',$true))}
 [void]$fields.Add(@('Password',$(if($Mode -in @('OwnPassword','ResetPassword')){'Новый пароль'}else{'Пароль'}),$true))
 if($askConfirm){[void]$fields.Add(@('ConfirmPassword','Повторите пароль',$true))}
 foreach($field in $fields){
  $label=New-Object Windows.Forms.Label;$label.Text=[string]$field[1];$label.Dock='Fill';$label.TextAlign='MiddleLeft'
  $box=New-Object Windows.Forms.TextBox;$box.Dock='Fill';$box.Margin=New-Object Windows.Forms.Padding(3,6,3,3)
  $box.MaxLength=if([bool]$field[2]){1024}else{120}
  if([bool]$field[2]){$box.UseSystemPasswordChar=$true;[void]$passwordBoxes.Add($box)}
  $boxes[[string]$field[0]]=$box
  [void]$layout.Controls.Add($label,0,$row);[void]$layout.Controls.Add($box,1,$row);$row++
 }
 if($Mode -eq 'Lock'){$boxes.Username.Text=[string]$Session.Username;$boxes.Username.ReadOnly=$true;$boxes.Username.TabStop=$false}
 $roleBox=$null
 if($askRole){
  $roleLabel=New-Object Windows.Forms.Label;$roleLabel.Text='Права доступа';$roleLabel.Dock='Fill';$roleLabel.TextAlign='MiddleLeft'
  $roleBox=New-Object Windows.Forms.ComboBox;$roleBox.Dock='Fill';$roleBox.DropDownStyle='DropDownList'
  [void]$roleBox.Items.Add('Пользователь');[void]$roleBox.Items.Add('Администратор');$roleBox.SelectedIndex=0
  [void]$layout.Controls.Add($roleLabel,0,$row);[void]$layout.Controls.Add($roleBox,1,$row);$row++
 }
 $errorLabel=New-Object Windows.Forms.Label;$errorLabel.Dock='Fill';$errorLabel.ForeColor=[Drawing.Color]::Firebrick
 $errorLabel.Padding=New-Object Windows.Forms.Padding(0,6,0,0)
 [void]$layout.Controls.Add($errorLabel,0,$row);$layout.SetColumnSpan($errorLabel,2);$row++
 $buttons=New-Object Windows.Forms.FlowLayoutPanel;$buttons.Dock='Fill';$buttons.FlowDirection='RightToLeft';$buttons.WrapContents=$false
 $cancel=New-Object Windows.Forms.Button;$cancel.Text=if($Mode -eq 'Lock'){'Закрыть программу'}else{'Отмена'};$cancel.Width=if($Mode -eq 'Lock'){190}else{110};$cancel.Height=32;$cancel.DialogResult='Cancel'
 $submit=New-Object Windows.Forms.Button;$submit.Text=$buttonText;$submit.Width=190;$submit.Height=32
 if($startup){
  $submit.FlatStyle='Flat';$submit.FlatAppearance.BorderSize=0
  $submit.BackColor=[Drawing.Color]::FromArgb(22,79,91);$submit.ForeColor=[Drawing.Color]::White
  $cancel.FlatStyle='Flat';$cancel.FlatAppearance.BorderColor=[Drawing.Color]::FromArgb(159,176,183)
  $cancel.BackColor=[Drawing.Color]::White
 }
 [void]$buttons.Controls.Add($cancel);[void]$buttons.Controls.Add($submit)
 [void]$layout.Controls.Add($buttons,0,$row);$layout.SetColumnSpan($buttons,2)
 [void]$dialog.Controls.Add($layout);$dialog.AcceptButton=$submit;$dialog.CancelButton=$cancel
 $state=@{Result=$null;Busy=$false}
 if($askLogin){
  $loginPicker.Add_SelectedIndexChanged({$boxes.Password.Clear();$errorLabel.Text='';[void]$boxes.Password.Focus()}.GetNewClosure())
 }
 $submit.Add_Click({
  if($state.Busy){return}
  $state.Busy=$true;$submit.Enabled=$false;$errorLabel.Text=''
  try{
   if($askConfirm){
    if($boxes.Password.Text.Length -lt 4){throw 'Пароль должен содержать не менее 4 символов.'}
    if($boxes.Password.Text -cne $boxes.ConfirmPassword.Text){throw 'Новый пароль и его повтор не совпадают.'}
   }
   switch($Mode){
    'FirstAdministrator'{$state.Result=& $commands['New-MedicalFirstAdministrator'] -Context $Context -Username $boxes.Username.Text -DisplayName $boxes.DisplayName.Text -Password $boxes.Password.Text}
    'Login'{
     $selectedAccount=$loginPicker.SelectedItem
     if($null -eq $selectedAccount -or [string]::IsNullOrWhiteSpace([string]$selectedAccount.Username)){throw 'Выберите сотрудника из списка.'}
     $state.Result=& $commands['Invoke-MedicalAccountLogin'] -Context $Context -Username ([string]$selectedAccount.Username) -Password $boxes.Password.Text
    }
    'Lock'{
     $candidate=& $commands['Invoke-MedicalAccountLogin'] -Context $Session.Context -Username $Session.Username -Password $boxes.Password.Text
     if(-not $candidate -or [string]$candidate.UserId -cne [string]$Session.UserId){throw 'Не удалось разблокировать программу. Повторите вход.'}
     $state.Result=$candidate
    }
    'Create'{
     $role=if($roleBox.SelectedIndex -eq 1){'Administrator'}else{'User'}
     $state.Result=& $commands['New-MedicalUserAccount'] -Session $Session -Username $boxes.Username.Text -DisplayName $boxes.DisplayName.Text -Password $boxes.Password.Text -Role $role
     # A core implementation may return no account record after a successful write.
     if($null -eq $state.Result){$state.Result=$true}
    }
    'OwnPassword'{$state.Result=& $commands['Set-MedicalOwnPassword'] -Session $Session -CurrentPassword $boxes.CurrentPassword.Text -NewPassword $boxes.Password.Text}
    'ResetPassword'{
     [void](& $commands['Reset-MedicalAccountPassword'] -Session $Session -UserId $TargetUserId -NewPassword $boxes.Password.Text)
     $state.Result=$true
    }
   }
   if($null -eq $state.Result){throw 'Не удалось завершить действие. Повторите попытку.'}
   if($Mode -in @('Login','FirstAdministrator')){
    # Preferences are optional: an unwritable preference must not reject a valid login.
    try{[void](& $commands['Save-MedicalLoginPreference'] -Session $state.Result)}catch{}
   }
   $dialog.DialogResult='OK';$dialog.Close()
  }catch{
   $state.Result=$null;$errorLabel.Text=$_.Exception.Message
   foreach($passwordBox in $passwordBoxes){$passwordBox.Clear()}
   if($askCurrent){[void]$boxes.CurrentPassword.Focus()}else{[void]$boxes.Password.Focus()}
  }finally{$state.Busy=$false;$submit.Enabled=$true}
 }.GetNewClosure())
 $dialog.Add_Shown({
  if($askUsername -and $Mode -ne 'Lock'){[void]$boxes.Username.Focus()}
  elseif($askCurrent){[void]$boxes.CurrentPassword.Focus()}else{[void]$boxes.Password.Focus()}
 }.GetNewClosure())
 try{if($Owner){[void]$dialog.ShowDialog($Owner)}else{[void]$dialog.ShowDialog()};return $state.Result}
 finally{foreach($passwordBox in $passwordBoxes){$passwordBox.Clear()};$state.Result=$null;$dialog.Dispose()}
}

function Show-MedicalLogin {
 param($Owner,$Context)
 try{
  $state=Get-MedicalAccountsState -Context $Context
  $mode=if($state.IsInitialized){'Login'}else{'FirstAdministrator'}
  return (Show-MedicalAccountEntryDialog -Owner $Owner -Context $Context -Mode $mode)
 }catch{
  [void][Windows.Forms.MessageBox]::Show($Owner,$_.Exception.Message,'Локальные учетные записи','OK','Error')
  return $null
 }
}

function Show-MedicalPasswordChange {
 param($Owner,$Session)
 return (Show-MedicalAccountEntryDialog -Owner $Owner -Session $Session -Mode OwnPassword)
}

function Show-MedicalLockScreen {
 param($Owner,$Session)
 # Caller keeps the working window hidden/disabled until a non-null session is returned.
 return (Show-MedicalAccountEntryDialog -Owner $Owner -Session $Session -Mode Lock)
}

function Show-MedicalAccountRoleDialog {
 param($Owner,$Account)
 $dialog=New-MedicalAccountsUiDialog 'Изменить права сотрудника' 520 214
 $layout=New-Object Windows.Forms.TableLayoutPanel;$layout.Dock='Fill';$layout.Padding=New-Object Windows.Forms.Padding(14)
 $layout.ColumnCount=1;$layout.RowCount=3
 [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)))
 [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',42)))
 [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',42)))
 $label=New-Object Windows.Forms.Label;$label.Dock='Fill';$label.Text='Права доступа: '+[string]$Account.DisplayName+' ('+[string]$Account.Username+')'
 $roleBox=New-Object Windows.Forms.ComboBox;$roleBox.Dock='Fill';$roleBox.DropDownStyle='DropDownList'
 [void]$roleBox.Items.Add('Пользователь');[void]$roleBox.Items.Add('Администратор')
 $roleBox.SelectedIndex=if($Account.Role -eq 'Administrator'){1}else{0}
 $buttons=New-Object Windows.Forms.FlowLayoutPanel;$buttons.Dock='Fill';$buttons.FlowDirection='RightToLeft'
 $cancel=New-Object Windows.Forms.Button;$cancel.Text='Отмена';$cancel.Width=110;$cancel.Height=32;$cancel.DialogResult='Cancel'
 $save=New-Object Windows.Forms.Button;$save.Text='Сохранить';$save.Width=130;$save.Height=32
 [void]$buttons.Controls.Add($cancel);[void]$buttons.Controls.Add($save)
 [void]$layout.Controls.Add($label,0,0);[void]$layout.Controls.Add($roleBox,0,1);[void]$layout.Controls.Add($buttons,0,2)
 [void]$dialog.Controls.Add($layout);$dialog.AcceptButton=$save;$dialog.CancelButton=$cancel
 $state=@{Role=$null}
 $save.Add_Click({$state.Role=if($roleBox.SelectedIndex -eq 1){'Administrator'}else{'User'};$dialog.DialogResult='OK';$dialog.Close()}.GetNewClosure())
 try{[void]$dialog.ShowDialog($Owner);return $state.Role}finally{$dialog.Dispose()}
}

function Show-MedicalAccountManager {
 param($Owner,$Session)
 $commands=@{}
 foreach($name in @('Assert-MedicalAdministrator','Get-MedicalAccounts','Set-MedicalAccountEnabled','Set-MedicalAccountRole','Test-MedicalSession','Show-MedicalAccountEntryDialog','Show-MedicalPasswordChange','Show-MedicalAccountRoleDialog')){
  $commands[$name]=Get-Command $name -CommandType Function -ErrorAction Stop
 }
 [void](& $commands['Assert-MedicalAdministrator'] -Session $Session)
 $dialog=New-MedicalAccountsUiDialog 'Сотрудники и права доступа' 960 590
 $dialog.FormBorderStyle='Sizable';$dialog.MaximizeBox=$true;$dialog.MinimumSize=New-Object Drawing.Size(780,510)
 $layout=New-Object Windows.Forms.TableLayoutPanel;$layout.Dock='Fill';$layout.Padding=New-Object Windows.Forms.Padding(12)
 $layout.ColumnCount=1;$layout.RowCount=4
 foreach($height in @(56,0,88,44)){
  if($height -eq 0){[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)))}
  else{[void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',$height)))}
 }
 $description=New-Object Windows.Forms.Label;$description.Dock='Fill'
 $description.Text='Администратор управляет сотрудниками и их правами. У каждого сотрудника отдельные рабочие данные и пароль.'
 $grid=New-Object Windows.Forms.DataGridView;$grid.Dock='Fill';$grid.ReadOnly=$true;$grid.MultiSelect=$false
 $grid.SelectionMode='FullRowSelect';$grid.AllowUserToAddRows=$false;$grid.AllowUserToDeleteRows=$false
 $grid.AllowUserToResizeRows=$false;$grid.RowHeadersVisible=$false;$grid.AutoGenerateColumns=$false
 foreach($spec in @(@('Username','Имя пользователя',25),@('DisplayName','Сотрудник',35),@('Role','Права',22),@('Enabled','Доступ',18))){
  $column=New-Object Windows.Forms.DataGridViewTextBoxColumn;$column.Name=[string]$spec[0];$column.HeaderText=[string]$spec[1]
  $column.AutoSizeMode='Fill';$column.FillWeight=[single]$spec[2];$column.SortMode='NotSortable';[void]$grid.Columns.Add($column)
 }
 $actions=New-Object Windows.Forms.FlowLayoutPanel;$actions.Dock='Fill';$actions.WrapContents=$true;$actions.AutoScroll=$true
 $buttons=@{}
 foreach($spec in @(@('Create','Добавить сотрудника',180),@('Enabled','Отключить',130),@('Role','Изменить права',150),@('Reset','Сбросить пароль',160),@('Own','Мой пароль',140))){
  $button=New-Object Windows.Forms.Button;$button.Text=[string]$spec[1];$button.Width=[int]$spec[2];$button.Height=34
  $buttons[[string]$spec[0]]=$button;[void]$actions.Controls.Add($button)
 }
 $footer=New-Object Windows.Forms.FlowLayoutPanel;$footer.Dock='Fill';$footer.FlowDirection='RightToLeft'
 $close=New-Object Windows.Forms.Button;$close.Text='Закрыть';$close.Width=120;$close.Height=32;$close.DialogResult='Cancel'
 [void]$footer.Controls.Add($close)
 [void]$layout.Controls.Add($description,0,0);[void]$layout.Controls.Add($grid,0,1);[void]$layout.Controls.Add($actions,0,2);[void]$layout.Controls.Add($footer,0,3)
 [void]$dialog.Controls.Add($layout);$dialog.CancelButton=$close
 $state=@{Session=$Session;Selected=$null;Busy=$false;Ready=$false}
 $select={
  $state.Selected=$null
  if($grid.SelectedRows.Count -gt 0){$state.Selected=$grid.SelectedRows[0].Tag}
  foreach($key in @('Enabled','Role','Reset')){$buttons[$key].Enabled=$null -ne $state.Selected}
  if($state.Selected){$buttons.Enabled.Text=if([bool]$state.Selected.Enabled){'Отключить'}else{'Включить'}}
 }.GetNewClosure()
 $refresh={
  if(-not (& $commands['Test-MedicalSession'] -Session $state.Session)){$state.Session=$null;$dialog.Close();return}
  if([string]$state.Session.Role -ne 'Administrator'){$dialog.Close();return}
  $previousId=if($state.Selected){[string]$state.Selected.Id}else{''}
  $accounts=@(& $commands['Get-MedicalAccounts'] -Session $state.Session)
  $grid.Rows.Clear();$selectedRow=$null
  foreach($account in @($accounts | Sort-Object Username)){
   $index=$grid.Rows.Add([object[]]@([string]$account.Username,[string]$account.DisplayName,$(if($account.Role -eq 'Administrator'){'Администратор'}else{'Пользователь'}),$(if($account.Enabled){'Включен'}else{'Отключен'})))
   $grid.Rows[$index].Tag=$account
   if([string]$account.Id -ceq $previousId){$selectedRow=$grid.Rows[$index]}
  }
  if($selectedRow){$grid.ClearSelection();$selectedRow.Selected=$true;$grid.CurrentCell=$selectedRow.Cells[0]}
  & $select
 }.GetNewClosure()
 $grid.Add_SelectionChanged($select)
 $buttons.Create.Add_Click({
  if($state.Busy){return};$state.Busy=$true
  try{[void](& $commands['Show-MedicalAccountEntryDialog'] -Owner $dialog -Session $state.Session -Mode Create);& $refresh}
  catch{[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Сотрудники','OK','Warning')}
  finally{$state.Busy=$false}
 }.GetNewClosure())
 $buttons.Enabled.Add_Click({
  if($state.Busy -or -not $state.Selected){return};$state.Busy=$true
  try{[void](& $commands['Set-MedicalAccountEnabled'] -Session $state.Session -UserId $state.Selected.Id -Enabled (-not [bool]$state.Selected.Enabled));& $refresh}
  catch{[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Права доступа','OK','Warning')}
  finally{$state.Busy=$false}
 }.GetNewClosure())
 $buttons.Role.Add_Click({
  if($state.Busy -or -not $state.Selected){return};$state.Busy=$true
  try{
   $role=& $commands['Show-MedicalAccountRoleDialog'] -Owner $dialog -Account $state.Selected
   if($role){[void](& $commands['Set-MedicalAccountRole'] -Session $state.Session -UserId $state.Selected.Id -Role $role);& $refresh}
  }catch{[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Права доступа','OK','Warning')}
  finally{$state.Busy=$false}
 }.GetNewClosure())
 $buttons.Reset.Add_Click({
  if($state.Busy -or -not $state.Selected){return};$state.Busy=$true
  try{
   if([string]$state.Selected.Id -ceq [string]$state.Session.UserId){
    $renewed=& $commands['Show-MedicalPasswordChange'] -Owner $dialog -Session $state.Session
    if($renewed){$state.Session=$renewed}
   }else{[void](& $commands['Show-MedicalAccountEntryDialog'] -Owner $dialog -Session $state.Session -Mode ResetPassword -TargetUserId $state.Selected.Id -TargetDisplayName $state.Selected.DisplayName)}
   & $refresh
  }catch{[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Пароль сотрудника','OK','Warning')}
  finally{$state.Busy=$false}
 }.GetNewClosure())
 $buttons.Own.Add_Click({
  if($state.Busy){return};$state.Busy=$true
  try{
   $renewed=& $commands['Show-MedicalPasswordChange'] -Owner $dialog -Session $state.Session
   if($renewed){$state.Session=$renewed}
   & $refresh
  }catch{[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Мой пароль','OK','Warning')}
  finally{$state.Busy=$false}
 }.GetNewClosure())
 $dialog.Add_Shown({
  try{& $refresh;$state.Ready=$true}
  catch{[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Сотрудники','OK','Error');$dialog.Close()}
 }.GetNewClosure())
 try{[void]$dialog.ShowDialog($Owner);return $state.Session}finally{$dialog.Dispose()}
}
