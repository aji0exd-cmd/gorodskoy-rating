﻿function Get-MedicalDocumentFolderDefaults {
 $workspace=$script:medicalAccountWorkspace
 return [pscustomobject]@{
  Save=$workspace.CardsRoot
  Open=(Join-Path $workspace.DataRoot 'Входящие')
 }
}

function Get-MedicalDocumentFolder([ValidateSet('Save','Open')][string]$kind){
 if(-not $script:medicalAccountWorkspace){return [string]$script:medicalProgramRoot}
 $selected=[string]$script:medicalDocumentFolders.$kind
 if($selected -and [IO.Directory]::Exists($selected)){
  Assert-MedicalAccountPath $selected
  return $selected
 }
 $defaults=Get-MedicalDocumentFolderDefaults
 $fallback=[string]$defaults.$kind
 Assert-MedicalAccountPath $fallback
 [void][IO.Directory]::CreateDirectory($fallback)
 return $fallback
}

function Resolve-MedicalDocumentFolder([string]$value){
 if([string]::IsNullOrWhiteSpace($value)){throw 'Укажите папку.'}
 if(-not [IO.Path]::IsPathRooted($value)){$value=Join-Path $script:medicalAccountWorkspace.DataRoot $value}
 $path=[IO.Path]::GetFullPath($value)
 Assert-MedicalAccountPath $path
 if(-not [IO.Directory]::Exists($path)){throw ('Папка недоступна: '+$path)}
 return $path
}

function Save-MedicalDocumentFolders([string]$save,[string]$open){
 $active=[pscustomobject]@{Save=(Resolve-MedicalDocumentFolder $save);Open=(Resolve-MedicalDocumentFolder $open)}
 $root=$script:medicalAccountWorkspace.DataRoot
 $record=[ordered]@{Version=1}
 foreach($kind in @('Save','Open')){
  $path=[string]$active.$kind
  $record[$kind]=if($path -ieq $root){'.'}elseif(Test-MedicalAccountPathInside $path $root){$path.Substring($root.Length+1)}else{$path}
 }
 $settings=Join-Path $root 'document-folders.json'
 $temporary=Join-Path $root ('document-folders-'+[guid]::NewGuid().ToString('N')+'.tmp')
 Assert-MedicalAccountPath $settings
 try{
  [IO.File]::WriteAllText($temporary,($record | ConvertTo-Json -Compress),[Text.UTF8Encoding]::new($true))
  if([IO.File]::Exists($settings)){[IO.File]::Replace($temporary,$settings,[NullString]::Value)}else{[IO.File]::Move($temporary,$settings)}
 }finally{if([IO.File]::Exists($temporary)){[IO.File]::Delete($temporary)}}
 $script:medicalDocumentFolders=$active
}

function Show-MedicalDocumentFolders($owner){
 $dialog=New-MedicalAccountsUiDialog 'Папки документов' 670 270
 if(-not $owner){$dialog.StartPosition='CenterScreen';$dialog.ShowInTaskbar=$true}
 $hint=New-Object Windows.Forms.Label
 $hint.Text='Укажите, где сохранять документы и откуда открывать карты, формы и шаблоны.'
 $hint.SetBounds(18,18,632,42);$dialog.Controls.Add($hint)
 $boxes=@{}
 $row=65
 foreach($entry in @(@('Save','Папка для сохранения'),@('Open','Папка для открытия и импорта'))){
  $label=New-Object Windows.Forms.Label
  $label.Text=$entry[1];$label.SetBounds(18,$row,630,24);$dialog.Controls.Add($label)
  $box=New-Object Windows.Forms.TextBox
  $box.Text=Get-MedicalDocumentFolder $entry[0]
  $box.SetBounds(18,($row+24),515,28);$dialog.Controls.Add($box)
  $boxes[$entry[0]]=$box
  $choose=New-Object Windows.Forms.Button
  $choose.Text='Обзор…';$choose.SetBounds(545,($row+23),106,28);$choose.Tag=$box
  $choose.Add_Click({
   $picker=New-Object Windows.Forms.FolderBrowserDialog
   $picker.Description='Выберите папку документов'
   $picker.ShowNewFolderButton=$true
   if([IO.Directory]::Exists($this.Tag.Text)){$picker.SelectedPath=$this.Tag.Text}
   try{if($picker.ShowDialog($this.FindForm()) -eq 'OK'){$this.Tag.Text=$picker.SelectedPath}}finally{$picker.Dispose()}
  })
  $dialog.Controls.Add($choose)
  $row+=68
 }
 $save=New-Object Windows.Forms.Button
 $save.Text='Сохранить';$save.SetBounds(398,218,123,34);$dialog.Controls.Add($save);$dialog.AcceptButton=$save
 $cancel=New-Object Windows.Forms.Button
 $cancel.Text='Позже';$cancel.DialogResult='Cancel';$cancel.SetBounds(530,218,121,34);$dialog.Controls.Add($cancel);$dialog.CancelButton=$cancel
 $command=Get-Command Save-MedicalDocumentFolders -CommandType Function -ErrorAction Stop
 $save.Add_Click({
  try{& $command $boxes.Save.Text $boxes.Open.Text;$dialog.DialogResult='OK'}
  catch{[void][Windows.Forms.MessageBox]::Show($dialog,$_.Exception.Message,'Папки документов')}
 }.GetNewClosure())
 try{if($owner){[void]$dialog.ShowDialog($owner)}else{[void]$dialog.ShowDialog()}}finally{$dialog.Dispose()}
}

function Initialize-MedicalDocumentFolders {
 $script:medicalDocumentFolders=$null
 $settings=Join-Path $script:medicalAccountWorkspace.DataRoot 'document-folders.json'
 Assert-MedicalAccountPath $settings
 if([IO.File]::Exists($settings)){
  try{
   $record=[IO.File]::ReadAllText($settings) | ConvertFrom-Json
   if($record.Version -eq 1){
    $script:medicalDocumentFolders=[pscustomobject]@{
     Save=(Resolve-MedicalDocumentFolder ([string]$record.Save))
     Open=(Resolve-MedicalDocumentFolder ([string]$record.Open))
    }
    return
   }
  }catch{}
 }
 Show-MedicalDocumentFolders $null
}
