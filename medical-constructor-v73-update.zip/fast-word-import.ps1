﻿function Get-MedicalFastWordText($node,$namespaces){
 return (($node.SelectNodes('.//w:t',$namespaces) | ForEach-Object {$_.InnerText}) -join '')
}

function Set-MedicalFastWordParagraph($paragraph,$namespaces,[string]$text){
 $xml=$paragraph.OwnerDocument
 $format=$paragraph.SelectSingleNode('.//w:r/w:rPr',$namespaces)
 foreach($child in @($paragraph.ChildNodes)){
  if($child.LocalName -ne 'pPr'){[void]$paragraph.RemoveChild($child)}
 }
 $run=$xml.CreateElement('w','r',$script:ns)
 if($format){[void]$run.AppendChild($format.CloneNode($true))}
 $value=$xml.CreateElement('w','t',$script:ns)
 Set-UniversalTextNode $value $text
 [void]$run.AppendChild($value)
 [void]$paragraph.AppendChild($run)
}

function Add-MedicalFastWordParagraph($body,$before,$namespaces,[string]$text){
 $paragraph=$body.OwnerDocument.CreateElement('w','p',$script:ns)
 Set-MedicalFastWordParagraph $paragraph $namespaces $text
 [void]$body.InsertBefore($paragraph,$before)
}

function Convert-MedicalFastWordStage($xml,[string]$stage,[int]$start,[int]$end){
 $namespaces=[Xml.XmlNamespaceManager]::new($xml.NameTable)
 $namespaces.AddNamespace('w',$script:ns)
 $body=$xml.SelectSingleNode('/w:document/w:body',$namespaces)
 $nodes=@($body.ChildNodes | Where-Object {$_ -is [Xml.XmlElement] -and $_.LocalName -ne 'sectPr'})
 for($i=0;$i -lt $nodes.Count;$i++){
  if($i -lt $start -or $i -ge $end){[void]$body.RemoveChild($nodes[$i])}
 }
 $replaceNextDiagnosis=$false
 foreach($p in @($body.SelectNodes('./w:p | ./w:sdt/w:sdtContent/w:p',$namespaces))){
  $text=(Get-MedicalFastWordText $p $namespaces).Trim()
  if($replaceNextDiagnosis -and $text){
   if($text -notmatch '\{\{(?:PRELIMINARY_DIAGNOSIS|DIAGNOSIS)\}\}'){
    Set-MedicalFastWordParagraph $p $namespaces '{{PRELIMINARY_DIAGNOSIS}}'
   }
   $replaceNextDiagnosis=$false
   continue
  }
  if($stage -eq 'initial' -and $text -match 'выставлен диагноз:\s*$'){
   $replaceNextDiagnosis=$true
  }elseif($stage -eq 'initial' -and $text -match 'Первичный\s+осмотр\s*$' -and $text -notmatch '\{\{ADMISSION_'){
   Set-MedicalFastWordParagraph $p $namespaces 'Первичный осмотр — {{ADMISSION_DATETIME}}'
  }elseif($stage -eq 'diary' -and $text -match '^\.*(?:\d{2}\.\d{2}\.)?\d{4}\s*г?\.?\s*в\s*\d{1,2}[.:]\d{2}\s*$'){
   Set-MedicalFastWordParagraph $p $namespaces '{{DIARY_PERIOD}} • {{ADMISSION_TIME}}'
  }elseif($text -match '^Ф\.?И\.?О\.?\s*:\s*г\.\s*р\.?\s*$'){
   Set-MedicalFastWordParagraph $p $namespaces 'Ф.И.О.: {{PATIENT_NAME}}. Дата рождения: {{PATIENT_BIRTH}}'
  }elseif($text -match '^г\.\s*р\.,'){
   $first=$p.SelectSingleNode('./w:r/w:t',$namespaces)
   if($first){Set-UniversalTextNode $first ('{{PATIENT_NAME}}, {{PATIENT_BIRTH}} '+$first.InnerText)}
  }elseif($text -match '^Место (?:жительства|регистрации|проживания):\s*Выберите элемент\.?$'){
   Set-MedicalFastWordParagraph $p $namespaces 'Адрес: {{PATIENT_ADDRESS}}'
  }elseif($stage -eq 'discharge' -and $text -match '^Диагноз:\s*Выберите элемент\.?$'){
   Set-MedicalFastWordParagraph $p $namespaces 'Диагноз: {{PRELIMINARY_DIAGNOSIS}}'
  }elseif($stage -eq 'discharge' -and $text -match '(?i)стационарном лечении.+\sс\s+по\s*\.$'){
   Set-MedicalFastWordParagraph $p $namespaces ($text -replace '\sс\s+по\s*\.$',' с {{TREATMENT_START_DATE}} по {{TREATMENT_END_DATE}}.')
  }
 }

 $text=Get-MedicalFastWordText $body $namespaces
 $firstParagraph=$body.SelectSingleNode('./w:p | ./w:sdt',$namespaces)
 $insertAfter=$firstParagraph.NextSibling
 if($stage -eq 'initial'){
  Add-MedicalFastWordParagraph $body $insertAfter $namespaces 'Черновик. Проверьте текст шаблона и сведения пациента.'
 }
 if($text -notmatch '\{\{ADMISSION_DATETIME\}\}' -and $text -notmatch '\{\{ADMISSION_DATE\}\}.*\{\{ADMISSION_TIME\}\}'){
  $dateLine=if($stage -eq 'discharge'){'Поступление: {{ADMISSION_DATETIME}}'}elseif($stage -eq 'diary'){'Дата записи: {{ADMISSION_DATETIME}}'}else{'Дата осмотра: {{ADMISSION_DATETIME}}'}
  Add-MedicalFastWordParagraph $body $insertAfter $namespaces $dateLine
 }
 if($stage -ne 'diary'){
  foreach($field in @(@('PATIENT_NAME','Ф.И.О.'),@('PATIENT_BIRTH','Дата рождения'),@('PATIENT_ADDRESS','Адрес'))){
   $marker='{{'+$field[0]+'}}'
   if(-not $text.Contains($marker)){Add-MedicalFastWordParagraph $body $insertAfter $namespaces ($field[1]+': '+$marker)}
  }
  if($text -notmatch '\{\{(?:DIAGNOSIS|PRELIMINARY_DIAGNOSIS)\}\}'){
   $section=$body.SelectSingleNode('./w:sectPr',$namespaces)
   Add-MedicalFastWordParagraph $body $section $namespaces 'Диагноз: {{PRELIMINARY_DIAGNOSIS}}'
  }
 }
 $starts=@{};$ends=@{}
 foreach($node in $body.SelectNodes('.//w:bookmarkStart',$namespaces)){$starts[$node.GetAttribute('id',$script:ns)]=$node}
 foreach($node in $body.SelectNodes('.//w:bookmarkEnd',$namespaces)){$ends[$node.GetAttribute('id',$script:ns)]=$node}
 foreach($id in $starts.Keys){if(-not $ends.ContainsKey($id)){[void]$starts[$id].ParentNode.RemoveChild($starts[$id])}}
 foreach($id in $ends.Keys){if(-not $starts.ContainsKey($id)){[void]$ends[$id].ParentNode.RemoveChild($ends[$id])}}
}

function Import-MedicalFastWordSet([string]$path){
 Assert-MedicalAccountPath $path
 Test-MedicalTemplateBytes ([IO.File]::ReadAllBytes($path))
 $inputArchive=[IO.Compression.ZipFile]::OpenRead($path)
 try{$source=Get-MedicalDiaryXml $inputArchive 'word/document.xml'}finally{$inputArchive.Dispose()}
 $namespaces=[Xml.XmlNamespaceManager]::new($source.NameTable)
 $namespaces.AddNamespace('w',$script:ns)
 $body=$source.SelectSingleNode('/w:document/w:body',$namespaces)
 $nodes=@($body.ChildNodes | Where-Object {$_ -is [Xml.XmlElement] -and $_.LocalName -ne 'sectPr'})
 $diary=-1;$discharge=-1
 for($i=0;$i -lt $nodes.Count;$i++){
  $caption=(Get-MedicalFastWordText $nodes[$i] $namespaces).Trim()
  if($diary -lt 0 -and $caption -match '^Дневники(?:\s+наблюдения)?\s*:?$'){$diary=$i}
  if($caption -match '^Выписной\s+эпикриз\s*:?$'){$discharge=$i;break}
 }
 if($discharge -le 0){throw 'В Word-файле не найден отдельный заголовок «Выписной эпикриз».'}
 $initialEnd=if($diary -ge 0){$diary}else{$discharge}
 if($initialEnd -le 0){throw 'Перед дневниками должен быть раздел первичного осмотра.'}
 $diaryEnd=$discharge
 if($diary -ge 0){
  $seenDate=$false
  for($i=$diary+1;$i -lt $discharge;$i++){
   $caption=(Get-MedicalFastWordText $nodes[$i] $namespaces).Trim()
   if($caption -match '^\.*(?:\d{2}\.\d{2}\.)?\d{4}\s*г?\.?\s*в\s*\d{1,2}[.:]\d{2}\s*$'){
    if($seenDate){$diaryEnd=$i;break}
    $seenDate=$true
   }
  }
 }
 $schemas=@{}
 $folder=Join-Path ([IO.Path]::GetTempPath()) ('mc-fast-word-'+[guid]::NewGuid().ToString('N'))
 [void][IO.Directory]::CreateDirectory($folder)
 try{
  $ranges=@(@('initial',0,$initialEnd,'Первичный осмотр'),@('discharge',$discharge,$nodes.Count,'Выписной эпикриз'))
  if($diary -ge 0){$ranges+=,@('diary',$diary,$diaryEnd,'Дневник наблюдения')}
  foreach($range in $ranges){
   $stage=[string]$range[0]
   $xml=[Xml.XmlDocument]$source.CloneNode($true)
   Convert-MedicalFastWordStage $xml $stage $range[1] $range[2]
   $copy=Join-Path $folder ($range[3]+[IO.Path]::GetExtension($path))
   [IO.File]::Copy($path,$copy)
   $archive=[IO.Compression.ZipFile]::Open($copy,[IO.Compression.ZipArchiveMode]::Update)
   try{Set-MedicalDiaryXml $archive 'word/document.xml' $xml}finally{$archive.Dispose()}
   $schema=New-MedicalSchemaFromTemplate $copy
   foreach($field in Get-UniversalFields $schema){$field.Required=$false}
   $schema | Add-Member -NotePropertyName PreserveTemplateFormatting -NotePropertyValue $true -Force
   $schemas[$stage]=$schema
  }
  [void](Get-MedicalFastIntakeFields $schemas.initial)
  [pscustomobject]@{Schema=$schemas.initial;Diary=$schemas.diary;Discharge=$schemas.discharge;DiarySamplesTrimmed=($diaryEnd -lt $discharge)}
 }finally{[IO.Directory]::Delete($folder,$true)}
}

function New-MedicalFastFormFromWord([string]$path){
 $pack=Import-MedicalFastWordSet $path
 $forms=New-MedicalClinicalFormData $pack.Schema
 if($pack.Diary){
  $forms.DiaryForm.Schema=$pack.Diary
  $forms.DiaryForm.Links=Get-MedicalClinicalDefaultLinks $pack.Diary $pack.Schema
 }
 $forms.Discharge.Schema=$pack.Discharge
 $forms.Discharge.Links=Get-MedicalClinicalDefaultLinks $pack.Discharge $pack.Schema
 $forms.Discharge.FollowInitialSchema=$false
 return [pscustomobject]@{
  Schema=$pack.Schema;StageForms=$forms;Name=[IO.Path]::GetFileNameWithoutExtension($path)
  UsesDefaultDiary=(-not $pack.Diary);DiarySamplesTrimmed=$pack.DiarySamplesTrimmed
 }
}

function Invoke-MedicalFastWordImport($owner){
 $picker=New-Object Windows.Forms.OpenFileDialog
 $picker.Filter='Файлы и шаблоны Word (*.docx;*.dotx)|*.docx;*.dotx'
 $picker.Title='Выберите Word-шаблон быстрой истории'
 $picker.InitialDirectory=Get-MedicalDocumentFolder 'Open'
 try{
  if($picker.ShowDialog($owner) -ne 'OK'){return}
  if(-not (Confirm-MedicalFormReset)){return}
  $formTemplate=New-MedicalFastFormFromWord $picker.FileName
  Use-MedicalFormSchema $formTemplate.Schema $formTemplate.Name '' $formTemplate.StageForms
  if($formTemplate.UsesDefaultDiary){
   [void][Windows.Forms.MessageBox]::Show($owner,'В файле нет раздела «Дневники». Добавлена типовая форма дневника. Её можно заменить перед сохранением комплекта.','Импорт из Word')
  }elseif($formTemplate.DiarySamplesTrimmed){
   [void][Windows.Forms.MessageBox]::Show($owner,'Первая запись дневника взята за общий шаблон. Остальные записи в исходном файле оставлены без изменений.','Импорт из Word')
  }
  Show-MedicalFastTemplateSetup $owner
 }catch{[void][Windows.Forms.MessageBox]::Show($owner,$_.Exception.Message,'Импорт из Word')}
 finally{$picker.Dispose()}
}
